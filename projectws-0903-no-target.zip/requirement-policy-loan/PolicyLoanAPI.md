# Parent API Specification: Policy Loan Instant Transaction Entry

## Endpoint
`POST /PolicyLoan/{partyId}/Execute`

## Description
提供線上保險平台、行動銀行統一發起「壽險保單質押借款撥付」(`operationType=A`) 與「質借還款結清解質」(`operationType=B`) 之對外標準 REST 端點。

### Request Body Schema (application/json)
```json
{
  "partyId": "A123456789",
  "policyNo": "POL2026083001",
  "policyType": "LIFE01",
  "bankAccountId": "01234567890123",
  "transactionDate": "20260830",
  "transactionDateTime": "11300000",
  "channelCode": "APP01",
  "operationType": "A",
  "amount": "0000300000",
  "sequenceNumber": "PL_TX_20260830_001",
  "originalSequenceNumber": null
}
```

### Response Schema (200 OK)
```json
{
  "track_id": "PL_TX_20260830_001",
  "workflow": "POLICY_LOAN_TRANSACTION",
  "status": 0,
  "finalStatus": "SUCCESS",
  "message": "保單質押借款撥付成功",
  "policyPledgeResult": {
    "status": 0,
    "message": "壽險保單質押圈存成功",
    "track_id": "ins-pledge-tx-101"
  },
  "coreBankingResult": {
    "status": 0,
    "message": "銀行帳戶撥款入帳成功",
    "track_id": "bank-credit-tx-202"
  },
  "policyRollbackResult": null,
  "auditSaved": true
}
```

