# Core Banking Account Transfer API Specification

## Endpoint
`POST /CoreBanking/{partyId}/Transfer/Execute`

## Description
銀行核心存款帳務主機 (Core Banking Account Host) 活期儲蓄帳戶質借撥款入帳及還款扣繳介面。
- `operationType = 'A'`: 質借撥款入帳 (Credit)
- `operationType = 'B'`: 還款扣款入帳 (Debit)

### Request Schema
```json
{
  "partyId": "A123456789",
  "bankAccountId": "01234567890123",
  "operationType": "A",
  "amount": "0000300000",
  "sequenceNumber": "PL_TX_20260830_001"
}
```

### Response Schema
```json
{
  "status": 0,
  "message": "銀行核心帳戶資金撥轉處理成功",
  "track_id": "bank-core-778899"
}
```

