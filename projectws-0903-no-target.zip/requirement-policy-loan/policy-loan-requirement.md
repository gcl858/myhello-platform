# 壽險保單質押借款與即時還款業務 (Policy Loan Instant Borrowing & Repayment) 需求規格書

## 1. 業務背景與場景概述
本業務為金控/壽險與銀行跨業整合之「線上人壽保單質押即時借款與還款解質」核心交易服務。保戶因臨時資金需求，透過行動銀行或線上保險服務平台，以名下具備保單價值準備金 (Surrender/Cash Value) 之有效人壽保險保單申請即時質押借款。流程須依序完成「壽險核心系統保價金檢核與質押圈存」以及「指定銀行活存帳號即時撥款入帳」兩階段 Saga 交易。若銀行撥款失敗，需即時回滾解除壽險保單之質押圈存；同時支援線上全額還款結清與解質沖銷作業，並具備 Parent 級冪等防護機制。

---

## 2. 核心架構設計 (Mode B: Parent + 2 Child Subflows)

```mermaid
flowchart TD
    Client[行動銀行 / 壽險 App] --> Parent[Parent: policy_loan_transaction]
    Parent -->|11 欄位檢核失敗| VFail[REJECTED_VALIDATION -> HTTP 400]
    Parent -->|Parent 級冪等命中| IdemHit[IDEMPOTENT_REPLAY -> HTTP 200]
    Parent -->|operationType == 'A'| WFA[Child WF-A: policy_loan_borrow]
    Parent -->|operationType == 'B'| WFB[Child WF-B: policy_loan_repayment]

    WFA -->|Step 1: 壽險保單質押圈存| PolicyPledge[Insurance Host: 檢核保價金並圈存質押]
    PolicyPledge -->|Step 2: 銀行帳戶撥款入帳| BankCredit[Core Banking: 質借撥款入帳]
    BankCredit -->|成功| Success[SUCCESS -> HTTP 200]
    BankCredit -->|失敗| Rollback[Insurance Host: 反向解除質押圈存 -> ROLLED_BACK / HTTP 200]

    WFB -->|Step 1: 查詢原交易| Lookup[Audit Log: 查原質借交易]
    Lookup -->|查無原交易| LF[LOOKUP_FAILED -> HTTP 500]
    Lookup -->|原交易非 SUCCESS / 已還款| CR[CANCEL_REJECTED -> HTTP 200]
    Lookup -->|Step 2: 銀行帳戶扣繳還款| BankDebit[Core Banking: 扣除還款本息]
    BankDebit -->|Step 3: 壽險主機解質沖銷| PolicyUnpledge[Insurance Host: 解除保單質押]
    PolicyUnpledge -->|Step 4: 標記已還款結清| MarkCancel[CANCELLED -> HTTP 200]
```

---

## 3. 欄位規範 (11 個核心業務欄位)

| 欄位名稱 | 欄位代碼 | 型態 | 必填 | 格式 / 正則規則 | 說明與範例 |
|---|---|---|---|---|---|
| 身分證號 / 統編 | `partyId` | String | 是 | `^[A-Za-z0-9]+$` | 保戶身分代碼，如 `A123456789` |
| 保險保單號碼 | `policyNo` | String | 是 | `^[A-Za-z0-9]{8,20}$` | 質押保單號碼，如 `POL2026083001` |
| 保單險種代碼 | `policyType` | String | 是 | `^[A-Za-z0-9]{3,8}$` | 保單險種代號，如 `LIFE01`, `ANNUITY02` |
| 銀行入扣帳帳號 | `bankAccountId` | String | 是 | `^[0-9]{10,16}$` | 撥款入帳 / 還款扣款活期儲蓄帳號，如 `01234567890123` |
| 交易日期 | `transactionDate` | String | 是 | `^[0-9]{8}$` | YYYYMMDD，如 `20260830` |
| 交易時間 | `transactionDateTime` | String | 是 | `^[0-9]{8}$` | HHMMSSNN，如 `11300000` |
| 通路代碼 | `channelCode` | String | 是 | `^[A-Za-z0-9]{1,10}$` | 發起通路代碼，如 `APP01`, `INS01` |
| 交易類別 | `operationType` | String | 是 | `^(A|B)$` | `A`: 保單質押借款撥付, `B`: 還款結清解除質押 |
| 借款/還款金額 | `amount` | String | 是 | `^(FAIL_)?[0-9]{1,14}$` | 質借/還款金額 (元)，如 `0000300000` (NT$ 300,000) |
| 本筆交易序號 | `sequenceNumber` | String | 是 | `^[A-Za-z0-9_]{1,32}$` | 全局唯一交易追蹤碼，如 `PL_TX_20260830_001` |
| 原交易序號 | `originalSequenceNumber` | String | 條件 | `^[A-Za-z0-9_]{1,32}$` | `operationType=B` 必填；`A` 必須為空 |

---

## 4. 狀態代碼與 HTTP Mapping

| finalStatus | 業務說明 | status | HTTP Status |
|---|---|---|---|
| `SUCCESS` | 保單質押借款撥付全流程成功 | 0 | 200 |
| `FAILED` | 壽險核心保單質押圈存失敗 (額度不足/保單無效) | 1 | 200 |
| `ROLLED_BACK` | 銀行撥款入帳失敗，壽險保單質押已自動解除圈存回滾 | 0 | 200 |
| `ROLLBACK_FAILED`| 撥款失敗且壽險解質回滾亦失敗 (需人工介入告警) | 1 | 409 |
| `CANCELLED` | 還款結清與保單解質成功 | 0 | 200 |
| `CANCEL_REJECTED`| 還款拒絕 (原交易非 SUCCESS 或已被結清解質) | 1 | 200 |
| `LOOKUP_FAILED` | 查無原質借交易紀錄 | 1 | 500 |
| `REJECTED_VALIDATION`| 輸入參數檢核失敗 | 1 | 400 |
| `IDEMPOTENT_REPLAY` | Parent 級冪等防重複重播 | 0 | 200 |

