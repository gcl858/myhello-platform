# Insurance Policy Pledge Host API Specification

## Endpoint
`POST /InsurancePolicy/{partyId}/Pledge/Execute`

## Description
壽險核心系統 (Life Insurance Policy Host) 負責保單價值準備金檢核、質押圈存鎖定與還款解質介面。
- `operationType = 'A'`: 質押圈存鎖定 (Pledge)
- `operationType = 'B'`: 解除質押解鎖 (Unpledge / Rollback)

### Request Schema
```json
{
  "partyId": "A123456789",
  "policyNo": "POL2026083001",
  "policyType": "LIFE01",
  "operationType": "A",
  "amount": "0000300000",
  "sequenceNumber": "PL_TX_20260830_001"
}
```

### Response Schema
```json
{
  "status": 0,
  "message": "壽險保單質押圈存處理成功",
  "track_id": "ins-pledge-889900"
}
```

