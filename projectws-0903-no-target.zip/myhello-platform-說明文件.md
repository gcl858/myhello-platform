# myhello-platform — 企業級 SonataFlow 金融交易編排平台

> **文件版本**：v1.0
> **撰寫日期**：2026-09-02
> **目標讀者**：內部研發團隊(新進 Onboarding、跨團隊教育、Workflow 開發 SOP 參考)
> **對應程式碼版本**：`myhello_project_0830` / `project-0825-pd` v1.2.x

---

## 目錄 (Table of Contents)

- [第 1 章:技術框架](#第-1-章技術框架)
  - [1.1 技術棧總覽](#11-技術棧總覽)
  - [1.2 核心元件說明](#12-核心元件說明)
  - [1.3 為什麼選這些技術](#13-為什麼選這些技術)
- [第 2 章:專案架構](#第-2-章專案架構)
  - [2.1 多模組樹狀圖](#21-多模組樹狀圖)
  - [2.2 模組職責定義表](#22-模組職責定義表)
  - [2.3 模組依賴有向無環圖 (DAG)](#23-模組依賴有向無環圖-dag)
  - [2.4 dev / prod Profile 物理隔離](#24-dev--prod-profile-物理隔離)
  - [2.5 儲存拓撲與共用 Volume](#25-儲存拓撲與共用-volume)
- [第 3 章:案例 1 — saga2-transfer-workflow](#第-3-章案例-1--saga2-transfer-workflow)
  - [3.1 業務背景](#31-業務背景)
  - [3.2 整體流程圖](#32-整體流程圖)
  - [3.3 核心設計點](#33-核心設計點)
  - [3.4 關鍵 YAML 解析](#34-關鍵-yaml-解析)
  - [3.5 補償時序(樂觀路徑 / LIFO 全回沖 / A16229-only 回沖)](#35-補償時序)
- [第 4 章:案例 2 — omni-cash-transaction](#第-4-章案例-2--omni-cash-transaction)
  - [4.1 業務背景](#41-業務背景)
  - [4.2 整體流程圖(Parent + 2 Child)](#42-整體流程圖parent--2-child)
  - [4.3 核心設計點](#43-核心設計點)
  - [4.4 關鍵 YAML 解析](#44-關鍵-yaml-解析)
  - [4.5 subflow merge 時序圖](#45-subflow-merge-時序圖)
  - [4.6 八個 finalStatus 對映表](#46-八個-finalstatus-對映表)
- [第 5 章:兩案例對比](#第-5-章兩案例對比)
- [第 6 章:專案總覽與設計理念](#第-6-章專案總覽與設計理念)
  - [6.1 專案定位](#61-專案定位)
  - [6.2 核心特色:AI 驅動的需求 → 實作一條龍](#62-核心特色ai-驅動的需求--實作一條龍)
  - [6.3 與傳統開發流程的差異](#63-與傳統開發流程的差異)
- [第 7 章:開發方式 — 從需求到測試驗證](#第-7-章開發方式--從需求到測試驗證)
  - [7.1 整體開發鏈](#71-整體開發鏈)
  - [7.2 設計期(Step 0~4):vibe-workflow-design-v2](#72-設計期step-04vibe-workflow-design-v2)
  - [7.3 整合期(Step 0~10):sonataflow-integration](#73-整合期step-010sonataflow-integration)
- [第 8 章:兩支 Skill 詳解(SOP + 踩坑對照)](#第-8-章兩支-skill-詳解sop--踩坑對照)
  - [8.1 vibe-workflow-design-v2](#81-vibe-workflow-design-v2)
  - [8.2 sonataflow-integration](#82-sonataflow-integration)
- [第 9 章:附錄](#第-9-章附錄)
  - [9.1 測試覆蓋一覽](#91-測試覆蓋一覽)
  - [9.2 Data Index GraphQL 查詢範例](#92-data-index-graphql-查詢範例)
  - [9.3 部署拓撲](#93-部署拓撲)
  - [9.4 未來演進路線](#94-未來演進路線)

---
# 第 1 章:技術框架

## 1.1 技術棧總覽

| 分類 | 技術 | 版本 | 角色 |
|---|---|---|---|
| 語言 | Java | 17 (release) | 主要開發語言 |
| 建置 | Maven | 3.8+ | 多模組 reactor 建置;父 POM 統一版本管理 |
| Runtime | Quarkus | 3.27.2 | 雲原生 Java 框架(響應式、記憶體友善、GraalVM native 支援) |
| Workflow 引擎 | Apache Kogito / SonataFlow | 10.2.0 (kie) | CNCF Serverless Workflow 規格實作引擎 |
| Workflow 規格 | Serverless Workflow | v0.8 | `*.sw.yaml` 使用的語法版本 |
| 編排資料 | jackson-jq | 隨 Kogito | workflow 內的 jq 表達式 |
| 持久化(預設) | SQLite WAL | 3.45.1.0 (sqlite-jdbc) | 本機 + UAT + 單機 prod |
| 持久化(可選) | PostgreSQL | 14+ | 企業級 prod |
| 資料遷移 | Flyway(自製 runner) | — | 掃描 `db/migration/`,V 編號遞增 |
| HTTP Client | Java 11+ `java.net.http.HttpClient` | — | `MyOpenApiService` 用,自帶指數退避重試 |
| API 規格 | OpenAPI | 3.0 | `notebooks/*.yaml` |
| 測試框架 | JUnit 5 + REST Assured | 5.5.0 | E2E 測試,走 HTTP 端點觸發 workflow |
| Data Index | Kogito Data Index + Quarkus + SQLite | 10.2.0 | 流程實例即時索引,GraphQL 查詢 |
| Logging | SLF4J + Quarkus log file | — | 統一日誌格式,含 `%d{HH:mm:ss} %-5p [%c{3.}]` |
| AI Skill | Custom Skill(整合於 Mavis) | v1.0+ | 兩支 skill 串成開發鏈 |

## 1.2 核心元件說明

### 1.2.1 Quarkus 3.27.2

選擇 Quarkus 而非 Spring Boot 的理由:

- **GraalVM Native Image 支援** — native 編譯後啟動 < 100ms、記憶體 < 50MB,適合 FaaS / K8s autoscaling
- **響應式 I/O**(Mutiny + Vert.x)— 高併發下資源消耗遠低於傳統 servlet 模型
- **與 Kogito 整合最自然** — Kogito 官方 `kogito-addons-quarkus-*` 系列擴充點皆為 Quarkus 設計
- **Build-time classpath 掃描** — 配置錯誤在 build 階段就會失敗,提早發現

### 1.2.2 Apache Kogito / SonataFlow 10.2.0

`kogito` 是 `drools` 團隊在 Red Hat 孵化的雲原生決策與流程引擎,專注於:

- **Serverless Workflow v0.8** 規格的 Quarkus 整合
- **Code generation** — 從 `*.sw.yaml` 在 build 階段產生 Java 程式碼(可觀察的 `Process<>-` class)
- **Process Management** — 流程實例的啟動、暫停、恢復、查詢
- **Source Files Addon** — 允許 workflow 與 Java 程式碼放在同一個模組(本專案的核心)

> **注意**:本專案鎖定 Kogito 10.2.0 有一個重要的踩坑點——任何含 `subFlowRef` 且 workflow id 含 hyphen(`-`)的 workflow 會在 codegen 階段壞掉。**解法**:用 `snake_case` 命名(詳見第 8 章)。

### 1.2.3 Serverless Workflow v0.8

CNCF 的 workflow 規格,本專案用到的主要概念:

| 概念 | 用途 | 範例 |
|---|---|---|
| `states` | 流程的基本單位,`type` 有 `operation` / `switch` / `inject` / `event` | 見 saga2 / omni |
| `operation` | 呼叫外部函式(`functionRef` 或 `subFlowRef`) | `CallA16229State`、`CallWFARepayment` |
| `switch` | 條件分支,`dataConditions` + `defaultCondition` | `CheckA16229Result`、`Dispatcher` |
| `inject` | 純設定 state data(無副作用) | `InjectSuccessStatus` |
| `functions` | 對應 Java FQCN 的可呼叫函式 | `callApiViaOpenAPI`、`recordAuditLog` |
| `errors` | 平台層錯誤定義,用於 `onErrors` | `platformError` |
| `metadata` | 標籤,供 Data Index GraphQL 過濾 | `domain / pattern / criticality / owner` |
| `timeouts` | 動作或狀態層級逾時 | `actionExecTimeout: PT15S` |
| `actionDataFilter` | action 回應的擷取規則 | `results: '{code: .code, ...}'` |
| `stateDataFilter.output` | workflow 最終輸出的 jq 模板 | 統一終點的對外契約 |
| `subFlowRef` | 委派給子 workflow | `omni_cash_transaction` 委派 `repayment_cash_deposit` |

### 1.2.4 SQLite WAL

預設儲存引擎,選 SQLite 的理由:

- **零運維** — 單一檔案,`DatabaseMigrationRunner` 自動掃描 `db/migration/`
- **WAL 模式** — 讀寫並發,workflow 寫 AuditLog 與對帳查詢不互鎖
- **企業級替代** — 透過 `kogito-addons-quarkus-data-index-persistence-postgresql` 切換 PostgreSQL 即可

## 1.3 為什麼選這些技術

| 決策 | 理由 |
|---|---|
| Java 17 | LTS,Pattern Matching / Records 簡化程式碼;Kogito 10.x 最低需求 |
| Maven(非 Gradle) | 企業內部 Maven mirror(Aliyun)穩定;`mvn -pl` 多模組管理成熟 |
| Quarkus 3.27.2 | Kogito 10.2.0 官方測試矩陣支援;啟動快、native 友善 |
| Serverless Workflow v0.8 | 雲原生標準,語法宣告式、易讀;非 imperative 流程引擎 |
| SQLite 預設 | 單機 + 開發環境零部署成本;切換 PG 只需換 JDBC driver |
| 兩支 Skill | 把隱性知識結構化;AI Agent 可獨立完成端到端開發 |

---

# 第 2 章:專案架構

## 2.1 多模組樹狀圖

```mermaid
graph TD
    Root["myhello-platform (parent POM)<br/>v1.0.0-SNAPSHOT"]

    Root --> PlatformCommon["platform-common<br/>(公用工具層)"]
    Root --> PlatformSecurity["platform-security<br/>(安全 / JAX-RS Filter)"]
    Root --> PlatformExtensions["platform-extensions<br/>(Quarkus extension 擴充點)"]
    Root --> PlatformDataIndex["platform-data-index<br/>(Data Index 共用設定)"]
    Root --> DomainTransfer["domain-transfer<br/>(轉帳業務域)"]
    Root --> DomainReconciliation["domain-reconciliation<br/>(對帳審計業務域)"]
    Root --> Distribution["distribution<br/>(可執行應用)"]
    Root -. dev profile only .-> Dev["dev/<br/>(示範 + 外部 mock)"]

    DomainTransfer --> TransferWorkflow["transfer-workflow<br/>(7 個 workflow + MyOpenApiService)"]

    DomainReconciliation --> ReconciliationApi["reconciliation-api<br/>(AuditLog + Idempotency + CSV)"]

    Distribution --> TransferApp["transfer-app<br/>(Quarkus 8080)"]
    Distribution --> ReconciliationApp["reconciliation-app<br/>(Quarkus 8081, 5 個 HTML 頁面)"]

    Dev --> TransferMock["transfer-mock<br/>(A16229/A16220 等 host API mock)"]
    Dev --> TransferSamples["transfer-samples<br/>(ApiService 範例,UAT 端點)"]

    PlatformExtensions --> Ext1["data-index-storage-sqlite"]
    PlatformExtensions --> Ext2["kogito-addons-data-index-persistence-sqlite"]
    PlatformExtensions --> Ext3["kogito-addons-data-index-sqlite"]
```

## 2.2 模組職責定義表

| 模組 | 角色 | 主要產出 | 何時被引用 |
|---|---|---|---|
| `platform-common` | 公用工具 | `PlatformPaths`(日誌目錄解析)、共用工具類 | 所有模組 |
| `platform-security` | 安全 / 過濾 | `WorkflowStatusFilter`(ContainerResponseFilter,改寫 HTTP code) | 所有對外 endpoint |
| `platform-extensions` | Quarkus 擴充 | 自製 SQLite Data Index 擴充點 | Kogito 啟動時 |
| `platform-data-index` | Data Index 共用設定 | `application.properties` base | transfer-app / reconciliation-app |
| `domain-transfer` | 轉帳業務域 | `transfer-workflow` 模組 | 業務方呼叫 |
| `domain-reconciliation` | 對帳審計業務域 | `reconciliation-api` 模組(`AuditLogService` / `IdempotencyService` / `OpsAlertService` / `ReconciliationCsvExporter`) | workflow 統一終點呼叫 |
| `distribution` | 可執行應用 | `transfer-app` + `reconciliation-app` 兩個獨立的 Quarkus 應用 | K8s 部署 |
| `dev/transfer-mock` | 外部系統 mock | A16229 / A16220 / CoreAccount 等 host API 模擬 | dev profile 啟用 |
| `dev/transfer-samples` | 範例流程 | `ApiService`(呼叫 UAT 銀行端點) | dev profile 啟用 |

## 2.3 模組依賴有向無環圖 (DAG)

```mermaid
graph LR
    TC["transfer-workflow"] --> PCA["platform-common"]
    TC --> RA["reconciliation-api"]
    RA --> PCA
    RA --> PS["platform-security"]
    PS --> PCA
    TA["transfer-app"] --> TC
    TA --> RA
    TA --> PDI["platform-data-index"]
    TA --> PS
    RA2["reconciliation-app"] --> RA
    RA2 --> PDI
    RA2 --> PS
    TM["transfer-mock<br/>(dev)"] --> PCA
    TS["transfer-samples<br/>(dev)"] --> PCA

    style TC fill:#ffe4b5
    style RA fill:#b0e0e6
    style TA fill:#f0e68c
    style RA2 fill:#f0e68c
```

**核心守則**(違反即 review block):

1. **單向依賴** — `platform-*` 不知道 `domain-*` 存在;`domain-*` 不知道 `distribution-*` 存在
2. **無循環依賴** — 任何 `A → B → A` 模式禁止
3. **dev 模組只依賴 platform** — `dev/transfer-mock` 與 `dev/transfer-samples` 不可依賴 `domain-*`,確保 prod 物理隔離
4. **業務域隔離** — `domain-transfer` 只透過 `reconciliation-api` 公開介面寫 AuditLog,不直接存取 DB

## 2.4 dev / prod Profile 物理隔離

這是平台重要的安全設計:

```mermaid
flowchart TB
    subgraph Default["預設 (mvn package)"]
        D1[platform-*]
        D2[domain-transfer]
        D3[domain-reconciliation]
        D4[distribution]
        D5[dev/transfer-mock]
        D6[dev/transfer-samples]
        D1 --> D2 --> D3 --> D4
        D1 --> D5
        D1 --> D6
    end

    subgraph Prod["-P prod"]
        P1[platform-*]
        P2[domain-transfer]
        P3[domain-reconciliation]
        P4[distribution]
        P1 --> P2 --> P3 --> P4
    end
```

**為什麼要物理隔離?**

| dev 模組 | 風險 |
|---|---|
| `transfer-mock` | 暴露 A16229 / A16220 / CoreAccount mock 端點,若部署到 prod 會被誤連,造成測試交易污染真實帳務 |
| `transfer-samples` | `ApiService.java` 硬編 UAT 網址 + client_id 屬敏感資訊 |

**機制**:

- 父 POM 內 `<profile id="dev">` 預設啟用,`<profile id="prod">` 透過 `-P prod` 啟用
- prod profile **不列** `<module>dev</module>`,Maven reactor 自動排除
- prod profile 設 `<skipTests>true</skipTests>`,prod 測試應於外部 IT 環境跑
- `application.properties` 內 dev-only 設定用 `%dev.kogito.sw.functions.xxx=...` 前綴,prod 自動失效

## 2.5 儲存拓撲與共用 Volume

```mermaid
graph TB
    subgraph Container1["transfer-app (8080)"]
        WF1[7 個 workflow]
        DB1[(SQLite WAL<br/>data/transfer.db)]
        Logs1[logs/transfer-app.log]
    end

    subgraph Container2["reconciliation-app (8081)"]
        WF2[Reconciliation API]
        HTML[5 個 HTML 頁面<br/>META-INF/resources]
        Logs2[logs/reconciliation-app.log]
    end

    subgraph SharedVolume["共用 Volume (NFS / PV)"]
        AuditDB[(workflow_execution_log<br/>audit.db)]
    end

    Container1 -.寫 AuditLog.-> SharedVolume
    Container2 -.讀取 + 匯出.-> SharedVolume
    Container1 -.DB 檔掛載.-> PV1[(data/)]
    Container2 -.DB 檔掛載.-> PV1
```

**關鍵設計**:

- `workflow_execution_log` 透過共用 Volume 或獨立的 `audit.db` SQLite 檔,讓 `transfer-app` 寫、`reconciliation-app` 讀
- 兩個 app 的 logs 目錄透過 `MYHELLO_LOGS_DIR` 環境變數指向外部路徑,容器重啟不丟失
- `platform-common/PlatformPaths` 統一解析路徑(預設 `logs/`,可被環境變數覆寫)

---

# 第 3 章:案例 1 — saga2-transfer-workflow

> **檔案**:`domain-transfer/transfer-workflow/src/main/resources/saga2-transfer-workflow.sw.yaml`
> **版本**:v2.2.0
> **模式**:A — 單層 Saga LIFO(2 階段提交 + 業務規則觸發補償)
> **終態數**:6 個(`SUCCESS` / `FAILED` / `ROLLED_BACK` / `VALIDATION_FAILED` / `ROLLBACK_FAILED`)

## 3.1 業務背景

**情境**:客戶 A 帳號(`Account_A`)轉帳給客戶 B 帳號(`Account_B`),金額 `AMT`。

**雙階段**:

1. 呼叫 **A16229** API(從 `Account_A` 扣款,`EC=false`)
2. 呼叫 **A16220** API(對 `Account_B` 入帳,`EC=false`)

**業務規則**:當 `AMT > 500`,視為「大額交易」,觸發 **LIFO 回沖**(雙邊 EC=true 補償)。

**Saga 補償原則**:

- 任一階段失敗或業務規則未過,觸發 LIFO 回沖
- LIFO = 後進先出:先回沖 A16220,再回沖 A16229
- 任一補償失敗 → `ROLLBACK_FAILED`(需人工介入,HTTP 409)

## 3.2 整體流程圖

```mermaid
stateDiagram-v2
    [*] --> ValidateInput

    ValidateInput --> InjectValidationFailedStatus: 欄位錯誤
    ValidateInput --> CallA16229State: 通過

    CallA16229State --> CheckA16229Result
    CheckA16229Result --> CallA16220State: code==100
    CheckA16229Result --> InjectFailedStatus: 失敗

    CallA16220State --> CheckA16220Result
    CheckA16220Result --> DecideByEvaluation: code==100
    CheckA16220Result --> RollbackA16229Only: 失敗

    DecideByEvaluation --> InjectSuccessStatus: AMT <= 500
    DecideByEvaluation --> RollbackA16220: AMT > 500

    RollbackA16220 --> RollbackA16229
    RollbackA16229 --> CheckRollbackResults

    RollbackA16229Only --> CheckRollbackA16229OnlyResult
    CheckRollbackA16229OnlyResult --> InjectRolledBackOnlyStatus: code==100
    CheckRollbackA16229OnlyResult --> InjectRollbackFailedStatus: 失敗

    CheckRollbackResults --> InjectRolledBackStatus: 都成功
    CheckRollbackResults --> InjectRollbackFailedStatus: 任一失敗

    InjectSuccessStatus --> FinalAuditAndEnd
    InjectFailedStatus --> FinalAuditAndEnd
    InjectRolledBackStatus --> FinalAuditAndEnd
    InjectRolledBackOnlyStatus --> FinalAuditAndEnd
    InjectRollbackFailedStatus --> FinalAuditAndEnd
    InjectValidationFailedStatus --> FinalAuditAndEnd

    FinalAuditAndEnd --> [*]
```

## 3.3 核心設計點

### 3.3.1 三層防線 — 任何錯誤都收斂到統一終點

| 防線 | 機制 | 觸發情境 |
|---|---|---|
| **服務層** | `MyOpenApiService` 自行吞例外 → 標準化 body `{code: "999", errorType: "TRANSPORT"}` | 連線拒絕 / HTTP 逾時 / 4xx / 5xx |
| **引擎層** | operation state 的 `actionExecTimeout: PT15S` + `stateExecTimeout: PT30S` | 引擎中斷(逾時 / jq 例外 / 未攔截例外) |
| **Workflow 層** | `onErrors → errorRef: platformError` 攔截,路由到語義正確的終點 | state timeout / 引擎例外 / 服務未攔截例外 |

> **為什麼 timeout 要 > HTTP 逾時?** `MyOpenApiService` 預設 10s,設 15s 是讓服務層先回標準化錯誤,而非引擎中斷拖到 `workflowExecTimeout: PT5M` 才結束,造成 AuditLog 缺失。

### 3.3.2 errorType 分流 — 失敗原因可觀測

`MyOpenApiService` 把失敗分成 4 類:

| errorType | 場景 | retry 策略 |
|---|---|---|
| `TRANSPORT` | 連線拒絕、逾時、無回應 | ✅ 可重試(已內建指數退避) |
| `BUSINESS` | host 回 2xx 但 `code != "100"` | ❌ 不重試,直接走補償 |
| `HTTP_4XX` | 400 / 404 等客戶端錯誤 | ❌ 不重試,通常資料錯 |
| `HTTP_5XX` | 500 / 502 / 503 等伺服器錯誤 | ✅ 可重試(但本 workflow 不自動重試,人工介入) |

`actionDataFilter` 統一收進 state data,供稽核與未來重試分流:

```yaml
results: '{code: .code, message: .message, Account: .Account, errorType: .errorType, _httpStatus: ._httpStatus}'
```

### 3.3.3 樣板慣例(P2-1):正向條件 + 安全 default

每個 switch state 採用「**只列正向條件 + 安全 default**」結構,避免冗餘的全覆蓋條件,並讓 default 永遠是安全策略:

```yaml
- name: CheckA16229Result
  type: switch
  dataConditions:
    - name: a16229Success
      condition: '${ .a16229Result.code == "100" }'
      transition: CallA16220State
  defaultCondition:
    transition: InjectFailedStatus   # 安全策略:未明確成功視為失敗
```

### 3.3.4 統一終點 FinalAuditAndEnd — 三件大事

1. **寫 AuditLog**(`AuditLogService::saveLog`)— 不掛 onErrors,服務自吞例外,寫入結果浮現於 `auditSaved`
2. **條件告警**(`OpsAlertService::raise`)— `finalStatus=ROLLBACK_FAILED` 時進 `[OPS-ALERT]` 日誌通道
3. **統一對外契約**(`stateDataFilter.output`)— 所有路徑(含 onErrors 兜底)收斂同一份輸出模板

### 3.3.5 Saga 語義正確性 — onErrors 路由語義

| state | onErrors 路由 | 原因 |
|---|---|---|
| `ValidateInput` | `InjectValidationFailedStatus` | 還沒扣款,標 `VALIDATION_FAILED` |
| `CallA16229State` | `InjectFailedStatus` | 還沒扣款,標 `FAILED` |
| `CallA16220State` | `RollbackA16229Only` | 已扣 A16229,必須補償,不可直接 FAILED 收尾 |
| `RollbackA16220` | `InjectRollbackFailedStatus` | 補償鏈中斷,需人工 |
| `RollbackA16229` | `InjectRollbackFailedStatus` | 補償鏈中斷,需人工 |

## 3.4 關鍵 YAML 解析

### 3.4.1 函式定義與 metadata

```yaml
id: saga2-transfer-workflow
version: '2.2.0'
specVersion: '0.8'
name: Saga2 Transfer Workflow
start: ValidateInput

metadata:                       # Data Index GraphQL 過濾用
  domain: transfer
  pattern: saga-lifo-compensation
  criticality: high
  owner: platform-team

timeouts:
  workflowExecTimeout: PT5M     # 最後防線

errors:
  - name: platformError         # ⚠️ Kogito 要求 error 定義必須含 code,否則整條被忽略
    code: 'PLATFORM_ERROR'
    description: 平台層非預期錯誤 (state timeout / 引擎例外 / 服務未攔截例外)

functions:
  - name: callApiViaOpenAPI
    operation: 'service:com.example.transfer.workflow.MyOpenApiService::callOpenApi'
    type: custom
  - name: recordAuditLog
    operation: 'service:com.example.reconciliation.AuditLogService::saveLog'
    type: custom
  - name: notifyOps
    operation: 'service:com.example.reconciliation.OpsAlertService::raise'
    type: custom
```

### 3.4.2 ValidateInput — 11 條驗證規則(條件順序即回報優先序)

```yaml
- name: ValidateInput
  type: switch
  onErrors:
    - errorRef: platformError
      transition: InjectValidationFailedStatus
  dataConditions:
    - name: accountAInvalid
      # jackson-jq 不支援 test(),改用 match() // false == false 判斷
      # 欄位缺失/null 先以 // "" 收斂為空字串,避免對 null 做 match 拋例外
      condition: '${ ((.Account_A // "") | match("^[A-Za-z0-9_]+$") // false) == false }'
      transition: InjectValidationFailedStatus
    - name: amtInvalid
      condition: '${ .AMT | type != "number" }'
      transition: InjectValidationFailedStatus
    - name: sameAccount
      condition: '${ .Account_A == .Account_B }'
      transition: InjectValidationFailedStatus
  defaultCondition:
    transition: CallA16229State
```

### 3.4.3 CallA16229State — 通用 OpenAPI 呼叫樣板

```yaml
- name: CallA16229State
  type: operation
  timeouts:
    actionExecTimeout: PT15S     # 須 > MyOpenApiService HTTP 逾時 10s
    stateExecTimeout: PT30S
  onErrors:
    - errorRef: platformError
      transition: InjectFailedStatus
  actions:
    - name: callA16229Action
      functionRef:
        refName: callApiViaOpenAPI
        arguments:
          functionName: "callApiViaOpenAPI"        # base-url 快取 key
          schemaRef: 'specs/A16229-api.yaml#executeA16229'  # 動態綁定
          payload:
            Account_A: '${ .Account_A }'
            AMT: '${ .AMT }'
            EC: false                              # 正向交易
      actionDataFilter:
        # ⭐ 從 MyOpenApiService 頂層讀取,不是 .result.code
        results: '{code: .code, message: .message, Account: .Account, errorType: .errorType, _httpStatus: ._httpStatus}'
        toStateData: '${ .a16229Result }'
  transition: CheckA16229Result
```

### 3.4.4 FinalAuditAndEnd — 統一終點(對外契約)

```yaml
- name: FinalAuditAndEnd
  type: operation
  timeouts:
    actionExecTimeout: PT10S
    stateExecTimeout: PT20S
  actions:
    - name: saveFinalAuditLog
      functionRef:
        refName: recordAuditLog
        arguments:
          workflowId: "saga2-transfer-workflow"
          businessKey: '${ .Account_A }'           # 業務鍵
          processInstanceId: '${ $WORKFLOW.instanceId }'
          inputData: { Account_A: '${ .Account_A }', Account_B: '${ .Account_B }', AMT: '${ .AMT }' }
          outputData:
            status: '${ .finalStatus }'
            message: '${ .finalMessage }'
            a16229Result: '${ .a16229Result }'
            a16220Result: '${ .a16220Result }'
            a16229Rollback: '${ .a16229Rollback }'
            a16220Rollback: '${ .a16220Rollback }'
        actionDataFilter:
          results: '{saved: .saved}'
          toStateData: '${ .auditResult }'
    - name: raiseOpsAlertIfRequired
      functionRef:
        refName: notifyOps
        arguments:
          workflowId: "saga2-transfer-workflow"
          processInstanceId: '${ $WORKFLOW.instanceId }'
          businessKey: '${ .Account_A }'
          finalStatus: '${ .finalStatus }'
          finalMessage: '${ .finalMessage }'
        actionDataFilter:
          results: '{raised: .raised}'
          toStateData: '${ .opsAlert }'
  stateDataFilter:
    output: |
      {
        status: .finalStatus,
        message: .finalMessage,
        AMT: .AMT,
        a16229Result: (.a16229Result // null),
        a16220Result: (.a16220Result // null),
        a16229Rollback: (.a16229Rollback // null),
        a16220Rollback: (.a16220Rollback // null),
        auditSaved: (.auditResult.saved // false),
        opsAlertRaised: (.opsAlert.raised // false)
      }
  end: true
```

## 3.5 補償時序

### 3.5.1 樂觀路徑(AMT <= 500,全成功)

```mermaid
sequenceDiagram
    autonumber
    participant C as 呼叫端
    participant W as workflow
    participant S as MyOpenApiService
    participant A29 as A16229 主機
    participant A20 as A16220 主機
    participant DB as AuditLog

    C->>W: POST /saga2-transfer-workflow<br/>{Account_A, Account_B, AMT: 100}
    W->>W: ValidateInput ✓
    W->>S: callOpenApi(A16229, payload)
    S->>A29: POST (EC=false)
    A29-->>S: 200 {code: "100"}
    S-->>W: {code: "100", Account, errorType: null}
    W->>S: callOpenApi(A16220, payload)
    S->>A20: POST (EC=false)
    A20-->>S: 200 {code: "100"}
    S-->>W: {code: "100", Account, errorType: null}
    W->>W: DecideByEvaluation: AMT <= 500
    W->>W: InjectSuccessStatus
    W->>DB: recordAuditLog(status: "SUCCESS")
    W-->>C: 200 {status: "SUCCESS", message: "交易成功", auditSaved: true}
```

### 3.5.2 LIFO 全回沖路徑(AMT > 500 → 觸發補償)

```mermaid
sequenceDiagram
    autonumber
    participant C as 呼叫端
    participant W as workflow
    participant S as MyOpenApiService
    participant A29 as A16229 主機
    participant A20 as A16220 主機
    participant DB as AuditLog
    participant OPS as OPS-ALERT

    C->>W: POST /saga2-transfer-workflow {AMT: 1000}
    W->>S: callOpenApi(A16229)
    S->>A29: POST (EC=false)
    A29-->>S: 200 {code: "100"}
    W->>S: callOpenApi(A16220)
    S->>A20: POST (EC=false)
    A20-->>S: 200 {code: "100"}
    W->>W: DecideByEvaluation: AMT > 500
    Note over W: 觸發 LIFO 回沖
    W->>S: rollbackA16220 (EC=true)
    S->>A20: POST (EC=true)
    A20-->>S: 200 {code: "100"}
    W->>S: rollbackA16229 (EC=true)
    S->>A29: POST (EC=true)
    A29-->>S: 200 {code: "100"}
    W->>W: CheckRollbackResults ✓
    W->>W: InjectRolledBackStatus
    W->>DB: recordAuditLog(status: "ROLLED_BACK")
    W-->>C: 200 {status: "ROLLED_BACK", message: "AMT > 500 觸發 saga 回沖 (LIFO)"}
```

### 3.5.3 A16229-only 回沖路徑(A16220 失敗但 A16229 補償成功)

```mermaid
sequenceDiagram
    autonumber
    participant C as 呼叫端
    participant W as workflow
    participant S as MyOpenApiService
    participant A29 as A16229 主機
    participant A20 as A16220 主機
    participant DB as AuditLog

    C->>W: POST /saga2-transfer-workflow {AMT: 300}
    W->>S: callOpenApi(A16229)
    S->>A29: POST (EC=false)
    A29-->>S: 200 {code: "100"} ✓
    W->>S: callOpenApi(A16220)
    S->>A20: POST (EC=false)
    A20-->>S: 200 {code: "200" BUS_FAIL}
    Note over W: CheckA16220Result:<br/>code != "100" → 觸發 A16229-only 回沖
    W->>S: rollbackA16229 (EC=true)
    S->>A29: POST (EC=true)
    A29-->>S: 200 {code: "100"} ✓
    W->>W: InjectRolledBackOnlyStatus
    W->>DB: recordAuditLog(status: "ROLLED_BACK")
    W-->>C: 200 {status: "ROLLED_BACK", message: "A16220 業務失敗,僅回沖 A16229"}
```

---

# 第 4 章:案例 2 — omni-cash-transaction

> **檔案**:`domain-transfer/transfer-workflow/src/main/resources/omni-cash-transaction.sw.yaml`(snake_case!)
> **版本**:v1.0.1
> **模式**:B — Parent + 2 Child Subflow(統一入口,dispatcher 路由)
> **終態數**:8 個(`SUCCESS` / `FAILED` / `ROLLED_BACK` / `CANCELLED` / `CANCEL_*` 系列 / `LOOKUP_FAILED` / `IDEMPOTENT_REPLAY`)

## 4.1 業務背景

**情境**:信用卡臨櫃現金繳款的**統一入口**,依 `operationType` 路由:

- `operationType=A` → WF-A `repayment_cash_deposit`(正向繳款,Core+CC 兩階段)
- `operationType=B` → WF-B `repayment_cash_cancellation`(取消繳款,先 lookup 原 SUCCESS,再反向)

**業務痛點**(從 v1.0 演進到 v2.2 Parent 架構):

| 舊問題 | Parent 架構解法 |
|---|---|
| 繳款 / 取消走不同端點,呼叫端邏輯分散 | 單一 `/omni_cash_transaction` 入口 |
| 無統一取消機制 | WF-B 標準化反向流程 |
| 無對帳軌跡 | Parent 級 AuditLog + idempotency |
| 兩個主機任一失敗,系統無法保證最終一致 | Parent 統一補償 + WF-A LIFO |

**冪等性**:

- **Parent 級**(`BR-502`):同 `sequenceNumber` 重送由 `IdempotencyCheck` 攔截,回 `IDEMPOTENT_REPLAY`
- **Child 級**:各 child 不重複去重,沿用 host 主機的 `BR-501` 冪等

## 4.2 整體流程圖(Parent + 2 Child)

```mermaid
flowchart TB
    Start([POST /omni_cash_transaction]) --> V[ValidateInput<br/>11 欄驗證]

    V -- 失敗 --> IVR[InjectValidationFailedStatus<br/>REJECTED_VALIDATION]
    V -- 通過 --> ID[IdempotencyCheck]

    ID -- 命中已收斂 --> IIR[InjectIdempotentReplayStatus<br/>IDEMPOTENT_REPLAY]
    ID -- 未命中/失敗 --> DIS[Dispatcher]

    DIS -- opType=A --> CWA[CallWFARepayment<br/>subflowRef]
    DIS -- opType=B --> CWB[CallWFBCCancellation<br/>subflowRef]
    DIS -- 其他 --> IVR

    CWA --> SubA[Child: repayment_cash_deposit<br/>Core+CC 兩階段 + LIFO]
    CWB --> SubB[Child: repayment_cash_cancellation<br/>lookup + 反向]

    SubA --> MAP[MapToParentFinalStatus]
    SubB --> MAP

    MAP -- SUCCESS --> IS[InjectSuccessStatus]
    MAP -- FAILED --> IF[InjectFailedStatus]
    MAP -- ROLLED_BACK --> IRB[InjectRolledBackStatus]
    MAP -- ROLLBACK_FAILED --> IRF[InjectRollbackFailedStatus]
    MAP -- CANCELLED --> IC[InjectCancelledStatus]
    MAP -- CANCEL_REJECTED --> ICR[InjectCancelRejectedStatus]
    MAP -- CANCEL_FAILED --> ICF[InjectCancelFailedStatus]
    MAP -- CANCEL_ROLLED_BACK --> ICRB[InjectCancelRolledBackStatus]
    MAP -- CANCEL_ROLLBACK_FAILED --> ICRF[InjectCancelRollbackFailedStatus]
    MAP -- LOOKUP_FAILED --> ILF[InjectLookupFailedStatus]
    MAP -- 未知 --> IPU[InjectParentUnknown]

    IVR --> FINAL
    IIR --> FINAL
    IS --> FINAL
    IF --> FINAL
    IRB --> FINAL
    IRF --> FINAL
    IC --> FINAL
    ICR --> FINAL
    ICF --> FINAL
    ICRB --> FINAL
    ICRF --> FINAL
    ILF --> FINAL
    IPU --> FINAL

    FINAL[FinalAuditAndEnd<br/>寫 AuditLog + 條件告警] --> End([HTTP 200/400/409/500])
```

## 4.3 核心設計點

### 4.3.1 workflow id 為何用 snake_case?

Kogito 10.2.0 有個 **codegen bug**——任何含 `subFlowRef` 且 workflow id 含 hyphen(`-`)的 workflow 會在 build 階段壞掉。

| workflow | id | 子流程 | 結果 |
|---|---|---|---|
| `saga2-transfer-workflow` | 含 hyphen 但**無 subFlowRef** | 無 | ✅ 可用 kebab-case |
| `omni-cash-transaction`(原本) | 含 hyphen + 有 subFlowRef | 有 | ❌ 編譯失敗 |
| `omni_cash_transaction`(修正) | snake_case + 有 subFlowRef | 有 | ✅ 編譯通過 |

> 整併時的修正腳本見第 8 章。

### 4.3.2 Parent 級冪等(`IdempotencyService`)

```yaml
- name: IdempotencyCheck
  type: operation
  timeouts:
    actionExecTimeout: PT5S
    stateExecTimeout: PT10S
  onErrors:
    # 冪等查詢失敗視為未命中(保險絲),繼續 dispatcher
    - errorRef: platformError
      transition: Dispatcher
  actions:
    - name: findExistingBySequenceNumber
      functionRef:
        refName: checkIdempotency
        arguments:
          workflowId: "omni_cash_transaction"
          businessKey: '${ .sequenceNumber }'        # 業務鍵
        actionDataFilter:
          results: '{found: .found, priorFinalStatus: .priorFinalStatus, priorResult: .priorResult}'
          toStateData: '${ .idempotencyResult }'
  transition: CheckIdempotencyResult

- name: CheckIdempotencyResult
  type: switch
  dataConditions:
    - name: idempotentHit
      condition: '${ .idempotencyResult.found == true and ((.idempotencyResult.priorFinalStatus // "") | length) > 0 and (.idempotencyResult.priorFinalStatus != "DISPATCHED") }'
      transition: InjectIdempotentReplayStatus
  defaultCondition:
    transition: Dispatcher
```

> **設計細節**:`priorFinalStatus != "DISPATCHED"` 是為了區分「正在進行中」與「已收斂」。已收斂的 finalStatus 才是命中。

### 4.3.3 Dispatcher — 依 operationType 路由

```yaml
- name: Dispatcher
  type: switch
  dataConditions:
    - name: dispatchToWFA
      condition: '${ .operationType == "A" }'
      transition: CallWFARepayment
    - name: dispatchToWFB
      condition: '${ .operationType == "B" }'
      transition: CallWFBCCancellation
  defaultCondition:
    transition: InjectValidationFailedStatus
```

> **為什麼不直接拒絕非 A/B?** 讓 default 路由到 `InjectValidationFailedStatus` 是「安全策略」——任何 `jq` 評估出錯或欄位漂移都不會靜默通過,都會回 HTTP 400。

### 4.3.4 subFlowRef — Serverless Workflow v0.8 規範

**重要**:Serverless Workflow v0.8 已 **REPLACED** 了舊的 `SubFlow state`,正確寫法是 `operation state` 內的 `subFlowRef` action type:

```yaml
- name: CallWFARepayment
  type: operation
  actions:
    - name: callWFARepaymentAction
      subFlowRef:
        workflowId: repayment_cash_deposit        # 子 workflow id(snake_case!)
        version: "1.0"
  onErrors:
    - errorRef: platformError
      transition: InjectParentPlatformFailed
  transition: MapToParentFinalStatus
```

**subflow merge 機制**:

- 當前 workflow data 自動傳入子 workflow
- 子 workflow `end` 時,其 `stateDataFilter.output` 會 merge 回父 workflow data
- 後續 state 可直接讀 `.finalStatus` / `.coreResult` / `.ccResult`

### 4.3.5 MapToParentFinalStatus — 1:1 對映 + 安全網

```yaml
- name: MapToParentFinalStatus
  type: switch
  dataConditions:
    - name: fromWFASuccess
      condition: '${ .finalStatus == "SUCCESS" }'
      transition: InjectSuccessStatus
    # ... 10 個正向列舉
    - name: fromWFBLookupFailed
      condition: '${ .finalStatus == "LOOKUP_FAILED" }'
      transition: InjectLookupFailedStatus
  defaultCondition:
    transition: InjectParentUnknown          # 安全網:沒對應到任何已知值
```

### 4.3.6 統一終點 — 新 convention 對外契約

```yaml
stateDataFilter:
  output: |
    {
      track_id: .sequenceNumber,
      workflow: (if .operationType == "A" then "REPAYMENT" else "CANCELLATION" end),
      status: (if .finalStatus == "SUCCESS" or .finalStatus == "CANCELLED" or .finalStatus == "ROLLED_BACK" or .finalStatus == "CANCEL_ROLLED_BACK" or .finalStatus == "IDEMPOTENT_REPLAY" then 0 else 1 end),
      finalStatus: .finalStatus,
      message: .finalMessage,
      coreResult: (.coreResult // null),
      ccResult: (.ccResult // null),
      coreRollbackResult: (.coreRollbackResult // null),
      lookupResult: (.lookupResult // null),
      auditSaved: (.auditResult.saved // false),
      opsAlertRaised: (.opsAlert.raised // false)
    }
```

**新 convention 與 saga2(舊 convention)的差異**:

| 欄位 | saga2(舊) | omni(新) |
|---|---|---|
| `status` | string | int(0=成功, 1=失敗) |
| `finalStatus` | 無 | string |
| 對應 HTTP code 改寫 | 讀 `status`(string) | 優先讀 `finalStatus`,退回 `status` |

> 這是 `WorkflowStatusFilter` 同時支援兩種 convention 的向下相容設計(見第 8 章 6c)。

## 4.4 關鍵 YAML 解析

### 4.4.1 ValidateInput — 11 欄驗證(含條件必填)

```yaml
- name: ValidateInput
  type: switch
  dataConditions:
    - name: partyIdInvalid
      condition: '${ ((.partyId // "") | match("^[A-Za-z0-9]+$") // false) == false }'
      transition: InjectValidationFailedStatus
    # ... 中略 8 條
    - name: amountInvalid
      condition: '${ ((.amount // "") | match("^(FAIL_)?[0-9]+$") // false) == false }'
      transition: InjectValidationFailedStatus
    - name: amountNotPositive
      # 0 或 "0000000000" 視為 0;FAIL_ 哨兵 (mock 用) 放行
      condition: '${ ((.amount // "") as $a | ($a == "0" or $a == "0000000000" or (($a | startswith("FAIL_") | not) and ($a | tonumber) <= 0))) }'
      transition: InjectValidationFailedStatus
    - name: opTypeAWithOriginalSeq
      # operationType=A 不可帶 originalSequenceNumber (BR-P03)
      condition: '${ .operationType == "A" and ((.originalSequenceNumber // "") | length) > 0 }'
      transition: InjectValidationFailedStatus
    - name: opTypeBMissingOriginalSeq
      # operationType=B 必填 originalSequenceNumber (BR-P03)
      condition: '${ .operationType == "B" and ((.originalSequenceNumber // "") | length) == 0 }'
      transition: InjectValidationFailedStatus
  defaultCondition:
    transition: IdempotencyCheck
```

> **設計巧思**:`amountNotPositive` 用 `startswith("FAIL_")` 守衛,讓 mock 可以用 `FAIL_TIMEOUT` / `FAIL_BUS_REJECT` 觸發失敗路徑而不被 `tonumber` 拋例外。

## 4.5 subflow merge 時序圖

```mermaid
sequenceDiagram
    autonumber
    participant C as 呼叫端
    participant P as Parent<br/>(omni_cash_transaction)
    participant IDP as IdempotencyService
    participant CH as Child<br/>(repayment_cash_deposit)
    participant S as MyOpenApiService
    participant CORE as Core 主機
    participant CC as CC 主機
    participant DB as AuditLog

    C->>P: POST /omni_cash_transaction<br/>{operationType: "A", sequenceNumber, ...}
    P->>P: ValidateInput ✓ (11 欄)
    P->>IDP: findBySequenceNumber
    IDP-->>P: {found: false, priorFinalStatus: null}
    P->>P: Dispatcher: opType=A
    P->>CH: subFlowRef(repayment_cash_deposit, 1.0)<br/>自動傳入當前 data
    Note over CH: 二次驗證 ValidateChildInput
    CH->>S: callOpenApi(CoreAccount, opType=A)
    S->>CORE: POST (opType=A)
    CORE-->>S: 200 {status: 0, result: {sequenceNumber: "..."}}
    S-->>CH: {status: 0, ...}
    CH->>S: callOpenApi(CreditCard, opType=A)
    S->>CC: POST (opType=A)
    CC-->>S: 200 {status: 0}
    S-->>CH: {status: 0}
    Note over CH: 兩階段都成功
    CH->>DB: recordAuditLog(status: "SUCCESS")
    CH-->>P: stateDataFilter.output merge<br/>{finalStatus: "SUCCESS", coreResult, ccResult}
    P->>P: MapToParentFinalStatus: SUCCESS → InjectSuccessStatus
    P->>DB: recordAuditLog(Parent 級)
    P-->>C: 200 {track_id, workflow: "REPAYMENT", status: 0, finalStatus: "SUCCESS", ...}
```

## 4.6 八個 finalStatus 對映表

| finalStatus | HTTP code | status (int) | 觸發情境 | 來源 child |
|---|---|---|---|---|
| `SUCCESS` | 200 | 0 | 繳款兩階段皆成功 | WF-A |
| `FAILED` | 200 | 1 | 繳款業務失敗(階段 1) | WF-A |
| `ROLLED_BACK` | 200 | 0 | 繳款階段 2 失敗,Core 補償成功 | WF-A |
| `ROLLBACK_FAILED` | 409 | 1 | 繳款階段 2 失敗,Core 補償也失敗(需人工) | WF-A |
| `CANCELLED` | 200 | 0 | 取消流程成功 | WF-B |
| `CANCEL_REJECTED` | 200 | 1 | 取消被拒(原交易非 SUCCESS) | WF-B |
| `CANCEL_FAILED` | 200 | 1 | 取消業務失敗(階段 1) | WF-B |
| `CANCEL_ROLLED_BACK` | 200 | 0 | 取消階段 1 失敗,Core 反向成功 | WF-B |
| `CANCEL_ROLLBACK_FAILED` | 409 | 1 | 取消 Core 反向失敗(需人工) | WF-B |
| `LOOKUP_FAILED` | 500 | 1 | 取消時找不到原 transaction | WF-B |
| `IDEMPOTENT_REPLAY` | 200 | 0 | 冪等重送(命中 Parent 級 cache) | Parent 自身 |
| `REJECTED_VALIDATION` | 400 | 1 | 輸入驗證失敗 | Parent 自身 |
| `PARENT_PLATFORM_FAILED` | 500 | 1 | Parent 平台層錯誤兜底 | Parent 自身 |
| `PARENT_UNKNOWN` | 500 | 1 | 未知 child finalStatus(安全網) | Parent 自身 |

---

# 第 5 章:兩案例對比

| 面向 | saga2-transfer-workflow | omni-cash-transaction |
|---|---|---|
| **模式** | A 單層 Saga LIFO | B Parent + 2 Child Subflow |
| **workflow id** | `saga2-transfer-workflow`(kebab-case) | `omni_cash_transaction`(snake_case) |
| **輸入欄位** | 3 個(Account_A, Account_B, AMT) | 11 個(含 operationType 條件必填) |
| **業務子情境** | 1 個(轉帳) | 2 個(繳款 / 取消),dispatcher 路由 |
| **終態數** | 6 個 | 8~14 個(依 child finalStatus 對映) |
| **業務觸發補償** | `AMT > 500` | 全靠 child LIFO 觸發,Parent 不做業務規則 |
| **冪等** | 無(靠呼叫端 Idempotency-Key) | Parent 級(查 AuditLog)+ Child 級(沿用 host) |
| **Convention** | 舊(`status: STRING`) | 新(`status: 0/1` int + `finalStatus: STRING`) |
| **subflow** | 無 | 有 2 個 child,merge 回 Parent data |
| **HTTP 改寫** | 讀 `status` 欄位 | 優先讀 `finalStatus`,退回 `status` |
| **Operations / States** | 22 個 state(11 個 operation + 11 個 switch/inject) | 24+ 個 state(Parent 11 + Child A 9 + Child B 12) |
| **適用場景** | 簡單雙階段提交 + 業務規則觸發補償 | 多入口業務 + 統一對外契約 + 跨主機最終一致 |

**選型指引**:

- **業務流程單純、單一入口** → saga2 模式
- **業務流程多入口、需統一審計與對外契約、跨多個主機** → omni 模式

---

# 第 6 章:專案總覽與設計理念

## 6.1 專案定位

`myhello-platform` 是一個**專為金融級分散式交易編排與即時對帳所打造的雲原生微服務平台**,從早期單一模組架構演進為**高內聚、低耦合、領域驅動(DDD)的多模組架構**。平台以 CNCF Serverless Workflow 規格為基礎,結合 Quarkus 響應式框架與 Apache Kogito 引擎,提供:

- **毫秒級啟動、低記憶體佔用** — 適合 K8s / FaaS 部署
- **Saga 分散式交易模式** — 編排式(Orchestrator)正向交易與逆向補償,LIFO 完整回沖 + 短路容錯
- **強一致性對帳** — 所有 workflow 終點必寫 `AuditLog`,任何終態都可被審計/重放
- **可觀測性** — 統一終點 + 條件告警 + Data Index GraphQL 即時查詢流程實例

平台已落地 7 個金融業務 workflow(轉帳、信用卡還款、跨行匯款、基金下單、FX 結算、貸款撥款、信用卡繳款),全部共享同一套**可靠性樣板**與**整合 SOP**。

## 6.2 核心特色:AI 驅動的需求 → 實作一條龍

本專案最與眾不同的一點:**兩支 skill 串成一條 AI 驅動的開發鏈**,把「業務需求文件 + Host API 規格」到「可運行、可測試的 workflow」之間的落差,變成可重複、可驗證的標準程序。

```mermaid
flowchart LR
    A[業務需求書<br/>BR-XXX] --> B[Host API 規格<br/>OpenAPI YAML]
    B --> C["vibe-workflow-design-v2<br/>(設計期 Skill)"]
    A --> C
    C --> D[draft 套件<br/>workflow YAML + OpenAPI + DDL + Mock Java + Test + spec.md]
    D --> E["sonataflow-integration<br/>(整合期 Skill)"]
    E --> F[project-0825-pd<br/>多模組 Quarkus 平台]
    F --> G[mvn test<br/>E2E 驗證]
    G --> H{測試通過?}
    H -- 否 --> I[回到 Step 4 / 6 修正]
    I --> E
    H -- 是 --> J[上線]

    style C fill:#ffe4b5,stroke:#ff8c00
    style E fill:#b0e0e6,stroke:#4682b4
    style D fill:#f0f8ff,stroke:#4682b4
```

| 階段 | Skill | 角色 | 產出 |
|---|---|---|---|
| **設計期** | `vibe-workflow-design-v2` | 業務架構師 / AI Agent | 完整可整併的 `draft-<name>/` 套件 |
| **整合期** | `sonataflow-integration` | 平台工程師 / AI Agent | `project-0825-pd` 內的多模組程式碼 + 測試 |

**為什麼是 Skill 而不是 Library?**

這兩支 skill 把**經驗**編碼成**可重複的步驟 + 自我檢查 + 已知踩坑解法**。傳統的「Library / Framework」提供的是**程式碼**,但金融交易 workflow 開發最大的成本是「知道要避開哪些坑」、「要對齊哪些平台假設」、「要符合哪些 convention」——這些都是**隱性知識**,而 skill 把隱性知識外顯化、結構化,讓 AI Agent 也能像資深工程師一樣產出符合規範的程式碼。

## 6.3 與傳統開發流程的差異

| 面向 | 傳統流程 | 本專案流程 |
|---|---|---|
| 需求 → workflow 設計 | 手寫 `*.sw.yaml`,憑經驗 | `vibe-workflow-design-v2` 強制走 Step 0~4 + 8 項設計期自檢 + 6 項平台相容性預檢 |
| workflow → 上線 | 工程師手動複製檔案 + 改 package + 處理整合 bug | `sonataflow-integration` 6-step SOP,內建 5 個 Kogito 10.2.0 已知 bug 修正腳本 |
| 對齊 convention | 各自解讀、文件散落 | `spec.md §0` 假設清單為單一事實來源,convention 明確標註(舊 / 新 / 純 HTTP) |
| 測試 | 開發完才寫 | 設計期就產出 5+ 個 E2E 案例(含 happy path + 主要 error path) |
| 跨團隊交接 | 口頭 + 零散文件 | `draft/<name>/spec.md` 14 條假設 + Project Mapping Manifest 對應正式路徑 |

**一句話總結**:本專案把 workflow 開發從「手藝」升級為「可重複的工程製程」。

---


# 第 7 章:開發方式 — 從需求到測試驗證

## 7.1 整體開發鏈

```mermaid
flowchart LR
    subgraph S1["Step 0-1 業務調研 + 拆解"]
        A0[Step 0<br/>5 個必問<br/>平台/模組/Host API/DB/對外契約]
        A1[Step 1<br/>寫 spec.md §0 假設清單<br/>識別 5 種模式 A-E]
    end

    subgraph S2["Step 2-4 設計期產出物"]
        A2[Step 2<br/>產出 OpenAPI specs<br/>3 種角色:對外 / host / mock]
        A3[Step 3<br/>產出 workflow YAML<br/>+ 6 項平台相容性預檢]
        A4[Step 4<br/>補 Java 服務 FQCN<br/>（既有擴充 / 新建）]
    end

    subgraph S3["Step 5-7 設計期自檢"]
        A5[Step 5<br/>Mock package 對齊<br/>path param 注入]
        A6[Step 6<br/>actionDataFilter 結構<br/>convention 對齊]
        A7[Step 7<br/>15+ 項 self-check<br/>+ spec.md §8 §9]
    end

    subgraph S4["Step 8 測試設計"]
        A8[Step 8<br/>5+ 個 E2E 案例<br/>happy path + 主要 error path]
    end

    subgraph S5["整合期 sonataflow-integration"]
        B0[Step 0<br/>環境檢查<br/>Java 17 / Maven mirror]
        B1[Step 1<br/>分析 draft 結構<br/>讀 spec.md §0 §8]
        B2[Step 2-3<br/>落規格 + workflow YAML<br/>+ 套用 Kogito bug 修正]
        B3[Step 4-5<br/>補 Java service<br/>+ 落 mock resource]
        B4[Step 6<br/>4 個 workflow 內容修正<br/>path param / actionDataFilter<br/>status-rewrite / SQL view]
        B5[Step 7-8<br/>合併 application.properties<br/>+ 落測試]
        B6[Step 9-10<br/>mvn 編譯 + 測試 + package<br/>+ E2E smoke test]
    end

    A0 --> A1 --> A2 --> A3 --> A4 --> A5 --> A6 --> A7 --> A8
    A8 --> B0 --> B1 --> B2 --> B3 --> B4 --> B5 --> B6
    B6 --> Result{測試通過?}
    Result -- 否 --> A4
    Result -- 是 --> Done[上線]
```

## 7.2 設計期(Step 0~4):vibe-workflow-design-v2

### Step 0:前置調研(5 個必問)

| # | 問題 | 影響 |
|---|---|---|
| 0a | 目標平台是哪個?(SonataFlow 10.2.0 / 其他 Kogito 版本 / Camunda / Airflow) | 決定 workflow YAML dialect、可用 function |
| 0b | 整合到哪個既有 project?模組結構為何? | 決定 package 命名、service 位置 |
| 0c | 有哪些 host API 規格?(OpenAPI / AsyncAPI / 純文件) | 決定 spec 檔案產出格式 |
| 0d | DB / 對帳目標是什麼?(SQLite + Flyway / Postgres / 無) | 決定 V 編號起點、View DDL 必要性 |
| 0e | 對外 API contract 與 mock 端點需求? | 決定 test 套件設計 |

### Step 1:業務需求拆解

1a. 寫 `spec.md` 草稿(§0 假設清單 H1-Hn + §1 概覽 + §2 輸入輸出)
- **H<sub>n</sub> 必須明確標註「FQCN 假設」**,這是下游識別要新建/擴充 service 的唯一依據

1b. 識別 workflow 結構模式(5 種常見)

| 模式 | 適用情境 | 典型架構 |
|---|---|---|
| **A. 單層 Saga LIFO** | 跨 1 個外部系統,2 階段提交 | workflow 內: Forward → Check → (Rollback if fail) → End |
| **B. Parent + 2 個 Child Subflow** | 業務多入口,依 dispatcher 路由 | Parent: Validate → Idempotency → Dispatcher → (subflow) → End |
| **C. 多層 Parent** | 多層級審批 / 多階段業務流 | 多個 Parent 互相 subflow 委派 |
| **D. 事件驅動** | 接收外部事件觸發 | EventListener → Validate → Process |
| **E. 計時 / 排程** | 排程觸發 | Timer → Validate → Process |

1c. 識別「終態 vs 業務碼」分離需求(Convention 決策)

| Convention | 適用情境 | 對應 HTTP 改寫需求 |
|---|---|---|
| 舊(saga2) | `status: STRING` | 需 status-rewrite 改寫 HTTP code |
| 新(omni) | `status: 0/1` int + `finalStatus: STRING` | 需 status-rewrite 改寫 HTTP code |
| 純 HTTP status | 對外不需 finalStatus,直接靠 HTTP code 區分 | 不需 status-rewrite |

### Step 2:產出 OpenAPI specs(3 種角色)

- **2a 對外契約 spec**:放 `notebooks/<entry-name>.yaml`,含完整 request/response schema
- **2b Host API 規格**:一個 host 一個 spec,`parameters: [in: path]` 區段務必明確
- **2c Mock 規格**:mock 的 `@Path` 與 spec 的 `paths` 必須一致(若有 path param 設計時就要明確標出)

### Step 3:產出 workflow YAML

- **3a 平台相容性預檢(必跑)**

| 檢查 | 不通過時 |
|---|---|
| Kogito 10.2.0 + 含 subFlowRef + workflow id 含 hyphen | 改 snake_case |
| actionDataFilter 用 `.result.X` | 改用頂層欄位 |
| path param 未在 payload | 自動加 |
| output 缺 `status: 0/1` + `finalStatus: STRING`(新 convention) | 補上 |
| YAML 有 trailing comma | 移除 |

- **3b YAML 結構樣板**:依 Step 1b 識別的模式,對應到 5 種樣板

- **3c ActionDataFilter 結構守則**:`MyOpenApiService::callOpenApi` 回傳是頂層,不是 `.result`

```yaml
# ✅ 對
results: '{code: .code, message: .message, errorType: .errorType, _httpStatus: ._httpStatus}'

# ❌ 錯
results: '{status: .result.code, ...}'
```

- **3d StateDataFilter Output 結構守則**:依 convention 決定

### Step 4:補 Java 服務

讀 `spec.md §0` 假設清單,找出所有 FQCN,在 draft 階段就明確:

- 既有 service 擴充方法:`AuditLogService::findBySequenceNumber`
- 新建 service 類別:`IdempotencyService::findBySequenceNumber`

> 完整 Step 4a~4d 見第 8 章。

## 7.3 整合期(Step 0~10):sonataflow-integration

### Step 0:環境檢查

- 確認 Java 17、Maven 3.8+ 可用
- 確認 Maven mirror 已設定(Aliyun `https://maven.aliyun.com/repository/central`)
- 確認 JVM truststore 含企業 proxy cert

### Step 1:分析 draft 結構

預期 draft 內含結構:

```
draft-<name>/
├── notebooks/
│   ├── internal/             # 對外契約 / 動態路由 spec (含 x-workflow-id，作為輸入驗證 SSOT)
│   │   └── <entry-api>.yaml
│   ├── <api-2>-api.yaml      # host call spec
│   └── <api-3>-api.yaml
├── spec/
│   ├── <workflow-1>.sw.yaml
│   ├── <workflow-2>.sw.yaml
│   ├── db/V<X>.<Y>.<Z>__<desc>.sql
│   ├── config/application.properties.snippet
│   ├── mocks/<Resource>1.java
│   ├── mocks/dto/*.java
│   └── tests/<TestName>.java
└── spec.md                    # 規格書,內含 14 條假設清單
```

**關鍵讀取點**:

1. 讀 `spec.md` §0 假設清單(H1-Hn),找出需要新建/修改的 Java 服務
2. 讀 §8 Project Mapping Manifest,確認 draft 規劃的目標路徑
3. 檢查每個 `*.sw.yaml` 的 `functions:` section,識別需要新 service bean 的 FQCN

### Step 2:落規格檔(純複製,無變形)

| draft 路徑 | 目標路徑 |
|---|---|
| `notebooks/internal/*.yaml` (含 x-workflow-id) | `<project>/domain-transfer/transfer-workflow/src/main/resources/specs/internal/`<br/>`<project>/distribution/transfer-app/src/main/resources/specs/internal/` |
| `notebooks/*.yaml` (外部 host API) | `<project>/domain-transfer/transfer-workflow/src/main/resources/specs/`<br/>`<project>/distribution/transfer-app/src/main/resources/specs/` |
| `spec/db/V*.sql` | `<project>/domain-transfer/transfer-workflow/src/main/resources/db/migration/` |

### Step 3:落 workflow YAML + 套用 Kogito bug 修正(見第 8 章踩坑)

### Step 4:補 Java 服務(見第 8 章)

### Step 5:落 mock resources(見第 8 章)

### Step 6:4 個 workflow 內容修正(見第 8 章踩坑對照)

### Step 7:合併 application.properties

```properties
# 1. 加 N 個 workflow 到 status-rewrite 名單
platform.status-rewrite.workflows=saga2-transfer-workflow,omni_cash_transaction,repayment_cash_deposit,repayment_cash_cancellation

# 2. 加 finalStatus 對映
platform.status-rewrite.mapping=\
VALIDATION_FAILED=400,\
ROLLBACK_FAILED=409,\
REJECTED_VALIDATION=400,\
LOOKUP_FAILED=500,\
CANCEL_ROLLBACK_FAILED=409

# 3. dev profile function bean 註冊
%dev.kogito.sw.functions.checkIdempotency.bean=idempotencyService
%dev.kogito.sw.functions.lookupOriginalTransaction.bean=auditLogService
```

### Step 8:落測試

```bash
cp draft/spec/tests/*.java <project>/distribution/transfer-app/src/test/java/com/example/platform/distribution/transfer/
# package 替換
```

### Step 9:編譯 → 測試 → package

```bash
# 9a 編譯
mvn -B compile -DskipTests -fae -T 1 -Dmaven.wagon.http.retryHandler.count=10

# 9b 測試
find ~/.m2/repository -name "*.lastUpdated" -delete
mvn -B test -fae -T 1 -Dmaven.wagon.http.retryHandler.count=10

# 9c package(必須從根跑)
mvn -B package -DskipTests -fae -T 1 -Dmaven.wagon.http.retryHandler.count=10
```

**預期時間**:編譯 1-2min、測試 5-10min、package 3-5min(首次下載 20-30min)

### Step 10:端對端 smoke test

啟動 transfer-app,curl 觸發 workflow,驗證 AuditLog、Data Index。

---

# 第 8 章:兩支 Skill 詳解(SOP + 踩坑對照)

> 本章按「**方法論 → 對應踩坑**」的順序撰寫,每個 Step 末尾用 callout 標註對應的 Kogito 10.2.0 已知問題。

## 8.1 vibe-workflow-design-v2

### 8.1.1 Skill 套件結構

```
vibe-workflow-design-v2/
├── SKILL.md                          # SOP 主文件
├── examples/                         # 完整範例
│   ├── 01-financial-repayment/       # 金融信用卡繳款 (Mode B,真實案例)
│   ├── 02-ecommerce-order/           # 電商訂單履行 (Mode A 範本)
│   └── 03-insurance-claim/           # 保險理賠 (Mode B 跨領域)
└── references/                       # 可重用資源
    ├── 01-platform-checks/           # 6 項平台相容性預檢
    ├── 02-self-check/                # 15 項 self-check 清單
    ├── 03-templates/                 # 5 種 workflow YAML 範本
    ├── 04-config-snippets/           # application.properties.snippet 完整模板
    └── 05-fqcn-template/             # spec.md §0 假設清單完整模板
```

### 8.1.2 核心方法論:8 項設計期自我檢查守則

這 8 項守則是從 8 個真實整併踩坑**上移為設計期預防**——把問題消滅在 spec 階段,而非整合時才發現。

| # | 守則 | 對應踩坑 |
|---|---|---|
| 1 | workflow id 一律 snake_case(有 subFlowRef 時) | Kogito 10.2.0 codegen bug |
| 2 | actionDataFilter 從頂層讀(`.code` 而非 `.result.code`) | `MyOpenApiService` 結構假設 |
| 3 | 顯式 path param 注入(避免 `Illegal character in path`) | 整合期 6a 坑 |
| 4 | stateDataFilter.output 對齊 convention(舊/新/純 HTTP) | `WorkflowStatusFilter` 讀錯欄位 |
| 5 | YAML 結構驗證(無 trailing comma) | YAML 解析錯誤 |
| 6 | mock sentinel 通過 input validation(用 `FAIL_` 前綴守衛) | mock 拋 `tonumber` 例外 |
| 7 | mock package 對齊既有專案(避免 rename) | 整併期 sed 二次替換陷阱 |
| 8 | 測試資料走 input validation(動態序號避免重觸 Parent 冪等) | 測試誤觸 IDEMPOTENT_REPLAY |

### 8.1.3 設計期 6 項平台相容性預檢

`references/01-platform-checks/` 內每個檢查都有自動檢查腳本:

1. **workflow-id-naming** — Kogito 10.2.0 + subFlowRef + hyphen → fail
2. **action-data-filter** — grep `.result.X` 模式 → fail
3. **path-parameter-injection** — OpenAPI path 的 `{xxx}` 必須在 payload 內有對應
4. **state-data-filter-convention** — output 必須符合選定的 convention
5. **yaml-strictness** — 檢查 trailing comma
6. **mock-sentinel-vs-input-validation** — `FAIL_` 哨兵必須通過 `tonumber` 守衛

### 8.1.4 設計期 15+ 項 Self-Check 清單

`references/02-self-check/self-check-list.md` 完整清單,設計完成後逐項驗證(摘錄):

| # | 檢查項 | 對應預檢 |
|---|---|---|
| 7.1 | `spec.md §0` 含 FQCN 假設 | — |
| 7.2 | `spec.md §0` 含 id 命名決策(snake_case / kebab-case) | 01 |
| 7.3 | `spec.md §0` 含 convention 決策(舊/新/純 HTTP) | 04 |
| 7.4 | OpenAPI path param 與 workflow payload 對應 | 03 |
| 7.5 | actionDataFilter 用頂層欄位 | 02 |
| 7.16 | Input Validation Regex 與 API Sample 相容(如 `2500P` 通路碼) | 06 |
| 7.17 | 測試案例採動態唯一序號(避免誤觸 Parent 冪等) | — |
| 7.18 | jq 條件 `tonumber` 防呆 | 06 |
| 7.19 | Workflow Root 顯式定義 `start: <StateName>` | 01 |

## 8.2 sonataflow-integration

### 8.2.1 套件結構

```
sonataflow-integration/
└── SKILL.md                          # 6-step SOP + 5 個已知踩坑解法
```

### 8.2.2 6-step SOP

| Step | 名稱 | 主要動作 |
|---|---|---|
| 0 | 環境檢查 | Java 17 / Maven mirror / truststore |
| 1 | 分析 draft 結構 | 讀 `spec.md` §0 + §8 + 識別 FQCN |
| 2 | 落規格檔 | notebooks (specs, specs/internal) / db migration |
| 3 | 落 workflow YAML + Kogito bug 修正 | 複製 + 套用 hyphen id 修正腳本 |
| 4 | 補 Java 服務 | 既有擴充 + 新建 class |
| 5 | 落 mock resources | package 替換(小心二次替換陷阱) |
| 6 | 4 個 workflow 內容修正 | path param / actionDataFilter / status-rewrite / SQL view |
| 7 | 合併 application.properties | status-rewrite + function bean 註冊 |
| 8 | 落測試 | 複製 + package 替換 |
| 9 | mvn 編譯 + 測試 + package | 三階段 + 預期時間 |
| 10 | E2E smoke test | curl 觸發 + 驗證 AuditLog |

### 8.2.3 5 個 Kogito 10.2.0 已知踩坑 + 解法

> 這是本平台最寶貴的知識——踩過一次就別再踩第二次。

#### 踩坑 #1:Hyphen workflow id + subFlowRef 編譯失敗

**症狀**:codegen 階段 fail,workflow 沒生成對應的 Java class。

**根因**:Kogito 10.2.0 codegen 在處理 `subFlowRef` 與 hyphen id 時,Java identifier 解析錯誤。

**檢測**:

```bash
grep -l "subFlowRef" *.sw.yaml | xargs grep -l "id: .*-"
```

**解法**:整個 spec 全用 `snake_case`:

```python
mappings = {
    "omni-cash-transaction": "omni_cash_transaction",
    "repayment-cash-deposit": "repayment_cash_deposit",
    "repayment-cash-cancellation": "repayment_cash_cancellation",
}
for f in workflow_yaml_files:
    content = open(f).read()
    for old, new in mappings.items():
        content = content.replace(old, new)
    open(f, "w").write(content)
```

> **影響**:對外 API path 也會從 `/omni-cash-transaction` 變 `/omni_cash_transaction`,需在 spec 註明 v1.0 hotfix。

#### 踩坑 #2:actionDataFilter 結構對齊 MyOpenApiService

**症狀**:workflow 走到 FAILED 分支但 host API 回 200,因為 `.result.status` 是 null。

**根因**:`MyOpenApiService` 把 host API response 直接放頂層(`.code` / `.message` / `.Account` 等),不是 `.result` 底下。

**解法**:改 actionDataFilter 直接讀頂層:

```yaml
# ✗ 錯(假設 response 在 .result 下)
results: '{status: .result.status, message: .result.message, track_id: .result.track_id}'

# ✓ 對(直接讀頂層)
results: '{code: .code, message: .message, errorType: .errorType, _httpStatus: ._httpStatus, errors: .errors}'
```

#### 踩坑 #3:Path parameter 注入

**症狀**:workflow 調用 OpenAPI 時報 `Illegal character in path ... {xxx}`。

**根因**:mock 的 `@Path("/foo/{xxx}/bar")` 但 workflow 沒在 payload 帶 `xxx`。

**解法**:在每個 `callApiViaOpenAPI` 的 payload 內顯式加:

```yaml
payload:
  creditcardid: '${ .partyId }'   # ← 補上
  partyId: '${ .partyId }'
  ...
```

**小心**:YAML list item 不要 trailing comma:

```yaml
# ✗ 錯
creditcardid: '${ .partyId }',
# ✓ 對(無 comma)
creditcardid: '${ .partyId }'
```

#### 踩坑 #4:status-rewrite filter 加 finalStatus 支援

**症狀**:workflow 回 `finalStatus: REJECTED_VALIDATION` 但 HTTP code 是 200(應該 400)。

**根因**:既有 `WorkflowStatusFilter` 只讀 `status` 欄位。新 omni convention 用 `status: 0/1` (int) + `finalStatus: STRING`。

**解法**:修改 `platform-security/.../SonataFlowSecurityConfig.java`:

```java
// 改前
Object status = map.get("status");

// 改後(優先 finalStatus,退回 status;且只對 String 映射)
Object status = map.get("finalStatus");
if (status == null) {
    status = map.get("status");  // 向下相容 saga2
}
if (status != null && status instanceof String) {
    Integer rewrite = statusRewriteMap.get(status.toString());
    if (rewrite != null) {
        responseContext.setStatus(rewrite);
    }
}
```

> **向下相容**:這個改法讓 saga2 與 omni 兩種 convention 可以共存於同一個 filter,不需要 fork。

#### 踩坑 #5:SQL view workflow_id 對齊

**症狀**:`V<X>` SQL view 套用後查詢回 0 筆。

**根因**:view 的 `WHERE workflow_id IN (...)` 用了 draft 的 hyphen id,實際是 underscore(踩坑 #1 的修正結果)。

**解法**:改 `V<X>` SQL 內的 id 清單,並手動 drop & recreate view(因為 `CREATE VIEW IF NOT EXISTS` 不會重新觸發)。

### 8.2.4 反模式(不要這樣做)

- ❌ 不要把整個 draft 資料夾丟進 project,挑選對應的檔案落對應目錄
- ❌ 不要跳過 Kogito bug 修正,直接編譯會 fail
- ❌ 不要改既有 saga2-transfer-workflow 的 convention(向後相容用 fallback)
- ❌ 不要用 `mvn install:install-file` 手動裝 jar,會破壞 reactor 一致性
- ❌ 不要在 test 階段才建 workflow URL prefix(應該是 dev profile 啟動時 Kogito 自動註冊)
- ❌ 不要省略 `creditcardid` 補上動作(踩坑 #3),否則 mock 收到 `IllegalArgumentException`
- ❌ 不要在沒有 dev profile 下做 E2E(mocks 是 dev-only 模組,prod 會被排除)

### 8.2.5 完整疑難排對照表

| 症狀 | 對應 Step |
|---|---|
| `vw_xxx_reconciliation` 查詢回 0 筆 | view 的 WHERE 用舊 id → 踩坑 #5 |
| `result.status == 0` 永遠 false | actionDataFilter 結構錯誤 → 踩坑 #2 |
| `rowsUpdated=0` 在 `markOriginalCancelled` | transaction 隔離 / cancelled_by 已值 / 連線池問題,留 v1.1 排查 |
| `Expected status code <200> but was <400>` | 全域正則拒絕正常通路碼(如 `2500P`)→ 檢查 API 規格放寬正則(如 `^[A-Za-z0-9]{1,10}$`) |
| `finalStatus: null` 在業務失敗分支 | jq condition `tonumber` 遇到非數字哨兵(如 `FAIL_`)拋錯 → 加上 `startswith("FAIL_")` 守衛 |
| `Expected: SUCCESS Actual: IDEMPOTENT_REPLAY` | 測試案例重複使用硬編碼 sequenceNumber 觸發冪等 → 測試改用 `System.nanoTime()` 動態序號 |
| `NullPointerException: ... getStart() is null` | `.sw.yaml` 根節點缺少 `start:` 宣告 → 於 workflow 頂層顯式定義 `start: <StateName>` |
| `ClassCastException: ... cannot be cast to JsonNode` | Java 重載方法參數綁定失配 → 於 `functionRef` arguments 明確傳遞 `workflowId` 與 `businessKey` |
| `API 呼叫錯誤: 無法確定 API Base URL` | OpenAPI Spec 缺少 `servers:` 宣告且無全域 host → 於 Spec 補上 `servers: - url: http://localhost:8080` |
| `sqlite3.OperationalError: no such column: updated_at` | 對帳 View 參照不存在欄位 → 修正 View 定義 |
| `maven.aliyun.com 503 Service Unavailable` | 重試 / 切換 mirror / 縮短單次 build |
| Java/Maven 突然 not found | sandbox 自動清掉,重裝 `apt-get install openjdk-17-jdk-headless maven` |

---

# 第 9 章:附錄

## 9.1 測試覆蓋一覽

### 9.1.1 saga2-transfer-workflow(18 個 E2E 案例)

| 類別 | 案例 | 驗證點 |
|---|---|---|
| Happy path | `testAmt100Success` / `testAmt500BoundarySuccess` | AMT <= 500,全成功 |
| 業務規則觸發補償 | `testAmt600RolledBackLifo` / `testAmt2000RolledBackA16229Only` / `testAmt501BoundaryRolledBack` | AMT > 500 觸發 LIFO |
| 業務失敗 | `testAmt30Failed` | A16229 業務失敗 |
| Rollback 失敗 | `testRollbackFailedLifo` / `testRollbackFailedA16229Only` | 補償失敗 → ROLLBACK_FAILED |
| errorType 分流 | `testSuccessHasNoErrorType` / `testFailedPathErrorTypeBusiness` | 成功無 errorType,失敗有 |
| Input validation | `testValidationFailedMissingField` / `testValidationFailedBadChars` / `testValidationFailedAmtZero` / `testValidationFailedSameAccount` | 11 條規則覆蓋 |
| 對帳 | `testSqliteDatabaseRecords` / `testExportCsvAllRecords` / `testExportCsvFilteredByStatus` / `testExportCsvNoMatchingRecords` | AuditLog 寫入 + CSV 匯出 |

### 9.1.2 omni-cash-transaction(16 個 E2E 案例)

| 類別 | 案例 | 驗證點 |
|---|---|---|
| Parent 級 | P1~P4 | 驗證失敗 / opType 條件必填 / 冪等命中 |
| WF-A | A1~A6 | 繳款成功 / amount=0 拒絕 / Core 業務拒絕 / CC 失敗 Core rollback / Rollback 失敗 / 對帳 view |
| WF-B | B1, B2, B3, B5, B6, B7 | 取消成功 / Lookup 失敗 / 原非 SUCCESS 拒絕 / 取消階段 1 失敗 / 取消 rollback 成功 / 取消 rollback 失敗 |
| 留待 v0.3 | B4, X1~X5 | 重複取消冪等 / 跨 workflow 整合 |

## 9.2 Data Index GraphQL 查詢範例

Data Index 透過 GraphQL 提供流程實例即時查詢:

```graphql
# 查詢所有 status 為 ROLLBACK_FAILED 的 saga2 流程實例
{
  ProcessInstances(
    where: {
      processId: { equal: "saga2-transfer-workflow" }
      variables: { contains: { finalStatus: "ROLLBACK_FAILED" } }
    }
    limit: 50
  ) {
    processInstanceId
    start
    end
    state
    variables
  }
}

# 用 metadata 過濾 criticality=high 的所有 workflow
{
  ProcessInstances(
    where: {
      metadata: { contains: { criticality: "high" } }
    }
    limit: 50
  ) {
    processInstanceId
    processId
    start
    state
  }
}
```

`metadata` 機制是 v2.2 樣板新增的設計——`domain / pattern / criticality / owner` 四個 tag 讓 Data Index 可橫跨多 workflow 統一過濾。

## 9.3 部署拓撲

```mermaid
graph TB
    subgraph K8s["Kubernetes Cluster"]
        subgraph NS1["Namespace: prod-transfer"]
            TA1[transfer-app Pod 1]
            TA2[transfer-app Pod 2]
            TA3[transfer-app Pod 3]
            SVC1[Service: transfer-app:8080]
        end

        subgraph NS2["Namespace: prod-reconciliation"]
            RA1[reconciliation-app Pod 1]
            RA2[reconciliation-app Pod 2]
            SVC2[Service: reconciliation-app:8081]
        end

        subgraph NS3["Namespace: prod-data"]
            DI[Data Index Pod]
        end
    end

    subgraph Storage["共用儲存"]
        PVC1[(PVC: transfer.db<br/>SQLite WAL)]
        PVC2[(PVC: audit.db<br/>workflow_execution_log)]
    end

    Client[呼叫端 / 銀行核心] --> SVC1
    SVC1 --> TA1 & TA2 & TA3
    TA1 & TA2 & TA3 -.讀寫.-> PVC1
    TA1 & TA2 & TA3 -.寫 AuditLog.-> PVC2
    TA1 & TA2 & TA3 -.流程實例.-> DI

    Operator[運維人員] --> SVC2
    SVC2 --> RA1 & RA2
    RA1 & RA2 -.讀.-> PVC2
```

**關鍵設定**:

- transfer-app 3 個副本,reconciliation-app 2 個副本(讀寫分離,讀少寫多)
- `transfer.db` 與 `audit.db` 用 `RWX` PVC 讓多副本共享(ReadWriteMany)
- 預設不啟用 Kogito Data Index 的 K8s deployment(只在本機 / UAT 啟用),prod 改用 PostgreSQL + 外部監控

## 9.4 未來演進路線

| 主題 | 方向 | 預期效益 |
|---|---|---|
| **Native Image** | 全模組 GraalVM native 編譯 | 啟動 < 100ms、記憶體 < 50MB、FaaS 友善 |
| **跨 workflow 冪等** | 從 omni Parent 級擴充到平台級 IdempotencyService(v1.1 留白項) | 簡化呼叫端去重邏輯 |
| **分散式鎖** | `IdempotencyService` 補強分散式鎖避免競態 | 多副本部署時保證冪等原子性 |
| **PostgreSQL 預設** | 取代 SQLite 預設,提供企業級 ACID | 滿足金融監管對持久化的要求 |
| **可觀測性整合** | OpenTelemetry trace + Prometheus metrics + Grafana 模板 | 全鏈路追蹤 workflow 執行 |
| **AI skill 自動生成** | 從自然語言業務書直接產出 draft 套件 | 把 vibe-workflow-design-v2 變成 LLM prompt |
| **Workflow Marketplace** | 把已驗證的 7 個 workflow 抽成可重用模板 | 新業務 80% 直接套範本,只調 20% 業務邏輯 |

---

## 結語

`myhello-platform` 不只是一個「能跑 workflow 的 Quarkus 專案」,它是一個**把金融交易 workflow 開發變成可重複工程的平台**。兩支 skill 是這個平台最重要的資產:

- **`vibe-workflow-design-v2`** 把「需求 → workflow 設計」的隱性知識結構化
- **`sonataflow-integration`** 把「draft → 可運行 + 可測試的程式碼」的隱性知識結構化

只要這兩支 skill 持續維護,新增任何金融業務 workflow 都能在 1-2 天內從需求走到端對端測試完成。這就是**AI 驅動開發**的真正價值——不是讓 AI 取代工程師,而是讓工程師的經驗**沉澱**為可重複的 SOP,讓 AI Agent 與人類工程師都能用同一套方法論產出高品質程式碼。

---

> **本文件版本**:v1.0
> **對應程式碼版本**:`myhello_project_0830` / `project-0825-pd` v1.2.x
> **如有更新,請同步更新 SYSTEM-ARCHITECTURE.md / CODE-SPECIFICATION.md / NEW-WORKFLOW-SOP.md**
