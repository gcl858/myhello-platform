# OBSERVABILITY — errorType 分類、HTTP 改寫、OPS-ALERT、節點軌跡、GraphQL

> 所屬:[Ox_docs](../README.md) / 02 架構
> 事實基準:全部內容基於原始碼親自核對(引用格式:`類別#方法` 或檔名;行號為輔且**可能隨版本變動**)。
> 前置閱讀:[ARCHITECTURE](ARCHITECTURE.md) 第 8 節(filter 鏈排序)、[DATA-FLOW](DATA-FLOW.md) 第 4 節(失敗路徑)。

---

## 目錄

1. [可觀測性四支柱總覽](#1-可觀測性四支柱總覽)
2. [支柱一:errorType 四分類契約](#2-支柱一errortype-四分類契約)
3. [支柱二:HTTP 狀態碼改寫(status-rewrite)](#3-支柱二http-狀態碼改寫status-rewrite)
4. [支柱三:[OPS-ALERT] 運維告警通道](#4-支柱三ops-alert-運維告警通道)
5. [支柱四:NodeTracing 節點軌跡與 Data Index GraphQL](#5-支柱四nodetracing-節點軌跡與-data-index-graphql)
6. [輸出欄位的可觀測性設計(auditSaved / opsAlertRaised)](#6-輸出欄位的可觀測性設計auditsaved--opsaleraised)
7. [觀測矩陣:症狀 → 去哪查](#7-觀測矩陣症狀--去哪查)
8. [常見錯誤](#8-常見錯誤)

---

## 1. 可觀測性四支柱總覽

```mermaid
flowchart LR
    subgraph P1["支柱一:錯誤分類"]
        ET["errorType 四分類<br/>MyOpenApiService#normalizeResponse"]
    end
    subgraph P2["支柱二:HTTP 語意"]
        SR["status-rewrite 改寫<br/>WorkflowStatusFilter<br/>+ [HTTP-AUDIT] 日誌"]
    end
    subgraph P3["支柱三:主動告警"]
        OA["[OPS-ALERT] ERROR 通道<br/>OpsAlertService#raise"]
    end
    subgraph P4["支柱四:軌跡查詢"]
        NT["NodeTracing 節點軌跡<br/>NodeTracingProcessEventListener"]
        GQL["Data Index GraphQL<br/>/graphql"]
    end
    DB[("reconciliation.db")]
    LOG["logs/transfer-app.log"]
    ET -->|"errorType 進 state data"| DB
    SR --> LOG
    OA --> LOG
    NT -->|"nodes.input_args/<br/>output_args/error_message"| DB
    GQL --> DB
```

四支柱分工:**分類**(出了什麼錯)→ **語意**(對客戶端意味什麼)→ **告警**(誰要被叫醒)→ **軌跡**(在哪個節點、什麼上下文出的事)。

---

## 2. 支柱一:errorType 四分類契約

### 2.1 分類定義(`MyOpenApiService` 常數與 javadoc)

| errorType | 涵義 | 結果確定性 | 典型案例 |
|-----------|------|------------|----------|
| `TRANSPORT` | 呼叫未抵達或未完成目標系統 | **未知**(目標可能已執行) | 連線拒絕、逾時、規格解析/組態錯誤 |
| `BUSINESS` | 目標系統明確回覆的業務碼失敗(body 自帶 code ≠ "100") | **確定** | mock 回 403 + `{code:"999"}`;RBFAIL 回 403 + `{code:"401"}` |
| `HTTP_4XX` | HTTP 層客戶端錯誤**且 body 無業務碼** | 確定(重試無效) | 404 路由不存在、405 方法不允許 |
| `HTTP_5XX` | HTTP 層伺服端錯誤**且 body 無業務碼** | **未知**(與 TRANSPORT 同保守處理) | 500、503 |

向後相容設計:**成功回應(code="100")不含 errorType 欄位**。

### 2.2 normalizeResponse 判定流程圖

```mermaid
flowchart TB
    START["收到 HTTP 回應"] --> EMPTY{"204 或 body 空?"}
    EMPTY -->|"是"| SYNTH["合成 code:<br/>statusCode>=400 ? '999' : '100'"]
    EMPTY -->|"否"| OBJ{"body 形態?"}
    OBJ -->|"JSON object"| HASCODE{"自帶 code 欄位?"}
    HASCODE -->|"是"| KEEP["保留該碼(業務碼)<br/>businessCodeFromBody=true"]
    HASCODE -->|"否"| FILL["補 code = >=400 ? '999' : '100'"]
    OBJ -->|"JSON array"| WRAP["包裝 {data:[...]}<br/>補 code/message"]
    OBJ -->|"其他文字"| RAW["存 rawResponse<br/>補 code/message"]
    OBJ -->|"JSON 解析例外"| PARSE_ERR["rawResponse + code='999'<br/>(message=解析錯誤)"]
    SYNTH & FILL & WRAP & RAW --> CLASSIFY
    KEEP --> CLASSIFY
    PARSE_ERR --> CLASSIFY
    CLASSIFY{"code != '100'?"}
    CLASSIFY -->|"否(成功)"| NOFLAG["不加 errorType(向後相容)"]
    CLASSIFY -->|"是"| FROM_BODY{"businessCodeFromBody?"}
    FROM_BODY -->|"是"| BUSINESS["errorType = BUSINESS"]
    FROM_BODY -->|"否"| HTTP{"statusCode >= 500?"}
    HTTP -->|"是"| H5["errorType = HTTP_5XX"]
    HTTP -->|"否"| H4["errorType = HTTP_4XX"]
    NOFLAG & BUSINESS & H5 & H4 --> FINAL["一律補 _httpStatus<br/>回傳標準化 JsonNode"]
```

> 註:上圖「JSON 解析例外」分支在實作中同樣流經後續的 CLASSIFY(此時 businessCodeFromBody=false),故解析失敗會依 HTTP 狀態碼得到 HTTP_4XX/HTTP_5XX。程式路徑以 `MyOpenApiService#normalizeResponse` 為準。

### 2.3 transportError 的固定結構

呼叫未抵達目標系統時(含 schemaRef 格式錯誤、spec 找不到、Base URL 四規則全敗、重試達上限),`transportError()` 固定產生:

```json
{ "code": "999", "message": "API 呼叫錯誤: ...", "errorType": "TRANSPORT", "_httpStatus": 0 }
```

`_httpStatus=0` 是「從未取得 HTTP 回應」的哨兵值——與「收到了 HTTP 500」(`_httpStatus=500`, HTTP_5XX)在資料上可明確區分。

### 2.4 契約細節與邊界

1. **BUSINESS 判定的唯一來源是回應 body 自帶的 code 欄位**;服務自己補的 code(含 999)不算,故純 HTTP 錯誤不會被誤判為業務決策。
2. **邊界案例**:body 自帶 `code:"100"` 但 HTTP status 是 500 → 最終 code="100" → **不標 errorType**(契約以 code 為準)。整合真實外部系統時應確認其成功語意與 code 慣例。
3. errorType 透過 actionDataFilter 進入 state data(`a16229Result.errorType` 等),再經 FinalAuditAndEnd 寫入 AuditLog 的 output_data——**分類結果隨對帳紀錄永久留痕**。

---

## 3. 支柱二:HTTP 狀態碼改寫(status-rewrite)

### 3.1 配置(全配置化,免改 Java)

`distribution/transfer-app/src/main/resources/application.properties` 第 52–59 行:

```properties
# (1) 啟用改寫的 workflow 名單 (比對目標為路徑第一段 = workflow id)
platform.status-rewrite.workflows=saga2-transfer-workflow
# (2) finalStatus → HTTP 狀態碼映射 (格式 STATUS=CODE,逗號分隔)
platform.status-rewrite.mapping=VALIDATION_FAILED=400,ROLLBACK_FAILED=409
```

兩個 key 都有程式內預設值(`WorkflowStatusFilter.DEFAULT_WORKFLOWS` / `DEFAULT_MAPPING`),未配置時行為相同。**新增 workflow 沿用範本時,於名單註冊即可**;映射格式錯誤(非 `STATUS=CODE`)會在啟動時被忽略並 LOG.warnf(`WorkflowStatusFilter#init`)。

### 3.2 執行順序(為什麼 1990 刻意晚於 2000)

JAX-RS response filter 以 priority **降序**執行:

```mermaid
sequenceDiagram
    participant ENG as 引擎回應<br/>{id, workflowdata}
    participant UF as UnwrapResponseFilter<br/>@Priority(USER)=2000<br/>(先跑)
    participant WSF as WorkflowStatusFilter<br/>@Priority(USER−10)=1990<br/>(後跑)
    participant C as Client
    ENG->>UF: 剝殼取 workflowdata<br/>強制 setStatus(200)
    UF->>WSF: 解包後 entity + HTTP 200
    Note over WSF: 讀 status(或 workflowdata.status)<br/>查 mapping 命中 → setStatus(400/409)<br/>覆蓋 Unwrap 的強制 200
    WSF->>C: 最終語意正確的狀態碼
```

此排序是刻意設計(`SonataFlowSecurityConfig.WorkflowStatusFilter` javadoc 第 86–88 行):改寫必須發生在剝殼**之後**,才能(a)讀到解包後的最終 entity;(b)讓 400/409 蓋過 Unwrap 強制設定的 200。

判定細節(`WorkflowStatusFilter#filter`):

1. 只處理 POST 回應;跳過 `q/` 路徑;
2. 正規化路徑去前導 `/`,取第一段與啟用名單比對;
3. entity 三型別相容(Map / Jackson JsonNode / JSON 字串),統一正規化為 Map(`normalizeEntityToMap`);
4. status 取法:頂層 `"status"` → fallback `workflowdata.status`;
5. 未命中映射的 status(SUCCESS / FAILED / ROLLED_BACK)**保持引擎原碼**。

### 3.3 [HTTP-AUDIT] 日誌

同一 filter 在改寫之後輸出完整存取紀錄(`SonataFlowSecurityConfig.WorkflowStatusFilter#filter`):

```text
[HTTP-AUDIT] URI: /saga2-transfer-workflow | HTTP: 409 | Cost: 1234ms | INPUT: {...原始請求...} | OUTPUT: {...最終回應...}
```

| 欄位 | 來源 |
|------|------|
| URI | 正規化後路徑(補回前導 `/`) |
| HTTP | **改寫後**的最終狀態碼 |
| Cost | `(System.nanoTime() - startTimeNano) / 1_000_000`(RuntimeFilter 於請求進入時記錄) |
| INPUT | RuntimeFilter 快取的 `rawInputPayload`(空白壓縮為單行;無則 `{}`) |
| OUTPUT | 最終 entity 序列化(Map/JsonNode/String 三型別皆支援;失敗退回 `String.valueOf`) |

落點:`logs/transfer-app.log`(rotation 10M × 10 個備份,格式見 transfer-app application.properties)。ELK/Splunk 可用 `[HTTP-AUDIT]` 關鍵字切欄位做延遲分布、status 分布看板。

---

## 4. 支柱三:[OPS-ALERT] 運維告警通道

### 4.1 設計定位

`OpsAlertService`(v2.2.0 新增)是「條件告警」:由 workflow 統一終點(FinalAuditAndEnd)每次收尾呼叫,**僅當 finalStatus == "ROLLBACK_FAILED"**(常數 `ALERT_ON_STATUS`)時實際觸發;其餘狀態靜默返回 `{raised:false}`,不產生日誌噪音。

觸發時輸出(專屬 SLF4J logger 名稱 **`OPS-ALERT`**,ERROR 級):

```text
[OPS-ALERT] 回沖失敗,需人工介入 | workflowId=saga2-transfer-workflow | instanceId=... | businessKey=... | message=⚠️ 回沖失敗,需人工介入處理 | detail={a16229Rollback={...}, a16220Rollback={...}}
```

detail 內含兩個 rollback 結果(workflow functionRef arguments 傳入),值班人員不必開 DB 即可判斷哪一腿回沖失敗。

### 4.2 ELK/Splunk 接單建議

- 依關鍵字 `[OPS-ALERT]` 建立 alert rule(ERROR level、logger OPS-ALERT);
- 從訊息中解析 `businessKey=`(Account_A)與 `instanceId=` 建 ticket 欄位;
- 對照查詢:`workflow_execution_log WHERE process_instance_id = '<instanceId>'` 取完整上下文;Data Index GraphQL 以 businessKey/processId 反查流程實例([§5.3](#53-data-index-graphql-查詢範例))。

### 4.3 降級策略(告警不阻斷)

`OpsAlertService#raise` 內部:

1. 狀態不符 → 立即返回 `{raised:false}`(零副作用);
2. 命中 → 寫 [OPS-ALERT] 日誌,返回 `{raised:true}`;
3. **告警通道本身拋例外** → catch 後改用一般 logger(`OpsAlertService` 的 LOG)記錄失敗原因,返回 `{raised:false}`——交易收尾不被阻斷,但送出失敗仍有一般日誌可追。

擴充點(javadoc 明載):串接 Kafka / webhook / ITSM 時在 `raise` 內追加通道,workflow 端契約(`raised` 布林回傳)不變。workflow 端把結果收進 `opsAlert.raised`,最終以 `opsAlertRaised` 輸出([第 6 節](#6-輸出欄位的可觀測性設計auditsaved--opsaleraised))。

---

## 5. 支柱四:NodeTracing 節點軌跡與 Data Index GraphQL

### 5.1 NodeTracingProcessEventListener

`platform-data-index/.../NodeTracingProcessEventListener.java`(@ApplicationScoped + @Unremovable,繼承 `DefaultKogitoProcessEventListener`)自動為**所有節點**(Split、ActionNode、StartNode、EndNode、WorkItemNode、CompositeContextNode、Join 等)記錄三類資訊到 node instance 的 metaData:

| 事件 | 寫入 key | 取值邏輯 |
|------|----------|----------|
| `beforeNodeTriggered` | `inputArgs` | WorkItemNode → workItem.parameters;否則流程變數快照(**優先 workflowdata**) |
| `beforeNodeLeft` | `outputArgs` | WorkItemNode → workItem.results;否則流程變數快照 |
| `onError` | `errorMessage`(並補 outputArgs={error: ...}) | pi.getErrorMessage() → errorCause 訊息 → 固定字串兜底 |

實作要點:`extractProcessStateSnapshot()` 優先取 `workflowdata` 變數;`snapshotValue()` 以 JsonNode deepCopy / ObjectMapper.valueToTree 保證快照不可變;所有監聽器自身例外都被捕獲降級為 warn 日誌,**絕不影響流程執行**。

上述 metaData 最終落地到 reconciliation.db 的 **nodes 表**:基礎欄位由 Data Index SQLite Flyway 建立(`V1.32.0__data_index_create.sql`:id, definition_id, enter, exit, name, node_id, type, process_instance_id),後續遷移陸續加欄——`V1.45.0.6` sla_due_date、`V1.45.1.1` retrigger + **error_message**、`V1.45.1.3` cancel_type、`V1.48.0` **input_args / output_args**(正是本監聽器寫入的 metaData keys)。查詢入口見下節 GraphQL。

### 5.2 時間戳修補(KogitoSQLiteDialect)

GraphQL 回傳的 enter/exit/start/end 是 ZonedDateTime;SQLite 存 TEXT。`KogitoSQLiteDialect#contributeTypes` 註冊自訂型別,讓 Hibernate 同時解析 Unix epoch ms 字串與 ISO-8601 字串——修復 ProcessInstances 時間解析 bug(#9)。沒有這層,GQL 查詢會在時間欄位上炸出解析例外。

### 5.3 Data Index GraphQL 查詢範例

端點:`POST http://localhost:8080/graphql`(Data Index 內嵌於 transfer-app;GraphQL UI 恆啟用 `quarkus.kogito.data-index.graphql.ui.always-include=true`,`kogito.data-index.blocking=true` 使查詢同步回應)。

**內建 instances.html 的實際查詢**(`distribution/transfer-app/src/main/resources/META-INF/resources/instances.html#fetchInstances`):

```graphql
query {
  ProcessInstances {
    id
    processId
    processName
    state
    start
    end
    variables
    nodes {
      id
      name
      enter
      exit
    }
  }
}
```

**依 workflow 定義盤查(ProcessDefinitions)**:

```graphql
query {
  ProcessDefinitions {
    id
    processId
    processName
    version
    annotations
  }
}
```

**metadata 標籤過濾**:saga2 v2.2.0 在 YAML 宣告定義層中繼資料(YAML 註解明言「Data Index GraphQL / 營運查詢過濾用」):

```yaml
metadata:
  domain: transfer
  pattern: saga-lifo-compensation
  criticality: high
  owner: platform-team
```

搭配實例層查詢,營運可以回答「轉帳域(domain=transfer)、Saga 模式(pattern=saga-lifo-compensation)、高關鍵度(criticality=high)的流程現況如何」這類問題;實例層可用 `where` 引數以 businessKey/processId/state 等條件過濾(schema 隨 Kogito 10.2.0 Data Index 提供,可在 `/graphql` UI 檢視完整 schema 後調整欄位)。

> 節點軌跡聯查建議:GQL 取 nodes.enter/exit 算每個 state 耗時;對失敗實例再查 SQLite `nodes.error_message` / `input_args` / `output_args` 定位事故節點上下文。

### 5.4 其他觀測輔助

| 元件 | 出處 | 用途 |
|------|------|------|
| `MyLivenessCheck`(@Liveness) | platform-data-index | `/q/health/live` 恆回 up("alive")——容器編排存活探針的最小實作 |
| log 檔設定 | 兩個 app 的 application.properties | transfer-app.log(10M×10)/ reconciliation-app.log(20M×14);格式 `%d %-5p [%c{3.}] (%t) %s%e%n` |
| `quarkus.smallrye-health.management.enabled=false` | platform-data-index base | 關閉 management port,健康檢查統一走一般 `/q/health` |

---

## 6. 輸出欄位的可觀測性設計(auditSaved / opsAlertRaised)

v2.2.0 把兩個「幕後服務的結果」提升為一等輸出欄位:

| 欄位 | 追蹤編號 | 設計動機(YAML 註解原文語意) | 值的意義 |
|------|----------|------------------------------|----------|
| `auditSaved` | P0-5 | 對帳寫入結果不再靜默丟失——`doSaveLog` 自吞例外,若不揭露,saved=false 會無聲消失 | `true`=對帳紀錄已落地;`false`=落地失敗(查 AuditLogService ERROR 日誌) |
| `opsAlertRaised` | P2-6 | 告警是否真的送出——降級策略會把通道故障轉為 raised=false | `true`=[OPS-ALERT] 已發出;`false`=未觸發或送出失敗 |

三個觀測面一次到位:客戶端回應、[HTTP-AUDIT] 日誌的 OUTPUT 欄、AuditLog 的 output_data(status/message)三者可交叉比對。例如 `status=ROLLBACK_FAILED && opsAlertRaised=false` 是必須人工處理的組合(交易收了尾但沒人被通知);`status=SUCCESS && auditSaved=false` 則是對帳缺口預警。

---

## 7. 觀測矩陣:症狀 → 去哪查

| 症狀/問題 | 第一現場 | 進階查詢 |
|-----------|----------|----------|
| 客戶端收到 400 | [HTTP-AUDIT] 看 OUTPUT.status=VALIDATION_FAILED + INPUT 驗欄位 | workflow_execution_log WHERE status='VALIDATION_FAILED' |
| 客戶端收到 409 | [OPS-ALERT] ERROR 日誌(接單)+ OUTPUT.opsAlertRaised | nodes 表 error_message;detail 判斷哪一腿回沖失敗 |
| status=FAILED 但不知道錯在哪 | 回應內 a16229Result/a16220Result 的 code/errorType/_httpStatus | errorType=TRANSPORT → 查 MyOpenApiService WARN/ERROR(重試紀錄);BUSINESS → 查目標系統 |
| 交易慢(Cost 高) | [HTTP-AUDIT] Cost 欄趨勢 | GraphQL nodes.enter/exit 算各 state 耗時;注意 transport-retry 的退避睡眠(delayMs×2^n) |
| 疑似漏單(AuditLog 缺) | workflow_execution_log 以 businessKey/processInstanceId 查 | Data Index GraphQL 反查實例是否存在及其 state;platformError 兜底應保證「有跑必有帳」 |
| 寫入失敗(SQLITE_BUSY?) | auditSaved=false + AuditLogService ERROR 日誌 | 檢查 busy_timeout、共享 volume 掛載、writer 數量(見 [ARCHITECTURE](ARCHITECTURE.md#7-sqlite-wal-多讀者架構)) |
| 流程卡住不結束 | workflowExecTimeout PT5M 上限 | GraphQL 查 state=ACTIVE 實例與其最後節點 |

---

## 8. 常見錯誤

1. **以為 HTTP_4XX/HTTP_5XX 涵蓋所有 4xx/5xx** → 只要回應 body 自帶業務碼就歸 BUSINESS;判定順序見[§2.2](#22-normalizeresponse-判定流程圖),勿憑 HTTP 狀態碼直覺分類。
2. **在 ELK 用 logger 名稱小寫過濾** → logger 名稱就是大寫 `OPS-ALERT`,訊息關鍵字 `[OPS-ALERT]`;兩者都區分大小寫。
3. **期待 opsAlertRaised=true 於 FAILED/ROLLED_BACK** → 只有 ROLLBACK_FAILED 觸發(`ALERT_ON_STATUS` 常數);要擴大觸發面改 OpsAlertService 或新增狀態,不要繞過服務直接打 logger。
4. **把 UnwrapResponseFilter 的強制 200 誤認為最終狀態碼** → 它先執行;WorkflowStatusFilter(1990)隨後改寫。調整 priority 順序會破壞整個改寫機制([§3.2](#32-執行順序為什麼-1990-刻意晚於-2000))。
5. **status-rewrite 只對 POST 啟動請求生效** → GET 狀態查詢、q/ 路徑不在範圍;別期待查詢類 API 也被改碼。
6. **用 GQL 查時間欄位卻拿到解析錯誤** → 確認 KogitoSQLiteDialect 已掛(它負責 epoch-ms/ISO-8601 雙格式相容);自行繞過 dialect 直連 SQLite 解析 TEXT 時間是自找麻煩。
7. **NodeTracing 監聽器「看起來沒生效」** → 先確認實例確實經由組裝了 platform-data-index 的 app 執行(@Unremovable 保證 bean 不被移除,但模組沒進 pom 就什麼都沒有);再確認 nodes 表已有 input_args/output_args 欄位(V1.48.0 遷移已套用,reconciliation_schema_history 可查)。
8. **拿 auditSaved=false 當罕見雜訊忽略** → 它代表對帳缺口,是本平台最重要的完整性訊號之一(P0-5 特意為此而生);應設定告警。
9. **混淆 errorType(BUSINESS=結果確定)與重試策略** → 服務層只對 TRANSPORT(未取得 HTTP 回應)重試;收到任何 HTTP 回應(含 5xx)永不重試。呼叫端若自行重試整筆交易,務必配合冪等鍵(見 [DATA-FLOW](DATA-FLOW.md#7-冪等性注意))。
10. **引用 states 數量的舊口徑「19」** → saga2 v2.2.0 實為 **18**(詳 [DATA-FLOW](DATA-FLOW.md#2-全鏈路總覽-sequencediagram主幹) 勘誤聲明)。

---

## 相關文件

- [ARCHITECTURE](ARCHITECTURE.md) — filter 鏈排序、SQLite WAL、部署模型
- [DATA-FLOW](DATA-FLOW.md) — 失敗路徑時序與 errorType 在資料流中的位置
- [SERVICE-REFERENCE](../04-reference/SERVICE-REFERENCE.md) — MyOpenApiService/AuditLogService/OpsAlertService 完整手冊
- [DATABASE-REFERENCE](../04-reference/DATABASE-REFERENCE.md) — nodes/workflow_execution_log 全表
- [TROUBLESHOOTING](../07-operations/TROUBLESHOOTING.md) — 已知地雷症狀→原因→解法
- [UI-PAGES](../07-operations/UI-PAGES.md) — instances.html 等 8 個內建頁面導覽
