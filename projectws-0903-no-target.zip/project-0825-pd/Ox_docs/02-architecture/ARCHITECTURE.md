# ARCHITECTURE — myhello-platform 三層架構與部署模型

> 所屬:[Ox_docs](../README.md) / 02 架構
> 事實基準:全部內容基於原始碼親自核對(引用格式:`類別#方法` 或檔名;行號為輔且**可能隨版本變動**)。
> 版本基準:Java 17 · Quarkus 3.27.2 · KIE/Kogito 10.2.0 · sqlite-jdbc 3.45.1.0 · Maven 3.9.0+（`maven-enforcer-plugin` 強制）

---

## 目錄

1. [系統一句話與設計目標](#1-系統一句話與設計目標)
2. [三層架構總覽圖](#2-三層架構總覽圖)
3. [各層職責詳解](#3-各層職責詳解)
4. [Bounded Context 劃分理由](#4-bounded-context-劃分理由)
5. [模組依賴不變式](#5-模組依賴不變式)
6. [部署模型:雙 App 與共享 SQLite](#6-部署模型雙-app-與共享-sqlite)
7. [SQLite WAL 多讀者架構](#7-sqlite-wal-多讀者架構)
8. [平台橫切層:filter 鏈順序與職責](#8-平台橫切層filter-鏈順序與職責)
9. [配置疊加模型(base + override)](#9-配置疊加模型base--override)
10. [未來換 Postgres 的影響點](#10-未來換-postgres-的影響點)
11. [常見錯誤](#11-常見錯誤)

---

## 1. 系統一句話與設計目標

`myhello-platform` 是一個 Maven 多模組 **SonataFlow/Kogito 10.2.0 + Quarkus 3.27.2** 企業級工作流平台:

- **平台層(`platform-*`)** 提供安全過濾(filter 鏈)、Data Index 擴展(SQLite 方言與儲存)與跨平台路徑工具;
- **業務域(`domain-transfer` 轉帳 / `domain-reconciliation` 對帳)** 以 Serverless Workflow YAML 定義 Saga 補償流程,核心範本為 `saga2-transfer-workflow.sw.yaml`(v2.2.0);
- **組裝層(`distribution/*`)** 最終組裝成兩個可執行 Quarkus 應用:**8080 讀寫交易(transfer-app)、8090 唯讀對帳(reconciliation-app)**,共享單一 `reconciliation.db`(WAL 模式)。

三大設計目標:

| 目標 | 具體落實 |
|------|----------|
| 新 workflow 開發成本極小化 | saga2 v2.2.0 作為「填空式」範本;新增 workflow 只需改 YAML + 於 `application.properties` 兩處註冊(見 `distribution/transfer-app/src/main/resources/application.properties` 第 52–59 行註解) |
| 任何錯誤都收斂到統一終點 | workflow 級 `errors.platformError` 兜底 + 各 state `onErrors`,保證 AuditLog 不留缺口(saga2 YAML 第 49–56 行說明) |
| 觀測與稽核一等公民 | errorType 四分類、status-rewrite HTTP 改寫、`[OPS-ALERT]` 日誌通道、節點軌跡(詳見 [OBSERVABILITY](OBSERVABILITY.md)) |

---

## 2. 三層架構總覽圖

```mermaid
flowchart TB
    subgraph L3["第三層:distribution 組裝層(唯一可執行入口)"]
        TA["transfer-app :8080<br/>線上交易(讀寫 reconciliation.db)<br/>Pod ≥ 3"]
        RA["reconciliation-app :8090<br/>對帳查詢/CSV 匯出(read-only)<br/>Pod 1~2"]
    end

    subgraph L2["第二層:domain 業務域層(bounded context)"]
        subgraph DT["[v1.2] domain-transfer 轉帳域 (prod-only)"]
            TWF["transfer-workflow<br/>saga2 v2.2.0(.sw.yaml)+ OpenAPI specs<br/>MyOpenApiService / SagaApiService"]
        end
        subgraph DR["domain-reconciliation 對帳域"]
            RAPI["reconciliation-api<br/>AuditLogService / OpsAlertService<br/>AuditQueryService / CSV Exporter"]
        end
    end

    subgraph L_DEV["[v1.2] dev/ dev-only 層 (僅 -P dev 納入 reactor)"]
        TSAMP["transfer-samples<br/>示範 workflows<br/>(ApiService 硬編 UAT 端點)"]
        TMOCK["transfer-mock<br/>A16229/A16220 mock Resource + DTO"]
    end

    subgraph L1["第一層:platform 平台層(橫切關注)"]
        PC["platform-common<br/>PlatformPaths(無框架依賴)"]
        PS["platform-security<br/>RuntimeFilter / UnwrapResponseFilter<br/>WorkflowStatusFilter / SwaggerFilter"]
        PDI["platform-data-index<br/>KogitoSQLiteDialect / PlatformConfigSource<br/>NodeTracingProcessEventListener / MyLivenessCheck"]
        PE["platform-extensions<br/>data-index-storage-sqlite(Flyway 22 支)<br/>kogito-addons-quarkus-data-index-*"]
    end

    DB[("reconciliation.db<br/>SQLite WAL 模式<br/>共享 volume")]

    TA --> PS & PC & PDI & PE
    RA --> PS & PC & PDI & PE
    TMOCK & TWF & TSAMP --> TA
    RAPI --> TA
    RAPI --> RA
    TWF -. "僅依賴服務介面:<br/>AuditLogService / OpsAlertService" .-> RAPI
    PS & PDI --> PC
    PE --> PDI
    TA -. "寫入(唯一定寫者)" .-> DB
    RA -. "唯讀連線" .-> DB
```

三個要點:

1. **依賴方向永遠向下**:distribution → domain → platform;沒有任何反向箭頭。
2. **跨域合約最小化**:`transfer-workflow` 對對帳域只依賴 `AuditLogService` / `OpsAlertService` 兩個服務介面(pom 實證:`domain-transfer/transfer-workflow/pom.xml` 僅宣告 `reconciliation-api` 一個對帳域依賴),不觸及任何內部實作。
3. **寫者唯一**:`reconciliation.db` 的所有寫入由 transfer-app 側的 `AuditLogService#doSaveLog` 完成;reconciliation-app 以 `quarkus.datasource.jdbc.read-only=true` 強制唯讀(`distribution/reconciliation-app/src/main/resources/application.properties`)。

---

## 3. 各層職責詳解

### 3.1 第一層:platform 平台層

| 模組 | 核心元件 | 職責(原始碼依據) |
|------|----------|-------------------|
| `platform-common` | `PlatformPaths` | 純 Java(無框架依賴)路徑工具:`MYHELLO_DATA_DIR` / `MYHELLO_LOGS_DIR` 解析、專案根目錄探測(`findProjectRoot`,以 `.git` 或 `pom.xml+distribution` 為錨)、`sqliteUrl()`、classpath 正規化 `normalizeClasspath()` |
| `platform-security` | `SonataFlowSecurityConfig`(內含 `SwaggerFilter` / `RuntimeFilter` / `WorkflowStatusFilter`)、`UnwrapResponseFilter` | JAX-RS 橫切:非 POST 一律 403、payload 快取供稽核、workflow 回應解包(workflowdata)、依 finalStatus 改寫 HTTP code、`[HTTP-AUDIT]` 存取日誌 |
| `platform-data-index` | `KogitoSQLiteDialect`、`SqliteZonedDateTimeJdbcType`、`PlatformConfigSource`、`NodeTracingProcessEventListener`、`MyLivenessCheck` | Data Index 基礎設定(application.properties base)、SQLite ZonedDateTime 型別修補、配置注入(ordinal=250)、節點軌跡監聽器 |
| `platform-extensions` | `data-index-storage-sqlite`(+22 支 Flyway SQL)、`kogito-addons-quarkus-data-index-sqlite`、`kogito-addons-quarkus-data-index-persistence-sqlite` | Kogito 官方 PostgreSQL addon 的 SQLite 修補移植:儲存適配器、時間型別、deployment/runtime 兩層擴展 |

### 3.2 第二層:domain 業務域層

| 模組 | 核心內容 | 備註 |
|------|----------|------|
| `dev/transfer-mock` | `A16229Resource` / `A16220Resource`(mock 主機端)、Request/Response DTO | 外部系統模擬器 Resource + DTO(`dev/transfer-mock` 模組,[v1.2] 從頂層 `mocks/transfer-mock` 搬入)。mock 規則:A16229 成功條件 AMT>50;A16220 成功條件 AMT<1000;兩者皆支援 RBFAIL 測試哨兵(`A16229Resource#execute`、`A16220Resource#execute`) |
| `transfer-workflow` | `saga2-transfer-workflow.sw.yaml` v2.2.0(**開發範本**)、`saga-transfer-workflow.sw.yaml` v15(舊版對照)、`specs/A16229-api.yaml`、`specs/A16220-api.yaml`(OpenAPI specs 自包含於本模組 resources)、`MyOpenApiService`、`SagaApiService` | canonical 資源所在地;`MyOpenApiService#callOpenApi` 是 saga2 全部外部呼叫的唯一通道 |
| `transfer-samples` | java/OpenAPI/rest 示範 workflows | pom 依賴方向:**無內部模組依賴**(已親核 `dev/transfer-samples/pom.xml`) |
| `reconciliation-api` | `AuditLogService`(WAL 寫入+遷移)、`OpsAlertService`(告警)、`AuditQueryService`、`ReconciliationResource`(CSV 匯出) | 對帳域的合約定義地;被兩個 app 共同組裝 |

### 3.3 第三層:distribution 組裝層

每個 app 是一個 `quarkus-run.jar`,自身**零業務碼**,只負責:

1. **pom 組裝**:挑選 platform + domain 模組(唯一允許同時依賴兩層的地方);
2. **資源同步**:`src/main/resources` 下是 canonical 資源的建置副本(例如 `saga2-transfer-workflow.sw.yaml`、`application.properties`);**勿手改副本**——單一事實來源規則見 [PROJECT-LAYOUT](../01-getting-started/PROJECT-LAYOUT.md);
3. **配置疊加**:同名 key 覆寫 `platform-data-index` 的 base 配置(詳見[第 9 節](#9-配置疊加模型base--override))。

> 已核對:`domain-transfer/transfer-workflow/src/main/resources/saga2-transfer-workflow.sw.yaml` 與 `distribution/transfer-app/src/main/resources/saga2-transfer-workflow.sw.yaml` **逐位元組一致**(diff 驗證)。

---

## 4. Bounded Context 劃分理由

**轉帳域(domain-transfer)與對帳域(domain-reconciliation)分開的理由:**

1. **生命周期不同**:轉帳是線上即時交易(毫秒~秒級、高頻、SLA 敏感);對帳是離線查詢/匯出(批次、低頻、讀多寫少)。分域後可各自伸縮——轉帳側 Pod ≥ 3,對帳側 1~2 即可。
2. **讀寫角色不同**:只有轉帳域產生交易紀錄(透過 `AuditLogService#doSaveLog` INSERT);對帳域只消費(read-only datasource)。把「寫入合約」定義在對帳域(reconciliation-api),把「寫入行為」放在轉帳側執行,是最小的跨域接觸面。
3. **演進節奏不同**:轉帳域的工作流會持續新增(saga2 範本複製);對帳域的表結構則靠模組化遷移穩定演進(`DatabaseMigrationRunner#runMigrations` 掃描 classpath `db/migration/V{版本}__描述.sql`,歷史記錄於 `reconciliation_schema_history` 表)。

**context map(合約關係):**

```mermaid
flowchart LR
    subgraph TC["轉帳 context"]
        WF[saga2 workflow states]
        MOS[MyOpenApiService]
        MOCK[A16229Resource / A16220Resource]
    end
    subgraph RC["對帳 context"]
        ALS[AuditLogService]
        OAS[OpsAlertService]
        QRY[AuditQueryService / CSV]
    end
    WF -->|"callApiViaOpenAPI function"| MOS --> MOCK
    WF -->|"recordAuditLog function"| ALS
    WF -->|"notifyOps function"| OAS
    ALS --> DBT[("reconciliation.db")]
    QRY --> DBT
```

注意 workflow 對兩個服務的引用都是**以函數名稱綁定服務類別全名**(`saga2-transfer-workflow.sw.yaml` functions 區塊):

```yaml
- name: recordAuditLog
  operation: 'service:com.example.reconciliation.AuditLogService::saveLog'
- name: notifyOps
  operation: 'service:com.example.reconciliation.OpsAlertService::raise'
```

---

## 5. 模組依賴不變式

以下四條不變式以 pom 實證(任一違反即架構破壞):

1. **沒有任何 `domain-*` 反向依賴 `platform-*`**——domain 只能往下依賴 platform(反例檢查:`transfer-workflow/pom.xml` 對 platform 側僅依賴 `platform-common` 工具類)。
2. **沒有 `transfer-*` 依賴 `reconciliation-*` 內部實作**——唯一接觸點是 `transfer-workflow → reconciliation-api` 的 `AuditLogService` / `OpsAlertService` 服務介面。
3. **`distribution/*` 是唯一允許組裝 platform + domain 的地方**。
4. **沒有任何循環依賴**——依賴形態為 DAG;`dev/transfer-samples` 無任何內部模組依賴;`dev/transfer-mock` 是 leaf 模組,僅被 distribution 組裝層透過 dev profile 下的 Maven pom 依賴 + `quarkus.index-dependency.*` 宣告(也加 `%dev.` 前綴)引入。**[v1.2]** 此依賴關係在 `-P prod` 模式下完全消失,prod 鏡像物理隔離 dev/ 子樹。

> 注意區分兩種「依賴」:(a) Maven pom 依賴(編譯期);(b) `quarkus.index-dependency.*`(CDI 索引宣告,見 `distribution/transfer-app/src/main/resources/application.properties` 第 84–98 行)。後者讓 Quarkus 在建置時掃描這些模組的 bean,不改變 Maven DAG。

模組全景圖另見 [Ox_docs README](../README.md#模組全景圖)。

---

## 6. 部署模型:雙 App 與共享 SQLite

### 6.1 部署模型表

| Distribution | Port | 寫 reconciliation.db? | Pod 建議 | Datasource 關鍵配置 | 用途 |
|---|---|---|---|---|---|
| `transfer-app` | 8080 | **是**(workflow 引擎狀態 + audit log,唯一寫者) | **≥ 3**(WAL 多 reader 併發讀;寫入經 busy_timeout 序列化) | `jdbc:sqlite:${MYHELLO_DATA_DIR:data}/reconciliation.db`;連線池 `max-size=1` | 線上轉帳交易 |
| `reconciliation-app` | 8090 | 否,**`quarkus.datasource.jdbc.read-only=true`** | 1~2 | 同一 JDBC URL(共享 volume) | 對帳查詢 / CSV 匯出 |

配置出處:
- `distribution/transfer-app/src/main/resources/application.properties`(port 8080、function 位址、status-rewrite)
- `distribution/reconciliation-app/src/main/resources/application.properties`(port 8090、read-only=true,第 40–42 行註解明言「寫入應由 transfer-app 端透過 AuditLogService 進行」)
- `platform-data-index/src/main/resources/application.properties`(共用 base:`max-size=1`、WAL pragmas,第 17–25 行)

### 6.2 部署模型圖

```mermaid
flowchart TB
    Client["客戶端 / API Gateway"]
    subgraph K8s["容器平台(建議)"]
        subgraph TS["transfer-app Deployment(Pod ≥ 3,HPA 可擴)"]
            P1["Pod transfer-app #1<br/>:8080"]
            P2["Pod transfer-app #2<br/>:8080"]
            P3["Pod transfer-app #N<br/>:8080"]
        end
        subgraph RS["reconciliation-app Deployment(Pod 1~2)"]
            R1["Pod reconciliation-app #1<br/>:8090(read-only)"]
        end
    end
    subgraph VOL["共享 Persistent Volume(MYHELLO_DATA_DIR)"]
        DBC[("reconciliation.db")]
        DBW[("reconciliation.db-wal")]
        DBS[("reconciliation.db-shm")]
    end
    LOGS["共享 logs volume<br/>MYHELLO_LOGS_DIR<br/>(transfer-app.log / reconciliation-app.log)"]

    Client -->|POST 啟動工作流| TS
    Client -->|GET 對帳查詢 / CSV| RS
    P1 & P2 & P3 -->|"寫(AuditLogService#doSaveLog)<br/>+ 引擎狀態"| DBC
    R1 -->|"唯讀連線"| DBC
    DBC --- DBW & DBS
    TS & RS -.-> LOGS
```

部署決策的因果鏈:

1. SQLite 是**單檔嵌入式資料庫**,「共享」必須靠 volume(所有 Pod 掛載同一個 `MYHELLO_DATA_DIR`);
2. WAL 模式允許**多 reader + 1 writer 併發**——因此讀方(對帳 Pod、多個 transfer Pod 的查詢)可以任意擴;寫方衝突交給 `busy_timeout=5000` 排隊;
3. 寫入面刻意收斂到單一服務(`AuditLogService#doSaveLog`)+ 單一連線池上限(`max-size=1`),把 writer 競爭降到最低;
4. 若寫入吞吐成為瓶頸,正解是換 Postgres(見[第 10 節](#10-未來換-postgres-的影響點)),而不是調大 SQLite 連線池。

---

## 7. SQLite WAL 多讀者架構

### 7.1 PRAGMA 配置的兩個落點

| 落點 | 配置 | 出處 |
|------|------|------|
| JDBC 連線參數(引擎/Data Index 側) | `additional-jdbc-properties.journal_mode=WAL`、`.synchronous=NORMAL`、`.foreign_keys=true` | `platform-data-index/src/main/resources/application.properties` 第 23–25 行 |
| 應用初始化(audit 表側) | `stmt.execute("PRAGMA journal_mode=WAL;")`、`PRAGMA synchronous=NORMAL`、`PRAGMA busy_timeout=5000` | `AuditLogService#initDatabase`(第 93–96 行,行號可能隨版本變動) |

`journal_mode=WAL` 是持久性質(寫入 db 檔一次即生效);`busy_timeout=5000` 是連線級性質,因此 `AuditLogService` 在每次取得連線寫入時都走同一池化連線來保證生效。`busy_timeout=5000` 的意義:writer 鎖競爭時最多等 5 秒再放棄——這是「多 Pod 共寫一檔」能運作的核心參數。

### 7.2 併發語意

```mermaid
flowchart LR
    subgraph Readers["Reader × N(不受鎖阻擋)"]
        RD1["對帳查詢"]
        RD2["Data Index GraphQL"]
    end
    subgraph Writer["Writer × 1(同一時間)"]
        WR["AuditLogService#doSaveLog<br/>INSERT INTO workflow_execution_log"]
    end
    WAL[("WAL 檔<br/>(-wal)")]
    MAIN[("主檔 reconciliation.db")]
    RD1 & RD2 -->|"快照讀(SHARED)"| WAL
    WR -->|"追加寫(WRITE)"| WAL
    WAL -.checkpoint.- MAIN
```

- reader 讀 WAL 快照,不被 writer 阻擋;writer 追加 WAL,與 reader 並存;
- 同時只能有**一個** writer——第二個寫者在 `busy_timeout=5000` 內等待,逾時回 `SQLITE_BUSY`;
- `AuditLogService#doSaveLog` 吞掉一切例外並回 `{saved:false, error}`——即使鎖逾時也不會打斷工作流收尾,寫入結果透過輸出欄位 `auditSaved` 浮現(設計細節見 [OBSERVABILITY](OBSERVABILITY.md#6-輸出欄位的可觀測性設計auditsaved--opsaleraised))。

### 7.3 schema 初始化與遷移體系

- 觸發點:`AuditLogService` 監聽 `StartupEvent`(`onStart`),以 `AtomicBoolean` + synchronized 保證只初始化一次(`initDatabase`);
- 基礎表:`V1.0.0__create_workflow_execution_log.sql` 建立 `workflow_execution_log`(欄位:id, workflow_id, business_key, process_instance_id, status, message, input_data, output_data, created_at)與兩支索引;
- Data Index 側表(含 `nodes`、`processes` 等)由 `platform-extensions/data-index-storage-sqlite` 的 Flyway 腳本建立(如 `V1.32.0__data_index_create.sql`);
- 遷移執行與歷史表(`reconciliation_schema_history`)機制見 `DatabaseMigrationRunner#runMigrations`;完整表單與 view 說明見 [DATABASE-REFERENCE](../04-reference/DATABASE-REFERENCE.md)。

### 7.4 Hibernate 方言修補

Quarkus 3.27.x 無內建 `db-kind=sqlite`,因此 `db-kind=other` + 明確 driver(`org.sqlite.JDBC`),並掛載自訂方言 `KogitoSQLiteDialect`(extends Hibernate community `SQLiteDialect`):

- 註冊 `SqliteZonedDateTimeJdbcType` + `SqliteZonedDateTimeJavaType`,使 Hibernate 能從 TEXT 欄位同時解析 Unix epoch ms 字串與 ISO-8601 字串——修復 GraphQL ProcessInstances 時間戳解析 bug(#9)(見 `KogitoSQLiteDialect#contributeTypes` javadoc);
- 關閉 post-boot schema validation(`database.generation=none`):Hibernate 6.x 對 xerial driver 的欄位 metadata 解析會拋 `NoSuchElementException`,誤報驗證失敗(platform-data-index application.properties 第 31–40 行註解完整記錄此決策)。

---

## 8. 平台橫切層:filter 鏈順序與職責

所有 HTTP 流量先後穿過以下元件(`SonataFlowSecurityConfig` 內部類別 + `UnwrapResponseFilter`):

| # | 元件 | 類型 | Priority | 執行時機 | 職責 |
|---|------|------|----------|----------|------|
| 1 | `SwaggerFilter`(inner class of SonataFlowSecurityConfig) | OASFilter | —(build time) | OpenAPI 文件生成 | 從 API 文件移除 DELETE/PUT/PATCH/HEAD(`filterPathItem`) |
| 2 | `RuntimeFilter` | ContainerRequestFilter | USER = **2000** | 請求進入 | ①排除系統路徑(q/、靜態檔、含 reconciliation/specs/instances/jobs/trace 字樣);②**非 POST → 直接 403**;③快取原始 payload 至 property `rawInputPayload`、記錄 `startTimeNano`;④以 ByteArrayInputStream 重設串流供下游反序列化 |
| 3 | (workflow 引擎處理請求) | — | — | — | 產生 `id` + `workflowdata` 包裝格式的原始回應 |
| 4 | `UnwrapResponseFilter` | ContainerResponseFilter | USER = **2000** | 回應寫回前(先跑) | 剝掉外殼,只回傳 `workflowdata` 子物件,**強制 status=200** |
| 5 | `WorkflowStatusFilter` | ContainerResponseFilter | USER − 10 = **1990** | 回應寫回前(**後跑**) | ①讀 entity 內 `status`(或 `workflowdata.status`),命中映射則**覆寫** Unwrap 強制的 200(VALIDATION_FAILED→400、ROLLBACK_FAILED→409);②輸出 `[HTTP-AUDIT]` 日誌(URI/HTTP/Cost/INPUT/OUTPUT) |

**為什麼 WorkflowStatusFilter 必須晚於 UnwrapResponseFilter?**
JAX-RS response filter 以 priority **降序**執行(數字大者先跑)。Unwrap(USER=2000)先把包裝剝掉並強制 200;WorkflowStatusFilter(USER−10=1990,1990 < 2000)接著才能:(a) 取得**解包後**的最終 entity 判讀 `status`;(b) 讓 400/409 **覆蓋** Unwrap 強制設定的 200。此排序在 `SonataFlowSecurityConfig.WorkflowStatusFilter` 的 javadoc(第 86–88 行)有明白記載,屬刻意設計而非巧合。

```mermaid
sequenceDiagram
    participant C as Client
    participant RF as RuntimeFilter<br/>(USER=2000)
    participant ENG as Workflow Engine
    participant UF as UnwrapResponseFilter<br/>(USER=2000, 先跑)
    participant WSF as WorkflowStatusFilter<br/>(USER−10=1990, 後跑)

    C->>RF: POST /saga2-transfer-workflow
    Note over RF: 非 POST→403;<br/>快取 payload+startTimeNano
    RF->>ENG: 重設後的 stream
    ENG-->>UF: {id, workflowdata:{...}}
    Note over UF: 剝殼取 workflowdata<br/>強制 HTTP 200
    UF-->>WSF: 解包後 entity
    alt status ∈ {VALIDATION_FAILED, ROLLBACK_FAILED}
        Note over WSF: 覆寫為 400 / 409
    end
    Note over WSF: 記錄 [HTTP-AUDIT]
    WSF-->>C: 最終回應
```

> request filter 以 priority 升序執行、response filter 降序——所以兩個 response filter 的實際順序是 Unwrap(2000)→ WorkflowStatusFilter(1990)。

filter 鏈在整筆交易中的位置與作用,搭配實例見 [DATA-FLOW](DATA-FLOW.md);改寫契約細節見 [OBSERVABILITY](OBSERVABILITY.md#3-支柱二http-狀態碼改寫status-rewrite)。

---

## 9. 配置疊加模型(base + override)

配置解析優先級(MicroProfile ConfigSource ordinal,低→高):

```mermaid
flowchart LR
    A["application.properties<br/>(ordinal 100)<br/>platform-data-index 提供 base"] -->
    B["PlatformConfigSource<br/>(ordinal 250)<br/>注入 MYHELLO_DATA_DIR / MYHELLO_LOGS_DIR"] -->
    C["OS 環境變數<br/>(ordinal 300)<br/>外部覆寫"] -->
    D["JVM -D 系統屬性<br/>(ordinal 400)"]
```

- `PlatformConfigSource#getOrdinal()` 固定回傳 250,設計意圖寫明:高於 application.properties 的 fallback(100)、低於環境變數(300)與 `-D`(400),保留外部覆寫能力(`PlatformConfigSource` javadoc);
- 建構時透過 `PlatformPaths.ensureDataDirectory()` / `ensureLogsDirectory()` 保證目錄存在,再把絕對路徑塞進 `MYHELLO_DATA_DIR` / `MYHELLO_LOGS_DIR` 兩個 property;
- `PlatformPaths` 自身的 static initializer 也會在外部未設定時,把系統屬性預設為專案根目錄下的 `data/` 與 `logs/`(根目錄探測:`.git` 或 `pom.xml+distribution`,見 `PlatformPaths#findProjectRoot`);
- distribution 層的 `application.properties` 用**同名 key** 覆寫 base(如 port、JDBC URL);未覆寫的 key(如 `max-size=1`、dialect)直接繼承。

實際疊加結果(與 reconciliation.db 相關):

| Key | base(platform-data-index) | transfer-app | reconciliation-app |
|-----|------------------------------|--------------|--------------------|
| `quarkus.datasource.jdbc.url` | `jdbc:sqlite:${MYHELLO_DATA_DIR:data}/reconciliation.db` | 未覆寫(繼承) | 未覆寫(繼承) |
| `quarkus.http.port` | (無) | 8080 | 8090 |
| `quarkus.datasource.jdbc.read-only` | (無) | (預設 false → 可寫) | true |

> ⚠️ `MYHELLO_DATA_DIR` 是雙 app 指向同一顆 SQLite 的樞紐——容器部署時兩個 Deployment 必須掛載**同一個 volume** 到該路徑,否則各自拿到獨立的空庫。

---

## 10. 未來換 Postgres 的影響點

遷移影響面清單(全部可在現有程式中定位):

| # | 影響點 | 位置 | 動作 |
|---|--------|------|------|
| 1 | DataSource 配置 | `platform-data-index/src/main/resources/application.properties`:`db-kind=other`、driver、JDBC URL、`additional-jdbc-properties.journal_mode=WAL...` | 改 `db-kind=postgresql`、URL/driver 移除;WAL/synchronous/busy_timeout pragmas 整組移除(Postgres MVCC 不需要) |
| 2 | 自訂方言 | `KogitoSQLiteDialect`、`SqliteZonedDateTimeJdbcType/JavaType`(platform-data-index + kogito-addons-quarkus-data-index-sqlite) | 移除引用,還原官方 Postgres dialect;時間型別修補不再需要(epoch-ms-in-TEXT 問題不存在) |
| 3 | SQLite 儲存擴展 | `platform-extensions/data-index-storage-sqlite`(+22 支 Flyway SQL)、`kogito-addons-quarkus-data-index-persistence-sqlite` | 換回 Kogito 官方 postgresql addons;Flyway 腳本改用官方版 |
| 4 | audit 表遷移腳本 | `db/migration/V1.0.0__create_workflow_execution_log.sql`(SQLite 方言 SQL) | 語法審核(`INTEGER PRIMARY KEY AUTOINCREMENT` → `BIGSERIAL`/identity;`TEXT`→適當型別);`DatabaseMigrationRunner` 機制本身可保留 |
| 5 | 備援 DriverManager 路徑 | `AuditLogService#getConnection` 的 fallback 與 `DB_URL = PlatformPaths.sqliteUrl(...)` | fallback 邏輯改寫或移除;`sqliteUrl()` 僅 SQLite 場景使用 |
| 6 | read-only 部署策略 | reconciliation-app `read-only=true` | Postgres 下仍可保留(read-only 連線),但「共享 volume」概念消失——各 app 直接連 DB server |
| 7 | Pod 拓撲 | transfer-app ≥3 / reconciliation-app 1~2 的容量論證基礎(WAL 單 writer) | 寫入瓶頸解除後,transfer-app 可獨立水平擴;寫入不再受 busy_timeout 排隊限制 |
| 8 | 連線池 | `max-size=1`(刻意壓低以避鎖) | 改回正常池大小(如 10~20) |
| 9 | 測試配置 | `%test.quarkus.datasource.jdbc.url=jdbc:sqlite:target/test-reconciliation.db`(兩個 app) | 換 testcontainers 或測試用 PG URL |

**不需要動的東西**(架構投資的回收):全部 workflow YAML、`MyOpenApiService`、filter 鏈、status-rewrite、`[OPS-ALERT]`、NodeTracing 監聽器、`PlatformConfigSource` 注入機制(僅環境變數名稱沿用)——這正是三層切分買到的保險。

---

## 11. 常見錯誤

1. **手改 `distribution/*/src/main/resources` 下的副本**(workflow YAML、application.properties),下次同步被 canonical 覆蓋。→ 一律改 domain 層 canonical,再走建置同步。
2. **兩個 app 的 `MYHELLO_DATA_DIR` 指向不同目錄** → 各自產生獨立的 `reconciliation.db`,對帳查不到交易紀錄。容器部署務必掛載同一 volume。
3. **誤以為 reconciliation-app 可以寫 DB** → datasource 已 `read-only=true`,寫入會失敗;寫入一律走 transfer-app 側 `AuditLogService`。
4. **調大 `max-size=1` 連線池想提升寫入吞吐** → SQLite 單寫者本質不變,只會增加 `SQLITE_BUSY` 機率;正解見第 10 節(Postgres 遷移)。
5. **以為 response filter 按 priority 升序執行** → 實為降序;若把 WorkflowStatusFilter priority 調得比 Unwrap 高(≥2000),它會在剝殼前剝殼前執行,讀不到最終 entity 且其改寫會被 Unwrap 的強制 200 蓋掉,400/409 失效。
6. **忘記 `PlatformConfigSource` ordinal=250 低於環境變數** → 在容器裡設了 `MYHELLO_DATA_DIR` 環境變數卻又期待 properties 內的預設值生效,結果以環境變數為準;排查路徑問題先看 `AuditLogService` 啟動日誌的「使用 data 目錄」一行(`initDatabase`)。
7. **把 `quarkus.index-dependency.*` 當成 Maven 依賴** → 它只是 CDI 建置期索引宣告;真正的依賴圖以各模組 pom 為準。
8. **在 dev mode 中看到 Hibernate schema validation 錯誤就以為 schema 壞了** → validation 已被刻意關閉(`database.generation=none`,原因見第 7.4 節);schema 事實來源是 Flyway 遷移腳本。
9. **引用 saga2 states 數量時沿用舊口徑「19 個 states」** → 以 YAML 實際解析為準,v2.2.0 為 **18 個 states**(逐一名單見 [DATA-FLOW](DATA-FLOW.md#2-全鏈路總覽-sequencediagram主幹));文件集其他分冊若出現 19,以此勘誤為準。

---

## 相關文件

- [DATA-FLOW](DATA-FLOW.md) — 一筆轉帳的全鏈路時序與 state data 演進
- [OBSERVABILITY](OBSERVABILITY.md) — errorType/status-rewrite/[OPS-ALERT]/節點軌跡
- [GETTING-STARTED](../01-getting-started/GETTING-STARTED.md) — 建置與啟動操作
- [PLATFORM-MODULES](../05-platform/PLATFORM-MODULES.md) — 平台元件手冊
- [DATABASE-REFERENCE](../04-reference/DATABASE-REFERENCE.md) — reconciliation.db 完整 schema
- [CONFIG-REFERENCE](../04-reference/CONFIG-REFERENCE.md) — 全參數手冊
