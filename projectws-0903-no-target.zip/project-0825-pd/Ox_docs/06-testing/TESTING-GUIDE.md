# TESTING-GUIDE — myhello-platform 測試指南

> 本文為 Ox_docs 第 06 冊。內容 100% 基於 `distribution/transfer-app/src/test/` 下四支測試類原始碼逐一分析撰寫。
> 引用慣例:`類別#方法` 為主;行號僅輔助且**可能隨版本變動**。術語(finalStatus/errorType/RBFAIL)依 [README 術語統一表](../README.md)。

---

## 目錄

1. [測試總覽與金字塔](#1-測試總覽與金字塔)
2. [測試環境:%test profile 要點](#2-測試環境test-profile-要點)
3. [執行測試的指令](#3-執行測試的指令)
4. [Saga2TransferWorkflowTest(18 tests)](#4-saga2transferworkflowtest18-tests)
5. [ReconciliationCsvTest(14 tests)](#5-reconciliationcsvtest14-tests)
6. [DataIndexGraphQLTest(3 tests)](#6-dataindextestgraphql--dataindexgraphqltest3-tests)
7. [MyOpenApiServiceRetryTest(2 tests)](#7-myopenapiserviceretrytest2-tests)
8. [RBFAIL 哨兵:ROLLBACK_FAILED 的端到端重現](#8-rbfail-哨兵rollback_failed-的端到端重現)
9. [為新 Workflow 撰寫測試:模板與骨架](#9-為新-workflow-撰寫測試模板與骨架)
10. [常見錯誤](#10-常見錯誤)

---

## 1. 測試總覽與金字塔

### 1.1 四支測試類、37 個 test 方法

本平台目前共 **4 支測試類、合計 37 個 `@Test` 方法**(以下數字為逐一清點 `@Test` 註記之實際結果):

| # | 測試類 | 位置(皆在 `distribution/transfer-app/src/test/java/com/example/platform/distribution/transfer/`) | test 數 | 類型 |
|---|--------|------------------|--------|------|
| 1 | `Saga2TransferWorkflowTest` | 同上目錄 | **18** | `@QuarkusTest` 全棧(HTTP + SQLite 直查) |
| 2 | `ReconciliationCsvTest` | 同上目錄 | **14** | `@QuarkusTest` 全棧(HTTP + CSV 檔案 + SQLite 直查) |
| 3 | `DataIndexGraphQLTest` | 同上目錄 | **3** | `@QuarkusTest` 全棧(HTTP GraphQL + SQLite 直查) |
| 4 | `MyOpenApiServiceRetryTest` | 同上目錄 | **2** | **純 JUnit 5**(無 `@QuarkusTest`,不起動容器) |

### 1.2 測試金字塔

```mermaid
flowchart TB
    subgraph L1["頂層:業務情境斷言(@QuarkusTest + rest-assured 打 HTTP)"]
        S2T["Saga2TransferWorkflowTest<br/>18 tests:五種業務情境/邊界值/<br/>VALIDATION_FAILED/RBFAIL→409"]
        RCT["ReconciliationCsvTest<br/>14 tests:CSV 匯出匯出↔DB↔Saga 邏輯一致性"]
    end
    subgraph L2["中層:平台擴展契約驗證(@QuarkusTest)"]
        DGT["DataIndexGraphQLTest<br/>3 tests:GraphQL dialect / nodes I/O listener"]
    end
    subgraph L3["底層:服務層單元測試(純 JUnit 5,不起容器)"]
        RT["MyOpenApiServiceRetryTest<br/>2 tests:指數退避重試/discard port"]
    end
    subgraph L4["貫穿三層的旁路驗證(JDBC 直連 target/test-reconciliation.db)"]
        JDBC["vw_saga_reconciliation View /<br/>nodes 表 input_args・output_args /<br/>rowCount 對帳"]
    end
    S2T --> JDBC
    RCT --> JDBC
    DGT --> JDBC
```

分層意義:

- **頂層(業務契約)**:`Saga2TransferWorkflowTest` 以 rest-assured `POST /saga2-transfer-workflow` 走完整 HTTP → SonataFlow 引擎 → MyOpenApiService → mock API → AuditLogService 全鏈路,只斷言「輸入什麼就該得到什麼 JSON」。這是 regression 的第一道防線。
- **中層(平台契約)**:`DataIndexGraphQLTest` 驗證的不是轉帳本身,而是**平台對 Data Index 的兩項擴展**是否生效(SQLite timestamp dialect、nodes 表 I/O tracing)。
- **底層(服務單元)**:`MyOpenApiServiceRetryTest` 不起 Quarkus 容器,直接 `new MyOpenApiService()`,以確定性手段(discard 埠)製造傳輸失敗,毫秒級完成退避演算法驗證。
- **JDBC 旁路**:HTTP 斷言只能看到 workflow 輸出 JSON;四支測試中三支會另開 `jdbc:sqlite:target/test-reconciliation.db` 連線直查資料庫,驗證「引擎說成功」之外「帳也真的記對了」。

### 1.3 為什麼幾乎都是 `@QuarkusTest`?

`saga2-transfer-workflow` 的核心價值在「SonataFlow 引擎編排 + jq 條件 + 自訂 Java 服務」三者之間的接線。任何一環用 mock 取代都會讓測試失去意義(例如 jq `match()` 寫錯只有真引擎才會暴露)。因此本平台的策略是:**寧可全棧慢,也不要 mock 出一個假的綠燈**。唯一的例外是重試演算法——它需要精確計時與確定性失敗,全棧反而做不到,故用純 JUnit。

---

## 2. 測試環境:%test profile 要點

測試設定集中在 `distribution/transfer-app/src/main/resources/application.properties` 的 `%test.*` 段(行號可能隨版本變動,約在檔尾 Test profile 區塊):

```properties
%test.quarkus.http.test-port=8080
%test.quarkus.datasource.jdbc.url=jdbc:sqlite:target/test-reconciliation.db
%test.quarkus.oidc.enabled=false
%test.quarkus.oidc.tenant-enabled=false
%test.quarkus.oidc.auth-server-url=none
%test.quarkus.keycloak.devservices.enabled=false
```

逐條解讀:

| 設定 | 為什麼 |
|------|--------|
| `%test.quarkus.http.test-port=8081 → 8080` | 生產設定 transfer-app 本來就是 8080;註解明言「將測試 port 改回 8080,**讓 self-call 可命中**」——workflow 內 `MyOpenApiService#callOpenApi` 依 `kogito.sw.functions.callApiViaOpenAPI.host=localhost/port=8080` 回打自己應用內的 `/A16229`・`/A16220` mock 端點。若測試埠不同,self-call 就會打到不存在的服務。 |
| `%test.quarkus.datasource.jdbc.url=jdbc:sqlite:target/test-reconciliation.db` | 測試專用 DB,**相對路徑**(相對 surefire 工作目錄 = `distribution/transfer-app/`)。SQLite JDBC 同時接受 `/` 與 `\`,Linux/Windows 皆可(`Saga2TransferWorkflowTest` 註解明載此跨平台考量)。每次 `mvn clean` 後首輪測試由空库起步;`AuditLogService#initDatabase` 啟動時自動建表+WAL+遷移。 |
| `%test.quarkus.oidc.*=false` / `%test.quarkus.keycloak.devservices.enabled=false` | 平台整體 OIDC 全關(platform-data-index base 已設),%test 再強化一次,確保 CI 環境不會因嘗試連 Keycloak Dev Services 而卡住。 |

> 注意:reconciliation-app 的 `%test` 段用的是 `test-port=8081`(見 `distribution/reconciliation-app/src/main/resources/application.properties`),但**四支測試類全部位於 transfer-app 模組**,實際測試一律跑在 8080。

---

## 3. 執行測試的指令

```bash
# 完整測試(37 tests,位於 transfer-app 模組)
mvn test -pl distribution/transfer-app

# 先建置依賴模組再測(首次或改了 domain/platform 原始碼後必須)
mvn install -DskipTests && mvn test -pl distribution/transfer-app

# 只跑單一測試類
mvn test -pl distribution/transfer-app -Dtest=Saga2TransferWorkflowTest

# 只跑單一方法(支援萬用字元)
mvn test -pl distribution/transfer-app -Dtest='ReconciliationCsvTest#testACsvFilenameUniqueness'
```

要點:

- `-pl distribution/transfer-app`:四支測試類都在此模組,不必掃全 repo。
- 若改過 `domain-transfer/*` 或 `platform-*` 原始碼,需先 `install`(或至少 `-am`)讓快照進本地倉庫。
- 測試期間日誌寫到 `logs/transfer-app.log`(`quarkus.log.file.path`);`[OPS-ALERT]`、`[HTTP-AUDIT]` 通道亦在此觀察。
- 測試會在 `distribution/transfer-app/data/`(經 `PlatformPaths#dataDirectory()` 解析)留下匯出的 CSV 檔,屬正常副產物。

---

## 4. Saga2TransferWorkflowTest(18 tests)

> 原始檔:`distribution/transfer-app/src/test/java/com/example/platform/distribution/transfer/Saga2TransferWorkflowTest.java`
> 類級註解自述:「對應 saga-transfer-workflow v14 測試集」,透過 `POST /saga2-transfer-workflow` 啟動並以 rest-assured 驗證輸出 JSON。
> 共用常數:`WORKFLOW_URL = "/saga2-transfer-workflow"`、`PAYLOAD_TEMPLATE = {"Account_A":"A123","Account_B":"B123","AMT":%d}`。

18 個 test 方法分七組:

### 第一組 [1]–[6]:五種業務情境 + 邊界值

| # | 方法 | 情境 | 關鍵斷言 |
|---|------|------|---------|
| [1] | `testAmt100Success` | AMT=100,兩 API 都成功 | `status=SUCCESS`、`message="交易成功"`、`a16229Result.code="100"` 且 `_httpStatus=200`、`a16220Result.code="100"`、**`opsAlertRaised=false`** |
| [2] | `testAmt600RolledBackLifo` | AMT>500 觸發 LIFO 完整回沖 | `status=ROLLED_BACK`、`message="AMT > 500 觸發 saga 回沖 (LIFO)"`、兩個 Rollback 都 `code="100"` 且 `message="成功(EC)"`(EC=true 之路徑) |
| [3] | `testAmt30Failed` | A16229 業務失敗短路 | `status=FAILED`、`a16229Result.code="999"` 且 `_httpStatus=403`;**短路斷言**:`a16220Result`、`a16229Rollback`、`a16220Rollback` 三者皆 `nullValue()` |
| [4] | `testAmt2000RolledBackA16229Only` | A16220 失敗(AMT≥1000),僅回沖 A16229 | `message="A16220 業務失敗,僅回沖 A16229"`、`a16229Rollback.code="100"`、**`a16220Rollback=nullValue()`**(A16220 從未扣款成功,不需回沖) |
| [5] | `testAmt500BoundarySuccess` | 邊界 AMT=500 | `status=SUCCESS`(規則:AMT ≤ 500 才算成功) |
| [6] | `testAmt501BoundaryRolledBack` | 邊界 AMT=501 | `status=ROLLED_BACK`(501 即觸發 LIFO) |

> mock 分流規則(斷言值的源頭):
> - `A16229Resource#execute`:AMT ≤ 50 → HTTP 403 + `code="999"`("AMT必須大於50");否則成功 `code="100"`。
> - `A16220Resource#execute`:AMT ≥ 1000 → HTTP 403 + `code="999"`("AMT必須小於1000");否則成功。
> 因此 AMT=30 卡在階段 1、AMT=2000 卡在階段 2、600 走全回沖、500/501 是 `DecideByEvaluation` switch 的 `.AMT <= 500` 邊界。

### 第二組 [7]:JDBC 驗證對帳 View

| # | 方法 | 內容 |
|---|------|------|
| [7] | `testSqliteDatabaseRecords` | `Class.forName("org.sqlite.JDBC")` 後直連 `jdbc:sqlite:target/test-reconciliation.db`,`SELECT ... FROM vw_saga_reconciliation`,逐列印出並斷言 `count > 0`——驗證 workflow 收尾時 `AuditLogService#saveLog` 真的落庫,而非只在 HTTP 回應上好看。 |

### 第三組 [8]–[10]:CSV 匯出(`/reconciliation/export-csv`)

| # | 方法 | 內容 |
|---|------|------|
| [8] | `testExportCsvAllRecords` | 無過濾 `{}` 匯出;斷言 `ok=true`、`fileName` 符合 `^reconciliation-\d{8}-\d{6}\.csv$`、`filePath` 落在 `<sep>data<sep>` 下(**以 `File.separator` 動態構造 regex,Linux/Windows 通吃**)、檔案真實存在、內容以 UTF-8 BOM(`\uFEFF`)開頭、含標準表頭與 SUCCESS 紀錄。 |
| [9] | `testExportCsvFilteredByStatus` | `{"status":"ROLLED_BACK"}` 過濾匯出;斷言 `filters.status` 回顯。 |
| [10] | `testExportCsvNoMatchingRecords` | 不存在的 workflowId → `rowCount=0` 但仍 `ok=true`(空匯出不報錯)。 |

### 第四組 [11]–[14]:VALIDATION_FAILED → HTTP 400(含 null-safety)

v2.1.0 起 `ValidateInput` switch 在 workflow 內做 jq 驗證,失敗走 `InjectValidationFailedStatus` → 統一終點,再由 `SonataFlowSecurityConfig$WorkflowStatusFilter` 依 `platform.status-rewrite.mapping=VALIDATION_FAILED=400` 改寫狀態碼:

| # | 方法 | 餵入 | 重點 |
|---|------|------|------|
| [11] | `testValidationFailedMissingField` | 只有 `Account_A`(缺 Account_B/AMT) | **null-safety 主斷言**:400 + `status=VALIDATION_FAILED` + 固定訊息「輸入欄位格式錯誤 (帳號僅限英數字與底線且兩者不得相同;AMT 須為大於 0 的數字)」+ `auditSaved=true`(驗證失敗也留審計)+ `opsAlertRaised=false`;缺失欄位**不得拋 jq 例外**而應收斂到 400。 |
| [12] | `testValidationFailedBadChars` | `Account_B="A@0001"` | 非法字元 → 400(帳號 regex `^[A-Za-z0-9_]+$`)。 |
| [13] | `testValidationFailedAmtZero` | `AMT=0` | 非正數 → 400,且回顯 `AMT=0`。 |
| [14] | `testValidationFailedSameAccount` | A=B=`123456` | 同帳號 → 400。 |

### 第五組 [15]–[16]:errorType 契約

`MyOpenApiService` 的錯誤分類欄位 errorType 採「**成功不含、失敗必有**」的向後相容設計:

| # | 方法 | 斷言 |
|---|------|------|
| [15] | `testSuccessHasNoErrorType` | AMT=100 成功時 `a16229Result.errorType` 與 `a16220Result.errorType` 皆 `nullValue()`——舊消費端不受新欄位影響。 |
| [16] | `testFailedPathErrorTypeBusiness` | AMT=30 時 `a16229Result.errorType="BUSINESS"`(mock 回 HTTP 403 且 body 自帶 `code="999"`,屬「伺服端明確業務決策」)。 |

### 第六組 [17]–[18]:RBFAIL 哨兵 → ROLLBACK_FAILED → HTTP 409

詳見 [第 8 節](#8-rbfail-哨兵rollback_failed-的端到端重現)。

| # | 方法 | 斷言摘要 |
|---|------|---------|
| [17] | `testRollbackFailedLifo` | `Account_B=RBFAIL`、AMT=600:兩階段原本都成功,LIFO 中 A16220 回沖得 `code="401"`、`message="回沖失敗(測試哨兵)"`,但 **LIFO 不中斷**——A16229 仍繼續回沖並成功(`code="100"`);最終 409 + `status=ROLLBACK_FAILED` + `message="⚠️ 回沖失敗,需人工介入處理"` + `auditSaved=true` + `opsAlertRaised=true`。 |
| [18] | `testRollbackFailedA16229Only` | `Account_A=RBFAIL`、AMT=2000:EC=false 正常交易**不受 RBFAIL 影響**(哨兵只在 EC=true 生效),階段 1 成功、階段 2 因 AMT≥1000 失敗;唯一回沖 A16229 得 `code="401"` → 409 ROLLBACK_FAILED + `opsAlertRaised=true`。 |

---

## 5. ReconciliationCsvTest(14 tests)

> 原始檔:同目錄 `ReconciliationCsvTest.java`。
> 類別設計:`@TestMethodOrder(OrderAnnotation.class)` + `@TestInstance(PER_CLASS)` 強制有序;`@BeforeAll seedWorkflowData` 預先跑 6 筆 workflow(`AMT ∈ {100,30,600,2000,500,501}`,帳號 A123/B123)**確保測試獨立可執行、不依賴 Saga2TransferWorkflowTest 的執行順序**。
> 共用常數:`WORKFLOW_URL="/saga2-transfer-workflow"`、`EXPORT_URL="/reconciliation/export-csv"`、`DB_URL="jdbc:sqlite:target/test-reconciliation.db"`。
> 私有工具:`exportField(body,field)`(打匯出 API 抽欄位)、`countDbRows(workflowId,businessKey,status)`(直查 view COUNT)、`parseCsvLine`(處理雙引號跳脫的 CSV 解析器)、BOM 偵測(讀 byte 0xEF/0xBB/0xBF)。

四大類 14 個 test:

### A 類:CSV 匯出健全性(5 個,[A1]–[A5])

| # | 方法 | 驗證點 |
|---|------|--------|
| [A1] | `testACsvFilenameUniqueness` | 連續兩次匯出(中間睡 1100ms 跨秒)`fileName` 必不重複,且格式為 `reconciliation-YYYYMMDD-HHmmss.csv`(秒級時間戳命名)。 |
| [A2] | `testAEmptyCsvStillHasHeader` | 用不存在 workflowId 匯出空資料:檔案存在、前三 byte = `EF BB BF`(UTF-8 BOM)、表頭齊全(`id,created_at,workflow_id,business_key,process_instance_id,status,...`)、全文僅 1 行(表頭)。**空匯出也要能被 Excel 正確開啟。** |
| [A3] | `testANullFieldsAsEmptyString` | FAILED 紀錄的 NULL 欄位(`a16220_code`/各 rollback code)在 CSV 必為**空字串**,不得出現字面 `"null"`(斷言 `,null,`、`,null\r`、結尾 `,null` 三種形態皆不存在);同時驗證 FAILED 列 `cols[10]="999"`。 |
| [A4] | `testACsvEscapeForCommas` | 含逗號的中文訊息 `"A16220 業務失敗,僅回沖 A16229"` 必被雙引號包裹(RFC 4180 跳脫)。 |
| [A5] | `testAContentType` | 匯出 API 的 Content-Type 為 `application/json`(回的是 JSON 描述,不是檔案串流),`ok=true`。 |

### B 類:CSV ↔ DB 一致性(3 個,[B1]–[B3])

| # | 方法 | 驗證點 |
|---|------|--------|
| [B1] | `testBCsvRowCountMatchesDbTotal` | CSV 回報的 `rowCount` == `SELECT COUNT(*) FROM vw_saga_reconciliation`(無過濾時)。 |
| [B2] | `testBFilteredCsvMatchesDb` | `ROLLED_BACK`/`SUCCESS`/`FAILED` 三種過濾各自:CSV rowCount == DB 同條件筆數,且 ROLLED_BACK 至少 1 筆。 |
| [B3] | `testBCsvContentMatchesDbFieldByField` | 抽樣最多 10 筆,CSV 每格與 `vw_saga_reconciliation` 逐欄位比對(id/workflow_id/business_key/process_instance_id/status/message/account_a/account_b/amt/a16229_code/a16220_code…),amt 與 NULL 欄位做空字串正規化後比對。 |

### C 類:Saga 業務邏輯一致性(4 個,[C1]–[C4])

以 SQL 對 view 下條件,反向驗證「落庫資料的分布符合 Saga 規則」:

| # | 方法 | SQL 條件(account_a='A123') | 斷言 |
|---|------|------------------------------|------|
| [C1] | `testCAmtGreaterThan500` | `amt > 500 AND amt < 1000` | 必 `ROLLED_BACK` 且 **雙 rollback code 都是 "100"(LIFO 完整回沖)**;至少 1 筆(種子資料 AMT=600 保證)。 |
| [C2] | `testCSuccessHasNoRollback` | `status='SUCCESS'` | `a16229_code` 與 `a16220_code` 都是 "100"、兩個 rollback code 皆空。 |
| [C3] | `testCFailedShortCircuit` | `status='FAILED'` | `a16229_code="999"`、`a16220_code`/`a16220_msg` 空(**短路未呼叫**)、兩個 rollback code 皆空(失敗即停,不回沖)。 |
| [C4] | `testCA16220FailedOnlyRollbackA16229` | `amt >= 1000` | `ROLLED_BACK` + `a16220_code="999"` + `a16229_rollback_code="100"` + `a16220_rollback_code` 空(部分回沖)。 |

### D 類:全鏈路整合(2 個,[D1]–[D2])

| # | 方法 | 驗證點 |
|---|------|--------|
| [D1] | `testDEndToEndAllFourStatuses` | 以時間戳後 6 位當 unique 帳號前綴隔離本次測試資料,連跑 4 種情境(S/F/R/P → SUCCESS/FAILED/ROLLED_BACK×2)並逐一斷言 HTTP 回傳 status;DB 總數恰 +4;匯出全量 CSV 後以帳號字串反查,4 種紀錄都出現在檔案裡。 |
| [D2] | `testDConsistentExportResults` | 無新增紀錄時連續兩次匯出的 rowCount(全量與 SUCCESS 過濾)必一致——匯出是冪等快照,不得有隨機性。 |

---

## 6. DataIndexGraphQLTest(3 tests)

> 原始檔:同目錄 `DataIndexGraphQLTest.java`,`@QuarkusTest`。
> 這支測試守護的是**平台層對 Kogito Data Index SQLite 擴展的兩項修補**,而非轉帳業務。

| # | 方法 | 打擊點 | 斷言與意義 |
|---|------|--------|-----------|
| [1] | `testProcessDefinitionsQuery` | `POST /graphql`,query `{ ProcessDefinitions { id name version } }` | `statusCode(200)`、**`errors=nullValue()`**、`data.ProcessDefinitions notNullValue()`。基本 GraphiQL 端點可用性。 |
| [2] | `testProcessInstancesQuery` | 先 `POST /saga2-transfer-workflow` 製造一筆實例(AMT=100),再查 `{ ProcessInstances { id processId state start end } }` | 同樣 `errors=nullValue()`。**這是 SQLite timestamp dialect 的迴歸測試**:若 `KogitoSQLiteDialect#contributeTypes` 未生效,讀取 `start/end`(ZonedDateTime)即拋 `Error parsing time stamp`,errors 就不再是 null。 |
| [3] | `testNodeInstancesRecordedInDatabase` | 先以**唯一帳號** `AccNodeTestA/AccNodeTestB`(AMT=100)觸發 workflow,再 JDBC 直連 `target/test-reconciliation.db`,`nodes JOIN processes WHERE p.variables LIKE '%AccNodeTestA%'` | 統計每個 node 的 `input_args`/`output_args`:**totalNodes > 0 且兩者非空率 100%**。這是 `NodeTracingProcessEventListener`(beforeNodeTriggered/beforeNodeLeft 寫入 I/O snapshot)的迴歸測試。 |

> 測試技巧:用唯一帳號當「資料指紋」再以 LIKE 反查,避免斷言到其他測試留下的實例——與 `ReconciliationCsvTest#[D1]` 的 uniqueSuffix 手法一致,值得在新測試沿用。

---

## 7. MyOpenApiServiceRetryTest(2 tests)

> 原始檔:同目錄 `MyOpenApiServiceRetryTest.java`。**純 JUnit 5,沒有 `@QuarkusTest`**(類別 javadoc 自述「v2.2 / P2-2」)。
> 測試對象:`MyOpenApiService#callOpenApi` 的傳輸層指數退避重試(僅對「未取得 HTTP 回應」的失敗重試;收到回應者一律不重試)。

### 7.1 確定性失敗的製造手法(本測試最有價值的設計)

網路測試最大的敵人是「不確定」。本測試用三招把 TRANSPORT 失敗變成**必然**:

1. **discard 埠**:`@BeforeAll writeProbeSpec` 動態寫一支探測 spec 到 `target/test-classes/specs/__retry_probe__.yaml`,`servers[0].url` 指向保留埠 `http://127.0.0.1:9/`(discard protocol,作業系統層保證連線立即被拒,不需要任何 mock server,也不佔 port)。
2. **未註冊的 functionName**:`call(...)` 使用 `functionName="retryProbeFn"`,刻意不寫進 application.properties。`MyOpenApiService#doResolveBaseUrl` 的解析順序是 函式屬性 → 規格屬性 → `servers[0].url`;函式屬性缺席時自然落到 spec 宣告值,探測 URL 才會生效。
3. **短 timeout**:`arguments.timeoutSeconds=2`,即使有意外排程延遲也不至於拖垮測試。

### 7.2 兩個 test 方法

| # | 方法 | 參數 | 斷言 |
|---|------|------|------|
| [retry-1] | `transportFailureRetriesWithBackoff` | `maxAttempts=3, retryDelayMs=80` | ① 契約不變:`code="999"`、`errorType="TRANSPORT"`、`_httpStatus=0`(`MyOpenApiService#transportError` 的標準化輸出)。② **耗時計時**:`System.nanoTime()` 包住呼叫,斷言 `elapsedMs >= 180`——maxAttempts=3 意味 3 次嘗試 + 2 次退避 sleep(80 × 2⁰ + 80 × 2¹ = 80+160 = 240ms),扣除計時誤差容忍 60ms 後取下界 180ms。 |
| [retry-2] | `noRetryWhenMaxAttemptsIsOne` | `maxAttempts=1, retryDelayMs=500` | 同樣標準化輸出(code=999/TRANSPORT/_httpStatus=0),且 `elapsedMs < 2000`——maxAttempts=1(預設語意)**不做任何退避 sleep**,連線拒絕應在 timeout 上限內快速返回。 |

> 為何斷言「≥180ms」而不是「≈240ms」?退避 sleep 的理論總量是 240ms,但 JVM 排程、GC、CI 機器負載都會引入上偏;下界斷言(180ms)既能證明「確實睡了兩次」,又不會因計時抖動誤殺。反之 [retry-2] 用上界(<2000ms)證明「完全沒睡」。**上下界夾擊**是計時型測試的標準套路。

---

## 8. RBFAIL 哨兵:ROLLBACK_FAILED 的端到端重現

RBFAIL 是內建的**測試哨兵(test sentinel)**,讓任何人不用改程式就能重現「回沖也失敗」的最糟情境。

### 8.1 哨兵規則

| Mock 端點 | 觸發條件 | 回應 |
|-----------|----------|------|
| `A16229Resource#execute`(/A16229) | `request.EC == true` **且** `Account_A.equals("RBFAIL")` | HTTP 403,body `{code:"401", message:"回沖失敗(測試哨兵)", Account:"RBFAIL"}` |
| `A16220Resource#execute`(/A16220) | `request.EC == true` **且** `Account_B.equals("RBFAIL")` | 同上(Account 帶 Account_B) |

關鍵語意:**一般交易(EC=false)永遠不受 RBFAIL 影響**——哨兵只在回沖(EC=true)呼叫時生效,因此可以自由選擇讓「哪一腳的回沖」失敗。

### 8.2 完整事件鏈(以 test [17] 為例)

```mermaid
sequenceDiagram
    participant T as 測試 [17]
    participant WF as saga2 workflow
    participant M as Mock API
    participant F as WorkflowStatusFilter
    T->>WF: POST {Account_A:"123456", Account_B:"RBFAIL", AMT:600}
    WF->>M: A16229 EC=false → 100 成功
    WF->>M: A16220 EC=false → 100 成功
    Note over WF: DecideByEvaluation: 600 > 500 → LIFO
    WF->>M: A16220 回沖 EC=true + Account_B=RBFAIL
    M-->>WF: 403 + code=401「回沖失敗(測試哨兵)」
    Note over WF: RollbackA16229 仍繼續(LIFO 不中斷)→ 100 成功
    WF->>WF: CheckRollbackResults: 任一回沖≠100 → InjectRollbackFailedStatus
    WF->>WF: FinalAuditAndEnd: AuditLogService#saveLog + OpsAlertService#raise
    Note over WF: 輸出 status=ROLLBACK_FAILED, opsAlertRaised=true
    F-->>T: HTTP 409(mapping ROLLBACK_FAILED=409)
```

涉及的原始碼鏈:`A16220Resource#execute`(哨兵)→ `CheckRollbackResults`(switch 條件 `anyRollbackFailed`)→ `InjectRollbackFailedStatus` → `FinalAuditAndEnd`(auditSaved/opsAlertRaised)→ `OpsAlertService#raise`(僅 `finalStatus=="ROLLBACK_FAILED"` 時輸出 `[OPS-ALERT]` ERROR 日誌)→ `SonataFlowSecurityConfig$WorkflowStatusFilter`(status-rewrite → 409)。

### 8.3 測試上的兩個哨兵用法

- 讓 **A16220 回沖**失敗:`Account_B=RBFAIL` + AMT∈(500,1000)(如 test [17])——額外驗證 LIFO 不中斷、後一步照走。
- 讓 **A16229 回沖**失敗:`Account_A=RBFAIL` + AMT≥1000(如 test [18])——走 RollbackA16229Only 路徑,且同時驗證「EC=false 階段 1 不受哨兵污染」。

---

## 9. 為新 Workflow 撰寫測試:模板與骨架

假設你已依照 [NEW-WORKFLOW-GUIDE](../03-workflow-dev-guide/NEW-WORKFLOW-GUIDE.md) 完成新 workflow(以下以虛構的 `my-new-workflow` 示範),建議測試套按下列步驟生長:

### 步驟 1:建立測試類(複製 Saga2 骨架)

```java
package com.example.platform.distribution.transfer;

import io.quarkus.test.junit.QuarkusTest;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.*;

@QuarkusTest
@DisplayName("my-new-workflow 測試")
class MyNewWorkflowTest {

    private static final String WORKFLOW_URL = "/my-new-workflow";

    private static final String PAYLOAD_TEMPLATE =
            "{\"Account_A\":\"A123\",\"Account_B\":\"B123\",\"AMT\":%d}";

    @Test
    @DisplayName("[1] 正常情境")
    void testHappyPath() {
        given()
            .contentType("application/json")
            .body(String.format(PAYLOAD_TEMPLATE, 100))
        .when()
            .post(WORKFLOW_URL)
        .then()
            .statusCode(200)
            .body("status", equalTo("SUCCESS"));   // ← 依你的 finalStatus 契約調整
    }
}
```

### 步驟 2:補滿最小測試集(checklist)

照 `Saga2TransferWorkflowTest` 的七組結構,新 workflow 至少要有:

- [ ] **正向情境** 1 筆(status=SUCCESS,含主要 result 欄位斷言);
- [ ] **補償情境**(若有 Saga):觸發條件值 ±1 各一筆(學 [5]/[6] 的 500/501 邊界);
- [ ] **業務失敗短路** 1 筆(斷言後續欄位 `nullValue()`);
- [ ] **驗證失敗**(若有輸入驗證):缺欄位/非法字元/邊界外值,斷言 400 + `VALIDATION_FAILED`;
- [ ] **errorType 契約**:成功不含 errorType、失敗標記正確分類;
- [ ] **JDBC 落庫驗證** 1 筆(`jdbc:sqlite:target/test-reconciliation.db` 直查你的 view/表);
- [ ] 若 workflow 會回沖失敗:**RBFAIL 哨兵** 1–2 筆(409 + `opsAlertRaised=true`)。

### 步驟 3:註冊 status-rewrite(若使用非 200 回應碼)

若新 workflow 有 VALIDATION_FAILED/ROLLBACK_FAILED 之類需要改寫 HTTP code 的狀態,在 `distribution/transfer-app/src/main/resources/application.properties` 把 id 加入名單(免改 Java):

```properties
platform.status-rewrite.workflows=saga2-transfer-workflow,my-new-workflow
```

(映射 `mapping` 通常沿用既有設定;細節見 [CONFIG-REFERENCE](../04-reference/CONFIG-REFERENCE.md)。)

### 步驟 4:讓測試可獨立執行

若測試依賴「某些情境的資料已存在」(像 ReconciliationCsvTest 對 view 筆數的要求),學它用 `@BeforeAll` 自己種資料,**不要**依賴另一支測試先跑——surefire 的類別執行順序不保證。

---

## 10. 常見錯誤

| 症狀 | 原因 | 解法 |
|------|------|------|
| 測試 self-call 全部 connection refused | %test port 不是 8080,workflow 回打 `localhost:8080` 落空 | 確認 `%test.quarkus.http.test-port=8080` 未被改動(見第 2 節) |
| `Error parsing time stamp` 使 DataIndexGraphQLTest [2] 失敗 | SQLite timestamp dialect 修補被移除/覆蓋 | 檢查 `KogitoSQLiteDialect` 是否仍掛在 `quarkus.hibernate-orm.dialect`(症狀辨識詳見 [TROUBLESHOOTING](../07-operations/TROUBLESHOOTING.md)) |
| nodes 表 input_args/output_args 有 null | `NodeTracingProcessEventListener` 未註冊或被改壞 | 對照 DataIndexGraphQLTest [3] 的 100% 非空斷言排查 listener |
| 重試測試偶爾 <180ms 失敗 | 有人把退避因子/上限改掉,或 discard 埠行為被防火牆攔截 | 核對 `MyOpenApiService` 的 `RETRY_BACKOFF_FACTOR=2.0` 與 `MAX_ATTEMPTS_CAP=5` |
| CSV 測試在 Windows 失敗(路徑 regex) | 自行 hard-code 了 `/` 分隔符 | 學 test [8] 用 `File.separator` 動態構造;或直接沿用相對路徑 `jdbc:sqlite:target/...` |
| 測試間筆數斷言(B1/D1)飄移 | 測試資料互相汙染(共用帳號 A123 又自己亂插資料) | 學 [D1] 用時間戳 unique 帳號隔離自己的斷言範圍 |
| `mvn test -pl` 找不到上游類別 | 改了 domain/platform 原始碼但未 install | 先 `mvn install -DskipTests` 再跑測試 |
| 403 Only POST method is allowed | 對 workflow 端點用了 GET(見 [RuntimeFilter 白名單](../07-operations/TROUBLESHOOTING.md)) | 一律 POST |

---

> 相關文件:[TROUBLESHOOTING](../07-operations/TROUBLESHOOTING.md)(地雷排查)、[UI-PAGES](../07-operations/UI-PAGES.md)(手動驗證用的 8 個頁面)、[REST-API-REFERENCE](../04-reference/REST-API-REFERENCE.md)(測試打擊的 endpoint 契約)、[DATABASE-REFERENCE](../04-reference/DATABASE-REFERENCE.md)(vw_saga_reconciliation/nodes 表結構)。
