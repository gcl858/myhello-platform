# OMNI-CASH-TRANSACTION-DEEP-DIVE — omni-cash-transaction.sw.yaml 全流程剖析

> 本文是「企業級 Parent-Child 分流工作流」的核心深度剖析文件，針對 `domain-transfer/transfer-workflow/src/main/resources/omni-cash-transaction.sw.yaml` (v1.0.1) 做逐區塊全文精解：從 11 欄入口契約驗證、Parent 級保險絲冪等檢查、Dispatcher 分流路由、Serverless Workflow v0.8 `subFlowRef` 委派與資料合併、11 狀態對映收斂矩陣，到統一終點與對帳視圖。
>
> - 工作流檔案：`domain-transfer/transfer-workflow/src/main/resources/omni-cash-transaction.sw.yaml` (v1.0.1)
> - 子工作流檔案：
>   - WF-A 繳款：`domain-transfer/transfer-workflow/src/main/resources/repayment-cash-deposit.sw.yaml` (v1.0.1)
>   - WF-B 取消：`domain-transfer/transfer-workflow/src/main/resources/repayment-cash-cancellation.sw.yaml` (v1.0.1)
> - 契約與視圖：
>   - 輸入 Schema：`schemas/omni-cash-transaction-input-schema.json`
>   - 對帳視圖：`db/migration/V1.2.0__create_view_omni_cash_transaction_reconciliation.sql`
> - 引用慣例：以「類別#方法」或「檔案 + state 名」為主；行號僅輔助說明（見 [../README.md](../README.md)）。
> - 配套閱讀：[SAGA2-TEMPLATE-DEEP-DIVE](SAGA2-TEMPLATE-DEEP-DIVE.md)（Saga 核心樣板）、[NEW-WORKFLOW-GUIDE](NEW-WORKFLOW-GUIDE.md)（實作 SOP）、[WORKFLOW-COOKBOOK](WORKFLOW-COOKBOOK.md)（模式配方）。

---

## 目錄

1. [全景：Parent-Child 架構圖與版本演進](#1-全景parent-child-架構圖與版本演進)
2. [檔頭基本資訊與 Metadata 規範](#2-檔頭基本資訊與-metadata-規範)
3. [Timeouts 與平台級錯誤兜底 (platformError)](#3-timeouts-與平台級錯誤兜底-platformerror)
4. [階段 0：ValidateInput 13 條件輸入契約驗證](#4-階段-0validateinput-13-條件輸入契約驗證)
5. [階段 1：IdempotencyCheck 保險絲冪等檢查 (BR-502)](#5-階段-1idempotencycheck-保險絲冪等檢查-br-502)
6. [階段 2：Dispatcher 業務分流路由](#6-階段-2dispatcher-業務分流路由)
7. [階段 3：subFlowRef 子流程委派與資料合併 (H5 機制)](#7-階段-3subflowref-子流程委派與資料合併-h5-機制)
8. [階段 4：MapToParentFinalStatus 狀態對映收斂矩陣](#8-階段-4maptoparentfinalstatus-狀態對映收斂矩陣)
9. [階段 5：14 個 Inject*Status 狀態注入群](#9-階段-514-個-injectstatus-狀態注入群)
10. [階段 6：統一終點 FinalAuditAndEnd 與輸出模板](#10-階段-6統一終點-finalauditandend-與輸出模板)
11. [資料庫對帳視圖 (Reconciliation View) 解析](#11-資料庫對帳視圖-reconciliation-view-解析)
12. [測試情境矩陣與斷言驗證](#12-測試情境矩陣與斷言驗證)
13. [設計原則、已知陷阱與最佳實踐](#13-設計原則已知陷阱與最佳實踐)

---

## 1. 全景：Parent-Child 架構圖與版本演進

### 1.1 業務背景與架構定位

在銀行信用卡臨櫃現金交易體系中，臨櫃交易分為兩大類：
- **正向繳款 (WF-A: `repayment_cash_deposit`)**：櫃員收取現金，依序執行「核心帳戶現金存入 (Core)」與「信用卡主機還款 (CC)」，若 CC 失敗需觸發 Saga LIFO 補償回沖 Core。
- **反向取消 (WF-B: `repayment_cash_cancellation`)**：櫃員因誤入帳等原因執行取消，需先反查原繳款紀錄進行預檢，再依序執行「核心帳戶沖正」與「信用卡主機沖銷」，若 CC 失敗需冪等回滾 Core。

`omni-cash-transaction.sw.yaml` 定位為 **Parent Dispatcher Workflow（統一交易入口工作流）**，對外部系統（臨櫃系統/API Gateway）提供單一 REST 端點 (`POST /omni_cash_transaction`)，封裝了跨子流程的路由、Parent 級冪等攔截、狀態對映與統一可觀測性收尾。

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    API Gateway / 臨櫃終端 (Counter POS)                      │
└──────────────────────────────────────┬──────────────────────────────────────┘
                                       │ POST /omni_cash_transaction (11 欄 JSON)
                                       ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                  Parent Workflow: omni_cash_transaction                     │
│  ┌──────────────────┐    ┌──────────────────┐    ┌───────────────────────┐  │
│  │  ValidateInput   │───▶│ IdempotencyCheck │───▶│      Dispatcher       │  │
│  │ (11 欄格式+條件) │    │(BR-502 冪等保險絲)│    │(operationType: A / B) │  │
│  └──────────────────┘    └──────────────────┘    └───────────┬───────────┘  │
│                                                              │              │
│                 ┌────────────────────────────────────────────┴──────────┐   │
│                 ▼                                                       ▼   │
│   ┌───────────────────────────┐                           ┌─────────────┴─────────────┐
│   │ CallWFARepayment (subflow)│                           │CallWFBCCancellation(subflow)│
│   └─────────────┬─────────────┘                           └─────────────┬─────────────┘
│                 │                                                       │   │
│                 └────────────────────────────┬──────────────────────────┘   │
│                                              ▼                              │
│                               ┌─────────────────────────────┐               │
│                               │   MapToParentFinalStatus    │               │
│                               │ (收斂對映 11 種子流程狀態)  │               │
│                               └──────────────┬──────────────┘               │
│                                              ▼                              │
│                               ┌─────────────────────────────┐               │
│                               │      Inject*Status (14)     │               │
│                               └──────────────┬──────────────┘               │
│                                              ▼                              │
│                               ┌─────────────────────────────┐               │
│                               │      FinalAuditAndEnd       │               │
│                               │(AuditLog + OpsAlert + 輸出) │               │
│                               └─────────────────────────────┘               │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 1.2 22 個 State 分區清單

`omni-cash-transaction.sw.yaml` 內部定義了 **22 個 state**（4 個 switch、4 個 operation、14 個 inject）：

| 分區 | State 名稱 | 類型 | 核心職責 |
|------|-----------|------|----------|
| **驗證區 (階段 0)** | `ValidateInput` | switch | 13 條 jq 規則檢驗 11 欄輸入格式與 A/B 條件必填；失敗導向 `InjectValidationFailedStatus` |
| **冪等區 (階段 1)** | `IdempotencyCheck` | operation | 呼叫 `IdempotencyService::findBySequenceNumber` 查詢既有 AuditLog |
| **冪等區 (階段 1)** | `CheckIdempotencyResult` | switch | 判斷是否命中已收斂終態；命中導向 `InjectIdempotentReplayStatus`，未命中/例外導向 `Dispatcher` |
| **分流區 (階段 2)** | `Dispatcher` | switch | 依 `operationType` 路由：`A` 導向 WF-A、`B` 導向 WF-B、其他導向驗證失敗 |
| **委派區 (階段 3a)** | `CallWFARepayment` | operation | `subFlowRef` 委派子工作流 `repayment_cash_deposit` |
| **委派區 (階段 3b)** | `CallWFBCCancellation` | operation | `subFlowRef` 委派子工作流 `repayment_cash_cancellation` |
| **對映區 (階段 4)** | `MapToParentFinalStatus` | switch | 接收 subflow merge 回來的 `finalStatus`，精準對映至 Parent 對外契約 |
| **注入區 (階段 5)** | `InjectValidationFailedStatus` | inject | 設定 `finalStatus = REJECTED_VALIDATION` (HTTP 400) |
| **注入區 (階段 5)** | `InjectIdempotentReplayStatus` | inject | 設定 `finalStatus = IDEMPOTENT_REPLAY` (HTTP 200) 並提取原執行結果 |
| **注入區 (階段 5)** | `InjectParentPlatformFailed` | inject | 設定 `finalStatus = FAILED` (subflow 委派發生平台錯誤) |
| **注入區 (階段 5)** | `InjectParentUnknown` | inject | 設定 `finalStatus = FAILED` (子流程狀態未知降級安全網) |
| **注入區 (階段 5)** | `InjectSuccessStatus` | inject | 設定 `finalStatus = SUCCESS` (繳款成功, HTTP 200) |
| **注入區 (階段 5)** | `InjectFailedStatus` | inject | 設定 `finalStatus = FAILED` (繳款階段 1 失敗, HTTP 200/500) |
| **注入區 (階段 5)** | `InjectRolledBackStatus` | inject | 設定 `finalStatus = ROLLED_BACK` (繳款階段 2 失敗補償成功, HTTP 200) |
| **注入區 (階段 5)** | `InjectRollbackFailedStatus` | inject | 設定 `finalStatus = ROLLBACK_FAILED` (繳款回沖失敗, HTTP 409 + OpsAlert) |
| **注入區 (階段 5)** | `InjectCancelledStatus` | inject | 設定 `finalStatus = CANCELLED` (取消成功, HTTP 200) |
| **注入區 (階段 5)** | `InjectCancelRejectedStatus` | inject | 設定 `finalStatus = CANCEL_REJECTED` (取消預檢不通過, HTTP 200) |
| **注入區 (階段 5)** | `InjectCancelFailedStatus` | inject | 設定 `finalStatus = CANCEL_FAILED` (取消階段 1 失敗, HTTP 200/500) |
| **注入區 (階段 5)** | `InjectCancelRolledBackStatus` | inject | 設定 `finalStatus = CANCEL_ROLLED_BACK` (取消階段 2 失敗補償成功, HTTP 200) |
| **注入區 (階段 5)** | `InjectCancelRollbackFailedStatus` | inject | 設定 `finalStatus = CANCEL_ROLLBACK_FAILED` (取消回沖失敗, HTTP 409 + OpsAlert) |
| **注入區 (階段 5)** | `InjectLookupFailedStatus` | inject | 設定 `finalStatus = LOOKUP_FAILED` (原交易查無資料, HTTP 500) |
| **終點區 (階段 6)** | `FinalAuditAndEnd` | operation | 寫入 `workflow_execution_log` + 條件觸發 `OpsAlert` + 統一輸出模板後結束 (`end: true`) |

### 1.3 全流程狀態轉移圖 (Mermaid)

```mermaid
flowchart TD
    Start(["▶ POST /omni_cash_transaction"]) --> P0

    %% 階段 0
    subgraph P0["階段 0: 輸入契約驗證"]
        VI{"ValidateInput<br/>13 條 jq 規則檢驗 11 欄位"}
    end

    VI -- "格式非法 / 條件不符" --> IVF["InjectValidationFailedStatus<br/>(REJECTED_VALIDATION · 400)"]
    VI -- "驗證通過 (default)" --> P1

    %% 階段 1
    subgraph P1["階段 1: Parent 級冪等檢查 (BR-502)"]
        IC["IdempotencyCheck<br/>IdempotencyService::findBySequenceNumber"] --> CIR{"CheckIdempotencyResult<br/>found &amp;&amp; non-dispatched"}
    end

    IC -. "平台例外 (保險絲放行)" .-> P2
    CIR -- "命中已收斂紀錄" --> IIR["InjectIdempotentReplayStatus<br/>(IDEMPOTENT_REPLAY · 200)"]
    CIR -- "未命中 / 例外 (default)" --> P2

    %% 階段 2
    subgraph P2["階段 2: 業務分流路由 (Dispatcher)"]
        DISP{"Dispatcher<br/>operationType"}
    end

    DISP -- "opType == 'A'" --> S3A
    DISP -- "opType == 'B'" --> S3B
    DISP -- "default (未知)" --> IVF

    %% 階段 3
    subgraph S3A["階段 3a: 子工作流 WF-A 繳款"]
        CWFA["CallWFARepayment<br/>subFlowRef: repayment_cash_deposit"]
    end

    subgraph S3B["階段 3b: 子工作流 WF-B 取消"]
        CWFB["CallWFBCCancellation<br/>subFlowRef: repayment_cash_cancellation"]
    end

    CWFA -. "onErrors: platformError" .-> IPPF["InjectParentPlatformFailed<br/>(FAILED · 500)"]
    CWFB -. "onErrors: platformError" .-> IPPF
    CWFA --> P4
    CWFB --> P4

    %% 階段 4
    subgraph P4["階段 4: 狀態對映 (MapToParentFinalStatus)"]
        MAP{"MapToParentFinalStatus<br/>對映子流程 finalStatus"}
    end

    MAP -- "SUCCESS" --> ISU["InjectSuccessStatus (200)"]
    MAP -- "FAILED" --> IFA["InjectFailedStatus (500)"]
    MAP -- "ROLLED_BACK" --> IRB["InjectRolledBackStatus (200)"]
    MAP -- "ROLLBACK_FAILED" --> IRBF["InjectRollbackFailedStatus (409 ⚠️)"]
    MAP -- "CANCELLED" --> ICAN["InjectCancelledStatus (200)"]
    MAP -- "CANCEL_REJECTED" --> ICRJ["InjectCancelRejectedStatus (200)"]
    MAP -- "CANCEL_FAILED" --> ICFA["InjectCancelFailedStatus (500)"]
    MAP -- "CANCEL_ROLLED_BACK" --> ICRB["InjectCancelRolledBackStatus (200)"]
    MAP -- "CANCEL_ROLLBACK_FAILED" --> ICRBF["InjectCancelRollbackFailedStatus (409 ⚠️)"]
    MAP -- "LOOKUP_FAILED" --> ILKF["InjectLookupFailedStatus (500)"]
    MAP -- "default (未匹配)" --> IPU["InjectParentUnknown (500)"]

    %% 階段 6
    subgraph P6["階段 6: 統一終點 (FinalAuditAndEnd)"]
        FAE["FinalAuditAndEnd<br/>• saveFinalAuditLog (AuditLogService)<br/>• raiseOpsAlertIfRequired (OpsAlertService)<br/>• 統一輸出 JSON 模板"]
    end

    IVF --> FAE
    IIR --> FAE
    IPPF --> FAE
    IPU --> FAE
    ISU --> FAE
    IFA --> FAE
    IRB --> FAE
    IRBF --> FAE
    ICAN --> FAE
    ICRJ --> FAE
    ICFA --> FAE
    ICRB --> FAE
    ICRBF --> FAE
    ILKF --> FAE

    FAE --> End(["⏹ HTTP Response (200 / 400 / 409 / 500)"])
```

### 1.4 版本演進與架構升級

| 版本 | 核心特性與架構變更 |
|------|-------------------|
| **v0.1 (早期草案)** | 正向繳款與反向取消為兩個完全獨立的 entry point，無統一入口與調度，重複驗證且日誌分散。 |
| **v1.0.0 (雙層架構)** | • 引入 Parent + Child 雙層架構，單一 REST 入口 `POST /omni_cash_transaction`。<br/>• 建立 11 欄位入口契約與條件必填驗證（`ValidateInput`）。<br/>• 實作 Parent 級冪等性檢查（BR-502, `IdempotencyCheck`）。<br/>• 導入 SonataFlow 10.2.0 `subFlowRef` 機制進行子流程動態委派。<br/>• 建立 11 種終態收斂對映矩陣與統一終點 `FinalAuditAndEnd`。 |
| **v1.0.1 (現行版本)** | • 強化 `amount` 欄位的正整數與 mock 哨兵校驗（支援 `FAIL_` 前綴）。<br/>• 完善 `onErrors` 保險絲放行策略，確保 DB 冪等查詢異常不阻斷交易。<br/>• 規範 SQLite 視圖 `vw_omni_cash_transaction_reconciliation` 的 JSON 抽取定義。 |

---

## 2. 檔頭基本資訊與 Metadata 規範

### 2.1 檔頭宣告

```yaml
id: omni_cash_transaction
version: '1.0.1'
specVersion: '0.8.0'
name: Omni Cash Transaction (Parent)
start: ValidateInput
```
(來源：`omni-cash-transaction.sw.yaml` 第 1-4, 29 行)

- **`id: omni_cash_transaction`**：
  - 同時作為 SonataFlow 自動生成的 REST 進入點路徑：`POST /omni_cash_transaction`。
  - 作為 status-rewrite 過濾器的比對鍵。
  - **重要命名規範**：Kogito 10.2.0 中 `id` 若含連字號 `-` 在子流程委派與 codegen 可能產生符號衝突，此處採用底線 `omni_cash_transaction`。
- **`specVersion: '0.8.0'`**：遵循 CNCF Serverless Workflow 0.8 規範。
- **`start: ValidateInput`**：入口第一站即為輸入檢驗。

### 2.2 Metadata 標籤體系

```yaml
metadata:
  domain: payment
  pattern: parent-dispatcher-saga-lifo
  criticality: high
  owner: platform-team
```
(來源：`omni-cash-transaction.sw.yaml` 第 31-35 行)

| Metadata 鍵值 | 實際數值 | 語義與維運用途 |
|--------------|---------|----------------|
| `domain` | `payment` | 業務領域分類，供 Data Index GraphQL 與多租戶查詢過濾。 |
| `pattern` | `parent-dispatcher-saga-lifo` | 架構設計模式標記，表明本流程為 Parent 分流器且內部子流程具備 Saga LIFO 補償能力。 |
| `criticality` | `high` | 交易關鍵等級，金融臨櫃主通道設定為 `high`，影響 SRE 監控告警權重。 |
| `owner` | `platform-team` | 負責團隊標籤，與 `[OPS-ALERT]` 告警派工系統對齊。 |

---

## 3. Timeouts 與平台級錯誤兜底 (platformError)

### 3.1 四層逾時防線設計

Parent 工作流整合多個子流程與內部服務，逾時預算必須逐層放大，保證「底層服務先行回傳錯誤，上層引擎不過早中斷」：

```
IdempotencyService / 本地 DB 查詢 (5s)
  < AuditLogService / 本地 DB 寫入 (10s)
    < 子流程 API 呼叫 (MyOpenApiService 10s < actionExec 15s < stateExec 30s)
      < 子流程總預算 (workflowExecTimeout PT5M)
        < Parent 總預算 (workflowExecTimeout PT10M)
```

| 層次 | 逾時設定值 | 作用範疇與設計依據 |
|------|-----------|--------------------|
| **Parent 總逾時** | `workflowExecTimeout: PT10M` | Parent 流程整體執行的最大上限（10 分鐘）。容納子流程呼叫、主機延遲、傳輸重試、Saga 補償及兩次 AuditLog 寫入。 |
| **Idempotency 查詢** | `actionExec: PT5S`<br/>`stateExec: PT10S` | 本地 SQLite 查詢既有記錄，給予 5s/10s 快速失敗防線。 |
| **統一終點 AuditLog** | `actionExec: PT10S`<br/>`stateExec: PT20S` | 本地 DB 寫入與告警日誌輸出，給予 10s/20s 充裕時間確保帳務落地。 |

### 3.2 platformError 兜底定義與 onErrors 收斂策略

```yaml
errors:
  - name: platformError
    code: 'PLATFORM_ERROR'
    description: 平台層非預期錯誤 (state timeout / 引擎例外 / 服務未攔截例外)
```
(來源：`omni-cash-transaction.sw.yaml` 第 40-43 行)

> [!IMPORTANT]
> **Kogito Codegen 鐵律**：`errors` 項目中必須包含 `code: 'PLATFORM_ERROR'`，若缺少 `code` 欄位，Kogito 代碼生成器將在編譯期靜默忽略該錯誤定義，導致所有 `onErrors` 攔截完全失效！

#### Parent 工作流各 State 的 onErrors 收斂決策表

| State 名稱 | 業務位置 | onErrors 目標轉移 | 設計動機與收斂理由 |
|-----------|---------|-------------------|-------------------|
| `ValidateInput` | 階段 0 驗證 | `InjectValidationFailedStatus` | 未動帳，直接收斂為驗證失敗（HTTP 400）。 |
| `IdempotencyCheck` | 階段 1 冪等查詢 | `Dispatcher` | **保險絲放行原則**：DB 查詢異常絕不可阻斷臨櫃交易，降級繼續正常分流。 |
| `CheckIdempotencyResult` | 階段 1 冪等分流 | `Dispatcher` | jq 求值或資料結構異常時，保守視為未命中，放行進 Dispatcher。 |
| `Dispatcher` | 階段 2 分流路由 | `InjectValidationFailedStatus` | 路由異常或找不到分支時，收斂為驗證失敗。 |
| `CallWFARepayment` | 階段 3a 委派 WF-A | `InjectParentPlatformFailed` | 子流程委派發生引擎級例外時，Parent 標記為 `FAILED` 並進入終點記帳。 |
| `CallWFBCCancellation` | 階段 3b 委派 WF-B | `InjectParentPlatformFailed` | 同上。 |
| `MapToParentFinalStatus` | 階段 4 狀態對映 | `InjectParentUnknown` | 子流程回傳未知狀態時，降級為 `FAILED` 安全網。 |
| 14 個 `Inject*Status` | 階段 5 狀態注入 | —（無 onErrors） | 純記憶體字面值注入，不可能發生例外。 |
| `FinalAuditAndEnd` | 階段 6 統一終點 | —（無 onErrors） | `AuditLogService#doSaveLog` 與 `OpsAlertService#raise` 內部自主吞例外並回傳布林值，確保不拋出異常中斷收尾。 |

---

## 4. 階段 0：ValidateInput 13 條件輸入契約驗證

### 4.1 11 欄位輸入契約規範

與 `schemas/omni-cash-transaction-input-schema.json` 保持 100% 同步的 11 欄位規範：

| 欄位名稱 | 型別 | 長度/格式規則 | 必填性 | 業務說明 (BR 依據) |
|---------|------|-------------|--------|-------------------|
| `partyId` | String | `^[A-Za-z0-9]+$` (1~20) | 必填 | 客戶統編 / 身分證字號 (BR-001) |
| `branchCode` | String | `^[A-Za-z0-9]+$` (1~10) | 必填 | 交易分行代號 (BR-001) |
| `transactionDate` | String | `^[0-9]{8}$` | 必填 | 交易日期 `YYYYMMDD` |
| `transactionDateTime` | String | `^[0-9]{8}$` | 必填 | 交易時間 `HHMMSSxx` (8 碼) |
| `postingDayType` | String | `A` 或 `B` | 必填 | 本/次日帳類型 (`A`=本日帳 / `B`=次日帳) |
| `postingDate` | String | `^[0-9]{8}$` | 必填 | 入帳日期 `YYYYMMDD` |
| `paymentSourceCode` | String | `^[A-Za-z0-9]{1,10}$` | 必填 | 繳款來源碼 (如 `2500P`) |
| `operationType` | String | `A` 或 `B` | 必填 | Dispatcher 路由鍵 (`A`=繳款, `B`=取消) |
| `amount` | String | `^(FAIL_)?[0-9]+$` (>0) | 必填 | 繳款金額（單位：分，左補零，正整數）(BR-002) |
| `sequenceNumber` | String | `^[A-Za-z0-9_]+$` (1~22) | 必填 | 交易序號，Parent 級冪等鍵 (BR-502) |
| `originalSequenceNumber` | String | `^[A-Za-z0-9_]+$` (1~22) | **條件必填** | 原繳款序號（**`operationType=A` 嚴禁帶入；`operationType=B` 必填**）(BR-P03) |

### 4.2 13 條 jq 驗證條件逐條剖析

`ValidateInput` 採用 **P2-1 反轉慣例（窮舉所有非法條件導向失敗，全部通過則由 defaultCondition 前進）**：

```yaml
- name: ValidateInput
  type: switch
  onErrors:
    - errorRef: platformError
      transition: InjectValidationFailedStatus
  dataConditions:
    # 1. partyId 格式檢驗 (null-safe)
    - name: partyIdInvalid
      condition: '${ ((.partyId // "") | match("^[A-Za-z0-9]+$") // false) == false }'
      transition: InjectValidationFailedStatus

    # 2. branchCode 格式檢驗
    - name: branchCodeInvalid
      condition: '${ ((.branchCode // "") | match("^[A-Za-z0-9]+$") // false) == false }'
      transition: InjectValidationFailedStatus

    # 3. transactionDate 8 碼數字檢驗
    - name: transactionDateInvalid
      condition: '${ ((.transactionDate // "") | match("^[0-9]{8}$") // false) == false }'
      transition: InjectValidationFailedStatus

    # 4. transactionDateTime 8 碼時間檢驗
    - name: transactionDateTimeInvalid
      condition: '${ ((.transactionDateTime // "") | match("^[0-9]{8}$") // false) == false }'
      transition: InjectValidationFailedStatus

    # 5. postingDayType 列舉檢驗 (A 或 B)
    - name: postingDayTypeInvalid
      condition: '${ ((.postingDayType // "") as $t | ($t == "A" or $t == "B")) | not }'
      transition: InjectValidationFailedStatus

    # 6. postingDate 8 碼數字檢驗
    - name: postingDateInvalid
      condition: '${ ((.postingDate // "") | match("^[0-9]{8}$") // false) == false }'
      transition: InjectValidationFailedStatus

    # 7. paymentSourceCode 1~10 碼英數檢驗
    - name: paymentSourceCodeInvalid
      condition: '${ ((.paymentSourceCode // "") | match("^[A-Za-z0-9]{1,10}$") // false) == false }'
      transition: InjectValidationFailedStatus

    # 8. operationType 列舉檢驗 (A 或 B)
    - name: operationTypeInvalid
      condition: '${ ((.operationType // "") as $o | ($o == "A" or $o == "B")) | not }'
      transition: InjectValidationFailedStatus

    # 9. amount 格式檢驗 (支援 FAIL_ mock 哨兵)
    - name: amountInvalid
      condition: '${ ((.amount // "") | match("^(FAIL_)?[0-9]+$") // false) == false }'
      transition: InjectValidationFailedStatus

    # 10. amount 正數檢驗 (不可為 0、0000000000 或負數)
    - name: amountNotPositive
      condition: '${ ((.amount // "") as $a | ($a == "0" or $a == "0000000000" or (($a | startswith("FAIL_") | not) and ($a | tonumber) <= 0))) }'
      transition: InjectValidationFailedStatus

    # 11. sequenceNumber 非空檢驗
    - name: sequenceNumberMissing
      condition: '${ ((.sequenceNumber // "") | length) == 0 }'
      transition: InjectValidationFailedStatus

    # 12. BR-P03: operationType=A 時嚴禁帶 originalSequenceNumber
    - name: opTypeAWithOriginalSeq
      condition: '${ .operationType == "A" and ((.originalSequenceNumber // "") | length) > 0 }'
      transition: InjectValidationFailedStatus

    # 13. BR-P03: operationType=B 時必填 originalSequenceNumber
    - name: opTypeBMissingOriginalSeq
      condition: '${ .operationType == "B" and ((.originalSequenceNumber // "") | length) == 0 }'
      transition: InjectValidationFailedStatus

  defaultCondition:
    transition: IdempotencyCheck
```
(來源：`omni-cash-transaction.sw.yaml` 第 73-123 行)

#### jq 安全表達式關鍵技術：
1. **`((.field // "") | match("regex") // false) == false`**：
   - 由於 jackson-jq 不支援 `test()` 函數，必須使用 `match()`。
   - `match()` 在匹配失敗時會丟出錯誤而非 false，因此透過 `// false` 收斂為布林 false，再以 `== false` 檢定「不匹配」。
   - `// ""` 預先將 null 或缺失欄位收斂為空字串，防止對 null 求值丟出例外導致跳過檢查。
2. **條件相關性校驗 (BR-P03)**：
   - 條件 12 與條件 13 實現了 JSON Schema `if-then` 語義：A 交易不應有原單序號（防誤填），B 取消交易必須明確指定被取消的原單序號。

---

## 5. 階段 1：IdempotencyCheck 保險絲冪等檢查 (BR-502)

### 5.1 業務邏輯與流程設計

```
                             POST /omni_cash_transaction
                                         │
                                         ▼
                            [ ValidateInput 通過 ]
                                         │
                                         ▼
                      ┌──────────────────────────────────────┐
                      │          IdempotencyCheck            │
                      │ IdempotencyService.findBySequenceNo  │
                      └──────────────────┬───────────────────┘
                                         │
                                         ▼
                            /─────────────────────────\
                           /   CheckIdempotencyResult  \
                          <   found==true && status!=   >
                           \       'DISPATCHED'?       /
                            \─────────────────────────/
                                 │                 │
                           [ 是: 命中已收斂 ]     [ 否 / 例外 ]
                                 │                 │
                                 ▼                 ▼
                  ┌───────────────────────────┐ ┌──────────────┐
                  │InjectIdempotentReplayStatus│ │  Dispatcher  │
                  │(finalStatus=IDEMPOTENT_REPLAY│ │ (繼續委派子流程)│
                  └──────────────┬────────────┘ └──────────────┘
                                 │
                                 ▼
                      ┌───────────────────────┐
                      │   FinalAuditAndEnd    │
                      │ (回傳原交易執行結果)  │
                      └───────────────────────┘
```

### 5.2 狀態定義與程式碼剖析

```yaml
- name: IdempotencyCheck
  type: operation
  timeouts:
    actionExecTimeout: PT5S
    stateExecTimeout: PT10S
  onErrors:
    # 冪等查詢失敗視為未命中(保險絲放行),繼續 dispatcher;絕不因冪等查詢而 5xx
    - errorRef: platformError
      transition: Dispatcher
  actions:
    - name: findExistingBySequenceNumber
      functionRef:
        refName: checkIdempotency
        arguments:
          workflowId: "omni_cash_transaction"
          businessKey: '${ .sequenceNumber }'
      actionDataFilter:
        results: '{found: .found, priorFinalStatus: .priorFinalStatus, priorResult: .priorResult}'
        toStateData: '${ .idempotencyResult }'
  transition: CheckIdempotencyResult

- name: CheckIdempotencyResult
  type: switch
  onErrors:
    - errorRef: platformError
      transition: Dispatcher
  dataConditions:
    # 命中且 finalStatus 已收斂(非 PENDING/DISPATCHED) → 走 IDEMPOTENT_REPLAY
    - name: idempotentHit
      condition: '${ .idempotencyResult.found == true and ((.idempotencyResult.priorFinalStatus // "") | length) > 0 and (.idempotencyResult.priorFinalStatus != "DISPATCHED") }'
      transition: InjectIdempotentReplayStatus
  defaultCondition:
    transition: Dispatcher
```
(來源：`omni-cash-transaction.sw.yaml` 第 132-164 行)

### 5.3 IdempotencyService 實作機制與保險絲原理

`IdempotencyService`（`com.example.reconciliation.IdempotencyService`）核心邏輯：
1. 查詢 SQL：
   ```sql
   SELECT id, status, message, output_data, cancelled_by 
   FROM workflow_execution_log 
   WHERE workflow_id = ? AND business_key = ? 
   ORDER BY id DESC LIMIT 1
   ```
2. **保險絲機制 (Circuit Breaker Style)**：
   - 若資料庫連線超時或異常，`IdempotencyService` 內部 catch 例外並回傳 `{"found": false}`。
   - YAML 的 `onErrors` 同步轉移至 `Dispatcher`。
   - **核心原則**：冪等性為防護措施，絕不能因輔助查詢故障而造成主交易 500 失敗。

---

## 6. 階段 2：Dispatcher 業務分流路由

```yaml
- name: Dispatcher
  type: switch
  onErrors:
    - errorRef: platformError
      transition: InjectValidationFailedStatus
  dataConditions:
    - name: dispatchToWFA
      condition: '${ .operationType == "A" }'
      transition: CallWFARepayment
    - name: dispatchToWFB
      condition: '${ .operationType == "B" }'
      transition: CallWFBCCancellation
  defaultCondition:
    transition: InjectValidationFailedStatus
```
(來源：`omni-cash-transaction.sw.yaml` 第 172-185 行)

- 路由單純明確：
  - `operationType == "A"` → 前往 `CallWFARepayment`（WF-A 繳款）。
  - `operationType == "B"` → 前往 `CallWFBCCancellation`（WF-B 取消）。
  - 非預期值落入 `defaultCondition` → 轉移至 `InjectValidationFailedStatus`。

---

## 7. 階段 3：subFlowRef 子流程委派與資料合併 (H5 機制)

### 7.1 Serverless Workflow v0.8 subFlowRef 規範

在 CNCF Serverless Workflow 0.8 規格中，舊版的 `SubFlow state` 已被廢棄，改為在 `operation` state 內以 `subFlowRef` action 形式執行：

```yaml
- name: CallWFARepayment
  type: operation
  actions:
    - name: callWFARepaymentAction
      subFlowRef:
        workflowId: repayment_cash_deposit
        version: "1.0"
  onErrors:
    - errorRef: platformError
      transition: InjectParentPlatformFailed
  transition: MapToParentFinalStatus

- name: CallWFBCCancellation
  type: operation
  actions:
    - name: callWFBCCancellationAction
      subFlowRef:
        workflowId: repayment_cash_cancellation
        version: "1.0"
  onErrors:
    - errorRef: platformError
      transition: InjectParentPlatformFailed
  transition: MapToParentFinalStatus
```
(來源：`omni-cash-transaction.sw.yaml` 第 198-224 行)

### 7.2 上下文傳遞與資料合併機制 (Data Merging)

```
┌────────────────────────────────────────────────────────┐
│               Parent Workflow State Data               │
│  partyId, branchCode, amount, sequenceNumber, ...      │
└───────────────────────────┬────────────────────────────┘
                            │ (自動繼承並傳入全部上下文)
                            ▼
┌────────────────────────────────────────────────────────┐
│            Child Subflow 執行 (WF-A 或 WF-B)           │
│  執行 API 呼叫、Saga 補償、寫入子流程 AuditLog         │
│  終點輸出: { finalStatus, coreResult, ccResult, ... }  │
└───────────────────────────┬────────────────────────────┘
                            │ (結束時 output 自動 Merge 回 Parent)
                            ▼
┌────────────────────────────────────────────────────────┐
│            Parent Workflow 接收 Merge 後 Data          │
│  .finalStatus          (來自 Child)                    │
│  .coreResult           (來自 Child)                    │
│  .ccResult             (來自 Child)                    │
│  .coreRollbackResult   (來自 Child)                    │
│  .lookupResult         (來自 Child WF-B)               │
└────────────────────────────────────────────────────────┘
```

- **輸入傳入**：Parent 當前的完整 state data（含 11 欄位）自動複製至子流程作為輸入。
- **輸出合併**：子流程 `ChildFinalAuditAndEnd` 輸出的 JSON 物件，會自動 shallow merge 回 Parent 的 state data。
- **後續讀取**：後續 state（如 `MapToParentFinalStatus` 與 `FinalAuditAndEnd`）可直接透過 `.finalStatus`、`.coreResult` 存取子流程的執行明細。

---

## 8. 階段 4：MapToParentFinalStatus 狀態對映收斂矩陣

### 8.1 狀態對映總表 (11 條正向條件 + 1 安全 Default)

Parent 的 `MapToParentFinalStatus` 是將兩大子流程多達 10 種內部狀態收斂對齊為 Parent 對外契約的樞紐：

| 來源子流程 | 子流程 finalStatus | Parent 命中條件 | 轉移 Inject State | Parent 對外 finalStatus | 業務意涵 |
|-----------|-------------------|----------------|-------------------|------------------------|----------|
| **WF-A** | `SUCCESS` | `fromWFASuccess` | `InjectSuccessStatus` | `SUCCESS` | 繳款兩階段皆成功（Core + CC 均入帳） |
| **WF-A** | `FAILED` | `fromWFAFailed` | `InjectFailedStatus` | `FAILED` | 階段 1 Core 失敗（未動帳無補償） |
| **WF-A** | `ROLLED_BACK` | `fromWFARolledBack` | `InjectRolledBackStatus` | `ROLLED_BACK` | 階段 2 CC 失敗，Core 補償成功 |
| **WF-A** | `ROLLBACK_FAILED` | `fromWFARollbackFailed` | `InjectRollbackFailedStatus` | `ROLLBACK_FAILED` | ⚠️ 階段 2 CC 失敗，Core 補償也失敗（需人工） |
| **WF-B** | `CANCELLED` | `fromWFBCancelled` | `InjectCancelledStatus` | `CANCELLED` | 取消兩階段皆成功（Core + CC 沖正沖銷） |
| **WF-B** | `CANCEL_REJECTED` | `fromWFBCancelRejected` | `InjectCancelRejectedStatus` | `CANCEL_REJECTED` | 取消預檢不通過（非 SUCCESS/已取消） |
| **WF-B** | `CANCEL_FAILED` | `fromWFBCancelFailed` | `InjectCancelFailedStatus` | `CANCEL_FAILED` | 取消階段 1 Core 失敗（原入帳仍存） |
| **WF-B** | `CANCEL_ROLLED_BACK` | `fromWFBCancelRolledBack` | `InjectCancelRolledBackStatus` | `CANCEL_ROLLED_BACK` | 取消階段 2 CC 失敗，Core 補償成功 |
| **WF-B** | `CANCEL_ROLLBACK_FAILED` | `fromWFBCancelRollbackFailed` | `InjectCancelRollbackFailedStatus` | `CANCEL_ROLLBACK_FAILED` | ⚠️ 取消階段 2 失敗且補償失敗（需人工） |
| **WF-B** | `LOOKUP_FAILED` | `fromWFBLookupFailed` | `InjectLookupFailedStatus` | `LOOKUP_FAILED` | 原交易序號查無資料 (HTTP 500) |
| **其他** | 未匹配 / 異常 | `defaultCondition` | `InjectParentUnknown` | `FAILED` | 子狀態未知，安全降級為 FAILED |

### 8.2 狀態對映 YAML 定義

```yaml
- name: MapToParentFinalStatus
  type: switch
  onErrors:
    - errorRef: platformError
      transition: InjectParentUnknown
  dataConditions:
    - name: fromWFASuccess
      condition: '${ .finalStatus == "SUCCESS" }'
      transition: InjectSuccessStatus
    - name: fromWFAFailed
      condition: '${ .finalStatus == "FAILED" }'
      transition: InjectFailedStatus
    - name: fromWFARolledBack
      condition: '${ .finalStatus == "ROLLED_BACK" }'
      transition: InjectRolledBackStatus
    - name: fromWFARollbackFailed
      condition: '${ .finalStatus == "ROLLBACK_FAILED" }'
      transition: InjectRollbackFailedStatus
    - name: fromWFBCancelled
      condition: '${ .finalStatus == "CANCELLED" }'
      transition: InjectCancelledStatus
    - name: fromWFBCancelRejected
      condition: '${ .finalStatus == "CANCEL_REJECTED" }'
      transition: InjectCancelRejectedStatus
    - name: fromWFBCancelFailed
      condition: '${ .finalStatus == "CANCEL_FAILED" }'
      transition: InjectCancelFailedStatus
    - name: fromWFBCancelRolledBack
      condition: '${ .finalStatus == "CANCEL_ROLLED_BACK" }'
      transition: InjectCancelRolledBackStatus
    - name: fromWFBCancelRollbackFailed
      condition: '${ .finalStatus == "CANCEL_ROLLBACK_FAILED" }'
      transition: InjectCancelRollbackFailedStatus
    - name: fromWFBLookupFailed
      condition: '${ .finalStatus == "LOOKUP_FAILED" }'
      transition: InjectLookupFailedStatus
  defaultCondition:
    transition: InjectParentUnknown
```
(來源：`omni-cash-transaction.sw.yaml` 第 239-277 行)

---

## 9. 階段 5：14 個 Inject*Status 狀態注入群

所有分支在進入統一終點 `FinalAuditAndEnd` 前，均經過專屬 Inject 節點注入標準化的 `finalStatus` 與繁體中文 `finalMessage`：

| # | Inject State 名稱 | 注入 finalStatus | 注入 finalMessage 原文字串 | HTTP 改寫狀態碼 |
|---|-------------------|------------------|---------------------------|----------------|
| 1 | `InjectValidationFailedStatus` | `REJECTED_VALIDATION` | `輸入欄位格式錯誤 (operationType 必須為 A 或 B;條件必填欄位未滿足)` | **400 Bad Request** |
| 2 | `InjectIdempotentReplayStatus` | `IDEMPOTENT_REPLAY` | `Parent 級冪等命中,回傳原 finalStatus` | **200 OK** |
| 3 | `InjectParentPlatformFailed` | `FAILED` | `subflow 委派發生 platform 級錯誤,Parent 視為失敗` | **500 Internal Error** |
| 4 | `InjectParentUnknown` | `FAILED` | `child finalStatus 對映失敗,Parent 安全降級為 FAILED` | **500 Internal Error** |
| 5 | `InjectSuccessStatus` | `SUCCESS` | `繳款成功 (WF-A 兩階段皆成功)` | **200 OK** |
| 6 | `InjectFailedStatus` | `FAILED` | `繳款失敗 (WF-A 階段 1 失敗,無補償)` | **200 OK** (業務拒絕) |
| 7 | `InjectRolledBackStatus` | `ROLLED_BACK` | `繳款階段 2 失敗,Core 補償成功` | **200 OK** |
| 8 | `InjectRollbackFailedStatus` | `ROLLBACK_FAILED` | `⚠️ 繳款回沖失敗,需人工介入處理` | **409 Conflict** (觸發告警) |
| 9 | `InjectCancelledStatus` | `CANCELLED` | `取消成功 (WF-B 兩階段皆成功)` | **200 OK** |
| 10 | `InjectCancelRejectedStatus` | `CANCEL_REJECTED` | `取消預檢不通過 (原狀態非 SUCCESS / 已被取消 / 查無)` | **200 OK** |
| 11 | `InjectCancelFailedStatus` | `CANCEL_FAILED` | `取消階段 1 失敗,原核心入帳仍存` | **200 OK** |
| 12 | `InjectCancelRolledBackStatus` | `CANCEL_ROLLED_BACK` | `取消階段 2 失敗,Core 補償成功` | **200 OK** |
| 13 | `InjectCancelRollbackFailedStatus` | `CANCEL_ROLLBACK_FAILED` | `⚠️ 取消回沖失敗,需人工介入處理` | **409 Conflict** (觸發告警) |
| 14 | `InjectLookupFailedStatus` | `LOOKUP_FAILED` | `原交易查無資料 (WF-B Lookup 失敗)` | **500 Internal Error** |

---

## 10. 階段 6：統一終點 FinalAuditAndEnd 與輸出模板

### 10.1 State 定義全文

```yaml
- name: FinalAuditAndEnd
  type: operation
  timeouts:
    actionExecTimeout: PT10S
    stateExecTimeout: PT20S
  actions:
    - name: saveFinalAuditLog
      functionRef:
        refName: recordAuditLog
        arguments:
          workflowId: "omni_cash_transaction"
          businessKey: '${ .sequenceNumber }'
          processInstanceId: '${ $WORKFLOW.instanceId }'
          inputData:
            partyId: '${ .partyId }'
            branchCode: '${ .branchCode }'
            operationType: '${ .operationType }'
            amount: '${ .amount }'
            sequenceNumber: '${ .sequenceNumber }'
            originalSequenceNumber: '${ .originalSequenceNumber }'
          outputData:
            status: '${ .finalStatus }'
            message: '${ .finalMessage }'
            coreResult: '${ .coreResult }'
            ccResult: '${ .ccResult }'
            coreRollbackResult: '${ .coreRollbackResult }'
            lookupResult: '${ .lookupResult }'
      actionDataFilter:
        results: '{saved: .saved}'
        toStateData: '${ .auditResult }'

    - name: raiseOpsAlertIfRequired
      functionRef:
        refName: notifyOps
        arguments:
          workflowId: "omni_cash_transaction"
          processInstanceId: '${ $WORKFLOW.instanceId }'
          businessKey: '${ .sequenceNumber }'
          finalStatus: '${ .finalStatus }'
          finalMessage: '${ .finalMessage }'
          detail:
            coreResult: '${ .coreResult }'
            ccResult: '${ .ccResult }'
            coreRollbackResult: '${ .coreRollbackResult }'
      actionDataFilter:
        results: '{raised: .raised}'
        toStateData: '${ .opsAlert }'

  stateDataFilter:
    output: |
      {
        track_id: .sequenceNumber,
        workflow: (if .operationType == "A" then "REPAYMENT" else "CANCELLATION" end),
        status: (if .finalStatus == "SUCCESS" or .finalStatus == "CANCELLED" or .finalStatus == "ROLLED_BACK" or .finalStatus == "CANCEL_ROLLED_BACK" or .finalStatus == "IDEMPOTENT_REPLAY" then 0 else 1 end),
        finalStatus: .finalStatus,
        message: .finalMessage,
        coreResult: (.coreResult // null),
        ccResult: (.ccResult // null),
        coreRollbackResult: (.coreRollbackResult // null),
        lookupResult: (.lookupResult // null),
        auditSaved: (.auditResult.saved // false),
        opsAlertRaised: (.opsAlert.raised // false)
      }
  end: true
```
(來源：`omni-cash-transaction.sw.yaml` 第 393-455 行)

### 10.2 兩大收尾 Action 機制

1. **`saveFinalAuditLog` (稽核落地)**：
   - 呼叫 `AuditLogService#saveLog`。
   - `workflowId` 寫入 `"omni_cash_transaction"`，`businessKey` 綁定 `sequenceNumber`。
   - 寫入資料庫 `workflow_execution_log` 資料表。
   - `actionDataFilter` 捕捉 `{saved: .saved}` 存入 `.auditResult`，避免對帳寫入失敗被靜默掩蓋。
2. **`raiseOpsAlertIfRequired` (條件式運維告警)**：
   - 呼叫 `OpsAlertService#raise`。
   - 服務端過濾：僅在 `finalStatus` 為 `ROLLBACK_FAILED` 或 `CANCEL_ROLLBACK_FAILED` 時觸發專屬 logger `[OPS-ALERT]` 輸出 ERROR 級日誌，供 ELK / Splunk 抓取自動開單。其餘正常或業務失敗狀態回傳 `raised: false`，零日誌干擾。

### 10.3 統一輸出模板欄位對照

| 輸出欄位 | 型別 | jq 表達式 | 說明 |
|---------|------|-----------|------|
| `track_id` | String | `.sequenceNumber` | 交易追蹤號，即 Parent sequenceNumber |
| `workflow` | String | `if .operationType == "A" then "REPAYMENT" else "CANCELLATION" end` | 辨識當前執行為繳款或取消 |
| `status` | Number | `if (.finalStatus in [SUCCESS, CANCELLED, ROLLED_BACK, CANCEL_ROLLED_BACK, IDEMPOTENT_REPLAY]) then 0 else 1` | 頂層數值狀態碼：`0` 代表帳務正常收斂或已妥善回沖，`1` 代表異常 |
| `finalStatus` | String | `.finalStatus` | 業務終態字串（如 `SUCCESS`, `REJECTED_VALIDATION` 等） |
| `message` | String | `.finalMessage` | 業務中文說明訊息 |
| `coreResult` | Object / null | `.coreResult // null` | Core 主機 API 執行結果，未呼叫時為 null |
| `ccResult` | Object / null | `.ccResult // null` | CC 主機 API 執行結果，未呼叫時為 null |
| `coreRollbackResult`| Object / null | `.coreRollbackResult // null` | Core 補償回沖結果，未回沖時為 null |
| `lookupResult` | Object / null | `.lookupResult // null` | WF-B 反查原交易結果，WF-A 時為 null |
| `auditSaved` | Boolean | `.auditResult.saved // false` | 對帳記錄是否成功寫入 SQLite |
| `opsAlertRaised` | Boolean | `.opsAlert.raised // false` | 是否觸發了運維告警 |

---

## 11. 資料庫對帳視圖 (Reconciliation View) 解析

在模組 `V1.2.0__create_view_omni_cash_transaction_reconciliation.sql` 中，建立了專屬的 SQLite 對帳視圖：

```sql
CREATE VIEW IF NOT EXISTS vw_omni_cash_transaction_reconciliation AS
SELECT
  id,
  created_at,
  workflow_id,
  business_key,
  process_instance_id,
  status,
  message,
  -- 入口 11 欄 (Parent 層)
  json_extract(input_data, '$.partyId') AS party_id,
  json_extract(input_data, '$.branchCode') AS branch_code,
  json_extract(input_data, '$.operationType') AS operation_type,
  json_extract(input_data, '$.amount') AS amount,
  json_extract(input_data, '$.sequenceNumber') AS sequence_number,
  json_extract(input_data, '$.originalSequenceNumber') AS original_sequence_number,
  -- 各階段 API 結果
  json_extract(output_data, '$.coreResult.status') AS core_status,
  json_extract(output_data, '$.coreResult.message') AS core_message,
  json_extract(output_data, '$.coreResult.track_id') AS core_track_id,
  json_extract(output_data, '$.ccResult.status') AS cc_status,
  json_extract(output_data, '$.ccResult.message') AS cc_message,
  json_extract(output_data, '$.ccResult.track_id') AS cc_track_id,
  json_extract(output_data, '$.coreRollbackResult.status') AS core_rollback_status,
  json_extract(output_data, '$.coreRollbackResult.message') AS core_rollback_message,
  json_extract(output_data, '$.coreRollbackResult.track_id') AS core_rollback_track_id,
  -- WF-B 專屬
  json_extract(output_data, '$.lookupResult.found') AS lookup_found,
  json_extract(output_data, '$.lookupResult.originalFinalStatus') AS lookup_original_status,
  json_extract(output_data, '$.markResult.marked') AS mark_original_cancelled,
  -- 對帳與告警
  json_extract(output_data, '$.auditSaved') AS audit_saved,
  json_extract(output_data, '$.opsAlertRaised') AS ops_alert_raised
FROM workflow_execution_log
WHERE workflow_id IN (
  'omni_cash_transaction',
  'repayment_cash_deposit',
  'repayment_cash_cancellation'
);
```

### 視圖查詢與稽核優勢：
1. **單一視圖跨三流程**：同時涵蓋 Parent (`omni_cash_transaction`) 與兩個 Child (`repayment_cash_deposit`, `repayment_cash_cancellation`)。
2. **免除複雜 JSON 解析**：將 `input_data` 與 `output_data` 中的關聯鍵值（`amount`, `core_status`, `cc_status`, `lookup_found`）拍平成關聯欄位，支援快速 SQL 查帳與自動化對帳報表產出。

---

## 12. 測試情境矩陣與斷言驗證

在 `OmniCashTransactionWorkflowTest.java` 中實現的完整測試覆蓋：

### 12.1 Parent 級測試情境 (P1~P4)

| 測試編號 | 測試方法名 | 測試情境與輸入特徵 | 預期 HTTP 碼 | 預期 finalStatus | 關鍵斷言屬性 |
|---------|-----------|-------------------|-------------|------------------|-------------|
| **P1** | `testP1InvalidOpType` | `operationType = "C"` (非法操作碼) | `400 Bad Request` | `REJECTED_VALIDATION` | `auditSaved=true`, `opsAlertRaised=false` |
| **P2** | `testP2OpTypeBMissingOriginalSeq` | `operationType = "B"` 但缺 `originalSequenceNumber` | `400 Bad Request` | `REJECTED_VALIDATION` | 驗證 BR-P03 條件必填 |
| **P3** | `testP3OpTypeAWithOriginalSeq` | `operationType = "A"` 但誤帶 `originalSequenceNumber` | `400 Bad Request` | `REJECTED_VALIDATION` | 驗證 BR-P03 A 不可帶原單 |
| **P4** | `testP4IdempotentReplay` | 同一 `sequenceNumber` 重送第二次 | `200 OK` | `IDEMPOTENT_REPLAY` | `message="Parent 級冪等命中,回傳原 finalStatus"` |

### 12.2 WF-A 繳款子流程情境 (A1~A6)

| 測試編號 | 測試方法名 | 測試情境與輸入特徵 | 預期 HTTP 碼 | 預期 finalStatus | 關鍵斷言屬性 |
|---------|-----------|-------------------|-------------|------------------|-------------|
| **A1** | `testA1RepaymentSuccess` | 正向繳款正常流程 | `200 OK` | `SUCCESS` | `workflow="REPAYMENT"`, `coreResult.status=0`, `ccResult.status=0` |
| **A2** | `testA2AmountZeroRejected` | `amount = "0000000000"` (金額為零) | `400 Bad Request` | `REJECTED_VALIDATION` | Parent 階段 0 攔截 |
| **A3** | `testA3CoreBusinessReject` | `amount = "FAIL_000011758"` (Core 拒絕) | `200 OK` | `FAILED` | `coreResult.status=1`, `ccResult=null` (短路無補償) |
| **A4** | `testA4CCFailCoreRollbackSuccess` | CC 業務拒絕，Core 補償成功 | `200 OK` | `ROLLED_BACK` | `coreRollbackResult.status=0` |
| **A5** | `testA5RollbackFailed` | CC 業務拒絕，Core 補償也失敗 (`RBFAIL`) | `409 Conflict` | `ROLLBACK_FAILED` | `opsAlertRaised=true` (觸發 `[OPS-ALERT]`) |
| **A6** | `testA6ReconciliationView` | 驗證 SQLite 對帳視圖落地 | — | `SUCCESS` | 透過原生 JDBC 查 `vw_omni_cash_transaction_reconciliation` 命中紀錄 |

### 12.3 WF-B 取消子流程情境 (B1~B7)

| 測試編號 | 測試方法名 | 測試情境與輸入特徵 | 預期 HTTP 碼 | 預期 finalStatus | 關鍵斷言屬性 |
|---------|-----------|-------------------|-------------|------------------|-------------|
| **B1** | `testB1CancellationSuccess` | 帶有效 `originalSequenceNumber` 取消原交易 | `200 OK` | `CANCELLED` | `workflow="CANCELLATION"`, Core/CC 皆反向成功 |
| **B2** | `testB2LookupFailed` | `originalSequenceNumber` 查無既有記錄 | `500 Internal Error` | `LOOKUP_FAILED` | `coreResult=null`, `ccResult=null` |
| **B3** | `testB3CancelRejectedOriginalNotSuccess` | 原交易狀態為 `FAILED` (非 SUCCESS) | `200 OK` | `CANCEL_REJECTED` | 取消預檢拒絕，未發外部呼叫 |
| **B5** | `testB5CancelStage1Failed` | Core 沖正反向失敗 | `200 OK` / `500` | `CANCEL_FAILED` | 階段 1 失敗無補償，原核心入帳仍存 |
| **B6** | `testB6CancelRolledBack` | CC 沖銷失敗，Core 補償成功 | `200 OK` | `CANCEL_ROLLED_BACK` | 階段 2 失敗，Core 補償回滾 |
| **B7** | `testB7CancelRollbackFailed` | CC 沖銷失敗，Core 補償也失敗 | `409 Conflict` | `CANCEL_ROLLBACK_FAILED` | `opsAlertRaised=true` |

---

## 13. 設計原則、已知陷阱與最佳實踐

### 13.1 六大設計原則 (Best Practices)

1. **單一事實來源原則 (Single Source of Truth)**：
   - Workflow 定義唯一維護於 `domain-transfer/transfer-workflow/src/main/resources/`。
   - `distribution/transfer-app` 下的資源純由 Maven `process-resources` 同步複製，嚴禁直接修改 distribution 副本。
2. **保險絲冪等防護 (Circuit-Breaker Idempotency)**：
   - 冪等查詢（`IdempotencyCheck`）的 `onErrors` 與例外處理必須指向 `Dispatcher` 放行，保證輔助性查詢不拖垮核心交易。
3. **P2-1 正向條件與安全 Default 慣例**：
   - Switch 條件僅列舉明確的正向業務條件，所有邊界狀況、缺失欄位與異常型態一律落入 `defaultCondition` 安全側（如失敗短路或補償）。
4. **服務層吞例外，引擎層依狀態分流**：
   - `MyOpenApiService`、`AuditLogService` 與 `OpsAlertService` 在 Java 內部吞掉傳輸與 SQL 例外，標準化為包含 `status`/`saved`/`raised` 的 JsonNode 回傳，避免引擎過早中斷導致 AuditLog 丟失。
5. **形狀固定的統一輸出模板**：
   - 所有 Inject 分支均匯流至 `FinalAuditAndEnd`，使用 `// null` 與 `// false` 保證輸出 JSON 的鍵值集合永遠完全一致，徹底杜絕前端與消費者解析破裂。
6. **分級可觀測性閉環**：
   - 正常業務失敗僅記錄 AuditLog（`opsAlertRaised=false`）；唯有資料不一致需要人工介入的 `ROLLBACK_FAILED` / `CANCEL_ROLLBACK_FAILED` 才啟動 `[OPS-ALERT]` 日誌通道。

### 13.2 避坑指南 (Pitfalls & Gotchas)

| # | 陷阱 / 錯誤寫法 | 造成後果 | 正確做法 |
|---|----------------|---------|----------|
| 1 | `workflowId` 或 subflow ID 使用連字號 `-` (如 `omni-cash-transaction`) | Kogito 在生成 Java 類別或 subFlowRef 綁定時因識別字不相容報錯 | 統一採用底線命名（如 `omni_cash_transaction`、`repayment_cash_deposit`）。 |
| 2 | `errors` 宣告中遺漏 `code: 'PLATFORM_ERROR'` | Kogito codegen 編譯期靜默忽略該 error 定義，所有 `onErrors` 攔截完全失效 | 每個 error 定義均嚴格指定 `name` 與 `code`。 |
| 3 | 在 jq 中使用 `test()` 函數 | jackson-jq 不支援 `test()`，執行期拋出語法解析例外 | 採用 `((.field // "") | match("regex") // false) == false` 慣用法。 |
| 4 | 在 `FinalAuditAndEnd` 掛載 `onErrors` | 收尾動作若拋錯無人接應，恐形成無限遞迴或狀態混亂 | 收尾 Service（`AuditLogService`）內部保證吞例外回傳布林值，終點不掛 `onErrors`。 |
| 5 | 子流程輸出鍵值與 Parent 讀取鍵值未對齊 | Parent 在 Merge 後讀取 `.coreResult` 為 null，導致 AuditLog 缺失明細 | 子流程的 `stateDataFilter.output` 鍵值必須與 Parent 的 `outputData` 與輸出模板精準一致。 |

---

## 相關文件

- [SAGA2-TEMPLATE-DEEP-DIVE](SAGA2-TEMPLATE-DEEP-DIVE.md)：Saga LIFO 核心樣板 18 狀態精解。
- [NEW-WORKFLOW-GUIDE](NEW-WORKFLOW-GUIDE.md)：8 步開發新工作流 SOP。
- [WORKFLOW-COOKBOOK](WORKFLOW-COOKBOOK.md)：12 道常見工作流設計配方。
- [../02-architecture/OBSERVABILITY.md](../02-architecture/OBSERVABILITY.md)：全鏈路可觀測性與告警體系。
- [../04-reference/SERVICE-REFERENCE.md](../04-reference/SERVICE-REFERENCE.md)：`IdempotencyService`、`AuditLogService`、`OpsAlertService` 完整 API 手冊。
- [../04-reference/DATABASE-REFERENCE.md](../04-reference/DATABASE-REFERENCE.md)：`reconciliation.db` 表結構與對帳視圖全覽。

