# SAGA2-TEMPLATE-DEEP-DIVE — saga2-transfer-workflow v2.2.0 全樣板精解

> 本文是「開發新 Workflow 前必讀」核心三份的第一份,對 `saga2-transfer-workflow.sw.yaml`(v2.2.0)做逐區塊全文精解:從 metadata、timeout 防線、錯誤兜底、switch 慣例,到統一終點與輸出模板,每個設計決策都附原始碼依據。
>
> - 樣板檔案:`domain-transfer/transfer-workflow/src/main/resources/saga2-transfer-workflow.sw.yaml`(v2.2.0)
> - 引用慣例:以「類別#方法」或「檔案 + state 名」為主;行號僅輔助且可能隨版本變動(見 [../README.md](../README.md))。
> - 配套閱讀:[NEW-WORKFLOW-GUIDE](NEW-WORKFLOW-GUIDE.md)(實作 SOP)、[WORKFLOW-COOKBOOK](WORKFLOW-COOKBOOK.md)(模式配方)。

## 目錄

1. [全景:state 分區圖與版本演進](#1-全景state-分區圖與版本演進)
2. [metadata 慣例](#2-metadata-慣例data-index-過濾用)
3. [timeouts 三層防線](#3-timeouts-三層防線)
4. [errors.platformError 兜底與 onErrors 收斂表](#4-errorsplatformerror-兜底與-onerrors-收斂表)
5. [switch 慣例 P2-1:僅正向條件 + 安全 default](#5-switch-慣例-p2-1僅正向條件--安全-default)
6. [operation state 解剖:functionRef 與 actionDataFilter](#6-operation-state-解剖functionref-與-actiondatafilter)
7. [Inject 模式:6 個 Inject*Status 全表](#7-inject-模式6-個-injectstatus-全表)
8. [統一終點 FinalAuditAndEnd](#8-統一終點-finalauditandend)
9. [冪等性(Idempotency)註記](#9-冪等性idempotency註記)
10. [v15 vs v2 差異對照表](#10-v15-vs-v2-差異對照表)
11. [常見錯誤](#11-常見錯誤)

---

## 1. 全景:state 分區圖與版本演進

### 1.1 檔頭基本資訊

```yaml
id: saga2-transfer-workflow
version: '2.2.0'
specVersion: '0.8'
name: Saga2 Transfer Workflow
```
(來源:`saga2-transfer-workflow.sw.yaml` 檔頭)

| 屬性 | 值 | 說明 |
|------|-----|------|
| `id` | `saga2-transfer-workflow` | 同時是 REST 啟動路徑(`POST /saga2-transfer-workflow`)與 status-rewrite 名單比對鍵 |
| `version` | `'2.2.0'` | 目前樣板版本 |
| `specVersion` | `'0.8'` | Serverless Workflow 規格版本,新 workflow 一律沿用 `'0.8'` |
| `start` | `ValidateInput` | 入口即輸入驗證(v15 舊版入口直接是 `CallA16229State`,無驗證) |

**state 總數勘誤**:本文件集早期索引標記「19 states」;對 v2.2.0 YAML 的 `states:` 區塊逐行清點(`- name:` 共 18 個定義),實際為 **18 個 state**:switch ×6、operation ×6、inject ×6。一切以 YAML 實際定義為準。

### 1.2 18 個 state 分區清單

| 分區 | state 名稱 | 型別 | 職責 |
|------|-----------|------|------|
| 驗證區 | `ValidateInput` | switch | jq 五條件驗證輸入;失敗 → `InjectValidationFailedStatus` |
| 階段 1 | `CallA16229State` | operation | 扣款端呼叫 A16229(EC=false),結果存 `.a16229Result` |
| 階段 1 | `CheckA16229Result` | switch | `code=="100"` 才前進;default → `InjectFailedStatus`(短路,未扣款無需補償) |
| 階段 2 | `CallA16220State` | operation | 入帳端呼叫 A16220(EC=false),結果存 `.a16220Result`;此時階段 1 已扣款 |
| 階段 2 | `CheckA16220Result` | switch | 失敗落 default → `RollbackA16229Only`(只回沖已扣款的階段 1) |
| 業務判斷 | `DecideByEvaluation` | switch | `AMT <= 500` 成功;default(>500)觸發 LIFO 全回沖 |
| LIFO 回沖區 | `RollbackA16220` | operation | 回沖後執行的 A16220(EC=true),接 `RollbackA16229` |
| LIFO 回沖區 | `RollbackA16229` | operation | 回沖先執行的 A16229(EC=true),接 `CheckRollbackResults` |
| LIFO 回沖區 | `RollbackA16229Only` | operation | 只回沖 A16229(階段 2 未扣款),接 `CheckRollbackA16229OnlyResult` |
| LIFO 回沖區 | `CheckRollbackResults` | switch | 任一回沖非 100 → ROLLBACK_FAILED;default 全成功 → ROLLED_BACK |
| LIFO 回沖區 | `CheckRollbackA16229OnlyResult` | switch | A16229 回沖成功與否分流 |
| Inject 區 | `InjectValidationFailedStatus` | inject | finalStatus=`VALIDATION_FAILED` |
| Inject 區 | `InjectSuccessStatus` | inject | finalStatus=`SUCCESS` |
| Inject 區 | `InjectFailedStatus` | inject | finalStatus=`FAILED` |
| Inject 區 | `InjectRolledBackStatus` | inject | finalStatus=`ROLLED_BACK`(LIFO 全回沖) |
| Inject 區 | `InjectRolledBackOnlyStatus` | inject | finalStatus=`ROLLED_BACK`(僅回沖 A16229) |
| Inject 區 | `InjectRollbackFailedStatus` | inject | finalStatus=`ROLLBACK_FAILED` |
| 統一終點 | `FinalAuditAndEnd` | operation | 寫 AuditLog + 條件 OpsAlert,以統一模板輸出後 `end: true` |

### 1.3 全流程分區圖(18 states)

```mermaid
flowchart TB
    subgraph V["驗證區(階段 0)"]
        VI["ValidateInput<br/>switch · jq 五條件"]
    end

    subgraph S1["階段 1:扣款 A16229(EC=false)"]
        C29["CallA16229State<br/>operation"] --> K29["CheckA16229Result<br/>switch"]
    end

    subgraph S2["階段 2:入帳 A16220(EC=false)"]
        C20["CallA16220State<br/>operation"] --> K20["CheckA16220Result<br/>switch"]
    end

    subgraph BIZ["業務判斷"]
        DEC["DecideByEvaluation<br/>switch · AMT<=500?"]
    end

    subgraph RB["LIFO 回沖區(補償,EC=true)"]
        RB20["RollbackA16220<br/>後執行先回沖"] --> RB29["RollbackA16229<br/>先執行最後回沖"] --> KR2["CheckRollbackResults<br/>switch"]
        RB29O["RollbackA16229Only<br/>僅回沖階段1"] --> KR1["CheckRollbackA16229OnlyResult<br/>switch"]
    end

    subgraph INJ["Inject 區(設定 finalStatus/finalMessage)"]
        IVF["InjectValidationFailedStatus"]
        ISU["InjectSuccessStatus"]
        IFA["InjectFailedStatus"]
        IRB["InjectRolledBackStatus"]
        IRBO["InjectRolledBackOnlyStatus"]
        IRBF["InjectRollbackFailedStatus"]
    end

    subgraph FIN["統一終點"]
        FA["FinalAuditAndEnd<br/>AuditLog + OpsAlert + 統一輸出模板"]
    end

    VI -->|"default:全部通過"| C29
    VI -->|"任一條件命中"| IVF
    K29 -->|"code==100"| C20
    K29 -->|"default:扣款前失敗"| IFA
    K20 -->|"code==100"| DEC
    K20 -->|"default:已扣款,只回沖A16229"| RB29O
    DEC -->|"AMT<=500 成功"| ISU
    DEC -->|"default:>500 全回沖"| RB20
    KR2 -->|"anyRollbackFailed"| IRBF
    KR2 -->|"default:兩者皆成功"| IRB
    KR1 -->|"rollbackSuccess"| IRBO
    KR1 -->|"default:回沖失敗"| IRBF
    IVF --> FA
    ISU --> FA
    IFA --> FA
    IRB --> FA
    IRBO --> FA
    IRBF --> FA
    FA --> DONE(("end: true"))
```

> 圖中未畫出 12 條 `onErrors` 虛線路徑(避免混雜);每個 state 的 platformError 收斂目標見 [§4 收斂總表](#4-errorsplatformerror-兜底與-onerrors-收斂表)。注意 onErrors 目標與正常轉移目標高度一致——這是刻意設計:任何非預期錯誤都走「該 state 所在業務位置」的同一套收斂語義。

### 1.4 版本演進(v2.0 → v2.1.0 → v2.2.0)

以下摘要取自 YAML `description` 內文(`saga2-transfer-workflow.sw.yaml` description 區塊):

- **v2.0(基線)**:「兩階段交易流程 (Saga 模式回沖) — 套用 MyOpenApiService」。透過 MyOpenApiService 動態套用 `specs/A16229-api.yaml`(executeA16229)與 `specs/A16220-api.yaml`(executeA16220)規格發送 API 請求。
- **v2.1.0 變更(可靠性強化)**:
  - 新增 `errors.platformError` 兜底定義;各 state 掛 `onErrors` 收斂至統一終點,非預期錯誤仍會寫入 AuditLog(**修復 timeout 對帳缺口風險**)。
  - operation state 加 `actionExecTimeout`/`stateExecTimeout` 短防線(須大於 MyOpenApiService 的 HTTP 逾時,讓服務層先行回傳標準化錯誤)。
  - `ValidateInput` 強化:null-safety、AMT > 0、禁止同帳號;驗證訊息與實際規則同步。
  - MyOpenApiService 回應新增 `errorType`(TRANSPORT/BUSINESS/HTTP_4XX/HTTP_5XX),actionDataFilter 一併收進 state data 供稽核與後續分流。
  - 輸出新增 `auditSaved` 欄位,揭露對帳紀錄寫入結果。
- **v2.2.0 變更(樣板精煉)**:
  - 新增 workflow metadata(domain/pattern/criticality/owner),利於 Data Index 查詢過濾。
  - switch 條件精簡:僅保留正向條件 + 安全 default,消除冗餘的全覆蓋條件。
  - 統一終點新增 OpsAlertService 條件告警:`finalStatus=ROLLBACK_FAILED` 時輸出 `[OPS-ALERT]` 日誌通道供接單整合;輸出新增 `opsAlertRaised` 欄位。

YAML 中另有一段被**註解停用**的 `dataInputSchema`(第 43-47 行附近),說明驗證已改由 workflow 內 `ValidateInput` 承接、`schemas/saga-transfer-input-schema.json` 轉為「同步後的文件化契約」,HTTP 400 由 WorkflowStatusFilter 在 JAX-RS 層改寫——完整討論見 §5 與 [NEW-WORKFLOW-GUIDE](NEW-WORKFLOW-GUIDE.md) 步驟⑤。

---

## 2. metadata 慣例(Data Index 過濾用)

```yaml
# 工作流標籤 — Data Index GraphQL / 營運查詢過濾用
metadata:
  domain: transfer
  pattern: saga-lifo-compensation
  criticality: high
  owner: platform-team
```
(來源:`saga2-transfer-workflow.sw.yaml` metadata 區塊)

四個標籤鍵的語義與填寫慣例:

| 鍵 | saga2 實值 | 語義 | 新 workflow 建議 |
|----|-----------|------|------------------|
| `domain` | `transfer` | 業務域歸屬 | 對應所屬 `domain-*` Maven 模組(如 `reconciliation`) |
| `pattern` | `saga-lifo-compensation` | 編排模式 | 有補償用 `saga-*`;單純呼叫用 `pipeline`/`orchestration` 等自訂值 |
| `criticality` | `high` | 關鍵等級(營運優先序) | 金融主流程 `high`,輔助流程 `medium`/`low` |
| `owner` | `platform-team` | 負責團隊(ticketing/通知對象) | 與 OPS-ALERT 接單對象一致 |

用途說明:v2.2.0 變更記錄明言「利於 Data Index 查詢過濾」。實際查詢入口與已驗證的 GraphQL 寫法(含誠實的能力邊界說明)見 [WORKFLOW-COOKBOOK](WORKFLOW-COOKBOOK.md) 配方⑩,以及 [../02-architecture/OBSERVABILITY.md](../02-architecture/OBSERVABILITY.md)。**新 workflow 一律照抄這組四鍵**,只換值——讓所有 workflow 的標籤形狀一致,營運檢索才有可比性。

---

## 3. timeouts 三層防線

### 3.1 工作流層防線

```yaml
timeouts:
  workflowExecTimeout: PT5M
```
(來源:`saga2-transfer-workflow.sw.yaml` timeouts 區塊)

### 3.2 設計原則:「服務層先回標準化錯誤,引擎層才中斷」

四層時間預算由小到大,**外層必須大於內層**:

```
MyOpenApiService HTTP 逾時 (10s, DEFAULT_HTTP_TIMEOUT)
  < actionExecTimeout (PT15S)
    < stateExecTimeout (PT30S)
      < workflowExecTimeout (PT5M)
```

依據(YAML CallA16229State 上方註解原文):「timeouts 防線須大於 MyOpenApiService 的 HTTP 逾時 (預設 10s),讓服務層先回傳標準化錯誤 (code=999 + errorType),而非引擎層中斷。」

為什麼順序如此重要:

1. **HTTP 先斷(10s)**:`MyOpenApiService#resolveTimeout` 解析出的 Duration 套在 `HttpRequest.timeout()`;逾時屬傳輸失敗,由 `MyOpenApiService#sendWithRetry` 的 exceptionally 分支接住,回傳 `{code:"999", errorType:"TRANSPORT", _httpStatus:0}` 的**標準化 body**——workflow 仍能以 jq 讀 `.code` 走 switch 分流,AuditLog 不缺席。
2. **actionExecTimeout 後斷(15s)**:若服務層因故卡住超過 HTTP 逾時仍未返回,引擎在此中斷 action,觸發該 state 的 `onErrors`(platformError),同樣收斂到統一終點。
3. **stateExecTimeout 再後斷(30s)**:涵蓋整個 state(多 action + data filter 求值)。
4. **workflowExecTimeout 最後(5M)**:整體執行上限,防止任何路徑無限掛起。

### 3.3 各 state timeout 數值表(實值)

來源:`saga2-transfer-workflow.sw.yaml` 各 state 定義。

| state | 型別 | actionExecTimeout | stateExecTimeout | 備註 |
|-------|------|-------------------|------------------|------|
| `ValidateInput` | switch | —(未設) | —(未設) | 純 jq 求值,無外部呼叫 |
| `CallA16229State` | operation | **PT15S** | **PT30S** | 須大於 HTTP 10s |
| `CheckA16229Result` | switch | — | — | |
| `CallA16220State` | operation | **PT15S** | **PT30S** | 同上 |
| `CheckA16220Result` | switch | — | — | |
| `DecideByEvaluation` | switch | — | — | |
| `RollbackA16220` | operation | **PT15S** | **PT30S** | 回沖也是外部 API 呼叫 |
| `RollbackA16229` | operation | **PT15S** | **PT30S** | |
| `RollbackA16229Only` | operation | **PT15S** | **PT30S** | |
| `CheckRollbackResults` | switch | — | — | |
| `CheckRollbackA16229OnlyResult` | switch | — | — | |
| `InjectValidationFailedStatus` 等 6 個 Inject | inject | — | — | 純資料注入 |
| **`FinalAuditAndEnd`** | operation | **PT10S** | **PT20S** | 特例,見下 |

### 3.4 兩個特例的解讀

- **FinalAuditAndEnd 是 PT10S / PT20S**:它呼叫的 `recordAuditLog`(AuditLogService#saveLog)與 `notifyOps`(OpsAlertService#raise)是**本地 Java 服務**(SQLite 寫入/日誌),不走 MyOpenApiService 的 HTTP 通道,因此不受「大於 HTTP 10s」約束,可給較緊的 10s/20s 預算。
- **switch/inject state 不設 timeout**:純 jq 求值毫秒級完成;若求值異常會直接拋 platformError 走 onErrors,不需要時間防線。

### 3.5 與傳輸重試的交互作用警告

`kogito.sw.openapi.transport-retry.max-attempts`(預設 1 = 不重試,上限 5)會放大單次呼叫的最壞耗時:`MyOpenApiService#sendWithRetry` 在每次重試前以指數退避 sleep(delay-ms × 2^(n-1),預設首延遲 500ms)。若啟用重試(如 max-attempts=5),最壞情況 ≈ 5×10s(每次都等到 HTTP 逾時)+ 0.5+1+2+4s 退避 ≈ 57.5s,**將超過 PT15S/PT30S 防線**——此時必須同步調大 actionExecTimeout/stateExecTimeout,否則引擎會比服務層先斷,違反 §3.2 的設計原則。配置細節見 [../04-reference/CONFIG-REFERENCE.md](../04-reference/CONFIG-REFERENCE.md)。

---

## 4. errors.platformError 兜底與 onErrors 收斂表

### 4.1 定義

```yaml
# ═══════════════════════════════════════════════
# 平台層錯誤兜底定義
#   onErrors 以名稱匹配,攔截該 state 的所有非預期例外:
#   stateExecTimeout / actionExecTimeout 中斷、jq 評估錯誤、引擎與服務層未攔截例外。
#   MyOpenApiService 自行吞例外回標準化 body,故 HTTP 業務/傳輸失敗不走此路徑,
#   仍由 Check* switch 依 code 判斷;此處主要保障「任何錯誤都收斂到 FinalAuditAndEnd」,
#   避免 AuditLog 缺失造成對帳缺口。
# ═══════════════════════════════════════════════
errors:
  # 注意:Kogito codegen 要求 error 定義必須含 code,否則該定義會被忽略
  - name: platformError
    code: 'PLATFORM_ERROR'
    description: 平台層非預期錯誤 (state timeout / 引擎例外 / 服務未攔截例外)
```
(來源:`saga2-transfer-workflow.sw.yaml` errors 區塊)

三個關鍵事實:

1. **code 必填**:Kogito codegen 要求 error 定義必須含 `code`,否則整個定義會被靜默忽略(YAML 註解原文)——這是「寫了 errors 卻完全沒生效」的頭號原因。
2. **攔截範圍**:onErrors 攔的是「平台層」非預期例外(state timeout 中斷、jq 評估錯誤、引擎/服務層未攔截的例外)。**HTTP 層業務失敗或傳輸失敗不會走到這裡**,因為 MyOpenApiService 把它們吞成標準化 body(`code=999`)交回 workflow。
3. **收斂目的**:確保「任何路徑都會抵達 FinalAuditAndEnd」,對帳紀錄不因非預期錯誤而缺席。

### 4.2 onErrors 收斂目標總表(逐 state)

來源:`saga2-transfer-workflow.sw.yaml` 各 state 的 `onErrors` 區塊。

| state | 所在業務位置 | onErrors → transition | 收斂理由 |
|-------|------------|----------------------|----------|
| `ValidateInput` | 驗證區(**扣款前**) | `InjectValidationFailedStatus` | 尚未動帳,以驗證失敗語義收尾(HTTP 400) |
| `CallA16229State` | 階段 1(**扣款前**) | `InjectFailedStatus` | A16229 未確認成功,視同失敗,無需補償 |
| `CheckA16229Result` | 階段 1(扣款前) | `InjectFailedStatus` | 同上 |
| `CallA16220State` | 階段 2(**A16229 已扣款**) | `RollbackA16229Only` | 已扣款必須補償;階段 2 未扣款,只回沖 A16229 |
| `CheckA16220Result` | 階段 2(A16229 已扣款) | `RollbackA16229Only` | 同上 |
| `DecideByEvaluation` | 業務判斷(兩階段皆已扣款) | `RollbackA16220` | **安全策略:與 default 同向,全回沖**;避免「雙邊扣款卻無補償」 |
| `RollbackA16220` | 回沖區 | `InjectRollbackFailedStatus` | 回沖中出錯 → 標記需人工介入 |
| `RollbackA16229` | 回沖區 | `InjectRollbackFailedStatus` | 同上 |
| `RollbackA16229Only` | 回沖區 | `InjectRollbackFailedStatus` | 同上 |
| `CheckRollbackResults` | 回沖結果檢查 | `InjectRollbackFailedStatus` | 結果未知時保守標記為回沖失敗 |
| `CheckRollbackA16229OnlyResult` | 回沖結果檢查 | `InjectRollbackFailedStatus` | 同上 |
| 6 個 `Inject*Status` | Inject 區 | —(無 onErrors) | inject 是字面資料合併,jq 不可能失敗 |
| `FinalAuditAndEnd` | 統一終點 | —(無 onErrors,刻意) | AuditLogService#doSaveLog 吞例外回 `{saved:false}`、OpsAlertService#raise 吞例外回 `raised=false`,服務層保證不拋(見 §8) |

### 4.3 收斂分組的判斷法

新 workflow 設計 onErrors 時,只需回答一個問題:**「這個 state 執行到一半時,前面已經扣款了嗎?」**

- 扣款前 → 失敗語義直接收尾:`InjectValidationFailedStatus`(輸入問題)或 `InjectFailedStatus`(業務/API 問題)。
- 扣款後 → 一律先補償再收尾:依已完成的階段數選 `RollbackA16229Only`(僅階段 1)或 `RollbackA16220`(全 LIFO);`DecideByEvaluation` 的 onErrors 特別設計成與 defaultCondition 同向(全回沖),讓「評估本身壞掉」不會造成雙邊扣款無補償。
- 回沖過程中 → 只能標記 `ROLLBACK_FAILED` + 觸發 `[OPS-ALERT]`,交人工介入。

完整決策表模板見 [NEW-WORKFLOW-GUIDE](NEW-WORKFLOW-GUIDE.md) 步驟③;模式化配方見 [WORKFLOW-COOKBOOK](WORKFLOW-COOKBOOK.md) 配方③。

---

## 5. switch 慣例 P2-1:僅正向條件 + 安全 default

### 5.1 慣例定義

v2.2.0 變更記錄:「switch 條件精簡:僅保留正向條件 + 安全 default,消除冗餘的全覆蓋條件。」具體規則:

1. dataConditions 只列**正向/成功條件**(如 `code == "100"`),不列鏡像的失敗條件;
2. 其餘一切情況(明確失敗、資料形狀異常、欄位缺失)**一律落 `defaultCondition`**;
3. default 分支即「安全分支」:往保守方向走(失敗短路或補償);
4. onErrors 目標與 default 同向(見 §4.3)。

好處:條件互斥完備性由 default 兜底保證;jq 求值異常或資料異形不會導致「無路由可走」;新增條件時不必重新證明全集覆蓋。

### 5.2 ValidateInput 五條件逐條解析

```yaml
- name: ValidateInput
  type: switch
  onErrors:
    - errorRef: platformError
      transition: InjectValidationFailedStatus
  dataConditions:
    - name: accountAInvalid
      # jackson-jq 不支援 test(),改用 match() // false == false 判斷是否匹配。
      # 欄位缺失/null 先以 // "" 收斂為空字串,避免對 null 做 match 拋例外繞過驗證。
      condition: '${ ((.Account_A // "") | match("^[A-Za-z0-9_]+$") // false) == false }'
      transition: InjectValidationFailedStatus
    - name: accountBInvalid
      condition: '${ ((.Account_B // "") | match("^[A-Za-z0-9_]+$") // false) == false }'
      transition: InjectValidationFailedStatus
    - name: amtInvalid
      # 缺失/null 的 type 為 "null",自然落入本條件
      condition: '${ .AMT | type != "number" }'
      transition: InjectValidationFailedStatus
    - name: amtNotPositive
      condition: '${ .AMT <= 0 }'
      transition: InjectValidationFailedStatus
    - name: sameAccount
      condition: '${ .Account_A == .Account_B }'
      transition: InjectValidationFailedStatus
  defaultCondition:
    transition: CallA16229State
```
(來源:`saga2-transfer-workflow.sw.yaml` state `ValidateInput`)

注意這裡是 P2-1 的**反轉應用**:五個條件全是「非法檢測」,全部導向同一個失敗分支,default 反而是正常路徑。因為驗證場景的本質就是「列舉所有非法情況」,合法情況只有一種(全部通過)→ 交給 default。YAML 註解另指出:「條件順序即回報優先序;多欄位同時錯誤時僅回報第一個命中的分類。」

### 5.3 jq 安全寫法的三個原理

**(1)`match(...) // false == false`——jackson-jq 相容的「是否匹配」判斷**

- jackson-jq(SonataFlow 內嵌 jq 實作)**不支援 `test()`**(YAML 註解原文),必須用 `match()`。
- 但 `match()` 在**不匹配時拋出錯誤**而非回傳 false,因此用 alternative operator `// false` 把「匹配失敗的錯誤」收斂成布林 false,再比較 `== false` 得到「未匹配」的事實。
- 整句讀法:「帳號不是純英數底線組合」→ true → 落入本條件 → 導向驗證失敗。

**(2)`// ""` null 收斂**

`.Account_A // ""` 表示:欄位缺失、null(或 false)時取空字串。若不做這一步,對 null 做 `match()` 會拋例外——例外被 switch 視為求值錯誤,**該條件不成立而跳到下一條件,反而繞過了驗證**。空字串必然不通過 `^[A-Za-z0-9_]+$`(要求至少一字元),所以缺失欄位穩定落入 `accountAInvalid`。測試 [11](Saga2TransferWorkflowTest#testValidationFailedMissingField) 即驗證「缺失欄位不拋 jq 例外,回 400 VALIDATION_FAILED」。

**(3)`type != "number"` 型別檢查**

jq 的 `type` 對數字回傳 `"number"`,對**缺失/null 回傳 `"null"`**,對字串回傳 `"string"`。因此 `.AMT | type != "number"` 一條就涵蓋「缺失、null、字串」三種非法形狀,不需要另外的 null 檢查;隨後的 `.AMT <= 0` 到達時 AMT 必為數字,比較安全。

### 5.4 Check* switch 的正向慣例實例

```yaml
- name: CheckA16229Result
  type: switch
  ...
  dataConditions:
    # 樣板慣例 (P2-1):僅列正向條件,其餘一律落 default 安全分支
    - name: a16229Success
      condition: '${ .a16229Result.code == "100" }'
      transition: CallA16220State
  defaultCondition:
    transition: InjectFailedStatus
```
(來源:`saga2-transfer-workflow.sw.yaml` state `CheckA16229Result`)

`CheckA16220Result` 同構(default → `RollbackA16229Only`)。

### 5.5 鏡像案例:CheckRollbackResults 明列危險條件

```yaml
dataConditions:
  # 樣板慣例 (P2-1):單一失敗條件(任一回沖非 100),其餘視為全部成功
  - name: anyRollbackFailed
    condition: '${ .a16229Rollback.code != "100" or .a16220Rollback.code != "100" }'
    transition: InjectRollbackFailedStatus
defaultCondition:
  # 到此表示兩者皆回沖成功
  transition: InjectRolledBackStatus
```
(來源:`saga2-transfer-workflow.sw.yaml` state `CheckRollbackResults`)

這裡把「危險」明列出來、「正常」走 default——方向依然是安全的:若 rollback 資料缺失,`.code` 為 null ≠ "100",條件成立 → 標記 ROLLBACK_FAILED(保守正確)。可見 P2-1 的精神不在「正向 vs 負向」的字面,而在:**default 永遠指向安全側,未知狀態永遠歸入保守分支**。

---

## 6. operation state 解剖:functionRef 與 actionDataFilter

### 6.1 functions 定義(樣板三函式)

```yaml
functions:
  # 使用通用 OpenAPI 服務 MyOpenApiService
  - name: callApiViaOpenAPI
    operation: 'service:com.example.transfer.workflow.MyOpenApiService::callOpenApi'
    type: custom
  # 使用通用對帳紀錄服務 AuditLogService
  - name: recordAuditLog
    operation: 'service:com.example.reconciliation.AuditLogService::saveLog'
    type: custom
  # 運維條件告警 (ROLLBACK_FAILED → [OPS-ALERT] 日誌通道,供 ticketing/ELK 接單)
  - name: notifyOps
    operation: 'service:com.example.reconciliation.OpsAlertService::raise'
    type: custom
```
(來源:`saga2-transfer-workflow.sw.yaml` functions 區塊)

`operation` 格式為 `service:<完整類別路徑>::<方法名稱>`,`type: custom` 表示由 Kogito codegen 以反射綁定 Java 方法(v15 的 description 記載了歷史教訓:曾用 `type: rest`(OpenAPI addon),但 addon 對 4xx/5xx 寫死拋例外且 v0.8 onErrors 攔不到,故全面改用 custom service)。

### 6.2 以 CallA16229State 為例的完整解剖

```yaml
- name: CallA16229State
  type: operation
  timeouts:
    actionExecTimeout: PT15S
    stateExecTimeout: PT30S
  onErrors:
    - errorRef: platformError
      transition: InjectFailedStatus
  actions:
    - name: callA16229Action
      functionRef:
        refName: callApiViaOpenAPI
        arguments:
          functionName: "callApiViaOpenAPI"
          schemaRef: 'specs/A16229-api.yaml#executeA16229'
          payload:
            Account_A: '${ .Account_A }'
            AMT: '${ .AMT }'
            EC: false
      actionDataFilter:
        results: '{code: .code, message: .message, Account: .Account, errorType: .errorType, _httpStatus: ._httpStatus}'
        toStateData: '${ .a16229Result }'
  transition: CheckA16229Result
```
(來源:`saga2-transfer-workflow.sw.yaml` state `CallA16229State`;`CallA16220State`/三個 Rollback state 同構)

逐元素解析:

| 元素 | 值 | 意義 |
|------|-----|------|
| `functionRef.refName` | `callApiViaOpenAPI` | 對應 functions 區塊的 name |
| `arguments.functionName` | `"callApiViaOpenAPI"` | 供 MyOpenApiService 解析 Base URL 時作為配置鍵(`kogito.sw.functions.<functionName>.host` 等) |
| `arguments.schemaRef` | `'specs/A16229-api.yaml#executeA16229'` | **動態 OpenAPI 定位點**:`<classpath 內 spec 路徑>#<operationId>`;`MyOpenApiService#callOpenApi` 要求必含 `#`,並以 `PlatformPaths#normalizeClasspath` 正規化路徑分隔符 |
| `arguments.payload` | `{Account_A, AMT, EC:false}` | 由 `MyOpenApiService#extractPayload` 取出作為 HTTP body(`EC: false` 是 YAML 字面布林,非運算式) |
| payload 欄位 | `'${ .Account_A }'` 等 | jq 運算式從 state data 取值;注意 A16229 用 `Account_A`、A16220 用 `Account_B`,與各 spec 的 requestBody schema 一致 |

### 6.3 MyOpenApiService 內部流程(一次呼叫的生命週期)

1. `callOpenApi(JsonNode arguments)`:驗證 schemaRef 存在且含 `#`,拆出 specPath/operationId。
2. `resolveEndpoint`:從快取的 YAML AST 找到 operationId 對應的 path/method,並讀 `servers[0].url` 備用。
3. `doResolveBaseUrl`:四層優先序——① `kogito.sw.functions.<fn>.base_url`/`.url` → ② `.protocol`+`.host`+`.port` → ③ `kogito.sw.openapi.<specKey>.base_url`/`quarkus.rest-client.<specKey>.url` → ④ spec 的 `servers[0].url`;全缺則拋 IllegalStateException。
4. `buildTargetUrl`:替換路徑模板 `{param}`、GET/DELETE 無 body 參數轉 Query String。
5. `sendWithRetry`:發送;**僅傳輸失敗**(未取得 HTTP 回應)按指數退避重試,已收到回應者不重試。
6. `normalizeResponse`:標準化——body 自帶業務碼者保留其 code;204/空 body/陣列/純文字各有形狀;失敗時附 `errorType`(BUSINESS=目標系統明確回覆 code≠100 / HTTP_4XX / HTTP_5XX / TRANSPORT);成功(code=="100")**不含 errorType**(向後相容)。一律附 `_httpStatus`。

### 6.4 actionDataFilter 映射語法

```yaml
actionDataFilter:
  results: '{code: .code, message: .message, Account: .Account, errorType: .errorType, _httpStatus: ._httpStatus}'
  toStateData: '${ .a16229Result }'
```

- `results` 是一個 jq **物件建構式**:從服務回應中挑欄位重組成新物件。這裡刻意只挑 5 個契約欄位,不讓整包回應汙染 state data。
- `toStateData` 把 results 物件**整包掛到 state data 的指定鍵下**:此例即 `.a16229Result`。後續 switch 以 `.a16229Result.code == "100"` 判讀;統一終點把它原樣寫入 AuditLog 與輸出模板。
- 三個 Rollback state 的 toStateData 分別是 `.a16220Rollback`/`.a16229Rollback`,與成功結果鍵分離,讓輸出模板能同時呈現「正向結果」與「補償結果」。
- v2.1.0 起 `results` 加入 `errorType`,使稽核與事後分流能看到錯誤分類(description 原文:「actionDataFilter 一併收進 state data 供稽核與後續分流」)。

---

## 7. Inject 模式:6 個 Inject*Status 全表

Inject state 的語義:把 `data` 字面物件合併進 state data(設定 finalStatus/finalMessage),隨即轉移到統一終點。所有終點共用 FinalAuditAndEnd 的同一份 body 模板(YAML ValidateInput 註解:「與其它終點共用同一個 stateDataFilter.output 模板」)。

| Inject state | finalStatus | finalMessage(原文) | 觸發來源 |
|--------------|-------------|----------------------|----------|
| `InjectValidationFailedStatus` | `VALIDATION_FAILED` | `輸入欄位格式錯誤 (帳號僅限英數字與底線且兩者不得相同;AMT 須為大於 0 的數字)` | ValidateInput 五條件 + 其 platformError |
| `InjectSuccessStatus` | `SUCCESS` | `交易成功` | DecideByEvaluation successPath(AMT<=500) |
| `InjectFailedStatus` | `FAILED` | `業務失敗或 API 錯誤` | CheckA16229Result default;CallA16229State/CheckA16229Result 的 platformError |
| `InjectRolledBackStatus` | `ROLLED_BACK` | `AMT > 500 觸發 saga 回沖 (LIFO)` | CheckRollbackResults default(兩回沖皆成功) |
| `InjectRolledBackOnlyStatus` | `ROLLED_BACK` | `A16220 業務失敗,僅回沖 A16229` | CheckRollbackA16229OnlyResult rollbackSuccess |
| `InjectRollbackFailedStatus` | `ROLLBACK_FAILED` | `⚠️ 回沖失敗,需人工介入處理` | CheckRollbackResults anyRollbackFailed;CheckRollbackA16229OnlyResult default;Rollback×3 的 platformError |

範例原文(state `InjectValidationFailedStatus`):

```yaml
- name: InjectValidationFailedStatus
  type: inject
  data:
    finalStatus: "VALIDATION_FAILED"
    # 訊息與 ValidateInput 實際規則同步 (帳號 regex、AMT 正數、禁止同帳號)
    finalMessage: "輸入欄位格式錯誤 (帳號僅限英數字與底線且兩者不得相同;AMT 須為大於 0 的數字)"
  transition: FinalAuditAndEnd
```

兩個工程要點:

1. **訊息與規則同步**:finalMessage 必須與 ValidateInput 的實際五條件一致(regex/正數/不同帳號)——這串文字會直接回給呼叫端,測試 [11] 以 `equalTo("輸入欄位格式錯誤 ...")` 逐字斷言(Saga2TransferWorkflowTest#testValidationFailedMissingField)。改規則必須同步改訊息與測試。
2. **finalStatus 是對外契約**:下游 WorkflowStatusFilter 依它改寫 HTTP code(VALIDATION_FAILED→400、ROLLBACK_FAILED→409),AuditLogService 從 outputData 取它當 status 欄位,OBSERVABILITY 的 errorType 分類也以它為軸。可選值全集即術語表所列:`SUCCESS`/`FAILED`/`ROLLED_BACK`/`ROLLBACK_FAILED`/`VALIDATION_FAILED`。

---

## 8. 統一終點 FinalAuditAndEnd

### 8.1 全文(樣板最重要的 60 行)

```yaml
- name: FinalAuditAndEnd
  type: operation
  timeouts:
    actionExecTimeout: PT10S
    stateExecTimeout: PT20S
  actions:
    - name: saveFinalAuditLog
      functionRef:
        refName: recordAuditLog
        arguments:
          workflowId: "saga2-transfer-workflow"
          businessKey: '${ .Account_A }'
          processInstanceId: '${ $WORKFLOW.instanceId }'
          inputData:
            Account_A: '${ .Account_A }'
            Account_B: '${ .Account_B }'
            AMT: '${ .AMT }'
          outputData:
            status: '${ .finalStatus }'
            message: '${ .finalMessage }'
            AMT: '${ .AMT }'
            a16229Result: '${ .a16229Result }'
            a16220Result: '${ .a16220Result }'
            a16229Rollback: '${ .a16229Rollback }'
            a16220Rollback: '${ .a16220Rollback }'
      # 捕捉對帳寫入結果 (P0-5 可觀測性):saved=false 時輸出仍可見,不再靜默丟失
      actionDataFilter:
        results: '{saved: .saved}'
        toStateData: '${ .auditResult }'
    - name: raiseOpsAlertIfRequired
      # P2-6 運維告警:僅 finalStatus=ROLLBACK_FAILED 時實際觸發
      # ([OPS-ALERT] 日誌通道,供 ELK/Splunk/ticketing 接單);其餘狀態服務端返回 raised=false
      functionRef:
        refName: notifyOps
        arguments:
          workflowId: "saga2-transfer-workflow"
          processInstanceId: '${ $WORKFLOW.instanceId }'
          businessKey: '${ .Account_A }'
          finalStatus: '${ .finalStatus }'
          finalMessage: '${ .finalMessage }'
          detail:
            a16229Rollback: '${ .a16229Rollback }'
            a16220Rollback: '${ .a16220Rollback }'
      actionDataFilter:
        results: '{raised: .raised}'
        toStateData: '${ .opsAlert }'
  stateDataFilter:
    output: |
      {
        status: .finalStatus,
        message: .finalMessage,
        AMT: .AMT,
        a16229Result: (.a16229Result // null),
        a16220Result: (.a16220Result // null),
        a16229Rollback: (.a16229Rollback // null),
        a16220Rollback: (.a16220Rollback // null),
        auditSaved: (.auditResult.saved // false),
        opsAlertRaised: (.opsAlert.raised // false)
      }
  end: true
```
(來源:`saga2-transfer-workflow.sw.yaml` state `FinalAuditAndEnd`)

### 8.2 action 1:saveFinalAuditLog(AuditLogService 模式)

| 參數 | 值 | 對應 DB 欄位/用途 |
|------|-----|------------------|
| `workflowId` | 字面值 `"saga2-transfer-workflow"` | `workflow_execution_log.workflow_id` |
| `businessKey` | `'${ .Account_A }'` | `business_key`(對帳主鍵;選扣款帳號) |
| `processInstanceId` | `'${ $WORKFLOW.instanceId }'` | 引擎內建變數,串起 Data Index 實例與稽核紀錄 |
| `inputData` | 三欄輸入原樣 | `input_data`(JSON 字串) |
| `outputData` | status/message/AMT + 四個 result 物件 | `output_data`;AuditLogService#doSaveLog 另取其中 status/message 存欄位 |

`actionDataFilter` 以 `results: '{saved: .saved}'` 捕捉服務回傳的寫入結果到 `.auditResult`。YAML 註解明言設計動機:「saved=false 時輸出仍可見,不再靜默丟失」。

**為何此 state 不掛 onErrors**(YAML 註解原文):「AuditLogService.doSaveLog 自行吞例外回 {saved:false},不拋例外…失敗細節由服務層 LOG 追查。」亦即收尾動作本身被設計成不可能失敗拋出——若在終點掛 onErrors 反而要再設計一層「收尾失敗的收尾」,無限遞迴;吞例外+回報布林是更務實的終止設計。

### 8.3 action 2:raiseOpsAlertIfRequired(OpsAlertService 模式)

- 判斷在**服務端**完成:`OpsAlertService#raise` 內部比對 `ALERT_ON_STATUS = "ROLLBACK_FAILED"`,不符直接回 `{raised:false}`(靜默、零日誌噪音);符合才以專屬 logger `"OPS-ALERT"` 輸出 ERROR 日誌 `[OPS-ALERT] 回沖失敗,需人工介入 | workflowId=... | detail=...`。
- 告警通道故障也**不得阻斷交易收尾**:raise 內 catch 後降級為一般 LOG.error 並回 `raised:false`(原始碼註解原文)。
- workflow 端契約固定:`results: '{raised: .raised}'` → `.opsAlert`。

### 8.4 stateDataFilter.output 統一輸出模板逐欄解析

| 輸出欄位 | jq 表達式 | 形狀保證 | 說明 |
|----------|-----------|----------|------|
| `status` | `.finalStatus` | 必有字串 | 由上游 Inject 注入;HTTP 語義化與對帳的樞紐欄位 |
| `message` | `.finalMessage` | 必有字串 | 同上 |
| `AMT` | `.AMT` | 必有數字 | 通過驗證後不會缺失 |
| `a16229Result` | `.a16229Result // null` | 物件或 **null** | 未呼叫時顯式 null(如驗證失敗短路) |
| `a16220Result` | `.a16220Result // null` | 物件或 null | A16229 失敗短路時為 null |
| `a16229Rollback` | `.a16229Rollback // null` | 物件或 null | 只有走過回沖才存在 |
| `a16220Rollback` | `.a16220Rollback // null` | 物件或 null | RollbackA16229Only 路徑恆為 null(測試 [4] 斷言 nullValue) |
| `auditSaved` | `.auditResult.saved // false` | 必為布林 | 收尾寫帳結果,false=需查 transfer-app.log |
| `opsAlertRaised` | `.opsAlert.raised // false` | 必為布林 | true ⇒ 已發 [OPS-ALERT](測試 [17] 斷言 true) |

模板的三個設計價值:

1. **形狀固定**:`// null` / `// false` 讓輸出 JSON 的鍵集合在任何路徑下完全一致,消費端(前端 tester.html、測試斷言、CSV 匯出)不必處理「缺欄 vs null」二義性。
2. **所有終點共用**:6 個 Inject 都轉移到此 state,VALIDATION_FAILED/SUCCESS/FAILED/ROLLED_BACK/ROLLBACK_FAILED 全走同一份模板——這正是 v15「每個終點各自維護一份 stateDataFilter.output」痛點的解法(見 §10)。
3. **可觀測性閉環**:輸出同時揭露業務結果(四個 result)、對帳落地結果(auditSaved)、告警結果(opsAlertRaised),一筆回應即可判斷「交易如何結束、帳是否記上、是否有人需要被叫醒」。

---

## 9. 冪等性(Idempotency)註記

YAML description 原文:

> 本 workflow 未內建請求去重——同一請求重送將產生獨立的流程實例與重複交易。
> 金融場景建議:呼叫端於 Header 攜帶 Idempotency-Key,
> 由 API Gateway / 入口層依 key 去重;或於業務 API 層對業務鍵建唯一約束。

解讀與落實建議:

- **現況**:每次 `POST /saga2-transfer-workflow` 都是全新實例;平台各層(UnwrapResponseFilter/WorkflowStatusFilter/RuntimeFilter)均無去重邏輯。
- **入口去重**:Gateway 層以 Idempotency-Key Header 為鍵快取首次回應,重送直接回放(推薦,見 [WORKFLOW-COOKBOOK](WORKFLOW-COOKBOOK.md) 配方⑫)。
- **底線防護**:mock API 層(A16229Resource/A16220Resource)或真實核心系統對「帳號+日期+金額+序號」等業務鍵建唯一約束,防止補償與重試疊加造成重複動帳。
- **對帳偵測**:`vw_saga_reconciliation` 可作事後重複交易稽核來源(見 [../04-reference/DATABASE-REFERENCE.md](../04-reference/DATABASE-REFERENCE.md))。

---

## 10. v15 vs v2 差異對照表

對照檔案:`saga-transfer-workflow.sw.yaml`(v15.0.0,舊版主流程,僅作對照)vs `saga2-transfer-workflow.sw.yaml`(v2.2.0,開發範本)。

| 面向 | v15(saga-transfer-workflow) | v2(saga2-transfer-workflow) |
|------|------------------------------|------------------------------|
| 服務層路線 | `SagaApiService` **直打 REST**:`BASE_URL="http://localhost:8080"` 寫死在程式碼,每端點一個方法(callA16229/callA16220),JDK HttpClient 直連;回應僅標準化 code/message/_httpStatus,**無 errorType、無重試、無 spec 解析**(`SagaApiService#callApiAsync`) | `MyOpenApiService` **動態 OpenAPI**:schemaRef 定位端點、四層 Base URL 解析、path-param/query 自動組裝、傳輸層指數退避重試、errorType 四分類、四層 ConcurrentHashMap 快取 |
| state 數量 | **10 states**(operation×7 + switch×3) | **18 states**(switch×6、operation×6、inject×6) |
| 輸入驗證 | `dataInputSchema: classpath:schemas/saga-transfer-input-schema.json` 引擎級 JSON Schema 驗證(`start: CallA16229State`,入口即呼叫、無驗證 state) | dataInputSchema **停用改 jq**:workflow 內 ValidateInput 五條件驗證;schema 檔轉為「文件化契約」(規則與 runtime 同步);失敗走 InjectValidationFailedStatus → FinalAuditAndEnd 共用模板,HTTP 400 由 WorkflowStatusFilter 改寫 |
| 錯誤兜底 | **無 errors/onErrors**:任何引擎層例外直接讓實例 ERROR,對帳紀錄缺席(timeout 對帳缺口風險的根源) | errors.platformError + **每個 operation/switch state 掛 onErrors**,全部收斂到 FinalAuditAndEnd |
| switch 慣例 | 正反條件並列(如 `code != "100"` 明列失敗分支)+ default | P2-1:僅正向條件 + 安全 default;DecideByEvaluation 的 onErrors 與 default 同向全回沖 |
| 輸出契約 | **每個終點各自維護** stateDataFilter.output(SuccessState/FailedState/RollbackA16229/RollbackA16229Only 各一份,欄位形狀互異;RollbackA16229Only 不含 a16220Rollback) | **統一終點單一模板**:status/message/AMT/四 result(null 收斂)/auditSaved/opsAlertRaised,鍵集合恆定 |
| 對帳落地 | 無 AuditLog 呼叫(流程結束即無紀錄) | FinalAuditAndEnd 必寫 workflow_execution_log,auditSaved 揭露寫入結果 |
| 運維告警 | 無 | OpsAlertService 條件告警,ROLLBACK_FAILED → [OPS-ALERT],opsAlertRaised 揭露 |
| metadata 標籤 | 無 | domain/pattern/criticality/owner 四標籤 |
| HTTP 對外語義 | 一律 200(UnwrapResponseFilter 強制),失敗只能靠 body.status 判讀 | status-rewrite:VALIDATION_FAILED→400、ROLLBACK_FAILED→409(配置驅動) |

v15 description 中記載的關鍵歷史教訓(v14 改動):functions 曾從 `type: rest`(OpenAPI addon)改為 `type: custom`(SagaApiService),原因是「SonataFlow OpenAPI addon 4xx/5xx 寫死拋例外 + v0.8 onErrors 攔不到」——這也是 saga2 選擇 custom service + 服務層吞例外回標準化 body 架構的遠因。

兩代共通不變的部分:Saga LIFO 回沖順序(A16220 失敗只回沖 A16229;AMT>500 先回沖 A16220 再回沖 A16229)、EC 參數語義(false=扣款/true=回沖)、code=="100" 成功判讀、workflowExecTimeout PT5M。

---

## 11. 常見錯誤

| # | 錯誤 | 後果 | 正確做法 |
|---|------|------|----------|
| 1 | error 定義漏寫 `code` | Kogito codegen 靜默忽略該定義,onErrors 全部失效 | 每個 error 都補 `code:`(見 §4.1) |
| 2 | jq 用 `test("regex")` | jackson-jq 不支援,runtime 求值錯誤 | 用 `match(...) // false == false` 慣用法(§5.3) |
| 3 | 對可能缺失的欄位直接 `match()` | null 求值拋例外,條件被跳過反而繞過驗證 | 先 `// ""`(或 `// {}`)收斂再判斷(§5.3) |
| 4 | actionExecTimeout/stateExecTimeout 設得小於 MyOpenApiService HTTP 逾時(10s) | 引擎先中斷,拿不到標準化錯誤 body,分流與稽核退化 | 保持 10s < PT15S < PT30S < PT5M;啟用傳輸重試時同步放大(§3.5) |
| 5 | 手改 `distribution/transfer-app/src/main/resources/` 下的 .sw.yaml/schema/properties 副本 | 下次建置被 canonical 版本覆蓋 | 只改 `domain-transfer/transfer-workflow/src/main/resources/`,distribution 是建置同步副本(單一事實來原則) |
| 6 | 以為 HTTP 4xx/5xx 會觸發 onErrors | 誤判錯誤路徑;實際服務層吞例外回 code=999 | onErrors 只攔平台層例外;業務/HTTP 失敗由 Check* switch 依 `.code` 分流(§4.1) |
| 7 | Inject 的 finalMessage 與 ValidateInput 規則不同步 | 回應文字誤導呼叫端,測試 [11] 斷言失敗 | 兩處一起改;以測試逐字斷言鎖住(§7) |
| 8 | 新終點自創輸出欄位形狀 | 消費端(tester/CSV/測試)解析破裂 | 全部走 FinalAuditAndEnd 統一模板,缺資料用 `// null`/`// false`(§8.4) |
| 9 | 在 FinalAuditAndEnd 掛 onErrors 或換成會拋例外的收尾服務 | 收尾失敗無人接,對帳缺口重現 | 維持「服務層吞例外+回布林」契約(auditSaved/opsAlertRaised 浮現結果)(§8.2-8.3) |
| 10 | 忘記 EC=true 才會觸發 RBFAIL 哨兵 | 一般交易誤用帳號 RBFAIL 卻測不到 401 | 哨兵條件是 `request.EC && "RBFAIL".equals(account)`(A16229Resource#execute / A16220Resource#execute) |

---

## 相關文件

- [NEW-WORKFLOW-GUIDE](NEW-WORKFLOW-GUIDE.md):把本樣板落成新 workflow 的 8 步 SOP。
- [WORKFLOW-COOKBOOK](WORKFLOW-COOKBOOK.md):12 道模式配方速查。
- [../04-reference/SERVICE-REFERENCE.md](../04-reference/SERVICE-REFERENCE.md):MyOpenApiService/AuditLogService/OpsAlertService/SagaApiService 完整手冊。
- [../04-reference/CONFIG-REFERENCE.md](../04-reference/CONFIG-REFERENCE.md):kogito.sw.*、status-rewrite、重試參數。
- [../02-architecture/OBSERVABILITY.md](../02-architecture/OBSERVABILITY.md):errorType/HTTP-AUDIT/OPS-ALERT/GraphQL 軌跡。
