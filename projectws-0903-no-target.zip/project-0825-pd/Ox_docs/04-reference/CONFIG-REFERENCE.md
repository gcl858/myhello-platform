# CONFIG-REFERENCE — myhello-platform 配置完全手冊

> 本文為 Ox_docs 第 04 冊《配置參考》,100% 基於原始碼與 application.properties 撰寫,涵蓋:
>
> | 主題 | 一句話 |
> |------|--------|
> | [配置載入優先序](#1-配置載入優先序) | -D(400) > OS env(300) > PlatformConfigSource(250) > application.properties(100) |
> | [transfer-app 參數](#2-transfer-app-applicationproperties-逐段解析) | :8080 主應用逐段逐參數表 |
> | [reconciliation-app 差異](#3-reconciliationapp-與-transfer-app-差異表) | :8090 唯讀對帳 app |
> | [platform-data-index base](#4-platform-data-index-base-properties被雙-app-繼承) | SQLite/Data Index/OIDC 全關的基礎層 |
> | [kogito.sw.* 家族](#5-kogitosw--家族總表) | timeout / transport-retry / functions base_url / openapi base_url |
> | [MYHELLO_* 環境變數](#6-myhello_data_dirmyhello_logs_dir-與-platformpaths) | 資料/日誌目錄解析與 findProjectRoot |
>
> 術語定義見 [../README.md](../README.md);資料庫面(WAL、datasource 行為)詳見
> [DATABASE-REFERENCE.md](DATABASE-REFERENCE.md);平台模組見 [../05-platform/PLATFORM-MODULES.md](../05-platform/PLATFORM-MODULES.md);
> 部署與啟動見 [../01-getting-started/GETTING-STARTED.md](../01-getting-started/GETTING-STARTED.md)。
> 引用慣例:`類別#方法` 或檔名;行號僅輔助且可能隨版本變動。

---

## 目錄

- [1. 配置載入優先序](#1-配置載入優先序)
  - [1.1 Ordinal 優序圖](#11-ordinal-優序圖)
  - [1.2 PlatformConfigSource 詳解](#12-platformconfigsource-詳解)
  - [1.3 MYHELLO_* 的三重注入路徑(易誤解點)](#13-myhello_-的三重注入路徑易誤解點)
- [2. transfer-app application.properties 逐段解析](#2-transfer-app-applicationproperties-逐段解析)
  - [2.1 HTTP](#21-http) · [2.2 Logging](#22-logging) · [2.3 OpenAPI Filter / CORS](#23-openapi-filter--cors)
  - [2.4 Hibernate ORM](#24-hibernate-orm) · [2.5 kogito.sw.functions](#25-kogitoswfunctions)
  - [2.6 platform.status-rewrite.*](#26-platformstatus-rewrite)
  - [2.7 TLS / Proxy(DEV-ONLY)](#27-tls--proxydev-only)
  - [2.8 %test profile](#28-test-profile)
  - [2.9 index-dependency(7 模組)](#29-index-dependency7-模組)
- [3. reconciliation-app 與 transfer-app 差異表](#3-reconciliationapp-與-transfer-app-差異表)
- [4. platform-data-index base properties(被雙 app 繼承)](#4-platform-data-index-base-properties被雙-app-繼承)
- [5. kogito.sw.* 家族總表](#5-kogitosw--家族總表)
- [6. MYHELLO_DATA_DIR / MYHELLO_LOGS_DIR 與 PlatformPaths](#6-myhello_data_dirmyhello_logs_dir-與-platformpaths)
- [7. 常見錯誤](#7-常見錯誤)

---

## 1. 配置載入優先序

### 1.1 Ordinal 優序圖

MicroProfile Config 以 ordinal 決定同名 key 的勝者(**數字大者贏**)。本平台涉及四個 source:

```mermaid
flowchart TD
    subgraph ORD["ordinal 由高到低(高者覆寫低者)"]
        D["JVM 系統參數 -D<br/>ordinal=400<br/>最高(MicroProfile 規格慣例)<br/>例: -DMYHELLO_DATA_DIR=/data"]
        E["OS 環境變數<br/>ordinal=300<br/>例: export MYHELLO_DATA_DIR=/data"]
        P["PlatformConfigSource<br/>ordinal=250<br/>(PlatformConfigSource#getOrdinal)<br/>注入 MYHELLO_DATA_DIR / MYHELLO_LOGS_DIR"]
        A["application.properties<br/>ordinal=100<br/>(Quarkus 對 MP microprofile-config.properties<br/>同位階之預設)"]
    end
    D -->|"覆寫"| E -->|"覆寫"| P -->|"覆寫"| A
```

| Source | ordinal | 依據 |
|--------|---------|------|
| JVM `-D` 系統參數 | 400 | MicroProfile Config 規格預設;`PlatformConfigSource` 類 Javadoc 同此口徑 |
| OS 環境變數 | 300 | MicroProfile Config 規格預設;同上 |
| `PlatformConfigSource`(自訂) | **250**(hardcode 於 `PlatformConfigSource#getOrdinal`) | 高於 application.properties(100)、低於 env(300)與 `-D`(400),「保留外部覆寫能力」(Javadoc 原意) |
| `application.properties` | 100 | Quarkus/MP 預設 |

實務含義:

1. **容器掛 volume** → 設 OS env `MYHELLO_DATA_DIR`,300 打敗一切自動推導。
2. **本機臨時實驗** → `-D` 最快且不動檔案。
3. **都不設** → `PlatformConfigSource` 兜底注入專案根目錄下的 `data/`、`logs/` 絕對路徑,
   讓 `application.properties` 裡 `${MYHELLO_DATA_DIR:data}` 的 placeholder 必有值可解。
4. `%test.*` 等 Quarkus profile 前綴是在「同一 source 內」按啟用 profile 取值,**不改變**上述跨 source 優序。

### 1.2 PlatformConfigSource 詳解

原始碼:`platform-data-index/src/main/java/org/acme/platform/dataindex/PlatformConfigSource.java`
(`implements org.eclipse.microprofile.config.spi.ConfigSource`)

| 項目 | 內容 |
|------|------|
| NAME | `"PlatformConfigSource"`(`PlatformConfigSource#getName`) |
| getOrdinal | 固定 `250` |
| 提供的 key | 僅兩個:`MYHELLO_DATA_DIR`、`MYHELLO_LOGS_DIR`(常數定義於 `PlatformPaths#DATA_DIR_ENV/#LOGS_DIR_ENV`) |
| 建構子副作用 | 呼叫 `PlatformPaths#ensureDataDirectory()` 與 `#ensureLogsDirectory()`——在 DataSource 初始化**之前**就把 data/logs 實體目錄建好(mkdirs),再把絕對路徑放進 property map |
| 失敗行為 | 建目錄丟例外時 catch 住靜默降級(Javadoc: fallback gracefully if filesystem permissions prevent mkdir)——目錄建不出來不會擋啟動,但後續寫檔會再失敗 |
| 註冊方式 | SPI:`platform-data-index/src/main/resources/META-INF/services/org.eclipse.microprofile.config.spi.ConfigSource` 內容即此類 FQN(ServiceLoader 標準機制) |
| 打包範圍 | platform-data-index 被 distribution 兩個 app 共同依賴 → **兩 app 都自動獲得此 source** |

### 1.3 MYHELLO_* 的三重注入路徑(易誤解點)

同一個 `MYHELLO_DATA_DIR` 其實有三條供值路徑,全部指向同一處,故行為一致但機制不同:

| 路徑 | 觸發條件 | 生效 source(ordinal) | 依據 |
|------|----------|------------------------|------|
| 使用者顯式設定 | env var 或 `-D` 已存在 | env=300 或 sysprop=400 | `PlatformPaths` static init 與 `PlatformConfigSource` 都會讓位 |
| PlatformPaths 自動補 | env 與 sysprop **皆未設** | System Property(**400**) | `PlatformPaths` static initializer:`System.setProperty(DATA_DIR_ENV, findProjectRoot()/data)` |
| PlatformConfigSource 兜底 | ConfigSource 被載入即執行 | 自訂 source(**250**) | 建構子 put 絕對路徑 |

> 推論:只要 platform-common 有被類別載入(static init)或 platform-data-index 在 classpath(SPI),
> `${MYHELLO_DATA_DIR:data}` placeholder 幾乎不可能落到字面預設 `data`;
> 字面預設只是最後防線。三者路徑計算同源(`findProjectRoot`),不會互相矛盾。

---

## 2. transfer-app application.properties 逐段解析

原始檔:`distribution/transfer-app/src/main/resources/application.properties`
(建置同步副本性質——canonical 分散在各 domain/platform 模組,見 §4 與 README 術語表「單一事實來源」;
本檔以相同 key **覆寫** platform-data-index base,§4)

### 2.1 HTTP

| 參數 | 值 | 說明 |
|------|-----|------|
| `quarkus.http.port` | `8080` | 正式 HTTP port;reconciliation-app 用 8090 錯開 |
| `quarkus.http.host` | `0.0.0.0` | 監聽所有介面(容器可用) |

### 2.2 Logging

| 參數 | 值 | 說明 |
|------|-----|------|
| `quarkus.log.file.enabled` | `true` | 啟用檔案日誌 |
| `quarkus.log.file.path` | `${MYHELLO_LOGS_DIR:logs}/transfer-app.log` | 目錄由 MYHELLO_LOGS_DIR 解析(§6) |
| `quarkus.log.file.rotation.max-file-size` | `10M` | 單檔上限 10 MB |
| `quarkus.log.file.rotation.max-backup-index` | `10` | 最多保留 10 個輪替備份 → 總量約 ≤110 MB |
| `quarkus.log.file.format` | `%d{yyyy-MM-dd HH:mm:ss,SSS} %-5p [%c{3.}] (%t) %s%e%n` | 時間 級別 [短類名] (執行緒) 訊息 例外 |
| `quarkus.log.file.rotation.file-suffix` | `.yyyyMMdd_HHmm` | 歷史檔名精確至分 |
| `quarkus.log.file.rotation.rotate-on-boot` | `true` | 重啟即歸檔舊檔 |

### 2.3 OpenAPI Filter / CORS

| 參數 | 值 | 說明 |
|------|-----|------|
| `mp.openapi.filter` | `com.example.platform.security.SonataFlowSecurityConfig$SwaggerFilter` | Swagger UI/OpenAPI 文件過濾器(platform-security);隱藏敏感端點,詳 [../05-platform/PLATFORM-MODULES.md](../05-platform/PLATFORM-MODULES.md) |
| `quarkus.http.cors.enabled` | `false` | CORS 關閉(單體部署,瀏覽器直連 UI 頁面同源) |

### 2.4 Hibernate ORM

| 參數 | 值 | 說明 |
|------|-----|------|
| `quarkus.hibernate-orm.database.generation` | `none` | schema 全權交給 Flyway 體系(DATABASE-REFERENCE §4) |
| `quarkus.hibernate-orm.schema-management.strategy` | `none` | 同上,雙保險 |
| `quarkus.hibernate-orm.validate-in-dev-mode` | `false` | dev mode 也不校驗(xerial metadata bug,DATABASE-REFERENCE §7.3) |

### 2.5 kogito.sw.functions

SonataFlow function 位址覆寫(由 `MyOpenApiService#doResolveBaseUrl` 規則 1/2 消費,§5):

| 參數 | 值 | 說明 |
|------|-----|------|
| `kogito.sw.functions.callAaaService.scheme` | `https` | 展示用 https endpoint |
| `kogito.sw.functions.callAaaService.host` | `apimgw-uat.tttkkkk.com.tw` | UAT API GW 主機 |
| `kogito.sw.functions.callAaaService.port` | `443` | 標準 https |
| `kogito.sw.functions.fetchHealthData.protocol` | `http` | rest-workflow 範例用 |
| `kogito.sw.functions.fetchHealthData.host` | `localhost` | 本機 self-call |
| `kogito.sw.functions.fetchHealthData.port` | `8080` | 即 transfer-app 自己 |
| `kogito.sw.functions.callApiViaOpenAPI.protocol` | `http` | **saga2 主路徑**:mock API 也掛在本機 |
| `kogito.sw.functions.callApiViaOpenAPI.host` | `localhost` | |
| `kogito.sw.functions.callApiViaOpenAPI.port` | `8080` | transfer-app 自己(mock API 同 app) |

> 注意鍵名差異:callAaaService 用 `scheme`,另兩個用 `protocol` ——
> `MyOpenApiService` 兩種都接受(`.or(() -> …)` fallback),但新 workflow 建議統一用 `protocol`。

### 2.6 platform.status-rewrite.*

WorkflowStatusFilter 配置化改寫(新增 workflow 只需在此註冊,免改 Java):

| 參數 | 值 | 說明 |
|------|-----|------|
| `platform.status-rewrite.workflows` | `saga2-transfer-workflow` | 逗號分隔白名單;比對請求路徑第一段(workflow id) |
| `platform.status-rewrite.mapping` | `VALIDATION_FAILED=400,ROLLBACK_FAILED=409` | 格式 `STATUS=CODE`;慣例:VALIDATION_FAILED=400(客戶端輸入錯)、ROLLBACK_FAILED=409(需人工介入);SUCCESS/FAILED/ROLLED_BACK 不列=保持引擎原碼 200 |

背景與鏈路詳 [../02-architecture/OBSERVABILITY.md](../02-architecture/OBSERVABILITY.md)。

### 2.7 TLS / Proxy(DEV-ONLY)

| 參數 | 值 | 說明 |
|------|-----|------|
| `quarkus.tls.trust-all` | `true` | ⚠️ **DEV-ONLY(P2-5)**:信任所有 TLS 憑證,限本機/UAT 聯調。**生產必移除**,改配正式 truststore(`quarkus.tls.*`),否則中間人攻擊風險(原檔註解原文警示) |
| `system.property.http.nonProxyHosts` | `localhost\|127.0.0.1\|*.tttkkkk.com.tw` | JVM 系統屬性形式注入;內網網域不走 proxy |
| `system.property.https.nonProxyHosts` | 同上 | 同上(https 版) |

### 2.8 %test profile

| 參數 | 值 | 說明 |
|------|-----|------|
| `%test.quarkus.http.test-port` | `8080` | 測試期 self-call 可命中(原檔註解:「將測試 port 改回 8080」;與生效值一致) |
| `%test.quarkus.datasource.jdbc.url` | `jdbc:sqlite:target/test-reconciliation.db` | 測試用獨立 db,不污染正式 reconciliation.db |
| `%test.quarkus.oidc.enabled` / `%test.quarkus.oidc.tenant-enabled` | `false` | 測試關 OIDC(base 已全關,雙保險) |
| `%test.quarkus.oidc.auth-server-url` | `none` | 同上 |
| `%test.quarkus.keycloak.devservices.enabled` | `false` | 防 Dev Services 自動拉 Keycloak 容器 |

### 2.9 index-dependency(7 模組)

Quarkus Jandex 索引宣告(讓反射/CDI 能掃到依賴 jar 內元件),全部 `group-id=org.acme.platform`:

| key 片段 | artifact-id |
|----------|-------------|
| `quarkus.index-dependency.platform-common` | platform-common |
| `quarkus.index-dependency.platform-security` | platform-security |
| `quarkus.index-dependency.platform-data-index` | platform-data-index |
| `quarkus.index-dependency.transfer-mock` | transfer-mock |
| `quarkus.index-dependency.transfer-workflow` | transfer-workflow |
| `quarkus.index-dependency.transfer-samples` | transfer-samples |
| `quarkus.index-dependency.reconciliation-api` | reconciliation-api |

另有**已註解**的傳輸重試參數(說明文字為官方口徑,生效值見 §5):

```properties
# kogito.sw.openapi.transport-retry.max-attempts=2   ← 註解中示例
# kogito.sw.openapi.transport-retry.delay-ms=500     ← 註解中示例
```

---

## 3. reconciliation-app 與 transfer-app 差異表

原始檔:`distribution/reconciliation-app/src/main/resources/application.properties`

| 面向 | transfer-app(:8080) | reconciliation-app(:8090) | 備註 |
|------|----------------------|----------------------------|------|
| `quarkus.http.port` | 8080 | **8090** | ⚠️ 原檔第 9 行行內註解仍寫「預設改用 8081」為**過時殘留**,以生效值 `8090` 為準(已核對 §2.1 實際 key) |
| `quarkus.http.host` | 0.0.0.0 | 0.0.0.0 | 相同 |
| datasource jdbc.url | (繼承 base,§4) | 明列 `jdbc:sqlite:${MYHELLO_DATA_DIR:data}/reconciliation.db` | 與 base 同值,顯式化便於外部覆寫 |
| `quarkus.datasource.jdbc.read-only` | 無(讀寫) | **true**(%test 下 false) | 對帳 app 唯讀;fallback 暗門見 DATABASE-REFERENCE §6.3 |
| log path | `${MYHELLO_LOGS_DIR:logs}/transfer-app.log` | `${MYHELLO_LOGS_DIR:logs}/reconciliation-app.log` | 各自檔案 |
| rotation 大小/份數 | **10M × 10** | **20M × 14** | 對帳查詢量大,保留更久 |
| format / suffix / rotate-on-boot | 相同 | 相同 | |
| mp.openapi.filter / CORS / Hibernate none×3 | 相同 | 相同 | |
| kogito.sw.functions 三組 | 有 | **無** | 對帳 app 不外呼 |
| platform.status-rewrite.* | 有 | **無** | 改寫只針對轉帳啟動端點 |
| tls.trust-all + nonProxyHosts | 有(DEV-ONLY) | **無** | 對帳 app 不出網 |
| `%test.quarkus.http.test-port` | 8080 | **8081** | 與 transfer 測試埠錯開,可並行跑測試 |
| `%test` 其餘(url/oidc×3/keycloak) | 相同 | 多一條 `%test…read-only=false` | 測試需寫入 test db |
| index-dependency | 7 模組(§2.9) | **4 模組**:platform-common、platform-security、platform-data-index、reconciliation-api | 不含 transfer 三模組 |

---

## 4. platform-data-index base properties(被雙 app 繼承)

原始檔:`platform-data-index/src/main/resources/application.properties`
任何組裝 platform-data-index 的 distribution 模組自動繼承;同名 key 可在其自身 application.properties 覆寫。

### 4.1 Datasource

| 參數 | 值 | 說明 |
|------|-----|------|
| `quarkus.datasource.db-kind` | `other` | Quarkus 3.27.x 無內建 sqlite kind(原檔註解) |
| `quarkus.datasource.jdbc.driver` | `org.sqlite.JDBC` | 必須明確指定——修補版 Kogito SQLite addon 期待此 driver |
| `quarkus.datasource.jdbc.url` | `jdbc:sqlite:${MYHELLO_DATA_DIR:data}/reconciliation.db` | MYHELLO_DATA_DIR 優先,fallback 字面 `data/` |
| `quarkus.datasource.jdbc.max-size` | `1` | 連線池上限 1(SQLite 鎖策略,DATABASE-REFERENCE §6.2) |
| `additional-jdbc-properties.foreign_keys` | `true` | inline FK 生效前提(V1.32.0 檔頭要求) |
| `additional-jdbc-properties.journal_mode` | `WAL` | 與程式端 PRAGMA 雙保險 |
| `additional-jdbc-properties.synchronous` | `NORMAL` | 同上 |

### 4.2 Hibernate ORM

| 參數 | 值 | 說明 |
|------|-----|------|
| `quarkus.hibernate-orm.dialect` | `org.acme.platform.dataindex.KogitoSQLiteDialect` | 自訂 dialect(修 timestamp bug,DATABASE-REFERENCE §7) |
| `quarkus.hibernate-orm.jdbc.timezone` | `UTC` | 統一時間口徑 |
| `quarkus.hibernate-orm.physical-naming-strategy` | `org.hibernate.boot.model.naming.CamelCaseToUnderscoresNamingStrategy` | 駝峰→蛇形 |
| `database.generation` / `schema-management.strategy` / `validate-in-dev-mode` | `none` / `none` / `false` | 原 Kogito SQLite 擴充預設 validate,但 Hibernate 6.x 解析 xerial metadata 會在 `AbstractInformationExtractorImpl.columnInformation:651` 丟 NoSuchElementException;Flyway 是 schema 唯一來源,關閉消除誤報(原檔長註解自述) |

### 4.3 Flyway / OIDC / Data Index 其他

| 參數 | 值 | 說明 |
|------|-----|------|
| `kie.flyway.enabled` | `true` | 啟用 KIE flyway(Data Index 22 支腳本,DATABASE-REFERENCE §4.3) |
| `quarkus.oidc.enabled` | `false` | 本平台不接 Keycloak(原檔註解) |
| `quarkus.oidc.tenant-enabled` | `false` | 同上 |
| `quarkus.oidc.auth-server-url` | `none` | 同上 |
| `quarkus.keycloak.devservices.enabled` | `false` | 防 Dev Services 拉 Keycloak |
| `quarkus.kogito.data-index.graphql.ui.always-include` | `true` | GraphQL UI 一律打包進來 |
| `kogito.data-index.blocking` | `true` | GraphQL 路由走 blocking(AuditQueryService proxyGraphQL 直打 `/graphql` 的前提之一) |
| `sonataflow.devui.isLocalCluster` | `false` | Dev UI 模式標記 |
| `kogito.data-index.url` | `http://localhost:${quarkus.http.port:8080}` | Data Index 位址跟隨本 app port |
| `quarkus.smallrye-health.management.enabled` | `false` | management endpoint 關閉,用一般 health 即可(原檔註解) |

---

## 5. kogito.sw.* 家族總表

消費者皆為 `MyOpenApiService`(transfer-workflow;手冊詳 [SERVICE-REFERENCE.md §1](SERVICE-REFERENCE.md))。

### 5.1 逾時

| 參數 | 預設 | 覆寫鏈 | 依據 |
|------|------|--------|------|
| `kogito.sw.openapi.timeout-seconds` | 未設 = `10` 秒(程式常數 `DEFAULT_HTTP_TIMEOUT`) | `arguments.timeoutSeconds` > 0 時單次覆寫 → 此參數 → 預設 10s | `MyOpenApiService#resolveTimeout`(經 `ConfigProvider.getConfig().getOptionalValue(..., Long.class)`) |

### 5.2 傳輸層重試(v2.2)

僅對「未取得 HTTP 回應」的傳輸失敗(連線拒絕/逾時等 IOException)指數退避;**已收到回應者(含 4xx/5xx)一律不重試**。

| 參數 | 預設 | 上限/規則 | 依據 |
|------|------|-----------|------|
| `kogito.sw.openapi.transport-retry.max-attempts` | 未設 = `1`(不重試) | 程式硬上限 `MAX_ATTEMPTS_CAP = 5`;單次呼叫 `arguments.retryMaxAttempts` 可覆寫 | 常數 `CFG_RETRY_MAX_ATTEMPTS`(MyOpenApiService) |
| `kogito.sw.openapi.transport-retry.delay-ms` | 未設 = `500` ms | 退避因子固定 `2.0`(`RETRY_BACKOFF_FACTOR`);`arguments.retryDelayMs` 可覆寫 | `CFG_RETRY_DELAY_MS`、`DEFAULT_RETRY_DELAY_MS` |

### 5.3 Base URL 解析四規則(`MyOpenApiService#doResolveBaseUrl`)

| 規則 | 參數 | 例 |
|------|------|----|
| 1(函式整串) | `kogito.sw.functions.<fn>.base_url`,退而 `.url` | `kogito.sw.functions.callAaaService.base_url=https://apimgw-uat.tttkkkk.com.tw` |
| 2(函式三件套) | `kogito.sw.functions.<fn>.protocol`(或 `.scheme`)+ `.host` + `.port`,缺 protocol 補 `http`、缺 port 不加冒號段 | transfer-app 現行三組皆此型(§2.5) |
| 3(規格層) | `kogito.sw.openapi.<specKey>.base_url`,退而 `quarkus.rest-client.<specKey>.url`;**specKey = specPath 把 `/`→`_`、`.`→`_`**(如 `specs/A16229-api.yaml` → `specs_A16229-api_yaml`) | 適合同一 spec 多 function 共用位址 |
| 4(spec 內建) | OpenAPI YAML `servers[0].url` | 最後手段;全無則丟 IllegalStateException(錯誤訊息列出應補的 key) |

四規則依序嘗試,任一命中即回;結果按 `functionName#specPath` 快取於 `baseUrlCache`。

### 5.4 家族速查表

| Key | 出現位置 | 生效值/預設 | 消費者 |
|-----|----------|--------------|--------|
| `kogito.sw.functions.callAaaService.{scheme,host,port}` | transfer-app | https / apimgw-uat.tttkkkk.com.tw / 443 | MyOpenApiService(規則 2) |
| `kogito.sw.functions.fetchHealthData.{protocol,host,port}` | transfer-app | http / localhost / 8080 | 同上 |
| `kogito.sw.functions.callApiViaOpenAPI.{protocol,host,port}` | transfer-app | http / localhost / 8080 | 同上(saga2 主路徑) |
| `kogito.sw.openapi.<specKey>.base_url` | 未設(靠規則 2/4) | — | MyOpenApiService(規則 3) |
| `kogito.sw.openapi.timeout-seconds` | 未設 | 10s | `#resolveTimeout` |
| `kogito.sw.openapi.transport-retry.max-attempts` | 未設(transfer-app 有註解示例 `2`) | 1(cap 5) | 重試引擎 |
| `kogito.sw.openapi.transport-retry.delay-ms` | 未設(transfer-app 有註解示例 `500`) | 500(factor 2.0) | 重試引擎 |

---

## 6. MYHELLO_DATA_DIR / MYHELLO_LOGS_DIR 與 PlatformPaths

原始碼:`platform-common/src/main/java/com/example/platform/common/PlatformPaths.java`(pure Java,無 framework 依賴)

### 6.1 兩個環境變數

| 變數 | 常數(`PlatformPaths`) | 缺省值 | 用途 |
|------|--------------------------|--------|------|
| `MYHELLO_DATA_DIR` | `DATA_DIR_ENV` | `<專案根>/data`(static init 自動補) | reconciliation.db、CSV 匯出、測試 db 以外所有落地資料 |
| `MYHELLO_LOGS_DIR` | `LOGS_DIR_ENV` | `<專案根>/logs` | transfer-app.log / reconciliation-app.log |

### 6.2 解析順序(`PlatformPaths#dataDirectory` / `#logsDirectory`,兩方法同構)

1. OS 環境變數(非空白即採用,轉絕對路徑+normalize);
2. System Property 同名 key;
3. `findProjectRoot()` + 預設目錄名。

static initializer(類載入即執行):若 env 與 sysprop **都沒有**,把「專案根/data」「專案根/logs」
寫成 System Property——這就是 §1.3 的第二條注入路徑。

### 6.3 findProjectRoot(`PlatformPaths#findProjectRoot`)

從 `user.dir` 起**逐層向上**找第一個滿足以下任一條件的目錄:

- 存在 `.git`;或
- 同時存在 `pom.xml` **與** `distribution` 子目錄(避免誤判一般 Maven 專案)。

找不到就返回 `user.dir` 原值(降級不報錯)。因此:在 `distribution/transfer-app/` 目錄直接啟動 jar,
也會正確定位到多模組根目錄。

### 6.4 目錄建立與 Windows 相容

| 方法 | 行為 |
|------|------|
| `ensureDataDirectory` / `ensureLogsDirectory` | `mkdirs` + 競爭二次 exists 檢查;失敗拋 `UncheckedIOException`(被 PlatformConfigSource 吞掉,§1.2) |
| `dataFile(name)` / `logFile(name)` | 目錄.resolve(檔名),不建目錄 |
| `sqliteUrl(fileName)` | `"jdbc:sqlite:" + 絕對路徑`;以 `File` API 產生字串,Windows 自帶 `\`、Linux `/`(Javadoc 示例:Linux `jdbc:sqlite:/opt/app/data/reconciliation.db`、Windows `jdbc:sqlite:D:\app\data\reconciliation.db`) |
| `normalizeClasspath(input)` | `\`→`/`、去重複斜線、去頭尾 `/`——Classpath 資源一律 forward slash(Java 規格);`MyOpenApiService#callOpenApi` 解析 schemaRef 時必經此正規化 |

---

## 7. 常見錯誤

| # | 症狀 | 原因 | 解法 |
|---|------|------|------|
| 1 | 改了 application.properties 卻沒效果 | 被更高 ordinal 覆寫(-D 400 > env 300 > PlatformConfigSource 250 > 檔案 100) | 用 §1 圖排查;`quarkus:dev` 啟動 log 會列出 config source |
| 2 | 容器內 db/log 落到奇怪路徑或唯讀 FS 報錯 | 未設 `MYHELLO_DATA_DIR`/`MYHELLO_LOGS_DIR`,findProjectRoot 找不到根退化到 user.dir | 容器務必顯式 export 兩變數指向掛載 volume |
| 3 | reconciliation-app 以為跑在 8081 | 讀到過時行內註解「預設改用 8081」;**生效值是 `quarkus.http.port=8090`**,8081 只是 %test test-port | 以本文 §3 表為準 |
| 4 | 測試期間 self-call connection refused(transfer-app) | %test 下 port 走 `test-port=8080`,若外部又強制改 port 會打不到 | 保持 %test 預設,勿覆寫 |
| 5 | 想調大連線池提升查詢吞吐 | `max-size=1` 是刻意設計(SQLite 單寫者/WAL 鎖策略),調大反致 database is locked | 維持 1;效能問題走索引/limit 優化(DATABASE-REFERENCE §5) |
| 6 | 生產環境沿用 trust-all=true | DEV-ONLY 配置未移除,中間人風險(原檔註解 P2-5) | 上線前刪除該行並配 `quarkus.tls.*` truststore |
| 7 | 新增 mock/spec 後 GraphQL/UI 掃不到 bean | 新模組沒加進 `quarkus.index-dependency.*` | transfer-app 7 條/recon 4 條照抄補上(§2.9/§3) |
| 8 | `kogito.sw.functions.X.scheme` 與 `protocol` 混用困惑 | 兩鍵都被接受(protocol 優先 or-fallback scheme),但混用難維護 | 新配置統一用 `protocol`(§2.5) |
| 9 | 規則 3 的 specKey 寫錯不生效還不報錯 | specKey 是機械轉換(`/`→`_`、`.`→`_`),手寫常拼錯;且四規則會默默落到規則 4 | 直接印錯誤訊息中的提示 key(`IllegalStateException` 會列出正確 specKey)(§5.3) |
