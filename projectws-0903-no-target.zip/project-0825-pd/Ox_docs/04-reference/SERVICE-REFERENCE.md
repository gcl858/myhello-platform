# SERVICE-REFERENCE — myhello-platform 四大服務完整手冊

> 本文為 Ox_docs 第 04 冊《服務參考》,100% 基於原始碼撰寫,涵蓋 workflow 開發者最常接觸的四個服務:
>
> | 服務 | 模組 | 定位 |
> |------|------|------|
> | [MyOpenApiService](#1-myopenapiservice--通用-openapi-動態呼叫服務) | transfer-workflow | 通用 OpenAPI 動態呼叫(saga2 主路徑) |
> | [AuditLogService](#2-auditlogservice--對帳紀錄寫入與-db-初始化) | reconciliation-api | 對帳紀錄寫入 + SQLite 初始化與遷移 |
> | [OpsAlertService](#3-opsalertservice--運維條件告警) | reconciliation-api | ROLLBACK_FAILED 條件告警 |
> | [SagaApiService](#4-sagaapiservice--v15-直打-http-客戶端) | transfer-workflow | 舊版 saga v15 直打 HTTP 客戶端 |
>
> 術語定義見 [../README.md](../README.md);workflow 端如何呼叫這些服務見 [../03-workflow-dev-guide/SAGA2-TEMPLATE-DEEP-DIVE.md](../03-workflow-dev-guide/SAGA2-TEMPLATE-DEEP-DIVE.md);
> API 對外契約見 [REST-API-REFERENCE.md](REST-API-REFERENCE.md)。
> 引用慣例:`類別#方法`;行號僅輔助且可能隨版本變動。

---

## 目錄

- [1. MyOpenApiService](#1-myopenapiservice--通用-openapi-動態呼叫服務)
  - [1.1 定位與設計特點](#11-定位與設計特點)
  - [1.2 公開方法簽名表(6 個)](#12-公開方法簽名表6-個)
  - [1.3 schemaRef 格式與解析](#13-schemaref-格式與解析)
  - [1.4 四層快取](#14-四層快取)
  - [1.5 Base URL 解析四規則(優先序圖)](#15-base-url-解析四規則優先序圖)
  - [1.6 Timeout 解析鏈](#16-timeout-解析鏈)
  - [1.7 傳輸層重試機制(v2.2)](#17-傳輸層重試機制v22)
  - [1.8 errorType 判定流程(normalizeResponse)](#18-errortype-判定流程normalizeresponse)
  - [1.9 URL 組裝:路徑參數替換與 Query String](#19-url-組裝路徑參數替換與-query-string)
  - [1.10 Headers 與 HTTP 方法支援](#110-headers-與-http-方法支援)
- [2. AuditLogService](#2-auditlogservice--對帳紀錄寫入與-db-初始化)
  - [2.1 saveLog 四種多載](#21-savelog-四種多載)
  - [2.2 doSaveLog 行為細節](#22-dosavelog-行為細節)
  - [2.3 initDatabase 啟動初始化](#23-initdatabase-啟動初始化)
  - [2.4 DatabaseMigrationRunner 概要](#24-databasemigrationrunner-概要)
  - [2.5 V1.0.0 遷移腳本(workflow_execution_log)](#25-v100-遷移腳本workflow_execution_log)
- [3. OpsAlertService](#3-opsalertservice--運維條件告警)
- [4. SagaApiService](#4-sagaapiservice--v15-直打-http-客戶端)
- [5. 新增 workflow 的服務接線 SOP](#5-新增-workflow-的服務接線-sop)
- [6. 常見錯誤](#6-常見錯誤)

---

## 1. MyOpenApiService — 通用 OpenAPI 動態呼叫服務

原始碼:`domain-transfer/transfer-workflow/src/main/java/com/example/transfer/workflow/MyOpenApiService.java`

### 1.1 定位與設計特點

**「給一份 OpenAPI YAML + 一個 operationId,就能發出正確的 HTTP 請求」**——workflow 不必為每個外部 API 手寫 Java 客戶端,只需宣告:

```yaml
functions:
  - name: callApiViaOpenAPI
    operation: 'service:com.example.transfer.workflow.MyOpenApiService::callOpenApi'
    type: custom
```

類別 Javadoc 宣告的能力清單:

1. **完整 HTTP 方法支援**:GET / POST / PUT / DELETE / PATCH / HEAD / OPTIONS
2. **動態路徑與查詢參數**:URL 模板 `{param}` 以 payload 替換;無 body 請求其餘欄位轉 Query String
3. **自訂 Headers**:`arguments.headers`;預設附 `Content-Type: application/json`
4. **彈性逾時**:`kogito.sw.openapi.timeout-seconds` 全域設定、`arguments.timeoutSeconds` 單次覆寫
5. **傳輸層指數退避重試**(v2.2):僅未取得 HTTP 回應者重試
6. **回應標準化**:JSON Object / Array / 204 / 非 JSON 統一整形;保證 `code` 與 `_httpStatus` 存在;失敗附 `errorType`
7. **多層 ConcurrentHashMap 快取**(見 [1.4](#14-四層快取))

### 1.2 公開方法簽名表(6 個)

| # | 簽名 | 用途 | 內部行為 |
|---|------|------|---------|
| 1 | `JsonNode callOpenApi(JsonNode arguments)` | **主進入點**,workflow functionRef 反射呼叫 | 解析 schemaRef → endpoint → Base URL → payload/headers/timeout/retry → 發送;任何例外收斂為 TRANSPORT 錯誤節點 |
| 2 | `JsonNode callOpenApi(String schemaRef, Map<String,Object> payload)` | codegen 反射入口(Map 版) | payload 各 key 攤平進 arguments(排除 schemaRef/functionName 兩個保留鍵)→ 轉呼 #1 |
| 3 | `JsonNode callOpenApi(String schemaRef, JsonNode payload)` | codegen 反射入口(JsonNode 版) | 同 #2 |
| 4 | `JsonNode callOpenApi(String functionName, String schemaRef, Map<String,Object> payload)` | 含 functionName 的 Map 版 | payload 整包放進 `arguments.payload` → 轉呼 #1 |
| 5 | `JsonNode callOpenApi(String functionName, String schemaRef, JsonNode payload)` | 含 functionName 的 JsonNode 版 | 同 #4 |
| 6 | `List<String> resolveRequestFieldNames(String schemaRef)` | 解析 spec requestBody 的欄位名稱清單(供 Payload 過濾等用途) | 走 `$ref` 解析至 `components/schemas`,取 `properties` 的 key;解析失敗回空清單 |

> 注意 #2/#3 與 #4/#5 的差異:前者把 payload **攤平**(欄位直接變 arguments),後者保留在 `arguments.payload` 之下——`extractPayload` 對兩種形狀都支援(`arguments.has("payload")` 優先)。

### 1.3 schemaRef 格式與解析

`callOpenApi(JsonNode)` 第一步即驗證 `schemaRef`(缺漏或空白拋 IllegalArgumentException,最終收斂為 TRANSPORT 回應):

```
格式:'<specPath>#<operationId>'
範例:'specs/A16229-api.yaml#executeA16229'
```

解析規則(`MyOpenApiService#callOpenApi`):

- 必須含 `#`(以第一個 `#` 切分,最多兩段),否則 IllegalArgumentException
- specPath 可帶 `classpath:` 前綴(自動剥除);Windows 反斜線 `\` 由 `PlatformPaths.normalizeClasspath()` 正規化為 `/`
- 以 `<specPath>#<operationId>` 為 key 查 `operationCache`(computeIfAbsent,首次才掃 YAML)

### 1.4 四層快取

四張 `ConcurrentHashMap`,皆以 `computeIfAbsent` 被動載入(首次呼叫解析、之後 O(1)):

| 快取 | Key 粒度 | Value | 填充來源 |
|------|----------|-------|---------|
| `operationCache` | `specPath#operationId` | `ApiEndpoint(path, method, specDeclaredBaseUrl)` record | 掃 paths 下所有 method node 找 operationId;同時記下 spec `servers[0].url` |
| `baseUrlCache` | `functionName#specPath` | String(Base URL) | [Base URL 四規則](#15-base-url-解析四規則優先序圖) |
| `specAstCache` | `specPath` | JsonNode(YAML 根 AST) | classpath 讀檔 + SnakeYAML(yamlMapper.readTree);找不到檔案丟 FileNotFoundException 包成 RuntimeException |
| `requestFieldsCache` | 完整 schemaRef 字串 | List<String>(requestBody properties 名稱) | `resolveRequestFieldNames` 解析 `$ref` 後的 schema |

> 快取永不失效——spec 或設定檔改動後需重啟應用才會生效(熱部署 dev mode 例外)。

### 1.5 Base URL 解析四規則(優先序圖)

核心方法:`MyOpenApiService#doResolveBaseUrl`(經 `resolveBaseUrl` 快取)。四條規則**依序嘗試,第一個命中者勝**:

```mermaid
flowchart TD
    A["需要 Base URL<br/>functionName + specPath"] --> R1{"規則 1<br/>kogito.sw.functions.&lt;fn&gt;.base_url<br/>(或 .url)有值?"}
    R1 -- 有 --> U1["使用函式級 base_url"]
    R1 -- 無 --> R2{"規則 2<br/>kogito.sw.functions.&lt;fn&gt;.host 有值?"}
    R2 -- 有 --> U2["組合 protocol 或 .scheme(預設 http)<br/>+ '://' + host + ':port'(port 可省略)"]
    R2 -- 無 --> R3{"規則 3<br/>kogito.sw.openapi.&lt;specKey&gt;.base_url<br/>(或 quarkus.rest-client.&lt;specKey&gt;.url)"}
    R3 -- 有 --> U3["使用規格級 base_url<br/>specKey = specPath 的 '/'→'_'、'.'→'_'"]
    R3 -- 無 --> R4{"規則 4<br/>spec 內 servers[0].url 有值?"}
    R4 -- 有 --> U4["使用 spec 宣告的 servers[0].url"]
    R4 -- 無 --> X["IllegalStateException<br/>(提示補設定)→ callOpenApi 收斂為<br/>TRANSPORT 錯誤(code=999,_httpStatus=0)"]
```

實際專案配置(`distribution/transfer-app/src/main/resources/application.properties`)走的是**規則 2**:

```properties
kogito.sw.functions.callApiViaOpenAPI.protocol=http
kogito.sw.functions.callApiViaOpenAPI.host=localhost
kogito.sw.functions.callApiViaOpenAPI.port=8080
```

> 設定鍵全表見 [CONFIG-REFERENCE.md](CONFIG-REFERENCE.md)。規則 3 的 specKey 例:`specs/A16229-api.yaml` → `specs_A16229-api_yaml`。

### 1.6 Timeout 解析鏈

`MyOpenApiService#resolveTimeout`,優先序:

1. `arguments.timeoutSeconds`(workflow 單次覆寫;需 > 0 才生效)
2. `kogito.sw.openapi.timeout-seconds`(全域;需 > 0)
3. **預設 `DEFAULT_HTTP_TIMEOUT = Duration.ofSeconds(10)`**

另外,JDK HttpClient 本身的 `connectTimeout` 也固定為 10 秒(`httpClient` 欄位初始化),此值不受上述鏈影響。

### 1.7 傳輸層重試機制(v2.2)

相關常數與設定(`MyOpenApiService` 上方宣告):

| 項目 | 值 / 設定鍵 | 預設 |
|------|------------|------|
| 重試總次數上限(含首次) | `kogito.sw.openapi.transport-retry.max-attempts` | **1(=不重試)**;防呆 cap = **MAX_ATTEMPTS_CAP=5** |
| 首次重試延遲 | `kogito.sw.openapi.transport-retry.delay-ms` | **DEFAULT_RETRY_DELAY_MS = 500ms** |
| 退避因子 | 固定常數 RETRY_BACKOFF_FACTOR | **2.0**(不可配置) |
| 單次覆寫 | `arguments.retryMaxAttempts` / `arguments.retryDelayMs` | —— |

**覆寫鏈**(`resolveRetryMaxAttempts` / `resolveRetryDelayMs`):arguments 值 > 0 優先 → 全域配置 → 預設值;最終 `max(1, min(attempts, 5))` 收斂。

**重試觸發條件**(關鍵語義,`sendWithRetry`):

- **僅 `.exceptionally`(未取得 HTTP 回應)才重試**:連線拒絕、逾時、IO 錯誤——「結果未知」的傳輸失敗
- **已收到 HTTP 回應者一律不重試**(含 4xx/5xx):屬確定結果,交給 normalizeResponse 標準化
- 退避延遲:`backoffMs = delayMs × 2.0^(attempt−1)`(第 1 次重試前 500ms、第 2 次 1000ms、第 3 次 2000ms…,以預設值計)
- 達上限仍失敗 → `transportError(...)`(code=999,errorType=TRANSPORT,_httpStatus=0),並 LOG.error 完整堆疊
- 重試等待期間被中斷(InterruptedException)→ 恢復中斷旗標並回傳 TRANSPORT 錯誤

```mermaid
sequenceDiagram
    participant W as Workflow action
    participant S as MyOpenApiService
    participant H as JDK HttpClient
    W->>S: callOpenApi(arguments)
    S->>H: sendAsync(request)
    alt 取得 HTTP 回應(任何狀態碼)
        H-->>S: HttpResponse
        S->>S: normalizeResponse(不重試)
    else exceptionally(連線拒絕/逾時)
        H-->>S: exception
        loop attempt < maxAttempts(cap 5)
            S->>S: sleep(delayMs × 2.0^(n-1))
            S->>H: resend(request)
        end
        Note over S: 達上限 → transportError<br/>{code:999, errorType:TRANSPORT, _httpStatus:0}
    end
    S-->>W: 標準化 JsonNode
```

### 1.8 errorType 判定流程(normalizeResponse)

`MyOpenApiService#normalizeResponse` 把任何 HTTP 回應整形為統一 JsonNode,並在失敗時附上 `errorType` 分類(成功回應**不含** errorType 欄位,向後相容):

| errorType | 意義 | 結果確定性 |
|-----------|------|-----------|
| `TRANSPORT` | 呼叫未抵達/未完成目標系統(`_httpStatus=0`):連線失敗、逾時、規格解析或組態錯誤 | **未知**(補償判斷前應視為不確定) |
| `BUSINESS` | 目標系統回應 body 自帶業務碼且 `code != "100"`(如 HTTP 403 + `{code:"999"}`) | **確定** |
| `HTTP_4XX` | body **無**業務碼且 400 ≤ HTTP < 500(如 404/405)——請求語法/路由問題 | 確定失敗,重試無效 |
| `HTTP_5XX` | body **無**業務碼且 HTTP ≥ 500 | **未知**(與 TRANSPORT 同屬保守處理) |

```mermaid
flowchart TD
    A["收到 HttpResponse(statusCode, body)"] --> B{"statusCode == 204<br/>或 body 為空?"}
    B -- 是 --> C["code = statusCode>=400 ? 999 : 100<br/>message = 成功(無回傳內容) / HTTP 錯誤"]
    B -- 否 --> D{"body 為 JSON Object?<br/>(以大括號開頭與結尾)"}
    D -- "是(解析成功)" --> E["解析為 ObjectNode"]
    E --> F{"已有 code 欄位?"}
    F -- 有 --> G["businessCodeFromBody = true"]
    F -- 無 --> H["補 code = statusCode>=400 ? 999 : 100"]
    D -- 否 --> I{"body 為 JSON Array?<br/>(以中括號開頭與結尾)"}
    I -- 是 --> J["包裝 data: array<br/>補 code/message"]
    I -- 否 --> K["rawResponse = 原文<br/>補 code/message"]
    D -- "解析拋例外" --> L["rawResponse = body<br/>code=999, message=JSON 解析錯誤"]
    C --> M{"code != '100' ?"}
    G --> M
    H --> M
    J --> M
    K --> M
    L --> M
    M -- 否 --> Z1["成功:不加 errorType<br/>附 _httpStatus"]
    M -- 是 --> N{"businessCodeFromBody?"}
    N -- 是 --> O["errorType = BUSINESS"]
    N -- 否 --> P{"statusCode >= 500 ?"}
    P -- 是 --> Q["errorType = HTTP_5XX"]
    P -- 否 --> R["errorType = HTTP_4XX"]
    O --> S["附 _httpStatus = statusCode"]
    Q --> S
    R --> S
```

**transportError 形狀**(`MyOpenApiService#transportError`,規格解析失敗/組態錯誤/傳輸達上限共用):

```json
{ "code": "999", "message": "API 呼叫錯誤: …", "errorType": "TRANSPORT", "_httpStatus": 0 }
```

> `_httpStatus` 附帶規則:**每個**標準化回應都會補上 `_httpStatus`(成功=實際碼;TRANSPORT=0)。workflow 的 actionDataFilter 樣本即以此欄位收進 state data 供稽核。

### 1.9 URL 組裝:路徑參數替換與 Query String

`MyOpenApiService#buildTargetUrl`:

1. **路徑參數替換**:以 regex `\{([^}]+)\}` 掃描 path 模板;payload 有同名欄位 → URL-encode 後替換並記入 usedAsPathParam;沒有 → 保留 `{param}` 原樣 + LOG.warn
2. **GET/DELETE/HEAD/OPTIONS 轉 Query String**:payload 中未用於 path param 且值非 null 的欄位,全部 `key=value` URL-encode 後串接(`?` 或既有 `?` 後接 `&`)
3. baseUrl 尾端 `/` 自動去除;path 不以 `/` 開頭自動補

POST/PUT/PATCH 則將整個 payload 序列化為 JSON body(payload 空物件時 body 為空字串);DELETE 特例:有 payload 時仍帶 JSON body(`requestBuilder.method("DELETE", …)`),無則標準 DELETE。

### 1.10 Headers 與 HTTP 方法支援

- 預設 header:`Content-Type: application/json`
- 自訂:`arguments.headers`(object;value 為 null 的鍵略過),逐一 `header(k, v)`
- 方法分派(`executeHttpRequestAsync` 的 switch):POST/PUT 用 BodyPublishers.ofString;PATCH 以 method() 指定;GET 固定 noBody;HEAD noBody;其他自訂 method 視 body 是否為空選 ofString/noBody

---

## 2. AuditLogService — 對帳紀錄寫入與 DB 初始化

原始碼:`domain-reconciliation/reconciliation-api/src/main/java/com/example/reconciliation/AuditLogService.java`

定位:通用型 Workflow 執行紀錄與對帳服務——workflow 統一終點呼叫 `saveLog` 寫入 `workflow_execution_log`;啟動時負責 SQLite WAL 初始化與模組化遷移。

### 2.1 saveLog 四種多載

| # | 簽名 | 用途 |
|---|------|------|
| 1 | `JsonNode saveLog(String workflowId, Object businessKey, Object inputData, Object outputData)` | 舊 4 參數相容版,內部轉呼 #2(processInstanceId=null) |
| 2 | `JsonNode saveLog(String workflowId, Object businessKey, Object processInstanceId, Object inputData, Object outputData)` | 多參數進入點(SonataFlow 反射把 arguments key 展開為獨立參數時命中此版;saga2 的 FinalAuditAndEnd 即此形) |
| 3 | `JsonNode saveLog(JsonNode arguments)` | 單一 JsonNode 版;缺 workflowId 時用 `"unknown-workflow"` 兜底;arguments=null 直接回 `{saved:false}` |
| 4 | `JsonNode saveLog(Map<String,Object> arguments)` | 單一 Map 版,valueToTree 後轉呼 #3 |

saga2 workflow 的呼叫形態(functionRef arguments 五個 key,Kogito 展開後命中多載 #2):

```yaml
functionRef:
  refName: recordAuditLog
  arguments:
    workflowId: "saga2-transfer-workflow"
    businessKey: '${ .Account_A }'
    processInstanceId: '${ $WORKFLOW.instanceId }'
    inputData: { Account_A: …, Account_B: …, AMT: … }
    outputData: { status: …, message: …, AMT: …, a16229Result: …, a16220Result: …, a16229Rollback: …, a16220Rollback: … }
```

### 2.2 doSaveLog 行為細節

核心私有方法 `AuditLogService#doSaveLog`(四種多載最終都收斂到此):

1. input/output 任一為 null 時序列化為 `"{}"`;否則 `toString()`(JsonNode)
2. 從 outputData 抽 `status`(預設 `"UNKNOWN"`)**與** `message`(預設空字串)
3. 若尚未初始化(`initialized.get()==false`)先觸發 `initDatabase()`(懶初始化防線)
4. INSERT 七欄:

```sql
INSERT INTO workflow_execution_log
(workflow_id, business_key, process_instance_id, status, message, input_data, output_data)
VALUES (?, ?, ?, ?, ?, ?, ?);
```

5. 成功回:`{ "saved": true, "workflowId": …, "status": … }`
6. **吞例外**:任何失敗僅 LOG.error 完整堆疊,回 `{ "saved": false, "error": "…" }`——**不會讓 workflow 收尾中斷**(因此 saga2 的 FinalAuditAndEnd state 不掛 onErrors;寫入結果經 `auditSaved` 浮現於輸出)

> ⚠️ 注意:outputData 抽取的是 `status`/`message` 欄位。saga2 在呼叫前已把 `finalStatus` 映射為 `outputData.status`,故 DB 的 status 欄存的就是 finalStatus 值(SUCCESS/FAILED/ROLLED_BACK/ROLLBACK_FAILED/VALIDATION_FAILED)。

### 2.3 initDatabase 啟動初始化

入口:`void onStart(@Observes StartupEvent ev)` → `AuditLogService#initDatabase()`。

執行序(原始碼逐條對應):

1. **單次初始化保證**:`AtomicBoolean initialized` + `synchronized(this)` double-check(兩次 `initialized.get()` 檢查)
2. `PlatformPaths.ensureDataDirectory()` 建立 data 目錄(跨平台)
3. 取連線(**DataSource 優先,fallback DriverManager**):`@Inject DataSource` 注入 Agroal 連線池;未注入(單元測試等場景)時以 `DB_URL = PlatformPaths.sqliteUrl("reconciliation.db")` 直連——該 static URL 只看 `MYHELLO_DATA_DIR`,不會跟 `quarkus.datasource.jdbc.url` 同步(fallback 日誌明文警示「資料分裂」風險)
4. **WAL PRAGMA 三行**(高併發設定):

```sql
PRAGMA journal_mode=WAL;
PRAGMA synchronous=NORMAL;
PRAGMA busy_timeout=5000;
```

5. `DatabaseMigrationRunner.runMigrations(conn)` 執行模組化遷移(見下節)
6. 成功才 `initialized.set(true)`;失敗只 LOG.error,**不拋出、不阻斷啟動**(下次 saveLog 會再嘗試)

### 2.4 DatabaseMigrationRunner 概要

原始碼:`…/reconciliation/migration/DatabaseMigrationRunner.java`(純靜態工具類,非 Bean)。

| 特性 | 事實 |
|------|------|
| 掃描位置 | classpath 的 `db/migration/`(支援 file 協議目錄與 jar 內枚舉兩種協議) |
| 檔名規範 | Flyway 式 regex `^V([0-9]+(?:\.[0-9]+)*)__(.+)\.sql$` → V{version}__{description}.sql |
| 排序 | 語意版本比對 `compareVersions`(逐段 int 比較,缺段補 0) |
| 歷史表 | `reconciliation_schema_history`:installed_rank(PK AUTOINCREMENT)/ version(TEXT NOT NULL UNIQUE)/ description / type('SQL')/ script / checksum / installed_by / installed_on / execution_time / success(BOOLEAN NOT NULL) |
| 已套用判定 | 只認 `success = 1` 的版本;已套用者跳過 |
| Checksum | CRC32(內容先做 `\r\n→\n` 正規化再 UTF-8 bytes) |
| SQL 切分 | 依分號切割,正確跳過單引號字串、行註解 `--`、區塊註解 `/* */` 內的分號 |
| fallback 清單 | classpath 枚舉不全的容器環境防護:硬編碼補掃 `V1.0.0__create_workflow_execution_log.sql`、`V1.1.0__create_view_transfer_reconciliation.sql` |
| 失敗語義 | runMigrations 任何例外包成 RuntimeException 拋出(initDatabase 端會 catch 住只記 log) |

### 2.5 V1.0.0 遷移腳本(workflow_execution_log)

檔案:`domain-reconciliation/reconciliation-api/src/main/resources/db/migration/V1.0.0__create_workflow_execution_log.sql`

```sql
CREATE TABLE IF NOT EXISTS workflow_execution_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    workflow_id TEXT,
    business_key TEXT,
    process_instance_id TEXT,
    status TEXT,
    message TEXT,
    input_data TEXT,
    output_data TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_wel_process_instance_id ON workflow_execution_log(process_instance_id);
CREATE INDEX IF NOT EXISTS idx_wel_workflow_business_key ON workflow_execution_log(workflow_id, business_key);
```

七個資料欄(workflow_id ~ output_data)正是 `doSaveLog` INSERT 的對象;全表 schema 與 view 定義見 [DATABASE-REFERENCE.md](DATABASE-REFERENCE.md)。

---

## 3. OpsAlertService — 運維條件告警

原始碼:`domain-reconciliation/reconciliation-api/src/main/java/com/example/reconciliation/OpsAlertService.java`(v2.2 新增)

### 3.1 定位與觸發條件

workflow 統一終點(`FinalAuditAndEnd`)每次收尾都呼叫本服務,但**僅當 `finalStatus == "ROLLBACK_FAILED"`(回沖失敗、需人工介入)時實際觸發**;其餘狀態靜默返回 `raised=false`,不產生日誌噪音。

```java
// 常數(原始碼摘錄)
static final String ALERT_ON_STATUS = "ROLLBACK_FAILED";
private static final Logger ALERT_LOG = LoggerFactory.getLogger("OPS-ALERT");
```

### 3.2 方法簽名與行為

| 簽名 | 說明 |
|------|------|
| `JsonNode raise(String workflowId, Object processInstanceId, Object businessKey, Object finalStatus, Object finalMessage, Map<String,Object> detail)` | **主進入點**(展開參數版)。⚠️ 簽名須與 workflow functionRef arguments 完全對應:Kogito codegen 以精確型別反射查找,參數一律用 Object/Map 接收(jq 運算式產出),內部再轉字串 |
| `JsonNode raise(JsonNode arguments)` | 單一 JsonNode 相容版;`finalStatus` 缺失直接回 `{raised:false}`;`detail` object 會 convertValue 成 Map |

執行流程:

1. `finalStatus != "ROLLBACK_FAILED"` → 回 `{raised:false}`(靜默)
2. 符合 → 專屬 logger `"OPS-ALERT"` 輸出 **ERROR** 級日誌:

```text
[OPS-ALERT] 回沖失敗,需人工介入 | workflowId=… | instanceId=… | businessKey=… | message=… | detail={a16229Rollback=…, a16220Rollback=…}
```

3. 成功輸出後回 `{raised:true}`
4. **降級不阻斷**:告警通道本身拋例外時,降級為一般 logger 的 ERROR 日誌並回 `{raised:false}`——交易收尾流程不受影響(workflow 端契約不變)

### 3.3 接單整合與擴充點

- ELK / Splunk 以關鍵字 `[OPS-ALERT]`(logger 名稱 `OPS-ALERT`)建立告警規則即可接單(ticketing);logger 以名稱建立,可在 log 設定檔單獨調級/分流
- 擴充點(原始碼 TODO 標記):串接 Kafka / webhook / ITSM 時於 `raise()` 內追加通道,**workflow 端契約(`raised` 布林)不變**
- 觀測鏈路:`opsAlertRaised` 欄位會出現在 workflow 輸出與對帳稽核軌跡,見 [../02-architecture/OBSERVABILITY.md](../02-architecture/OBSERVABILITY.md)

---

## 4. SagaApiService — v15 直打 HTTP 客戶端

原始碼:`domain-transfer/transfer-workflow/src/main/java/com/example/transfer/workflow/SagaApiService.java`

### 4.1 定位、方法與行為

**舊版主流程 `saga-transfer-workflow` v15 專用**(MyOpenApiService 出現前的直打路線):Base URL **寫死** `http://localhost:8080`,以 JDK HttpClient 非同步發送。

```java
private static final String BASE_URL = "http://localhost:8080";   // 寫死
private static final Duration HTTP_TIMEOUT = Duration.ofSeconds(10); // connect + request 皆用
```

公開方法(類別註解宣告的呼叫契約——workflow 以 `type: custom` 反射呼叫):

| 簽名 | 行為 |
|------|------|
| `JsonNode callA16229(String Account_A, Integer AMT, Boolean EC)` | 手工組 body `{Account_A, AMT, EC}` → POST `/A16229` → `.join()` 同步取回 |
| `JsonNode callA16220(String Account_B, Integer AMT, Boolean EC)` | 手工組 body `{Account_B, AMT, EC}` → POST `/A16220` → `.join()` |

回應處理規則(`SagaApiService#callApiAsync`):

1. body 可解析為 JSON → 原樣採用,**附上 `_httpStatus`**
2. 解析失敗 → `{rawResponse, code: statusCode>=400?"999":"100", message:"HTTP 狀態碼: …"}` + `_httpStatus`
3. **連線錯誤**(exceptionally 或建構失敗):`{ "code": "999", "message": "API 連線錯誤: …", "_httpStatus": 0 }`
4. **無 errorType 分類、無重試機制**(與 MyOpenApiService 的最大差異)

### 4.2 與 MyOpenApiService 取捨對照表

| 面向 | SagaApiService(v15 路線) | MyOpenApiService(saga2 路線) |
|------|---------------------------|------------------------------|
| 目標 URL | 寫死 `http://localhost:8080` | 四規則動態解析 + 快取(見 [1.5](#15-base-url-解析四規則優先序圖)) |
| API 描述來源 | Java 內硬編 path/body | OpenAPI spec(classpath YAML)+ operationId |
| 支援方法 | 僅 POST | GET/POST/PUT/DELETE/PATCH/HEAD/OPTIONS |
| Path param / Query String | 無 | 有(見 [1.9](#19-url-組裝路徑參數替換與-query-string)) |
| Timeout | 固定 10s | arguments.timeoutSeconds → 配置 → 10s 鏈式解析 |
| 重試 | 無 | transport-retry(cap 5/500ms/×2.0/僅 exceptionally) |
| 錯誤分類 | 無(僅 code/_httpStatus) | errorType 四分類(TRANSPORT/BUSINESS/HTTP_4XX/HTTP_5XX) |
| 自訂 Headers | 無 | arguments.headers |
| 快取 | 無 | 四層 ConcurrentHashMap |
| 適用場景 | 舊版流程相容、極簡依賴 | 新 workflow 開發範本(推薦) |

> 新 workflow 一律走 MyOpenApiService 路線(SOP 見 [NEW-WORKFLOW-GUIDE](../03-workflow-dev-guide/NEW-WORKFLOW-GUIDE.md));v15 僅作對照保留。

---

## 5. 新增 workflow 的服務接線 SOP

在新的 `.sw.yaml` 中使用這四個服務的標準寫法(全部 `type: custom`,operation 用 FQCN::method):

```yaml
functions:
  # 呼叫任意外部 API(OpenAPI 驅動)
  - name: callApiViaOpenAPI
    operation: 'service:com.example.transfer.workflow.MyOpenApiService::callOpenApi'
    type: custom
  # 寫入對帳紀錄(吞例外,回 {saved})
  - name: recordAuditLog
    operation: 'service:com.example.reconciliation.AuditLogService::saveLog'
    type: custom
  # ROLLBACK_FAILED 條件告警(其餘狀態靜默)
  - name: notifyOps
    operation: 'service:com.example.reconciliation.OpsAlertService::raise'
    type: custom
```

檢查清單:

- [ ] functionRef.arguments 的 key 名稱與服務方法簽名完全對應(saveLog 五鍵、raise 六鍵);Kogito 以精確型別反射綁定
- [ ] Base URL 已由四規則之一覆蓋(application.properties 註冊 `kogito.sw.functions.<fn>.*` 或 spec 內 servers[0])
- [ ] actionExecTimeout/stateExecTimeout 必須大於 HTTP timeout(預設 10s),讓服務層先回標準化錯誤
- [ ] 判斷分支一律以 `code == "100"` 為正向條件,其餘落 default 安全分支;需細分再讀 errorType
- [ ] 收尾 state 不掛 onErrors(saveLog 吞例外),但要把 `auditSaved`/`opsAlertRaised` 浮現到輸出
- [ ] 若要啟用 HTTP 400/409 改寫,記得把 workflow id 加進 `platform.status-rewrite.workflows`

---

## 6. 常見錯誤

| 症狀 | 原因 | 解法 |
|------|------|------|
| callOpenApi 回 `{code:999, _httpStatus:0}`,log 顯示「未指定 schemaRef」 | functionRef.arguments 缺 schemaRef 或空白 | 補 `'specs/<spec>.yaml#<operationId>'` 格式的值 |
| 「schemaRef 格式錯誤」或「找不到 operationId」 | 缺 `#`;或 operationId 與 YAML 內不一致 | 對照 spec 的 `operationId`(如 executeA16229);注意大小寫 |
| 「無法確定 API Base URL」IllegalStateException | 四規則全落空(spec 也沒有 servers) | 在 application.properties 註冊函式級 host/port(見 [1.5]) |
| 改了 application.properties 的 base_url 卻沒生效 | baseUrlCache 快取永不失效 | 重啟應用(dev mode 熱部署除外) |
| 明明下游回了 4xx/5xx 卻「沒有重試」 | 這是設計語義:只有 exceptionally(未取得回應)才重試 | 需重試業務失敗請自行在 workflow 層設計(switch + 迴圈) |
| 配了 max-attempts=10 只重試到第 5 次 | 防呆 cap MAX_ATTEMPTS_CAP=5 | 上限即 5;總嘗試次數含首次 |
| saveLog 後 DB 查不到資料但交易正常結束 | doSaveLog 吞例外;可能 DataSource 未注入走了 DriverManager fallback 寫去不同檔案(MYHELLO_DATA_DIR 與 jdbc.url 不一致) | 看 `[AuditLogService]` WARN 日誌;統一用 application.properties 配置 |
| raise 永遠 raised=false | 只有 `finalStatus=="ROLLBACK_FAILED"` 才觸發;或 JsonNode 版呼叫缺 finalStatus 欄 | 確認傳入的 finalStatus 值;哨兵測試見 [../06-testing/TESTING-GUIDE.md](../06-testing/TESTING-GUIDE.md) |
| [OPS-ALERT] 日誌看不到 | log 設定檔把 `OPS-ALERT` logger 調高了級別,或只看 console 未看檔案 | 檢查 quarkus.log 對 `OPS-ALERT` category 的配置(ERROR 級) |
| SagaApiService 回 `_httpStatus:0, code:999` | 8080 引擎不在(mock API 與引擎同 port) | 先確認 transfer-app 已啟動;v15 直打寫死 localhost:8080 |
| resolveRequestFieldNames 回空清單 | schemaRef 無 `#`、operationId 不存在,或 requestBody schema 非 `$ref` 形式 | 檢查 spec 結構(requestBody.content.application/json.schema) |
| migration 沒被執行 | classpath 枚舉不全且 fallback 清單外的新腳本未被發現;或歷史表已有同 version 但 success=0 | 確認腳本命名符合 regex;success=0 的殘留紀錄需人工清理後重跑 |

---

> 延伸閱讀:[REST-API-REFERENCE.md](REST-API-REFERENCE.md)(這些服務服務的對外 API)、[../03-workflow-dev-guide/WORKFLOW-COOKBOOK.md](../03-workflow-dev-guide/WORKFLOW-COOKBOOK.md)(Saga LIFO/安全 switch 配方)、[DATABASE-REFERENCE.md](DATABASE-REFERENCE.md)、[CONFIG-REFERENCE.md](CONFIG-REFERENCE.md)。
