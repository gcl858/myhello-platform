# REST-API-REFERENCE — myhello-platform 對外 REST API 完整手冊

> 本文為 Ox_docs 第 04 冊《REST API 參考》,100% 基於原始碼撰寫。
> 涵蓋三大 API 群:**① 轉帳 mock API(A16229/A16220)**、**② Workflow 啟動 API**、**③ Reconciliation 對帳 API(16 個 endpoints)**。
>
> 術語(`finalStatus`、`RBFAIL 哨兵`、`EC 參數`、`errorType`)定義見 [../README.md](../README.md) 術語統一表;
> workflow 內部行為詳見 [../03-workflow-dev-guide/SAGA2-TEMPLATE-DEEP-DIVE.md](../03-workflow-dev-guide/SAGA2-TEMPLATE-DEEP-DIVE.md);
> 錯誤分類與重試機制的服務端細節見 [SERVICE-REFERENCE.md](SERVICE-REFERENCE.md)。
>
> 引用慣例:`類別#方法`(如 `A16229Resource#execute`);行號僅輔助且可能隨版本變動。

---

## 目錄

- [0. 部署拓樸與 Base URL 總覽](#0-部署拓樸與-base-url-總覽)
- [1. 群組 A:轉帳 mock API(A16229 / A16220)](#1-群組-a轉帳-mock-apia16229--a16220)
  - [1.1 共通契約與 code 語義表](#11-共通契約與-code-語義表)
  - [1.2 POST /A16229](#12-post-a16229)
  - [1.3 POST /A16220](#13-post-a16220)
  - [1.4 RBFAIL 測試哨兵](#14-rbfail-測試哨兵)
  - [1.5 OpenAPI 規格檔](#15-openapi-規格檔)
- [2. 群組 B:Workflow 啟動 API](#2-群組-bworkflow-啟動-api)
  - [2.1 POST /saga2-transfer-workflow](#21-post-saga2-transfer-workflow)
  - [2.2 五大情境 input/output 全例](#22-五大情境-inputoutput-全例)
  - [2.3 HTTP 狀態碼語義(200/400/409)](#23-http-狀態碼語義200400409)
  - [2.4 其他 sample workflows](#24-其他-sample-workflows)
- [3. 群組 C:Reconciliation 對帳 API](#3-群組-creconciliation-對帳-api)
  - [3.1 /api/reconciliation 14 endpoints 總表](#31-apireconciliation-14-endpoints-總表)
  - [3.2 各 endpoint 細節(curl + 回應範例)](#32-各-endpoint-細節curl--回應範例)
  - [3.3 /reconciliation/export-csv(GET + POST)](#33-reconciliationexport-csvget--post)
  - [3.4 CSV 匯出檔案規格](#34-csv-匯出檔案規格)
- [4. 常見錯誤](#4-常見錯誤)

---

## 0. 部署拓樸與 Base URL 總覽

平台最終組裝為兩個 Quarkus 可執行應用(見 [../02-architecture/ARCHITECTURE.md](../02-architecture/ARCHITECTURE.md)):

| 應用 | Port | 角色 | 掛載的 API 群 |
|------|------|------|--------------|
| transfer-app | **8080** | 讀寫交易(引擎 + 業務) | 群組 A(mock API)+ 群組 B(workflow 啟動)+ 群組 C(reconciliation-api 模組同時被打包進本 app) |
| reconciliation-app | **8090** | 唯讀對帳(`quarkus.datasource.jdbc.read-only=true`,見 `distribution/reconciliation-app/src/main/resources/application.properties`) | 群組 C |

兩 app 共享同一個 `data/reconciliation.db`(SQLite WAL 模式)。

> ⚠️ 群組 C 同時掛在 8080 與 8090:`reconciliation-api` 模組被兩個 distribution app 同時 index(見兩份 `application.properties` 的 `quarkus.index-dependency.reconciliation-api.*`)。
> 但 **8090 的 DataSource 為 read-only**,寫入型操作(retry/cancel job、CSV 匯出落地)在 8080 上才有完整保證;
> `AuditQueryService#getConnection` 在 DataSource 取連線失敗時會 fallback 到 `DriverManager`,該路徑會繞過 read-only 設定(原始碼內已有 WARN 日誌聲明此事)。

本文所有 curl 範例假設服務已依 [../01-getting-started/GETTING-STARTED.md](../01-getting-started/GETTING-STARTED.md) 啟動於本機。

---

## 1. 群組 A:轉帳 mock API(A16229 / A16220)

### 1.1 共通契約與 code 語義表

兩支 mock API 位於 `dev/transfer-mock/src/main/java/org/acme/transfer/api/`(`dev/transfer-mock` 模組,[v1.2] 從頂層 `mocks/transfer-mock` 搬入;package 保留 `org.acme.transfer.api`):

- `A16229Resource`(`@Path("/A16229")`)
- `A16220Resource`(`@Path("/A16220")`)

兩者皆為 `@POST` + `@Consumes/@Produces(APPLICATION_JSON)`,邏輯完全同構(`A16229Resource#execute` / `A16220Resource#execute`):

```
request == null                      → HTTP 403, code="999"
EC == true 且帳號 == "RBFAIL"        → HTTP 403, code="401"(測試哨兵,強制回沖失敗)
金額符合業務條件                      → HTTP 200, code="100"
金額不符合                            → HTTP 403, code="999"
```

**code 語義表**(回應 body 內的 `code` 欄位,一律為字串):

| code | 意義 | HTTP 狀態 | 觸發條件 |
|------|------|-----------|---------|
| `"100"` | 交易成功 | 200 | 金額符合業務規則 |
| `"999"` | 失敗 | 403 | request 為空,或金額不符合業務規則 |
| `"401"` | 強制回沖失敗(**RBFAIL 哨兵**) | 403 | `EC=true` 且帳號為 `"RBFAIL"` |

**EC 參數語義**(定義見 README 術語統一表):

| EC | 意義 | 成功時 message |
|----|------|---------------|
| `false` | 正常交易扣款 | `"成功"` |
| `true` | 回沖(Saga 補償)呼叫 | `"成功(EC)"` |

**金額業務規則**(mock 世界觀,A16229 是「扣款方限制下限」、A16220 是「入款方限制上限」):

| API | 成功條件 | 失敗 message |
|-----|---------|--------------|
| A16229 | `AMT > 50` | `"AMT必須大於50"` |
| A16220 | `AMT < 1000` | `"AMT必須小於1000"` |

> DTO 定義(四支,均為 public field 的純 POJO):
> - `A16229Request`:{ `Account_A`: String, `AMT`: Integer, `EC`: Boolean }
> - `A16220Request`:{ `Account_B`: String, `AMT`: Integer, `EC`: Boolean }
> - `A16229Response` / `A16220Response`(結構相同):{ `code`: String, `message`: String, `Account`: String }

### 1.2 POST /A16229

- **來源**:`A16229Resource#execute`
- **用途**:模擬第一階段扣款(saga2 workflow 的 `CallA16229State` 以 `EC=false` 呼叫;回沖 `RollbackA16229*` 以 `EC=true` 呼叫)

#### 參數表(request body)

| 欄位 | 型別 | 必填 | 說明 |
|------|------|------|------|
| `Account_A` | string | ✔(spec 標 required) | 扣款帳號;填 `"RBFAIL"` 且 `EC=true` 時觸發哨兵 |
| `AMT` | integer | ✔ | 交易金額;`> 50` 才成功 |
| `EC` | boolean | ✔ | `false`=正常交易;`true`=回沖 |

#### 判定流程(`A16229Resource#execute`,行號可能隨版本變動)

```mermaid
flowchart TD
    S[POST /A16229] --> N{"request == null?"}
    N -- 是 --> E999a["HTTP 403<br/>code=999<br/>Request不可為空"]
    N -- 否 --> R{"EC == true<br/>且 Account_A == 'RBFAIL'?"}
    R -- 是 --> E401["HTTP 403<br/>code=401<br/>回沖失敗(測試哨兵)"]
    R -- 否 --> M{"AMT > 50 ?"}
    M -- 是 --> OK["HTTP 200<br/>code=100<br/>message=成功 或 成功(EC)"]
    M -- 否 --> E999b["HTTP 403<br/>code=999<br/>AMT必須大於50"]
```

#### curl 範例 ×3 與對應回應

**例 1:一般成功(EC=false,AMT>50)**

```bash
curl -s -X POST http://localhost:8080/A16229 \
  -H 'Content-Type: application/json' \
  -d '{"Account_A":"A123456789","AMT":100,"EC":false}'
```

```json
// HTTP 200
{ "code": "100", "message": "成功", "Account": "A123456789" }
```

**例 2:回沖成功(EC=true,AMT>50)**

```bash
curl -s -X POST http://localhost:8080/A16229 \
  -H 'Content-Type: application/json' \
  -d '{"Account_A":"A123456789","AMT":100,"EC":true}'
```

```json
// HTTP 200
{ "code": "100", "message": "成功(EC)", "Account": "A123456789" }
```

**例 3:金額不符(AMT ≤ 50)**

```bash
curl -s -X POST http://localhost:8080/A16229 \
  -H 'Content-Type: application/json' \
  -d '{"Account_A":"A123456789","AMT":30,"EC":false}'
```

```json
// HTTP 403
{ "code": "999", "message": "AMT必須大於50", "Account": "A123456789" }
```

### 1.3 POST /A16220

- **來源**:`A16220Resource#execute`
- **用途**:模擬第二階段入款(saga2 的 `CallA16220State` 以 `EC=false`;回沖 `RollbackA16220` 以 `EC=true`)

#### 參數表(request body)

| 欄位 | 型別 | 必填 | 說明 |
|------|------|------|------|
| `Account_B` | string | ✔ | 入款帳號;填 `"RBFAIL"` 且 `EC=true` 時觸發哨兵 |
| `AMT` | integer | ✔ | 交易金額;`< 1000` 才成功 |
| `EC` | boolean | ✔ | 同 A16229 |

#### curl 範例 ×3 與對應回應

**例 1:一般成功(AMT<1000)**

```bash
curl -s -X POST http://localhost:8080/A16220 \
  -H 'Content-Type: application/json' \
  -d '{"Account_B":"B123456789","AMT":500,"EC":false}'
```

```json
// HTTP 200
{ "code": "100", "message": "成功", "Account": "B123456789" }
```

**例 2:金額不符(AMT ≥ 1000)** —— 這是觸發 saga「僅回沖 A16229」路徑的關鍵場景:

```bash
curl -s -X POST http://localhost:8080/A16220 \
  -H 'Content-Type: application/json' \
  -d '{"Account_B":"B123456789","AMT":1500,"EC":false}'
```

```json
// HTTP 403
{ "code": "999", "message": "AMT必須小於1000", "Account": "B123456789" }
```

**例 3:RBFAIL 哨兵(EC=true + Account_B="RBFAIL")**

```bash
curl -s -X POST http://localhost:8080/A16220 \
  -H 'Content-Type: application/json' \
  -d '{"Account_B":"RBFAIL","AMT":500,"EC":true}'
```

```json
// HTTP 403
{ "code": "401", "message": "回沖失敗(測試哨兵)", "Account": "RBFAIL" }
```

### 1.4 RBFAIL 測試哨兵

**定義**(README 術語統一表):帳號欄填 `RBFAIL` 且 `EC=true` 時,mock API 強制回沖失敗(HTTP 403 + `code="401"`),供端到端驗證 `ROLLBACK_FAILED → HTTP 409` 路徑。

- 實作位置:`A16229Resource#execute`(比對 `Account_A`)與 `A16220Resource#execute`(比對 `Account_B`),兩者的哨兵判斷都在金額判斷**之前**。
- 一般交易(`EC=false`)完全不受影響——帳號叫 `RBFAIL` 也能正常扣款。
- 完整端到端劇本(啟動 workflow → 觀察 409 與 `[OPS-ALERT]` 日誌)見 [../06-testing/TESTING-GUIDE.md](../06-testing/TESTING-GUIDE.md)。

### 1.5 OpenAPI 規格檔

`domain-transfer/transfer-workflow/src/main/resources/specs/` 下有兩份 OpenAPI 3.0 規格,供 `MyOpenApiService` 於 runtime 動態解析(saga2 路線),也是 [GET /api/reconciliation/specs](#32-各-endpoint-細節curl--回應範例) 的掃描來源:

| 檔案 | operationId | 成功規則 | servers[0].url |
|------|-------------|---------|----------------|
| `specs/A16229-api.yaml` | `executeA16229` | AMT > 50 | `http://localhost:8080/` |
| `specs/A16220-api.yaml` | `executeA16220` | AMT < 1000 | `http://localhost:8080/` |

兩份 spec 已同步記載 RBFAIL 哨兵行為(description 欄位)。schemaRef 寫法範例:`specs/A16229-api.yaml#executeA16229`。

---

## 2. 群組 B:Workflow 啟動 API

### 2.1 POST /saga2-transfer-workflow

- **引擎標準 endpoint**:SonataFlow 為每個 workflow 自動暴露 `POST /{workflowId}`。
- **範本 workflow**:`saga2-transfer-workflow` v2.2.0(定義檔 `domain-transfer/transfer-workflow/src/main/resources/saga2-transfer-workflow.sw.yaml`,18 states)。
- **同步性**:呼叫會一路執行至統一終點 `FinalAuditAndEnd` 才回傳;workflow 層級逾時 `workflowExecTimeout: PT5M`。
- **輸入驗證**:由 state `ValidateInput`(switch + jq)在 workflow 內執行(`dataInputSchema` 已停用,YAML 內有註解聲明),驗證失敗走 `InjectValidationFailedStatus` → 最終 HTTP 400。

#### 輸入(input)

| 欄位 | 型別 | 驗證規則(`ValidateInput`,條件順序即優先序) |
|------|------|-------------------------------------------|
| `Account_A` | string | 須匹配 `^[A-Za-z0-9_]+$`(非空;僅英數字與底線) |
| `Account_B` | string | 同上 |
| `AMT` | number | 須為數字且 `> 0` |
| — | — | `Account_A != Account_B`(禁止同帳號) |

多欄位同時錯誤時僅回報第一個命中的分類(條件順序:accountAInvalid → accountBInvalid → amtInvalid → amtNotPositive → sameAccount)。

#### 輸出(output,經 `FinalAuditAndEnd#stateDataFilter.output` 重組)

| 欄位 | 說明 |
|------|------|
| `status` | 即 `finalStatus`:`SUCCESS` / `FAILED` / `ROLLED_BACK` / `ROLLBACK_FAILED` / `VALIDATION_FAILED` |
| `message` | 即 `finalMessage`(各 Inject state 的固定文案) |
| `AMT` | 原始交易金額 |
| `a16229Result` | 第一階段回應摘要 `{code, message, Account, errorType, _httpStatus}`,未執行則 null |
| `a16220Result` | 第二階段回應摘要,未執行則 null |
| `a16229Rollback` | A16229 回沖結果摘要,未執行則 null |
| `a16220Rollback` | A16220 回沖結果摘要,未執行則 null |
| `auditSaved` | 對帳紀錄寫入結果(`AuditLogService#doSaveLog` 的 `saved` 值;寫入失敗不影響交易收尾) |
| `opsAlertRaised` | 是否實際發出 `[OPS-ALERT]` 告警(僅 `ROLLBACK_FAILED` 時 true) |

> `*_Result` / `*_Rollback` 物件的內容由各 operation state 的 `actionDataFilter.results` 收斂為 `{code, message, Account, errorType, _httpStatus}`;其中 `errorType` 僅在失敗時由 `MyOpenApiService` 提供(成功時為 null/省略,`errorType` 分類契約見 [SERVICE-REFERENCE.md](SERVICE-REFERENCE.md#myopenapiservice--通用-openapi-動態呼叫服務))。

### 2.2 五大情境 input/output 全例

以下 5 個情境涵蓋全部 5 種 `finalStatus`(另附 RBFAIL 加碼情境)。所有請求皆為:

```bash
curl -s -X POST http://localhost:8080/saga2-transfer-workflow \
  -H 'Content-Type: application/json' \
  -d '<input>'
```

---

**情境 1:`SUCCESS` —— 一般成功(AMT ≤ 500)**

```json
// input
{ "Account_A": "Alice_001", "Account_B": "Bob_002", "AMT": 100 }
```

兩階段皆 `EC=false` 成功;`AMT <= 500` 不觸發回沖。

```json
// output(HTTP 200)
{
  "status": "SUCCESS",
  "message": "交易成功",
  "AMT": 100,
  "a16229Result":  { "code": "100", "message": "成功", "Account": "Alice_001", "errorType": null, "_httpStatus": 200 },
  "a16220Result":  { "code": "100", "message": "成功", "Account": "Bob_002",   "errorType": null, "_httpStatus": 200 },
  "a16229Rollback": null,
  "a16220Rollback": null,
  "auditSaved": true,
  "opsAlertRaised": false
}
```

---

**情境 2:`ROLLED_BACK` —— 大額全回沖(AMT > 500,Saga LIFO)**

```json
// input
{ "Account_A": "Alice_001", "Account_B": "Bob_002", "AMT": 600 }
```

兩階段扣款成功後,`DecideByEvaluation` 判定 `AMT > 500` → 先回沖 A16220 再回沖 A16229(LIFO,皆 `EC=true`)。

```json
// output(HTTP 200)
{
  "status": "ROLLED_BACK",
  "message": "AMT > 500 觸發 saga 回沖 (LIFO)",
  "AMT": 600,
  "a16229Result":     { "code": "100", "message": "成功",      "Account": "Alice_001", "errorType": null, "_httpStatus": 200 },
  "a16220Result":     { "code": "100", "message": "成功",      "Account": "Bob_002",   "errorType": null, "_httpStatus": 200 },
  "a16229Rollback":   { "code": "100", "message": "成功(EC)",  "Account": "Alice_001", "errorType": null, "_httpStatus": 200 },
  "a16220Rollback":   { "code": "100", "message": "成功(EC)",  "Account": "Bob_002",   "errorType": null, "_httpStatus": 200 },
  "auditSaved": true,
  "opsAlertRaised": false
}
```

---

**情境 3:`ROLLED_BACK` —— A16220 失敗,僅回沖 A16229(AMT ≥ 1000)**

```json
// input
{ "Account_A": "Alice_001", "Account_B": "Bob_002", "AMT": 1500 }
```

A16229 扣款成功;A16220 回 `code="999"`(AMT ≥ 1000)→ `CheckA16220Result` default 分支 → `RollbackA16229Only`(只回沖第一階段,因第二階段未曾扣款)。

```json
// output(HTTP 200)
{
  "status": "ROLLED_BACK",
  "message": "A16220 業務失敗,僅回沖 A16229",
  "AMT": 1500,
  "a16229Result":   { "code": "100", "message": "成功",         "Account": "Alice_001", "errorType": null,      "_httpStatus": 200 },
  "a16220Result":   { "code": "999", "message": "AMT必須小於1000", "Account": "Bob_002",   "errorType": "BUSINESS", "_httpStatus": 403 },
  "a16229Rollback": { "code": "100", "message": "成功(EC)",     "Account": "Alice_001", "errorType": null,      "_httpStatus": 200 },
  "a16220Rollback": null,
  "auditSaved": true,
  "opsAlertRaised": false
}
```

---

**情境 4:`FAILED` —— 第一階段業務失敗(AMT ≤ 50)**

```json
// input
{ "Account_A": "Alice_001", "Account_B": "Bob_002", "AMT": 30 }
```

A16229 即回 `code="999"` → `CheckA16229Result` default → `InjectFailedStatus`(尚未扣款,無需回沖)。

```json
// output(HTTP 200)
{
  "status": "FAILED",
  "message": "業務失敗或 API 錯誤",
  "AMT": 30,
  "a16229Result": { "code": "999", "message": "AMT必須大於50", "Account": "Alice_001", "errorType": "BUSINESS", "_httpStatus": 403 },
  "a16220Result": null,
  "a16229Rollback": null,
  "a16220Rollback": null,
  "auditSaved": true,
  "opsAlertRaised": false
}
```

---

**情境 5:`VALIDATION_FAILED` —— 輸入驗證失敗(HTTP 400)**

```json
// input(同帳號,命中 sameAccount 條件)
{ "Account_A": "Same_Account", "Account_B": "Same_Account", "AMT": 100 }
```

`ValidateInput` 命中 → `InjectValidationFailedStatus` → `platform.status-rewrite` 將 HTTP 改寫為 **400**。

```json
// output(HTTP 400)
{
  "status": "VALIDATION_FAILED",
  "message": "輸入欄位格式錯誤 (帳號僅限英數字與底線且兩者不得相同;AMT 須為大於 0 的數字)",
  "AMT": 100,
  "a16229Result": null,
  "a16220Result": null,
  "a16229Rollback": null,
  "a16220Rollback": null,
  "auditSaved": true,
  "opsAlertRaised": false
}
```

---

**加碼情境:`ROLLBACK_FAILED` —— RBFAIL 哨兵(HTTP 409 + OPS-ALERT)**

```json
// input(Account_B 用 RBFAIL,AMT > 500 走全回沖)
{ "Account_A": "Alice_001", "Account_B": "RBFAIL", "AMT": 600 }
```

兩階段扣款成功;LIFO 回沖第一步 `RollbackA16220`(`EC=true` + `Account_B="RBFAIL"`)被哨兵攔截 → `code="401"` → `CheckRollbackResults` 命中 `anyRollbackFailed` → `ROLLBACK_FAILED`,且 `OpsAlertService` 發出 `[OPS-ALERT]` ERROR 日誌。

```json
// output(HTTP 409)
{
  "status": "ROLLBACK_FAILED",
  "message": "⚠️ 回沖失敗,需人工介入處理",
  "AMT": 600,
  "a16229Result":   { "code": "100", "message": "成功",           "Account": "Alice_001", "errorType": null,       "_httpStatus": 200 },
  "a16220Result":   { "code": "100", "message": "成功",           "Account": "RBFAIL",    "errorType": null,       "_httpStatus": 200 },
  "a16229Rollback": { "code": "100", "message": "成功(EC)",       "Account": "Alice_001", "errorType": null,       "_httpStatus": 200 },
  "a16220Rollback": { "code": "401", "message": "回沖失敗(測試哨兵)", "Account": "RBFAIL",    "errorType": "BUSINESS", "_httpStatus": 403 },
  "auditSaved": true,
  "opsAlertRaised": true
}
```

> 補充:`errorType` 也可能是 `TRANSPORT` / `HTTP_4XX` / `HTTP_5XX`(例如下游服務整個不在),此時 `_httpStatus` 為 `0`(TRANSPORT)或對應 HTTP 碼;workflow 對任何 `code != "100"` 一律走安全分支(失敗/補償)。分類判定流程圖見 [SERVICE-REFERENCE.md](SERVICE-REFERENCE.md#errortype-判定流程normalizeResponse)。

### 2.3 HTTP 狀態碼語義(200/400/409)

由 platform-security 的 `WorkflowStatusFilter`(ContainerResponseFilter)+ `distribution/transfer-app/src/main/resources/application.properties` 配置實現(`platform.status-rewrite.*`):

```properties
platform.status-rewrite.workflows=saga2-transfer-workflow
platform.status-rewrite.mapping=VALIDATION_FAILED=400,ROLLBACK_FAILED=409
```

| HTTP | finalStatus | 說明 |
|------|-------------|------|
| **200** | `SUCCESS` / `FAILED` / `ROLLED_BACK` | 未列入 mapping,保持引擎原碼 |
| **400** | `VALIDATION_FAILED` | 客戶端輸入錯誤 |
| **409** | `ROLLBACK_FAILED` | 回沖失敗,需人工介入(衝突語義) |

- 只有名列 `platform.status-rewrite.workflows` 的 workflow 會被改寫;新增 workflow 需在此註冊(免改 Java)。
- 其餘 HTTP 層行為:body 格式錯誤(非 JSON)由 JAX-RS 層回引擎預設錯誤;找不到 workflow id 時回 404。

### 2.4 其他 sample workflows

`dev/transfer-samples/src/main/resources/` 下另有三個示範 workflow,皆以同一模式 `POST /{workflowId}` 啟動,此處一句話帶過(細節見 [../03-workflow-dev-guide/WORKFLOW-COOKBOOK.md](../03-workflow-dev-guide/WORKFLOW-COOKBOOK.md)):

| workflow id | 示範重點 |
|-------------|---------|
| `java-workflow` | `type: custom` 呼叫 Java 服務(`com.example.ApiService.callHealthApi()`)再打 `/q/health` |
| `rest-workflow` | 不靠 OpenAPI 規格、以 `rest:<method>:<path>` 純 REST 呼叫(fetchHealthData → `/q/health`),protocol/host/port 由 application.properties 提供 |
| `OpenAPI-workflow` | `type: rest` + OpenAPI 規格呼叫外部 API 的最小示範(jq 萃取/apiResponse) |

### 2.5 OpenAPI 動態路由代理 API (Vert.x Dynamic Route Proxy)

除了 Kogito 預設的 `POST /{workflowId}`，平台透過 `InternalOpenApiDynamicRouter` 支援由 `specs/internal/*.yaml` 所定義之階層式對外 API 與路徑參數 (Path Parameter) 自動注入。

**範例：臨櫃信用卡現金繳款**
- **規格檔案**：`specs/internal/omni-counter-repayment-api.yaml` (標記 `x-workflow-id: omni_cash_transaction`)
- **對外路徑**：`POST /Omni/{creditcardid}/Repayment/Execute`

```bash
curl -s -X POST http://localhost:8080/Omni/A123456789/Repayment/Execute \
  -H 'Content-Type: application/json' \
  -d '{
    "partyId": "A123456789",
    "operationType": "A",
    "paymentChannel": "2500P",
    "amount": "0000010000",
    "sequenceNumber": "202609030001"
  }'
```

```json
// output (HTTP 200)
{
  "track_id": "A123456789",
  "workflow": "REPAYMENT",
  "status": 0,
  "finalStatus": "SUCCESS",
  "message": "臨櫃信用卡現金繳款作業成功完成",
  "coreResult": {
    "code": "100",
    "message": "交易成功",
    "track_id": "A123456789"
  },
  "creditCardResult": {
    "code": "100",
    "message": "交易成功",
    "track_id": "A123456789"
  },
  "auditSaved": true
}
```

> **機制說明**：
> 1. 動態路由代理會自動將 URL 路徑中的 `{creditcardid}` (`A123456789`) 提取並合併注入到 Request Body JSON 頂層。
> 2. 轉發至本地流程引擎執行 `omni_cash_transaction`。
> 3. 若輸入格式不符（如 `operationType="C"`），`OpenApiSchemaValidator` 攔截並由 `WorkflowStatusFilter` 改寫回傳 **HTTP 400 (`REJECTED_VALIDATION`)**。

---

## 3. 群組 C:Reconciliation 對帳 API

來源:`domain-reconciliation/reconciliation-api/src/main/java/com/example/reconciliation/`
- `ReconciliationAuditResource`(`@Path("/api/reconciliation")`)— 14 個 endpoints
- `ReconciliationResource`(`@Path("/reconciliation")`)— 2 個 export-csv endpoints(GET/POST)
- 底層邏輯集中在 `AuditQueryService`(查詢/代理)與 `ReconciliationCsvExporter`(CSV 匯出)

### 3.1 /api/reconciliation 14 endpoints 總表

| # | Method | Path | 用途(原始碼 Javadoc 摘要) | 主要後端方法 |
|---|--------|------|---------------------------|-------------|
| 1 | GET | `/api/reconciliation/records` | 查詢對帳與審計流水(vw_saga_reconciliation) | `AuditQueryService#getReconciliationRecords` |
| 2 | GET | `/api/reconciliation/files` | 歷史 reconciliation-*.csv 清單 | `AuditQueryService#getReconciliationFiles` |
| 3 | GET | `/api/reconciliation/files/{filename}` | 下載/檢視特定 CSV 內容(TEXT_PLAIN) | `AuditQueryService#getCsvFileContent` |
| 4 | POST | `/api/reconciliation/export-csv` | 手動觸發產生新對帳 CSV | `AuditQueryService#exportCsv` → `ReconciliationCsvExporter#exportToCsv` |
| 5 | POST | `/api/reconciliation/trigger-saga2` | 觸發 Saga2 轉帳(前端代理 → 8080) | `AuditQueryService#triggerSaga2Transfer` |
| 6 | POST | `/api/reconciliation/proxy-test` | 沙盒通用測試代理(可選 5 大 workflow) | `AuditQueryService#proxyTestWorkflow` |
| 7 | POST | `/api/reconciliation/graphql` | GraphQL 代理(轉發 8080 /graphql,解 CORS) | `AuditQueryService#proxyGraphQL` |
| 8 | GET | `/api/reconciliation/jobs` | Kogito Jobs & Timers 排程查詢 | `AuditQueryService#getJobsRecords` |
| 9 | POST | `/api/reconciliation/jobs/{id}/retry` | 手動發送 Job 重試 | `AuditQueryService#retryJob` |
| 10 | POST | `/api/reconciliation/jobs/{id}/cancel` | 手動取消 Job 排程 | `AuditQueryService#cancelJob` |
| 11 | GET | `/api/reconciliation/specs` | 讀取與解析 OpenAPI 規格檔 | `AuditQueryService#getOpenApiSpecs` |
| 12 | POST | `/api/reconciliation/specs/ping` | 連線品質點檢(Health Check Ping) | `AuditQueryService#pingEndpoint` |
| 13 | GET | `/api/reconciliation/instances` | 近期工作流實例清單(processes 表) | `AuditQueryService#getRecentInstances` |
| 14 | GET | `/api/reconciliation/trace/{instanceId}` | 特定實例之圖形化節點軌跡 | `AuditQueryService#getInstanceTrace` |

另有 `/reconciliation/export-csv`(GET + POST,見 [3.3](#33-reconciliationexport-csvget--post))。

> 所有 endpoint 的 `@Produces` 為 `application/json`,唯 #3 為 `text/plain`。回應主體一律由 `JsonNode.toString()` 序列化;**即使底層失敗也多半回 HTTP 200 + 錯誤欄位**(proxy 系列以 `status_code`/`error` 欄位揭露真相),這是本資源類別的設計慣例,呼叫端務必檢查內容而非只看 HTTP 碼。

### 3.2 各 endpoint 細節(curl + 回應範例)

以下範例以 8080 為準;8090 上的行為相同(read-only 差異見 [§0](#0-部署拓樸與-base-url-總覽))。

---

#### ① GET /api/reconciliation/records

查詢 view `vw_saga_reconciliation`,動態組 SQL(`WHERE 1=1` + 條件附加),固定 `ORDER BY id DESC LIMIT 100`。view 不存在時 fallback 查 `workflow_execution_log`(LIMIT 50)。

**參數表(query params,皆可省略)**

| 參數 | 型別 | 行為 |
|------|------|------|
| `accountA` | string | `AND account_a LIKE '%…%'`(模糊) |
| `accountB` | string | `AND account_b LIKE '%…%'` |
| `status` | string | 精確等於;`ALL`(不分大小寫)= 不過濾 |
| `minAmt` | number | `AND amt >= ?` |
| `maxAmt` | number | `AND amt <= ?` |

```bash
curl -s "http://localhost:8080/api/reconciliation/records?status=SUCCESS&minAmt=100"
```

```json
[
  {
    "id": 3, "created_at": "2026-08-23 10:15:30",
    "workflow_id": "saga2-transfer-workflow", "business_key": "Alice_001",
    "process_instance_id": "8f3c…", "status": "SUCCESS", "message": "交易成功",
    "account_a": "Alice_001", "account_b": "Bob_002", "amt": 100.0,
    "a16229_code": "100", "a16229_msg": "成功",
    "a16220_code": "100", "a16220_msg": "成功",
    "a16229_rollback_code": null, "a16220_rollback_code": null
  }
]
```

> 欄位名稱即 view 欄位(`ResultSetMetaData` 反射輸出);數值欄一律轉 double。view 的完整定義見 [DATABASE-REFERENCE.md](DATABASE-REFERENCE.md)。

---

#### ② GET /api/reconciliation/files

列出 `data/` 目錄下檔名以 `reconciliation-` 開頭且以 `.csv` 結尾的檔案。

```bash
curl -s http://localhost:8080/api/reconciliation/files
```

```json
[
  { "filename": "reconciliation-20260823-101500.csv", "sizeBytes": 1240, "lastModified": 1755917700000 }
]
```

---

#### ③ GET /api/reconciliation/files/{filename}

讀取單一 CSV 檔案全文(UTF-8 字串回傳,`Content-Disposition: inline`)。檔案不存在時回 **空字串**(HTTP 仍 200)。

```bash
curl -s http://localhost:8080/api/reconciliation/files/reconciliation-20260823-101500.csv
```

```text
id,created_at,workflow_id,…(BOM 開頭的 UTF-8 CSV 全文)
1,2026-08-23 10:15:30,saga2-transfer-workflow,…
```

---

#### ④ POST /api/reconciliation/export-csv

手動觸發匯出。body 可省略(null 安全);支援 `workflowId`、`status` 兩個過濾鍵(`businessKey` 不由此 endpoint 暴露,`ALL` 視同不過濾)。委派 `ReconciliationCsvExporter#exportToCsv(workflowId, null, status)`。

| body 欄位 | 型別 | 說明 |
|-----------|------|------|
| `workflowId` | string | 精確過濾 workflow_id |
| `status` | string | 精確過濾 status;`"ALL"` → null(不過濾) |

```bash
curl -s -X POST http://localhost:8080/api/reconciliation/export-csv \
  -H 'Content-Type: application/json' \
  -d '{"workflowId":"saga2-transfer-workflow","status":"ROLLBACK_FAILED"}'
```

```json
{
  "ok": true,
  "filePath": "/abs/path/to/data/reconciliation-20260823-110230.csv",
  "fileName": "reconciliation-20260823-110230.csv",
  "rowCount": 1,
  "byteSize": 987,
  "exportedAt": "2026-08-23T11:02:30.123",
  "filters": { "workflowId": "saga2-transfer-workflow", "businessKey": "", "status": "ROLLBACK_FAILED" }
}
```

view 尚未建立時:`{ "ok": false, "error": "View vw_saga_reconciliation 不存在,請先執行 workflow 觸發 AuditLogService 初始化" }`。

---

#### ⑤ POST /api/reconciliation/trigger-saga2

以 `HttpURLConnection` 代理 POST `http://localhost:8080/saga2-transfer-workflow`。body 三欄皆可省略,預設值:`Account_A="Account_Standalone_A"`、`Account_B="Account_Standalone_B"`、`AMT=500`。

```bash
curl -s -X POST http://localhost:8080/api/reconciliation/trigger-saga2 \
  -H 'Content-Type: application/json' \
  -d '{"Account_A":"Alice_001","Account_B":"Bob_002","AMT":100}'
```

```json
{
  "status_code": 200,
  "data": {
    "status": "SUCCESS", "message": "交易成功", "AMT": 100,
    "a16229Result": { "code": "100", "message": "成功", "Account": "Alice_001", "errorType": null, "_httpStatus": 200 },
    "a16220Result": { "code": "100", "message": "成功", "Account": "Bob_002", "errorType": null, "_httpStatus": 200 },
    "a16229Rollback": null, "a16220Rollback": null,
    "auditSaved": true, "opsAlertRaised": false
  }
}
```

連不上引擎時:`{ "status_code": 500, "error": "Connection refused…" }`。

---

#### ⑥ POST /api/reconciliation/proxy-test

沙盒通用代理:把任意 payload POST 到 `http://localhost:8080/{workflowPath}`(路徑開頭 `/` 會被剥除;`workflowPath` 缺省為 `saga2-transfer-workflow`)。回應自帶量測資訊(`duration_ms`),回應非 JSON 時降級為 `response_text`。

| body 欄位 | 型別 | 預設 |
|-----------|------|------|
| `workflowPath` | string | `saga2-transfer-workflow` |
| `payload` | object | `{}` |

```bash
curl -s -X POST http://localhost:8080/api/reconciliation/proxy-test \
  -H 'Content-Type: application/json' \
  -d '{"workflowPath":"java-workflow","payload":{"name":"John"}}'
```

```json
{
  "workflowPath": "java-workflow",
  "targetUrl": "http://localhost:8080/java-workflow",
  "status_code": 200,
  "duration_ms": 1234,
  "request_payload": { "name": "John" },
  "response_json": { "greeting": "…", "data": "…" }
}
```

---

#### ⑦ POST /api/reconciliation/graphql

將 body 原樣轉發至 Data Index GraphQL 端點 `http://localhost:8080/graphql`(解決瀏覽器跨域)。

```bash
curl -s -X POST http://localhost:8080/api/reconciliation/graphql \
  -H 'Content-Type: application/json' \
  -d '{"query":"{ ProcessInstances (orderBy: {start: DESC}) { id processId state } }"}'
```

```json
{ "status_code": 200, "data": { "data": { "ProcessInstances": [ … ] } } }
```

GraphQL 查詢語法與常用 query 收錄於 [../02-architecture/OBSERVABILITY.md](../02-architecture/OBSERVABILITY.md)。

---

#### ⑧ GET /api/reconciliation/jobs

查詢 `jobs` 表(Kogito Jobs & Timers),`ORDER BY last_update DESC LIMIT 50`,`status` 參數精確過濾(`ALL`/省略 = 不過濾)。

> ⚠️ 原始碼事實:`getJobsRecords` 的 status 條件是以**字串拼接**組進 SQL(`sql += "AND status = '" + … + "'"`),非 PreparedStatement 參數;此 endpoint 僅宜由可信介面(內建 UI)使用。

```bash
curl -s "http://localhost:8080/api/reconciliation/jobs?status=ERROR"
```

```json
[
  {
    "id": "job-abc123", "processId": "saga2-transfer-workflow",
    "processInstanceId": "8f3c…", "status": "ERROR",
    "expirationTime": "2026-08-23T10:20:00", "retries": 0,
    "callbackEndpoint": "http://localhost:8080/saga2-transfer-workflow/…",
    "exceptionMessage": "…"
  }
]
```

---

#### ⑨ POST /api/reconciliation/jobs/{id}/retry

執行 `UPDATE jobs SET status='RETRY', retries=retries+1 WHERE id=?`。

```bash
curl -s -X POST http://localhost:8080/api/reconciliation/jobs/job-abc123/retry
```

```json
{ "success": true, "updatedRows": 1, "message": "Job #job-abc123 已成功發送重試調用信號。" }
```

> ⚠️ 原始碼事實:`retryJob`/`cancelJob` 的 catch 區塊**同樣回傳 `success:true`**(僅少了 updatedRows)——例外被吞掉,呼叫端無法從回應區分成敗,需以日誌佐證。

---

#### ⑩ POST /api/reconciliation/jobs/{id}/cancel

執行 `UPDATE jobs SET status='CANCELED' WHERE id=?`。

```bash
curl -s -X POST http://localhost:8080/api/reconciliation/jobs/job-abc123/cancel
```

```json
{ "success": true, "updatedRows": 1, "message": "Job #job-abc123 已成功中斷並取消排程。" }
```

---

#### ⑪ GET /api/reconciliation/specs

掃描 3 個候選目錄下的 `.yaml/.yml/.json` 規格檔(依檔名去重,先到先得):

1. `domain-transfer/transfer-workflow/src/main/resources/specs`
2. `distribution/transfer-app/src/main/resources/specs`
3. `dev/transfer-samples/src/main/resources/specs`

```bash
curl -s http://localhost:8080/api/reconciliation/specs
```

```json
[
  {
    "fileName": "A16229-api.yaml",
    "rawContent": "openapi: 3.0.0\ninfo:\n  title: A16229 API\n…",
    "title": "A16229-api",
    "version": "1.0.0",
    "description": "OpenAPI Specification: A16229-api.yaml"
  }
]
```

> `version`/`description` 為服務端組出的展示值(固定 `1.0.0`),非解析 spec 內容而得。

---

#### ⑫ POST /api/reconciliation/specs/ping

對 `targetUrl` 發 GET(connect/read timeout 各 3000ms);`online = statusCode < 500`。targetUrl 缺省 `http://localhost:8080/`。

```bash
curl -s -X POST http://localhost:8080/api/reconciliation/specs/ping \
  -H 'Content-Type: application/json' \
  -d '{"targetUrl":"http://localhost:8090/"}'
```

```json
{ "targetUrl": "http://localhost:8090/", "statusCode": 200, "latencyMs": 12, "online": true }
```

連線失敗:`{ "targetUrl": "…", "statusCode": 0, "latencyMs": 3011, "online": false, "error": "…" }`。

---

#### ⑬ GET /api/reconciliation/instances

查 `processes` 表(`ORDER BY start_time DESC LIMIT 50`)。epoch 毫秒時間戳會轉為系統時區 datetime 字串;從 `variables` JSON 內的 `workflowdata.finalStatus`(退回 `status`)抽業務狀態,`finalMessage`(退回 `message`)抽訊息,皆無則 `UNKNOWN`。

```bash
curl -s http://localhost:8080/api/reconciliation/instances
```

```json
[
  {
    "id": "8f3c-…", "processId": "saga2-transfer-workflow",
    "processName": "Saga2 Transfer Workflow", "state": "COMPLETED",
    "startTime": "2026-08-23T10:15:29.900", "endTime": "2026-08-23T10:15:30.450",
    "status": "SUCCESS", "message": "交易成功"
  }
]
```

---

#### ⑭ GET /api/reconciliation/trace/{instanceId}

以 `id LIKE %instanceId%` 查 `processes`(支援部分 ID),再撈 `nodes` 表(`ORDER BY enter ASC`)組節點軌跡。`status` 判斷:變數字串含 `ROLLED_BACK` 或 `回沖` → `"ROLLED_BACK"`,否則 `"SUCCESS"`;查無實例 → `"UNKNOWN"` + 空 nodes。

```bash
curl -s http://localhost:8080/api/reconciliation/trace/8f3c
```

```json
{
  "instanceId": "8f3c-…(完整 ID)",
  "processId": "saga2-transfer-workflow",
  "processName": "Saga2 Transfer Workflow",
  "state": "COMPLETED",
  "startTime": "2026-08-23T10:15:29.900",
  "endTime": "2026-08-23T10:15:30.450",
  "status": "ROLLED_BACK",
  "variables": { …完整 workflow variables… },
  "nodes": [
    {
      "id": "3", "name": "CallA16229State", "type": "OperationState",
      "enter": "2026-08-23T10:15:29.950", "exit": "2026-08-23T10:15:30.010",
      "errorMessage": null,
      "inputArgs": { "Account_A": "Alice_001", "AMT": 600, "EC": false },
      "outputArgs": { "code": "100", "message": "成功", "Account": "Alice_001" }
    }
  ]
}
```

節點軌跡如何寫入 `nodes` 表,見 [../02-architecture/OBSERVABILITY.md](../02-architecture/OBSERVABILITY.md)。

### 3.3 /reconciliation/export-csv(GET + POST)

來源:`ReconciliationResource`(`@Path("/reconciliation")`)。與 [④](#④-post-apireconciliationexport-csv) 的差異:**支援 `businessKey` 過濾**、GET 版可用瀏覽器直呼、且 HTTP 狀態碼會反映結果(`ok=true→200,false→500`)。

**GET 版**(`ReconciliationResource#exportViaGet`)參數表(query params,皆可省略 = 不過濾):

| 參數 | 說明 |
|------|------|
| `workflowId` | 精確等於 workflow_id |
| `businessKey` | 精確等於 business_key |
| `status` | 精確等於 status |

```bash
# 匯出全部
curl -s "http://localhost:8080/reconciliation/export-csv"
# 只匯出 SUCCESS
curl -s "http://localhost:8080/reconciliation/export-csv?status=SUCCESS"
# 只匯出特定業務鍵
curl -s "http://localhost:8080/reconciliation/export-csv?businessKey=Alice_001"
```

**POST 版**(`ReconciliationResource#exportViaPost`):body JSON `{ "workflowId": …, "businessKey": …, "status": … }`(三鍵皆可省略;`hasNonNull` 判斷)。

```bash
curl -s -X POST http://localhost:8080/reconciliation/export-csv \
  -H 'Content-Type: application/json' \
  -d '{"workflowId":"saga2-transfer-workflow","status":"ROLLED_BACK"}'
```

回應(成功)/ 失敗:

```json
// HTTP 200(ok=true)
{ "ok": true, "filePath": "…", "fileName": "reconciliation-20260823-111500.csv", "rowCount": 42, "byteSize": 8210, "exportedAt": "2026-08-23T11:15:00.321", "filters": { "workflowId": "saga2-transfer-workflow", "businessKey": "", "status": "ROLLED_BACK" } }
// HTTP 500(ok=false)
{ "ok": false, "error": "…" }
```

### 3.4 CSV 匯出檔案規格

`ReconciliationCsvExporter#exportToCsv` 的輸出契約:

| 項目 | 規格 | 原始碼依據 |
|------|------|-----------|
| 編碼 | **UTF-8 含 BOM**(`\ufeff`,讓 Excel 直接開中文不亂碼) | writer.write('\ufeff') |
| 表頭 | 固定 **16 欄**(下方全列) | `COLUMNS` 常數 |
| 檔名 | `reconciliation-YYYYMMDD-HHmmss.csv`(避免覆蓋) | `resolveCsvPath()` + `FILE_TS` formatter |
| 落地位置 | `data/` 目錄(經 `PlatformPaths.dataFile()` 跨平台解析;啟動時 `onStart` 先 ensure) | `PlatformPaths.ensureDataDirectory()` |
| 跳脫規則 | 值含逗號/雙引號/換行 → 整體雙引號包裹,內部 `"` 跳脫為 `""` | `escapeCsv()` |
| NULL 處理 | 輸出空字串 | `rs.getString` → null → escapeCsv("") |
| 排序 | `ORDER BY id ASC` | SQL 組裝 |
| 過濾 | workflow_id / business_key / status 三條件獨立,皆可省略 | 動態 SQL |
| 前置檢查 | view 不存在 → 不產檔,回 `{ok:false,…}` | getTables 檢查 |

16 欄表頭(欄名同名於 view `vw_saga_reconciliation`;注意末兩欄順序與 view 相反——CSV 為 `a16229_rollback_code, a16220_rollback_code`,view 為 `a16220_rollback_code` 在前,比對請依欄名而非位置):

```
id, created_at, workflow_id, business_key, process_instance_id, status, message,
account_a, account_b, amt,
a16229_code, a16229_msg, a16220_code, a16220_msg,
a16229_rollback_code, a16220_rollback_code
```

CSV 檔案樣例(前兩列):

```text
﻿id,created_at,workflow_id,business_key,process_instance_id,status,message,account_a,account_b,amt,a16229_code,a16229_msg,a16220_code,a16220_msg,a16229_rollback_code,a16220_rollback_code
1,2026-08-23 10:15:30,saga2-transfer-workflow,Alice_001,8f3c-…,SUCCESS,交易成功,Alice_001,Bob_002,100,100,成功,100,成功,,
```

> `ReconciliationCsvExporter` 另提供 workflow function 進入點 `exportReconciliationCsv`(JsonNode/Map/三參數/無參數 4 種多載),供 workflow 端點自動匯出;但預設 workflow 不呼叫它,主要觸發介面就是上述 REST endpoint(Javadoc 明文聲明)。

---

## 4. 常見錯誤

| 症狀 | 原因 | 解法 |
|------|------|------|
| 打 `POST /A16229` 得 403 `Request不可為空` | body 不是合法 JSON 或 Content-Type 非 `application/json` | 補 `-H 'Content-Type: application/json'`,確認 body 合法 |
| 想測 RBFAIL 卻一直成功 | 哨兵需要 **EC=true 且帳號=RBFAIL** 同時成立;`EC=false` 時 RBFAIL 只是普通帳號 | 回沖測試請求改 `EC:true`(或走 workflow 全回沖路徑 AMT>500) |
| workflow 回 400 但不知哪個欄位錯 | `ValidateInput` 只回第一個命中的分類,訊息為固定文案 | 依優先序自查:帳號 regex → AMT 型別 → AMT>0 → 同帳號 |
| workflow 回 200 但 status=FAILED,想看細節 | 輸出僅收斂 `{code,message,errorType,_httpStatus}` | 查 `GET /api/reconciliation/trace/{instanceId}` 的 `outputArgs`,或 [../02-architecture/OBSERVABILITY.md](../02-architecture/OBSERVABILITY.md) |
| `POST /api/reconciliation/export-csv` 回 `View vw_saga_reconciliation 不存在` | 尚未有 workflow 執行過(AuditLogService 未初始化遷移) | 先跑一筆轉帳,或確認兩 app 指向同一 `data/reconciliation.db` |
| 8090 上 retry/cancel job「成功」但沒生效 | 例外被吞、回應恆 `success:true`;且 8090 DataSource 為 read-only | 改打 8080;以 updatedRows + 日誌核實 |
| `GET /api/reconciliation/files/{filename}` 回空字串 | 檔名不存在(或不在 data/ 目錄) | 先 `GET /files` 取得清單 |
| proxy-test 打到別的 workflow 沒反應 | `workflowPath` 拼錯(會直接拼到 URL 後面) | workflow id 清單:saga2-transfer-workflow / saga-transfer-workflow / java-workflow / rest-workflow / OpenAPI-workflow |
| GraphQL proxy 回 `status_code: 500, error` | 8080 引擎未啟動,或 query 語法錯(Data Index 仍會回 200+errors) | 先 ping 8080;query 見 OBSERVABILITY 文件 |
| CSV 用 Excel 開亂碼 | 檔案被中途重新存檔失去 BOM,或用了舊版匯出 | 重新匯出;確認檔頭含 BOM(`\ufeff`) |
| 同一筆轉帳打了兩次,資料重複 | workflow **冪等性需呼叫端保證**(YAML 冪等性註記:未內建去重) | 呼叫端帶 `Idempotency-Key` 由入口層去重 |

---

> 延伸閱讀:[SERVICE-REFERENCE.md](SERVICE-REFERENCE.md)(四大服務內部行為)、[DATABASE-REFERENCE.md](DATABASE-REFERENCE.md)(vw_saga_reconciliation / workflow_execution_log 全表)、[CONFIG-REFERENCE.md](CONFIG-REFERENCE.md)(status-rewrite / kogito.sw.* 參數)、[../07-operations/TROUBLESHOOTING.md](../07-operations/TROUBLESHOOTING.md)(症狀對照)。
