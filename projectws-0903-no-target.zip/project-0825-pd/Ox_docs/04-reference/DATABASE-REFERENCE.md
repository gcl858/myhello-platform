# DATABASE-REFERENCE — reconciliation.db 完整資料庫手冊

> 本文為 Ox_docs 第 04 冊《資料庫參考》,100% 基於原始碼與 SQL 腳本撰寫,涵蓋:
>
> | 主題 | 一句話 |
> |------|--------|
> | [reconciliation.db 全覽](#1-reconciliationdb-全覽) | 單一 SQLite 檔、雙 app 共享、兩套 schema 管理體系 |
> | [workflow_execution_log](#2-workflow_execution_log--稽核主表) | 稽核主表逐欄解析 + 寫入者 AuditLogService |
> | [vw_saga_reconciliation](#3-vw_saga_reconciliation--saga2-對帳視圖) | json_extract 欄位對應、查詢/CSV/fallback 三用途 |
> | [遷移體系](#4-遷移體系) | 自製 DatabaseMigrationRunner + kie-flyway 22 支腳本 |
> | [jobs / nodes / processes](#5-jobs-nodes-processes--data-index-核心表實務查詢) | Data Index 核心表在 AuditQueryService 的實際用法 |
> | [WAL 運維](#6-wal-與連線運維) | PRAGMA 三件套、連線池 max-size=1、read-only 模式 |
> | [SQLite timestamp 特殊處理](#7-data-index-sqlite-timestamp-特殊處理) | KogitoSQLiteDialect + SqliteZonedDateTimeJdbcType 修 bug 始末 |
>
> 術語定義見 [../README.md](../README.md);服務行為細節見 [SERVICE-REFERENCE.md](SERVICE-REFERENCE.md);
> 對外 API 見 [REST-API-REFERENCE.md](REST-API-REFERENCE.md);整體部署模型見 [../02-architecture/ARCHITECTURE.md](../02-architecture/ARCHITECTURE.md)。
> 引用慣例:`類別#方法` 或 SQL 檔名;行號僅輔助且可能隨版本變動。

---

## 目錄

- [1. reconciliation.db 全覽](#1-reconciliationdb-全覽)
  - [1.1 檔案位置與共享模型](#11-檔案位置與共享模型)
  - [1.2 兩套 schema 管理體系](#12-兩套-schema-管理體系)
  - [1.3 ER 概念圖](#13-er-概念圖)
  - [1.4 全部物件清單](#14-全部物件清單)
- [2. workflow_execution_log — 稽核主表](#2-workflow_execution_log--稽核主表)
  - [2.1 逐欄位表](#21-逐欄位表)
  - [2.2 索引](#22-索引)
  - [2.3 唯一寫入者:AuditLogService](#23-唯一寫入者auditlogservice)
- [3. vw_saga_reconciliation — Saga2 對帳視圖](#3-vw_saga_reconciliation--saga2-對帳視圖)
  - [3.1 view 定義](#31-view-定義)
  - [3.2 json_extract 欄位對應表(逐欄)](#32-json_extract-欄位對應表逐欄)
  - [3.3 三大用途:查詢 / CSV 匯出 / raw fallback](#33-三大用途查詢--csv-匯出--raw-fallback)
- [4. 遷移體系](#4-遷移體系)
  - [4.1 自製 DatabaseMigrationRunner](#41-自製-databasemigrationrunner)
  - [4.2 reconciliation_schema_history 逐欄表](#42-reconciliation_schema_history-逐欄表)
  - [4.3 kie-flyway:Data Index 22 支腳本演進摘要](#43-kie-flywaydata-index-22-支腳本演進摘要)
  - [4.4 V1.32.0 基礎表群(逐表結構)](#44-v1320-基礎表群逐表結構)
  - [4.5 V1.44.0 definitions 群](#45-v1440-definitions-群)
- [5. jobs / nodes / processes — Data Index 核心表實務查詢](#5-jobs-nodes-processes--data-index-核心表實務查詢)
  - [5.1 jobs 表](#51-jobs-表)
  - [5.2 processes 表](#52-processes-表)
  - [5.3 nodes 表](#53-nodes-表)
- [6. WAL 與連線運維](#6-wal-與連線運維)
- [7. Data Index SQLite timestamp 特殊處理](#7-data-index-sqlite-timestamp-特殊處理)
- [8. 常見錯誤](#8-常見錯誤)

---

## 1. reconciliation.db 全覽

### 1.1 檔案位置與共享模型

本平台**只有一個業務資料庫檔案**:`reconciliation.db`(SQLite)。位置由 `PlatformPaths` 統一解析:

| 項目 | 值 | 依據 |
|------|-----|------|
| 檔名常數 | `DB_FILE_NAME = "reconciliation.db"` | `AuditLogService` 類別常數 |
| 所在目錄 | `${MYHELLO_DATA_DIR}`(預設=專案根目錄下 `data/`) | `PlatformPaths#dataDirectory` |
| JDBC URL(程式端) | `jdbc:sqlite:<絕對路徑>` | `PlatformPaths#sqliteUrl` |
| JDBC URL(配置端) | `jdbc:sqlite:${MYHELLO_DATA_DIR:data}/reconciliation.db` | platform-data-index `application.properties` |

兩個 Quarkus 應用共享同一檔案:`transfer-app`(:8080,讀寫,由 `AuditLogService` 寫入稽核紀錄)與
`reconciliation-app`(:8090,**唯讀**,只做查詢/匯出),靠 WAL 模式並存(見[第 6 節](#6-wal-與連線運維))。
部署模型詳見 [../02-architecture/ARCHITECTURE.md](../02-architecture/ARCHITECTURE.md)。

### 1.2 兩套 schema 管理體系

同一個 `.db` 檔內的表,來自**兩條互不隸屬的遷移管線**:

| 體系 | 執行者 | 腳本來源 classpath 目錄 | 歷史紀錄表 | 啟動時機 |
|------|--------|--------------------------|-----------|----------|
| 自製 Flyway 式 runner | `DatabaseMigrationRunner#runMigrations` | `db/migration/`(各 domain 模組 resources) | `reconciliation_schema_history` | app 啟動 `AuditLogService#initDatabase`(`@Observes StartupEvent`) |
| KIE 官方 kie-flyway | KIE addon 內建機制(原始碼不在本倉庫) | `kie-flyway/db/data-index/sqlite/`(platform-extensions 打包) | 由 KIE flyway 機制自管 | Data Index 啟動,受 `kie.flyway.enabled=true` 控制(platform-data-index `application.properties`) |

Hibernate **不做** schema 管理:三處設定均關閉
(`quarkus.hibernate-orm.database.generation=none`、`schema-management.strategy=none`、`validate-in-dev-mode=false`),
schema 唯一事實來源就是上述 SQL 腳本。

### 1.3 ER 概念圖

```mermaid
erDiagram
    vw_saga_reconciliation ||..|{ workflow_execution_log : "view 衍生(WHERE workflow_id='saga2-transfer-workflow')"

    workflow_execution_log {
        INTEGER id PK
        TEXT workflow_id
        TEXT business_key
        TEXT process_instance_id
        TEXT status
        TEXT message
        TEXT input_data
        TEXT output_data
        TIMESTAMP created_at
    }

    reconciliation_schema_history {
        INTEGER installed_rank PK
        TEXT version UK
        TEXT description
        TEXT type
        TEXT script
        INTEGER checksum
        TEXT installed_by
        TIMESTAMP installed_on
        INTEGER execution_time
        BOOLEAN success
    }

    processes {
        TEXT id PK
        TEXT process_id
        TEXT version
        INTEGER state
        TEXT start_time
        TEXT end_time
        TEXT variables
        TEXT sla_due_date
        TEXT cloud_event_id
    }
    nodes {
        TEXT id PK
        TEXT process_instance_id FK
        TEXT name
        TEXT type
        TEXT enter
        TEXT exit
        TEXT sla_due_date
        INTEGER retrigger
        TEXT error_message
        TEXT input_args
        TEXT output_args
    }
    jobs {
        TEXT id PK
        TEXT process_id
        TEXT process_instance_id
        TEXT status
        TEXT expiration_time
        INTEGER retries
        TEXT exception_message
    }
    tasks {
        TEXT id PK
        TEXT process_instance_id
        TEXT state
    }
    attachments_comments_roles {
        TEXT task_id FK
    }
    definitions {
        TEXT id PK
        TEXT version PK
        TEXT source
        TEXT metadata
    }
    definitions_children {
        TEXT process_id FK
        TEXT process_version FK
    }
    milestones {
        TEXT id PK
        TEXT process_instance_id FK
    }

    processes ||--o{ nodes : "FK ON DELETE CASCADE"
    processes ||--o{ milestones : "FK ON DELETE CASCADE"
    tasks ||--o{ attachments_comments_roles : "task_id FK CASCADE"
    definitions ||--o{ definitions_children : "(id,version) FK CASCADE"
    processes |o..o{ jobs : "邏輯關聯(無 FK 宣告)"
```

> 讀法:`workflow_execution_log` 與 `reconciliation_schema_history` 屬「稽核/遷移」域(自製 runner 管);
> 其餘屬「Data Index」域(kie-flyway 管)。`jobs` 對 `processes` 只有欄位值的邏輯關聯,
> `V1.32.0__data_index_create.sql` 中未宣告 FOREIGN KEY。

### 1.4 全部物件清單

| 物件 | 類型 | 建立者 | 用途 |
|------|------|--------|------|
| `workflow_execution_log` | TABLE | V1.0.0__create_workflow_execution_log.sql | 全系統流程執行稽核紀錄 |
| `idx_wel_process_instance_id` | INDEX | 同上 | 依 process instance 查稽核 |
| `idx_wel_workflow_business_key` | INDEX | 同上 | 依 workflow+business key 查稽核 |
| `vw_saga_reconciliation` | VIEW | V1.1.0__create_view_transfer_reconciliation.sql | saga2 對帳扁平化視圖 |
| `reconciliation_schema_history` | TABLE | `DatabaseMigrationRunner#ensureHistoryTable` | 自製遷移歷史 |
| `processes` / `nodes` / `jobs` / `tasks` / `milestones` | TABLE | V1.32.0__data_index_create.sql | Data Index 核心 |
| `attachments` / `comments` | TABLE | 同上 | human task 附件/留言 |
| `processes_addons` / `processes_roles` | TABLE | 同上 | process 附屬資訊 |
| `tasks_admin_groups` 等 5 張 task 子表 | TABLE | 同上 | task 角色授權 |
| `definitions`(+addons/roles/nodes/metadata/annotations) | TABLE | V1.44.0、V1.45.0.x 系列 | workflow 定義註冊簿 |

---

## 2. workflow_execution_log — 稽核主表

SQL 來源:`domain-reconciliation/reconciliation-api/src/main/resources/db/migration/V1.0.0__create_workflow_execution_log.sql`

### 2.1 逐欄位表

| 欄位 | 型別 | 約束 | 語意 | 實際寫入值(AuditLogService#doSaveLog) |
|------|------|------|------|----------------------------------------|
| `id` | INTEGER | PRIMARY KEY AUTOINCREMENT | 流水號 | SQLite 自動指派 |
| `workflow_id` | TEXT | — | workflow 定義 id | `saveLog(...)` 第 1 參;JsonNode 版取 `arguments.workflowId`,缺省 `"unknown-workflow"` |
| `business_key` | TEXT | — | 業務鍵(轉帳場景=帳號組合識別) | 第 2 參 `toString()`;可 null |
| `process_instance_id` | TEXT | — | Kogito process instance UUID | 第 3 參 `toString()`;可 null(舊 4 參多載傳 null) |
| `status` | TEXT | — | 工作流輸出狀態(finalStatus 口徑) | 取 `output_data.status`;無則 `"UNKNOWN"` |
| `message` | TEXT | — | 工作流輸出訊息 | 取 `output_data.message`;無則空字串 |
| `input_data` | TEXT | — | 輸入 JSON 字串 | Jackson 序列化;null → `{}` |
| `output_data` | TEXT | — | 輸出 JSON 字串 | Jackson 序列化;null → `{}` |
| `created_at` | TIMESTAMP | DEFAULT CURRENT_TIMESTAMP | 寫入時間 | SQLite 自動填入 |

> `status` 的可能值即 README 術語表的 finalStatus 家族:`SUCCESS` / `FAILED` / `ROLLED_BACK` /
> `ROLLBACK_FAILED` / `VALIDATION_FAILED`(以及引擎未輸出時的 `UNKNOWN`)。

### 2.2 索引

| 索引名 | 欄位 | 典型受益查詢 |
|--------|------|--------------|
| `idx_wel_process_instance_id` | `(process_instance_id)` | 以 instance UUID 反查稽核紀錄 |
| `idx_wel_workflow_business_key` | `(workflow_id, business_key)` | CSV 匯出、特定業務鍵追蹤 |

### 2.3 唯一寫入者:AuditLogService

原始碼:`domain-reconciliation/reconciliation-api/src/main/java/com/example/reconciliation/AuditLogService.java`
(行為細節另見 [SERVICE-REFERENCE.md §2](SERVICE-REFERENCE.md))

要點:

1. **四種 `saveLog` 多載**(5 參 / 4 參相容版 / `JsonNode` / `Map`),最後都收斂到 `doSaveLog`,
   執行固定 INSERT(7 個綁定參數,不含 `id`/`created_at`)。
2. **啟動初始化**:`onStart(@Observes StartupEvent)` → `initDatabase()`——以 `AtomicBoolean` +
   `synchronized` 雙重檢查確保只跑一次;先執行 PRAGMA 三件套(§6),再呼叫
   `DatabaseMigrationRunner#runMigrations`。
3. **取得連線**:`getConnection()` 優先用注入的 Quarkus `DataSource`;
   DataSource 未注入時 fallback `DriverManager` + `PlatformPaths#sqliteUrl("reconciliation.db")`,
   並打 WARN 提醒「備用 URL 與 `quarkus.datasource.jdbc.url` 可能不一致造成資料分裂」。
4. **寫入失敗不丟例外**:catch 後回 `{saved:false, error:...}`,讓 workflow 端拿到明確結果而非炸掉交易。
5. 寫入成功日誌走一般 LOG;`[AuditLogService] 成功寫入對帳紀錄! ...` 可作為落地證據。

---

## 3. vw_saga_reconciliation — Saga2 對帳視圖

SQL 來源:`domain-transfer/transfer-workflow/src/main/resources/db/migration/V1.1.0__create_view_transfer_reconciliation.sql`

### 3.1 view 定義

```sql
CREATE VIEW IF NOT EXISTS vw_saga_reconciliation AS
SELECT id, created_at, workflow_id, business_key, process_instance_id, status, message,
       json_extract(input_data,  '$.Account_A') AS account_a,
       json_extract(input_data,  '$.Account_B') AS account_b,
       json_extract(input_data,  '$.AMT')       AS amt,
       json_extract(output_data, '$.a16229Result.code')    AS a16229_code,
       json_extract(output_data, '$.a16229Result.message') AS a16229_msg,
       json_extract(output_data, '$.a16220Result.code')    AS a16220_code,
       json_extract(output_data, '$.a16220Result.message') AS a16220_msg,
       json_extract(output_data, '$.a16220Rollback.code')  AS a16220_rollback_code,
       json_extract(output_data, '$.a16229Rollback.code')  AS a16229_rollback_code
FROM workflow_execution_log
WHERE workflow_id = 'saga2-transfer-workflow';
```

### 3.2 json_extract 欄位對應表(逐欄)

以下每一列都直接對照 V1.1.0 SQL 逐欄核對:

| # | view 欄位(alias) | 來源表欄位 | JSON path | 語意 |
|---|--------------------|------------|-----------|------|
| 1 | `id` | workflow_execution_log.id | —(直通) | 紀錄流水號 |
| 2 | `created_at` | workflow_execution_log.created_at | —(直通) | 寫入時間 |
| 3 | `workflow_id` | workflow_execution_log.workflow_id | —(直通) | 恆為 `saga2-transfer-workflow`(WHERE 過濾) |
| 4 | `business_key` | workflow_execution_log.business_key | —(直通) | 業務鍵 |
| 5 | `process_instance_id` | workflow_execution_log.process_instance_id | —(直通) | 引擎實例 UUID |
| 6 | `status` | workflow_execution_log.status | —(直通) | finalStatus(SUCCESS/FAILED/ROLLED_BACK/ROLLBACK_FAILED/VALIDATION_FAILED) |
| 7 | `message` | workflow_execution_log.message | —(直通) | 輸出訊息 |
| 8 | `account_a` | input_data | `$.Account_A` | 轉出帳號 A |
| 9 | `account_b` | input_data | `$.Account_B` | 轉入帳號 B |
| 10 | `amt` | input_data | `$.AMT` | 轉帳金額 |
| 11 | `a16229_code` | output_data | `$.a16229Result.code` | A16229(扣款)回應碼 |
| 12 | `a16229_msg` | output_data | `$.a16229Result.message` | A16229 回應訊息 |
| 13 | `a16220_code` | output_data | `$.a16220Result.code` | A16220(入帳)回應碼 |
| 14 | `a16220_msg` | output_data | `$.a16220Result.message` | A16220 回應訊息 |
| 15 | `a16220_rollback_code` | output_data | `$.a16220Rollback.code` | A16220 回沖(RollbackA16220,EC=true)結果碼 |
| 16 | `a16229_rollback_code` | output_data | `$.a16229Rollback.code` | A16229 回沖(RollbackA16229,EC=true)結果碼 |

> 注意:JSON path 大小寫敏感(`Account_A` 大寫開頭、`a16229Result` 小駝峰),
> 與 `saga2-transfer-workflow.sw.yaml` 的輸入/輸出欄位命名一致;
> 若上游 workflow 改名而未同步改此 view,對應欄會靜默變成 NULL(json_extract 找不到路徑回 NULL,不報錯)。

### 3.3 三大用途:查詢 / CSV 匯出 / raw fallback

全部消費端都在 `AuditQueryService`(reconciliation-api):

| 用途 | 方法 | 行為 |
|------|------|------|
| 動態查詢 | `AuditQueryService#getReconciliationRecords` | `SELECT * FROM vw_saga_reconciliation WHERE 1=1` 再依參數串接:`account_a LIKE %x%`、`account_b LIKE %x%`、`status = ?`(`ALL` 忽略)、`amt >= ?`、`amt <= ?`;`ORDER BY id DESC LIMIT 100` |
| 手動 CSV 匯出 | `AuditQueryService#exportCsv` → `ReconciliationCsvExporter#exportToCsv` | 匯出 `reconciliation-*.csv` 至 data 目錄;歷史檔列表見 `getReconciliationFiles` |
| 失敗 fallback | 同方法 catch 內 → `getRawLogRecords()` | view 不存在或查詢失敗時,改查 `SELECT * FROM workflow_execution_log ORDER BY id DESC LIMIT 50` 保住基本可观测性 |

---

## 4. 遷移體系

### 4.1 自製 DatabaseMigrationRunner

原始碼:`domain-reconciliation/reconciliation-api/src/main/java/com/example/reconciliation/migration/DatabaseMigrationRunner.java`

一個「Flyway 命名規範相容」的極簡遷移器(類 Javadoc 自述):掃描 classpath `db/migration/`,
按語意版本排序執行,歷史存於 `reconciliation_schema_history`。

| 機制 | 實作(`DatabaseMigrationRunner#…`) | 細節 |
|------|------------------------------------|------|
| 檔名規範 | 正則 `^V([0-9]+(?:\.[0-9]+)*)__(.+)\.sql$` | `V{version}__{description}.sql`,description 底線在 history 中轉空格 |
| 掃描 | `discoverMigrationScripts` | 支援 `file:` 目錄與 `jar:` 兩種 protocol;同名腳本去重;另有硬編碼 fallback 清單(V1.0.0/V1.1.0)防容器環境枚舉不全 |
| 版本排序 | `compareVersions` | 逐段 `Integer.parseInt` 數值比較,缺段補 0(故 `1.45.1.0 > 1.45.0.9`) |
| 已套用跳過 | `runMigrations` 主迴圈 | 只看 `reconciliation_schema_history` 中 `success = 1` 的 version 集合;**版本存在即跳過,不以 checksum 比對漂移**(checksum 僅記錄供人工核對) |
| Checksum | `calculateChecksum` | CRC32;計算前先把 `\r\n` 正規化為 `\n`,避免跨平台換行差異 |
| SQL 切割 | `splitSqlStatements` | 依分號切分,正確略過 `--` 行註解、`/* */` 區塊註解與單引號字串內的分號 |
| 歷史寫入 | `recordMigrationSuccess` | INSERT 含 version/description/type='SQL'/script/checksum/installed_by=`user.name`/execution_time/success=1 |
| 執行緒安全 | `runMigrations` 為 `static synchronized` | 多 app 同檔啟動時仍靠 SQLite 鎖 + busy_timeout 兜底(§6) |
| 失敗語意 | runMigrations catch → 重拋 RuntimeException | 但注意:`AuditLogService#initDatabase` 外層把例外吞成 ERROR log,app 不會因此起不來 |

目前自製管線下的腳本(全平台僅 2 支,雙模組各持一份、內容相同):

| 腳本 | 所在模組(canonical) | 內容 |
|------|-----------------------|------|
| V1.0.0__create_workflow_execution_log.sql | domain-reconciliation/reconciliation-api | 稽核主表 + 2 索引(§2) |
| V1.1.0__create_view_transfer_reconciliation.sql | domain-transfer/transfer-workflow | saga2 對帳 view(§3) |

> 「單一事實來源」規則:canonical 在 `domain-*` 模組,`distribution/transfer-app/src/main/resources/db/migration`
> 下為建置同步副本,勿手改(README 術語表)。

### 4.2 reconciliation_schema_history 逐欄表

DDL 出自 `DatabaseMigrationRunner#ensureHistoryTable`:

| 欄位 | 型別 | 約束 | 語意 |
|------|------|------|------|
| `installed_rank` | INTEGER | PRIMARY KEY AUTOINCREMENT | 套用順序 |
| `version` | TEXT | NOT NULL UNIQUE | 腳本版本(去重鍵) |
| `description` | TEXT | NOT NULL | 檔名描述段(底線→空格) |
| `type` | TEXT | NOT NULL DEFAULT `'SQL'` | 固定 SQL |
| `script` | TEXT | NOT NULL | 完整檔名 |
| `checksum` | INTEGER | — | CRC32(僅記錄,不參與 skip 判斷) |
| `installed_by` | TEXT | — | `System.getProperty("user.name","system")` |
| `installed_on` | TIMESTAMP | DEFAULT CURRENT_TIMESTAMP | 安裝時間 |
| `execution_time` | INTEGER | — | 耗時(ms) |
| `success` | BOOLEAN | NOT NULL | 恆寫 1;失敗腳本不會留下紀錄(交易性質上「重試直到成功」) |

### 4.3 kie-flyway:Data Index 22 支腳本演進摘要

腳本位置:`platform-extensions/data-index-storage-sqlite/src/main/resources/kie-flyway/db/data-index/sqlite/`
(共 22 支,皆為 Apache KIE 上游 PostgreSQL 腳本的 SQLite 移植)。啟用開關:`kie.flyway.enabled=true`。

版本軸總表(檔名歸納 + 主要腳本已實讀):

| 版本 | 檔名後綴 | 演進重點 |
|------|----------|----------|
| V1.32.0 | data_index_create | **基礎 13 張表**建立(§4.4);型別映射註記 bytea→BLOB、jsonb→TEXT、timestamp→TEXT、boolean→INTEGER(0/1) |
| V1.44.0 | data_index_definitions | 新增 `definitions` 群 3 表 + `processes.version` 欄(§4.5) |
| V1.45.0.0 | node_definitions | `definitions_nodes` + `definitions_nodes_metadata` |
| V1.45.0.1 | add_identity_to_process_instance | `processes.created_by` / `updated_by` |
| V1.45.0.2 | definitions_add_columns | `definitions_annotations`、`definitions_metadata`、`definitions.description` |
| V1.45.0.3 | add_fk_index | 17 支 FK 索引(idx_*_tid / _pid_pv / _piid / _pid) |
| V1.45.0.4 | increase_varchar_length | **SQLite no-op**(varchar 長度無意義,僅註解) |
| V1.45.0.5 | add_external_reference_id | `tasks.external_reference_id` |
| V1.45.0.6 | add_sla_due_date_columns | **SLA 欄**:`processes.sla_due_date`、`nodes.sla_due_date` |
| V1.45.0.7 | add_sla_due_date_tasks | **SLA 欄**:`tasks.sla_due_date` |
| V1.45.0.8 | modify_columns_with_reserved_words | 保留字改名:metadata 表 `key`→`name`、`value`→`meta_value`;annotations `value`→`annotation` |
| V1.45.0.9 | increase_comments_content_size | **SQLite no-op** |
| V1.45.1.0 | metadata_as_jsonb | `definitions.metadata`(TEXT)新增 ← `json_group_object` 聚合回填 → DROP `definitions_metadata` 表 |
| V1.45.1.1 | retrigger | **retrigger 支撐欄**:`nodes.retrigger`(DEFAULT 0)、`nodes.error_message`、`processes.node_instance_id` |
| V1.45.1.2 | cloudevent | **CloudEvent 欄**:`processes.cloud_event_id`、`cloud_event_source` |
| V1.45.1.3 | add_cancelled_type_nodes | `nodes.cancel_type` |
| V1.45.1.4 | add_indexes_for_jobs_and_tasks | `idx_jobs_piid`、`idx_tasks_piid` |
| V1.46.0 | add_user_task_id_column | `tasks.user_task_id` |
| V1.47.0 | adjust_column_sizes_in_tables_updated_by_hibernate | **SQLite no-op** |
| V1.48.0 | add_input_output_args | `nodes.input_args`、`nodes.output_args`(節點軌跡 UI 資料來源) |
| V1.49.0 | add_job_exception_details | `jobs.exception_message`、`jobs.exception_details` |
| V1.50.0 | definitions_upsert_trigger | `BEFORE INSERT` 觸發器模擬 upsert:同 `(id,version)` 存在則先 DELETE |

> 三支 no-op(V1.45.0.4/.9、V1.47.0)保留版本號是為了與上游 PostgreSQL 腳本序號對齊;
> 實測以 grep 確認其內容無任何 `ALTER/CREATE/UPDATE/DROP` 語句。

### 4.4 V1.32.0 基礎表群(逐表結構)

摘自 `V1.32.0__data_index_create.sql`(SQLite port;完整欄位以檔案為準,此處列主要欄位與約束):

| 表 | 主鍵 | 外鍵 | 主要欄位 |
|----|------|------|----------|
| `attachments` | `id` | `task_id → tasks(id)` CASCADE | content, name, updated_at, updated_by |
| `comments` | `id` | `task_id → tasks(id)` CASCADE | content, name, updated_at, updated_by |
| `jobs` | `id` | **無 FK** | callback_endpoint, endpoint, execution_counter, expiration_time, last_update, node_instance_id, priority, process_id, process_instance_id, repeat_interval, repeat_limit, retries, root_process_id, root_process_instance_id, scheduled_id, status |
| `milestones` | `(id, process_instance_id)` | `process_instance_id → processes(id)` CASCADE | name, status |
| `nodes` | `id` | `process_instance_id → processes(id)` CASCADE | definition_id, enter, exit, name, node_id, type |
| `processes` | `id` | — | business_key, end_time, endpoint, message, node_definition_id, last_update_time, parent_process_instance_id, process_id, process_name, root_process_id, root_process_instance_id, start_time, state(INTEGER), variables(TEXT,原 jsonb) |
| `processes_addons` | `(process_id, addon)` | → processes CASCADE | — |
| `processes_roles` | `(process_id, role)` | → processes CASCADE | — |
| `tasks` | `id` | — | actual_owner, completed, description, endpoint, inputs(TEXT,原 jsonb), last_update, name, outputs(TEXT,原 jsonb), priority, process_id, process_instance_id, reference_name, root_process_id, root_process_instance_id, started, state |
| `tasks_admin_groups` / `tasks_admin_users` / `tasks_excluded_users` / `tasks_potential_groups` / `tasks_potential_users` | `(task_id, 群/人 id)` | `task_id → tasks(id)` CASCADE | — |

檔頭註記的重點:SQLite 版不需 PostgreSQL 的 drop-then-add-FK 手法(`CREATE TABLE IF NOT EXISTS` 即可);
FK 為 inline 宣告,**runtime 每條連線需 `PRAGMA foreign_keys = ON`**(本平台經
`additional-jdbc-properties.foreign_keys=true` 配置,§6)。

### 4.5 V1.44.0 definitions 群

摘自 `V1.44.0__data_index_definitions.sql`:

| 表/變更 | 結構 |
|---------|------|
| `definitions` | `id TEXT + version TEXT` 複合主鍵;name, type, source(BLOB,原 bytea), endpoint |
| `definitions_addons` | `(process_id, process_version, addon)` PK;FK → definitions(id,version) CASCADE |
| `definitions_roles` | `(process_id, process_version, role)` PK;同上 FK |
| `processes` | `ALTER TABLE … ADD COLUMN version TEXT` |

---

## 5. jobs / nodes / processes — Data Index 核心表實務查詢

消費者皆為 `AuditQueryService`(reconciliation-app :8090 的 UI/REST 後盾)。

### 5.1 jobs 表

| 使用點(`AuditQueryService#…`) | SQL 欄位 |
|-------------------------------|----------|
| `getJobsRecords(statusFilter)` | SELECT `id, process_id, process_instance_id, status, expiration_time, retries, callback_endpoint, exception_message` FROM jobs;`ORDER BY last_update DESC LIMIT 50`;statusFilter 非 ALL 時加 `AND status = ?` |
| `retryJob(jobId)` | `UPDATE jobs SET status='RETRY', retries=retries+1 WHERE id=?` |
| `cancelJob(jobId)` | `UPDATE jobs SET status='CANCELED' WHERE id=?` |

- `expiration_time` / `last_update` 是 epoch ms 字串(TEXT),UI 顯示前經私有方法
  `formatTimestamp` 轉系統時區 LocalDateTime;非數字字串則原樣返回。
- `exception_message` 欄位由 V1.49.0 加入——若 DB 由過舊腳本建立而未升級,查詢會報
  "no such column" 並被 catch 成 WARN、回空陣列。

### 5.2 processes 表

| 使用點 | SQL 欄位 |
|--------|----------|
| `getRecentInstances()` | SELECT `id, process_id, process_name, state, start_time, end_time, variables` ORDER BY `start_time DESC` LIMIT 50 |
| `getInstanceTrace(instanceId)` | 同欄位,`WHERE id LIKE '%<instanceId>%' LIMIT 1`(支援部分 UUID) |

`variables` 解析邏輯(兩方法相同):

1. `MAPPER.readTree(varsStr)`,優先取子物件 `workflowdata`;
2. 業務狀態:`finalStatus` → 退 `status`;業務訊息:`finalMessage` → 退 `message`;
3. `getInstanceTrace` 另以 `varsStr.contains("ROLLED_BACK") || varsStr.contains("回沖")`
   直接判定 trace 狀態標籤(粗粒度但免解析失敗風險)。

### 5.3 nodes 表

`getInstanceTrace` → 私有方法 `getRealNodesFromDb(conn, fullId)`:

```sql
SELECT id, name, type, enter, exit, error_message, input_args, output_args
FROM nodes WHERE process_instance_id = ? ORDER BY enter ASC, id ASC
```

| 欄位 | 來源版本 | UI 呈現 |
|------|----------|---------|
| `id`,`name`,`type` | V1.32.0 | 節點軌跡基本資訊 |
| `enter`,`exit` | V1.32.0(epoch ms 字串) | `formatTimestamp` 轉顯示時間 |
| `error_message` | V1.45.1.1 | 有值才放 `errorMessage` |
| `input_args`,`output_args` | V1.48.0 | 嘗試 parse 成 JSON(`inputArgs`/`outputArgs`),失敗退原字串 |

---

## 6. WAL 與連線運維

### 6.1 PRAGMA 三件套(程式端)

`AuditLogService#initDatabase` 於每次 app 啟動執行一次(AtomicBoolean 保證):

```java
PRAGMA journal_mode=WAL;     // 寫前日誌 → 讀寫不互斥,雙 app 共享檔案的基礎
PRAGMA synchronous=NORMAL;   // WAL 下安全且快速的持久化等級
PRAGMA busy_timeout=5000;    // 鎖競爭時最多等 5000ms 再回報 SQLITE_BUSY
```

### 6.2 PRAGMA / 連線池(配置端)

platform-data-index `application.properties`(兩 app 共同繼承):

| 參數 | 值 | 效果 |
|------|-----|------|
| `quarkus.datasource.jdbc.max-size` | `1` | 單 app 僅 1 條連線,將 SQLite 檔鎖競爭降到最低(代價:併發查詢序列化) |
| `additional-jdbc-properties.foreign_keys` | `true` | 每條池內連線自動 ON,V1.32.0 inline FK 生效的前提 |
| `additional-jdbc-properties.journal_mode` | `WAL` | 與程式端 PRAGMA 雙保險 |
| `additional-jdbc-properties.synchronous` | `NORMAL` | 同上 |

### 6.3 read-only 模式(reconciliation-app)

- `distribution/reconciliation-app/src/main/resources/application.properties`:
  `quarkus.datasource.jdbc.read-only=true`(正式 profile);`%test` 下改 `false`。
- 目的:對帳 app 只准查詢,寫入一律回到 transfer-app 端 `AuditLogService`,避免雙寫者鎖衝突。
- **已知漏洞**(程式碼自我揭露,`AuditQueryService#getConnection`):
  若 `dataSource.getConnection()` 失敗(被鎖/read-only 拒絕等),fallback 走
  `DriverManager` 直連——**此路徑 bypass read-only 設定**。正常情況不觸發,但排查鎖問題時要知道這條暗門。

---

## 7. Data Index SQLite timestamp 特殊處理

背景:GraphQL ProcessInstances 查詢曾因 Hibernate 解析 SQLite TEXT 時間戳丟出
"Error parsing time stamp"(`DateTimeParseException`,KogitoSQLiteDialect 類 Javadoc 標注 issue #9)。
根因:xerial sqlite-jdbc 把時間戳存成**多種字串格式**,Hibernate 預設 JdbcType 只認其中一種。

解法 = 一個 Dialect + 一個自訂 JdbcType(均在 `platform-data-index` 模組):

### 7.1 KogitoSQLiteDialect

`org.acme.platform.dataindex.KogitoSQLiteDialect extends org.hibernate.community.dialect.SQLiteDialect`,
override `contributeTypes`(`KogitoSQLiteDialect#contributeTypes`):

1. 貢獻 `SqliteZonedDateTimeJdbcType.INSTANCE`(JDBC 側);
2. 貢獻 `SqliteZonedDateTimeJavaType.INSTANCE`(Java 側,來自 kogito addons runtime);
3. 另以 `BasicTypeImpl` 把兩者組合註冊成名稱 `"zdt"` / `"ZonedDateTime"` / FQN 三個別名。

配置掛接:`quarkus.hibernate-orm.dialect=org.acme.platform.dataindex.KogitoSQLiteDialect`(platform-data-index base)。

### 7.2 SqliteZonedDateTimeJdbcType

`SqliteZonedDateTimeJdbcType`(JDBC type code = `Types.VARCHAR`):

| 方向 | 行為(`SqliteZonedDateTimeJdbcType#…`) |
|------|----------------------------------------|
| 寫入 Binder(`doBind`) | `ZonedDateTime` → `toInstant().toEpochMilli()` → **epoch ms 十進位字串**(如 `"1786185258763"`)寫入 TEXT 欄 |
| 讀取 Extractor(`parseValue`) | 先嘗試 `Long.parseLong` → `Instant.ofEpochMilli().atZone(ZoneId.systemDefault())`;NumberFormatException 則 fallback `ZonedDateTime.parse(str)`(**ISO-8601**);兩者皆敗 → 回 null(不丟例外) |

配套:`quarkus.hibernate-orm.jdbc.timezone=UTC` 統一時區口徑;
`CamelCaseToUnderscoresNamingStrategy` 使 Java 駝峰欄位對應 SQL 蛇形命名。

### 7.3 連帶影響:Hibermate validation 必須關閉

platform-data-index `application.properties` 註解自述:Hibernate 6.x 解析 xerial driver 的
欄位 metadata(`IS_AUTOINCREMENT`/`COLUMN_DEF`)會在
`AbstractInformationExtractorImpl.columnInformation:651` 丟 `NoSuchElementException`,
因此三個 schema 校驗開關全設 none/false(§1.2)。Flyway 是 schema 唯一來源,校驗關閉即消除誤報。

---

## 8. 常見錯誤

| # | 症狀 | 原因 | 解法 |
|---|------|------|------|
| 1 | 啟動時 `database is locked`(SQLITE_BUSY) | 雙 app 同檔、busy_timeout 未生效或長交易佔鎖 | 確認 WAL PRAGMA 有跑(`[AuditLogService] SQLite 資料庫 (WAL 模式)…已就緒` log);確認 `max-size=1` 未被覆寫調大 |
| 2 | `no such column: exception_message`(jobs 查詢回空) | DB 由舊版腳本建立,V1.49.0 未套用 | 檢查 kie-flyway 歷史;勿手改表,讓遷移補齊 |
| 3 | 對帳欄位(account_a 等)全為 NULL | 上游 workflow 輸入/輸出鍵改名,json_extract path 失配(view 不報錯) | 對照 §3.2 表與 sw.yaml 欄位;同步修改 V1.1.0(需新版本腳本重建 view,勿改已套用腳本) |
| 4 | 改了 `V1.0.0__….sql` 內容卻沒生效 | 自製 runner 以 version 是否在 history 判 skip,**checksum 不參與判斷** | 已套用的腳本永不重跑;結構變更請新增 `V1.x.y__…sql` |
| 5 | GraphQL 查 instances 報 "Error parsing time stamp" | Dialect/JdbcType 未生效(dialect 配置被覆寫或模組未裝) | 確認 `quarkus.hibernate-orm.dialect=…KogitoSQLiteDialect` 且 platform-data-index 有打包 |
| 6 | reconciliation-app 查詢偶發成功、又見 read-only 相關 WARN | `AuditQueryService#getConnection` fallback DriverManager **bypass read-only** | 屬已知暗門(§6.3);根治是修復 DataSource 取線失敗的根本原因,而非依賴 fallback |
| 7 | 兩支 V1.1.0(transfer-workflow / distribution 副本)改了不同步 | 違反「單一事實來源」規則 | 只改 `domain-transfer/transfer-workflow` canonical,distribution 為建置同步副本 |
| 8 | 測試環境資料出現在正式 db(%test) | `%test.quarkus.datasource.jdbc.url=jdbc:sqlite:target/test-reconciliation.db` 僅 test profile 生效 | 確認啟動 profile;正式 db 一律在 `${MYHELLO_DATA_DIR}/reconciliation.db` |
