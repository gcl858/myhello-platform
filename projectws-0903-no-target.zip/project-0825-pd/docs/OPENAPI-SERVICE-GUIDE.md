# MyOpenApiService 通用 OpenAPI 服務使用手冊與架構指南

## 1. 概述 (Overview)

`MyOpenApiService` (`com.example.transfer.workflow.MyOpenApiService`) 是 SonataFlow / Kogito 工作流程中用於動態調用 OpenAPI 微服務的通用服務引擎。

傳統的 SonataFlow OpenAPI 調用方式通常需在編譯期透過 Kogito OpenAPI Codegen 產生專屬的 Client 類別與 Data Model，若 API 規格微調（如新增可選欄位或路徑調整），往往需要重新編譯與部署整包 Application。

`MyOpenApiService` 採用**執行期動態解析 (Runtime Spec-Driven Execution)** 與**多層高併發快取**架構：
- Workflow 僅需宣告標準 OpenAPI YAML 規格路徑與 `operationId`（例如 `specs/A16229-api.yaml#executeA16229`）。
- 執行期自動解析 HTTP Method、URL 路徑、路徑參數 (Path Params)、查詢參數 (Query Params)、Request Body 與 Headers。
- 支援非同步 HTTP 發送與標準化響應轉換，具備高併發、低延遲與強容錯特性。

```
                     ┌──────────────────────────────────────────────────────────┐
                     │               SonataFlow / Kogito Workflow               │
                     │           (saga2-transfer-workflow.sw.yaml)              │
                     └──────────────────────────────────────────────────────────┘
                                                  │
                                                  │ functionRef (custom type)
                                                  ▼
                     ┌──────────────────────────────────────────────────────────┐
                     │                  MyOpenApiService                        │
                     └──────────────────────────────────────────────────────────┘
                                                  │
         ┌──────────────────┬─────────────────────┼─────────────────────┬──────────────────┐
         │ (1) 規格定位與解析│ (2) Base URL 解析   │ (3) 參數與路徑建構  │ (4) 非同步 HTTP 發送│ (5) 響應標準化   │
         ▼                  ▼                     ▼                     ▼                  ▼
┌─────────────────┐ ┌────────────────┐ ┌────────────────────┐ ┌─────────────────┐ ┌────────────────┐
│ • specAstCache  │ │ • baseUrlCache │ │ • Path {param} 替換│ │ • JDK HttpClient│ │ • JSON Object  │
│   (YAML AST)    │ │ • MicroProfile │ │ • Query ?k=v 組裝  │ │   sendAsync()   │ │ • JSON Array   │
│ • operationCache│ │   Config 4大規則│ │ • Custom Headers   │ │ • Configurable  │ │ • 204 No Body  │
│   (Path/Method) │ │                │ │ • Request Body JSON│ │   Timeout       │ │ • code/status  │
└─────────────────┘ └────────────────┘ └────────────────────┘ └─────────────────┘ └────────────────┘
                                                  │
                                                  ▼
                     ┌──────────────────────────────────────────────────────────┐
                     │                 目標微服務 / RESTful API                  │
                     │                 (A16229 / A16220 / ...)                  │
                     └──────────────────────────────────────────────────────────┘
```

---

## 2. 核心功能與特性 (Key Features)

### 2.1 全 HTTP Method 完整支援
支援 `GET`、`POST`、`PUT`、`DELETE`、`PATCH`、`HEAD`、`OPTIONS`：
- **含 Body 方法 (`POST`, `PUT`, `PATCH`)**：自動將 Payload 序列化為 JSON 字串發送。
- **無 Body / 查詢方法 (`GET`, `HEAD`, `OPTIONS`)**：使用 `BodyPublishers.noBody()`，並將 Payload 轉為 Query Parameters。
- **混合型方法 (`DELETE`)**：Payload 為空時發送標準 DELETE，有 Payload 時自動攜帶 JSON Body。

### 2.2 動態路徑與查詢參數解析
- **Path Parameters**：若 OpenAPI 定義之路徑含有 `{paramName}`（例如 `/accounts/{accountId}/balance`），引擎會自動從傳入的 `payload` 或 `arguments` 中取出同名鍵值，並以 **UTF-8 URL 編碼** 後精確替換。
- **Query Parameters**：對於 GET/DELETE 請求，未被路徑參數消耗的其餘欄位，會自動組裝成 URL 查詢字串（`?status=ACTIVE&limit=10`）。

### 2.3 自訂 Headers 與分散式鏈路追蹤
- 預設標頭：`Content-Type: application/json`。
- 支援於 Workflow 參數中傳入 `headers` 物件，動態注入 `Authorization: Bearer <token>`、`X-Correlation-ID`、`X-Tenant-ID` 等業務標頭。

### 2.4 彈性逾時配置 (Configurable Timeout)
- **預設逾時**：10 秒。
- **全域設定**：於 `application.properties` 設定 `kogito.sw.openapi.timeout-seconds=15`。
- **單次覆寫**：於 Workflow Action 引數中傳入 `timeoutSeconds: 30`。

### 2.5 響應資料結構標準化 (Response Normalization)
不論目標服務回傳何種格式，引擎皆會將其正規化為符合 Workflow jq 運算式判斷的 `ObjectNode`：

| 下游回應格式 | HTTP 狀態碼 | 轉換後的輸出結構 | 說明 |
| :--- | :--- | :--- | :--- |
| **標準 JSON Object** | 200 OK | `{ ...原欄位..., "_httpStatus": 200, "code": "100" }` | 若原 JSON 無 `code` 或 `message` 會自動補齊 |
| **JSON Array** | 200 OK | `{ "data": [ ... ], "code": "100", "message": "成功", "_httpStatus": 200 }` | 自動包裝為物件，避免破壞 Workflow 結構 |
| **空 Body / 204** | 204 No Content | `{ "code": "100", "message": "成功 (無回傳內容)", "_httpStatus": 204 }` | 避免因空字串導致 JSON 解析崩潰 |
| **非 JSON / 文字** | 200 / 4xx / 5xx | `{ "rawResponse": "...", "code": "100"/"999", "message": "...", "_httpStatus": status }` | 保留原始回傳字串 |
| **網路連線/逾時異常** | 連線失敗/逾時 | `{ "code": "999", "message": "API 呼叫錯誤: ...", "_httpStatus": 0 }` | 攔截例外避免 Workflow 崩潰 |

---

## 3. 多層高效能快取架構 (Caching Strategy)

為避免每一次 API 調用皆需重新由磁碟讀取 YAML 與重複解釋規格，`MyOpenApiService` 建立了 4 層執行期執行期 `ConcurrentHashMap` 快取：

```java
// 1. 端點定位快取: 記錄路徑模板、HTTP Method 與規格內宣告之 Base URL
private final Map<String, ApiEndpoint> operationCache;      // key: "specPath#operationId"

// 2. Base URL 解析快取: 記錄計算後的目標 Base URL
private final Map<String, String> baseUrlCache;             // key: "functionName#specPath"

// 3. YAML AST 快取: 記錄 Classpath YAML 檔案解析後的 JsonNode 語法樹
private final Map<String, JsonNode> specAstCache;           // key: "specPath"

// 4. Request Schema 欄位快取: 記錄 operation 的 requestBody schema 欄位清單
private final Map<String, List<String>> requestFieldsCache; // key: "schemaRef"
```

> **效能優勢**：首次調用完成 Lazy Init 載入與解析後，後續相同端點的所有調用皆為 **O(1)** 記憶體級查找。

---

## 4. Base URL 解析規則與優先級

當 Workflow 發起調用時，`MyOpenApiService` 會透過 MicroProfile Config 按以下順序依序解析目標主機位址（解析成功即停止）：

| 優先級 | 設定項目 (Key) | 範例 | 適用場景 |
| :---: | :--- | :--- | :--- |
| **1** | `kogito.sw.functions.<functionName>.base_url`<br>或 `kogito.sw.functions.<functionName>.url` | `http://api.example.com/v1` | 明確指定單一 Function 完整 Base URL |
| **2** | `kogito.sw.functions.<functionName>.protocol`<br>`kogito.sw.functions.<functionName>.host`<br>`kogito.sw.functions.<functionName>.port` | `protocol=http`<br>`host=localhost`<br>`port=8080` | 分離設定通訊協定、主機與連接埠（**SonataFlow 建議慣例**） |
| **3** | `kogito.sw.openapi.<specKey>.base_url`<br>或 `quarkus.rest-client.<specKey>.url` | `kogito.sw.openapi.specs_A16229-api_yaml.base_url=http://10.0.1.5:8080` | 針對特定 OpenAPI 檔案進行全域 Base URL 設定 |
| **4** | OpenAPI YAML 內的 `servers[0].url` | `servers: [{url: "http://localhost:8080/"}]` | 從 OpenAPI 規格書預設 servers 區塊提取 |

---

## 5. Workflow 設定與調用教學 (Usage in Workflow)

### 5.1 步驟一：在 Workflow YAML 宣告 Function

在 `*.sw.yaml` 檔案的 `functions` 區塊宣告使用 `MyOpenApiService`：

```yaml
functions:
  - name: callApiViaOpenAPI
    operation: 'service:com.example.transfer.workflow.MyOpenApiService::callOpenApi'
    type: custom
```

### 5.2 步驟二：在 application.properties 設定目標位址（可選）

```properties
# 針對 callApiViaOpenAPI 函式設定目標端點
kogito.sw.functions.callApiViaOpenAPI.protocol=http
kogito.sw.functions.callApiViaOpenAPI.host=localhost
kogito.sw.functions.callApiViaOpenAPI.port=8080

# (可選) 全域 OpenAPI 呼叫逾時時間 (秒)
kogito.sw.openapi.timeout-seconds=15
```

### 5.3 步驟三：在 Workflow State 中調用

#### 範例 1：標準 POST 請求（含 Payload 封裝）
```yaml
  - name: CallA16229State
    type: operation
    actions:
      - name: callA16229Action
        functionRef:
          refName: callApiViaOpenAPI
          arguments:
            functionName: "callApiViaOpenAPI"
            schemaRef: 'specs/A16229-api.yaml#executeA16229'
            payload:
              Account_A: '${ .Account_A }'
              AMT: '${ .AMT }'
              EC: false
        actionDataFilter:
          results: '{code: .code, message: .message, Account: .Account, _httpStatus: ._httpStatus}'
          toStateData: '${ .a16229Result }'
    transition: CheckA16229Result
```

#### 範例 2：帶有 Path Parameter 與自訂 Headers 的 GET 請求
假設 OpenAPI 規格如下：
```yaml
paths:
  /accounts/{accountId}/details:
    get:
      operationId: getAccountDetails
```

Workflow 調用宣告：
```yaml
  - name: QueryAccountState
    type: operation
    actions:
      - name: queryAccountAction
        functionRef:
          refName: callApiViaOpenAPI
          arguments:
            schemaRef: 'specs/account-api.yaml#getAccountDetails'
            timeoutSeconds: 5
            headers:
              Authorization: 'Bearer ${ .token }'
              X-Correlation-ID: '${ $WORKFLOW.instanceId }'
            payload:
              accountId: '${ .Account_A }'
              includeHistory: true
        actionDataFilter:
          toStateData: '${ .accountDetails }'
```
> **執行結果**：
> 1. `{accountId}` 會自動替換為 `.Account_A`。
> 2. `includeHistory=true` 自動轉為 Query String：`GET /accounts/A12345/details?includeHistory=true`。
> 3. HTTP Header 自動附帶 `Authorization` 與 `X-Correlation-ID`。

---

## 6. Java API 進入點與多載簽章 (Java Signatures)

`MyOpenApiService` 實作了多種多載方法，以完整相容 Kogito 編譯期 Codegen 與反射調用：

```java
@ApplicationScoped
public class MyOpenApiService {

    // 1. 標準進入點 (Workflow functionRef.arguments)
    public JsonNode callOpenApi(JsonNode arguments);

    // 2. Map 參數版
    public JsonNode callOpenApi(String schemaRef, Map<String, Object> payload);

    // 3. JsonNode 參數版
    public JsonNode callOpenApi(String schemaRef, JsonNode payload);

    // 4. 含 functionName 與 Map 參數版
    public JsonNode callOpenApi(String functionName, String schemaRef, Map<String, Object> payload);

    // 5. 含 functionName 與 JsonNode 參數版
    public JsonNode callOpenApi(String functionName, String schemaRef, JsonNode payload);

    // 公開 Utility: 解析指定 OpenAPI operation 的 requestBody schema 欄位名稱
    public List<String> resolveRequestFieldNames(String schemaRef);
}
```

---

## 7. 常見問題與除錯指引 (Troubleshooting)

### Q1: 出現 `未指定 OpenAPI 規格定位點 (schemaRef)` 錯誤
- **原因**：Workflow 的 `arguments` 未傳入 `schemaRef` 屬性。
- **解法**：確認 `functionRef.arguments` 中含有 `schemaRef: 'specs/<file>.yaml#<operationId>'`。

### Q2: 出現 `在 OpenAPI 規格檔 [...] 中找不到 operationId = '...'`
- **原因**：OpenAPI YAML 檔案內未定義該 `operationId`，或是大小寫不一致。
- **解法**：檢查 `src/main/resources/specs/*.yaml` 檔案中各路徑下的 `operationId` 設定。

### Q3: 出現 `無法確定 API Base URL！未在 application.properties 中設定...`
- **原因**：未在 `application.properties` 中指定 Base URL 相關設定，且 YAML 檔案亦無 `servers[0].url`。
- **解法**：在 `application.properties` 補上 `kogito.sw.functions.<functionName>.host` 或 `kogito.sw.functions.<functionName>.base_url`。

### Q4: 如何在 Windows 與 Linux 跨平台環境確保 Classpath 正確？
- `MyOpenApiService` 內部呼叫了 `PlatformPaths.normalizeClasspath()`，即使傳入 Windows 風格的 `specs\A16229-api.yaml#executeA16229`，也會自動正規化為 `specs/A16229-api.yaml#executeA16229`，完全相容跨平台部署。

---

## 8. 平台級 OpenAPI 生態整合全貌 (Ecosystem Overview)

在 `myhello-platform` 雲原生多模組架構中，OpenAPI 規格被賦予三種截然不同但互相協作的關鍵角色，達成 **Single Source of Truth (SSOT)**：

```
                              ┌───────────────────────────────────────────────────────────┐
                              │                    OpenAPI 規格檔體系                     │
                              └───────────────────────────────────────────────────────────┘
                                             │                             │
                     specs/*.yaml            │                             │ specs/internal/*.yaml
             (外部 Host 系統介面規格)         │                             │ (內部/對外入口契約規格)
                                             ▼                             ▼
                              ┌─────────────────────────────┐ ┌─────────────────────────────────────────┐
                              │ 1. Outbound 外部呼叫引擎    │ │ 2. Inbound 入口動態代理                │
                              │    (MyOpenApiService)       │ │    (InternalOpenApiDynamicRouter)       │
                              └─────────────────────────────┘ └─────────────────────────────────────────┘
                                             │                                     │
                                             │ 發送 HTTP 請求                      │ 攔截外部 HTTP POST /Omni/...
                                             ▼                                     │ 注入 Path Parameter
                               ┌───────────────────────────┐                       ▼
                               │   外部銀行主機 / 核心系統 │        ┌────────────────────────────────────┐
                               │   (A16229, A16220, Core)  │        │ SonataFlow 流程端點 (/omni_cash...)│
                               └───────────────────────────┘        └────────────────────────────────────┘
                                                                                   │
                                                                                   │ Step 0: ValidateInput
                                                                                   ▼
                                                                    ┌────────────────────────────────────┐
                                                                    │ 3. Validation 規格驅動驗證器       │
                                                                    │    (OpenApiSchemaValidator)        │
                                                                    └────────────────────────────────────┘
                                                                                   │
                                                          ┌────────────────────────┴────────────────────────┐
                                                          │ 合法通過                                        │ 驗證失敗 (400)
                                                          ▼                                                 ▼
                                            ┌───────────────────────────┐                     ┌───────────────────────────┐
                                            │ IdempotencyCheck & Subflow│                     │ InjectValidationFailed    │
                                            └───────────────────────────┘                     └───────────────────────────┘
                                                                                                            │
                                                                                                            ▼
                                                                                              ┌───────────────────────────┐
                                                                                              │ FinalAuditAndEnd (防缺口) │
                                                                                              └───────────────────────────┘
```

### 8.1 外部呼叫 (Outbound): `MyOpenApiService`
- **目標資源**：`src/main/resources/specs/*.yaml`
- **核心職責**：Workflow 節點透過 `service:com.example.transfer.workflow.MyOpenApiService::callOpenApi` 動態解析規格、替換路徑參數、發送非同步 HTTP 請求至外部系統，並標準化回應資料結構。

### 8.2 入口代理 (Inbound): `InternalOpenApiDynamicRouter`
- **目標資源**：`src/main/resources/specs/internal/*.yaml`
- **核心職責**：應用啟動時由 Vert.x 掃描含有 `x-workflow-id` 標註之路徑（如 `/Omni/{creditcardid}/Repayment/Execute`），自動將 URL 路徑變數注入 JSON Body，並以非阻塞方式代理轉發至本地 SonataFlow 工作流端點。

### 8.3 規格校驗 (Validation): `OpenApiSchemaValidator`
- **目標資源**：`src/main/resources/specs/internal/*.yaml`
- **核心職責**：作為工作流啟動的第一個狀態節點（`ValidateInput`），以 Swagger Parser 動態快取之 RequestBody Schema 校驗所有必填、長度、正則、列舉與條件相依規則。
- **Audit Gap 防護優勢**：取代 Kogito 原生在外層中斷的 `dataInputSchema`，確保即使輸入錯誤，流程亦能建立實例並安全抵達 `FinalAuditAndEnd`，100% 寫入審計日誌與對帳資料庫，再由 `WorkflowStatusFilter` 改寫為 HTTP 400。

