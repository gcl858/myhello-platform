# Policy Loan Transaction - Spec v1.0

> 對應 draft: `draft-policy-loan-transaction/` (壽險保單質押借款與即時還款業務)
> 撰寫日期: 2026-09-02
> 設計期採用模式: Mode B (Parent + 2 Child Subflows)
> Convention: 新 (status: 0/1 int + finalStatus: string)

---

## §0 假設清單 (Step 1a 強制結構)

| # | 假設 | 為何這樣假設 | 待確認問題 | 落地策略 |
|---|---|---|---|---|
| H1 | 輸入欄位 11 個 (`partyId`, `policyNo`, `policyType`, `bankAccountId`, `transactionDate`, `transactionDateTime`, `channelCode`, `operationType`, `amount`, `sequenceNumber`, `originalSequenceNumber`) | 業務書 §3 | — | `schemas/policy-loan-input-schema.json` |
| H2 | 終態 finalStatus 有 9 個 | 業務書 §4 表格 | — | `spec.md §2.3` + `application.properties.snippet` |
| H3 | 對外契約用 REST POST | 既有 transfer-workflow 標準 | — | `specs/policy-loan-api.yaml` |
| H4 | 壽險主機質押圈存 + 銀行主機撥款 2 階段 Saga | 業務書 §2 架構圖 | — | `policy_loan_borrow.sw.yaml` |
| H5 | 還款解質時需 lookup 原 SUCCESS 質借交易 | 業務書 §2 架構圖 | — | `lookupOriginalTransaction` function |
| H6 | **FQCN**: `AuditLogService::findBySequenceNumber` | 既有 service 提供 | — | 複用 `AuditLogService` |
| H7 | **FQCN**: `IdempotencyService::findBySequenceNumber` | 既有 service 提供 | — | 複用 `IdempotencyService` |
| H8 | **FQCN**: `AuditLogService::markCancelledBy` | 既有 service 提供 | — | 複用 `AuditLogService` |
| H9 | **ID 命名**: snake_case (`policy_loan_transaction`, `policy_loan_borrow`, `policy_loan_repayment`) | ⭐ 規避 Kogito 10.2.0 subflow codegen bug | — | 所有 sw.yaml id 全用 snake_case |
| H10 | **Convention**: 新 (`status`: 0/1 int + `finalStatus`: string) | 與全平台新標準對齊 | — | `stateDataFilter.output` |
| H11 | **Mock package**: `org.acme.transfer.api` | 對齊既有 transfer-mock 模組 | — | `spec/mocks/*` 全部直接對齊 |

---

## §1 概覽

Parent workflow 接收壽險保單質押借款與還款請求, 依 `operationType` 路由到對應的 child subflow:
- `operationType=A` → 委派給 `policy_loan_borrow` (正向質借撥付: 壽險質押圈存 + 銀行活存撥款 2 階段 Saga, 失敗自動解除圈存回滾)
- `operationType=B` → 委派給 `policy_loan_repayment` (還款解質: 驗證原交易 + 銀行活存扣繳還款 + 壽險主機解除質押)

---

## §2 輸入輸出

### §2.1 Input schema
詳見 [`spec/schemas/policy-loan-input-schema.json`](file:///media/op/acer_sata/2026_AI_Hack/SonataFlow/myhello_project_0830/draft-policy-loan-transaction/spec/schemas/policy-loan-input-schema.json)

### §2.3 finalStatus 對照表

| finalStatus | HTTP code | status (int) | 業務說明 |
|---|---|---|---|
| `SUCCESS` | 200 | 0 | 保單質押借款撥付全流程成功 |
| `FAILED` | 200 | 1 | 壽險核心保單質押圈存失敗 |
| `ROLLED_BACK` | 200 | 0 | 銀行撥款入帳失敗, 壽險保單質押已自動解除圈存回滾 |
| `ROLLBACK_FAILED` | 409 | 1 | 撥款失敗且壽險解質回滾亦失敗 (需告警) |
| `CANCELLED` | 200 | 0 | 還款結清與保單解質成功 |
| `CANCEL_REJECTED` | 200 | 1 | 原交易非 SUCCESS 或已被結清解質 |
| `LOOKUP_FAILED` | 500 | 1 | 查無原保單質借交易紀錄 |
| `REJECTED_VALIDATION` | 400 | 1 | 輸入參數檢核失敗 |
| `IDEMPOTENT_REPLAY` | 200 | 0 | Parent 級冪等防重複重播 |

---

## §3 Workflow 結構

- **Parent**: `policy_loan_transaction` ([`spec/policy_loan_transaction.sw.yaml`](file:///media/op/acer_sata/2026_AI_Hack/SonataFlow/myhello_project_0830/draft-policy-loan-transaction/spec/policy_loan_transaction.sw.yaml))
- **Child A**: `policy_loan_borrow` ([`spec/policy_loan_borrow.sw.yaml`](file:///media/op/acer_sata/2026_AI_Hack/SonataFlow/myhello_project_0830/draft-policy-loan-transaction/spec/policy_loan_borrow.sw.yaml))
- **Child B**: `policy_loan_repayment` ([`spec/policy_loan_repayment.sw.yaml`](file:///media/op/acer_sata/2026_AI_Hack/SonataFlow/myhello_project_0830/draft-policy-loan-transaction/spec/policy_loan_repayment.sw.yaml))

---

## §4 資料庫 migration (Step 4d 編號遞增)

- `V1.2.5__create_view_policy_loan_transaction_reconciliation.sql` (對帳 view, 位於 [`spec/db/`](file:///media/op/acer_sata/2026_AI_Hack/SonataFlow/myhello_project_0830/draft-policy-loan-transaction/spec/db/V1.2.5__create_view_policy_loan_transaction_reconciliation.sql))

---

## §5 組態 (Step 8 整合前置產出物)

詳見 [`spec/config/application.properties.snippet`](file:///media/op/acer_sata/2026_AI_Hack/SonataFlow/myhello_project_0830/draft-policy-loan-transaction/spec/config/application.properties.snippet)

---

## §6 測試 (Step 7.12)

- 6 個 E2E 測試案例 ([`spec/tests/PolicyLoanTransactionWorkflowTest.java`](file:///media/op/acer_sata/2026_AI_Hack/SonataFlow/myhello_project_0830/draft-policy-loan-transaction/spec/tests/PolicyLoanTransactionWorkflowTest.java)):
  - `[P1]`: 參數檢核失敗 (`operationType=C`) -> 400 `REJECTED_VALIDATION`
  - `[A1]`: 正向保單質借撥款正常成功 (`WF-A`) -> 200 `SUCCESS`
  - `[P4]`: Parent 級冪等重送 -> 200 `IDEMPOTENT_REPLAY`
  - `[B1]`: 保單質借還款結清成功 (`WF-B`) -> 200 `CANCELLED`
  - `[B2]`: 還款結清查無原質借紀錄 -> 500 `LOOKUP_FAILED`

---

## §7 已知限制 / 簡化

- 本版本質借利息計算採即時結算總額 (由前端/主機預先試算帶入 `amount`)，利息所得扣繳稅款由壽險主機內部帳處理。
- 質借幣別預設為新台幣 (TWD)。

---

## §8 Project Mapping Manifest (Step 7.14)

| Draft 檔案 | 正式專案目標路徑 |
|---|---|
| `spec/policy_loan_transaction.sw.yaml` | `domain-transfer/transfer-workflow/src/main/resources/policy_loan_transaction.sw.yaml` |
| `spec/policy_loan_borrow.sw.yaml` | `domain-transfer/transfer-workflow/src/main/resources/policy_loan_borrow.sw.yaml` |
| `spec/policy_loan_repayment.sw.yaml` | `domain-transfer/transfer-workflow/src/main/resources/policy_loan_repayment.sw.yaml` |
| `spec/specs/policy-loan-api.yaml` | `domain-transfer/transfer-workflow/src/main/resources/specs/policy-loan-api.yaml` |
| `spec/specs/insurance-policy-pledge-api.yaml` | `domain-transfer/transfer-workflow/src/main/resources/specs/insurance-policy-pledge-api.yaml` |
| `spec/specs/core-banking-account-api.yaml` | `domain-transfer/transfer-workflow/src/main/resources/specs/core-banking-account-api.yaml` |
| `spec/schemas/policy-loan-input-schema.json` | `domain-transfer/transfer-workflow/src/main/resources/schemas/policy-loan-input-schema.json` |
| `spec/mocks/InsurancePolicyPledgeResource.java` | `domain-transfer/transfer-mock/src/main/java/org/acme/transfer/api/InsurancePolicyPledgeResource.java` |
| `spec/mocks/CoreBankingAccountResource.java` | `domain-transfer/transfer-mock/src/main/java/org/acme/transfer/api/CoreBankingAccountResource.java` |
| `spec/mocks/dto/*` | `domain-transfer/transfer-mock/src/main/java/org/acme/transfer/api/dto/*` |
| `spec/db/V1.2.5__create_view_policy_loan_transaction_reconciliation.sql` | `domain-transfer/transfer-workflow/src/main/resources/db/migration/V1.2.5__create_view_policy_loan_transaction_reconciliation.sql` |
| `spec/tests/PolicyLoanTransactionWorkflowTest.java` | `distribution/transfer-app/src/test/java/com/example/platform/distribution/transfer/PolicyLoanTransactionWorkflowTest.java` |

