CREATE VIEW IF NOT EXISTS vw_policy_loan_transaction_reconciliation AS
SELECT
    id,
    created_at,
    workflow_id,
    business_key,
    process_instance_id,
    status,
    message,
    json_extract(input_data, '$.partyId') AS party_id,
    json_extract(input_data, '$.policyNo') AS policy_no,
    json_extract(input_data, '$.policyType') AS policy_type,
    json_extract(input_data, '$.bankAccountId') AS bank_account_id,
    json_extract(input_data, '$.operationType') AS operation_type,
    json_extract(input_data, '$.amount') AS amount,
    cancelled_by,
    cancelled_at
FROM workflow_execution_log
WHERE workflow_id IN ('policy_loan_transaction', 'policy_loan_borrow', 'policy_loan_repayment');

