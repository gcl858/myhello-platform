package com.example.platform.distribution.transfer;

import io.quarkus.test.junit.QuarkusTest;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.*;

@QuarkusTest
public class PolicyLoanTransactionWorkflowTest {

    private static final String PARENT_URL = "/policy_loan_transaction";

    @Test
    @DisplayName("[P1] 參數檢核失敗 (operationType=C) -> 400 REJECTED_VALIDATION")
    void testP1InvalidOpType() {
        String seq = "PL_P1_" + System.nanoTime();
        String payload = "{\n" +
                "  \"partyId\":\"A123456789\",\"policyNo\":\"POL2026083001\",\n" +
                "  \"policyType\":\"LIFE01\",\"bankAccountId\":\"01234567890123\",\n" +
                "  \"transactionDate\":\"20260830\",\"transactionDateTime\":\"11300000\",\n" +
                "  \"channelCode\":\"APP01\",\"operationType\":\"C\",\n" +
                "  \"amount\":\"0000300000\",\"sequenceNumber\":\"" + seq + "\"\n" +
                "}";

        given()
            .contentType("application/json")
            .body(payload)
        .when()
            .post(PARENT_URL)
        .then()
            .statusCode(400)
            .body("finalStatus", equalTo("REJECTED_VALIDATION"));
    }

    @Test
    @DisplayName("[A1] 正向保單質借撥款正常成功 (WF-A) -> 200 SUCCESS")
    void testA1BorrowSuccess() {
        String seq = "PL_A1_" + System.nanoTime();
        String payload = "{\n" +
                "  \"partyId\":\"A123456789\",\"policyNo\":\"POL2026083001\",\n" +
                "  \"policyType\":\"LIFE01\",\"bankAccountId\":\"01234567890123\",\n" +
                "  \"transactionDate\":\"20260830\",\"transactionDateTime\":\"11300000\",\n" +
                "  \"channelCode\":\"APP01\",\"operationType\":\"A\",\n" +
                "  \"amount\":\"0000300000\",\"sequenceNumber\":\"" + seq + "\"\n" +
                "}";

        given()
            .contentType("application/json")
            .body(payload)
        .when()
            .post(PARENT_URL)
        .then()
            .statusCode(200)
            .body("finalStatus", equalTo("SUCCESS"))
            .body("policyPledgeResult.status", equalTo(0))
            .body("coreBankingResult.status", equalTo(0));
    }

    @Test
    @DisplayName("[P4] Parent 級冪等重送 -> 200 IDEMPOTENT_REPLAY")
    void testP4Idempotency() {
        String seq = "PL_P4_" + System.nanoTime();
        String payload = "{\n" +
                "  \"partyId\":\"A123456789\",\"policyNo\":\"POL2026083001\",\n" +
                "  \"policyType\":\"LIFE01\",\"bankAccountId\":\"01234567890123\",\n" +
                "  \"transactionDate\":\"20260830\",\"transactionDateTime\":\"11300000\",\n" +
                "  \"channelCode\":\"APP01\",\"operationType\":\"A\",\n" +
                "  \"amount\":\"0000300000\",\"sequenceNumber\":\"" + seq + "\"\n" +
                "}";

        given().contentType("application/json").body(payload).when().post(PARENT_URL).then().statusCode(200).body("finalStatus", equalTo("SUCCESS"));
        given().contentType("application/json").body(payload).when().post(PARENT_URL).then().statusCode(200).body("finalStatus", equalTo("IDEMPOTENT_REPLAY"));
    }

    @Test
    @DisplayName("[B1] 保單質借還款結清成功 -> 200 CANCELLED")
    void testB1RepaymentSuccess() {
        String origSeq = "PL_ORIG_" + System.nanoTime();
        String setupPayload = "{\n" +
                "  \"partyId\":\"A123456789\",\"policyNo\":\"POL2026083001\",\n" +
                "  \"policyType\":\"LIFE01\",\"bankAccountId\":\"01234567890123\",\n" +
                "  \"transactionDate\":\"20260830\",\"transactionDateTime\":\"11300000\",\n" +
                "  \"channelCode\":\"APP01\",\"operationType\":\"A\",\n" +
                "  \"amount\":\"0000300000\",\"sequenceNumber\":\"" + origSeq + "\"\n" +
                "}";

        given().contentType("application/json").body(setupPayload).when().post(PARENT_URL).then().statusCode(200).body("finalStatus", equalTo("SUCCESS"));

        String revSeq = "PL_R_" + System.nanoTime();
        String revPayload = "{\n" +
                "  \"partyId\":\"A123456789\",\"policyNo\":\"POL2026083001\",\n" +
                "  \"policyType\":\"LIFE01\",\"bankAccountId\":\"01234567890123\",\n" +
                "  \"transactionDate\":\"20260830\",\"transactionDateTime\":\"11350000\",\n" +
                "  \"channelCode\":\"APP01\",\"operationType\":\"B\",\n" +
                "  \"amount\":\"0000300000\",\"sequenceNumber\":\"" + revSeq + "\",\n" +
                "  \"originalSequenceNumber\":\"" + origSeq + "\"\n" +
                "}";

        given()
            .contentType("application/json")
            .body(revPayload)
        .when()
            .post(PARENT_URL)
        .then()
            .statusCode(200)
            .body("finalStatus", equalTo("CANCELLED"));
    }

    @Test
    @DisplayName("[B2] 還款結清查無原質借紀錄 -> 500 LOOKUP_FAILED")
    void testB2LookupFailed() {
        String revSeq = "PL_R_" + System.nanoTime();
        String revPayload = "{\n" +
                "  \"partyId\":\"A123456789\",\"policyNo\":\"POL2026083001\",\n" +
                "  \"policyType\":\"LIFE01\",\"bankAccountId\":\"01234567890123\",\n" +
                "  \"transactionDate\":\"20260830\",\"transactionDateTime\":\"11350000\",\n" +
                "  \"channelCode\":\"APP01\",\"operationType\":\"B\",\n" +
                "  \"amount\":\"0000300000\",\"sequenceNumber\":\"" + revSeq + "\",\n" +
                "  \"originalSequenceNumber\":\"PL_NONEXIST_99999\"\n" +
                "}";

        given()
            .contentType("application/json")
            .body(revPayload)
        .when()
            .post(PARENT_URL)
        .then()
            .statusCode(500)
            .body("finalStatus", equalTo("LOOKUP_FAILED"));
    }
}

