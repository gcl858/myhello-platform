package org.acme.transfer.api;

import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import org.acme.transfer.api.dto.CoreBankingRequest;
import org.acme.transfer.api.dto.CoreBankingResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.UUID;

@Path("/CoreBanking/{partyId}/Transfer/Execute")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class CoreBankingAccountResource {
    private static final Logger LOG = LoggerFactory.getLogger(CoreBankingAccountResource.class);

    @POST
    public Response execute(@PathParam("partyId") String partyId, CoreBankingRequest request) {
        LOG.info("[Mock CoreBanking] partyId={}, account={}, opType={}, amount={}", partyId, request != null ? request.bankAccountId : null, request != null ? request.operationType : null, request != null ? request.amount : null);
        if (request != null && request.amount != null && request.amount.startsWith("FAIL_BANK")) {
            return Response.status(400).entity(new CoreBankingResponse(1, "銀行存款主機處理失敗(帳戶凍結或餘額不足)", "bank-err-" + UUID.randomUUID().toString().substring(0, 8))).build();
        }
        return Response.ok(new CoreBankingResponse(0, "銀行存款主機撥轉成功", "bank-core-" + UUID.randomUUID().toString().substring(0, 8))).build();
    }
}

