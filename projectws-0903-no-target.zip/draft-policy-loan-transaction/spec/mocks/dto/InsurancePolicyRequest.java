package org.acme.transfer.api.dto;

public class InsurancePolicyRequest {
    public String partyId;
    public String policyNo;
    public String policyType;
    public String operationType;
    public String amount;
    public String sequenceNumber;

    public InsurancePolicyRequest() {}

    public InsurancePolicyRequest(String partyId, String policyNo, String policyType, String operationType, String amount, String sequenceNumber) {
        this.partyId = partyId;
        this.policyNo = policyNo;
        this.policyType = policyType;
        this.operationType = operationType;
        this.amount = amount;
        this.sequenceNumber = sequenceNumber;
    }
}

