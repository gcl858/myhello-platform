package org.acme.transfer.api.dto;

public class CoreBankingRequest {
    public String partyId;
    public String bankAccountId;
    public String operationType;
    public String amount;
    public String sequenceNumber;

    public CoreBankingRequest() {}

    public CoreBankingRequest(String partyId, String bankAccountId, String operationType, String amount, String sequenceNumber) {
        this.partyId = partyId;
        this.bankAccountId = bankAccountId;
        this.operationType = operationType;
        this.amount = amount;
        this.sequenceNumber = sequenceNumber;
    }
}

