package org.acme.transfer.api.dto;

public class InsurancePolicyResponse {
    public int status;
    public String message;
    public String track_id;

    public InsurancePolicyResponse() {}

    public InsurancePolicyResponse(int status, String message, String track_id) {
        this.status = status;
        this.message = message;
        this.track_id = track_id;
    }
}

