package org.acme.transfer.api.dto;

public class CoreBankingResponse {
    public int status;
    public String message;
    public String track_id;

    public CoreBankingResponse() {}

    public CoreBankingResponse(int status, String message, String track_id) {
        this.status = status;
        this.message = message;
        this.track_id = track_id;
    }
}

