package org.acme.transfer.api;

import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import org.acme.transfer.api.dto.InsurancePolicyRequest;
import org.acme.transfer.api.dto.InsurancePolicyResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.UUID;

@Path("/InsurancePolicy/{partyId}/Pledge/Execute")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class InsurancePolicyPledgeResource {
    private static final Logger LOG = LoggerFactory.getLogger(InsurancePolicyPledgeResource.class);

    @POST
    public Response execute(@PathParam("partyId") String partyId, InsurancePolicyRequest request) {
        LOG.info("[Mock InsurancePolicy] partyId={}, policyNo={}, opType={}, amount={}", partyId, request != null ? request.policyNo : null, request != null ? request.operationType : null, request != null ? request.amount : null);
        if (request != null && request.amount != null) {
            if ("A".equals(request.operationType) && request.amount.startsWith("FAIL_INSURANCE")) {
                return Response.status(400).entity(new InsurancePolicyResponse(1, "壽險保單質押圈存失敗(保單無效或保價金不足)", "ins-err-" + UUID.randomUUID().toString().substring(0, 8))).build();
            }
            if ("B".equals(request.operationType) && request.amount.startsWith("FAIL_ROLLBACK")) {
                return Response.status(400).entity(new InsurancePolicyResponse(1, "壽險保單解質回滾失敗", "ins-rberr-" + UUID.randomUUID().toString().substring(0, 8))).build();
            }
        }
        return Response.ok(new InsurancePolicyResponse(0, "壽險保單質押處理成功", "ins-pledge-" + UUID.randomUUID().toString().substring(0, 8))).build();
    }
}

