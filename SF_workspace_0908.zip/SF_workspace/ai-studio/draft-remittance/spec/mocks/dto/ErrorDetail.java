package org.acme.transfer.api.dto;

public class ErrorDetail {
    public String error_code;
    public String message;
    public ErrorDetail() {}
    public ErrorDetail(String c, String m) { this.error_code = c; this.message = m; }
}
