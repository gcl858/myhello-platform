# Skill Patch Proposal — vibe-workflow-design-v2 (源自 remittance_swift 審查)

> 狀態：提案，尚未寫入 SKILL.md（依 writing-skills 鐵律，需先有 failing test）。
> 觸發案例：`draft-remittance/spec/remittance-swift.sw.yaml`（Core→AML→SWIFT→FX，19 states）。
> 現有版本：9 項預檢（6.1-6.10）+ 27 項自查（7.1-7.27，見 `references/02-self-check/self-check-list.md` v2.2）。

## P1: 新增 6.11 onErrors + notifyOps 覆蓋檢查（必做）

**缺口證據**：
* `remittance_swift` 宣告 `errors: [{name: platformError}]` 但 6 個 `type: operation` 全無 `onErrors`，host timeout 會繞過 `ChildFinalAuditAndEnd` → Audit Gap。
* `functions` 定義 `notifyOps` 但零調用，`SWIFT_ROLLBACK_FAILED / AML_REJECTED_ROLLBACK_FAILED` 靜默結束。

**提案 wording（Step 6 新增一節）**：
> 凡宣告 `errors:` 的 workflow，每個 `type: operation` 必須有 `onErrors`（直調走 `Finalize*`，terminal 除外）；凡 `finalStatus` 含 `ROLLBACK_FAILED` 的 workflow，必須至少一處調用 `notifyOps`。

**自動檢查腳本**：
```bash
# 6.11a: operation 數 vs onErrors 數
ops=$(grep -c "type: operation" draft/spec/*.sw.yaml)
errs=$(grep -c "onErrors:" draft/spec/*.sw.yaml)
[ "$errs" -ge "$ops" ] || echo "❌ FAIL: operation=$ops 但 onErrors=$errs"

# 6.11b: 有 ROLLBACK_FAILED 終態卻零 notifyOps
if grep -q "ROLLBACK_FAILED" draft/spec/*.sw.yaml; then
  grep -q "notifyOps" draft/spec/*.sw.yaml || echo "❌ FAIL: 有 ROLLBACK_FAILED 卻無 notifyOps 調用"
fi
```

**落地位置**：`SKILL.md Step 6` 加 `6.11` 小節 + 新增 `references/01-platform-checks/10-onerrors-and-opsalert.md`；`self-check-list.md` 加 `7.28` 行。

---

## P2: 擴充 7.18 + 7.6（jq null guard + output 欄位有賦值）

**缺口證據**：
* `CheckCoreResult` 用 `'(.coreResult.status|tostring)!="0" and .coreResult.status!=0'`，`.coreResult` 為 null 時 jq 拋錯；應為 `((.coreResult.status // "999")|tostring)!="0"`。
* `output` 含 `finalMessage: (.finalMessage // null)`，但 7 個 `Finalize* inject` 全沒設 `finalMessage`，永遠 null。

**提案 wording**：
> 7.18 擴為「所有 `condition:` 讀 `.xxx.status` 必須帶 `//` 預設值」；7.6 擴為「`output` 出現的每個 key，必須至少在一個 `inject`/`operation` 被賦值（允許 `// null` 兜底，但不允許全空）」。

**自動檢查腳本**：
```bash
# 7.18+: 找 .status 但無 // 的 condition
grep -n "condition:" draft/spec/*.sw.yaml | grep ".status" | grep -v "//" && echo "❌ FAIL: 有 status 判斷缺 // 預設值"
# 7.6+: output key vs inject data key 對齊（人工複核，腳本只列清單）
grep -h "finalMessage" draft/spec/*.sw.yaml
```

**落地位置**：改 `references/02-self-check/self-check-list.md` 7.18/7.6 兩行 + `SKILL.md Step 3c/3d` 各加一句，不新增檔案。

---

## P3: 擴充 7.22（業務欄位禁止 literal 硬編碼）

**缺口證據**：
* `senderBIC: BANKUS33XXX`、`remitterAddress: TAIPEI`、`beneficiaryCountry: DEU`、`feeAmount: '0000000500'` 全 literal；`amountInUSD: '${ .amount }'` 未經 `fxRate` 換算。

**提案 wording（7.29 新增）**：
> `currency/BIC/country/address/fee/rate` 六類業務欄位禁止 literal，必須 `${ .field }`；`amountInUSD` 類衍生欄位必須含運算式（含 `fxRate` 或註明 §0 假設）。

**自動檢查腳本**：
```bash
# 列出可疑 literal 供人工複核（誤報排除：OUR/BEN/operationType A/B/C/R）
grep -nE "senderBIC|receiverBIC|beneficiaryCountry|remitterAddress|feeAmount|amountInUSD|fxRate" draft/spec/*.sw.yaml
```

**落地位置**：`self-check-list.md` 加 `7.29` 行；`SKILL.md Step 3b` payload 範例加註「業務欄位一律 `${}`，literal 僅允許 OUR/BEN/A/B/C/R」。

---

## 不進 skill 的項目（留在本次 spec.md H）

| 項目 | 為何不進 skill |
|---|---|
| `debitAccount/remitterAccount` 誤用 `beneficiaryAccount` | 匯款領域欄位語意，通用 skill 無法判定 |
| `operationType B進/A出` 是否合法 | 本次 dispatcher 約定，寫 H 即夠 |
| AML 一次 vs 兩次、fee 500 計算式 | 業務書 BR 層級，skill 只管結構 |

## 驗證計畫（writing-skills RED→GREEN）

1. RED：用現版 skill 跑 `remittance_swift`，確認 P1/P2/P3 三項全 PASS（誤過）→ 證明缺口存在。
2. GREEN：套用本提案腳本重跑，確認三項全 FAIL（正確攔截）。
3. REFACTOR：修 workflow 後重跑，全 PASS，且舊 9+27 項不受影響。
