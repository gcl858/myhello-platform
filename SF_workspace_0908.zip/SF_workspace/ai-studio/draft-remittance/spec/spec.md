# Remittance 臨櫃匯款 — Spec v1.0 (draft-remittance)

> 對應業務需求書 `remittance-requirement.md` v1.0 + 4 份 host API md + status-mapping / fee / dispatcher 附件
> 設計日期: 2026-09-07｜目標平台: SonataFlow 10.2.0｜整合目標: project-0825-pd｜DB: SQLite + Flyway
> 模式: **B 擴充 (Parent + 3 Child)**｜Convention: **新 (status 0/1 int + finalStatus string)**

---

## §0 假設清單 H1–H18 (Step 1a 強制結構)

| # | 假設 | 為何這樣假設 | 待確認問題 | 落地策略 |
|---|---|---|---|---|
| H1 | 輸入欄位 18 個 (operationType A/B/C + 通用 12 + 條件必填) | 需求書 §6.2 + dispatcher 決策表 §0 | — | notebooks/internal schema §2.1 |
| H2 | 終態 finalStatus 19 個 (§5.2) | status-mapping.md §0 | — | spec §2.3 + config status-rewrite |
| H3 | 對外唯一入口 POST /Omni/{partyId}/Remittance/Execute | 需求書 BR-P01 | — | internal yaml x-workflow-id |
| H4 | Parent 職責 P1–P10，Child 不做驗證/冪等/回應 | 需求書 §4.0.1/4.0.2 | — | parent YAML Dispatcher |
| H5 | WF-A 三階段 Core→AML→Clearing；AML 命中時 Core 已扣須退款 | 需求書 §4.1.3 + A6 | A6 業務確認 | domestic YAML RefundForAml |
| H6 | **FQCN**: `AuditLogService::findBySequenceNumber` (擴充既有) | WF-C Lookup 需查原 row | 需擴充 | YAML lookupOriginalTransaction |
| H7 | sequenceNumber 規則：RE_ 對外；CR_/DR_/SW_/FX_/AM_ 對內，22 字元 | 需求書 §6.4 | A1 API owner 確認 | YAML prefix 拼接 |
| H8 | 費用預扣：國內 30；跨境 400 + 中間行預估 + 大額 0.05% | fee-calculation-rules.md | A7 門檻確認 | Core payload feeAmount |
| H9 | SWIFT_PENDING 為唯一對外中間態；FX 失敗不影響 SWIFT | 需求書 §4.2.3/BR-207 | — | swift YAML FinalizePending/FxReportFailed |
| H10 | 沖銷預檢：SUCCESS/SWIFT_PENDING + 未沖銷 + 當日內 | 需求書 §4.3.1/BR-301~303 | A3/A4 確認 | cancellation YAML CheckLookup |
| H11 | **ID 命名 snake_case**：remittance_transaction/domestic/swift/cancellation | Kogito 10.2.0 hyphen bug | — | 全 YAML + Manifest |
| H12 | Flyway 既有最大 V1.2.4 → 新 V1.2.5 對帳 View | project-0825-pd 實況 | 需探測確認 | spec/db/V1.2.5 |
| H13a | **FQCN**: `RemittanceBusinessRuleValidator::validate` (新建，implements BusinessRuleValidator) | operationType=A/B/C 條件必填 + FAIL_ 哨兵豁免 | 需新建 + dispatch 註冊 | OpenApiSchemaValidator 註冊 |
| H13b | **FQCN**: `IdempotencyService::findBySequenceNumber` (新建) | workflow 級冪等 BR-502 | 需新建 | YAML checkIdempotency |
| H14 | **FQCN**: `AuditLogService::markCancelledBy` (擴充，workflow_id 參數化) | BR-308；舊硬編碼坑不可學 | 需擴充 | YAML markOriginalCancelled |
| H15 | **Convention 新**：Parent status 0/1 + finalStatus；Child 僅 finalStatus | 對齊 omni-cash-transaction | — | stateDataFilter 分流 |
| H16 | Mock package 佔位 `org.acme.transfer.api`，已對齊既有，下游免 rename | project-0825-pd transfer-mock | — | spec/mocks |
| H17 | servers 皆填 http://localhost:8080；fallback 鏈聲明 | 09 預檢 | — | 6 yaml + config 註解 |
| H18 | FX Report 為補充契約 (需求書僅端點名)；央行批次差異列已知限制 | 需求書 §6.1 | FX 格式確認 | external/fx-report-api.yaml + §9 |

---

## §1 概覽

Parent `remittance_transaction` 統一收單→OpenAPI 驗證三件套→冪等→Dispatcher (A→domestic, B→swift, C→cancellation)→FinalAuditAndEnd。Child 各自執行 host 調用與 LIFO 補償，僅回 finalStatus。

## §2 輸入輸出

### §2.1 Input schema
見 `notebooks/internal/omni-remittance-api.yaml` components.schemas.RemittanceInput（SSOT；⛔ 禁止 schemas/*.json）。

### §2.2 Dispatcher
見 operation-type-decision-table.md：A 必 13 欄、禁 original/cancel；B 必 17 欄 + purposeCode；C 必 15 欄 + original/cancel。

### §2.3 finalStatus 對映 (19 個)
見 status-mapping.md §0：SUCCESS/SWIFT_PENDING/SUCCESS_AFTER_ACK/FAILED/AML_REJECTED/ROLLED_BACK/SWIFT_ROLLED_BACK/FX_REPORT_FAILED/CANCELLED/CANCEL_REJECTED/CANCEL_FAILED/CANCEL_ROLLED_BACK/REJECTED_VALIDATION(400)/LOOKUP_FAILED(500)/ROLLBACK_FAILED(409)/SWIFT_ROLLBACK_FAILED(409)/AML_REJECTED_ROLLBACK_FAILED(409)/CANCEL_ROLLBACK_FAILED(409)/IDEMPOTENT_REPLAY(200)。

## §3 Workflow 結構

- Parent: `remittance_transaction` (remittance-parent.sw.yaml, version 1.0.0)
- WF-A: `remittance_domestic` (Core→AML→Clearing + 退款補償)
- WF-B: `remittance_swift` (Core→AML→SWIFT→FX + 退款補償)
- WF-C: `remittance_cancellation` (Lookup→Core退款→SWIFT取消→MarkCancelled)
- subFlowRef version 皆 1.0.0，對齊 child version (6.10)。

## §4 資料庫 migration

- `db/V1.2.5__create_view_remittance_reconciliation.sql`：vw_remittance_reconciliation + 2 index。

## §5 組態

見 `config/application.properties.snippet`：workflows 4 個 + 6 mapping + bean 綁定 + baseUrl 註解。下游 sonataflow-integration Step 7 合併。

## §6 測試

見 `tests/RemittanceTransactionTest.java`：P1(400)/A1(SUCCESS)/P4(REPLAY)/B1(SWIFT_PENDING)/B2(CANCELLED)。動態序號；view 防污染用獨立測試資料。

## §7 檔名-id Manifest (7.2/7.14)

| 檔名 | workflow id | 備註 |
|---|---|---|
| remittance-parent.sw.yaml | remittance_transaction | hyphen 檔名 vs underscore id 合法，已登記 |
| remittance-domestic.sw.yaml | remittance_domestic | — |
| remittance-swift.sw.yaml | remittance_swift | — |
| remittance-cancellation.sw.yaml | remittance_cancellation | — |

## §8 Project Mapping Manifest (7.14，下游雙模組同步)

| Draft 檔案 | 正式專案路徑 |
|---|---|
| notebooks/internal/omni-remittance-api.yaml | domain-transfer/transfer-workflow/src/main/resources/specs/internal/omni-remittance-api.yaml (+ distribution 同步) |
| notebooks/external/*.yaml (5 檔) | domain-transfer/transfer-workflow/src/main/resources/specs/external/*.yaml (+ distribution 同步) |
| spec/remittance-*.sw.yaml (4 檔) | domain-transfer/transfer-workflow/src/main/resources/*.sw.yaml |
| spec/db/V1.2.5__*.sql | domain-reconciliation/reconciliation-api/src/main/resources/db/migration/ |
| spec/config/application.properties.snippet | 合併到 distribution/transfer-app/src/main/resources/application.properties |
| spec/mocks/*.java + dto | dev/transfer-mock/src/main/java/org/acme/transfer/api/ (已對齊，免 rename) |
| spec/tests/RemittanceTransactionTest.java | distribution/transfer-app/src/test/java/com/example/platform/distribution/transfer/ |
| spec/spec.md | 隨包移交 |

## §9 已知限制

- 退匯 webhook (Return/Recall) 設計預留，未實作 (T5/A8)。
- FX 央行批次格式可能需調整；本版單筆送出 (T6)。
- 跨境 24h 後僅人工 (A3)；Hold 圈存端點選用未用。
- 主機 seq 查詢端點覆蓋待確認 (T4)，未知狀態查詢流程見需求書 §9.3。

## §10 Validator 註冊 (H13a 落地)

`RemittanceBusinessRuleValidator implements BusinessRuleValidator`：operationType=A/B/C 條件必填互斥 + FAIL_/RBFAIL_/HIT 哨兵豁免 (剝離後測 regex) + `tonumber? //` 守衛；在 `OpenApiSchemaValidator` dispatch 以 workflowId=remittance_transaction 註冊。

## §11 Fallback 聲明 (H17)

6 個 OpenAPI yaml 皆含 servers http://localhost:8080；缺失時解析鏈 base_url>%dev.host>spec servers (見 config 註解)，09 預檢不 FAIL。
