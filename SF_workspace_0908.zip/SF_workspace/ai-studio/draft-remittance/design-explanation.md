# 臨櫃匯款 Workflow Draft — 設計說明書

> 給創建者看的文件：解釋「這份 draft 是怎麼被設計出來的」
> 日期：2026-09-07
> 對應業務書：`request-remittance/remittance-requirement.md` v1.0（含 status-mapping / fee-calculation-rules / operation-type-decision-table / 4 份 host API md）
> 對應產出：`draft-remittance/`（21 個檔案）+ `draft-remittance.zip`
> 目標平台：SonataFlow 10.2.0，整合目標 project-0825-pd

---

## 0. 導讀：先看這一段

如果你只有 3 分鐘，請看這一段：

1. **業務要什麼**：臨櫃匯款只有一個對外入口，櫃員傳 `operationType=A` 做國內跨行、`=B` 做跨境 SWIFT、`=C` 做沖銷。扣款、AML、匯出三段都成功才算成功，失敗要自動退款或告警。
2. **設計選了什麼**：用 **Mode B 擴充（Parent + 3 個 Child）**。Parent 負責收單、驗證、查重複、路由、記帳、回應；WF-A 做國內三階段；WF-B 做跨境四階段（含 FX 申報）；WF-C 做沖銷反向。
3. **為什麼你會看到 21 個檔案**：6 份 OpenAPI（對外 1 + 主機 5，含補充的 FX）、4 份 workflow YAML（Parent + 3 Child）、5 個 mock 主機、1 份 DB view、1 份組態、1 份測試、1 份 spec、1 份本說明書。§5 有地圖。
4. **最容易誤會的 5 個決策**：全部 `snake_case` 命名（避開平台 bug）、回應 `status 0/1 + finalStatus` 雙欄位、驗證放流程內（避免審計斷層）、測試用 `FAIL_`/`HIT` 開關不會被驗證擋掉、Parent/Child 版本同為 `1.0.0`。
5. **還沒確定的事**：序號長度、跨境 24 小時窗、AML 先扣後查、FX 批次格式等 8 件事在 §7，draft 先用最嚴格假設，業務方確認後可改。

---

## 1. 背景與目標

### 1.1 現在的痛點（業務書 §1.2）

| 痛點 | 白話解釋 |
|---|---|
| 雙段作業分散 | 扣款與匯出走不同端末機，人工串接易出錯 |
| 無 AML 統一檢查 | 黑名單、制裁名單、大額申報分散各端末機 |
| 無統一入口 | 國內與跨境走不同端點，呼叫端邏輯分散 |
| 無統一取消機制 | 國內/跨境沖銷流程不一致，無標準反向流程 |
| 外匯申報脫鉤 | 跨境未自動產生申報資料，需人工補件 |
| 無對帳軌跡 | 失敗、重試、補償無系統化記錄 |

### 1.2 這份 draft 的目標

- **單一 API 入口**：`POST /Omni/{partyId}/Remittance/Execute`，用 `operationType` 區分 A/B/C。
- **最終一致**：Core/AML/Clearing/SWIFT 任一失敗，保證補償或告警，不會錢扣一半。
- **標準化沖銷**：WF-C 先查原交易 → Core 退款 →（跨境）SWIFT 取消 → 標記已取消。
- **可整併**：符合 9 項預檢 + 26 項自查，移交 `sonataflow-integration` 後工時 < 1 小時。

### 1.3 不做什麼（業務書 §2.2）

ACH 代收代付、外幣現鈔買賣、虛擬帳號收款、票據託收、匯入解款都不在這版。退匯 webhook 為設計預留。

---

## 2. 輸入來源：設計是從哪幾份文件長出來的

| 文件 | 版本 | 用來決定什麼 |
|---|---|---|
| `remittance-requirement.md` | v1.0 | Parent 職責 P1–P10、Dispatcher、19 個對外狀態、BR-P/BR-001~BR-508、驗收 P1–P5/A1–A6/B1–B6/C1–C5 |
| `coresystem-account-api.md` | v1.0 | Core 路徑 `/CoreAccount/{partyId}/Debit|Refund|Hold|Query/Execute`、path param `{partyId}` |
| `aml-screening-api.md` | v1.0 | AML 三端點、命中回 `status=1 + HTTP 200` 業務拒絕契約 |
| `domestic-clearing-api.md` | v1.0 | 通匯三端點、`feeBearer` OUR/BEN、退匯預留 |
| `swift-outbound-api.md` | v1.0 | MT103 送出/取消、MT199 查詢、MT900/MT192 通知、`SWIFT_PENDING` 監控 |
| `status-mapping.md` | v1.0 | 19 終態 SSOT、WF-A/B/C 內部→對外對映 |
| `fee-calculation-rules.md` | v1.0 | 國內 30、SWIFT 400、中間行 USD 15~50、大額 0.05%、外匯差價 |
| `operation-type-decision-table.md` | v1.0 | A/B/C 必填/不可填欄位、dispatcher 流程圖 |
| skill 範例 `01-financial-repayment` | v2.x | YAML/mock/測試寫法模板 |

Step 0 五問答案（本次採用）：SonataFlow 10.2.0、整合進 project-0825-pd、4 份 md＋補 FX、SQLite＋Flyway、Parent＋全 host mock＋tests。這 5 個答案決定後面全部技術選型。

---

## 3. 從需求到設計：三步推導

### 3.1 第一步：把業務書拆成「誰做什麼」

業務書 §4.0 Parent 職責 P1–P10 → workflow state：

```
業務書語言              →  workflow 語言
P1 輸入驗證             →  ValidateInput（operation，調 OpenApiSchemaValidator）+ CheckValidationResult
P3 冪等性檢查           →  CheckIdempotency（查 IdempotencyService）
P2 Dispatcher           →  Dispatcher（switch：A→domestic，B→swift，C→cancellation）
P4 委派執行             →  InvokeDomesticSubflow / InvokeSwiftSubflow / InvokeCancelSubflow（subFlowRef）
P5 統一稽核             →  FinalAuditAndEnd（調 recordAuditLog，驗證失敗也經過 InjectValidationFailedStatus）
P6 統一回應             →  FinalAuditAndEnd 的 stateDataFilter.output（固定格式）
P7 補償治理 + P8 告警   →  Child 內 Refund*/Compensate* + notifyOps（預留）
P9 跨境路由 + P10 FX 追蹤 →  WF-B 內 SWIFT→FX 兩段
```

Child 不做的事（§4.0.2：不驗證、不查冪等、不定回應格式）→ Child 以 `ValidateChildInput` 輕量 switch 起頭（僅擋錯配的 operationType），output 只有 `finalStatus`。

### 3.2 第二步：選模式

- Mode A（單層 Saga）不行：A/B/C 流程差太多（B 要 SWIFT＋FX，C 要先 lookup），硬塞一層變蜘蛛網。
- **Mode B 擴充（Parent＋3 Child）✅**：Parent 只管路由善後，Child 各管一種業務。以後加退匯 webhook 只要加 state，不動路由骨架。
- Mode C/D/E（多層審批/事件/排程）與本業務無關。

選 Mode B 的直接後果：Parent 出現 `subFlowRef`，觸發 Kogito 10.2.0 hyphen-id bug → 必須全 snake_case（見 §4.1）。

### 3.3 第三步：定回應長什麼樣

業務書 §6.3＋status-mapping §4 的統一回應即「新 convention」：

```json
{"track_id": "vw123456789abcdef", "workflow": "DOMESTIC_REMITTANCE", "status": 0, "finalStatus": "SUCCESS", "errors": null, "result": {...}}
```

- `status` 給機器（0=成功系，1=失敗系），用來改寫 HTTP code。
- `finalStatus` 給人（19 種，見下表），Child 只回它。
- 範例值全部來自 status-mapping 真實 payload（如 `A123456789`、`070`、`0000011758`、`DEUTDEFFXXX`）。

| finalStatus | HTTP | status | 意思 |
|---|---|---|---|
| SUCCESS / SUCCESS_AFTER_ACK | 200 | 0 | 全成功（含 ack 後） |
| SWIFT_PENDING | 200 | 0 | 唯一對外中間態，已匯出待 ack |
| FAILED / AML_REJECTED | 200 | 1/1 | 業務拒絕（AML 命中已退款才叫 AML_REJECTED） |
| ROLLED_BACK / SWIFT_ROLLED_BACK | 200 | 0 | 補償成功，已退款 |
| FX_REPORT_FAILED | 200 | 0 | SWIFT 成功、申報待補 |
| CANCELLED / CANCEL_REJECTED / CANCEL_FAILED / CANCEL_ROLLED_BACK | 200 | 0/1/1/0 | 沖銷四態 |
| REJECTED_VALIDATION | 400 | 1 | 輸入錯，沒打主機但有 audit |
| LOOKUP_FAILED | 500 | 1 | 原交易找不到 |
| ROLLBACK_FAILED / SWIFT_ROLLBACK_FAILED / AML_REJECTED_ROLLBACK_FAILED / CANCEL_ROLLBACK_FAILED | 409 | 1 | 補償失敗，找主管 |
| IDEMPOTENT_REPLAY | 200 | 0 | 重送回上次答案 |

---

## 4. 關鍵設計決策（6 條，每條含「沒這樣做會怎樣」）

### 4.1 全部 snake_case（`remittance_transaction` 等 4 個 id）

- **選了什麼**：`remittance_transaction`、`remittance_domestic`、`remittance_swift`、`remittance_cancellation`，版本全 `1.0.0`。
- **為什麼**：Kogito 10.2.0 codegen bug——Parent 有 `subFlowRef` 且 id 含 `-` 會產生不合法變數名，編譯炸 `';' expected`。
- **沒選什麼**：業務書的 hyphen/駝峰寫法。
- **不這樣做的後果**：整合期改 9 處以上，至少半天。
- **在哪裡看到**：4 個 `.sw.yaml` 的 `id:`、`subFlowRef.workflowId`、snippet 的 `workflows=`、SQL view 的 `IN (...)`。

### 4.2 驗證放流程內三件套，不用 dataInputSchema

- **選了什麼**：`ValidateInput`(operation)→`CheckValidationResult`(switch)→`FinalAuditAndEnd`，失敗走 `InjectValidationFailedStatus` 照樣寫 audit。
- **為什麼**：金融審計「失敗也要留痕」；原生 `dataInputSchema` 在實例建立前丟 400，到不了 audit，造成 Audit Gap。
- **沒選什麼**：原生 schema、Parent-通用型簡化版（本 Parent 是對外入口，必須完整三件套）。
- **不這樣做的後果**：P1–P4 驗證失敗在監控/view 裡消失。
- **在哪裡看到**：`spec/remittance-parent.sw.yaml` 前三個 state。

### 4.3 Mock 用 Mode A（`FAIL_`/`RBFAIL_`/`HIT`），validator 配合放行

- **選了什麼**：`amount=FAIL_…`→Core 拒絕、`beneficiaryAccount=FAIL_…`→通匯失敗、`receiverBIC=FAIL_…`→SWIFT 失敗、`partyName 含 HIT`→AML 命中、`purposeCode=99999`→FX 失敗；internal schema 的 amount/sequenceNumber regex 內建 `FAIL_` 分支，H13a validator 剝離前綴後再測，switch 用 `tostring` 比對避開 `tonumber` 炸裂。
- **為什麼**：測試不改程式就能走失敗路徑；Mode B 獨立欄位真實主機沒有，易忘拔。
- **不這樣做的後果**：三件套缺一即斷鏈（regex 擋掉、或 jq 拋錯 finalStatus=null）；實況新 5 域即因此失敗路徑零覆蓋。
- **在哪裡看到**：`notebooks/internal` pattern、`spec/mocks/*.java` 的 `startsWith`、Child YAML 的 `tostring` 條件。

### 4.4 雙軌 results：主機 `code` 另算、對外 `status` 重算

- **選了什麼**：讀主機用 `results: '{status: .code, …}'`（頂層 `.code`，string）；對外用 `status: (if .finalStatus == "SUCCESS" or … then 0 else 1 end)` 重算 int。
- **為什麼**：主機 `code` 是 string 業務碼，對外 `status` 是 int 成功系/失敗系；`MyOpenApiService` 回頂層欄位，寫 `.result.code` 拿 null。
- **不這樣做的後果**：status 全 null，status-rewrite 失效。
- **在哪裡看到**：Child YAML 所有 `actionDataFilter.results`、Parent `output.status`。

### 4.5 直調必寫 toStateData，subFlow 豁免

- **選了什麼**：每個直調 action 配 `toStateData: '${ .coreResult }'`（或 aml/clearing/swift/fx/refund/lookup 等 key）。
- **為什麼**：Kogito 無 `toStateData` 會把 results 蓋掉整份記憶體，`partyId/amount/sequenceNumber` 全丟失。
- **例外**：`subFlowRef`（本 draft 3 處皆無 actionDataFilter，正常）、terminal recordAuditLog。
- **在哪裡看到**：4 個 YAML 共 16 處 `toStateData`（預檢 6.8）。

### 4.6 subFlowRef version 對齊＋FX 補充契約

- **選了什麼**：Parent 三個 `subFlowRef.version` 全 `1.0.0`＝child `version`；FX 主機需求書僅端點名，本 draft 補最小可用 `fx-report-api.yaml`（opType=R），央行批次差異列 §9。
- **為什麼**：omni 實況 1.0.1 vs 1.0 殘留教訓；FX 不補則 WF-B 階段 4 無 schemaRef 可掛。
- **不這樣做的後果**：版不一致啟動失敗；或 WF-B 缺一階段。
- **在哪裡看到**：parent YAML 三處 `version: '1.0.0'`、`notebooks/external/fx-report-api.yaml`。

---

## 5. 產出物地圖：21 個檔案各是幹嘛的

```
draft-remittance/
├── design-explanation.md                   ← 本檔（給創建者看為什麼這樣設計）
├── notebooks/                              ← OpenAPI SSOT
│   ├── internal/
│   │   └── omni-remittance-api.yaml        ← 對外入口。唯一含 x-workflow-id 的檔；18 欄位、19 終態全定義
│   └── external/                           ← 被調 host（皆無 x-workflow-id）
│       ├── core-account-api.yaml           ← Core 4 端點，含 {partyId}
│       ├── aml-screening-api.yaml          ← AML 3 端點
│       ├── domestic-clearing-api.yaml      ← 通匯 3 端點，含 {partyId}
│       ├── swift-outbound-api.yaml         ← SWIFT 5 端點（無 path param）
│       └── fx-report-api.yaml              ← FX 補充契約（opType=R）
└── spec/
    ├── spec.md                             ← 規格書（H1–H18＋11 章＋Manifest）
    ├── remittance-parent.sw.yaml           ← Parent：驗證三件套→冪等→Dispatcher→3 subFlow→稽核回應
    ├── remittance-domestic.sw.yaml         ← WF-A：Core→AML→Clearing＋退款補償
    ├── remittance-swift.sw.yaml            ← WF-B：Core→AML→SWIFT→FX＋退款補償
    ├── remittance-cancellation.sw.yaml     ← WF-C：Lookup→Core退款→SWIFT取消→標記取消
    ├── db/V1.2.5__create_view_remittance_reconciliation.sql ← 對帳 view＋2 index
    ├── config/application.properties.snippet ← status-rewrite＋bean＋baseUrl 註解
    ├── mocks/CoreAccountResource.java＋AmlScreeningResource.java＋DomesticClearingResource.java＋SwiftOutboundResource.java＋FxReportResource.java ← 5 假主機（Mode A）
    ├── mocks/dto/ErrorDetail.java
    └── tests/RemittanceTransactionTest.java ← 5 場：P1/A1/P4/B1/B2
```

檔名-id 對應（檔名≠id 合法，已登記）：

| 檔案 | id |
|---|---|
| remittance-parent.sw.yaml | remittance_transaction |
| remittance-domestic.sw.yaml | remittance_domestic |
| remittance-swift.sw.yaml | remittance_swift |
| remittance-cancellation.sw.yaml | remittance_cancellation |

---

## 6. 流程解說：一個請求走一遍

### 6.1 國內（operationType=A，例 `A123456789 / 070 / 0000011758`）

```
POST /Omni/A123456789/Remittance/Execute
 → ValidateInput＋CheckValidationResult：A 且 18 欄齊 → 通過
 → CheckIdempotency：序號 RE_A1234567890000015061 未出現 → 繼續
 → Dispatcher：A → InvokeDomesticSubflow
 → WF-A：CallCoreDebit（partyId 同時餵 path＋body，fee 30）
    → CallAmlScreen（partyName 掃描）→ 通過
    → CallClearingOutbound（coreSequence 串接，DR_ 序號）
      → 成功 → SUCCESS → Parent FinalAuditAndEnd → {status:0, workflow:DOMESTIC_REMITTANCE}
      → 失敗 → RefundCore → ROLLED_BACK(200) / ROLLBACK_FAILED(409)
    → AML 命中 → RefundForAml → AML_REJECTED(200) / AML_REJECTED_ROLLBACK_FAILED(409)
```

### 6.2 跨境＋沖銷（B 例 `USD / DEUTDEFFXXX / 10100`；C 例 `TELLER_MISTAKE`）

```
B：同上進 InvokeSwiftSubflow → Core(USD＋fee)→AML→SWIFT MT103
   → 成功 → FX 申報 → SWIFT_PENDING(200，待 ack 監控)／FX 失敗則 FX_REPORT_FAILED(200)
   → SWIFT 失敗 → CompensateSwiftFail → SWIFT_ROLLED_BACK(200)／SWIFT_ROLLBACK_FAILED(409)
C：POST(多 originalSequenceNumber＋cancellationReason)
 → Dispatcher：C → WF-C：LookupOriginal
   → 找不到 → LOOKUP_FAILED(500)；已被取消／狀態非 SUCCESS 系 → CANCEL_REJECTED(200)
   → CallCoreRefund（CR_R_ 序號）→ 失敗 → CANCEL_FAILED(200，可重試)
   → 原為跨境 → CallSwiftCancel → 失敗 → CANCEL_ROLLBACK_FAILED(409)
   → MarkCancelled（cancelled_by＝本次序號）→ CANCELLED(200)
```

### 6.3 測試對應表

| 場景 | 怎麼觸發 | 預期 |
|---|---|---|
| P1 | operationType=D | 400 REJECTED_VALIDATION（有 audit） |
| A1 | 正常 A＋nanoTime 唯一序號 | 200 SUCCESS，status 0 |
| P4 | 同 payload 送兩次 | 第二次 IDEMPOTENT_REPLAY |
| B1 | 正常 B（USD/DEUTDEFFXXX/10100） | 200 SWIFT_PENDING 或 SUCCESS_AFTER_ACK |
| B2 | 先 A 成功再 C 指著它 | 200 CANCELLED（防污染：查 DB 確認 cancelled_by） |

---

## 7. 假設與待確認（H1–H18 精簡版，完整版見 spec.md §0）

| 假設 | 現在怎麼定 | 待確認 |
|---|---|---|
| 序號 22 字元（RE_＋19 碼） | example `RE_A1234567890000015061` 等 | A1：API owner 確認長度 |
| 當日內以 transactionDate 為準 | WF-C 預檢同日 | A2 業務確認 |
| 跨境 24h 後僅人工 | 列限制未硬擋 | A3 業務確認是否硬性 |
| AML 命中時 Core 已扣必須退款 | RefundForAml 兩條路 | A6 業務確認先扣後查 |
| 大額門檻 USD 50,000 | fee 預扣邏輯 | A7 確認 |
| 退匯視狀態更新不另設 Child | webhook 預留 | A8 確認時程 |
| FX 單筆送出 | 補充契約 | FX 批次格式確認 |
| Hold 圈存選用未用 | 統一扣款＋退款 | 業務確認是否啟用圈存 |

---

## 8. 驗證＋限制＋下一步

### 8.1 驗證（全綠）

- **9＋1 項平台預檢**：hyphen、全頂層欄位、path 注入、output 分流、無 trailing comma、sentinel、example 一致、toStateData、x-workflow-id 二分、version 對齊。
- **自查**：H1–H18 齊全、Manifest 雙表、5 場測試＋動態序號、`tostring` 防呆、`start` 顯式、servers 齊全、零 `schemas/*.json`。
- 本次無需修 bug（YAML 一次解析通過）。

### 8.2 已知限制

- 退匯 webhook、Hold 圈存、主機 seq 查詢端點覆蓋待確認（T4/T5）。
- FX 央行批次格式差異、跨境稅務另案。
- SWIFT ack 監控靠 MT199＋排程，超 24h 告警 P2（人工追蹤）。

### 8.3 移交下游（sonataflow-integration）

| draft 檔案 | 正式路徑 |
|---|---|
| 4 個 .sw.yaml | domain-transfer/transfer-workflow/.../resources/＋distribution 鏡像 |
| internal 1＋external 5 yaml | .../resources/specs/internal／external 雙模組同步 |
| V1.2.5 sql | domain-reconciliation/.../db/migration/ |
| config snippet | 合併進 distribution/.../application.properties |
| 5 mocks＋dto | dev/transfer-mock/.../org/acme/transfer/api/（已對齊免 rename） |
| 測試 | distribution/.../transfer/ 跑 QuarkusTest |
| spec.md＋本檔 | 隨包移交（技術＋創建者各一） |

### 附錄：名詞解釋

| 詞 | 白話 |
|---|---|
| Parent / Child | 總機／分機。Parent 接單分線，Child 跑三/四階段實活 |
| subFlowRef | Parent 說「這段交給 Child 做」的指令 |
| Dispatcher | 看 operationType 分 A/B/C 的分線規則 |
| 冪等 | 同序號送兩次只算一次，第二次回上次答案（IDEMPOTENT_REPLAY） |
| LIFO 補償 | 後段失敗，把前段已扣的錢反向沖掉 |
| Audit Gap | 有請求沒記錄；本 draft 驗證失敗也寫 audit 即為防它 |
| FQCN | Java 全名；下游靠它知道新建（H13a/H13b）或擴充（H6/H14） |
| Sentinel | 測試開關：FAIL_/RBFAIL_/HIT/99999 讓假主機故意走失敗路 |
| SSOT | 唯一真相：欄位規則只看 notebooks YAML，不另存 JSON |
