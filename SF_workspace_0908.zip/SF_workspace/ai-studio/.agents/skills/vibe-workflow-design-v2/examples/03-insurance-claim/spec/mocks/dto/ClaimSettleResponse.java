package org.acme.insurance.api.dto;

public class ClaimSettleResponse {
    public String code;
    public String message;
    public String settlementId;
}
