package org.acme.insurance.api;

import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.core.Response;
import org.acme.insurance.api.dto.ClaimSettleRequest;
import java.util.Map;

// 最小可跑骨架：Mode A 前綴哨兵 + validator FAIL_ 豁免（見 06）
@Path("/Claim/{claimId}/Settle/Execute")
public class ClaimSettleResource {

    @POST
    public Response execute(@PathParam("claimId") String claimId, ClaimSettleRequest request) {
        if (request.claimAmount != null && request.claimAmount.startsWith("FAIL_")) {
            return Response.status(403).entity(Map.of("code", "E2001", "message", "CLAIM_REJECTED")).build();
        }
        return Response.ok(Map.of("code", "0", "message", "SUCCESS", "settlementId", "SET_" + claimId)).build();
    }
}
