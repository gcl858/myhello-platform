package com.example.platform.distribution.transfer;

import io.quarkus.test.junit.QuarkusTest;
import org.junit.jupiter.api.Test;
import static io.restassured.RestAssured.given;

// 最小可跑骨架：實作 P1/A1，其餘 skeleton
@QuarkusTest
public class ClaimProcessingTest {

    private String uniq(String prefix) {
        return prefix + "_" + System.nanoTime();
    }

    @Test
    public void p1_invalid_action_400() {
        given().contentType("application/json")
            .body("{\"claimId\":\"" + uniq("CLM") + "\",\"action\":\"BAD\"}")
            .when().post("/claim_processing")
            .then().statusCode(400);
    }

    @Test
    public void a1_happy_new_200() {
        String cid = uniq("CLM");
        given().contentType("application/json")
            .body("{\"claimId\":\"" + cid + "\",\"action\":\"NEW\",\"claimAmount\":\"0000050000\"}")
            .when().post("/claim_processing")
            .then().statusCode(200);
    }

    // skeleton: P4 replay / B1 cancel CANCELLED / B2 LOOKUP_FAILED
}
