package org.acme.insurance.api.dto;

public class ErrorDetail {
    public String code;
    public String message;
}
