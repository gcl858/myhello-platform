package org.acme.insurance.api.dto;

public class ClaimSettleRequest {
    public String claimId;
    public String action;
    public String claimAmount;
}
