package org.acme.ecommerce.api.dto;

public class ErrorDetail {
    public String code;
    public String message;
}
