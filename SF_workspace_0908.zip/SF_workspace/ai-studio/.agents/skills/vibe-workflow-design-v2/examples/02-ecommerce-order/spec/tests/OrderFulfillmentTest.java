package com.example.platform.distribution.transfer;

import io.quarkus.test.junit.QuarkusTest;
import org.junit.jupiter.api.Test;
import static io.restassured.RestAssured.given;

// 最小可跑骨架：P1/A1/P4/B1/B2 五場中實作 2 場，其餘 3 場 skeleton（明確標示）。
// 動態序號 + view 防污染查詢見 sonataflow-integration Step 8/6f。
@QuarkusTest
public class OrderFulfillmentTest {

    private String uniq(String prefix) {
        return prefix + "_" + System.nanoTime();
    }

    @Test
    public void p1_invalid_missingItems_400() {
        given().contentType("application/json")
            .body("{\"orderId\":\"" + uniq("ORD") + "\",\"customerId\":\"C1\",\"totalAmount\":\"100\",\"items\":[]}")
            .when().post("/order_fulfillment")
            .then().statusCode(400);
    }

    @Test
    public void a1_happy_success_200() {
        String oid = uniq("ORD");
        given().contentType("application/json")
            .body("{\"orderId\":\"" + oid + "\",\"customerId\":\"C1\",\"totalAmount\":\"0000010000\",\"items\":[{\"sku\":\"S1\",\"qty\":1}]}")
            .when().post("/order_fulfillment")
            .then().statusCode(200);
        // skeleton: 斷言 finalStatus==SUCCESS + view 查詢 status='SUCCESS' ORDER BY id DESC LIMIT 1
    }

    // skeleton: P4 idempotent replay（同 orderId 重送 → IDEMPOTENT_REPLAY）
    // skeleton: B1 cancel path（若有）→ CANCELLED
    // skeleton: B2 lookup failed → 500 LOOKUP_FAILED
}
