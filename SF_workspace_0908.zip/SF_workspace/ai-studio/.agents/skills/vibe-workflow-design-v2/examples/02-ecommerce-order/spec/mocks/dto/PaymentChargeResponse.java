package org.acme.ecommerce.api.dto;

public class PaymentChargeResponse {
    public String code;
    public String message;
    public String paymentId;
}
