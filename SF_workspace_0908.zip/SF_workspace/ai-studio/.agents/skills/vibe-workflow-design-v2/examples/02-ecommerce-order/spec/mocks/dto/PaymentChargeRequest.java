package org.acme.ecommerce.api.dto;

// 最小可跑骨架：純 public field，無 getter/setter（與 transfer-mock 一致）
public class PaymentChargeRequest {
    public String orderId;
    public String customerId;
    public String amount; // 業務金額字串；哨兵 FAIL_* 需 validator 豁免（見 06）
}
