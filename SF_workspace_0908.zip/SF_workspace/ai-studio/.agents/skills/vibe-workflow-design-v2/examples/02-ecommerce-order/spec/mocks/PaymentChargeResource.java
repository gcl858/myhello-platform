package org.acme.ecommerce.api;

import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.core.Response;
import org.acme.ecommerce.api.dto.PaymentChargeRequest;
import java.util.Map;

// 最小可跑骨架：Mode A 前綴哨兵為主（見 06）；draft 佔位 package，下游 Step 5 rename 兜底
@Path("/Payment/{orderId}/Charge/Execute")
public class PaymentChargeResource {

    @POST
    public Response execute(@PathParam("orderId") String orderId, PaymentChargeRequest request) {
        // 哨兵：amount 以 FAIL_ 開頭 → 業務拒絕（需 validator FAIL_ 豁免，見 SKILL 5b）
        if (request.amount != null && request.amount.startsWith("FAIL_")) {
            return Response.status(403).entity(Map.of("code", "E1001", "message", "PAYMENT_REJECTED")).build();
        }
        if (request.amount == null || request.amount.equals("0") || request.amount.equals("0000000000")) {
            return Response.status(403).entity(Map.of("code", "E1001", "message", "PAYMENT_REJECTED")).build();
        }
        return Response.ok(Map.of("code", "0", "message", "SUCCESS", "paymentId", "PAY_" + orderId)).build();
    }
}
