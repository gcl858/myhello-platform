# Reference 09: x-workflow-id 與 servers + internal/external 嚴格二分

> 對應 SKILL.md Step 6.9 + 7.21/7.25
> 實況：21 specs 僅 internal 1 有標籤；fx-exchange 缺 servers 仍運行；external/ 空待啟用；root omni 雙份漂移

---

## 規則（嚴格二分，root 禁放）

- `draft/notebooks/internal/*.yaml`：Parent 對外入口，每個 `post:` 必含 `x-workflow-id`（validator+router 唯一 SSOT）。
- `draft/notebooks/external/*.yaml`：被調 host 規格，禁止含 `x-workflow-id`/`x-kogito-workflow-id`。
- `draft/notebooks/*.yaml`（root）：禁止放業務 yaml（`openapi.yaml` 聚合除外），違者搬入 external。
- 整併後：`specs/internal/` + `specs/external/` 雙模組同步；root `specs/*.yaml` 僅相容舊案 20 檔，新案禁止再落 root；入口禁止落 root（root 舊 omni 無標籤嚴格版視為待刪，以 internal 放寬版為準）。
- `servers[0].url`：建議 `http://localhost:8080`，缺失走 `base_url>%dev.host>servers` fallback，不 FAIL。

## 自動檢查腳本

```bash
#!/bin/bash
# 用途：Step 6.9 — internal 必含標籤；external 必無；root 禁放
set -e
for f in draft/notebooks/internal/*.yaml; do
  [ -e "$f" ] || { echo "⚠️ 未發現 draft/notebooks/internal/*.yaml"; break; }
  python3 - "$f" <<'PY'
import yaml, sys
f = sys.argv[1]
s = yaml.safe_load(open(f))
for path, ops in (s.get("paths") or {}).items():
    for m, op in (ops or {}).items():
        if not isinstance(op, dict): continue
        if m.lower() == "post" and "x-workflow-id" not in op:
            print(f'❌ FAIL: {f} {path} 缺少 x-workflow-id')
        if "servers" not in s:
            print(f'⚠️ WARN: {f} 缺 servers，靠 baseUrl fallback（可接受，需 §0 註明）')
PY
done
echo "ℹ️ external（draft/notebooks/external/*.yaml）禁止 x-workflow-id；root（draft/notebooks/*.yaml）禁止放業務 yaml"
for f in draft/notebooks/external/*.yaml; do
  [ -e "$f" ] || continue
  grep -q "x-workflow-id" "$f" && echo "❌ FAIL: $f external 禁止含 x-workflow-id"
done
for f in draft/notebooks/*.yaml; do [ -e "$f" ] && echo "❌ FAIL: root $f 請搬入 notebooks/external/"; done
echo "ℹ️ 整併後 internal/external 同名檔除標籤外內容須一致（防 root omni 式漂移）"
```

## spec.md 標註範本

```markdown
| H5 | **入口路由**：`notebooks/internal/omni-*.yaml` post 含 `x-workflow-id: omni_cash_transaction`；host specs 不含 | 動態路由僅 Parent 需要 | — | Step 6.9 PASS |
| H21 | **BaseUrl**：specs 填 `http://localhost:8080`，缺失時靠 `%dev.callApiViaOpenAPI` fallback | fx-exchange 實況缺 servers 教訓 | — | §5 config snippet 註明 |
```
