# Reference 08: toStateData 作用域（直調才查，子流豁免）

> 對應 SKILL.md Step 3c 鐵律 2 + Step 6.8 + 7.23
> 來源：project-0825-pd 20 workflow 實況（12 subFlow 全無 actionDataFilter 屬正常）

---

## 規則

- 直調 `functionRef`（`callApiViaOpenAPI/checkIdempotency/lookup*/validate*`）若有 `results` 必有 `toStateData: '${ .xxxResult }'`。
- 豁免（不 FAIL）：
  1. `subFlowRef` invoke（`actions: [{ subFlowRef: ... }]`，實況 12 處全無 filter）
  2. terminal `recordAuditLog`（child End 8 處無 filter 屬正常）
  3. `MarkOriginalCancelled` 非關鍵路徑（5 處無 toStateData 可免，僅 repayment-cancellation 有 `${ .markResult }` 屬加分）

## 自動檢查腳本（排除誤報）

```bash
#!/bin/bash
# 用途：Step 6.8 — 只查直調，自動排除 subFlowRef 上下文
# 用法：./check-tostatedata.sh draft/spec/*.sw.yaml
set -e
FAIL=0
for f in "$@"; do
  # 逐段檢查：actionDataFilter 段內有 results 卻無 toStateData，且同段無 subFlowRef
  python3 - "$f" <<'PY'
import re, sys
f = sys.argv[1]
txt = open(f).read()
# 粗切 states 段
blocks = re.split(r'(?m)^\s*-\s*name:\s*', txt)
bad = []
for b in blocks:
    if "actionDataFilter:" not in b: continue
    if "subFlowRef" in b.split("actionDataFilter:")[0][-500:]: continue
    m = re.search(r'actionDataFilter:\s*\n((?:.*\n){1,5})', b)
    seg = m.group(0) if m else ""
    if "results:" in seg and "toStateData" not in seg and "subFlowRef" not in b[:2000]:
        bad.append(b.splitlines()[0][:80])
if bad:
    print(f'❌ FAIL: {f} 直調缺 toStateData: {bad}')
    sys.exit(1)
else:
    print(f'✅ PASS: {f}')
PY
done
```

## 對錯範例

```yaml
# ✅ 對：直調隔離注入
actionDataFilter:
  results: '{isValid: .isValid, message: .message, errors: .errors}'
  toStateData: '${ .validationResult }'

# ✅ 對（豁免）：子流無需 filter
- subFlowRef:
    workflowId: repayment_cash_deposit
    version: '1.0.1'

# ❌ 錯：直調缺 toStateData（輸入會被沖掉）
actionDataFilter:
  results: '{isValid: .isValid, message: .message, errors: .errors}'
```

下游詳見 `sonataflow-integration Step 6e`（State Data 沖洗症狀與修法）。
