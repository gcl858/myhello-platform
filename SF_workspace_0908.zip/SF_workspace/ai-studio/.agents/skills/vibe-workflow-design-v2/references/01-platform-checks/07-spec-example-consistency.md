# Reference 07: Spec Schema 與 Example/測試 Payload 一致性（YAML SSOT，無 JSON）

> 對應 SKILL.md Step 6.7 預檢 + 7.16/7.22
> SSOT 為 notebook YAML 內 `components.schemas/requestBody`；⛔ 禁止 `spec/schemas/*.json`（見 SKILL Step 8）

---

## 規則

OpenAPI YAML（`draft/notebooks/internal/*.yaml` + `draft/notebooks/external/*.yaml`）內每個 `properties.<field>` 的 `maxLength/minLength/pattern` 必須同時相容三者：`example`、測試 payload、真實業務樣本（如通路代碼 `2500P`）。

禁止：
- 宣告 `maxLength: 4` 但 example 給 `2500P`（5 碼）
- 宣告 `maxLength: 22` 但 example 含 prefix 達 25 碼
- `pattern: ^[0-9]+$` 卻要求支援 `FAIL_*` 哨兵而不加 validator 豁免（見 06）

## 自動檢查腳本

```bash
#!/bin/bash
# 用途：Step 6.7 — example 長度 vs maxLength/minLength；pattern 另需人工確認 FAIL_ 豁免
# 用法：./check-spec-example.sh draft/notebooks/internal/*.yaml draft/notebooks/external/*.yaml
set -e
FAIL=0
for f in "$@"; do
  python3 - "$f" <<'PY'
import yaml, sys
f = sys.argv[1]
s = yaml.safe_load(open(f))
bad = 0
def walk(props, prefix=""):
    global bad
    for pn, p in (props or {}).items():
        ex = p.get("example"); mx = p.get("maxLength"); mn = p.get("minLength")
        if isinstance(ex, str):
            if mx and len(ex) > mx:
                print(f'❌ FAIL: {f} {prefix}{pn} example "{ex}" len={len(ex)} > maxLength {mx}'); bad = 1
            if mn and len(ex) < mn:
                print(f'❌ FAIL: {f} {prefix}{pn} example "{ex}" len={len(ex)} < minLength {mn}'); bad = 1
for path, ops in (s.get("paths") or {}).items():
    for m, op in (ops or {}).items():
        if not isinstance(op, dict): continue
        rb = ((op.get("requestBody") or {}).get("content") or {}).get("application/json", {}).get("schema", {})
        walk(rb.get("properties"), f"{path} ")
for sn, sch in ((s.get("components") or {}).get("schemas") or {}).items():
    walk(sch.get("properties"), f"#{sn}.")
PY
done
```

## pattern 與哨兵對照（人工）

| pattern | 允許哨兵 | 條件 |
|---|---|---|
| `^[0-9]+$` | `FAIL_*` 僅當 validator 有剝離豁免 | 見 06 + H13a validator 註冊 |
| `^[A-Za-z0-9]{1,10}$` | `FAIL_*`、`2500P` | 通路代碼推薦此寬度 |
| 嚴格業務碼 | 無哨兵，用 `amount=0` 觸發拒絕 | Mock 改用 `equals("0")` |

## spec.md 標註範本

```markdown
| H16 | **Example 相容**：`branchCode` pattern `^[A-Za-z0-9]{1,10}$` 覆蓋 `2500P` 與 `FAIL_*` | 真實樣本 + 哨兵需求 | — | notebooks/*-api.yaml 全欄已跑 check-spec-example.sh |
```
