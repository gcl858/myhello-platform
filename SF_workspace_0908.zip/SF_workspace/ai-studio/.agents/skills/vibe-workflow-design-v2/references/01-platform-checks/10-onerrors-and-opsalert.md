# Reference 10: onErrors 覆蓋 + notifyOps 告警 (Audit Gap 防線)

> 對應 SKILL.md Step 6.11 預檢 + 自查 7.28
> 來源：`draft-remittance/spec/remittance-swift.sw.yaml` 審查（宣告 platformError 卻零 onErrors；定義 notifyOps 卻零調用）

---

## 核心規則

1. 凡宣告 `errors:` 的 workflow，每個 `type: operation` 必須有 `onErrors`（terminal audit state 除外）。
2. 凡 `finalStatus` 含 `ROLLBACK_FAILED` 的 workflow，必須至少一處調用 `notifyOps`。

違反任一即 Audit Gap 或靜默失敗：host timeout / 拋 exception 會繞過 `FinalAuditAndEnd`，`ROLLBACK_FAILED` 無人知曉。

---

## ✅ 對的寫法

```yaml
- name: CallCoreDebit
  type: operation
  onErrors:
    - errorRef: platformError
      transition: FinalizeFailed
  actions:
    - functionRef:
        refName: callApiViaOpenAPI
        arguments:
          functionName: callApiViaOpenAPI
          schemaRef: 'specs/external/core-account-api.yaml#executeCoreDebit'
          payload:
            partyId: '${ .partyId }'
      actionDataFilter:
        results: '{status: .code, message: .message}'
        toStateData: '${ .coreResult }'
  transition: CheckCoreResult

- name: ChildFinalAuditAndEnd
  type: operation
  actions:
    - functionRef:
        refName: recordAuditLog
        arguments:
          workflowId: remittance_swift
          sequenceNumber: '${ .sequenceNumber }'
          finalStatus: '${ .finalStatus }'
    - name: alertOnRollbackFailed
      functionRef:
        refName: notifyOps
        arguments:
          workflowId: remittance_swift
          sequenceNumber: '${ .sequenceNumber }'
          finalStatus: '${ .finalStatus }'
          # 建議 Java 側僅當 finalStatus 含 ROLLBACK_FAILED 才發告警，避免成功路徑噪音
  end: true
```

---

## ❌ 錯的寫法

```yaml
errors:
  - name: platformError
    code: 'PLATFORM_ERROR'
# ...但 operation 全無 onErrors → host 拋錯直接炸，不進 audit
- name: CallCoreDebit
  type: operation
  actions: [...]
  transition: CheckCoreResult

functions:
  - name: notifyOps
    operation: 'service:com.example.reconciliation.OpsAlertService::raise'
    type: custom
# ...但全檔無 notifyOps 調用 → ROLLBACK_FAILED 靜默結束
```

---

## 自動檢查腳本

```bash
#!/bin/bash
# 用途:Step 6.11 預檢 — onErrors 覆蓋 + notifyOps 調用
set -e
FAIL=0
for f in draft/spec/*.sw.yaml; do
  ops=$(grep -c "type: operation" "$f" || true)
  errs=$(grep -c "onErrors:" "$f" || true)
  # terminal audit state 可豁免 1 個（ChildFinalAuditAndEnd / FinalAuditAndEnd）
  if [ "$errs" -lt "$((ops - 1))" ]; then
    echo "❌ FAIL: $f operation=$ops 但 onErrors=$errs（terminal 僅豁免 1 個）"
    FAIL=1
  else
    echo "✅ PASS: $f onErrors 覆蓋 $errs/$ops"
  fi
  if grep -q "ROLLBACK_FAILED" "$f"; then
    # 注意：須查 refName 調用，僅 functions 定義不算（定義本身就含 notifyOps 字串）
    if ! grep -q "refName: notifyOps" "$f"; then
      echo "❌ FAIL: $f 有 ROLLBACK_FAILED 終態卻零 notifyOps 調用"
      FAIL=1
    fi
  fi
done
exit $FAIL
```
