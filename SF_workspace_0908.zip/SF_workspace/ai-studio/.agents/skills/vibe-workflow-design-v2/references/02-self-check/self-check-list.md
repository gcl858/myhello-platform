# Reference: 28+1 項 Self-Check 清單（v2.3）

> 對應 SKILL.md Step 7（7.1-7.27；7.27 為 design-explanation 必產檢查）
> 用於設計完成後逐項驗證；下游 E2E/編譯以 `sonataflow-integration Step 9-10` 為準，此處僅設計期

---

## 完整清單

| # | 檢查項 | 通過條件 | 對應 SKILL 步驟 | 對應預檢 |
|---|---|---|---|---|
| 7.1 | `spec.md §0 假設清單` 含 FQCN 假設（含 H13a validator） | ✅ 每個新 service/validator 都有 FQCN + 落地策略 | Step 1a | — |
| 7.2 | `spec.md §0` 含 `id 命名決策` + 檔名-id Manifest | ✅ snake_case + 檔名≠id 登記，或註明 v1.0 hotfix | Step 1a | 01 |
| 7.3 | `spec.md §0` 含 `convention 決策`（Parent/Child/Saga 分流） | ✅ Parent 舊/新/純 HTTP；Child 僅 finalStatus | Step 1c | 04 |
| 7.4 | OpenAPI spec 的 path param 與 workflow YAML 的 payload 對應 | ✅ 每個 `{xxx}` 都有對應 payload key | Step 6.3 | 03 |
| 7.5 | 直調 actionDataFilter 全部用頂層欄位（subFlowRef 豁免） | ✅ 直調 grep 不到 `.result.X` 配對 | Step 3c | 02 |
| 7.6 | stateDataFilter.output 對應 convention 與層級，且 output key 皆有賦值 | ✅ Parent 舊:`status`；Parent 新:`status: 0/1`+`finalStatus`；Child:僅 `finalStatus`；output 每個 key 至少在一個 inject/operation 被賦值 | Step 3d | 04 |
| 7.7 | Mock sentinel 字串能通過 input validation（A + FAIL_ 豁免為主） | ✅ 設計期實測；B 僅備選 | Step 5b | 06 |
| 7.8 | Mock package 命名（draft 佔位可，註明 rename 映射） | ✅ §8 有 rename 映射或已對齊；DTO 防 `.dto.dto` | Step 5a | — |
| 7.9 | SQL migration V 編號遞增 | ✅ 從既有最大 +1 | Step 4d | — |
| 7.10 | YAML 沒有 trailing comma | ✅ grep 不到 `,$\|,$` 結尾的 list item | Step 6.5 | 05 |
| 7.11 | spec/config/application.properties.snippet 含 status-rewrite 完整配置 | ✅ workflows + mapping + %dev/%prod bean + baseUrl 註解 | Step 8 | 04 |
| 7.12 | 測試套件包含 P1/A1/P4/B1/B2 五場 | ✅ P1 400/A1 SUCCESS/P4 REPLAY/B1 CANCELLED/B2 LOOKUP_FAILED；view 查詢加 `status='SUCCESS' ORDER BY id DESC LIMIT 1` | Step 8 | — |
| 7.13 | 測試資料字串能通過 input validation | ✅ 每個測試 payload 都驗過 | Step 6.6 | 06 |
| 7.14 | spec.md §8 Project Mapping Manifest 完整（含檔名-id + 雙模組路徑） | ✅ 每個 draft 檔案都有對應正式路徑 + 檔名-id 行 | Step 7 | — |
| 7.15 | spec.md §9 已知限制有列 | ✅ v1.0 留白 / 簡化項目都明確標出 | Step 7 | — |
| 7.16 | Input Validation Regex 與 API Sample 相容 | ✅ 通路代碼/欄位正則相容真實範例（如 `2500P`） | Step 1a | 06 |
| 7.17 | 測試案例採用動態唯一序號 | ✅ 正向/反向 `System.nanoTime()`；固定值僅 P1/B2 未入庫路徑 | Step 8 | — |
| 7.18 | jq 條件表達式 `tonumber` 防呆 + null guard | ✅ 用 `tonumber? //` 或 `startswith("FAIL_")` 守衛；所有讀 `.xxx.status` 的 condition 必須帶 `//` 預設值 | Step 3a | 06 |
| 7.19 | Workflow Root 顯式定義 `start`（四類值皆可） | ✅ `ValidateInput/ValidateChildInput/LookupOriginal/Call*`；避免 `getStart() is null` NPE | Step 3a | 01 |
| 7.20 | Service Function 參數鍵值對齊 Java 三入口簽名 | ✅ `workflowId`+`businessKey`；展開/Map/JsonNode，避免 ClassCastException | Step 3b | — |
| 7.21 | OpenAPI Spec `servers[0].url`（建議有，缺失走 fallback 不 FAIL） | ✅ 有則 `http://localhost:8080`；缺則 §0 註明 fallback 鏈 | Step 4 | 09 |
| 7.22 | OpenAPI Spec 欄位約束與 Example/測試 Payload 嚴格相容 | ✅ `maxLength`/`minLength` 覆蓋 example 與真實序號 | Step 2a | 07 |
| 7.23 | 直調 Operation State 若使用 results 必須顯式宣告 `toStateData`（subFlow/終端豁免） | ✅ 防 State Data 沖刷；子流無 filter 屬正常 | Step 3c | 08 |
| 7.24 | 金融工作流程輸入驗證避免原生 `dataInputSchema`（分流見 SKILL 1d） | ✅ Parent-Omni 完整三件套；其餘 Parent/Child 分流 | Step 1d | — |
| 7.25 | Parent 對外入口置於 `draft/notebooks/internal/` 且含 `x-workflow-id`；host 置於 `draft/notebooks/external/` 且必無標籤；root 禁放業務 yaml | ✅ Vert.x 動態路由解析；external 零標籤 | Step 2a | 09 |
| 7.26 | subFlowRef version 對齊 child version | ✅ 如 parent 1.0.1 則 subFlow 亦 1.0.1 | Step 6.10 | — |
| 7.27 | `design-explanation.md` 已產出且與 draft 一致（創建者導向，必產） | ✅ 9 節齊全 + 決策/假設/檔案地圖與實際產出一致，無虛構欄位；範例值來自 notebooks example 或測試 payload | Step 8b | — |
| 7.28 | onErrors 覆蓋 + ROLLBACK_FAILED 必告警（見 6.11/10） | ✅ `onErrors` 數 ≥ `operation` 數 −1（terminal 豁免 1 個）；有 `ROLLBACK_FAILED` 終態則必調用 `notifyOps` | Step 6.11 | 10 |
| 7.29 | 業務欄位禁止 literal 硬編碼，衍生欄位須含運算式 | ✅ `currency/BIC/country/address/fee/rate` 一律 `${ .field }`（僅允許 OUR/BEN/A/B/C/R）；`amountInUSD` 類必須含 `fxRate` 運算或 §0 假設註明 | Step 3b | — |

---

## 自動執行腳本

把所有檢查串起來:

```bash
#!/bin/bash
# 用途:設計完成後一次跑完 25+1 項 self-check（部分需獨立預檢腳本）
# 用法:./run-self-check.sh draft-<name>/

set -e
DRAFT_ROOT="$1"

if [ -z "$DRAFT_ROOT" ]; then
  echo "Usage: $0 <draft-root>"
  exit 2
fi

TOTAL=0
PASS=0
FAIL_LIST=()

check() {
  local id="$1"
  local desc="$2"
  local cmd="$3"
  TOTAL=$((TOTAL+1))
  echo "─── [$id] $desc ───"
  if eval "$cmd" > /dev/null 2>&1; then
    echo "✅ PASS"
    PASS=$((PASS+1))
  else
    echo "❌ FAIL"
    FAIL_LIST+=("$id: $desc")
  fi
  echo ""
}

# 7.1
check "7.1" "spec.md §0 含 FQCN 假設（含 validator）" \
  "grep -E 'FQCN' $DRAFT_ROOT/spec/spec.md | grep -E 'service|method|Validator'"

# 7.2
check "7.2" "spec.md §0 含 id 命名決策 + 檔名-id" \
  "grep -E 'ID 命名|snake_case|kebab-case' $DRAFT_ROOT/spec/spec.md | grep -E '檔名|Manifest|snake_case'"

# 7.3
check "7.3" "spec.md §0 含 convention 決策（Parent/Child 分流）" \
  "grep -E 'Convention' $DRAFT_ROOT/spec/spec.md | grep -E 'Parent|Child|舊|新|HTTP'"

# 7.4
# (需獨立跑 03-path-parameter-injection 預檢)

# 7.5
check "7.5" "直調 actionDataFilter 無 .result.X（subFlowRef 豁免，見 08）" \
  "bash references/01-platform-checks/02-action-data-filter.md >/dev/null 2>&1 || ! grep -rE 'actionDataFilter' $DRAFT_ROOT/spec/*.sw.yaml -A 3 | grep -E '\\.result\\.[a-zA-Z_]+' | grep -v subFlowRef"

# 7.6
check "7.6" "stateDataFilter.output 對應 convention 與層級" \
  "grep -E 'stateDataFilter' $DRAFT_ROOT/spec/*.sw.yaml -A 20 | grep -E 'finalStatus:|status:.*0|status:.*1|finalMessage'"

# 7.7
# (跑 06 預檢：Mode A + FAIL_ 豁免，見 references/01-platform-checks/06*)

# 7.8
check "7.8" "mock package 註明 rename 映射或已對齊" \
  "grep -rE '^package org\\.acme\\.[a-z]+\\.api' $DRAFT_ROOT/spec/mocks/ || grep -E 'rename|org\\.acme' $DRAFT_ROOT/spec/spec.md"

# 7.9
# (需手動查既有 V 編號：find <project>/ -path '*/db/migration/V*.sql' | sort -V | tail -1)

# 7.10
check "7.10" "YAML 無 trailing comma" \
  "! grep -rE '^\\s+\\w+:\\s+.+,\\$' $DRAFT_ROOT/spec/*.sw.yaml"

# 7.11
check "7.11" "application.properties.snippet 含 status-rewrite + bean + baseUrl 註解" \
  "grep -E 'status-rewrite' $DRAFT_ROOT/spec/config/application.properties.snippet && grep -E 'kogito.sw.functions|base_url|servers' $DRAFT_ROOT/spec/config/application.properties.snippet"

# 7.12
check "7.12" "測試套件含 P1/A1/P4/B1/B2 五場 (>=5 案例）" \
  "test \$(grep -c '@Test' $DRAFT_ROOT/spec/tests/*.java) -ge 5 && grep -rE 'IDEMPOTENT_REPLAY|LOOKUP_FAILED|REJECTED_VALIDATION' $DRAFT_ROOT/spec/tests/"

# 7.13
# (需手動驗證 payload 過 validation，或跑 06+07 腳本)

# 7.14
check "7.14" "spec.md §8 含 Project Mapping Manifest（含檔名-id + 雙模組路徑）" \
  "grep -E 'Project Mapping|draft.*正式|檔名.*id|transfer-workflow.*distribution' $DRAFT_ROOT/spec/spec.md"

# 7.15
check "7.15" "spec.md §9 含已知限制" \
  "grep -E '已知限制|Known Limitation' $DRAFT_ROOT/spec/spec.md"

# 7.16 (跑 07 腳本)
# 7.17
check "7.17" "測試用動態唯一序號" \
  "grep -rE 'nanoTime|currentTimeMillis' $DRAFT_ROOT/spec/tests/"

# 7.18
check "7.18" "jq tonumber 防呆" \
  "! grep -rh 'tonumber)' $DRAFT_ROOT/spec/*.sw.yaml | grep -v 'tonumber?' | grep -v 'startswith' || grep -rq 'tonumber?' $DRAFT_ROOT/spec/*.sw.yaml"

# 7.19
check "7.19" "Workflow Root 有 start" \
  "grep -E '^start:' $DRAFT_ROOT/spec/*.sw.yaml"

# 7.20
check "7.20" "functionRef 含 workflowId/businessKey" \
  "grep -E 'workflowId:|businessKey' $DRAFT_ROOT/spec/*.sw.yaml"

# 7.21 (WARN 級：servers 缺失可用 fallback，見 09)
# 7.22 (跑 07 腳本)
# 7.23 (跑 08 腳本)
# 7.24
check "7.24" "無 dataInputSchema" \
  "! grep -rq 'dataInputSchema' $DRAFT_ROOT/spec/*.sw.yaml"

# 7.25 (跑 09 腳本)
# 7.26 (跑 6.10：人工比對 subFlowRef version == child version)

# 總結
echo "============================================"
echo "Self-Check 結果: $PASS/$TOTAL PASS"
echo "============================================"
if [ ${#FAIL_LIST[@]} -gt 0 ]; then
  echo "❌ FAIL 項目:"
  for item in "${FAIL_LIST[@]}"; do
    echo "  - $item"
  done
  exit 1
fi
```

---

## 為何不全部自動化?

有些檢查項目**需要語意理解**,無法純靠 grep:

- 7.4 (path param 對應): 需解析 YAML 結構,確認 payload 內有對應 key
- 7.7 / 7.13 (sentinel vs validation): 需比對 mock 內的字串與 schema regex
- 7.9 (V 編號遞增): 需查 project 既有最大 V 編號

這些項目提供自動檢查腳本 + 人工 review 雙軌並用。
