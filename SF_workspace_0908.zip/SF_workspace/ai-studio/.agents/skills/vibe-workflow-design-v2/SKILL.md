---
name: vibe-workflow-design-v2
description: 從業務需求與 host API 規格出發,設計可直接整併到 SonataFlow / Kogito 平台的 workflow draft。涵蓋 10 項設計期自我檢查守則、平台相容性預檢、整合前置產出物(OpenAPI specs / workflow YAMLs / DDL / Mock Java / Test / 規格書 / 創建者導向 design-explanation)。設計完成即可移交 `sonataflow-integration` skill。
---

# Vibe Workflow Design v2

> v2 重點:把 9 個真實整併踩坑(從 `draft-omni-counter-repayment` → `project-0825-pd` 案例)上移為**設計期自我檢查守則**,讓 draft 在交付前就符合目標平台規範,降低下游整合工時 60%。本版為 v2.3：v2.2（必產 design-explanation.md）再加 **6.11 onErrors+notifyOps 預檢、7.28/7.29、7.6/7.18 擴充（源自 remittance_swift 審查）**。

## 📦 套件內容

```
vibe-workflow-design-v2/
├── SKILL.md                          # 本檔 (SOP 主文件)
├── examples/                         # 範例（01 完整真實案例；02/03 最小可跑骨架）
│   ├── 01-financial-repayment/       # 金融信用卡繳款 (Mode B,真實案例，完整)
│   ├── 02-ecommerce-order/           # 電商訂單履行 (Mode A，最小可跑骨架)
│   └── 03-insurance-claim/           # 保險理賠 (Mode B 跨領域，最小可跑骨架)
└── references/                       # 可重用資源
    ├── 01-platform-checks/           # 10 項平台相容性預檢 01-10 (各含自動檢查腳本)
    ├── 02-self-check/                # 29 項 self-check 清單 (7.1-7.29，7.27 為 design-explanation)
    ├── 03-templates/                 # 5 種 workflow YAML 範本（A/B/C 生產可用；D/E 實驗性）
    ├── 04-config-snippets/           # application.properties.snippet 完整模板（含 %dev/%prod 與 baseUrl fallback 註解）
    ├── 05-fqcn-template/             # spec.md §0 H1-H18 假設清單完整模板
    └── 06-design-explanation-template/ # design-explanation.md 寫作模板（創建者導向，必產）
```

**第一次使用**: 先讀 `examples/01-financial-repayment/` (最完整,真實案例)
**對應業務找範本**: 看 `examples/` 找最接近的模式
**遇到特定問題**: 翻 `references/01-platform-checks/` 找對應的預檢 + 自動檢查腳本

---

## 觸發條件

當使用者訊息包含以下任一:
- 「設計 / 起草 / 規劃 workflow」
- 「從業務需求做一份 draft」
- 「新業務要做 workflow 雛型」
- 「產生可直接整併的 workflow spec」
- 看到業務需求書 (BR-xxx) + host API 規格 + sample payloads

**不要**用於:
- ❌ 已存在的 draft 整併 (用 `sonataflow-integration` skill)
- ❌ 純文件撰寫 (用一般寫作工具)
- ❌ 既有 workflow 修改 (用 `vibe-workflow-design` v1 + 手動)

---

## Step 0: 前置調研 (5 個必問)

| # | 問題 | 影響 |
|---|---|---|
| 0a | 目標平台是哪個? (SonataFlow 10.2.0 / 其他 Kogito 版本 / Camunda / Airflow) | 決定 workflow YAML dialect、可用 function |
| 0b | 整合到哪個既有 project? 模組結構為何? (transfer-workflow / reconciliation-api 等) | 決定 package 命名、service 位置 |
| 0c | 有哪些 host API 規格? (OpenAPI / AsyncAPI / 純文件) | 決定 spec 檔案產出格式 |
| 0d | DB / 對帳目標是什麼? (SQLite + Flyway / Postgres / 無) | 決定 V 編號起點、View DDL 必要性 |
| 0e | 對外 API contract 與 mock 端點需求? (Parent 對外 / Child 內部 / mock for dev) | 決定 test 套件設計 |

**若任何問題用戶未回答,主動詢問;不可假設。**

---

## Step 1: 業務需求拆解 (與平台無關)

### 1a. 寫一份 `spec.md` 草稿 (§0 假設清單 + §1 概覽 + §2 輸入輸出)

**§0 假設清單強制結構** (H1-Hn):

| # | 假設 | 為何這樣假設 | 待確認問題 | 落地策略 |
|---|---|---|---|---|
| H1 | 輸入欄位 N 個 | 業務書 §X | — | spec §2.1 schema 對應 |
| H2 | 終態 finalStatus 有 M 個 | 業務書 §Y | — | spec §2.3 + status-rewrite config 對應 |
| H3 | ... | ... | ... | ... |
| H<sub>n</sub> | 新增 service FQCN: `xxx.Yyy::method` | 既有 service 未提供 | 需實作 service bean | 在 Step 4 補 Java service |

**⭐ 關鍵**: H<sub>n</sub> 必須明確標註「FQCN 假設」,這是下游 `sonataflow-integration` 識別要新建 / 擴充 service 的唯一依據。

### 1b. 識別 workflow 結構模式 (5 種常見)

| 模式 | 適用情境 | 典型架構 |
|---|---|---|
| **A. 單層 Saga LIFO** | 跨 1 個外部系統,2 階段提交 | workflow 內: ForwardState → CheckResult → (RollbackState if fail) → EndState |
| **B. Parent + 2 個 Child Subflow** | 業務多入口,依 dispatcher 路由 | Parent: Validate → CheckIdempotency → **CheckIdempotencyResult (獨立 switch)** → Dispatcher → (subflow) → FinalAuditAndEnd<br>Child A: 對應業務 A<br>Child B: 對應業務 B |
| **C. 多層 Parent** | 多層級審批 / 多階段業務流 | 多個 Parent 互相 subflow 委派 |
| **D. 事件驅動** | 接收外部事件觸發 | EventListener → Validate → Process |
| **E. 計時 / 排程** | 排程觸發 | Timer → Validate → Process |

**⭐ 識別結果決定 YAML 結構**:
1. B 模式 → 有 subflow，Step 6 「平台相容性預檢」必須過 hyphen ID 檢查。
2. **Kogito jBPM Split 條件順序防護**: Parent 狀態機中，**`CheckIdempotencyResult` 必須作為獨立 Switch 狀態**（僅判斷 `idempotentReplay == true` 轉移至重放終態，未命中 default 進入 `Dispatcher`）。嚴禁將冪等重放與 `operationType` 業務分流混寫在同一個 switch，否則 jBPM Split 節點條件無序性會導致業務分支掠奪冪等重放！
3. **平台標準 Action 簽名**: 調用 `recordAuditLog` 必須採用平台標準 5 參數契約：`arguments: {workflowId, businessKey, processInstanceId, inputData, outputData}`，其中 `outputData` 需包含 `{status: .finalStatus, finalStatus: .finalStatus, message: ...}`。

### 1c. 識別「終態 vs 業務碼」分離需求

**重要設計決策**: 對外 API response 要用以下哪種 convention?

| Convention | 適用情境 | 對應 HTTP 改寫需求 |
|---|---|---|
| **舊 convention** (saga2-transfer-workflow) | `status: STRING` 一個欄位 | 需 status-rewrite 改寫 HTTP code |
| **新 convention** (omni-cash-transaction) | `status: 0/1` (int) + `finalStatus: STRING` 兩欄位 | 需 status-rewrite 改寫 HTTP code |
| **純 HTTP status** | 對外不需 finalStatus,直接靠 HTTP code 區分 | 不需 status-rewrite |

**對應 platform 對齊**:
- 若 target platform 有 `WorkflowStatusFilter` 改寫機制 → 須沿用其 convention
- 若無 → 可自由設計

### 1d. 識別輸入驗證策略 (OpenAPI SSOT 驗證器 vs Kogito dataInputSchema 禁忌)

**⭐ 核心鐵律 (金融交易審計原則)**:
1. **嚴禁使用 Kogito 原生 `dataInputSchema`**:
   - 原生 `dataInputSchema` 會在 Workflow 實例建立前遭引擎中斷拋出 400，**無法抵達 `FinalAuditAndEnd` 寫入 AuditLog**，造成金融審計與對帳缺口 (Audit Gap)，且錯誤回傳結構非企業統一規範。
2. **推薦採用 OpenAPI Schema 驅動驗證 (方案 A / OpenApiSchemaValidator)**:
   - 以 `draft/notebooks/internal/*.yaml`（整併後為 `specs/internal/*.yaml`）的 `requestBody.content['application/json'].schema` 作為 Single Source of Truth (SSOT)。
   - 在 Workflow 起始狀態宣告 `ValidateInput` (operation state) 調用 `OpenApiSchemaValidator::validate`，搭配 `toStateData: '${ .validationResult }'`。
   - 經 `CheckValidationResult` (switch state) 路由：失敗時走 `InjectValidationFailedStatus` $\rightarrow$ `FinalAuditAndEnd` 確保 100% 審計軌跡落地，再由 `WorkflowStatusFilter` 改寫為 HTTP 400。
3. **分流適用範圍（對齊 project-0825-pd 20 workflow 實況：1/5+2/12）**:
   - Parent-Omni 型（完整三件套）：僅當 Parent 為對外入口且需嚴格審計時採用 `ValidateInput(operation)+CheckValidationResult+FinalAuditAndEnd`（如 `omni_cash_transaction`）。
   - Parent-通用型：其餘 Parent 可用 `ValidateInput(switch)+FinalAuditAndEnd`，無 `CheckValidationResult`（如 `fund_investment_order` 等 5 個）。
   - Child 型：用 `ValidateChildInput(switch)/LookupOriginal/Call* + End/ChildFinalAuditAndEnd`，不強制 validator（如 10 個 child + 2 saga）。下游詳見 `sonataflow-integration Step 6`。

---

## Step 2: 產出 OpenAPI specs (3 種角色)

### 2a. 對外契約 / 內部代理 spec (e.g., `omni-counter-repayment-api.yaml`)

- 目錄落位原則（draft→project 映射，下游詳見 `sonataflow-integration Step 2`；嚴格 internal/external 二分，root 禁放業務 yaml）:
  - **draft 側**：`draft/notebooks/internal/<entry-name>.yaml`（Parent 對外入口，必含 `x-workflow-id`，validator+router 唯一 SSOT）+ `draft/notebooks/external/<host>-api.yaml`（被調 host 規格，必無 `x-workflow-id`，`MyOpenApiService schemaRef` 來源）。
  - **整併後**：分別落到 `<project>/.../resources/specs/internal/` 與 `specs/external/`，再同步到 `distribution/transfer-app/.../specs/` 下同名子目錄（雙模組同步，transfer-workflow 為 SSOT）。root `specs/*.yaml` 僅相容舊案 20 檔，新案禁止再落 root；入口 API 禁止落 root（現 root 舊 `omni-counter-repayment-api.yaml` 無標籤嚴格版視為待刪，以 internal 放寬版為準）。
- 內容要素:
  - `info.title` 與 `description` 明確標記「此為 Parent / 對外 entry」
  - 僅 Parent 對外入口需要在操作路徑顯式宣告 `x-workflow-id: <workflow_id>`（供 `InternalOpenApiDynamicRouter` 自動註冊路由；host specs 不需要。實況 21 specs 僅 1 有，此為正常）。
  - `servers[0].url` 建議填 `http://localhost:8080`，但缺失時可用 `kogito.sw.functions.callApiViaOpenAPI` 的 `base_url>%dev.host>spec servers` fallback 鏈補救（實況 `fx-exchange-api.yaml` 缺 servers 仍可運行）。
  - 請求/回應 schema 完整，包含正則 pattern、minLength、maxLength、enum 與條件必填說明
  - `operationId` 唯一且具語意 (e.g., `executeOmniRepayment`)
  - ⭐ **Spec Schema 與 Example 嚴格一致性守則**:
    - Schema 內的 `maxLength` / `minLength` / `pattern` 必須與 example 內容完全相容。
    - **禁止出現「宣告 maxLength: 4 但 example 給 5 碼 (如 2500P)」或「宣告 maxLength: 22 但 example 含 prefix 達 25 碼」的內部矛盾**。

### 2b. Host API 規格 (e.g., `core-account-cash-deposit-api.yaml`)

- 一個 host 一個 spec，落放至 `specs/`
- `parameters: [in: path]` 區段務必明確 (下游整合會自動掃描)
- `paths` 完整含所有 operation (正向 + 反向 + 取消 + 查詢)

### 2c. Mock 規格 (給 dev profile mock 用)

- 通常等同 host API 規格 (mock 實作 host API)
- 但**重要**: mock 的 `@Path` 與 spec 的 `paths` 必須一致 (e.g., `/CoreAccount/{creditcardid}/CashDeposit/Execute`)
- 若有 path param,設計時就要明確標出,否則下游整合時 workflow 會丟 `Illegal character in path`

---

## Step 3: 產出 workflow YAML (Serverless Workflow v0.8)

### 3a. 平台相容性預檢 (設計期必跑 10 項，詳見 Step 6)

| 檢查 | 命令 | 不通過時 |
|---|---|---|
| Kogito 10.2.0 + 含 subFlowRef + workflow id 含 hyphen | 設計時主動詢問: 「workflow id 命名用 snake_case 或 hyphen-case?」 | 改 snake_case,或 spec.md 標註 v1.0 hotfix |
| actionDataFilter 是否用 `.result.X`（僅直調 functionRef 才查；subFlowRef 豁免） | 自我檢查清單 (見 Step 7) | 改用頂層欄位 |
| path param 是否在 payload | 自我檢查清單 | 自動加 |
| output 是否含 `status: 0/1` + `finalStatus: STRING` 兩欄位 (僅 Parent 新 convention；Child 僅 finalStatus、Saga 用 status/message，見 3d 分流) | 自我檢查清單 | 補上 |
| YAML 是否有 trailing comma | 自我檢查清單 | 移除 |
| subFlowRef version 是否等於 child version（如 parent 1.0.1 vs subFlow 1.0 即 FAIL） | Step 6.10 檢查 | 對齊為同一版本 |
| 檔名-id Manifest 是否齊全（hyphen 檔名 vs underscore id 視為合法，需登記） | Step 7.14 / §8 | 補 Manifest 行 |
| errors 有宣告但 operation 缺 onErrors，或有 ROLLBACK_FAILED 終態卻零 notifyOps | Step 6.11 檢查 | 補 onErrors + ROLLBACK_FAILED 告警 |

### 3b. YAML 結構樣板 (3 種模式對應)

**模式 A 範本 (單層 Saga LIFO)**:
```yaml
id: <workflow_id>
version: '1.0.0'
specVersion: '0.8.0'
name: <human readable name>
start: <first_state>
metadata:
  domain: <business-domain>
  pattern: saga-lifo-compensation
  criticality: <low|medium|high>
  owner: <team>
timeouts:
  workflowExecTimeout: PT5M
errors:
  - name: platformError
    code: 'PLATFORM_ERROR'
functions:
  - name: validateOpenApiInput
    operation: 'service:com.example.transfer.workflow.OpenApiSchemaValidator::validate'
    type: custom
  - name: callApiViaOpenAPI
    operation: 'service:com.example.transfer.workflow.MyOpenApiService::callOpenApi'
    type: custom
  - name: recordAuditLog
    operation: 'service:com.example.reconciliation.AuditLogService::saveLog'
    type: custom
  - name: notifyOps
    operation: 'service:com.example.reconciliation.OpsAlertService::raise'
    type: custom
states:
  # 階段 0: OpenAPI Schema 驅動驗證 (SSOT,取代冗長 jq)
  - name: ValidateInput
    type: operation
    onErrors:
      - errorRef: platformError
        transition: InjectValidationFailedStatus
    actions:
      - name: validateOpenApiSchemaAction
        functionRef:
          refName: validateOpenApiInput
          arguments:
            workflowId: "<workflow_id>"
            payload: '${ . }'
        actionDataFilter:
          results: '{isValid: .isValid, message: .message, errors: .errors}'
          toStateData: '${ .validationResult }'    # ⭐ 必須指定 toStateData 保全原始輸入資料
    transition: CheckValidationResult

  - name: CheckValidationResult
    type: switch
    onErrors:
      - errorRef: platformError
        transition: InjectValidationFailedStatus
    dataConditions:
      - name: inputValidationFailed
        condition: '${ .validationResult.isValid == false }'
        transition: InjectValidationFailedStatus
    defaultCondition:
      transition: CallCoreForward

  - name: CallCoreForward
    type: operation
    actions:
      - functionRef:
          refName: callApiViaOpenAPI
          arguments:
            functionName: "callApiViaOpenAPI"
            schemaRef: 'specs/<host-api>.yaml#<operationId>'
            payload:
              <path_param_1>: '${ .<input_field> }'   # ⭐ 自動注入
              <field_1>: '${ .<input_field> }'
              ...
        actionDataFilter:
          results: '{status: .code, message: .message, ...}'  # ⭐ 頂層,非 .result
          toStateData: '${ .coreResult }'
  ...
```

**模式 B 範本 (Parent + 2 Child)**:
- Parent workflow YAML 含 `subFlowRef: { workflowId: <child_id>, version: ... }`
- ⭐ **重要**: child workflow id 必須是 snake_case (見 3a 預檢)
- Child workflow YAML 各自獨立,但 functions 與 services 沿用
- ⭐ **payload 鐵律 (見 7.29)**: `currency/BIC/country/address/fee/rate` 一律 `'${ .field }'`，僅允許 `OUR/BEN/A/B/C/R` literal；衍生欄位（如 `amountInUSD`）必須含運算式

**模式 D 範本 (事件驅動，實驗性)**:
- ⚠️ 實驗性：`project-0825-pd` 20 workflow 零 `event` state，生產前需先驗證。
- 起點是 event trigger state
- 含 `eventConditions` 過濾事件

### 3c. ActionDataFilter 結構守則 (跨模式通用，子流豁免)

**鐵律 1: 頂層欄位對齊（雙軌）**:
`MyOpenApiService::callOpenApi` 回傳 response 是**頂層欄位**,不是 `.result` 底下。注意雙軌：host 業務碼為 `code(string)`，新 convention 對外為 `status(int 0/1)`，兩者不要混用。另有 `track_id/trackId`、`_httpStatus`、`errorType`、`errors` 頂層 metadata。下游詳見 `sonataflow-integration Step 6b`。
```yaml
# ✅ 對（新 convention：把 code 映射為 status，保留雙軌來源；schemaRef 指向 external）
results: '{status: .code, message: .message, track_id: .track_id, errorType: .errorType, _httpStatus: ._httpStatus, errors: .errors}'
# 對應 arguments: schemaRef: 'specs/external/<host>.yaml#<operationId>'（新案；舊案 specs/<host>.yaml 僅相容）

# ❌ 錯
results: '{status: .result.code, message: .result.message, ...}'
```

**鐵律 2: 直調必須宣告 `toStateData`，子流/終端豁免 (State Data 保全原則)**:
直調 `functionRef` 若只宣告 `results: '{ ... }'` 而漏掉 `toStateData`，Kogito 會將 results 物件**整份覆寫**當前的 Workflow State Data，導致先前的輸入欄位（如 `partyId`, `amount`, `sequenceNumber`）全部遺失，造成下游 Subflow 與 AuditLog 欄位全為 null！下游詳見 `sonataflow-integration Step 6e`。
豁免：`subFlowRef` invoke（12 處實況全無 actionDataFilter 屬正常）、terminal `recordAuditLog`、`MarkOriginalCancelled` 非關鍵路徑可免（child End 8 處無 actionDataFilter 屬正常）。
```yaml
# ✅ 對: 將 action 執行結果隔離注入指定 key，完整保留既有 State Data
actionDataFilter:
  results: '{isValid: .isValid, message: .message, errors: .errors}'
  toStateData: '${ .validationResult }'

# ❌ 錯: 缺少 toStateData，整份 Workflow 記憶體將被覆蓋成只有 isValid, message, errors
actionDataFilter:
  results: '{isValid: .isValid, message: .message, errors: .errors}'
```

**若有 `result` sub-object** (例如 host 回 `{status: 0, result: {sequenceNumber: "xxx"}}`):
```yaml
# ✅ 對: sub-object 內的欄位直接寫進 results,不要包 .result
results: '{status: .status, sequenceNumber: .result.sequenceNumber}'
```

### 3d. StateDataFilter Output 結構守則 (Parent/Child/Saga 分流)

依 convention 與 workflow 層級決定（下游 `WorkflowStatusFilter` 讀 `finalStatus→status` fallback，詳見 `sonataflow-integration Step 6c`）:

```yaml
# Parent 舊 convention (saga2-transfer-workflow 風格，僅 Parent-Saga 用)
stateDataFilter:
  output: |
    {
      status: .finalStatus,
      message: .finalMessage,
      ...
    }

# Parent 新 convention (omni-cash-transaction 風格,推薦，僅 Parent 用)
stateDataFilter:
  output: |
    {
      track_id: .<key_id_field>,
      workflow: (if .<dispatch_field> == "A" then "REPAYMENT" else "CANCELLATION" end),
      status: (if .finalStatus == "SUCCESS" or ... then 0 else 1 end),  # int 0/1
      finalStatus: .finalStatus,  # string
      message: .finalMessage,
      <host_api_result_1>: (.coreResult // null),
      ...
    }

# Child End（僅 finalStatus，不加 status；實況 10 child 皆如此）
stateDataFilter:
  output: |
    {
      finalStatus: .finalStatus,
      finalMessage: .finalMessage,
      <child_result>: (.coreResult // null)
    }
```

---

## Step 4: 補 Java 服務 (當 spec 標註新 FQCN 時)

### 4a. 識別需要新建 / 修改的 service

讀 `spec.md §0 H<sub>n</sub>` 假設清單,找出所有 FQCN:

```yaml
H13a: XxxBusinessRuleValidator::validate  # 新業務有條件必填/FAIL_哨兵時新建，否則複用通用 validator
H13b: IdempotencyService::findBySequenceNumber  # 新建
H14: AuditLogService::markCancelledBy          # 擴充既有（注意 workflow_id 必須參數化，不可寫死）
```

### 4b. 通用 service 模板

業務服務放 `<project>/domain-*/.../src/main/java/com/example/<domain>/<ClassName>.java`（業務沿用 `com.example.*`；Mock 另見 Step 5，用 `org.acme.transfer.api`，兩軌不要混用）。下游 Java 落檔詳見 `sonataflow-integration Step 4`。

```java
package com.example.<domain>;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Map;

@ApplicationScoped
public class <ClassName> {

    private static final Logger LOG = LoggerFactory.getLogger(<ClassName>.class);
    private static final ObjectMapper MAPPER = new ObjectMapper();

    @Inject
    DataSource dataSource;

    // 1. 展開參數版入口 (對應 Kogito reflection 具名綁定，鍵名必須與 YAML arguments 完全一致，含 workflowId/businessKey)
    public JsonNode <methodName>(String arg1, Object arg2) {
        return do<MethodName>(arg1, arg2 != null ? arg2.toString() : null);
    }

    // 1b. Map 版入口（核心 5 服務實況皆有，補齊以防 codegen 傳 Map）
    public JsonNode <methodName>(String arg1, Map<String, Object> arg2) {
        return do<MethodName>(arg1, arg2 != null ? String.valueOf(arg2.get("businessKey")) : null);
    }

    // 2. JsonNode 單參數版入口 (Kogito codegen 預設生成)
    public JsonNode <methodName>(JsonNode arguments) {
        if (arguments == null) {
            return MAPPER.createObjectNode().put("<key>", false);
        }
        // 從 arguments 解析 arg1, arg2
        return do<MethodName>(arg1, arg2);
    }

    private JsonNode do<MethodName>(String arg1, String arg2) {
        // 實際 SQL 邏輯
    }
}
```

### 4c. 既有 service 擴充原則

- 既有 `AuditLogService` / `OpsAlertService` / `MyOpenApiService` 必須優先複用,不重造
- 擴充方法須「展開參數版（鍵名對齊 YAML arguments）」+「Map 版」+「JsonNode 版」三進入點 (Kogito reflection 三種都可能用；舊 `SagaApiService` 僅展開參數為例外，新服務不可學)
- `markCancelledBy` 的 `workflow_id` 必須參數化，不可寫死為 `repayment-cash-deposit`（實況硬編碼為已知坑，設計期就要在 H14 落地策略寫明參數化）
- 新業務若有條件必填（如 operationType=A/B 與 originalSequenceNumber 連動）或 `FAIL_` 哨兵，需新建 `XxxBusinessRuleValidator implements BusinessRuleValidator` 並在 `OpenApiSchemaValidator` dispatch 註冊（仿 `OmniCashBusinessRuleValidator`）；無特殊規則則複用通用 validator 即可（實況新 5 域缺 validator 導致 FAIL_* 零覆蓋，不可重蹈）

### 4d. Flyway migration (若有新欄位或對帳 View 需求)

**自動探測既有最大版本號 (前置引導)**:
在為新 Draft 決定 Flyway 版本號前，先執行以下指令自動掃描目標專案中現有的最大版本：

```bash
# 自動探測目標專案中既有的最大 Flyway 版本號 (跨模組掃描)
latest_v=$(find <project>/ -path "*/db/migration/V*.sql" 2>/dev/null | grep -oE "V[0-9]+(\.[0-9]+)*" | sort -V | tail -n 1)
echo "目前專案既有最大版本: ${latest_v:-無}"
```

**版本號制定原則**:
- 若既有最大版本為 `V1.2.4`，則新 Draft 必須自動遞增為 `V1.2.5__<description>.sql`。
- 檔案命名格式：`V<X>.<Y>.<Z>__<description>.sql`（`description` 為英文小寫，底線分隔）。

放在 `draft/spec/db/V<X>.<Y>.<Z>__<description>.sql` (後續整併至 `<project>/.../src/main/resources/db/migration/`)：

```sql
-- 範例 1: 欄位擴充 (若有新欄位需求)
ALTER TABLE workflow_execution_log ADD COLUMN <new_col> TEXT;
CREATE INDEX IF NOT EXISTS idx_<table>_<col> ON <table>(<col>);

-- 範例 2: 業務對帳檢視表 (View DDL)
CREATE VIEW IF NOT EXISTS vw_<workflow>_reconciliation AS
SELECT
    id, created_at, workflow_id, business_key, process_instance_id, status, message,
    json_extract(input_data, '$.partyId') AS party_id,
    json_extract(input_data, '$.operationType') AS operation_type,
    json_extract(input_data, '$.amount') AS amount,
    cancelled_by, cancelled_at
FROM workflow_execution_log
WHERE workflow_id IN ('<parent_workflow_id>', '<child_a_id>', '<child_b_id>');
```

---

## Step 5: 產出 Mock Resources (dev profile)

### 5a. 命名對齊既有 project 模組 (設計期先問，下游 rename兜底)

**設計期先問**:
- 既有 mock 模組的 package 是? (e.g., `org.acme.transfer.api`)
- 若無既有,新模組該叫? (e.g., `org.acme.cashrepayment.api` 佔位亦可)

draft 可用佔位 package（如 `org.acme.cashrepayment.api`），下游 `sonataflow-integration Step 5a-5b` 會統一 `replace → org.acme.transfer.api`（注意 DTO 兩階段替換，避免 `.dto.dto`）。設計期若已知既有 package，直接對齊可省 rename 工時，但非強制。

### 5b. Mock Resource 樣板 (2 種 sentinel 模式)

**Sentinel 模式 A: 業務 payload 內字串前綴**
```java
@Path("/CoreAccount/{creditcardid}/CashDeposit/Execute")
public class CoreCashDepositResource {
    @POST
    public Response execute(@PathParam("creditcardid") String creditcardid,
                            CoreCashDepositRequest request) {
        // 業務拒絕 sentinel: amount = "0" 或 "0000000000" 或以 "FAIL" 開頭
        if (isBusinessReject(request.amount)) {
            return Response.status(403).entity(buildError("E0024", "金額不符", null)).build();
        }
        // RBFAIL sentinel: operationType=B 且 sequenceNumber 以 "RBFAIL" 開頭
        if ("B".equals(request.operationType) && request.sequenceNumber != null
                && request.sequenceNumber.startsWith("RBFAIL")) {
            return Response.status(403).entity(buildError("E0050", "回沖失敗", null)).build();
        }
        // 正常成功
        ...
    }
}
```

**Sentinel 模式 B: 獨立 sentinel field** (避免破壞 input validation)
```java
public class CoreCashDepositRequest {
    public String partyId;
    public String branchCode;
    public String amount;
    public String sequenceNumber;
    public String operationType;
    public String __sentinel;  // 設計期專用,真實 API 不會有
}
```

**設計期決策（實況主力為 A，B 備選）**:
- 預設採模式 A（字串前綴），並在 `OpenApiSchemaValidator::validate` 加 `FAIL_` 豁免（剝離前綴後再測 regex，實況 `OpenApiSchemaValidator.java:401-403` 已如此），同時 switch 條件用 `tonumber? //` 或 `startswith("FAIL_")` 守衛避免 jq 拋錯（詳見 `references/01-platform-checks/06-mock-sentinel-vs-input-validation.md` 陷阱 2）。
- 僅當業務 regex 絕對不可放行任何非數字且 validator 不可改時，才採模式 B（獨立 `__sentinel` field；實況零使用，屬備選）。
- 新業務若新建 `BusinessRuleValidator`，必須同步覆蓋 `FAIL_*` 剝離邏輯，否則新 workflow 的業務失敗路徑零覆蓋（實況新 5 域即如此）。

### 5c. DTO 設計守則

- 一個 request + 一個 response + 一個 result sub-object (e.g., `CoreCashDepositRequest` / `CoreCashDepositResponse` / `CoreCashDepositResult`)
- 極簡風格: 純 public field,無 getter/setter (與既有 transfer-mock 一致)
- ErrorDetail 共用 DTO 放 `org.acme.<project>.api.dto.ErrorDetail`

---

## Step 6: 平台相容性預檢 (★ v2 新增，v2.3 擴為 10 項+版本對齊)

設計期就跑這 10 項檢查（6.1-6.11），任何一項不通過就修正 draft,不交付。下游整合對應詳見 `sonataflow-integration Step 6/失敗速查`，此處為設計期前移，不重複下游編譯/E2E 指令。

### 6.1 Workflow ID 命名 (Kogito 10.2.0 相容性)

```bash
# 自動檢查
for f in draft/spec/*.sw.yaml; do
  if grep -q "subFlowRef" "$f"; then
    id=$(grep "^id:" "$f" | awk '{print $2}')
    if [[ "$id" == *-* ]]; then
      echo "❌ FAIL: $f workflow id '$id' 含 hyphen,會觸發 Kogito 10.2.0 codegen bug"
    fi
  fi
done
```

不通過: 改 snake_case + 在 spec.md 標註 v1.0 hotfix

### 6.2 actionDataFilter 結構 (MyOpenApiService 相容性)

```bash
# 自動檢查
grep -A 1 "actionDataFilter" draft/spec/*.sw.yaml | grep -E "\.result\."
# 任何 .result.X 配對都是錯的
```

不通過: 改為直接讀頂層 `.X`

### 6.3 Path Parameter 自動注入

```bash
# 自動檢查: 對每個 callApiViaOpenAPI 的 schemaRef,找出 spec 的 path param,
# 並確認 payload 內有對應 key（新案掃 external；舊案 root 僅相容）
for spec in draft/notebooks/external/*-api.yaml draft/notebooks/internal/*.yaml; do
  for op in $(grep "operationId:" "$spec" | awk '{print $2}'); do
    path_params=$(python3 -c "
import yaml
with open('$spec') as f:
    s = yaml.safe_load(f)
for path, methods in s.get('paths', {}).items():
    for m, op in methods.items():
        if op.get('operationId') == '$op':
            for p in op.get('parameters', []):
                if p.get('in') == 'path':
                    print(p['name'])
")
    echo "Schema $spec operation $op needs path params: $path_params"
  done
done
```

不通過: 在每個對應的 workflow YAML 的 payload 加 `xxx: '${ .對應欄位 }'`

### 6.4 StateDataFilter.output 欄位 (Convention 對齊)

```bash
# 若用新 convention,確認 output 含 status (int) + finalStatus (string) 兩欄位
grep -A 20 "stateDataFilter:" draft/spec/*.sw.yaml | grep -E "status:|finalStatus:"
```

不通過: 補上 `status: 0/1` (jq expression) 與 `finalStatus: .finalStatus`

### 6.5 YAML 語法嚴格性

```bash
# 檢查 list item 後是否多餘 comma
grep -E "^\s+\w+:\s+'.*',$" draft/spec/*.sw.yaml
# 任何結尾有 `,` 的 list item 是錯的
```

不通過: 移除 trailing comma

### 6.6 Mock sentinel vs input validation 相容性

```bash
# 列出所有 mock sentinel 字串
grep -h "startsWith\|equals.*\"0\"" draft/spec/mocks/*.java | grep -oE "\"FAIL[a-zA-Z_]*\"|\"RBFAIL\"|\"0\"|\"0000000000\""
# 對每個 sentinel 驗證它能通過 input validation 的 regex
```

不通過: 改用模式 B (獨立 sentinel field) 或放寬 validation regex

### 6.7 OpenAPI Spec Schema 與 Example 一致性預檢

```bash
# 自動檢查: 確保 OpenAPI spec 宣告的 maxLength/minLength 與其 example 字串長度相容
python3 -c "
import yaml, sys
with open('draft/notebooks/internal/omni-counter-repayment-api.yaml') as f:
    s = yaml.safe_load(f)
schemas = s.get('components', {}).get('schemas', {})
for s_name, schema in schemas.items():
    for p_name, prop in schema.get('properties', {}).items():
        ex = prop.get('example')
        max_l = prop.get('maxLength')
        min_l = prop.get('minLength')
        if ex is not None and isinstance(ex, str):
            if max_l and len(ex) > max_l:
                print(f'❌ FAIL: {s_name}.{p_name} example \"{ex}\" (len={len(ex)}) > maxLength {max_l}')
            if min_l and len(ex) < min_l:
                print(f'❌ FAIL: {s_name}.{p_name} example \"{ex}\" (len={len(ex)}) < minLength {min_l}')
"
```

不通過: 修正 OpenAPI Schema 內之 `maxLength` / `minLength` 或範例值，保持兩者 100% 一致。

### 6.8 ActionDataFilter 漏設 toStateData 檢查 (State Data 保全，直調才查)

```bash
# 自動檢查: 直調 functionRef 含有 results 但未設定 toStateData；subFlowRef 豁免
for f in draft/spec/*.sw.yaml; do echo "== $f"; grep -n -B2 -A 3 "actionDataFilter:" "$f" | grep -B1 -A2 "results:" | grep -v "toStateData" | grep -v "subFlowRef"; done
# 誤報排除：命中行若上下文含 subFlowRef 即為豁免；terminal recordAuditLog/MarkOriginalCancelled 非關鍵路徑可免
```

不通過: 直調必須顯式補上 `toStateData: '${ .targetField }'`，避免 Workflow 輸入 Payload 遭覆蓋。下游詳見 `sonataflow-integration Step 6e`。

### 6.9 OpenAPI 內外目錄 + 動態路由標籤預檢 (x-workflow-id 宣告，僅 Parent 入口)

```bash
# 自動檢查: internal 必含 x-workflow-id；external 必無；root 禁放業務 yaml
python3 -c "
import yaml, glob
files = glob.glob('draft/notebooks/internal/*.yaml')
if not files:
    print('⚠️ 未發現 draft/notebooks/internal/*.yaml (若有對外入口規格請放置此處)')
for f in files:
    s = yaml.safe_load(open(f))
    for path, ops in s.get('paths', {}).items():
        for method, detail in ops.items():
            if method.lower() == 'post' and 'x-workflow-id' not in detail:
                print(f'❌ FAIL: {f} 路徑 {path} 缺少 x-workflow-id 標籤 (供動態路由代理轉發)')
for f in glob.glob('draft/notebooks/external/*.yaml'):
    s = yaml.safe_load(open(f))
    for path, ops in (s.get('paths') or {}).items():
        for method, detail in (ops or {}).items():
            if isinstance(detail, dict) and ('x-workflow-id' in detail or 'x-kogito-workflow-id' in detail):
                print(f'❌ FAIL: {f} 路徑 {path} external 禁止含 x-workflow-id')
"
# root 禁放：draft/notebooks/*.yaml 若存在即 FAIL（請搬入 external/；openapi.yaml 聚合檔除外）
for f in draft/notebooks/*.yaml; do [ "$(basename "$f")" = "openapi.yaml" ] && continue; [ -e "$f" ] && echo "❌ FAIL: root $f 請搬入 notebooks/external/"; done
```

不通過: internal 的 `post:` 補 `x-workflow-id`；external 刪標籤；root yaml 搬入 external。`servers` 缺失可用 baseUrl fallback 鏈補救，不在此項 FAIL。

### 6.10 subFlowRef version 對齊檢查（新增，實況 omni 1.0.1 vs 1.0 教訓）

```bash
# 自動檢查: parent 引用的 subFlowRef version 必須等於對應 child YAML 的 version
for p in draft/spec/*.sw.yaml; do
  grep -A1 "workflowId:" "$p" | grep -B1 "version:" | head -n 20
done
# 人工比對：CallWFARepayment→repayment_cash_deposit version、CallWFBCCancellation→repayment_cash_cancellation version
```

不通過: 統一為 child 實際 version（如 `1.0.1`），Parent 與 Child 同步改。

### 6.11 onErrors 覆蓋 + notifyOps 告警 (Audit Gap 防線，詳見 `references/01-platform-checks/10-onerrors-and-opsalert.md`)

```bash
for f in draft/spec/*.sw.yaml; do
  ops=$(grep -c "type: operation" "$f"); errs=$(grep -c "onErrors:" "$f")
  [ "$errs" -lt "$((ops - 1))" ] && echo "❌ FAIL: $f operation=$ops 但 onErrors=$errs（terminal 僅豁免 1 個）"
  grep -q "ROLLBACK_FAILED" "$f" && ! grep -q "refName: notifyOps" "$f" && echo "❌ FAIL: $f 有 ROLLBACK_FAILED 卻零 notifyOps"
done
```

不通過: 每個 `type: operation` 補 `onErrors: [{errorRef: platformError, transition: Finalize*}]`（terminal audit state 豁免）；有 `ROLLBACK_FAILED` 終態必須至少一處調用 `notifyOps`（建議 Java 側僅對該終態發告警）。

---

## Step 7: 自我檢查清單 (★ v2 設計期 SOP 核心)

設計完成後,逐項檢查:

| # | 檢查項 | 通過條件 |
|---|---|---|
| 7.1 | `spec.md §0 假設清單` 含 FQCN 假設（含 H13a validator + H13b/H14 service） | ✅ 每個新 service/validator 都有 FQCN + 落地策略 |
| 7.2 | `spec.md §0` 含 `id 命名決策` 標記（含檔名-id Manifest） | ✅ 明確寫出 snake_case + 檔名≠id 登記，或註明 v1.0 hotfix |
| 7.3 | `spec.md §0` 含 `convention 決策` (status / finalStatus，Parent/Child/Saga 分流) | ✅ 標明 Parent 用舊 / 新 / 純 HTTP，Child 僅 finalStatus |
| 7.4 | OpenAPI spec 的 path param 與 workflow YAML 的 payload 對應 | ✅ 每個 `{xxx}` 都有對應 payload key |
| 7.5 | 直調 actionDataFilter 全部用頂層欄位 (非 .result.X；subFlowRef 豁免) | ✅ 直調 grep 不到 `.result.X` 配對 |
| 7.6 | stateDataFilter.output 對應選定的 convention 與層級，且 output key 皆有賦值 | ✅ Parent 舊:`status: STRING`；Parent 新:`status: 0/1` + `finalStatus`；Child:僅 `finalStatus`；output 每個 key 至少在一個 inject/operation 被賦值 |
| 7.7 | Mock sentinel 字串能通過 input validation（Mode A + validator FAIL_ 豁免優先） | ✅ 設計期實測；B 僅備選 |
| 7.8 | Mock package 命名（draft 佔位可，下游 rename 兜底；DTO 防 `.dto.dto`） | ✅ spec §8 註明 rename 映射或已對齊 |
| 7.9 | SQL migration V 編號遞增 | ✅ 從既有最大 +1 |
| 7.10 | YAML 沒有 trailing comma | ✅ grep 不到 `,$\|,$` 結尾的 list item |
| 7.11 | spec/config/application.properties.snippet 含 status-rewrite 完整配置（含 %dev/%prod bean 與 baseUrl 註解） | ✅ workflows + mapping + bean 三者齊全 |
| 7.12 | 測試套件包含 happy path + 主要 error path（對齊 P1/A1/P4/B1/B2 五場） | ✅ 至少 5 個測試案例（P1 400/A1 SUCCESS/P4 REPLAY/B1 CANCELLED/B2 LOOKUP_FAILED） |
| 7.13 | 測試資料字串能通過 input validation | ✅ 每個測試 payload 都驗過 |
| 7.14 | spec.md §8 Project Mapping Manifest 完整（含檔名-id、draft→project 雙模組路徑） | ✅ 每個 draft 檔案都有對應正式路徑 + 檔名-id 行 |
| 7.15 | spec.md §9 已知限制有列 | ✅ v1.0 留白 / 簡化項目都明確標出 |
| 7.16 | Input Validation Regex 與 API Sample 相容 | ✅ 通路代碼/欄位正則相容真實範例（如 `2500P`） |
| 7.17 | 測試案例採用動態唯一序號 | ✅ 正向/反向用 `System.nanoTime()`，固定值僅 P1/B2 未入庫路徑 |
| 7.18 | jq 條件表達式 `tonumber` 防呆 + null guard | ✅ 用 `tonumber? //` 或 `startswith("FAIL_")` 守衛；所有讀 `.xxx.status` 的 condition 必須帶 `//` 預設值（如 `((.coreResult.status // "999")\|tostring)!="0"`） |
| 7.19 | Workflow Root 顯式定義 `start: <StateName>` | ✅ 避免 Kogito 拋出 `Workflow.getStart() is null` NPE（值可為 ValidateInput/ValidateChildInput/LookupOriginal/Call* 四類） |
| 7.20 | Service Function 參數鍵值精準對齊 Java Overload 簽名 | ✅ `workflowId` 與 `businessKey` 齊全，展開/Map/JsonNode 三入口，避免 ClassCastException |
| 7.21 | OpenAPI Spec `servers[0].url`（建議有，缺失可用 fallback，不 FAIL） | ✅ 有則填 `http://localhost:8080`；缺則在 §0 註明 fallback 鏈 |
| 7.22 | OpenAPI Spec 欄位約束與 Example/測試 Payload 嚴格相容 | ✅ `maxLength`/`minLength` 覆蓋 example 與真實序號，無內部衝突 |
| 7.23 | 直調 Operation State 若使用 results 必須顯式宣告 `toStateData`（subFlow/終端豁免） | ✅ 嚴防 State Data 沖刷覆蓋，保證下游欄位與審計完整 |
| 7.24 | 金融工作流程輸入驗證避免使用原生 `dataInputSchema`（Parent-Omni 型完整三件套，其餘分流見 1d） | ✅ 改採 `OpenApiSchemaValidator` 於流程內校驗，杜絕 Audit Gap 審計斷點 |
| 7.25 | Parent 對外入口置於 `draft/notebooks/internal/` 且含 `x-workflow-id`；host 置於 `draft/notebooks/external/` 且必無標籤；root 禁放業務 yaml | ✅ Vert.x 動態路由解析；external 零標籤 |
| 7.26 | subFlowRef version 對齊 child version | ✅ 如 omni parent 1.0.1 則 subFlow 亦 1.0.1，不可殘留 1.0 |
| 7.27 | `design-explanation.md` 已產出且與 draft 一致（創建者導向，必產） | ✅ 9 節齊全 + 決策/假設/檔案地圖與實際產出一致，無虛構欄位 |
| 7.28 | onErrors 覆蓋 + ROLLBACK_FAILED 必告警（見 6.11） | ✅ `onErrors` 數 ≥ `operation` 數 −1（terminal 豁免 1 個）；有 `ROLLBACK_FAILED` 終態則必調用 `notifyOps` |
| 7.29 | 業務欄位禁止 literal 硬編碼，衍生欄位須含運算式 | ✅ `currency/BIC/country/address/fee/rate` 一律 `${ .field }`（僅允許 OUR/BEN/A/B/C/R）；`amountInUSD` 類必須含 `fxRate` 運算或 §0 假設註明 |

---

## Step 8: 交付前最後一次檢查

- [ ] 8 個目錄結構都產出 (draft/notebooks / draft/notebooks/internal / draft/notebooks/external / draft/spec / draft/spec/mocks / draft/spec/mocks/dto / draft/spec/db / draft/spec/config / draft/spec/tests)
- [ ] 16-21 個檔案 (依業務複雜度；02/03 最小可跑骨架至少 11 檔；含必產 `design-explanation.md` 1 檔)
- [ ] ⛔ 禁止產出 `spec/schemas/*.json`（JSON 僅允許設計期草稿，禁止進 handoff zip；SSOT 為 notebook YAML 內 `components.schemas`，見 07）。預檢：`test -z "$(find draft -name '*.json' -path '*/schemas/*')"` 必過，違者 FAIL。
- [ ] spec.md H1-H18 假設清單 + 11 個章節齊全（含檔名-id Manifest、validator 註冊、fallback 聲明）
- [ ] `design-explanation.md` 已產出（創建者導向，見 Step 8b；必產，違者 FAIL）
- [ ] 10 項平台相容性預檢 + version 對齊全綠
- [ ] 28+1 項自我檢查（7.1-7.29）全綠
- [ ] 包成 `draft-<name>.zip` 給下游 `sonataflow-integration` skill（下游 Step 2 雙模組同步、Step 5 rename、Step 6-8 落檔，此處不重複編譯/E2E 指令；zip 須含 `design-explanation.md`）

## Step 8b: 產出 design-explanation.md（★ v2.2 新增，必產）

`spec.md` 是給下游工程師看的技術規格；`design-explanation.md` 是給**創建者（業務/出資方）**看的設計說明，回答「為什麼這樣設計」。兩份缺一不可。

### 8b.1 落位與命名

- 落位：`draft-<name>/design-explanation.md`（draft 根，與 `notebooks/`、`spec/` 同層；進 handoff zip）。
- 範本：`references/06-design-explanation-template/design-explanation-template.md`。
- 語言：與創建者一致（本系列預設繁中），業務語言為主，技術術語首次出現加白話括號。

### 8b.2 強制 9 節結構（不可刪節，可加附錄）

| 節 | 標題 | 內容要求 |
|---|---|---|
| 0 | 導讀（3 分鐘版） | 5 點以內：業務要什麼 / 選了什麼模式 / 有幾個檔案 / 最易誤會的決策 / 還沒確定的事 |
| 1 | 背景與目標 | 痛點表 + draft 目標 + 不做什麼（對應業務書 In/Out-Scope） |
| 2 | 輸入來源 | 用了哪版業務書 + 哪幾份 host API（檔名+版本）+ Step 0 五問答案 |
| 3 | 從需求到設計 | 業務職責→state 對應表 + 模式選擇理由（為何是 A/B/C/D/E 其中之一）+ 回應 convention 決策 |
| 4 | 關鍵設計決策 | 至少 5 條，每條含「選了什麼 / 為什麼 / 沒選什麼 / 不這樣做的後果 / 在哪裡看到」 |
| 5 | 產出物地圖 | 全部檔案一句话分工 + 檔名-id 對應表 |
| 6 | 流程解說 | 正向/反向各走一遍 + 測試場景對應表（P1/A1/P4/B1/B2 或等價矩陣） |
| 7 | 假設與待確認 | H1-H18 精簡為業務語言，只列需人拍板的 |
| 8 | 驗證 + 限制 + 下一步 | 預檢/自查結果 + 已知限制 + 移交下游對照表 + 名詞解釋附錄 |

### 8b.3 一致性鐵律

- `design-explanation.md` 提到的每個 id / 檔名 / 欄位 / 狀態 / 數字，必須與實際產出一致（7.27 檢查）。禁止虛構範例值；範例值必須來自 notebooks YAML 的 `example` 或測試 payload。
- 決策條數不可少於 5 條，且必須覆蓋：id 命名、convention、驗證策略、sentinel、toStateData/version 任一。
- 寫完後跑：`grep -c "^## " draft-<name>/design-explanation.md`（≥9）+ 人工抽 3 個檔名/id/數字核對。

---

## 通用化考量 (跨領域)

### 適用領域

此 skill 不只限於「信用卡臨櫃現金繳款」,可應用於:

| 業務領域 | 範例 |
|---|---|
| 金融交易 | 信用卡現金繳款 (本次案例)、轉帳、匯款 |
| 電商訂單 | 下單 → 付款 → 出貨 → 退貨 |
| 保險理賠 | 申請 → 審核 → 撥款 |
| 物流配送 | 接單 → 揀貨 → 出貨 → 簽收 |
| 醫療掛號 | 預約 → 報到 → 看診 → 繳費 |

**共通特性** (這些領域都適用):
- 多階段業務流 (saga)
- 跨多個外部系統 (Core + CC 等)
- 需要對帳 (audit log)
- 需要 idempotency
- 需要 failure rollback

### 不適用場景

- 純 CRUD 應用 (無業務流)
- 純批次處理 (用 Airflow 而非 workflow engine)
- 純 event streaming (用 Kafka Streams)

---

## 與其他 skill 的關係

```
vibe-workflow-design-v2 (本 skill, 上游/Draft 階段)
  │
  │  產出 draft-<name>/ 套件
  │  (含 16-21 個檔案,符合 10 項預檢 + 28+1 項 self-check + H1-H18 + design-explanation)
  │  (Java/配置模板與下游部分重複屬正常，每處重複皆標下游 Step 號)
  │
  ▼
sonataflow-integration (下游/Integration 階段)
  │
  │  把 draft 整併進 project-0825-pd
  │  (10 步 SOP + 失敗模式速查：雙模組同步、rename、編譯測試、E2E 以下游為準)
  │
  ▼
最終產出:quarkus-run.jar + 通過 E2E smoke test
```

**本 skill 完成後,移交給 `sonataflow-integration` 即可預期整合階段工時 < 1 小時**(若上游預檢全綠)。

---

## 反模式 (不要這樣做)

- ❌ **不要產出 hyphen id + subflow 的 workflow** — 必觸發 Kogito 10.2.0 bug
- ❌ **不要在 actionDataFilter 用 `.result.X`** — 與 MyOpenApiService response 結構不符
- ❌ **不要忘了 path param** — 必在 payload 內顯式提供
- ❌ **不要設計 input validation regex 攔截 mock sentinel** — 預設用 Mode A + validator `FAIL_` 豁免 + `tonumber?` 守衛（B 僅備選）
- ❌ **不要強制 draft package 已對齊** — 佔位可，下游 `sonataflow-integration Step 5` 會 rename（DTO 注意兩階段替換）
- ❌ **不要用 trailing comma** — YAML 解析失敗
- ❌ **不要用未對齊 platform 的 convention** — 必觸發 status-rewrite 問題
- ❌ **不要省略 status-rewrite config snippet** — 下游必再摸索一次
- ❌ **不要省略 FQCN 假設清單** — 下游無法識別要新建/修改的 service
- ❌ **不要省略測試套件** — 整合後無法快速驗證
- ❌ **不要省略 design-explanation.md** — 創建者看不懂設計依據，驗收時必返工（v2.2 必產，見 Step 8b + 7.27）
- ❌ **不要宣告 errors 卻不寫 onErrors** — host 拋錯繞過 audit 成 Audit Gap（見 6.11 + 7.28）
- ❌ **不要有 ROLLBACK_FAILED 終態卻不調 notifyOps** — 補償失敗靜默結束（見 6.11 + 7.28）
- ❌ **不要硬編碼 BIC/country/address/fee** — 業務欄位一律 `${ .field }`，衍生欄位須含運算式（見 7.29）

---

## 輸出物結構 (draft-<name>/)

```
draft-<name>/
├── design-explanation.md                   # ★ v2.2 必產：創建者導向設計說明（9 節，見 Step 8b）
├── notebooks/                              # OpenAPI specs (draft 側；整併後→ specs/internal + specs/external，root 禁放)
│   ├── internal/                          # Parent 對外入口 (必含 x-workflow-id，validator+router 唯一 SSOT)
│   │   └── <entry-api>.yaml
│   ├── external/                          # 被調 host 規格 (必無 x-workflow-id；schemaRef='specs/external/<host>.yaml#op')
│   │   ├── <host-api-1>-api.yaml
│   │   └── <host-api-2>-api.yaml
│   └── ...
├── spec/                                   # workflow + 規格（⛔ 禁止含 schemas/*.json）
│   ├── <workflow-parent>.sw.yaml          # Parent workflow (若有；subFlowRef version 須等於 child version)
│   ├── <workflow-child-A>.sw.yaml         # Child A（End 僅 finalStatus）
│   ├── <workflow-child-B>.sw.yaml         # Child B
│   ├── db/V<X>.<Y>.<Z>__<desc>.sql       # Flyway DDL (從既有最大 +1；View IN 用 snake_case)
│   ├── config/application.properties.snippet  # 平台組態片段（含 status-rewrite + %dev/%prod bean + baseUrl 註解）
│   ├── mocks/<Resource1>.java             # JAX-RS mock（Mode A 前綴為主）
│   ├── mocks/<Resource2>.java
│   ├── mocks/dto/                         # DTO 群
│   │   ├── <Resource1>Request.java
│   │   ├── <Resource1>Response.java
│   │   ├── <Resource1>Result.java
│   │   └── ErrorDetail.java
│   ├── tests/<WorkflowTest>.java          # @QuarkusTest（P1/A1/P4/B1/B2 五場 + 動態序號 + view 防污染查詢）
│   └── spec.md                            # 規格書 (H1-H18 假設 + 11 章節，含檔名-id Manifest)
│   └── ⛔ 禁止 schemas/ 目錄（舊版 schemas/<input>.json 已廢止；input 約束一律寫進 notebooks YAML 的 components.schemas + example）
└── (optional) README.md
```

---

## 版本演進

| 版本 | 重點 |
|---|---|
| v1.0 | 基礎 draft 產出 (notebooks/spec/mocks/tests) |
| v1.1 | 加入 H1-H14 假設清單 + spec.md 11 章節 |
| v2.0 | 加入 6 項平台相容性預檢 + 15 項自我檢查 + 9 項可上移守則 + 3 個 examples + 5 個 reference 模組 |
| v2.1 | 統一 9 項預檢 + 25+1 項自查 + H1-H18 + 8 目錄；放寬 toStateData/servers/x-workflow-id/Validate 三件套為 Parent/Child/Saga 分流；新增 version 對齊 + 檔名-id Manifest + validator 註冊 + 雙軌 results + P1/A1/P4/B1/B2 測試矩陣；02/03 補為最小可跑骨架；D/E 標實驗性 |
| **v2.2** | **新增必產 `design-explanation.md`（創建者導向 9 節，Step 8b + 7.27 + 06 模板）；檔案數改為 16-21；其餘沿用 v2.1** |
| **v2.3** (本版) | **新增 6.11 onErrors+notifyOps 預檢 + 7.28/7.29；擴充 7.6（output key 必有賦值）+ 7.18（status 判斷必帶 `//`）；新增 `10-onerrors-and-opsalert.md`（源自 remittance_swift 審查）** |
| 未來 v3.0 | 預期:根據更多領域案例擴展 pattern (D 事件驅動 / E 計時) 的 SOP,加入 TypeScript/Go 多語言 mock 模板 |

---

## 對應 reference / example 速查

設計中遇到下列問題,直接翻對應 reference:

| 問題 | 翻哪個 reference | 對應 example |
|---|---|---|
| workflow id 怎麼命名才不會觸發 Kogito bug? | `references/01-platform-checks/01-workflow-id-naming.md`（含 9 處改名連動 + 檔名-id Manifest） | 全部 examples |
| actionDataFilter 怎麼寫才對（含雙軌 + 豁免）? | `references/01-platform-checks/02-action-data-filter.md` + `08-tostatedata-scope.md` | 全部 workflow YAML |
| path param 怎麼注入? | `references/01-platform-checks/03-path-parameter-injection.md` | 全部 workflow YAML |
| stateDataFilter 該用哪種 convention（Parent/Child/Saga 分流）? | `references/01-platform-checks/04-state-data-filter-convention.md` | 01-financial, 03-insurance |
| YAML 語法有什麼陷阱? | `references/01-platform-checks/05-yaml-strictness.md` | 全部 |
| mock sentinel 怎麼設計才不違反 input validation（A 為主 + validator 豁免）? | `references/01-platform-checks/06-mock-sentinel-vs-input-validation.md` | 01-financial |
| spec example 與 maxLength 怎麼對齊? | `references/01-platform-checks/07-spec-example-consistency.md` | 02/03 notebooks YAML components |
| toStateData 何時可免? | `references/01-platform-checks/08-tostatedata-scope.md` | 全部 workflow YAML |
| x-workflow-id/servers 何時必填? | `references/01-platform-checks/09-xworkflowid-and-servers.md` | 01 internal |
| operation 有宣告 errors 卻無 onErrors / ROLLBACK_FAILED 無告警怎麼辦? | `references/01-platform-checks/10-onerrors-and-opsalert.md` | remittance_swift 審查案例 |
| 設計完成後怎麼驗證? | `references/02-self-check/self-check-list.md` | 對所有 examples 套用 |
| workflow YAML 結構該長怎樣? | `references/03-templates/workflow-yaml-templates.md` | 全部 examples |
| application.properties 該加什麼? | `references/04-config-snippets/application-properties-snippet.md` | 01-financial, 03-insurance |
| spec.md §0 假設清單怎麼寫? | `references/05-fqcn-template/spec-assumption-template.md` | 01-financial/spec/spec.md |
| design-explanation.md 怎麼寫（創建者看得懂）? | `references/06-design-explanation-template/design-explanation-template.md`（9 節強制結構 + 一致性鐵律） | 本次 `design-explanation.md` 實例 |

---

## 對應 example 速查

| 業務情境 | 用哪個 example | 為何 |
|---|---|---|
| 金融交易 (繳款/轉帳/匯款) | `examples/01-financial-repayment/` | 真實案例,最完整 |
| 電商 (下單/出貨/退貨) | `examples/02-ecommerce-order/` | Mode A 最小可跑骨架,3 階段 LIFO |
| 保險/金融審批 (理賠/核保) | `examples/03-insurance-claim/` | Mode B 跨領域最小可跑骨架,結構相同但語意不同 |
| 物流配送 | 參考 `02-ecommerce-order` Mode A 改寫 | — |
| 醫療掛號 | 參考 `01-financial-repayment` Mode B 改寫 | — |
| 純 CRUD 應用 | ❌ 不適用 | 改用一般 API 設計 |
| 純批次處理 | ❌ 不適用 | 改用 Airflow skill |
