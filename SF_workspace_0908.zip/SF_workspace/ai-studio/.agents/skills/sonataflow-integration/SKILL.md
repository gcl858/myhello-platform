---
name: sonataflow-integration
description: 將 draft 階段的 SonataFlow workflow 套件(specs / workflow YAMLs / DDL / Mock Java / Test)整併到 project-0825-pd 多模組 Quarkus 平台。涵蓋 5 大通用品質門禁 (雙軌 Flyway 探測、Workflow↔Java 契約靜態比對、OpenAPI↔Mock 端點覆蓋門禁、Spec 自洽性預檢、組態 CSV 合併協議) 及 Kogito 10.2.0 已知陷阱 (hyphenated subflow workflow id、status-rewrite 對齊、path param 注入、toStateData 狀態保全、onErrors 健壯性)。
---

# SonataFlow Integration Skill (v2.0)

> 從真實整併實踐提煉的 6-step SOP + 5 大通用品質門禁 + 9 個已知踩坑解法。
> 適用於任何「有一個 draft 目錄,含 workflow YAML + OpenAPI spec + Java mock + SQL migration + Test,要整併進 Quarkus 多模組專案」的場景。
> 核心守則：
> 1. **整合守門員不 Overfit 業務邏輯，以靜態契約與雙軌探測杜絕執行期靜默失敗與編譯崩潰。**
> 2. **優先複用與調用端主動對齊 (Caller Adapts to Platform SSOT)**：平台既有成熟服務（如 `AuditLogService`、`IdempotencyService`）為最高標準。當發現 Draft 調用傳參與平台不一致時，**優先修改 Workflow YAML 的 `arguments` 去對齊平台標準簽名**，嚴禁無底線在 Java 新增臨時 overload 導致方法爆炸與介面腐化！

---

## 觸發條件

當使用者訊息包含以下任一,主動載入:
- 「整併 draft / workflow 到 project-0825-pd」
- 「把 sonataflow 套件整合進專案」
- 「新 workflow 要上線,幫我合併」
- 看到 draft 目錄結構含 `notebooks/external/*.yaml` + `spec/*.sw.yaml` + `spec/mocks/*.java` + `spec/db/*.sql` + `spec/tests/*.java`

---

## Step 0: 環境檢查

- 確認 Java 17、Maven 3.8+ 可用 (`which java mvn`)
- 確認 Python 3 與 pyyaml 套件可用 (`python3 -c "import yaml" 2>/dev/null || pip install pyyaml`)
- 確認 Maven mirror 已設定 (Aliyun `https://maven.aliyun.com/repository/central`,mirrorOf=*)
- 確認 JVM truststore 含企業 proxy cert (`keytool -list -cacerts | grep mvn-proxy`)
- 確認 `/root/.m2/settings.xml` mirror 配置正確

---

## Step 1: 分析 draft 結構

預期 draft 內含下列結構 (基於 `vibe-workflow-design` skill 的標準產出):
```
draft-<name>/
├── notebooks/
│   ├── internal/             # Parent 對外入口 (必含 x-workflow-id，validator+router 唯一 SSOT)
│   │   └── <entry-api>.yaml
│   ├── external/             # 被調 host 規格 (必無 x-workflow-id；新案一律此處，root 不收)
│   │   ├── <api-2>-api.yaml
│   │   └── <api-3>-api.yaml
├── spec/
│   ├── <workflow-1>.sw.yaml  # Parent / Child workflow
│   ├── <workflow-2>.sw.yaml
│   ├── <workflow-3>.sw.yaml
│   ├── db/V<X>.<Y>.<Z>__<desc>.sql
│   ├── config/application.properties.snippet
│   ├── mocks/<Resource>1.java
│   ├── mocks/<Resource>2.java
│   ├── mocks/dto/*.java
│   └── tests/<TestName>.java
└── spec.md                    # 規格書,內含 H1-H18 假設清單
```

⛔ draft 若含 `spec/schemas/*.json` 一律丟棄（最終整併不可出 JSON；SSOT 為 notebook YAML 內 `components.schemas`，見 vibe 07）。預檢：`test -z "$(find draft -name '*.json' -path '*schemas*')"`；notebook YAML 內 `$ref: '../spec/schemas/*.json'` 必須先改為 `#/components/schemas/...` 內聯，否則 FAIL。

**關鍵讀取點**:
1. 讀 `spec.md` §0 假設清單 (H1-H14),找出需要新建 / 修改的 Java 服務
2. 讀 §8 Project Mapping Manifest,確認 draft 規劃的目標路徑
3. 檢查每個 `*.sw.yaml` 的 `functions:` section,識別需要新 service bean 的 FQCN

---

## Step 1.5: ⭐ 整合前置品質門禁 (Pre-flight Quality Gates)

> 核心原則：**門禁左移**。在實際拷貝檔案前，透過自動化腳本靜態檢測 3 大契約，杜絕事後晦澀的 Codegen 崩潰與執行期 404/400。
> 執行彈性：腳本支援直接傳入參數：`python3 -c "..." [<draft_dir>] [<project_dir>]`，預設自動偵測 `draft-*` 與 `project-0825-pd`。

### Gate 1: OpenAPI 自洽性預檢 (Spec Self-Consistency Linter)
* **目的**：檢查 `notebooks/internal/*.yaml` 內部是否自相矛盾（驗證 `example` 是否符合 `pattern`、`minLength`、`maxLength`，杜絕規格與測試資料長度衝突）。
* **檢測**：
```bash
python3 -c '
import yaml, re, glob, sys, os
DRAFT = sys.argv[1] if len(sys.argv) > 1 else (glob.glob("draft-*")[0] if glob.glob("draft-*") else ".")
has_error = False
for f in glob.glob(f"{DRAFT}/notebooks/internal/*.yaml"):
    spec = yaml.safe_load(open(f))
    schemas = spec.get("components", {}).get("schemas", {})
    for sname, sdef in schemas.items():
        for pname, pdef in sdef.get("properties", {}).items():
            pattern = pdef.get("pattern")
            example = str(pdef.get("example", ""))
            min_l = pdef.get("minLength")
            max_l = pdef.get("maxLength")
            if example:
                if pattern:
                    clean_p = pattern.strip("^$")
                    if not re.fullmatch(clean_p, example):
                        print(f"❌ [Gate 1 FAIL] {f} -> {sname}.{pname}: example \"{example}\" 不符合 pattern \"{pattern}\"")
                        has_error = True
                if min_l and len(example) < min_l:
                    print(f"❌ [Gate 1 FAIL] {f} -> {sname}.{pname}: example 長度 {len(example)} < minLength {min_l}")
                    has_error = True
                if max_l and len(example) > max_l:
                    print(f"❌ [Gate 1 FAIL] {f} -> {sname}.{pname}: example 長度 {len(example)} > maxLength {max_l}")
                    has_error = True
if has_error:
    print("⚠️ 請放寬 OpenAPI 正則或修正 example 長度，否則正常測試皆會被 400 REJECTED_VALIDATION 攔截！")
    sys.exit(1)
print("✅ [Gate 1 PASS] OpenAPI Spec 自洽性檢查通過")
' draft-remittance
```

### Gate 2: OpenAPI ↔ Mock 端點覆蓋門禁 (Endpoint Coverage Gate)
* **目的**：防止 Draft 遺漏被調主機的補償或反向端點（例如核心帳務只寫了 `/Debit/Execute` 卻遺漏 `/Refund/Execute`），並精確拼接 JAX-RS 類別層級與方法層級 `@Path`，嚴禁子字串包含誤判。
* **檢測**：
```bash
python3 -c '
import yaml, glob, re, sys, os
DRAFT = sys.argv[1] if len(sys.argv) > 1 else "draft-remittance"
PROJECT = sys.argv[2] if len(sys.argv) > 2 else "project-0825-pd"
has_error = False

# 1. 蒐集工作流調用的所有 external schemaRef
called_ops = set()
for f in glob.glob(f"{DRAFT}/spec/*.sw.yaml"):
    for line in open(f):
        m = re.search(r"schemaRef:\s*[\x27\"]?specs/external/([^#]+)\.yaml#([a-zA-Z0-9_]+)", line)
        if m:
            called_ops.add((m.group(1), m.group(2)))

# 2. 解析所有 Mock Resource，拼接類別層級與方法層級 @Path 形成完整端點清單
mock_files = glob.glob(f"{DRAFT}/spec/mocks/*.java") + glob.glob(f"{PROJECT}/dev/transfer-mock/src/main/java/**/*.java", recursive=True)
mock_endpoints = set()
for mf in mock_files:
    content = open(mf, errors="ignore").read()
    paths = re.findall(r"@Path\(\s*\"([^\"]+)\"\s*\)", content)
    if not paths: continue
    c_idx = content.find("class ")
    p_idx = content.find("@Path")
    has_class_path = p_idx < c_idx if c_idx != -1 else False
    if has_class_path:
        cp = paths[0].rstrip("/")
        subs = paths[1:]
        if subs:
            for sp in subs:
                mock_endpoints.add(re.sub(r"\{[^}]+\}", "{x}", (cp + "/" + sp.lstrip("/")).replace("//", "/")))
        else:
            mock_endpoints.add(re.sub(r"\{[^}]+\}", "{x}", cp))
    else:
        for p in paths:
            mock_endpoints.add(re.sub(r"\{[^}]+\}", "{x}", p))

# 3. 比對 operationId 對應之 OpenAPI 端點是否在 Mock 中 100% 存在
for api_file, op_id in called_ops:
    yaml_path = glob.glob(f"{DRAFT}/notebooks/external/{api_file}.yaml")
    if not yaml_path: continue
    spec = yaml.safe_load(open(yaml_path[0]))
    for path, path_item in spec.get("paths", {}).items():
        for method, op in (path_item or {}).items():
            if isinstance(op, dict) and op.get("operationId") == op_id:
                skel = re.sub(r"\{[^}]+\}", "{x}", path)
                if skel not in mock_endpoints:
                    print(f"❌ [Gate 2 FAIL] 缺少 Mock 端點: {api_file}.yaml#{op_id} -> {method.upper()} {path}")
                    has_error = True
if has_error:
    print("⚠️ 缺少對應 Mock 端點，執行期將報 404 Not Found！請先於 draft/spec/mocks/ 補全 Resource 方法。")
    sys.exit(1)
print("✅ [Gate 2 PASS] 所有被調主機端點 Mock 覆蓋率達 100%")
' draft-remittance project-0825-pd
```

### Gate 3: Workflow ↔ Java 服務契約靜態比對 (Contract Linter)
* **目的**：驗證 Workflow 宣告的 Java 類別（FQCN）在專案中真實存在（**必須符合 Package 完整相對路徑，防跨 Package 誤放行**），且方法重載完整。
* **檢測**：
```bash
python3 -c '
import yaml, glob, re, sys, os
DRAFT = sys.argv[1] if len(sys.argv) > 1 else "draft-remittance"
PROJECT = sys.argv[2] if len(sys.argv) > 2 else "project-0825-pd"
has_error = False

for f in glob.glob(f"{DRAFT}/spec/*.sw.yaml"):
    wf = yaml.safe_load(open(f))
    for fn in wf.get("functions", []):
        op = fn.get("operation", "")
        if op.startswith("service:"):
            # 格式: service:com.package.Class::method
            target = op.replace("service:", "")
            fqcn, method = target.split("::")
            expected_rel = fqcn.replace(".", "/") + ".java"
            exact_hits = [h for h in glob.glob(f"{PROJECT}/**/*.java", recursive=True) if h.replace("\\", "/").endswith(expected_rel)]
            if not exact_hits:
                cls_name = fqcn.split(".")[-1]
                cls_hits = glob.glob(f"{PROJECT}/**/{cls_name}.java", recursive=True)
                if cls_hits:
                    print(f"❌ [Gate 3 FAIL] Package 命名空間不符: {fqcn} (宣告於 {f}，但實體類別位於 {cls_hits[0]})")
                else:
                    print(f"❌ [Gate 3 FAIL] 找不到 Java 服務類別: {fqcn} (宣告於 {f})")
                has_error = True
                continue
            content = open(exact_hits[0], errors="ignore").read()
            sigs = re.findall(r"public\s+\S+\s+" + re.escape(method) + r"\s*\(", content)
            if len(sigs) == 0:
                print(f"❌ [Gate 3 FAIL] 類別 {fqcn} 中找不到方法 {method}()！請檢閱該類別既有方法或建立對應實作。")
                has_error = True
            else:
                # 提示 AI 比對 YAML arguments 與既有簽名，優先對齊既有標準
                print(f"ℹ️ [Gate 3 CHECK] 命中 {fqcn}::{method} (現有 {len(sigs)} 個簽名)。請檢視該類別標準簽名，優先修改 Workflow YAML arguments 對齊平台，嚴禁濫造多載！")
if has_error:
    print("⚠️ Java 服務類別不存在、Package 錯誤或完全找不到方法，請依『平台優先原則』對齊簽名或建立類別。")
    sys.exit(1)
print("✅ [Gate 3 PASS] 所有 Workflow custom service FQCN 與既有 Java 方法對齊通過")
' draft-remittance project-0825-pd
```

---

## Step 2: 落規格檔 (純複製,無變形)

| draft 路徑 | 目標路徑 |
|---|---|
| `notebooks/internal/*.yaml` (必含 x-workflow-id) | `<project>/domain-transfer/transfer-workflow/src/main/resources/specs/internal/`<br/>`<project>/distribution/transfer-app/src/main/resources/specs/internal/` |
| `notebooks/external/*.yaml` (必無 x-workflow-id；舊 `notebooks/*.yaml` root 僅相容，進件即搬入 external) | `<project>/domain-transfer/transfer-workflow/src/main/resources/specs/external/`<br/>`<project>/distribution/transfer-app/src/main/resources/specs/external/` |
| `spec/db/V*.sql` | `<project>/domain-transfer/transfer-workflow/src/main/resources/db/migration/`<br/>`<project>/distribution/transfer-app/src/main/resources/db/migration/` |
| `spec/schemas/*.json` | ⛔ 丟棄，不落檔（見上；同時改寫 notebook 內懸空 `$ref` 為內聯） |

入口 API 禁止落 root `specs/*.yaml`（現 root 舊 `omni-counter-repayment-api.yaml` 無標籤嚴格版視為待刪，以 internal 放寬版為準）；`schemaRef` 新案一律 `specs/external/<host>.yaml#op`（舊 `specs/<host>.yaml` 僅相容）。

**⭐ 雙模組同步原則與 POM 保護鐵律 (Dual-Module Sync & POM Protection)**:
- **SSOT 唯一事實來源**: 專案架構中，`transfer-workflow` (邏輯定義模組) 是 `specs/internal/`、`specs/external/` 與 `db/migration/` 的 Canonical Source（root `specs/*.yaml` 僅相容舊案，不再是 SSOT；`schemas/` 已廢止，不同步）。`distribution/transfer-app` 在 Maven `initialize` 階段會自 `transfer-workflow` 自動同步。
- **落檔與更新順序**: 必須先落檔至 `transfer-workflow`，再同步覆蓋至 `distribution/transfer-app`，嚴防測試或打包時讀取到舊版配置！
- ⚠️ **POM 清理排除保護**: 檢查 `distribution/transfer-app/pom.xml` 的 `clean-resources-dir` (maven-clean-plugin)，確認 `<excludes>` 包含 `<exclude>specs/internal/**</exclude>`，否則建置 initialize 階段會將 `specs/internal/` 靜默清空！
- DatabaseMigrationRunner 自動掃描 `db/migration/`,V 編號必須嚴格遞增。

---

## Step 3: 落 workflow YAML + 套用 Kogito bug 修正

### Step 3a: 複製 N 個 workflow (勿寫死 3 個，remittance 為 4 個)

```bash
cp draft/spec/*.sw.yaml <project>/domain-transfer/transfer-workflow/src/main/resources/
```

> **版本字串精確匹配**：`subFlowRef.version` 必須與 child 頂層 `version:` 字串完全相等（含 `"1.0"` vs `"1.0.0"` 差異）。實測前案 `repayment_* version: '1.0.1'` 但 parent 誤寫 `"1.0"` 即為隱患，拷貝後用 `grep -n "version:"` 逐一核對。

### Step 3b: ⭐ Kogito 10.2.0 codegen bug 修正

**症狀預兆**: 任何 workflow 有 `subFlowRef:` 且 workflow id 含 hyphen (`-`)。

**檢測**:
```bash
grep -l "subFlowRef" <project>/domain-transfer/transfer-workflow/src/main/resources/*.sw.yaml
# 若結果的 yaml 內有 id: xxx-yyy → 必須改名
```

**解法** (Python):
```python
mappings = {
    "omni-cash-transaction": "omni_cash_transaction",
    "repayment-cash-deposit": "repayment_cash_deposit",
    "repayment-cash-cancellation": "repayment_cash_cancellation",
    # ... 視實際 draft 而定
}
for f in workflow_yaml_files:
    content = open(f).read()
    for old, new in mappings.items():
        content = content.replace(old, new)
    open(f, "w").write(content)
```

**影響與對外路由透明代理**:
- Kogito 內部工作流 ID 與原生端點變更為 `/xxx_yyy`。
- **對外 API 端點完全不需要妥協變更**: 只要在 `specs/internal/*.yaml` 中宣告原始業務路徑（如 `/Omni/{creditcardid}/Repayment/Execute`）並標註 `x-workflow-id: xxx_yyy`，平台層的 `InternalOpenApiDynamicRouter` (Vert.x 動態路由代理) 便會自動攔截並透明轉發至內部端點，同時自動將 URL 路徑參數（如 `{creditcardid}`）注入 Request Body 頂層，**100% 維持原始對外契約，無需 hotfix 外部路徑**！

---

## Step 4: 補 Java 服務

### Step 4a: 識別需要新建 / 修改的 service

讀 draft 的 `spec.md §0` 假設清單,找出所有 `假設 FQCN` 的 service。例如:
- H6: `AuditLogService::findBySequenceNumber` → 擴充既有 (若 Gate 3 已 PASS 則跳過新建，僅核對 overload 簽名)
- H13: `IdempotencyService` → 若專案已存在則沿用，僅 H13a 類 `*BusinessRuleValidator` 為新建
- H14: `AuditLogService::markCancelledBy` → 擴充既有

> **存在即跳過**：Gate 3 通過的類別/方法嚴禁重建，否則造成重複定義衝突。

### Step 4b: 新建 service 類別

放在 `domain-reconciliation/reconciliation-api/src/main/java/com/example/reconciliation/` 或 `domain-transfer/transfer-workflow/...`

**模板** (以 `IdempotencyService` / `OpenApiSchemaValidator` 為例):
```java
@ApplicationScoped
public class IdempotencyService {
    @Inject DataSource dataSource;
    private static final ObjectMapper MAPPER = new ObjectMapper();

    // 1. 展開參數版入口: 必須完全精確吻合 Workflow YAML arguments 鍵名與型別！
    //    若 arguments 為 { workflowId: "...", businessKey: '${ .seq }' }
    //    Kogito codegen 會嚴格比對此簽名。若缺少，編譯將拋出 NoSuchMethodException / ProcessCodegenException！
    public JsonNode findBySequenceNumber(String workflowId, Object businessKey) {
        // ... v1.0 簡化實作: query workflow_execution_log
    }

    // 2. 跨工作流命名相容多載 (例如 remittance 傳 sequenceNumber、omni 傳 businessKey)
    public JsonNode findBySequenceNumber(String workflowId, Object sequenceNumber) {
        return findBySequenceNumber(workflowId, (Object) sequenceNumber);
    }

    // 3. 通用 JsonNode 單參數版入口 (供通用 custom 呼叫)
    public JsonNode findBySequenceNumber(JsonNode arguments) { ... }
}
```

**⭐ Java 服務三大防護鐵律 (防範方法爆炸與介面腐化)**:
1. **調用端主動對齊平台標準 (Caller Adapts to Callee)**:
   - 當 Kogito Codegen 報錯 `could not find a method called ...` 時，**嚴禁直覺性地在 Java 類別中新增臨時多載 (overload)**！
   - AI 必須先閱讀既有 Java 服務，找出 Canonical 標準簽名（例如 `AuditLogService.saveLog` 標準 5 參）。**第一優先是修改 Workflow YAML 的 `arguments` 去對齊平台標準**，絕不讓未經審核的草稿破壞共用平台架構。
2. **嚴禁只提供 `(JsonNode arguments)`**: 當 Workflow YAML 在 `arguments:` 宣告具名參數時，Kogito 代碼生成器不會包裝為單一 JsonNode，而是直接查找具名參數的方法簽名。因此新建服務時需提供標準展開參數版。
3. **回傳結構對齊 actionDataFilter**: 檢查工作流 YAML 內 `results: '{key: .key}'` 提取的鍵名（例如某些流程期望 `.found`，某些期望 `.idempotentReplay`），Java 回傳之 `ObjectNode` 必須同時滿足或提供別名欄位！

### Step 4c: 擴充既有 AuditLogService (⭐ 解除 SQL 硬編碼與對齊 5-arg 標準)

平台稽核日誌唯一標準入口（SSOT）為 5 參數介面：
```java
// ✅ 平台唯一標準入口：工作流必須一律以 5 參數宣告對齊此方法
public JsonNode saveLog(String workflowId, Object businessKey, Object processInstanceId, Object inputData, Object outputData) { ... }

// 既有 doSaveLog 維持不變,加對應重載與參數化查詢
public JsonNode findBySequenceNumber(String workflowId, Object businessKey) { ... }
public JsonNode findBySequenceNumber(JsonNode arguments) { ... }

// ⚠️ 嚴禁在 SQL 硬編碼 WHERE workflow_id = '特定業務流程'！
// 必須支援傳入 workflowId 參數化，或動態兼容歷史流程：
public JsonNode markCancelledBy(String workflowId, Object originalSequenceNumber, Object cancelledBy, Object cancelledAt) { ... }
public JsonNode markCancelledBy(Object originalSequenceNumber, Object cancelledBy, Object cancelledAt) { ... }
public JsonNode markCancelledBy(JsonNode arguments) { ... }
```

### Step 4d: ⭐ 若需新欄位或對帳 View,加 Flyway migration (雙軌版本探測)

**⚠️ 踩坑預警 (靜默跳過致命陷阱)**:
`DatabaseMigrationRunner.java` 在執行遷移時，會先檢查 `if (appliedVersions.contains(script.getVersion())) continue;`。
若僅用 `find` 掃描專案檔案系統，可能因其他分支或本地 SQLite 資料庫（`data/reconciliation.db`）早已套用過該版本（例如實體 DB 已有 `1.2.5`，而檔案只見 `1.2.0`），導致新腳本**被完全靜默跳過**，對帳 View 根本未被建立！

**雙軌自動探測演算法 (Dual-Track Migration Probe)**:
在為新 Draft 命名 Flyway 腳本前，版本號取：
$$\text{Target Version} = \max(\text{檔案系統最大版本}, \text{實體 DB schema\_history 最大版本}) + 1$$

```bash
# 雙軌探測指令 (需在 vibe_design_0907 父目錄執行；PROJECT 指向 project-0825-pd):
# 注意：reconciliation_schema_history 主鍵為 installed_rank（無 id 欄），
# 取版號必須 SELECT 全量再 sort -V，嚴禁 ORDER BY id。
file_v=$(find <project>/ -path "*/db/migration/V*.sql" 2>/dev/null | grep -oE "V[0-9]+(\.[0-9]+)*" | sort -V | tail -n 1 | sed 's/V//')
db_v=$(sqlite3 <project>/data/reconciliation.db "SELECT version FROM reconciliation_schema_history WHERE success = 1;" 2>/dev/null | sort -V | tail -n 1 || echo "0")

echo "=========================================="
echo "檔案系統最新版本: ${file_v:-0}"
echo "實體 DB 最新版本: ${db_v:-0}"
# 計算兩者較大者
max_v=$(echo -e "${file_v:-0}\n${db_v:-0}" | sort -V | tail -n 1)
echo "目前專案安全基線: $max_v (新腳本必須嚴格大於此版本，例如遞增末碼)"
echo "=========================================="
```

**版本規範**: `V<X>.<Y>.<Z>__<description>.sql` (若安全基線為 `1.2.5`，則新版本必須命名為 `V1.2.6__...`)

```sql
-- 範例: 對帳檢視表
CREATE VIEW IF NOT EXISTS vw_<workflow>_reconciliation AS
SELECT
    id, created_at, workflow_id, business_key, process_instance_id, status, message,
    json_extract(input_data, '$.partyId') AS party_id,
    cancelled_by, cancelled_at
FROM workflow_execution_log
WHERE workflow_id IN ('<parent_workflow_id>', '<child_a_id>', '<child_b_id>');
```

放 `domain-transfer/transfer-workflow/src/main/resources/db/migration/` 與 `distribution/transfer-app/src/main/resources/db/migration/`。

---

## Step 5: 落 mock resources (小心 package 替換陷阱)

### Step 5a: 複製 Java 檔,package 從 draft 的命名空間改成既有 mock 模組的命名空間

```python
# 範例:draft 用 org.acme.cashrepayment.api,正式專案用 org.acme.transfer.api
for f in glob("draft/spec/mocks/*.java"):
    content = open(f).read()
    content = content.replace("org.acme.cashrepayment.api", "org.acme.transfer.api")
    open(f"dev/transfer-mock/src/main/java/org/acme/transfer/api/{basename(f)}", "w").write(content)
```

### Step 5b: ⭐ 避免 sed 二次替換陷阱

**坑**: 如果 draft 的 DTO 已經在 `org.acme.cashrepayment.api.dto` package,sed 兩次替換會變成 `org.acme.transfer.api.dto.dto` (錯誤)。

**預防**:
```python
# 用 Python 取代 sed,精準控制替換邏輯
# 或用兩階段 sed:
# 1. 先把 .cashrepayment.api.dto. 換成 .transfer.api.dto. (全詞匹配)
# 2. 再把 .cashrepayment.api. 換成 .transfer.api. (排除已換過的)
```

### Step 5c: DTO 放 `org.acme.transfer.api.dto/` 子目錄

### Step 5d: ⭐ Mock 端點完整性覆蓋與防重複覆寫 (Coverage & DTO Protection)

1. **正反向與補償端點 100% 覆蓋**:
   - 被調主機除了正向操作（如 `/Debit/Execute`、`/Send/Execute`），凡工作流具備補償或取消路徑（如 `/Refund/Execute`、`/Cancel/Execute`），Mock Resource 必須完整實作，嚴防集成測試時回傳 HTTP 404 Not Found。
2. **避免覆寫既有共享 DTO**:
   - 若目標專案 `dev/transfer-mock/.../dto/` 已存在共享類別（例如 `ErrorDetail.java`），落檔前先比對欄位，若結構相容則保留專案既有檔案，避免重複定義或覆寫破壞其他業務模組。

---

## Step 6: ⭐ 4 個 workflow 內容修正(整併特有的坑)

### 6a. Path parameter 注入

**症狀**: workflow 調用 OpenAPI 時報 `Illegal character in path ... {xxx}`。

**根因**: mock 的 `@Path("/foo/{xxx}/bar")` 但 workflow 沒在 payload 帶 `xxx`。

**解法**: 在每個 callApiViaOpenAPI 的 payload 內顯式加:
```yaml
payload:
  creditcardid: '${ .partyId }'   # ← 補上
  partyId: '${ .partyId }'
  ...
```

**小心**: YAML list item 不要 trailing comma:
```yaml
# ✗ 錯
creditcardid: '${ .partyId }',
# ✗ 對 (無 comma)
creditcardid: '${ .partyId }'
```

### 6b. actionDataFilter 結構對齊 MyOpenApiService

**症狀**: workflow 走到 FAILED 分支但 host API 回 200,因為 `.result.status` 是 null。

**根因**: `MyOpenApiService` 把 host API response 直接放頂層(`.code` / `.message` / `.Account` 等),不是 `.result` 底下。

**解法**: 改 actionDataFilter 直接讀頂層:
```yaml
# ✗ 錯 (假設 response 在 .result 下)
results: '{status: .result.status, message: .result.message, track_id: .result.track_id}'

# ✓ 對 (直接讀頂層)
results: '{status: .status, message: .message, track_id: .track_id, errorType: .errorType, _httpStatus: ._httpStatus, errors: .errors}'
```

### 6c. ⭐ status-rewrite filter 加 finalStatus 支援

**前置檢查（已修即跳過）**：若 `platform-security/.../SonataFlowSecurityConfig.java` 已含 `map.get("finalStatus")`，跳過 Java 修改，僅做 Step 7 mapping 追加，避免重複編輯造成 merge conflict。

**症狀**: workflow 回 `finalStatus: REJECTED_VALIDATION` 但 HTTP code 是 200(應該 400)。

**根因**: 既有 `WorkflowStatusFilter` 只讀 `status` 欄位。新 omni convention 用 `status: 0/1` (int) + `finalStatus: STRING`。

**解法**: 修改 `platform-security/.../SonataFlowSecurityConfig.java` 的 filter:
```java
// 改前
Object status = map.get("status");

// 改後 (優先 finalStatus,退回 status;且只對 String 映射)
Object status = map.get("finalStatus");
if (status == null) {
    status = map.get("status");  // 向下相容 saga2
}
if (status != null && status instanceof String) {
    Integer rewrite = statusRewriteMap.get(status.toString());
    if (rewrite != null) {
        responseContext.setStatus(rewrite);
    }
}
```

### 6d. SQL view workflow_id 對齊

**症狀**: V<X> SQL view 套用後查詢回 0 筆。

**根因**: view 的 `WHERE workflow_id IN (...)` 用了 draft 的 hyphen id,實際是 underscore。

**解法**: 改 V<X> SQL 內的 id 清單,並手動 drop & recreate view (因為 `CREATE VIEW IF NOT EXISTS` 不會重新觸發)。

### 6e. ⭐ actionDataFilter 必須宣告 toStateData (防 State Data 沖洗)

**症狀**: workflow 執行後下游節點或 `FinalAuditAndEnd` 取得的欄位（如 `partyId`, `amount`, `sequenceNumber`）全部為 `null`，且回應中的業務資料遺失。

**根因**: 在 operation state 中若僅配置 `actionDataFilter.results: '{ ... }'` 但未指定 `toStateData`，Kogito 預設會將 action results 物件**整份覆蓋**當前 Workflow State Data。

**解法**: 永遠顯式指定 `toStateData`:
```yaml
# ❌ 錯 (state data 被覆寫為僅有 validationResult)
actionDataFilter:
  results: '${ { validationResult: . } }'

# ✅ 對 (保留所有原始輸入欄位，僅注入指定 key)
actionDataFilter:
  results: '{isValid: .isValid, message: .message, errors: .errors}'
  toStateData: '${ .validationResult }'
```

### 6f. ⭐ SQLite 對帳視圖測試的歷史資料污染防護

**症狀**: 測試案例（如 `testA6ReconciliationView`）比對 `rs.getString("operation_type")` 斷言失敗（例如預期 `"A"` 但得到 `"C"`）。

**根因**: SQLite DB 跨測試方法持久化。若 SQL 僅用 `WHERE workflow_id = 'xxx' AND amount = 'xxx' LIMIT 1`，會因未排序且無狀態過濾，撈到前面失敗測試（如 P1 `operationType=C`）遺留的舊資料。

**解法**: 測試 SQL 必須加入精確的狀態約束與倒序排列：
```java
// ✅ 對: 限制 status='SUCCESS' 並以 id 倒序取最新一筆
ResultSet rs = stmt.executeQuery(
    "SELECT id, workflow_id, business_key, status, operation_type, amount " +
    "FROM vw_omni_cash_transaction_reconciliation " +
    "WHERE workflow_id = 'omni_cash_transaction' AND status = 'SUCCESS' AND amount = '0000011758' " +
    "ORDER BY id DESC LIMIT 1"
);
```

### 6g. ⭐ 操作健壯性與稽核安全網 (onErrors & OpsAlert Guard)

**症狀 A (Audit Gap 稽核斷層)**: Host 呼叫逾時或網路中斷（SocketTimeoutException）時，Workflow 直接中斷拋 500，未走到 `FinalAuditAndEnd`，導致 DB 無任何執行日誌記錄。
- **解法**: 凡工作流頂層宣告 `errors: [{name: platformError}]`，**每個 `type: operation` 節點必須標註 `onErrors`**（轉移至補償或結尾狀態），嚴禁操作裸奔！

**症狀 B (jq Null Pointer 崩潰)**: switch 條件判斷式 `(.coreResult.status | tostring) != "0"`，當前置操作失敗導致 `coreResult` 為 null 時，jq 拋出異常。
- **解法**: 所有 `condition:` 讀取嵌套欄位時，**一律加入 `//` 預設值保護**：
  ```yaml
  # ❌ 易崩潰
  condition: '${ (.coreResult.status | tostring) != "0" }'
  # ✅ 安全守衛
  condition: '${ ((.coreResult.status // "999") | tostring) != "0" }'
  ```

**症狀 C (回沖失敗靜默忽略)**: 當流程流轉至 `*_ROLLBACK_FAILED` 時靜默結束，未觸發運維通道。
- **解法**: 凡具備 `ROLLBACK_FAILED` 終態的工作流程，必須在結尾節點調用 `notifyOps`（`OpsAlertService::raise`），確保輸出 `[OPS-ALERT]` 供日誌監控攔截。

**症狀 D (取消標記無檢查)**: `MarkCancelled` 類 operation 無 `actionDataFilter`、直接進終態輸出，`markCancelledBy` 回 `rowsUpdated=0` 無人發現。
- **解法**: `markCancelledBy` 節點必須加 `actionDataFilter.results/toStateData` 並檢查結果，失敗時轉 `CANCEL_ROLLBACK_FAILED` 分支，嚴禁裸調直出。

### 6h. 業務欄位 literal 告警 (P3，非阻擋)
`currency/BIC/country/address/fee/rate` 六類業務欄位僅允許 `OUR/BEN/A/B/C/R` 字面值，其餘必須 `${ .field }`；`amountInUSD` 類衍生欄位必須含運算式（含 `fxRate` 或 §0 假設註明）。整併時人工複核：
```bash
grep -nE "senderBIC|receiverBIC|beneficiaryCountry|remitterAddress|feeAmount|amountInUSD|fxRate" <project>/domain-transfer/transfer-workflow/src/main/resources/*.sw.yaml
```

### 6i. ⭐ Kogito jBPM Split 節點條件順序競態防護 (解耦冪等 Switch 與業務 Dispatcher)

**症狀**: 測試冪等重放（例如 `p4_idempotentReplay`）發送相同 sequenceNumber，期望 `IDEMPOTENT_REPLAY`，卻實際回傳 `SUCCESS` 再次執行了業務流程！
**根因**: 在 Kogito Serverless Workflow 中，單一 `switch` state 的多個 `dataConditions` 會被編譯為 jBPM `Split (XOR)` 節點。當 `replayHit` (`.idempotencyResult.idempotentReplay == true`) 與 `routeDomestic` (`.operationType == "A"`) 同時滿足時，jBPM 的條件求值順序是由內部集合 iteration 決定，**非 YAML 宣告的先後順序**！業務路由分支很容易掠奪冪等重放分支。
**解法**: 狀態機拓撲結構必須將「冪等結果判斷」與「業務路由分流」徹底解耦為前後兩個獨立的 Switch 狀態：
`CheckIdempotency` (operation) $\rightarrow$ `CheckIdempotencyResult` (switch，僅判斷 `idempotentReplay == true` 轉移至 `InjectIdempotentReplayStatus`，default 轉移至 `Dispatcher`) $\rightarrow$ `Dispatcher` (switch，僅依 `operationType` 路由至子工作流)。

### 6j. ⭐ 稽核日誌狀態雙向對齊與落庫保全 (`status` vs `finalStatus`)

**症狀**: 沖銷子流程查詢原交易時報 `badStatus`（狀態非 SUCCESS），或對帳紀錄中 `status` 為 `"UNKNOWN"`。
**根因**: 工作流結尾 `FinalAuditAndEnd` 呼叫 `recordAuditLog` 時，若 `outputData` 僅傳遞 `{finalStatus: .finalStatus}`，而底層 `AuditLogService` 僅解析 `status` 屬性，會導致落庫時 `status` 欄位被降級填入 `"UNKNOWN"`，破壞後續沖銷查詢與對帳校驗。
**解法**:
1. Workflow `outputData` 永遠同時提供雙向欄位：`outputData: '${ {status: .finalStatus, finalStatus: .finalStatus, message: (.finalMessage // "")} }'`。
2. `AuditLogService.doSaveLog` 實作兼顧 `has("status")` 與 `has("finalStatus")` 的雙重讀取。

---

## Step 7: ⭐ 合併 application.properties (組態合併協議)

修改 `<project>/distribution/transfer-app/src/main/resources/application.properties`:

**⚠️ 平台 MicroProfile Config 解析合約陷阱**:
專案中 `SonataFlowSecurityConfig.java` 對狀態碼改寫的讀取採用 **單行逗號分隔字串 (CSV)** 解析（`configuredMapping.split(",")`，每項為 `STATUS=CODE`）。
**嚴禁**將 Draft snippet 產出的展開格式（`platform.status-rewrite.mapping.STATUS=CODE`）直接貼入，否則會被 MicroProfile Config 靜默忽略，改寫完全失效！

### 7a. 正確合併三原則:

1. **工作流名單追加 (CSV Append)**:
   在 `platform.status-rewrite.workflows` 現有名單後以逗號追加新工作流程 ID：
   ```properties
   platform.status-rewrite.workflows=saga2-transfer-workflow,omni_cash_transaction,repayment_cash_deposit,repayment_cash_cancellation,<new_parent_id>,<new_child_id>
   ```

2. **狀態碼改寫追加 (CSV Append)**:
   在 `platform.status-rewrite.mapping` 現有映射後以逗號追加 `STATUS=HTTP_CODE`：
   ```properties
   platform.status-rewrite.mapping=VALIDATION_FAILED=400,ROLLBACK_FAILED=409,REJECTED_VALIDATION=400,LOOKUP_FAILED=500,CANCEL_ROLLBACK_FAILED=409,SWIFT_ROLLBACK_FAILED=409,AML_REJECTED_ROLLBACK_FAILED=409
   ```

3. **Function Bean Alias 註冊**:
   若工作流程使用 `custom` 函數別名，在 `%dev.` profile 下綁定對應的 CDI Bean 名稱（首字母小寫）：
   ```properties
   %dev.kogito.sw.functions.checkIdempotency.bean=idempotencyService
   %dev.kogito.sw.functions.lookupOriginalTransaction.bean=auditLogService
   %dev.kogito.sw.functions.markOriginalCancelled.bean=auditLogService
   %dev.kogito.sw.functions.recordAuditLog.bean=auditLogService
   %dev.kogito.sw.functions.notifyOps.bean=opsAlertService
   ```

> 註: `RemittanceBusinessRuleValidator` 等實作 `BusinessRuleValidator` 的類別採 CDI 動態注入，無需在此重複註冊 Bean。

> 註:`kogito.sw.functions.X.bean=...` 這種設定 Quarkus 會噴 "Unrecognized configuration key" warning(因為 Kogito 內建 OpenAPI handler 才用這種設定),但對 `service:` 形式的 workflow 沒影響,可忽略。

---

## Step 8: 落測試

```bash
cp draft/spec/tests/*.java <project>/distribution/transfer-app/src/test/java/com/example/platform/distribution/transfer/
# package 替換: <draft-package> → com.example.platform.distribution.transfer
```

**測試撰寫注意事項**:
1. **動態唯一業務鍵**: 每個正向或反向測試，`sequenceNumber` 一律加上 `System.nanoTime()`，避免觸發 Parent 冪等快取。
2. **JDBC View 驗證防污染**: 如 6f 所述，查詢 View 時務必加上 `status = 'SUCCESS' ORDER BY id DESC LIMIT 1`。
3. **OpenAPI 動態路由斷言**: 透過 Vert.x 動態路由發送請求時，斷言應比對工作流程頂層回傳（如 `finalStatus`、`workflow`、`auditSaved`），避免依賴不存在的 `result.xxx` 嵌套欄位。

---

## Step 9: 編譯 → 測試 → package

### 9a: 編譯
```bash
mvn -B compile -DskipTests -fae -T 1 -Dmaven.wagon.http.retryHandler.count=10
```

### 9b: 測試
```bash
# 先清掉 .lastUpdated 失敗快取
find ~/.m2/repository -name "*.lastUpdated" -delete
find ~/.m2/repository -name "_remote.repositories" -delete
mvn -B test -fae -T 1 -Dmaven.wagon.http.retryHandler.count=10
```

### 9c: package
```bash
# 必須從根跑(子樹 -pl 會因 deployment extension descriptor 缺 jar 失敗)
mvn -B package -DskipTests -fae -T 1 -Dmaven.wagon.http.retryHandler.count=10
```

**預期時間**: 編譯 1-2min、測試 5-10min、package 3-5min(首次下載所有 deps 20-30min)。

---

## Step 10: 端對端 smoke test

```bash
# 啟動 (port 8080 是 mock 預期 port)
nohup java -Dquarkus.http.port=8080 -Dquarkus.profile=dev \
  -jar distribution/transfer-app/target/quarkus-app/quarkus-run.jar \
  > /tmp/transfer-app.log 2>&1 &

# 等 health
for i in {1..30}; do
  HC=$(curl -s -o /dev/null -w "%{http_code}" http://127.0.0.1:8080/q/health)
  [ "$HC" = "200" ] && break
  sleep 3
done

# 跑至少 5 個核心情境:
# 1. P1: operationType=C → 400 REJECTED_VALIDATION
# 2. A1: 正常 SUCCESS → 200,core+cc track_id 都有
# 3. B1: 正常 CANCELLED → 200,Core+CC 反向都成功
# 4. B2: 不存在的 originalSequenceNumber → 500 LOOKUP_FAILED
# 5. P4: Parent 級冪等 (同 seq 重送) → 第二次 IDEMPOTENT_REPLAY

# 查 DB 確認 audit log 落地
sqlite3 data/reconciliation.db \
  "SELECT workflow_id, COUNT(*) FROM workflow_execution_log
   WHERE workflow_id LIKE '%_cash%' OR workflow_id LIKE '%repayment_%' GROUP BY workflow_id;"
```

---

## 整合完成的驗收 checklist

- [ ] `mvn -B package -DskipTests` 全 22 modules BUILD SUCCESS
- [ ] `mvn -B test` 跑出至少 N+1 個測試(N=既有數,1=新測試類別)
- [ ] `transfer-app/target/quarkus-app/quarkus-run.jar` 存在 (~122MB)
- [ ] 啟動後 `/q/health` 回 200
- [ ] 至少 5 個 E2E 情境通過
- [ ] audit log 落地 (workflow_execution_log 有新 workflow_id 的 row)
- [ ] DB view 存在 (`vw_<workflow-name>_reconciliation`)
- [ ] 無 NEW critical build error(可有 Quarkus warning)

---

## 失敗模式速查

| 失敗訊息關鍵字 | 對應修正 |
|---|---|
| `KieMemoryCompilerException: ';' expected, <identifier> expected` | Kogito subflow hyphen bug → 改名 underscore |
| `Illegal character in path at index N: ...{xxx}` | path parameter 沒傳 → 6a |
| `expected <block end>, but found ','` | YAML trailing comma → 6a 注意 |
| `finalStatus: REJECTED_VALIDATION` 但 HTTP 200 | status-rewrite filter 沒認 finalStatus → 6c |
| `vw_xxx_reconciliation` 查詢回 0 筆 | view 的 WHERE 用舊 id → 6d |
| `result.status == 0` 永遠 false | actionDataFilter 結構錯誤 → 6b |
| `rowsUpdated=0` 在 markOriginalCancelled | transaction 隔離 / cancelled_by 已值 / 連線池問題,留 v1.1 排查 |
| `Expected status code <200> but was <400>` | 全域正則拒絕正常通路碼 (如 `2500P`) → 檢查 API 規格放寬正則 (如 `^[A-Za-z0-9]{1,10}$`) |
| `finalStatus: null` 在業務失敗分支 | jq condition `tonumber` 遇到非數字哨兵 (如 `FAIL_`) 拋錯 → 加上 startswith("FAIL_") 守衛 |
| `Expected: SUCCESS Actual: IDEMPOTENT_REPLAY` | 測試案例重複使用硬編碼 sequenceNumber 觸發冪等 → 測試改用 System.nanoTime() 動態序號 |
| `NullPointerException: ... getStart() is null` | `.sw.yaml` 根節點缺少 `start:` 宣告 → 於 workflow 頂層顯式定義 `start: <StateName>` |
| `ClassCastException: ... cannot be cast to JsonNode` | Java 重載方法參數綁定失配 → 於 functionRef arguments 明確傳遞 `workflowId` 與 `businessKey` |
| `ProcessCodegenException: could not find a method called "..." with proper arguments` | Kogito 工作項反射找不到對應具名參數的方法簽名 → Java 服務補上展開參數重載 (如 `(String, Object)`) |
| `JSON path result.xxx doesn't match / actual: null` | Operation state 缺少 `toStateData` 導致輸入 payload 被覆寫 → 在 `actionDataFilter` 補上 `toStateData: '${ .targetKey }'` (見 6e) |
| `AssertionFailedError: View 應包含一筆 REPAYMENT 成功紀錄` | SQLite 對帳 View 查詢撈到前置測試遺留舊資料 → SQL 補上 `status='SUCCESS' ORDER BY id DESC LIMIT 1` (見 6f) |
| `長度超限, 最多允許 X 字元` | OpenAPI Spec 的 maxLength 與 example/測試序號長度衝突 → 修改 OpenAPI spec 放寬限制 |
| `cannot find symbol: class <NewService>` | 子模組依賴更新但尚未安裝至本機庫 → 先執行 `mvn install -pl <module> -DskipTests` |
| `API 呼叫錯誤: 無法確定 API Base URL` | OpenAPI Spec 缺少 `servers:` 宣告且無全域 host → 於 Spec 補上 `servers: - url: http://localhost:8080` |
| `Expected status code <400> but was <404>` | `specs/internal` 被 `transfer-app` 的 clean plugin 刪除，或未放置於 `domain-transfer/transfer-workflow/src/main/resources/specs/internal/` → 補上 POM exclude 並於 SSOT 落檔 |
| `found JSON schema file in handoff`（`spec/schemas/*.json` 殘留） | 最終整併不可出 JSON → 丟棄 JSON 並將 notebook 內 `$ref: '../spec/schemas/*.json'` 改為 `#/components/schemas/...` 內聯 |
| `x-workflow-id in specs/external` 或 internal 缺標籤 | internal 必含、external 必無 → 按 vibe 6.9 修正後重落 |
| `new yaml landed in specs/ root` | root 禁放（`openapi.yaml` 除外）→ 搬入 `specs/external/`，`schemaRef` 改 `specs/external/...` |
| `internal/external 同名檔漂移`（除標籤外內容不一致，如 root omni 式放寬） | 以 internal 放寬版為準同步，刪除 root 舊檔 |
| `JSON path result.xxx doesn't match / actual: null (在動態路由測試時)` | 動態路由測試應斷言工作流程頂層欄位（如 `finalStatus`、`coreResult.status`），避免依賴不存在的 `result.xxx` |
| `sqlite3.OperationalError: no such column: updated_at` | 對帳 View 參照不存在欄位 → 修正 View 定義，移除 `updated_at`，僅保留 `created_at` |
| `no such table: vw_<name>_reconciliation` (即使有建 V 檔) | Flyway 版本號與實體 DB 衝突被靜默跳過 → 執行 Step 4d 雙軌探測，遞增版本號為安全基線+1 |
| `NoSuchMethodException: ... saveLog(...)` | Workflow 傳遞具名參數但 Java 服務缺少精確展開簽名 → 依 Step 4b 補上具名參數重載 |
| `404 Not Found (呼叫 Mock API 時)` | OpenAPI 宣告端點缺少對應 JAX-RS Resource (如漏寫 Refund) → 執行 Gate 2 並於 Mock 補全端點 |
| `Cannot index null with string "..."` | switch condition 讀取嵌套欄位未加安全守衛 → 依 Step 6g 加入 `((.status // "999") | tostring)` |
| `finalStatus: REJECTED_VALIDATION 但 HTTP 200 (已加 mapping)` | application.properties 使用了 dot-notation 被忽略 → 依 Step 7 改為單行 CSV 逗號追加格式 |
| `Audit Log 遺漏 (主機異常中斷時無記錄)` | operation 節點未宣告 onErrors 導致例外脫逸 → 依 Step 6g 補齊 onErrors 導流至 Audit 節點 |
| `maven.aliyun.com 503 Service Unavailable` | 重試 / 切換 mirror / 縮短單次 build |
| Java/Maven 突然 not found | sandbox 自動清掉,重裝 `apt-get install openjdk-17-jdk-headless maven` |

---

## 反模式 (不要這樣做)

- ❌ 不要把整個 draft 資料夾丟進 project,挑選對應的檔案落對應目錄
- ❌ 不要跳過 Kogito bug 修正,直接編譯會 fail
- ❌ 不要改既有 saga2-transfer-workflow 的 convention(向後相容用 fallback)
- ❌ 不要用 `mvn install:install-file` 手動裝 jar,會破壞 reactor 一致性
- ❌ 不要在 test 階段才建 workflow URL prefix(應該是 dev profile 啟動時 Kogito 自動註冊)
- ❌ 不要省略 `creditcardid` 補上動作(6a),否則 mock 收到 `IllegalArgumentException`
- ❌ 不要在沒有 dev profile 下做 E2E(mocks 是 dev-only 模組,prod 會被排除)
