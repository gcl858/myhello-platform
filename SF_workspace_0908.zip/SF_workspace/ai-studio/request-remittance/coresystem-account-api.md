# 核心帳務主機 — 扣款 / 退款 / 圈存 / 查詢 API

**ver.** : `1.0`
**主機名稱** : 核心帳務主機 (Core Account Host)
**通訊方式** : API
**訊息格式** : JSON (UTF-8)
**對應業務需求書** : `remittance-requirement.md` v1.0

> 本主機負責所有與客戶帳戶餘額相關的操作,是匯款流程的「資金落點」。所有 4 個端點由 Parent 的 Child Workflow (WF-A / WF-B / WF-C) 呼叫。

---

## 0. 端點清單

| # | 端點 | 用途 | 觸發 workflow 階段 |
|---|---|---|---|
| 1 | `POST /CoreAccount/{partyId}/Debit/Execute` | 扣款(opType=A) | WF-A 階段 1、WF-B 階段 1 |
| 2 | `POST /CoreAccount/{partyId}/Refund/Execute` | 退款(opType=B) | WF-A/B 失敗補償、WF-C 階段 2 |
| 3 | `POST /CoreAccount/{partyId}/Hold/Execute` | 圈存(預扣) | WF-B 階段 1(跨境預扣) |
| 4 | `POST /CoreAccount/{partyId}/Query/Execute` | 查詢餘額 | 輔助 |

---

## 1. 扣款 API

**URL** : `/CoreAccount/{partyId}/Debit/Execute`
**Method** : `POST`
**說明** : 從客戶台幣/外幣帳戶扣款,支援單幣別扣款;跨境匯款需分兩次呼叫(台幣手續費 + 外幣匯款金額)

### 1.1 Request 參數

| 參數名 | 類型 | 必填 | 說明 |
| --- | --- | --- | --- |
| partyId | `string` | ✓ | 客戶統編(URL path) |
| transactionType | `string` | ✓ | 固定為 `REMITTANCE` |
| transactionDate | `string` | ✓ | 交易日期 (YYYYMMDD) |
| transactionDateTime | `string` | ✓ | 交易時間 (HHMMSSxx) |
| postingDayType | `string` | ✓ | A=本日 / B=次日 |
| postingDate | `string` | ✓ | 入帳日 (YYYYMMDD) |
| paymentSourceCode | `string` | ✓ | 見下方 |
| operationType | `string` | ✓ | 固定為 `A`(扣款) |
| debitAccount | `string` | ✓ | 扣款帳號 |
| currency | `string` | ✓ | 扣款幣別(ISO 4217,如 TWD/USD/JPY) |
| amount | `string` | ✓ | 扣款金額(分,左補零) |
| feeAmount | `string` | ✗ | 手續費金額(分,跨境必填) |
| totalAmount | `string` | ✓ | 實際扣款總額(分,=amount+feeAmount) |
| sequenceNumber | `string` | ✓ | 交易序號(prefix `CR_` + 19 碼業務序號,共 22 字元) |
| remark | `string` | ✗ | 備註(用於跨境匯款的匯款性質記錄) |

### 1.2 繳款來源碼 (`paymentSourceCode`)

| Code | Description |
| --- | --- |
| J | 語音 |
| K | 存款 |
| P | 網路銀行 |
| I | CD/ATM 轉帳 |
| A | 現金 |
| E | 轉帳 |

### 1.3 Request 範例

**台幣扣款(WF-A 國內匯款):**
```json
{
    "transactionType": "REMITTANCE",
    "transactionDate": "20260907",
    "transactionDateTime": "15061655",
    "postingDayType": "A",
    "postingDate": "20260907",
    "paymentSourceCode": "2500P",
    "operationType": "A",
    "debitAccount": "0012345678901",
    "currency": "TWD",
    "amount": "0000011758",
    "feeAmount": "0000000030",
    "totalAmount": "0000011788",
    "sequenceNumber": "CR_A1234567890000015061655"
}
```

**外幣扣款(WF-B 跨境匯款,美元):**
```json
{
    "transactionType": "REMITTANCE",
    "transactionDate": "20260907",
    "transactionDateTime": "16000000",
    "postingDayType": "A",
    "postingDate": "20260907",
    "paymentSourceCode": "2500P",
    "operationType": "A",
    "debitAccount": "0098765432109",
    "currency": "USD",
    "amount": "0000010000",       // 100.00 USD
    "feeAmount": "0000000500",    // 5.00 USD (估算中間行費)
    "totalAmount": "0000010500",
    "sequenceNumber": "CR_A1234567890000016000000",
    "remark": "PURPOSE_CODE:10100 BENE_BIC:DEUTDEFFXXX"
}
```

### 1.4 Success Response

```json
{
    "track_id": "fec08b53dada432fac042dee8b1e3390",
    "status": 0,
    "errors": null,
    "result": {
        "partyId": "A123456789",
        "debitAccount": "0012345678901",
        "currency": "TWD",
        "operationType": "A",
        "amount": "0000011758",
        "feeAmount": "0000000030",
        "totalAmount": "0000011788",
        "balanceAfter": "0009876543210",
        "sequenceNumber": "CR_A1234567890000015061655"
    }
}
```

### 1.5 Error Response

```json
{
    "track_id": "c269cd92a1984c2895175926930b871e",
    "status": 1,
    "errors": [
        {
            "error_code": "E0011",
            "message": "帳戶餘額不足"
        }
    ],
    "result": null
}
```

### 1.6 常見錯誤代碼

| error_code | 訊息 | 業務處理 |
|---|---|---|
| E0011 | 帳戶餘額不足 | FAILED,告知客戶餘額不足 |
| E0012 | 帳戶已凍結 | FAILED,需客戶至分行解除凍結 |
| E0013 | 帳戶不存在 | FAILED,請客戶確認帳號 |
| E0021 | 單筆金額超過限額 | FAILED,需授權櫃員覆核 |
| E0022 | 當日累計超過限額 | FAILED,隔日再試 |
| E0023 | 查無資料 | FAILED(罕見,通常為 sequenceNumber 重複但資料未建) |
| E0050 | 系統錯誤 | 視為 timeout,Parent 啟動未知狀態查詢 |

---

## 2. 退款 API

**URL** : `/CoreAccount/{partyId}/Refund/Execute`
**Method** : `POST`
**說明** : 將款項退回客戶帳戶,opType=B;用於失敗補償或沖銷退款

### 2.1 Request 參數

| 參數名 | 類型 | 必填 | 說明 |
| --- | --- | --- | --- |
| partyId | `string` | ✓ | 客戶統編(URL path) |
| transactionType | `string` | ✓ | 固定為 `REMITTANCE` |
| originalSequenceNumber | `string` | ✓ | 原扣款的 sequenceNumber(用於冪等回滾) |
| transactionDate | `string` | ✓ | 退款日期 (YYYYMMDD) |
| transactionDateTime | `string` | ✓ | 退款時間 (HHMMSSxx) |
| postingDayType | `string` | ✓ | A=本日 / B=次日 |
| postingDate | `string` | ✓ | 入帳日 |
| operationType | `string` | ✓ | 固定為 `B`(退款) |
| refundAccount | `string` | ✓ | 退款帳號(同原扣款帳號) |
| currency | `string` | ✓ | 退款幣別(同原扣款幣別) |
| amount | `string` | ✓ | 退款金額(分) |
| feeAmount | `string` | ✗ | 退款手續費(通常為 0,但跨境可能不退中間行費) |
| totalAmount | `string` | ✓ | 實際退款總額(=amount+feeAmount) |
| refundReason | `string` | ✓ | 退款原因:`REMITTANCE_FAILED` / `REMITTANCE_CANCELLED` / `AML_REJECTED` |
| sequenceNumber | `string` | ✓ | 退款序號(prefix `CR_R_` + 19 碼業務序號,共 22 字元) |

### 2.2 Request 範例

```json
{
    "transactionType": "REMITTANCE",
    "originalSequenceNumber": "CR_A1234567890000015061655",
    "transactionDate": "20260907",
    "transactionDateTime": "15300000",
    "postingDayType": "A",
    "postingDate": "20260907",
    "operationType": "B",
    "refundAccount": "0012345678901",
    "currency": "TWD",
    "amount": "0000011758",
    "feeAmount": "0000000030",
    "totalAmount": "0000011788",
    "refundReason": "REMITTANCE_FAILED",
    "sequenceNumber": "CR_R_A1234567890000015300000"
}
```

### 2.3 Success Response

```json
{
    "track_id": "a1b2c3d4e5f6789012345678",
    "status": 0,
    "errors": null,
    "result": {
        "partyId": "A123456789",
        "refundAccount": "0012345678901",
        "currency": "TWD",
        "operationType": "B",
        "amount": "0000011758",
        "feeAmount": "0000000030",
        "totalAmount": "0000011788",
        "balanceAfter": "0009876544998",
        "sequenceNumber": "CR_R_A1234567890000015300000"
    }
}
```

### 2.4 Error Response

```json
{
    "track_id": "d4e5f6789012345678901abc",
    "status": 1,
    "errors": [
        {
            "error_code": "E0031",
            "message": "原交易已退款,不可重複退款"
        }
    ],
    "result": null
}
```

### 2.5 常見錯誤代碼

| error_code | 訊息 | 業務處理 |
|---|---|---|
| E0031 | 原交易已退款 | 視為冪等命中(同 seq 重送回傳同結果) |
| E0032 | 原交易未找到 | FAILED,需人工核對 |
| E0033 | 原交易非 SUCCESS 狀態,不可退款 | ROLLBACK_FAILED,告警人工 |
| E0050 | 系統錯誤 | 視為 timeout |

---

## 3. 圈存 API

**URL** : `/CoreAccount/{partyId}/Hold/Execute`
**Method** : `POST`
**說明** : 跨境匯款預扣款項,後續 SWIFT 報文送出失敗時可解除圈存(不必走退款流程)

> 本端點為**選用設計**,若業務方希望跨境匯款統一走「扣款 + 退款」路徑,可跳過本端點。本版 v1.0 設計為:**跨境匯款先圈存,SWIFT 成功後轉扣款,失敗後解除圈存**。

### 3.1 Request 參數

| 參數名 | 類型 | 必填 | 說明 |
| --- | --- | --- | --- |
| partyId | `string` | ✓ | 客戶統編(URL path) |
| holdAccount | `string` | ✓ | 圈存帳號 |
| currency | `string` | ✓ | 圈存幣別 |
| amount | `string` | ✓ | 圈存金額(分) |
| expireAt | `string` | ✓ | 圈存到期時間(YYYYMMDDHHMMSS),預設 24 小時 |
| sequenceNumber | `string` | ✓ | 圈存序號(prefix `CH_` + 19 碼,共 22 字元) |
| remark | `string` | ✗ | 備註 |

### 3.2 Request 範例

```json
{
    "holdAccount": "0098765432109",
    "currency": "USD",
    "amount": "0000010500",
    "expireAt": "20260908160000",
    "sequenceNumber": "CH_A1234567890000016000000",
    "remark": "SWIFT 跨境匯款預扣"
}
```

### 3.3 Success Response

```json
{
    "track_id": "h1h2h3h4h5h6h7h8h9h0h1h2",
    "status": 0,
    "errors": null,
    "result": {
        "partyId": "A123456789",
        "holdAccount": "0098765432109",
        "currency": "USD",
        "amount": "0000010500",
        "holdId": "HOLD202609070001",
        "expireAt": "20260908160000",
        "sequenceNumber": "CH_A1234567890000016000000"
    }
}
```

### 3.4 解除圈存

圈存可透過原 `sequenceNumber` 重送 Hold API 解除(冪等回傳同結果),或透過 Refund API(若已轉扣款)。

---

## 4. 查詢 API

**URL** : `/CoreAccount/{partyId}/Query/Execute`
**Method** : `POST`
**說明** : 查詢客戶帳戶餘額或單筆交易狀態,用於輔助與未知狀態查詢

### 4.1 查詢模式

| `queryType` | 用途 |
|---|---|
| `BALANCE` | 查帳戶餘額 |
| `TRANSACTION_STATUS` | 依 sequenceNumber 查交易狀態 |

### 4.2 Request 參數 (BALANCE)

| 參數名 | 類型 | 必填 | 說明 |
| --- | --- | --- | --- |
| partyId | `string` | ✓ | 客戶統編(URL path) |
| queryType | `string` | ✓ | `BALANCE` |
| account | `string` | ✓ | 查詢帳號 |
| currency | `string` | ✗ | 指定幣別(不填則回所有幣別) |

### 4.3 Request 範例 (BALANCE)

```json
{
    "queryType": "BALANCE",
    "account": "0012345678901"
}
```

### 4.4 Success Response (BALANCE)

```json
{
    "track_id": "q1q2q3q4q5q6q7q8q9q0q1q2",
    "status": 0,
    "errors": null,
    "result": {
        "partyId": "A123456789",
        "balances": [
            { "currency": "TWD", "amount": "0009876543210", "availableAmount": "0009876542210" },
            { "currency": "USD", "amount": "000001234500", "availableAmount": "000001234500" }
        ]
    }
}
```

### 4.5 Request 參數 (TRANSACTION_STATUS)

| 參數名 | 類型 | 必填 | 說明 |
| --- | --- | --- | --- |
| partyId | `string` | ✓ | 客戶統編(URL path) |
| queryType | `string` | ✓ | `TRANSACTION_STATUS` |
| sequenceNumber | `string` | ✓ | 欲查詢的 sequenceNumber |

### 4.6 Success Response (TRANSACTION_STATUS)

```json
{
    "track_id": "q3q4q5q6q7q8q9q0q1q2q3q4",
    "status": 0,
    "errors": null,
    "result": {
        "partyId": "A123456789",
        "sequenceNumber": "CR_A1234567890000015061655",
        "transactionStatus": "SUCCESS",
        "operationType": "A",
        "currency": "TWD",
        "amount": "0000011758",
        "feeAmount": "0000000030",
        "totalAmount": "0000011788",
        "postedAt": "20260907150617"
    }
}
```

---

## 5. 冪等性契約

| 代號 | 規則 |
|---|---|
| **CA-IDM-01** | 同 `sequenceNumber` 重送 Debit,回傳同結果(不重複扣款) |
| **CA-IDM-02** | 同 `sequenceNumber` 重送 Refund,回傳同結果(不重複退款) |
| **CA-IDM-03** | Refund 的 `originalSequenceNumber` 必須對應一筆 `SUCCESS` 狀態的扣款 |
| **CA-IDM-04** | Hold 可重送,重送視為「解除圈存」(若尚未轉扣款) |

---

## 6. 錯誤碼總表

| error_code | 訊息 | HTTP | 業務處理 |
|---|---|---|---|
| E0011 | 帳戶餘額不足 | 200 | FAILED |
| E0012 | 帳戶已凍結 | 200 | FAILED |
| E0013 | 帳戶不存在 | 200 | FAILED |
| E0021 | 單筆金額超過限額 | 200 | FAILED |
| E0022 | 當日累計超過限額 | 200 | FAILED |
| E0023 | 查無資料 | 200 | FAILED |
| E0031 | 原交易已退款 | 200 | 視為冪等成功 |
| E0032 | 原交易未找到 | 200 | FAILED |
| E0033 | 原交易非 SUCCESS 狀態,不可退款 | 200 | ROLLBACK_FAILED |
| E0040 | 圈存已存在 | 200 | 視為冪等成功 |
| E0041 | 圈存已解除 | 200 | 視為冪等成功 |
| E0050 | 系統錯誤 | 500 | timeout 處理 |
| E0051 | 通訊逾時 | 500 | timeout 處理 |
