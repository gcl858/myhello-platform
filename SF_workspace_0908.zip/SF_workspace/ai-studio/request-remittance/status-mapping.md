# Parent 對外狀態 ↔ Child 內部狀態對映表

**ver.** : `1.0`
**對應業務需求書** : `remittance-requirement.md` v1.0 §5

> 本文件定義 Parent 對外回報狀態與 Child 內部狀態的對映關係,作為 Parent 統一回應層的單一真相來源(SSOT)。

---

## 0. 對映總表

| # | Parent 對外狀態 | Child 內部來源 | HTTP | 出現頻率 |
|---|---|---|---|---|
| 1 | `SUCCESS` | WF-A: `INIT → CORE_PENDING → CORE_SUCCESS → AML_PENDING → AML_SUCCESS → DOMESTIC_PENDING → SUCCESS` | 200 | 高 |
| 2 | `SWIFT_PENDING` | WF-B: `INIT → CORE_PENDING → CORE_SUCCESS → AML_PENDING → AML_SUCCESS → SWIFT_PENDING_SEND → SWIFT_PENDING_ACK` | 200 | 高 |
| 3 | `SUCCESS_AFTER_ACK` | WF-B: `... → SWIFT_PENDING_ACK → FX_PENDING → SUCCESS` | 200 | 高 |
| 4 | `FAILED` | WF-A 或 WF-B 階段 1 (Core) 失敗 | 200 | 中 |
| 5 | `AML_REJECTED` | WF-A 或 WF-B 階段 2 (AML) 命中 | 200 | 中 |
| 6 | `ROLLED_BACK` | WF-A 階段 3 (Domestic Clearing) 失敗 + Core 退款成功 | 200 | 中 |
| 7 | `SWIFT_ROLLED_BACK` | WF-B 階段 3 (SWIFT) 失敗 + Core 退款成功 + SWIFT 取消成功 | 200 | 中 |
| 8 | `FX_REPORT_FAILED` | WF-B 階段 4 (FX Reporting) 失敗,但 SWIFT 已成功 | 200 | 低 |
| 9 | `CANCELLED` | WF-C 全階段成功 | 200 | 中 |
| 10 | `CANCEL_REJECTED` | WF-C 預檢不通過 | 200 | 中 |
| 11 | `CANCEL_FAILED` | WF-C 階段 2 (Core 退款) 失敗 | 200 | 低 |
| 12 | `CANCEL_ROLLED_BACK` | WF-C 部分失敗但內部補償成功 | 200 | 低 |
| 13 | `REJECTED_VALIDATION` | Parent 輸入驗證失敗 | 400 | 高 |
| 14 | `LOOKUP_FAILED` | WF-C 查原交易失敗 | 500 | 低 |
| 15 | `ROLLBACK_FAILED` | WF-A 階段 3 失敗但 Core 退款也失敗 | 409 | 極低 |
| 16 | `SWIFT_ROLLBACK_FAILED` | WF-B 階段 3 失敗 + 退款失敗 + SWIFT 取消失敗 | 409 | 極低 |
| 17 | `AML_REJECTED_ROLLBACK_FAILED` | AML 命中但 Core 退款失敗 | 409 | 極低 |
| 18 | `CANCEL_ROLLBACK_FAILED` | WF-C 階段 3 失敗且自身階段 2 補償也失敗 | 409 | 極低 |
| 19 | `IDEMPOTENT_REPLAY` | Parent 冪等性檢查命中 | 200 | 中 |

---

## 1. WF-A (Domestic Remittance) 內部狀態 → Parent 對外狀態

| Child 內部狀態 | Parent 對外狀態 | HTTP | 客戶端動作 |
|---|---|---|---|
| `INIT` | (中間態,不對外回報) | — | — |
| `CORE_PENDING` | (中間態) | — | — |
| `CORE_SUCCESS` | (中間態) | — | — |
| `AML_PENDING` | (中間態) | — | — |
| `AML_SUCCESS` | (中間態) | — | — |
| `DOMESTIC_PENDING` | (中間態) | — | — |
| `SUCCESS` | `SUCCESS` | 200 | 開立匯款收據 |
| `CORE_FAILED` | `FAILED` | 200 | 「款項未匯出」,不補償 |
| `AML_REJECTED`(退款成功) | `AML_REJECTED` | 200 | 「因合規因素拒絕」,退款已退回 |
| `AML_REJECTED`(退款失敗) | `AML_REJECTED_ROLLBACK_FAILED` | 409 | 通知分行主管 + AML Officer |
| `DOMESTIC_ROLLBACK_PENDING` | (中間態) | — | — |
| `ROLLED_BACK` | `ROLLED_BACK` | 200 | 「已退款」,結束 |
| `DOMESTIC_ROLLBACK_FAILED` | `ROLLBACK_FAILED` | 409 | 通知分行主管 + 監控中心 |

### 1.1 WF-A 內部狀態機

```
INIT
  ↓
CORE_PENDING ─(失敗)─→ CORE_FAILED
  │(成功)
  ↓
CORE_SUCCESS
  ↓
AML_PENDING ─(命中)─→ AML_REJECTED
  │(通過)               ├─(退款成功)─→ AML_REJECTED
  ↓                     └─(退款失敗)─→ AML_REJECTED_ROLLBACK_FAILED
AML_SUCCESS
  ↓
DOMESTIC_PENDING ─(失敗)─→ DOMESTIC_ROLLBACK_PENDING
  │(成功)                  ├─(退款成功)─→ ROLLED_BACK
  ↓                        └─(退款失敗)─→ DOMESTIC_ROLLBACK_FAILED
SUCCESS
```

---

## 2. WF-B (SWIFT Remittance) 內部狀態 → Parent 對外狀態

| Child 內部狀態 | Parent 對外狀態 | HTTP | 客戶端動作 |
|---|---|---|---|
| `INIT` | (中間態) | — | — |
| `CORE_PENDING` | (中間態) | — | — |
| `CORE_SUCCESS` | (中間態) | — | — |
| `AML_PENDING` | (中間態) | — | — |
| `AML_SUCCESS` | (中間態) | — | — |
| `SWIFT_PENDING_SEND` | (中間態) | — | — |
| `SWIFT_PENDING_ACK` | `SWIFT_PENDING` | 200 | 「已匯出,等待對方確認」 |
| `FX_PENDING` | (中間態) | — | — |
| `SUCCESS` | `SUCCESS_AFTER_ACK` | 200 | 開立匯款收據 |
| `CORE_FAILED` | `FAILED` | 200 | 「款項未匯出」,不補償 |
| `AML_REJECTED`(退款成功) | `AML_REJECTED` | 200 | 「因合規因素拒絕」 |
| `AML_REJECTED`(退款失敗) | `AML_REJECTED_ROLLBACK_FAILED` | 409 | 通知分行主管 + AML Officer |
| `SWIFT_SEND_FAILED` | (進入 SWIFT_ROLLBACK_PENDING) | — | — |
| `SWIFT_ROLLBACK_PENDING` | (中間態) | — | — |
| `SWIFT_ROLLED_BACK`(退款 + SWIFT 取消皆成功) | `SWIFT_ROLLED_BACK` | 200 | 「已退款 + SWIFT 已取消」 |
| `SWIFT_ROLLBACK_FAILED` | `SWIFT_ROLLBACK_FAILED` | 409 | 通知分行主管 + AML Officer |
| `SWIFT_ACK_FAILED`(對方拒絕) | (進入 SWIFT_ROLLBACK_PENDING,需發取消報文) | — | — |
| `FX_REPORT_FAILED` | `FX_REPORT_FAILED` | 200 | 「匯款成功,申報待補」,告警補申報 |

### 2.1 WF-B 內部狀態機

```
INIT
  ↓
CORE_PENDING ─(失敗)─→ CORE_FAILED
  │(成功)
  ↓
CORE_SUCCESS
  ↓
AML_PENDING ─(命中)─→ AML_REJECTED
  │(通過)               ├─(退款成功)─→ AML_REJECTED
  ↓                     └─(退款失敗)─→ AML_REJECTED_ROLLBACK_FAILED
AML_SUCCESS
  ↓
SWIFT_PENDING_SEND ─(失敗)─→ SWIFT_SEND_FAILED
  │(成功)                     ↓
  ↓                     SWIFT_ROLLBACK_PENDING
SWIFT_PENDING_ACK ─(拒絕)─→ SWIFT_ACK_FAILED
  │(成功)                  ↓
  ↓(等待 ack)         SWIFT_ROLLBACK_PENDING
FX_PENDING              ├─(退款成功 + SWIFT取消成功)─→ SWIFT_ROLLED_BACK
  │(成功)               └─(任一失敗)─→ SWIFT_ROLLBACK_FAILED
  ↓
SUCCESS
  ↓
FX_PENDING ─(失敗)─→ FX_REPORT_FAILED(仍視為 SUCCESS_AFTER_ACK)
```

---

## 3. WF-C (Cancellation) 內部狀態 → Parent 對外狀態

| Child 內部狀態 | Parent 對外狀態 | HTTP | 客戶端動作 |
|---|---|---|---|
| `INIT` | (中間態) | — | — |
| `LOOKUP_PENDING` | (中間態) | — | — |
| `LOOKUP_FAILED` | `LOOKUP_FAILED` | 500 | 系統異常,稍後重試 |
| `LOOKUP_REJECTED`(預檢不通過) | `CANCEL_REJECTED` | 200 | 顯示拒絕原因 |
| `CORE_PENDING` | (中間態) | — | — |
| `SWIFT_CANCEL_PENDING`(僅跨境) | (中間態) | — | — |
| `NOTIFY_PENDING`(僅跨境) | (中間態) | — | — |
| `CANCELLED` | `CANCELLED` | 200 | 開立沖銷收據 |
| `CORE_FAILED`(階段 2 失敗) | `CANCEL_FAILED` | 200 | 「沖銷失敗,原交易仍存」 |
| `SWIFT_CANCEL_FAILED`(階段 3 失敗) | (進入 ROLLBACK_PENDING) | — | — |
| `ROLLBACK_PENDING` | (中間態) | — | — |
| `CANCEL_ROLLED_BACK`(自身階段 2 退款回滾成功) | `CANCEL_ROLLED_BACK` | 200 | 「退款回滾成功」 |
| `CANCEL_ROLLBACK_FAILED` | `CANCEL_ROLLBACK_FAILED` | 409 | 通知分行主管 |

### 3.1 WF-C 內部狀態機

```
INIT
  ↓
LOOKUP_PENDING ─(找不到)─→ LOOKUP_FAILED
  │(找到)                  ↑
  ├─(狀態不對)─→ LOOKUP_REJECTED (CANCEL_REJECTED)
  │(通過)
  ↓
CORE_PENDING ─(失敗)─→ CORE_FAILED (CANCEL_FAILED)
  │(成功)
  ├─(原交易為 WF-A)─→ 直接跳至 NOTIFY_PENDING(可選)
  └─(原交易為 WF-B)─→ SWIFT_CANCEL_PENDING
                        ├─(成功)─→ NOTIFY_PENDING
                        │(失敗)─→ ROLLBACK_PENDING
                        │         ├─(階段 2 退款回滾成功)─→ CANCEL_ROLLED_BACK
                        │         └─(階段 2 退款回滾失敗)─→ CANCEL_ROLLBACK_FAILED
NOTIFY_PENDING ─(失敗)─→ CANCELLED(告警補送,仍視為 CANCELLED)
  │(成功)
  ↓
CANCELLED
```

---

## 4. Parent 對外狀態 → 統一回應範例

### 4.1 SUCCESS

```json
{
    "track_id": "vw123456789abcdef",
    "workflow": "DOMESTIC_REMITTANCE",
    "status": 0,
    "finalStatus": "SUCCESS",
    "errors": null,
    "result": {
        "partyId": "A123456789",
        "branchCode": "070",
        "operationType": "A",
        "amount": "0000011758",
        "currency": "TWD",
        "sequenceNumber": "RE_A1234567890000015061655",
        "coreSequence": "CR_A1234567890000015061655",
        "clearingSequence": "DR_A1234567890000015061655"
    }
}
```

### 4.2 SWIFT_PENDING

```json
{
    "track_id": "vw23456789abcdef0",
    "workflow": "SWIFT_REMITTANCE",
    "status": 0,
    "finalStatus": "SWIFT_PENDING",
    "errors": null,
    "result": {
        "partyId": "A123456789",
        "branchCode": "070",
        "operationType": "B",
        "amount": "0000100000",
        "currency": "USD",
        "fxRate": "0000031500",
        "sequenceNumber": "RE_A1234567890000016000000",
        "coreSequence": "CR_A1234567890000016000000",
        "swiftSequence": "SW_A1234567890000016000000",
        "swiftRefNo": "SWIFT20260907BANKUS33XXX000001",
        "expectedAckBy": "20260909000000"
    }
}
```

### 4.3 SUCCESS_AFTER_ACK

```json
{
    "track_id": "vw3456789abcdef01",
    "workflow": "SWIFT_REMITTANCE",
    "status": 0,
    "finalStatus": "SUCCESS_AFTER_ACK",
    "errors": null,
    "result": {
        "partyId": "A123456789",
        "branchCode": "070",
        "operationType": "B",
        "amount": "0000100000",
        "currency": "USD",
        "sequenceNumber": "RE_A1234567890000016000000",
        "coreSequence": "CR_A1234567890000016000000",
        "swiftSequence": "SW_A1234567890000016000000",
        "swiftRefNo": "SWIFT20260907BANKUS33XXX000001",
        "beneficiaryCreditedAt": "20260908094500",
        "fxSequence": "FX_A1234567890000020000000"
    }
}
```

### 4.4 ROLLED_BACK

```json
{
    "track_id": "vw456789abcdef012",
    "workflow": "DOMESTIC_REMITTANCE",
    "status": 0,
    "finalStatus": "ROLLED_BACK",
    "errors": null,
    "result": {
        "partyId": "A123456789",
        "branchCode": "070",
        "operationType": "A",
        "amount": "0000011758",
        "currency": "TWD",
        "sequenceNumber": "RE_A1234567890000015061655",
        "coreSequence": "CR_A1234567890000015061655",
        "rollbackSequence": "CR_R_A1234567890000015300000",
        "rollbackTrackId": "a1b2c3d4e5f6789012345678"
    }
}
```

### 4.5 SWIFT_ROLLED_BACK

```json
{
    "track_id": "vw56789abcdef0123",
    "workflow": "SWIFT_REMITTANCE",
    "status": 0,
    "finalStatus": "SWIFT_ROLLED_BACK",
    "errors": null,
    "result": {
        "partyId": "A123456789",
        "branchCode": "070",
        "operationType": "B",
        "amount": "0000100000",
        "currency": "USD",
        "sequenceNumber": "RE_A1234567890000016000000",
        "coreSequence": "CR_A1234567890000016000000",
        "rollbackSequence": "CR_R_A1234567890000016300000",
        "swiftCancelSequence": "SW_R_A1234567890000016300000"
    }
}
```

### 4.6 AML_REJECTED

```json
{
    "track_id": "vw6789abcdef01234",
    "workflow": "DOMESTIC_REMITTANCE",
    "status": 1,
    "finalStatus": "AML_REJECTED",
    "errors": [
        {
            "error_code": "AML001",
            "message": "命中制裁名單 (OFAC SDN)"
        }
    ],
    "result": {
        "partyId": "A123456789",
        "branchCode": "070",
        "operationType": "A",
        "amount": "0000011758",
        "currency": "TWD",
        "sequenceNumber": "RE_A1234567890000015061655",
        "coreSequence": "CR_A1234567890000015061655",
        "rollbackSequence": "CR_R_A1234567890000015062000",
        "amlHitList": "OFAC SDN"
    }
}
```

### 4.7 CANCELLED

```json
{
    "track_id": "vw789abcdef012345",
    "workflow": "CANCELLATION",
    "status": 0,
    "finalStatus": "CANCELLED",
    "errors": null,
    "result": {
        "partyId": "A123456789",
        "branchCode": "070",
        "operationType": "C",
        "amount": "0000100000",
        "currency": "USD",
        "sequenceNumber": "RE_A1234567890000017000000",
        "originalSequenceNumber": "RE_A1234567890000016000000",
        "cancellationReason": "TELLER_MISTAKE",
        "coreSequence": "CR_R_A1234567890000017000000",
        "swiftCancelSequence": "SW_R_A1234567890000017000000"
    }
}
```

### 4.8 REJECTED_VALIDATION

```json
{
    "track_id": "vw89abcdef0123456",
    "workflow": null,
    "status": 1,
    "finalStatus": "REJECTED_VALIDATION",
    "errors": [
        {
            "error_code": "VAL002",
            "message": "operationType=A 不可填 originalSequenceNumber"
        }
    ],
    "result": null
}
```

### 4.9 ROLLBACK_FAILED

```json
{
    "track_id": "vw9abcdef01234567",
    "workflow": "DOMESTIC_REMITTANCE",
    "status": 1,
    "finalStatus": "ROLLBACK_FAILED",
    "errors": [
        {
            "error_code": "DC007",
            "message": "扣款成功但通匯失敗,退款也失敗,需人工處理"
        }
    ],
    "result": {
        "partyId": "A123456789",
        "branchCode": "070",
        "operationType": "A",
        "amount": "0000011758",
        "currency": "TWD",
        "sequenceNumber": "RE_A1234567890000015061655",
        "coreSequence": "CR_A1234567890000015061655",
        "clearingSequence": "DR_A1234567890000015061655"
    }
}
```

### 4.10 IDEMPOTENT_REPLAY

```json
{
    "track_id": "vwabcdef0123456789",
    "workflow": "DOMESTIC_REMITTANCE",
    "status": 0,
    "finalStatus": "IDEMPOTENT_REPLAY",
    "errors": null,
    "result": {
        "partyId": "A123456789",
        "branchCode": "070",
        "operationType": "A",
        "amount": "0000011758",
        "currency": "TWD",
        "sequenceNumber": "RE_A1234567890000015061655",
        "originalFinalStatus": "SUCCESS",
        "originalResult": { ... }  // 完整重現第一次的 result
    }
}
```

---

## 5. 狀態對映的設計原則

### 5.1 中間態不外洩

任何 Child 的中間態(`CORE_PENDING`、`AML_PENDING`、`DOMESTIC_PENDING`、`FX_PENDING`、`LOOKUP_PENDING`、`NOTIFY_PENDING` 等)**不對外回報**,僅在 AuditLog 中記錄。

### 5.2 終態統一為 Parent 對外狀態

不論 Child 內部如何走,Parent 對外只回報 19 個對外狀態之一(`§0` 列出的全部)。

### 5.3 失敗狀態區分業務/系統

| 失敗類型 | HTTP | Parent 對外狀態 |
|---|---|---|
| 業務拒絕(status=1, http=200) | 200 | `FAILED` / `AML_REJECTED` / `CANCEL_REJECTED` |
| 系統錯誤(http=5xx) | 200(業務已成功但失敗) | `ROLLED_BACK` / `SWIFT_ROLLED_BACK` |
| 補償失敗 | 409 | `ROLLBACK_FAILED` / `SWIFT_ROLLBACK_FAILED` |
| 找不到資源 | 500 | `LOOKUP_FAILED` |
| 輸入錯誤 | 400 | `REJECTED_VALIDATION` |

### 5.4 跨境特有的中間態

`SWIFT_PENDING` 是**唯一對外暴露的中間態**,因為:
- 跨境匯款需等待對方 ack(可能 1-2 個工作天)
- 客戶需要知道「款項已匯出但對方尚未確認」
- 業務上 `SWIFT_PENDING` 視為「半成功」

---

## 6. 對外狀態的客戶端處理建議

| Parent 對外狀態 | 客戶端 UI 顯示 | 客戶端動作 |
|---|---|---|
| `SUCCESS` / `SUCCESS_AFTER_ACK` | 「匯款成功」 | 開立收據 |
| `SWIFT_PENDING` | 「已匯出,等待對方確認 (預計 1-2 工作天)」 | 開立暫存收據,告知客戶查詢 |
| `FAILED` | 「款項未匯出」 | 無收據,顯示原因 |
| `AML_REJECTED` | 「因合規因素拒絕,款項已退回」 | 顯示退款金額 |
| `ROLLED_BACK` / `SWIFT_ROLLED_BACK` | 「已退款,匯款失敗」 | 無收據,顯示退款金額 |
| `FX_REPORT_FAILED` | 「匯款成功,申報待補」 | 開立收據,告知客戶已成功 |
| `CANCELLED` | 「沖銷成功,款項已退回」 | 開立沖銷收據 |
| `CANCEL_REJECTED` | 「無法沖銷」 | 顯示原因(原交易狀態不對等) |
| `CANCEL_FAILED` | 「沖銷失敗,原交易仍存」 | 告知客戶可重試或人工處理 |
| `CANCEL_ROLLED_BACK` | 「沖銷部分失敗,已回滾」 | 顯示退款金額 |
| `REJECTED_VALIDATION` | 「輸入錯誤」 | 修正輸入 |
| `LOOKUP_FAILED` | 「系統異常」 | 稍後重試 |
| `ROLLBACK_FAILED` / `SWIFT_ROLLBACK_FAILED` | 「處理中,將通知分行主管」 | 等待人工處理 |
| `AML_REJECTED_ROLLBACK_FAILED` | 「合規拒絕,但退款失敗」 | 等待人工處理 |
| `CANCEL_ROLLBACK_FAILED` | 「沖銷失敗,需人工處理」 | 等待人工處理 |
| `IDEMPOTENT_REPLAY` | (同原結果) | (同原結果) |
