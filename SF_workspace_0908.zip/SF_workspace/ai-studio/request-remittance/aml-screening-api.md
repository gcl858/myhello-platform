# AML 制裁名單篩查 API

**ver.** : `1.0`
**主機名稱** : AML / Sanctions Screening Host
**通訊方式** : API
**訊息格式** : JSON (UTF-8)
**對應業務需求書** : `remittance-requirement.md` v1.0 §4.1.3、§4.2.1、BR-P08

> 本主機負責所有合規篩查作業,涵蓋客戶統編、受款人姓名/統編、交易特徵三個維度。所有 3 個端點由 Parent 的 Child Workflow (WF-A 階段 2、WF-B 階段 2) 呼叫。

---

## 0. 端點清單

| # | 端點 | 用途 | 觸發 workflow 階段 |
|---|---|---|---|
| 1 | `POST /AML/Party/Screen/Execute` | 客戶統編黑名單(含制裁、PEP) | WF-A 階段 2、WF-B 階段 2 |
| 2 | `POST /AML/Beneficiary/Screen/Execute` | 受款人姓名/統編黑名單 | WF-A 階段 2、WF-B 階段 2 |
| 3 | `POST /AML/Transaction/Check/Execute` | 交易特徵檢查(大額、可疑) | WF-B 階段 2(觸發大額申報) |

---

## 1. 客戶統編篩查 API

**URL** : `/AML/Party/Screen/Execute`
**Method** : `POST`
**說明** : 檢查匯款客戶(remitter)是否在制裁名單、PEP(政治人物)名單、內部黑名單

### 1.1 Request 參數

| 參數名 | 類型 | 必填 | 說明 |
| --- | --- | --- | --- |
| partyId | `string` | ✓ | 客戶統編 |
| partyName | `string` | ✓ | 客戶姓名/公司名稱 |
| partyType | `string` | ✓ | `INDIVIDUAL` / `CORPORATE` |
| nationality | `string` | ✗ | 國籍(ISO 3166-1 alpha-3) |
| birthDate | `string` | ✗ | 出生年月日(YYYYMMDD,個人必填) |
| screenScope | `array<string>` | ✓ | 篩查範圍:`SANCTIONS` / `PEP` / `INTERNAL_BLACKLIST` / `ADVERSE_MEDIA` |
| transactionDate | `string` | ✓ | 交易日期 |
| sequenceNumber | `string` | ✓ | 篩查序號(prefix `AM_` + 19 碼,共 22 字元) |

### 1.2 Request 範例

```json
{
    "partyId": "A123456789",
    "partyName": "陳大文",
    "partyType": "INDIVIDUAL",
    "nationality": "TWN",
    "birthDate": "19800101",
    "screenScope": ["SANCTIONS", "PEP", "INTERNAL_BLACKLIST"],
    "transactionDate": "20260907",
    "sequenceNumber": "AM_A1234567890000015061655"
}
```

### 1.3 Success Response (通過)

```json
{
    "track_id": "am1am2am3am4am5am6am7am8am9",
    "status": 0,
    "errors": null,
    "result": {
        "partyId": "A123456789",
        "screenResult": "CLEAR",
        "hitLists": [],
        "score": 0,
        "sequenceNumber": "AM_A1234567890000015061655",
        "screenedAt": "20260907150620"
    }
}
```

### 1.4 Success Response (命中)

```json
{
    "track_id": "am1am2am3am4am5am6am7am8am9",
    "status": 1,
    "errors": [
        {
            "error_code": "AML001",
            "message": "命中制裁名單 (OFAC SDN)"
        }
    ],
    "result": {
        "partyId": "A123456789",
        "screenResult": "HIT",
        "hitLists": [
            {
                "listName": "OFAC SDN",
                "matchScore": 95,
                "matchedName": "CHEN TA-WEN",
                "listEntryId": "OFAC-SDN-12345",
                "addedAt": "20240101"
            }
        ],
        "score": 95,
        "sequenceNumber": "AM_A1234567890000015061655",
        "screenedAt": "20260907150620"
    }
}
```

> **注意**: AML 主機的命中回傳使用 `status=1`(業務拒絕),HTTP 仍為 200。這對齊 credit-card 範例的「業務拒絕」契約。

### 1.5 常見錯誤代碼

| error_code | 訊息 | 業務處理 |
|---|---|---|
| AML001 | 命中制裁名單 | AML_REJECTED,Parent 觸發退款 |
| AML002 | 命中 PEP 名單(政治人物) | 視為通過但加註;高風險時升級為 AML_REJECTED |
| AML003 | 命中內部黑名單 | AML_REJECTED |
| AML004 | 命中負面媒體 | 視為通過但加註 |
| AML999 | AML 系統錯誤 | 視為 timeout,Parent 啟動未知狀態查詢 |

---

## 2. 受款人篩查 API

**URL** : `/AML/Beneficiary/Screen/Execute`
**Method** : `POST`
**說明** : 檢查受款人是否在制裁名單、PEP 名單;跨境匯款必填,國內匯款選填

### 2.1 Request 參數

| 參數名 | 類型 | 必填 | 說明 |
| --- | --- | --- | --- |
| partyId | `string` | ✓ | 匯款客戶統編 |
| beneficiaryAccount | `string` | ✓ | 受款人帳號 |
| beneficiaryName | `string` | ✓ | 受款人姓名/公司名稱 |
| beneficiaryCountry | `string` | ✓ | 受款人所在國(ISO 3166-1 alpha-3) |
| beneficiaryType | `string` | ✓ | `INDIVIDUAL` / `CORPORATE` |
| screenScope | `array<string>` | ✓ | 同上 |
| transactionDate | `string` | ✓ | 交易日期 |
| sequenceNumber | `string` | ✓ | 篩查序號(prefix `AM_` + 19 碼,共 22 字元) |

### 2.2 Request 範例

```json
{
    "partyId": "A123456789",
    "beneficiaryAccount": "DE89370400440532013000",
    "beneficiaryName": "Hans Schmidt",
    "beneficiaryCountry": "DEU",
    "beneficiaryType": "INDIVIDUAL",
    "screenScope": ["SANCTIONS", "PEP", "INTERNAL_BLACKLIST"],
    "transactionDate": "20260907",
    "sequenceNumber": "AM_A1234567890000015061700"
}
```

### 2.3 Success Response (通過)

```json
{
    "track_id": "bm1bm2bm3bm4bm5bm6bm7bm8bm9",
    "status": 0,
    "errors": null,
    "result": {
        "beneficiaryAccount": "DE89370400440532013000",
        "screenResult": "CLEAR",
        "hitLists": [],
        "score": 0,
        "sequenceNumber": "AM_A1234567890000015061700",
        "screenedAt": "20260907150621"
    }
}
```

### 2.4 Success Response (命中)

```json
{
    "track_id": "bm1bm2bm3bm4bm5bm6bm7bm8bm9",
    "status": 1,
    "errors": [
        {
            "error_code": "AML005",
            "message": "受款人命中制裁國家 (IRN)"
        }
    ],
    "result": {
        "beneficiaryAccount": "DE89370400440532013000",
        "screenResult": "HIT",
        "hitLists": [
            {
                "listName": "OFAC COUNTRY SANCTIONS",
                "matchScore": 100,
                "matchedName": "IRAN",
                "listEntryId": "OFAC-IRN",
                "addedAt": "19790101"
            }
        ],
        "score": 100,
        "sequenceNumber": "AM_A1234567890000015061700",
        "screenedAt": "20260907150621"
    }
}
```

### 2.5 常見錯誤代碼

| error_code | 訊息 | 業務處理 |
|---|---|---|
| AML001 | 受款人命中制裁名單 | AML_REJECTED |
| AML005 | 受款人命中制裁國家 | AML_REJECTED |
| AML006 | 受款人命中 PEP 名單 | 視為通過但加註 |
| AML007 | 受款人姓名模糊命中,需人工覆核 | AML_REJECTED(本版 v1.0 嚴格政策) |
| AML999 | AML 系統錯誤 | timeout 處理 |

---

## 3. 交易特徵檢查 API

**URL** : `/AML/Transaction/Check/Execute`
**Method** : `POST`
**說明** : 依交易金額、匯款性質、目的地國家等特徵,判斷是否觸發大額申報、可疑交易通報

### 3.1 Request 參數

| 參數名 | 類型 | 必填 | 說明 |
| --- | --- | --- | --- |
| partyId | `string` | ✓ | 客戶統編 |
| currency | `string` | ✓ | 交易幣別 |
| amount | `string` | ✓ | 交易金額(原幣,單位:分) |
| amountInUSD | `string` | ✓ | 等值美元金額(由 Parent 計算後傳入) |
| purposeCode | `string` | ✓ | 匯款性質分類 |
| beneficiaryCountry | `string` | ✓ | 受款人國家 |
| isCrossBorder | `boolean` | ✓ | 是否跨境 |
| paymentSourceCode | `string` | ✓ | 繳款來源碼 |
| transactionDate | `string` | ✓ | 交易日期 |
| sequenceNumber | `string` | ✓ | 篩查序號(prefix `AM_` + 19 碼,共 22 字元) |

### 3.2 大額申報門檻

| 條件 | 申報類型 |
|---|---|
| 單筆 ≥ 等值 USD 50,000 | 大額申報(Large Transaction Report) |
| 當日累計 ≥ 等值 USD 50,000(同客戶) | 累計大額申報 |
| 單筆 ≥ 等值 USD 10,000 流向高風險國家 | 強化審查(Enhanced Due Diligence) |
| 可疑交易特徵(如分散匯出、剛開戶即大額) | 可疑交易報告(Suspicious Transaction Report) |

### 3.3 Request 範例

```json
{
    "partyId": "A123456789",
    "currency": "USD",
    "amount": "0000100000",
    "amountInUSD": "0000100000",
    "purposeCode": "10100",
    "beneficiaryCountry": "DEU",
    "isCrossBorder": true,
    "paymentSourceCode": "2500P",
    "transactionDate": "20260907",
    "sequenceNumber": "AM_A1234567890000015061750"
}
```

### 3.4 Success Response

```json
{
    "track_id": "tc1tc2tc3tc4tc5tc6tc7tc8tc9",
    "status": 0,
    "errors": null,
    "result": {
        "checkResult": "REPORT_REQUIRED",
        "reportTypes": ["LARGE_TRANSACTION"],
        "hitLists": [],
        "score": 0,
        "amountInUSD": "0000100000",
        "sequenceNumber": "AM_A1234567890000015061750",
        "checkedAt": "20260907150622"
    }
}
```

### 3.5 checkResult 種類

| checkResult | 業務處理 |
|---|---|
| `CLEAR` | 不需申報,Parent 視為通過 |
| `REPORT_REQUIRED` | 需申報,Parent 呼叫 FX Report 端點 |
| `ENHANCED_DD_REQUIRED` | 需強化審查,Parent 告警但仍繼續流程 |
| `SUSPICIOUS_REPORT` | 可疑交易,Parent 告警 AML Officer |
| `BLOCKED` | 阻斷,Parent 視為 AML_REJECTED |

### 3.6 常見錯誤代碼

| error_code | 訊息 | 業務處理 |
|---|---|---|
| AML010 | 超過大額申報門檻,需申報 | REPORT_REQUIRED |
| AML011 | 命中高風險國家,需強化審查 | ENHANCED_DD_REQUIRED |
| AML012 | 觸發可疑交易特徵 | SUSPICIOUS_REPORT |
| AML013 | 阻斷(制裁國家/黑名單) | BLOCKED → AML_REJECTED |
| AML999 | AML 系統錯誤 | timeout 處理 |

---

## 4. 冪等性契約

| 代號 | 規則 |
|---|---|
| **AML-IDM-01** | 同 `sequenceNumber` 重送 Party Screen,回傳同結果 |
| **AML-IDM-02** | 同 `sequenceNumber` 重送 Beneficiary Screen,回傳同結果 |
| **AML-IDM-03** | 同 `sequenceNumber` 重送 Transaction Check,回傳同結果 |
| **AML-IDM-04** | 篩查結果快取 24 小時,避免重複查詢 |

---

## 5. 國家/地區風險分級(供受款人篩查參考)

| 風險等級 | 國家/地區範例 | 業務處理 |
|---|---|---|
| 高風險 | IRN(伊朗)、PRK(北韓)、SYR(敘利亞)等 | BLOCKED,直接 AML_REJECTED |
| 加強審查 | RUS(俄羅斯)、MMR(緬甸)、AFG(阿富汗)等 | ENHANCED_DD_REQUIRED |
| 一般 | 其他國家 | 標準流程 |

---

## 6. 錯誤碼總表

| error_code | 訊息 | HTTP | 業務處理 |
|---|---|---|---|
| AML001 | 命中制裁名單 | 200 | AML_REJECTED |
| AML002 | 命中 PEP 名單 | 200 | 視情況通過/拒絕 |
| AML003 | 命中內部黑名單 | 200 | AML_REJECTED |
| AML004 | 命中負面媒體 | 200 | 加註後通過 |
| AML005 | 受款人命中制裁國家 | 200 | AML_REJECTED |
| AML006 | 受款人命中 PEP | 200 | 視情況通過/拒絕 |
| AML007 | 受款人姓名模糊命中 | 200 | AML_REJECTED |
| AML010 | 超過大額申報門檻 | 200 | REPORT_REQUIRED |
| AML011 | 命中高風險國家 | 200 | ENHANCED_DD_REQUIRED |
| AML012 | 觸發可疑交易特徵 | 200 | SUSPICIOUS_REPORT |
| AML013 | 阻斷 | 200 | AML_REJECTED |
| AML999 | AML 系統錯誤 | 500 | timeout 處理 |
