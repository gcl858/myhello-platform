# Operation Type Dispatcher 決策表

**ver.** : `1.0`
**對應業務需求書** : `remittance-requirement.md` v1.0 §4.0.3、BR-P02
**對應 API 入口** : `POST /Omni/{partyId}/Remittance/Execute`

> 本文件定義 Parent Workflow 的 `operationType` 路由邏輯,作為 Parent 內 dispatcher 節點的單一真相來源(SSOT)。

---

## 0. 路由總表

| `operationType` | 業務語意 | 路由 Child | 必填額外欄位 | 不可填欄位 | HTTP 失敗 |
|---|---|---|---|---|---|
| `A` | 國內跨行匯出 | WF-A (Domestic Remittance) | 無 | `originalSequenceNumber`, `cancellationReason`, `currency`(非 TWD), `fxRate`, `beneficiaryBankBIC`, `purposeCode` | 400 |
| `B` | 跨境 SWIFT 匯出 | WF-B (SWIFT Remittance) | `currency`, `fxRate`, `beneficiaryBankBIC`, `purposeCode` | `originalSequenceNumber`, `cancellationReason` | 400 |
| `C` | 反向沖銷 | WF-C (Cancellation) | `originalSequenceNumber`, `cancellationReason` | `currency`(非 TWD), `fxRate`, `beneficiaryBankBIC`, `purposeCode` | 400 |
| 其他值 (D, E, F, ..., 1, 2, 3, ...) | — | — | — | — | 400 |

---

## 1. WF-A (operationType=A) 完整規則

### 1.1 必填欄位(13 個)

| # | 欄位 | 規格 |
|---|---|---|
| 1 | `partyId` | 客戶統編 |
| 2 | `branchCode` | 3 碼分行代號 |
| 3 | `transactionDate` | YYYYMMDD |
| 4 | `transactionDateTime` | HHMMSSxx |
| 5 | `postingDayType` | A=本日 / B=次日 |
| 6 | `postingDate` | YYYYMMDD |
| 7 | `paymentSourceCode` | 見 `coresystem-account-api.md` §1.2 |
| 8 | `operationType` | 固定 `A` |
| 9 | `amount` | 13 字元,左補零 |
| 10 | `currency` | **TWD**(其他值 REJECTED_VALIDATION) |
| 11 | `beneficiaryAccount` | 受款人帳號(15 碼) |
| 12 | `beneficiaryName` | 受款人姓名 |
| 13 | `sequenceNumber` | 22 字元(3 碼 prefix + 19 碼業務序號) |

### 1.2 選填欄位

| # | 欄位 | 規格 |
|---|---|---|
| 1 | `purposeCode` | 國內匯款可選填(如 11000=私人匯款) |
| 2 | `memo` | 給受款人的備註 |
| 3 | `fxRate` | TWD 固定為 1,可填可不填 |

### 1.3 不可填欄位

| 欄位 | 拒絕原因 |
|---|---|
| `originalSequenceNumber` | WF-A 無沖銷行為 |
| `cancellationReason` | 同上 |
| `currency` ≠ `TWD` | WF-A 僅支援台幣;跨境請用 operationType=B |
| `fxRate` ≠ `1` | 同上 |
| `beneficiaryBankBIC` | 國內匯款只需 bankCode(3 碼),用 `beneficiaryAccount` 前 3 碼識別 |

### 1.4 驗證流程

```
收到 API 請求
    ↓
檢查 operationType == "A"
    ├─ 否 → 路由至對應處理
    └─ 是 ↓
檢查必填 13 欄位
    ├─ 缺漏 → REJECTED_VALIDATION (400)
    └─ 齊全 ↓
檢查不可填欄位為 null
    ├─ 有值 → REJECTED_VALIDATION (400)
    └─ 為空 ↓
檢查 currency == "TWD"
    ├─ 否 → REJECTED_VALIDATION (400)
    └─ 是 ↓
    ↓
路由至 WF-A
```

---

## 2. WF-B (operationType=B) 完整規則

### 2.1 必填欄位(17 個)

| # | 欄位 | 規格 |
|---|---|---|
| 1 | `partyId` | 客戶統編 |
| 2 | `branchCode` | 3 碼分行代號 |
| 3 | `transactionDate` | YYYYMMDD |
| 4 | `transactionDateTime` | HHMMSSxx |
| 5 | `postingDayType` | A=本日 / B=次日 |
| 6 | `postingDate` | YYYYMMDD |
| 7 | `paymentSourceCode` | 見 `coresystem-account-api.md` §1.2 |
| 8 | `operationType` | 固定 `B` |
| 9 | `amount` | 13 字元,左補零 |
| 10 | `currency` | **非 TWD**(ISO 4217,如 USD/JPY/EUR) |
| 11 | `fxRate` | 牌告匯率(9 字元,如 31.50 → 0000031500) |
| 12 | `beneficiaryAccount` | 受款人帳號(IBAN 或一般帳號) |
| 13 | `beneficiaryName` | 受款人姓名(**英文**,與護照一致) |
| 14 | `beneficiaryBankBIC` | 受款行 BIC(如 DEUTDEFFXXX,11 字元) |
| 15 | `purposeCode` | 央行規定代號(見下方) |
| 16 | `beneficiaryAddress` | 受款人地址(英文) — 選填但強烈建議 |
| 17 | `sequenceNumber` | 22 字元 |

### 2.2 選填欄位

| # | 欄位 | 規格 |
|---|---|---|
| 1 | `correspondentBIC` | 中間行 BIC(若需中間行) |
| 2 | `remittanceInfo` | 匯款資訊(給受款人看的備註) |
| 3 | `detailOfCharges` | OUR / BEN / SHA(預設 OUR) |

### 2.3 不可填欄位

| 欄位 | 拒絕原因 |
|---|---|
| `originalSequenceNumber` | WF-B 無沖銷行為 |
| `cancellationReason` | 同上 |
| `currency` == `TWD` | TWD 請用 operationType=A |
| `fxRate` 為空或 0 | 跨境必填匯率 |

### 2.4 purposeCode 代號(央行規定)

| 代號 | 說明 |
|---|---|
| 10100 | 貨物貿易出口收匯 |
| 10200 | 貨物貿易進口付匯 |
| 10300 | 服務貿易 |
| 11000 | 私人匯款 |
| 20100 | 直接投資 |
| 20200 | 證券投資 |
| 30100 | 貸款 |
| 40100 | 個人旅遊 |
| 40200 | 公務出差 |
| 50100 | 政府間交易 |
| 99999 | 其他(需審批) |

### 2.5 驗證流程

```
收到 API 請求
    ↓
檢查 operationType == "B"
    ├─ 否 → 路由至對應處理
    └─ 是 ↓
檢查必填 17 欄位
    ├─ 缺漏 → REJECTED_VALIDATION (400)
    └─ 齊全 ↓
檢查不可填欄位為 null
    ├─ 有值 → REJECTED_VALIDATION (400)
    └─ 為空 ↓
檢查 currency != "TWD"
    ├─ 是 TWD → REJECTED_VALIDATION (400)
    └─ 否 ↓
檢查 purposeCode 在央行規定清單內
    ├─ 否 → REJECTED_VALIDATION (400)
    └─ 是 ↓
檢查 amountInUSD(由 Parent 計算) >= 0
    ├─ 否 → REJECTED_VALIDATION (400)
    └─ 是 ↓
    ↓
路由至 WF-B
```

---

## 3. WF-C (operationType=C) 完整規則

### 3.1 必填欄位(15 個)

| # | 欄位 | 規格 |
|---|---|---|
| 1 | `partyId` | 客戶統編(必須與原匯款相同) |
| 2 | `branchCode` | 3 碼分行代號 |
| 3 | `transactionDate` | YYYYMMDD(必須為當日) |
| 4 | `transactionDateTime` | HHMMSSxx |
| 5 | `postingDayType` | A=本日 / B=次日 |
| 6 | `postingDate` | YYYYMMDD |
| 7 | `paymentSourceCode` | 固定 `2500P`(沖銷一律走臨櫃通路) |
| 8 | `operationType` | 固定 `C` |
| 9 | `amount` | 13 字元(同原匯款金額) |
| 10 | `currency` | TWD(若原匯款為跨境,需注意退款金額計算,見 fee-calculation-rules.md) |
| 11 | `beneficiaryAccount` | 同原匯款 |
| 12 | `beneficiaryName` | 同原匯款 |
| 13 | `sequenceNumber` | 22 字元(新序號,不可與原匯款相同) |
| 14 ⭐ | `originalSequenceNumber` | **原匯款的 sequenceNumber** |
| 15 ⭐ | `cancellationReason` | `TELLER_MISTAKE` / `CARDHOLDER_REQUEST` |

### 3.2 選填欄位

| # | 欄位 | 規格 |
|---|---|---|
| 1 | `cancelRemark` | 沖銷備註 |

### 3.3 不可填欄位

| 欄位 | 拒絕原因 |
|---|---|
| `fxRate` | 沖銷不需要新匯率 |
| `beneficiaryBankBIC` | 國內匯款沖銷不需;跨境會透過 SWIFT 取消報文處理 |
| `purposeCode` | 同上 |

### 3.4 預檢條件(於 WF-C 階段 1 Lookup 時檢查)

| 條件 | 規格 |
|---|---|
| 原交易存在 | 用 `originalSequenceNumber` 查 parent row |
| 原交易狀態 | `SUCCESS` 或 `SWIFT_PENDING` |
| 原交易未沖銷 | 原 row 的 `cancelled_by` 為 null |
| 沖銷時機 | 當日內(`transactionDate` 與原交易同日);跨境另需 24 小時內 |
| 發動者 | 同一分行任一授權櫃員 |

### 3.5 驗證流程

```
收到 API 請求
    ↓
檢查 operationType == "C"
    ├─ 否 → 路由至對應處理
    └─ 是 ↓
檢查必填 15 欄位
    ├─ 缺漏 → REJECTED_VALIDATION (400)
    └─ 齊全 ↓
檢查不可填欄位為 null
    ├─ 有值 → REJECTED_VALIDATION (400)
    └─ 為空 ↓
檢查 cancellationReason 為合法值
    ├─ 否 → REJECTED_VALIDATION (400)
    └─ 是 ↓
    ↓
路由至 WF-C,於 Lookup 階段進行預檢
```

---

## 4. 跨 operationType 通用驗證

### 4.1 必填通用欄位(全部 operationType 都必填)

| # | 欄位 | 規格 |
|---|---|---|
| 1 | `partyId` | 客戶統編(10 碼) |
| 2 | `branchCode` | 3 碼分行代號 |
| 3 | `transactionDate` | YYYYMMDD |
| 4 | `transactionDateTime` | HHMMSSxx |
| 5 | `postingDayType` | A=本日 / B=次日 |
| 6 | `postingDate` | YYYYMMDD |
| 7 | `paymentSourceCode` | 見 `coresystem-account-api.md` §1.2 |
| 8 | `operationType` | A/B/C |
| 9 | `sequenceNumber` | 22 字元(3 碼 prefix + 19 碼業務序號) |
| 10 | `tellerId` | 經辦櫃員 ID |
| 11 | `counterNo` | 櫃號 |
| 12 | `terminalId` | 端末機 ID |

### 4.2 業務欄位驗證

| 欄位 | 驗證規則 |
|---|---|
| `partyId` | 10 碼英數字,首字為英文字母 |
| `branchCode` | 3 碼數字,對應分行代號表 |
| `transactionDate` | YYYYMMDD 格式,且 ≤ 系統日 |
| `transactionDateTime` | HHMMSSxx 格式,且 ≤ 系統時間 |
| `postingDate` | YYYYMMDD 格式 |
| `postingDayType=A` | `postingDate` == `transactionDate` |
| `postingDayType=B` | `postingDate` == `transactionDate` + 1 日 |
| `amount` | 13 字元,皆為數字,> 0 |
| `sequenceNumber` | 22 字元,首 3 碼為合法 prefix |

### 4.3 sequenceNumber prefix 規則

| Prefix | 適用 operationType | 說明 |
|---|---|---|
| `RE_` | A | 國內匯款業務序號 |
| `RE_` | B | 跨境匯款業務序號 |
| `RE_` | C | 沖銷業務序號 |

> Parent 生成的對外業務序號統一用 `RE_` prefix;具體主機呼叫的 sequenceNumber 在 child 內加上對應前綴(`CR_` / `AM_` / `DR_` / `SW_` / `FX_`)。

---

## 5. 錯誤回應範例

### 5.1 operationType 無效

```json
{
    "track_id": "vw123456789abcdef",
    "workflow": null,
    "status": 1,
    "finalStatus": "REJECTED_VALIDATION",
    "errors": [
        {
            "error_code": "VAL001",
            "message": "operationType 僅支援 A/B/C"
        }
    ],
    "result": null
}
```

### 5.2 operationType=A 但帶了 originalSequenceNumber

```json
{
    "track_id": "vw23456789abcdef0",
    "workflow": null,
    "status": 1,
    "finalStatus": "REJECTED_VALIDATION",
    "errors": [
        {
            "error_code": "VAL002",
            "message": "operationType=A 不可填 originalSequenceNumber"
        }
    ],
    "result": null
}
```

### 5.3 operationType=B 缺 purposeCode

```json
{
    "track_id": "vw3456789abcdef01",
    "workflow": null,
    "status": 1,
    "finalStatus": "REJECTED_VALIDATION",
    "errors": [
        {
            "error_code": "VAL003",
            "message": "operationType=B 必填 purposeCode"
        }
    ],
    "result": null
}
```

### 5.4 operationType=C 缺 cancellationReason

```json
{
    "track_id": "vw456789abcdef012",
    "workflow": null,
    "status": 1,
    "finalStatus": "REJECTED_VALIDATION",
    "errors": [
        {
            "error_code": "VAL004",
            "message": "operationType=C 必填 cancellationReason"
        }
    ],
    "result": null
}
```

---

## 6. 路由決策流程圖

```
[API POST /Omni/{partyId}/Remittance/Execute]
    ↓
[Parent: 驗證 12 個通用欄位]
    ├─(fail)─→ REJECTED_VALIDATION (400)
    └─(ok)
        ↓
[Parent: 驗證 operationType 範圍]
    ├─(A/B/C)─→ 繼續
    ├─(其他)─→ REJECTED_VALIDATION (400)
    └─(ok)
        ↓
[Parent: 依 operationType 驗證業務欄位]
    ├─(A)─→ 驗證 WF-A 必填/不可填欄位
    ├─(B)─→ 驗證 WF-B 必填/不可填欄位 + purposeCode 合法性
    └─(C)─→ 驗證 WF-C 必填/不可填欄位 + cancellationReason 合法性
        ├─(fail)─→ REJECTED_VALIDATION (400)
        └─(ok)
            ↓
[Parent: 冪等性檢查]
    ├─(hit)─→ IDEMPOTENT_REPLAY (回傳原結果)
    └─(miss)
        ↓
[Parent: Dispatcher]
    ├─(A)─→ 委派 WF-A (Domestic Remittance)
    ├─(B)─→ 委派 WF-B (SWIFT Remittance)
    └─(C)─→ 委派 WF-C (Cancellation)
        ↓
[Child 執行 → 回報 finalStatus]
    ↓
[Parent: 統一回應]
```
