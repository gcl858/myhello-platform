# 臨櫃匯款業務 (國內跨行 + 跨境 SWIFT) — 業務需求文件 v1.0

> 文件版本: v1.0
> 日期: 2026-09-07
> 對應 Host API 規格: `coresystem-account-api.md` / `aml-screening-api.md` / `domestic-clearing-api.md` / `swift-outbound-api.md`
> 對應設計參考: `requirement/credit-card-counter-cash-repayment-requirement.md` v2.2 (Parent Workflow 架構)

---

## 0. 文件目的

從業務方角度,描述臨櫃匯款的完整 workflow 架構:

- **Parent Workflow** (`RemittanceTransaction`): 統一收單、驗證、分派、稽核
- **Child Workflow A** (WF-A, Domestic Remittance): 國內跨行匯款
- **Child Workflow B** (WF-B, SWIFT Remittance): 跨境 SWIFT 電匯
- **Child Workflow C** (WF-C, Cancellation): 沖銷(支援 A 與 B 的反向)

> 註: **ACH 代收代付、外幣現鈔買賣、虛擬帳號收款** 已另案處理,本文件不涵蓋。

---

## 1. 業務背景與痛點

### 1.1 現況

目前臨櫃匯款流程由櫃員於端末機分兩段操作:

```
客戶拿現金/從帳戶扣款到櫃台
    ↓
櫃員輸入匯款資料 (收款人、金額、匯款性質)
    ↓
段一: 扣款作業 (現金或台幣帳戶)
    ↓
段二: 匯出路徑分流
    ├─ 國內跨行 → 端末機呼叫財金通匯
    └─ 跨境 → 端末機呼叫 SWIFT 終端機
    ↓
櫃員開立匯款收據給客戶
```

### 1.2 痛點

- **雙段作業分散** — 扣款與匯出走不同端末機,人工串接易出錯
- **無 AML 統一檢查** — 黑名單、制裁名單、大額申報分散在各端末機設定
- **無統一入口** — 國內匯款與跨境 SWIFT 走不同端點,呼叫端邏輯分散
- **無統一取消機制** — 國內/跨境的沖銷流程不一致,且無標準化反向流程
- **外匯申報脫鉤** — 跨境匯款未自動產生外匯申報資料,需人工補件
- **無對帳軌跡** — 失敗、重試、補償無系統化記錄

### 1.3 目標

- **單一 API 入口**,以 `operationType` 區分國內/跨境/取消
- **統一 AML 篩查**,所有匯款(不論國內或跨境)皆須通過
- **扣款與匯出** 必須保證最終一致(透過 Parent 統一補償)
- **取消流程標準化**,支援國內/跨境的統一沖銷路徑
- **跨境匯款自動產生外匯申報資料**,支援事後補申報

---

## 2. 業務範圍

### 2.1 包含 (In-Scope)

| Workflow 代號 | 名稱 | 觸發情境 |
|---|---|---|
| **Parent** | `RemittanceTransaction` | 統一收單 + 分派 + 稽核 |
| **WF-A** | Domestic Remittance (child) | 櫃員於臨櫃受理客戶國內跨行匯款,執行扣款 + AML + 財金通匯 |
| **WF-B** | SWIFT Remittance (child) | 櫃員於臨櫃受理客戶跨境 SWIFT 電匯,執行扣款 + AML + SWIFT + 外匯申報 |
| **WF-C** | Cancellation (child) | 櫃員當下發現打錯或持卡人反悔,發動對 WF-A 或 WF-B 的反向交易 |

### 2.2 不包含 (Out-of-Scope)

| 項目 | 原因 |
|---|---|
| ACH 代收代付 | 涉及批次媒體檔,需另案設計 |
| 外幣現鈔買賣 | 涉及實體鈔券與庫存,非本文件範圍 |
| 虛擬帳號收款 | 屬於「代收」業務,非本文件範圍 |
| 票據託收 | 屬於「票券」業務,非本文件範圍 |
| 匯入匯款解款 | 屬於「入帳」業務,本文件僅處理匯出 |

---

## 3. 角色與觸發情境

| 角色 | 說明 | 可發動 |
|---|---|---|
| 櫃員 (Teller) | 臨櫃受理客戶匯款 / 取消 | Parent(WF-A)、Parent(WF-B)、Parent(WF-C) |
| 持卡人 / 匯款人 (Remitter) | 臨櫃匯款本人,當場可請求取消 | Parent(WF-C)(由櫃員代發動) |
| AML Officer | 命中黑名單後的覆核 | WF-A 或 WF-B 階段 2 後的 manual override |
| 外匯申報員 (FX Reporter) | 跨境匯款的申報補件 | WF-B 階段 4 失敗後的補申報 |
| 分行主管 (Branch Supervisor) | 例外處理、人工核對 | 任一 *_FAILED 終態後的 manual recovery |
| 監控系統 (Monitoring) | 接收告警 | 訂閱 `vw_..._alerts` |

---

## 4. Parent Workflow 架構 (核心) ⭐ v1.0 重點

### 4.0 整體架構圖

```
┌─────────────────────────────────────────────────────────────────┐
│  API 端點: POST /Omni/{partyId}/Remittance/Execute             │
│  ─────────────────────────────────────────────────────────      │
│  輸入欄位 (15 個,見 §6.2),其中:                                │
│    operationType = A → 執行 WF-A (Domestic Remittance)          │
│    operationType = B → 執行 WF-B (SWIFT Remittance)             │
│    operationType = C → 執行 WF-C (Cancellation)                │
│    其他值 → 400 驗證錯誤                                        │
└─────────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────────┐
│  Parent: RemittanceTransaction                                 │
│  ──────────────────────────                                     │
│  1. 輸入驗證 (15 欄位、必填、operationType 範圍)               │
│  2. 身份/櫃員授權檢查                                            │
│  3. 冪等性檢查 (workflow 級)                                     │
│  4. Dispatcher ─┬─ operationType=A → WF-A (Domestic)            │
│                 ├─ operationType=B → WF-B (SWIFT)               │
│                 └─ operationType=C → WF-C (Cancellation)        │
│  5. 委派執行 (委派給 child workflow)                              │
│  6. 接收 child 回報的 finalStatus                                │
│  7. 統一寫 AuditLog (一個 parent row)                           │
│  8. 統一格式回應 (見 §6.3)                                      │
└─────────────────────────────────────────────────────────────────┘
                              ↓
            ┌─────────────────┬─────────────────┐
            ↓                 ↓                 ↓
   ┌─────────────────┐ ┌─────────────────┐ ┌─────────────────┐
   │ WF-A Domestic   │ │ WF-B SWIFT      │ │ WF-C Cancel     │
   │ (child)         │ │ (child)         │ │ (child)         │
   │                 │ │                 │ │                 │
   │ 階段1: Core     │ │ 階段1: Core     │ │ 階段1: Lookup   │
   │ 階段2: AML      │ │ 階段2: AML      │ │ 階段2: Core退款 │
   │ 階段3: Domestic │ │ 階段3: SWIFT    │ │ 階段3: SWIFT取消│
   │   Clearing      │ │ 階段4: FX申報   │ │   (僅SWIFT)     │
   │                 │ │                 │ │ 階段4: 通知對方 │
   │ 失敗 → Core退款 │ │ 失敗 → Core退款 │ │   (僅SWIFT)     │
   │                 │ │   + SWIFT取消   │ │ 失敗 → 自身補償 │
   └─────────────────┘ └─────────────────┘ └─────────────────┘
```

### 4.0.1 Parent 職責清單

| # | 職責 | 說明 |
|---|---|---|
| P1 | 輸入驗證 | 15 個欄位格式、`operationType` 必須為 A/B/C、業務必填欄位(櫃員、櫃號、端末機) |
| P2 | operationType Dispatcher | 唯一路由決策點,A→WF-A, B→WF-B, C→WF-C |
| P3 | 冪等性檢查 | 依 `sequenceNumber` 檢查,若已存在則回傳同結果(workflow 級冪等,見 §7.4) |
| P4 | 委派執行 | 將控制權交給 child,接收 child 回報的 finalStatus |
| P5 | 統一稽核 | 一筆匯款 = 一個 parent row,所有 child 階段結果寫入同一 row 的欄位 |
| P6 | 統一回應 | 不論 child 為何,API 回應結構一致(見 §6.3) |
| P7 | 補償治理 | 監控 child 回報,若進入 ROLLBACK_PENDING,驅動補償流程 |
| P8 | 告警 | 任何 child 進入 `*_FAILED` 終態,觸發對應告警 |
| P9 | 跨境路由分流 | `operationType=B` 時,依目的地國家分流至 SWIFT 或 ACH 路徑(本版僅 SWIFT) |
| P10 | FX 申報追蹤 | `operationType=B` 時,自動產生外匯申報資料,追蹤申報狀態 |

### 4.0.2 Child 不做的事(由 Parent 負責)

- ❌ 輸入驗證 → Parent 做
- ❌ 冪等性檢查 → Parent 做
- ❌ 統一回應格式 → Parent 做
- ❌ 跨 workflow 鎖 → Parent 做
- ❌ AML 規則設定 → Parent 集中管理(Child 僅呼叫 API)
- ❌ 手續費計算 → Parent 預扣,Child 僅負責路由(見 fee-calculation-rules.md)

### 4.0.3 Dispatcher 決策表

| `operationType` | 業務語意 | Child | 必填額外欄位 |
|---|---|---|---|
| `A` | 國內跨行匯出 | WF-A (Domestic Remittance) | 無 |
| `B` | 跨境 SWIFT 匯出 | WF-B (SWIFT Remittance) | `currency`, `beneficiaryBankBIC`, `purposeCode`, `fxRate` |
| `C` | 反向沖銷 | WF-C (Cancellation) | `originalSequenceNumber`, `cancellationReason` |
| 其他 | — | — | — (回 400) |

> **關鍵**: `operationType` 與 child 的 opType **必須一致**。WF-A 對 Core/AML/Domestic Clearing 呼叫一律 `opType=A`;WF-B 對 Core/AML/SWIFT 呼叫一律 `opType=A`(扣款),僅 FX 申報端點 `opType=R`(reporting);WF-C 對 Core 呼叫一律 `opType=B`(退款)。

---

### 4.1 Workflow A: 國內跨行匯款 (WF-A, child of Parent)

#### 4.1.1 流程圖

```
Parent 委派
    ↓
[WF-A: Domestic Remittance]
    ↓
階段 1: 核心帳務主機 ← 扣款(opType=A, seq=CR_xxx)
    ├─ 失敗(status=1 OR http=5xx) → FAILED(無補償,錢未扣)
    └─ 成功(status=0)
         ↓
階段 2: AML 主機 ← 黑名單篩查(客戶 + 受款人)
    ├─ 命中 → AML_REJECTED(無補償,錢未扣? ⚠️ 視扣款時機)
    └─ 通過
         ↓
階段 3: 財金跨行通匯主機 ← 匯出至受款行(opType=A, seq=DR_xxx)
    ├─ 成功 → SUCCESS ✅
    └─ 失敗 → 觸發 LIFO 補償
              ↓
          Rollback 核心帳務(opType=B, seq=CR_R_xxx)
              ├─ 成功 → ROLLED_BACK(已退款給客戶,結束)
              └─ 失敗 → ROLLBACK_FAILED(告警,人工處理)
    ↓
回報 Parent (finalStatus)
```

#### 4.1.2 為什麼三階段都必須成功

- 核心未扣 + AML 通過但客戶已收到扣款通知 → **虛假扣款**(客戶未實際付款)
- 核心已扣 + 財金未匯出 → **款項卡在銀行**(客戶已付但對方未收,監理申報異常)
- 核心已扣 + 財金已匯出但受款行退匯 → 走退匯處理(本文件 §4.4)

三者都是監理申報異常,Parent 必須透過 child 流程保證一致性。

#### 4.1.3 AML 命中時的扣款處理

> **重要決策**: AML 命中發生在階段 2,此時**核心已在階段 1 扣款**。因此:
> - 若 AML 命中 → Parent 必須觸發核心退款(等同於階段 3 失敗的補償路徑)
> - 退款成功 → 狀態為 `AML_REJECTED`(200,告知客戶因合規拒絕)
> - 退款失敗 → 狀態為 `AML_REJECTED_ROLLBACK_FAILED`(409,告警人工)

> 此情境在 v1.0 為 v1.0 新增決策,需業務方確認。

---

### 4.2 Workflow B: 跨境 SWIFT 電匯 (WF-B, child of Parent)

#### 4.2.1 流程圖

```
Parent 委派
    ↓
[WF-B: SWIFT Remittance]
    ↓
階段 1: 核心帳務主機 ← 扣款(opType=A, seq=CR_xxx,含手續費預扣)
    ├─ 失敗 → FAILED(無補償)
    └─ 成功
         ↓
階段 2: AML 主機 ← 黑名單篩查(客戶 + 受款人 + 國家)
    ├─ 命中 → 觸發核心退款
    │        ├─ 成功 → AML_REJECTED
    │        └─ 失敗 → AML_REJECTED_ROLLBACK_FAILED
    └─ 通過
         ↓
階段 3: SWIFT 主機 ← 送出 MT103 報文(opType=A, seq=SW_xxx)
    ├─ 成功 → SWIFT_PENDING(等待對方 ack,可能需 1-2 個工作天)
    │        ├─ 對方 ack 成功 → SUCCESS
    │        └─ 對方 ack 失敗 → 觸發 SWIFT 取消報文(MT103 cancel)
    └─ 失敗 → 觸發核心退款 + SWIFT 取消報文(若已送出)
         ↓
階段 4: 外匯申報主機 ← 送出申報資料(opType=R, seq=FX_xxx)
    ├─ 成功 → 視 SWIFT 最終狀態決定 (SUCCESS / SWIFT_PENDING / ROLLED_BACK)
    └─ 失敗 → 仍視為 SWIFT 成功,告警補申報
    ↓
回報 Parent (finalStatus)
```

#### 4.2.2 與國內匯款的差異

| 維度 | WF-A (Domestic) | WF-B (SWIFT) |
|---|---|---|
| 主機呼叫數 | 3 | 4 |
| 階段 1 扣款金額 | 僅匯款金額 | 匯款金額 + 手續費 + 中間行費預估 |
| 階段 2 AML | 客戶 + 受款人 | 客戶 + 受款人 + 國家(制裁國家名單) |
| 階段 3 路由 | 財金跨行通匯 | SWIFT MT103 |
| 階段 4 申報 | 無 | 外匯申報(央行規定) |
| 取消補償 | 僅核心退款 | 核心退款 + SWIFT 取消報文 + 通知對方行 |
| 對方 ack | 即時(秒級) | 延遲(1-2 工作天) |

#### 4.2.3 為什麼 SWIFT_PENDING 是中間態

SWIFT 報文送出後,需等待對方銀行 ack 才能視為「真正入帳」。在 ack 到達前,匯款處於 `SWIFT_PENDING` 狀態:

- 此狀態下**仍可發動取消**(Parent 將送出 SWIFT 取消報文)
- 此狀態下**不可視為最終 SUCCESS**
- Parent 對外回報 `SWIFT_PENDING`(HTTP 200),告知客戶「已匯出但對方尚未確認收款」

---

### 4.3 Workflow C: 沖銷 (WF-C, child of Parent)

#### 4.3.1 觸發條件

| 條件 | 規格 |
|---|---|
| 原交易類型 | WF-A 或 WF-B |
| 原交易狀態 | 必須為 `SUCCESS` 或 `SWIFT_PENDING` |
| 原交易未沖銷 | 該交易必須尚未被任何 WF-C 處理過 |
| 沖銷時機 | 當日內(以 `transactionDate` 為準);跨境匯款超過 24 小時僅能走人工 |
| 發動者 | 同一分行的任一授權櫃員(不限定原櫃員) |
| 沖銷原因 | `TELLER_MISTAKE`(打錯)或 `CARDHOLDER_REQUEST`(客戶反悔) |

#### 4.3.2 流程圖

```
Parent 委派
    ↓
[WF-C: Cancellation]
    ↓
[Lookup] 用 originalSequenceNumber 從 AuditLog 查原交易(parent row)
    ├─ 找不到 → LOOKUP_FAILED (500)
    ├─ 狀態 ≠ SUCCESS 且 ≠ SWIFT_PENDING → CANCEL_REJECTED (200)
    ├─ 已被沖銷 → CANCEL_REJECTED (idempotency 保護)
    └─ 通過預檢
         ↓
階段 2: 核心帳務主機 ← 退款(opType=B, seq=CR_R_{origCR})
    ├─ 失敗 → CANCEL_FAILED (原扣款仍存)
    └─ 成功
         ↓
階段 3: (僅 SWIFT) SWIFT 主機 ← 送出取消報文(MT103 cancel)
    ├─ 不適用(原交易為 WF-A)→ 跳過
    ├─ 失敗 → 觸發自身階段 2 補償(回滾核心退款)
    │        ├─ 成功 → CANCEL_ROLLED_BACK
    │        └─ 失敗 → CANCEL_ROLLBACK_FAILED
    └─ 成功
         ↓
階段 4: (僅 SWIFT) 通知對方行(可選,透過 SWIFT MT900)
    ├─ 失敗 → 不影響整體,告警補送
    └─ 成功 / 跳過
         ↓
最終狀態: CANCELLED ✅
    ↓
回報 Parent (finalStatus)
```

#### 4.3.3 與「系統自動補償」的差異

| 維度 | 業務流沖銷 (WF-C) | 系統自動補償 (WF-A/B 內部) |
|---|---|---|
| 觸發者 | 櫃員手動 (Parent 委派) | Parent 偵測到 child 階段失敗 |
| 對象 | 已成功的原交易 | 只有核心扣款的當下交易 |
| 順序 | Core → SWIFT(僅跨境) | Core only(因為 SWIFT 從未成功) |
| 失敗處理 | 觸發補償 → 失敗告警人工 | 同左 |
| AuditLog 標記 | `parent.transaction_type=CANCELLATION` | `parent.transaction_type=REMITTANCE_ROLLBACK` |

> **重要**: WF-C 階段 3 (SWIFT 取消) 失敗時,Parent 仍會觸發對 WF-C 階段 2 的補償(用同一個 `CR_R_xxx` 冪等回滾);若補償也失敗,則走人工(不再觸發四階補償)。

---

### 4.4 退匯處理 (Return / Recall)

> 退匯為特殊路徑,發生在「對方銀行已收款但退回」的情境。本文件僅作規格定義,不另設獨立 Child。

#### 4.4.1 觸發情境

| 情境 | 規格 |
|---|---|
| 國內匯款退匯 | 受款行於當日內退回(透過財金退匯機制) |
| SWIFT 退匯 | 受款行發動 Recall 請求(SWIFT MT192) |
| 退匯時點 | 原交易 SUCCESS 後,對方尚未動用款項 |

#### 4.4.2 處理路徑

退匯**不是**新的一筆交易,而是**對原交易的狀態更新**:

1. 財金/SWIFT 主機發起退匯通知
2. Parent 收到退匯通知(透過 webhook 或 polling)
3. Parent 觸發原交易 row 的狀態更新:`SUCCESS → RETURNED`
4. 退款給客戶(走 Core opType=B)
5. 退款成功 → 狀態 `RETURNED_REFUNDED`
6. 退款失敗 → 狀態 `RETURNED_PENDING`(告警人工)

> 退匯流程在本版 v1.0 為**設計預留**,實際 webhook 介接在下一版實作。

---

## 5. 統一狀態機

### 5.1 Parent + Child 狀態總表

| 層級 | 狀態 | 涵義 |
|---|---|---|
| **Parent** | `RECEIVED` | API 收到請求 |
| **Parent** | `VALIDATED` | 輸入驗證通過 |
| **Parent** | `REJECTED_VALIDATION` | 驗證失敗 (HTTP 400) |
| **Parent** | `DISPATCHED` | 已委派給 child,等待回報 |
| **Parent** | `COMPLETED` | child 已回報,Parent 整理回應 |
| **Parent** | `IDEMPOTENT_REPLAY` | workflow 級冪等命中,回傳上次結果 |
| **Child WF-A** | `INIT` → `CORE_PENDING` → `CORE_SUCCESS` → `AML_PENDING` → `AML_SUCCESS` → `DOMESTIC_PENDING` → `SUCCESS` |
| **Child WF-A** | `CORE_FAILED`(階段 1) |
| **Child WF-A** | `AML_REJECTED`(階段 2) |
| **Child WF-A** | `DOMESTIC_ROLLBACK_PENDING` → `ROLLED_BACK` |
| **Child WF-A** | `DOMESTIC_ROLLBACK_FAILED`(HTTP 409) |
| **Child WF-B** | `INIT` → `CORE_PENDING` → `CORE_SUCCESS` → `AML_PENDING` → `AML_SUCCESS` → `SWIFT_PENDING_SEND` → `SWIFT_PENDING_ACK` → `FX_PENDING` → `SUCCESS` |
| **Child WF-B** | `CORE_FAILED` |
| **Child WF-B** | `AML_REJECTED` |
| **Child WF-B** | `SWIFT_SEND_FAILED` |
| **Child WF-B** | `SWIFT_ACK_FAILED`(對方拒絕,需手動處理) |
| **Child WF-B** | `FX_REPORT_FAILED`(申報失敗,補申報) |
| **Child WF-B** | `SWIFT_ROLLBACK_PENDING` → `SWIFT_ROLLED_BACK` |
| **Child WF-B** | `SWIFT_ROLLBACK_FAILED`(HTTP 409) |
| **Child WF-C** | `INIT` → `LOOKUP_PENDING` → `CORE_PENDING` → `SWIFT_CANCEL_PENDING`(僅 SWIFT) → `NOTIFY_PENDING`(僅 SWIFT) → `CANCELLED` |
| **Child WF-C** | `LOOKUP_FAILED`(HTTP 500) |
| **Child WF-C** | `CANCEL_REJECTED` |
| **Child WF-C** | `CANCEL_FAILED`(階段 2 失敗) |
| **Child WF-C** | `CANCEL_ROLLED_BACK` |
| **Child WF-C** | `CANCEL_ROLLBACK_FAILED`(HTTP 409) |

### 5.2 對外回報狀態(Parent 統一)

> 不論內部 child 為何,Parent 對外只回報下列狀態:

| Parent 對外狀態 | 內部來源 | HTTP |
|---|---|---|
| `SUCCESS` | WF-A 三階段成功 | 200 |
| `SWIFT_PENDING` | WF-B 已送 SWIFT 等待對方 ack | 200 |
| `SUCCESS_AFTER_ACK` | WF-B 對方 ack 成功 | 200 |
| `FAILED` | WF-A 或 WF-B 階段 1 失敗 | 200 |
| `AML_REJECTED` | WF-A 或 WF-B 階段 2 命中 | 200 |
| `ROLLED_BACK` | WF-A 階段 3 失敗但 Core 退款成功 | 200 |
| `SWIFT_ROLLED_BACK` | WF-B 失敗但 Core 退款 + SWIFT 取消成功 | 200 |
| `CANCELLED` | WF-C 全成功沖銷 | 200 |
| `CANCEL_REJECTED` | WF-C 預檢不通過 | 200 |
| `CANCEL_FAILED` | WF-C 階段 2 失敗 | 200 |
| `CANCEL_ROLLED_BACK` | WF-C 部分失敗但內部補償成功 | 200 |
| `FX_REPORT_FAILED` | WF-B 階段 4 失敗,SWIFT 仍視為成功 | 200 |
| `REJECTED_VALIDATION` | Parent 驗證失敗 | 400 |
| `LOOKUP_FAILED` | WF-C 查原交易失敗 | 500 |
| `ROLLBACK_FAILED` | 任一補償失敗 | 409 |
| `AML_REJECTED_ROLLBACK_FAILED` | AML 命中但退款失敗 | 409 |
| `IDEMPOTENT_REPLAY` | 命中 workflow 級冪等 | 200(回原結果) |

### 5.3 狀態轉換圖

```
                              [API POST]
                                  ↓
                              RECEIVED
                                  ↓
                            [Parent 驗證]
                              ├─(fail)─→ REJECTED_VALIDATION (400)
                              └─(ok)
                                  ↓
                            VALIDATED
                                  ↓
                          [冪等性檢查]
                              ├─(hit)─→ IDEMPOTENT_REPLAY (回原結果)
                              └─(miss)
                                  ↓
                            DISPATCHED
                                  ↓
                  ┌───────────────┼───────────────┐
                  ↓               ↓               ↓
            [operationType=A] [operationType=B] [operationType=C]
                  ↓               ↓               ↓
              [WF-A]           [WF-B]           [WF-C]
                  ↓               ↓               ↓
   CORE_PENDING ─(fail)─→ FAILED  CORE_PENDING ─(fail)─→ FAILED  LOOKUP_PENDING
        │(ok)              ↑            │(ok)              ↑         ├─(fail)─→ LOOKUP_FAILED
        ↓                  │            ↓                  │         ├─(reject)─→ CANCEL_REJECTED
   AML_PENDING             │       AML_PENDING             │         │(ok)
   ├─(hit)─→ AML_REJECTED  │       ├─(hit)─→ AML_REJECTED  │         ↓
   │(ok)     (退款)        │       │(ok)                   │     CORE_PENDING
   ↓                       │       ↓                       │     ├─(fail)─→ CANCEL_FAILED
DOMESTIC_PENDING           │   SWIFT_PENDING_SEND          │     │(ok)
├─(ok)─→ SUCCESS          │   ├─(ok)─→ SWIFT_PENDING_ACK  │     ↓
└─(fail)─→ ROLLBACK_PENDING│   │         ├─(ok)─→ FX_PENDING │  SWIFT_CANCEL_PENDING
              ├─(ok)─→ ROLLED_BACK│     │         │(ok)─→ SUCCESS │  ├─(ok)─→ NOTIFY_PENDING
              └─(fail)─→ ROLLBACK_FAILED   │     │(fail)─→ FX_REPORT_FAILED│  ├─(fail)─→ ROLLBACK_PENDING
                          │   └─(fail)─→ SWIFT_SEND_FAILED       │  │         ├─(ok)─→ CANCEL_ROLLED_BACK
                          │                ↓                     │  │         └─(fail)─→ CANCEL_ROLLBACK_FAILED
                          │       [補償: Core退款 + SWIFT取消]    │  └─(skip)─→ CANCELLED
                          │       ├─(ok)─→ SWIFT_ROLLED_BACK     │      ↓
                          │       └─(fail)─→ SWIFT_ROLLBACK_FAILED│   NOTIFY_PENDING
                          │                                     │   ├─(ok)─→ CANCELLED
                          │                                     │   ├─(fail)─→ CANCELLED(告警補送)
                          │                                     │   └─(skip)─→ CANCELLED
                  ↓               ↓               ↓
                  └───────────────┼───────────────┘
                                  ↓
                              COMPLETED
                                  ↓
                              [統一回應]
```

### 5.4 HTTP 對應(Parent 對外)

| Parent 對外狀態 | HTTP | 客戶端動作 |
|---|---|---|
| `REJECTED_VALIDATION` | 400 | 修正輸入 |
| `SUCCESS` / `SUCCESS_AFTER_ACK` | 200 | 開立匯款收據 |
| `SWIFT_PENDING` | 200 | 顯示「已匯出,等待對方確認」,告知客戶 1-2 工作天後查詢 |
| `FAILED` | 200 | 顯示「款項未匯出」,不補償 |
| `AML_REJECTED` | 200 | 顯示「因合規因素拒絕」,退款已退回 |
| `ROLLED_BACK` / `SWIFT_ROLLED_BACK` | 200 | 顯示「已退款」,結束 |
| `CANCEL_REJECTED` | 200 | 顯示拒絕原因,結束 |
| `CANCEL_FAILED` | 200 | 顯示「沖銷失敗,原交易仍存」,由櫃員決定重試或人工 |
| `FX_REPORT_FAILED` | 200 | 顯示「匯款成功,申報待補」,告警補申報 |
| `IDEMPOTENT_REPLAY` | 200 | 顯示原結果 |
| `LOOKUP_FAILED` | 500 | 系統異常,稍後重試 |
| `ROLLBACK_FAILED` | 409 | 通知分行主管 |
| `AML_REJECTED_ROLLBACK_FAILED` | 409 | 通知分行主管 + AML Officer |
| `CANCEL_ROLLBACK_FAILED` | 409 | 通知分行主管 |

---

## 6. 介面契約

### 6.1 端點速查(清楚分層)

| 層級 | 端點 | 用途 |
|---|---|---|
| **API 入口 (唯一)** | `POST /Omni/{partyId}/Remittance/Execute` | Parent 收單,接收 operationType 分派 |
| Host 1 - 核心帳務 (由 child 觸發) | `POST /CoreAccount/{partyId}/Debit/Execute` | 扣款(opType=A) |
| Host 1 - 核心帳務 | `POST /CoreAccount/{partyId}/Refund/Execute` | 退款(opType=B) |
| Host 1 - 核心帳務 | `POST /CoreAccount/{partyId}/Hold/Execute` | 圈存(跨境預扣) |
| Host 1 - 核心帳務 | `POST /CoreAccount/{partyId}/Query/Execute` | 查詢餘額(輔助) |
| Host 2 - AML (由 child 觸發) | `POST /AML/Party/Screen/Execute` | 客戶統編黑名單 |
| Host 2 - AML | `POST /AML/Beneficiary/Screen/Execute` | 受款人黑名單 |
| Host 2 - AML | `POST /AML/Transaction/Check/Execute` | 交易特徵檢查 |
| Host 3 - 國內跨行通匯 (由 child 觸發) | `POST /DomesticClearing/{partyId}/Outbound/Execute` | 跨行匯出 |
| Host 3 - 國內跨行通匯 | `POST /DomesticClearing/{partyId}/Query/Execute` | 查匯出狀態 |
| Host 3 - 國內跨行通匯 | `POST /DomesticClearing/{partyId}/Return/Execute` | 退匯 |
| Host 4 - SWIFT (由 child 觸發) | `POST /SWIFT/MT103/Send/Execute` | 送出 MT103 |
| Host 4 - SWIFT | `POST /SWIFT/MT103/Cancel/Execute` | 送出取消報文(補償用) |
| Host 4 - SWIFT | `POST /SWIFT/MT199/Query/Execute` | 查詢報文狀態 |
| Host 4 - SWIFT | `POST /SWIFT/MT900/Notify/Execute` | 入帳通知 |
| Host 4 - SWIFT | `POST /SWIFT/MT192/Recall/Execute` | 退匯通知 |
| 外匯申報 (由 child 觸發) | `POST /FXReport/Transaction/Report/Execute` | 申報資料送出(opType=R) |

> **架構原則**: 對外**只有一個 API 入口**(`/Omni/...`),對內呼叫 4 個**主機服務**(共 17 個端點)。Parent 不直接呼叫主機,而是委派給 child 執行。

### 6.2 輸入欄位(API 入口,15 個)

> 詳細規格請參考各 Host API 文件,本文件補強因 Parent 架構新增的欄位。

| # | 參數 | 類型 | 必填 | 適用 | 說明 |
|---|---|---|---|---|---|
| 1 | `partyId` | string | ✓ | 全部 | 客戶統編 |
| 2 | `branchCode` | string | ✓ | 全部 | 交易分行代號 |
| 3 | `transactionDate` | string | ✓ | 全部 | 交易日期 (YYYYMMDD) |
| 4 | `transactionDateTime` | string | ✓ | 全部 | 交易時間 (HHMMSSxx) |
| 5 | `postingDayType` | string | ✓ | 全部 | A=本日 / B=次日 |
| 6 | `postingDate` | string | ✓ | 全部 | 入帳日 (YYYYMMDD) |
| 7 | `paymentSourceCode` | string | ✓ | 全部 | 見下方 |
| 8 | `operationType` | string | ✓ | **全部** | **A=國內匯款(WF-A) / B=跨境匯款(WF-B) / C=沖銷(WF-C)** ⭐ |
| 9 | `amount` | string | ✓ | A/B | 匯款金額(分,左補零) |
| 10 | `currency` | string | ✓ | B | 幣別(ISO 4217,如 USD/JPY/EUR) |
| 11 | `fxRate` | string | ✓ | B | 匯率(牌告匯率) |
| 12 | `beneficiaryAccount` | string | ✓ | A/B | 受款人帳號 |
| 13 | `beneficiaryName` | string | ✓ | A/B | 受款人姓名 |
| 14 | `beneficiaryBankBIC` | string | ✓ | **B** | 受款銀行 BIC(SWIFT 代碼) |
| 15 | `purposeCode` | string | ✓ | **B** | 匯款性質分類(央行規定代號) |
| 16 | `sequenceNumber` | string | ✓ | 全部 | 業務序號,Parent 生成 |
| 17 ⭐ | `originalSequenceNumber` | string | **條件必填** | **僅 operationType=C** | 欲沖銷的原匯款之 sequenceNumber |
| 18 ⭐ | `cancellationReason` | enum | **條件必填** | **僅 operationType=C** | `TELLER_MISTAKE` / `CARDHOLDER_REQUEST` |

**`paymentSourceCode`**: J=語音 / K=存款 / P=網銀 / I=ATM / A=現金 / E=轉帳

### 6.3 統一回應結構(Parent 對外)

```json
{
    "track_id": "<parent 統一 track_id>",
    "workflow": "DOMESTIC_REMITTANCE" | "SWIFT_REMITTANCE" | "CANCELLATION",
    "status": 0 | 1,
    "finalStatus": "SUCCESS" | "SWIFT_PENDING" | "SUCCESS_AFTER_ACK" | "FAILED" | "AML_REJECTED" | "ROLLED_BACK" | "SWIFT_ROLLED_BACK" | "CANCELLED" | "CANCEL_REJECTED" | "CANCEL_FAILED" | "CANCEL_ROLLED_BACK" | "FX_REPORT_FAILED" | "REJECTED_VALIDATION" | "LOOKUP_FAILED" | "ROLLBACK_FAILED" | "AML_REJECTED_ROLLBACK_FAILED" | "IDEMPOTENT_REPLAY",
    "errors": null | [{ "error_code": "...", "message": "..." }],
    "result": {
        "partyId": "...",
        "branchCode": "...",
        "operationType": "A" | "B" | "C",
        "amount": "...",
        "currency": "...",
        "sequenceNumber": "...",
        "originalSequenceNumber": "...",  // 僅 CANCELLATION 有
        "cancellationReason": "..."       // 僅 CANCELLATION 有
    }
}
```

### 6.4 Sequence Number 規則

| 前綴 | 用途 | 產生者 |
|---|---|---|
| `CR_` | 核心帳務扣款(正向) | WF-A 階段 1、WF-B 階段 1 |
| `CR_R_` | 核心帳務退款(反向/沖銷) | WF-A 失敗補償、WF-B 失敗補償、WF-C 沖銷退款 |
| `DR_` | 國內跨行通匯正向 | WF-A 階段 3 |
| `DR_R_` | 國內跨行通匯反向(退匯) | WF-A 退匯處理 |
| `SW_` | SWIFT 報文正向(MT103) | WF-B 階段 3 |
| `SW_R_` | SWIFT 報文反向(MT103 cancel) | WF-B 失敗補償、WF-C 階段 3 |
| `FX_` | 外匯申報 | WF-B 階段 4 |

> 規則: prefix 固定 3 碼,後接 19 碼業務序號,合計 22 字元。Parent 對外回報的 `sequenceNumber` 是 child 階段的最終 seq;Parent 自己的 `track_id` 是另一組(給稽核/監控用)。

### 6.5 Dispatcher 範例請求

**WF-A 範例 (operationType=A):**
```json
POST /Omni/A123456789/Remittance/Execute
{
    "partyId": "A123456789",
    "branchCode": "070",
    "transactionDate": "20260907",
    "transactionDateTime": "15061655",
    "postingDayType": "A",
    "postingDate": "20260907",
    "paymentSourceCode": "2500P",
    "operationType": "A",
    "amount": "0000011758",
    "currency": "TWD",
    "beneficiaryAccount": "1234567890123",
    "beneficiaryName": "王小明",
    "sequenceNumber": "A1234567890000015061655"
    // 不必填 fxRate, beneficiaryBankBIC, purposeCode, originalSequenceNumber, cancellationReason
}
```

**WF-B 範例 (operationType=B):**
```json
POST /Omni/A123456789/Remittance/Execute
{
    "partyId": "A123456789",
    "branchCode": "070",
    "transactionDate": "20260907",
    "transactionDateTime": "16000000",
    "postingDayType": "A",
    "postingDate": "20260907",
    "paymentSourceCode": "2500P",
    "operationType": "B",
    "amount": "0000011758",
    "currency": "USD",
    "fxRate": "0000031500",            // 31.5 TWD/USD
    "beneficiaryAccount": "DE89370400440532013000",
    "beneficiaryName": "Hans Schmidt",
    "beneficiaryBankBIC": "DEUTDEFFXXX",
    "purposeCode": "10100",            // 貨物貿易
    "sequenceNumber": "A1234567890000016000000"
    // 不必填 originalSequenceNumber, cancellationReason
}
```

**WF-C 範例 (operationType=C):**
```json
POST /Omni/A123456789/Remittance/Execute
{
    "partyId": "A123456789",
    "branchCode": "070",
    "transactionDate": "20260907",
    "transactionDateTime": "17000000",
    "postingDayType": "A",
    "postingDate": "20260907",
    "paymentSourceCode": "2500P",
    "operationType": "C",
    "amount": "0000011758",
    "currency": "TWD",
    "beneficiaryAccount": "1234567890123",
    "beneficiaryName": "王小明",
    "sequenceNumber": "A1234567890000017000000",
    "originalSequenceNumber": "A1234567890000015061655",   // ⭐ 必填
    "cancellationReason": "TELLER_MISTAKE"                  // ⭐ 必填
}
```

---

## 7. 業務規則

### 7.1 Parent 通用規則 (BR-P) ⭐ 新章節

| 代號 | 規則 |
|---|---|
| **BR-P01** ⭐ | **API 入口唯一,所有請求走 `POST /Omni/{partyId}/Remittance/Execute`** |
| **BR-P02** ⭐ | **`operationType` 為唯一 dispatcher 鍵;A → WF-A, B → WF-B, C → WF-C,其他值回 400** |
| **BR-P03** ⭐ | **`operationType=C` 時,`originalSequenceNumber` 與 `cancellationReason` 為必填;為 A/B 時不可填** |
| BR-P04 | `operationType=B` 時,`currency`、`fxRate`、`beneficiaryBankBIC`、`purposeCode` 為必填 |
| BR-P05 | Parent 必須先做輸入驗證、冪等性檢查,再委派給 child |
| BR-P06 | Parent 對外只回報 §5.2 的對外狀態,內部 child 狀態不外洩 |
| BR-P07 | 任何 child 進入 `*_FAILED` 終態,Parent 必須觸發對應告警 |
| BR-P08 | 跨境匯款金額超過等值 USD 50,000 須觸發大額申報(央行規定) |
| BR-P09 | 跨境匯款須附 `purposeCode`,未填則 REJECTED_VALIDATION |

### 7.2 通用規則 (跨 workflow)

| 代號 | 規則 | 適用 |
|---|---|---|
| BR-001 | 所有交易必須有 `tellerId`、`counterNo`、`terminalId` | 全部 |
| BR-002 | 交易金額必須 > 0(單位:分) | A/B |
| BR-003 | `sequenceNumber` 不可重複(同前綴內唯一) | 全部 |
| BR-004 | `operationType` 只能為 A/B/C | 全部 |
| BR-005 | 欄位驗證錯誤必須在 5xx 之前攔截,轉成 400 | 全部 |
| BR-006 | **冪等性**: 同一 `sequenceNumber` 重送主機必須回傳相同結果,不得重複扣款 | 全部 |
| BR-007 | **並發保護**: 同一原交易不得同時被兩個 workflow 處理(以 row-level lock 保護) | WF-C |

### 7.3 國內匯款規則 (WF-A)

| 代號 | 規則 |
|---|---|
| BR-101 | 業務拒絕(status=1, http=200)→ **不**觸發自動退款(因為本來就沒扣款) |
| BR-102 | 系統錯誤(http=5xx)→ **觸發**自動退款 |
| BR-103 | 自動退款本身失敗 → 告警 + 人工介入 |
| BR-104 | 三段都成功才視為 `SUCCESS`,任一失敗整筆不視為成功 |
| BR-105 | AML 命中後必須退款給客戶,因 Core 已在階段 1 扣款 |
| BR-106 | 退匯處理視為原交易的狀態更新,不另設 Child |

### 7.4 跨境匯款規則 (WF-B)

| 代號 | 規則 |
|---|---|
| BR-201 | 階段 1 扣款金額含匯款金額 + 手續費 + 中間行費預估 |
| BR-202 | AML 命中後必須退款給客戶,因 Core 已在階段 1 扣款 |
| BR-203 | SWIFT 報文送出後狀態為 `SWIFT_PENDING`,待對方 ack |
| BR-204 | 對方 ack 成功 → `SUCCESS_AFTER_ACK` |
| BR-205 | 對方 ack 失敗 → 觸發 SWIFT 取消報文(MT103 cancel) |
| BR-206 | SWIFT 取消報文失敗 → 告警人工處理 |
| BR-207 | FX 申報失敗不影響整體匯款,告警補申報 |
| BR-208 | 跨境匯款超過 24 小時且對方已入帳,僅能走人工沖銷 |

### 7.5 冪等性與並發規則

| 代號 | 規則 |
|---|---|
| BR-501 | 主機端必須支援 sequenceNumber 冪等(同 seq 重送回傳同結果) |
| **BR-502** ⭐ | **Parent 必須支援 workflow 級冪等:同 `sequenceNumber` 重送 Parent,回傳同 finalStatus(透過 `IDEMPOTENT_REPLAY` 狀態)** |
| BR-503 | WF-C 啟動時,Parent 必須對原交易 row 加 lock,防止並發沖銷 |
| BR-504 | 補償操作也必須是冪等的(同 CR_R_seq 重送回傳同結果) |
| BR-505 | 任何 workflow 在 30 秒無回應視為 timeout,進入「未知狀態」需主動查詢主機確認 |

### 7.6 沖銷規則 (WF-C)

| 代號 | 規則 |
|---|---|
| BR-301 | 沖銷對象的原狀態必須為 `SUCCESS` 或 `SWIFT_PENDING` |
| BR-302 | 同一原交易只能被沖銷一次(以原交易 `cancelledBy` 欄位為據) |
| BR-303 | 沖銷必須在原交易當日內發動;跨境匯款 24 小時後僅能走人工 |
| BR-304 | WF-C 階段 2 失敗 → `CANCEL_FAILED`,**不補償**(原扣款仍存,櫃員可重試) |
| BR-305 | WF-C 階段 3 失敗 → 觸發對**自身**階段 2 的補償(同 seq CR_R_xxx) |
| BR-306 | WF-C 補償失敗 → `CANCEL_ROLLBACK_FAILED`,告警,人工處理 |
| BR-307 | 沖銷原因 `TELLER_MISTAKE` 與 `CARDHOLDER_REQUEST` 走**相同**技術路徑,原因僅用於 audit |
| BR-308 | 沖銷成功後,原交易狀態改為 `CANCELLED`,並記錄 `cancelledBy` (Parent workflowId) 與 `cancelledAt` |

---

## 8. 資料模型 (Parent 統一)

### 8.1 `transactions` 表(單一主表,每筆 API 呼叫 = 一個 parent row)

| 欄位 | 類型 | 說明 |
|---|---|---|
| `id` | UUID | Primary Key |
| **`parent_workflow_id`** ⭐ | string | Parent 對外 track_id(給櫃員/監控用) |
| **`transaction_type`** ⭐ | enum | `DOMESTIC_REMITTANCE` / `SWIFT_REMITTANCE` / `CANCELLATION` / `REMITTANCE_ROLLBACK` |
| `operation_type` | char(1) | A / B / C(對應 API 輸入) |
| `parent_status` | enum | Parent 對外狀態(見 §5.2) |
| `child_status` | enum? | Child 內部狀態(給 Parent 內部用) |
| `parent_id` | UUID? | FK → 被沖銷的原交易(僅 CANCELLATION 有) |
| `original_sequence` | string? | ⭐ `originalSequenceNumber`(僅 CANCELLATION 有) |
| `cancellation_reason` | enum? | ⭐ `TELLER_MISTAKE` / `CARDHOLDER_REQUEST` |
| `party_id` | string | 客戶統編 |
| `branch_code` | string | 分行代號 |
| `amount` | bigint | 金額(分) |
| `currency` | string(3) | 幣別(ISO 4217,SWIFT 必填) |
| `fx_rate` | decimal? | 匯率(牌告,SWIFT 必填) |
| `beneficiary_account` | string | 受款人帳號 |
| `beneficiary_name` | string | 受款人姓名 |
| `beneficiary_bank_bic` | string? | 受款銀行 BIC(SWIFT 必填) |
| `purpose_code` | string? | 匯款性質分類(SWIFT 必填) |
| `core_sequence` | string? | 對應主機 seq (CR_xxx / CR_R_xxx) |
| `core_track_id` | string? | 主機回傳追蹤 ID |
| `core_status` | enum? | 主機狀態 (PENDING/SUCCESS/FAILED/NOT_APPLICABLE) |
| `aml_sequence` | string? | 對應主機 seq (AM_xxx) |
| `aml_track_id` | string? | AML 主機回傳追蹤 ID |
| `aml_status` | enum? | AML 狀態 (PENDING/SUCCESS/REJECTED/NOT_APPLICABLE) |
| `aml_hit_list` | string? | AML 命中的名單名稱 |
| `clearing_sequence` | string? | 對應主機 seq (DR_xxx,WF-A 用) |
| `clearing_track_id` | string? | 通匯主機回傳追蹤 ID |
| `clearing_status` | enum? | 通匯狀態 |
| `swift_sequence` | string? | 對應主機 seq (SW_xxx / SW_R_xxx,WF-B 用) |
| `swift_track_id` | string? | SWIFT 主機回傳追蹤 ID |
| `swift_status` | enum? | SWIFT 狀態 |
| `fx_sequence` | string? | 對應主機 seq (FX_xxx,WF-B 用) |
| `fx_track_id` | string? | FX 申報追蹤 ID |
| `fx_status` | enum? | FX 申報狀態 |
| `rollback_sequence` | string? | 補償 seq (若有的話) |
| `rollback_track_id` | string? | 補償 track_id |
| `rollback_status` | enum? | 補償狀態 |
| `cancelled_by` | UUID? | 哪個 Parent workflowId 把它沖銷 |
| `cancelled_at` | timestamp? | 沖銷時間 |
| `teller_id` | string | 經辦櫃員 |
| `counter_no` | string | 櫃號 |
| `terminal_id` | string | 端末機 ID |
| `created_at` | timestamp | 建立時間 |
| `updated_at` | timestamp | 更新時間 |
| `retry_count` | int | 重試次數 |

### 8.2 Parent-Child 對映範例

**DOMESTIC_REMITTANCE 範例 (transaction_type=DOMESTIC_REMITTANCE, operationType=A):**

| 欄位 | 值 |
|---|---|
| parent_workflow_id | `wf-uuid-001` |
| transaction_type | DOMESTIC_REMITTANCE |
| operation_type | A |
| parent_status | SUCCESS |
| amount | 11758 |
| currency | TWD |
| core_sequence | `CR_xxx_001` |
| core_track_id | `core-track-001` |
| core_status | SUCCESS |
| aml_sequence | `AM_xxx_001` |
| aml_track_id | `aml-track-001` |
| aml_status | SUCCESS |
| clearing_sequence | `DR_xxx_001` |
| clearing_track_id | `clearing-track-001` |
| clearing_status | SUCCESS |
| (無 swift_*) | — |
| (無 fx_*) | — |

**SWIFT_REMITTANCE 範例 (transaction_type=SWIFT_REMITTANCE, operationType=B):**

| 欄位 | 值 |
|---|---|
| parent_workflow_id | `wf-uuid-002` |
| transaction_type | SWIFT_REMITTANCE |
| operation_type | B |
| parent_status | SUCCESS_AFTER_ACK |
| amount | 11758 |
| currency | USD |
| fx_rate | 31.50 |
| beneficiary_bank_bic | DEUTDEFFXXX |
| purpose_code | 10100 |
| core_sequence | `CR_xxx_002` |
| core_track_id | `core-track-002` |
| core_status | SUCCESS |
| aml_sequence | `AM_xxx_002` |
| aml_status | SUCCESS |
| swift_sequence | `SW_xxx_002` |
| swift_track_id | `swift-track-002` |
| swift_status | ACKED |
| fx_sequence | `FX_xxx_002` |
| fx_track_id | `fx-track-002` |
| fx_status | SUCCESS |

**CANCELLATION 範例 (transaction_type=CANCELLATION, operationType=C):**

| 欄位 | 值 |
|---|---|
| parent_workflow_id | `wf-uuid-003` |
| transaction_type | CANCELLATION |
| operation_type | C |
| parent_status | CANCELLED |
| parent_id | `wf-uuid-002`(指向被沖銷的原 SWIFT_REMITTANCE row) |
| original_sequence | `A1234567890000016000000` |
| cancellation_reason | TELLER_MISTAKE |
| core_sequence | `CR_R_xxx_003`(反向前綴) |
| core_track_id | `core-track-003` |
| core_status | SUCCESS |
| swift_sequence | `SW_R_xxx_003`(SWIFT 取消報文) |
| swift_track_id | `swift-track-003` |
| swift_status | SUCCESS |

**被沖銷的原 SWIFT_REMITTANCE row 被更新:**

| 欄位 | 值 |
|---|---|
| (原 row) | — |
| cancelled_by | `wf-uuid-003` |
| cancelled_at | `2026-09-07T16:30:00` |

### 8.3 索引建議

- UNIQUE(`core_sequence`)
- UNIQUE(`clearing_sequence`)
- UNIQUE(`swift_sequence`)
- UNIQUE(`fx_sequence`)
- INDEX(`parent_id`)
- INDEX(`transaction_type`, `parent_status`)
- INDEX(`party_id`, `transaction_date`)
- INDEX(`original_sequence`) — 給 WF-C 快速查找原交易
- INDEX(`swift_status`) — 監控 `SWIFT_PENDING` 等待 ack 的交易
- INDEX(`cancelled_by`)

---

## 9. 例外處理與補償

### 9.1 補償策略總表(由 Parent 統一治理)

| 觸發情境 | 補償動作 | 失敗處置 |
|---|---|---|
| WF-A 階段 1 (Core) 失敗 | 無(錢未扣) | FAILED |
| WF-A 階段 2 (AML) 命中 | Core 退款(因 Core 已扣款) | AML_REJECTED_ROLLBACK_FAILED (告警) |
| WF-A 階段 3 (Domestic Clearing) 失敗 | Core 退款(opType=B, seq=CR_R_xxx) | 失敗→ROLLBACK_FAILED |
| WF-B 階段 1 (Core) 失敗 | 無 | FAILED |
| WF-B 階段 2 (AML) 命中 | Core 退款(因 Core 已扣款) | AML_REJECTED_ROLLBACK_FAILED |
| WF-B 階段 3 (SWIFT) 失敗 | Core 退款 + SWIFT 取消報文(若已送出) | SWIFT_ROLLBACK_FAILED |
| WF-B 階段 3 對方 ack 失敗 | SWIFT 取消報文(MT103 cancel) | 失敗→SWIFT_ROLLBACK_FAILED |
| WF-B 階段 4 (FX Reporting) 失敗 | 仍視為 SWIFT 成功,告警補申報 | FX_REPORT_FAILED |
| WF-C 階段 2 (Core 退款) 失敗 | 無(原扣款仍存) | CANCEL_FAILED,櫃員可重試 |
| WF-C 階段 3 (SWIFT 取消) 失敗 | 重試 3 次,失敗告警人工 | CANCEL_ROLLBACK_FAILED |
| WF-C 階段 4 (通知對方) 失敗 | 不影響整體,告警補送 | 仍視為 CANCELLED |
| 任何階段 timeout | Parent 啟動「未知狀態查詢流程」(見 9.3) | 視查詢結果決定 |

### 9.2 告警規則(Parent 觸發)

| 觸發條件 | 告警等級 | 通知對象 |
|---|---|---|
| `ROLLBACK_FAILED` | P1 | 分行主管 + 監控中心 |
| `SWIFT_ROLLBACK_FAILED` | P1 | 分行主管 + 監控中心 + AML Officer |
| `AML_REJECTED_ROLLBACK_FAILED` | P1 | 分行主管 + AML Officer |
| `CANCEL_ROLLBACK_FAILED` | P1 | 分行主管 + 監控中心 |
| `LOOKUP_FAILED` (連續 3 次) | P2 | 監控中心 |
| `FX_REPORT_FAILED` | P2 | 外匯申報員 |
| `SWIFT_PENDING` 超過 24 小時 | P2 | 監控中心 |
| 任何 Parent 30 分鐘卡在 DISPATCHED | P2 | 監控中心 |

### 9.3 未知狀態查詢流程

當 child 內某次主機呼叫 timeout:

1. Parent 不立即重試(避免重複扣款)
2. Parent 用相同 sequenceNumber 呼叫主機的「查詢端點」(若無,需請 API owner 補)
3. 依查詢結果決定:
   - 主機端 SUCCESS → 視為成功,繼續 child workflow
   - 主機端 FAILED → 視為失敗,進入補償
   - 主機端查無 → 視為「未送達」,人工聯絡主機 owner

### 9.4 SWIFT_PENDING 對方 ack 監控

跨境匯款送出後,Parent 啟動 ack 監控:

1. 每 30 分鐘查詢 SWIFT 主機該筆報文狀態
2. 收到 ack → 更新狀態為 `SUCCESS_AFTER_ACK`
3. 收到 reject → 觸發 SWIFT 取消報文流程
4. 超過 24 小時無 ack → 告警 P2,由外匯申報員人工追蹤

---

## 10. 驗收標準

### 10.1 Parent 層級驗收(5 大情境) ⭐ 新增

| # | 情境 | 預期 finalStatus | HTTP | 關鍵斷言 |
|---|---|---|---|---|
| **P1** ⭐ | `operationType=D` 或其他無效值 | `REJECTED_VALIDATION` | 400 | 沒進 child,沒寫主機 |
| **P2** ⭐ | `operationType=C` 但缺 `originalSequenceNumber` 或 `cancellationReason` | `REJECTED_VALIDATION` | 400 | 錯誤訊息明確指出缺漏欄位 |
| **P3** ⭐ | `operationType=A/B` 但帶了 `originalSequenceNumber` 或 `cancellationReason` | `REJECTED_VALIDATION` | 400 | 不可同時存在 |
| **P4** ⭐ | `operationType=B` 但缺 `currency`、`fxRate`、`beneficiaryBankBIC`、`purposeCode` | `REJECTED_VALIDATION` | 400 | 缺漏明確指出 |
| **P5** ⭐ | 同 `sequenceNumber` 重送 Parent | 第二次回 `IDEMPOTENT_REPLAY`,結果與第一次相同 | 200 | 沒有重複呼叫主機(用 mock 計次驗證) |

### 10.2 WF-A 國內匯款 6 大情境

| # | 情境 | 預期 finalStatus | HTTP | 關鍵斷言 |
|---|---|---|---|---|
| A1 | 正常成功 | `SUCCESS` | 200 | 三段 track_id 都有, auditSaved=true |
| A2 | 輸入校驗失敗(由 Parent 攔截) | `REJECTED_VALIDATION` | 400 | 失敗也寫 audit |
| A3 | Core 扣款失敗 | `FAILED` | 200 | 三段 track_id 都為 null |
| A4 | AML 命中(已扣款,需退款) | `AML_REJECTED` | 200 | Core 退款成功, AML track_id 有值 |
| A5 | Domestic Clearing 失敗 + 退款成功 | `ROLLED_BACK` | 200 | 三段 track_id 都有, opsAlert=false |
| A6 | 退款失敗告警 | `ROLLBACK_FAILED` | 409 | opsAlertRaised=true |

### 10.3 WF-B 跨境匯款 6 大情境

| # | 情境 | 預期 finalStatus | HTTP | 關鍵斷言 |
|---|---|---|---|---|
| B1 | 正常成功(含對方 ack) | `SUCCESS_AFTER_ACK` | 200 | 四段 track_id 都有, auditSaved=true |
| B2 | Core 扣款失敗 | `FAILED` | 200 | 四段 track_id 都為 null |
| B3 | AML 命中(已扣款,需退款) | `AML_REJECTED` | 200 | Core 退款成功 |
| B4 | SWIFT 報文送出成功,等待 ack | `SWIFT_PENDING` | 200 | 三段 track_id 有值, FX 尚未執行 |
| B5 | SWIFT 報文送出失敗 + 退款成功 + SWIFT 取消成功 | `SWIFT_ROLLED_BACK` | 200 | 退款 + SWIFT 取消皆有 track_id |
| B6 | FX 申報失敗,SWIFT 仍視為成功 | `FX_REPORT_FAILED` | 200 | SWIFT track_id 有值, FX track_id 有但 fx_status=FAILED |

### 10.4 WF-C 沖銷 5 大情境

| # | 情境 | 預期 finalStatus | HTTP | 關鍵斷言 |
|---|---|---|---|---|
| C1 | 正常沖銷(原交易為 WF-A) | `CANCELLED` | 200 | 兩段 track_id 都有,原交易 cancelledBy 有值 |
| C2 | 原交易找不到 | `LOOKUP_FAILED` | 500 | 沒發任何主機呼叫 |
| C3 | 原狀態 ≠ SUCCESS 且 ≠ SWIFT_PENDING | `CANCEL_REJECTED` | 200 | 顯示「原交易狀態不可沖銷」 |
| C4 | 重複沖銷 | `CANCEL_REJECTED` | 200 | idempotency 保護,顯示「已沖銷過」 |
| C5 | 沖銷階段 3 (SWIFT 取消) 失敗 + 補償成功 | `CANCEL_ROLLED_BACK` | 200 | Core 退款回滾,opsAlert=false |

### 10.5 跨 workflow 整合情境

| # | 情境 | 預期 |
|---|---:|---|
| X1 | 對已 CANCELLED 的交易再嘗試沖銷 | 第二次必須 `CANCEL_REJECTED` |
| X2 | 並發兩個沖銷同一交易 | 一個 `CANCELLED`、一個 `CANCEL_REJECTED`(並發保護) |
| X3 | 重送同一 `sequenceNumber` | 回傳同 finalStatus(Parent 級冪等) |
| X4 | 沖銷一筆 ROLLED_BACK 的交易 | `CANCEL_REJECTED`(只能沖銷 SUCCESS/SWIFT_PENDING) |
| **X5** ⭐ | AML_REJECTED 退款失敗後,嘗試沖銷該交易 | `CANCEL_REJECTED`(已不在 SUCCESS 狀態) |

---

## 11. 假設與限制

### 11.1 業務假設

| # | 假設 | 待確認 |
|---|---|---|
| A1 | sequenceNumber 採 22 字元(3 碼 prefix + 19 碼業務序號) | 需 API owner 確認 |
| A2 | 「當日內」以 `transactionDate` 為準,不看時間 | — |
| A3 | 跨境匯款 24 小時後僅能走人工(以 `transactionDateTime` 為準) | 需業務方確認 |
| A4 | 櫃員在當日內可發動沖銷(覆蓋跨班次情境) | 需業務方確認 |
| A5 | `originalSequenceNumber` 是唯一可用於查找原交易的鍵 | 需業務方確認 |
| **A6** ⭐ | **AML 命中時 Core 已在階段 1 扣款,必須退款**(因扣款發生在 AML 之前) | 需業務方確認 |
| **A7** ⭐ | **大額申報門檻為等值 USD 50,000**(央行規定) | 需業務方確認 |
| **A8** ⭐ | **退匯處理視為原交易狀態更新,不另設獨立 Child** | 需業務方確認 |

### 11.2 技術限制

| # | 限制 |
|---|---|
| T1 | 對帳資料儲存於 SQLite(本地),跨分行需 ETL 同步至中央資料庫 |
| T2 | Mock 端點僅供開發測試,正式環境由真實主機 API 取代 |
| T3 | Parent + WF-A/B/C 共用同一套 AuditLog 服務,以 `parent_workflow_id` 區分 |
| T4 | 主機端是否提供「seq 查詢端點」未知(影響 9.3 設計) |
| T5 | SWIFT 對方 ack 監控依賴 SWIFT 主機的查詢端點(`MT199`),若無則僅靠 webhook |
| T6 | 外匯申報端點可能需批次送出(央行規定),本版以單筆送出設計,實際可能需調整 |

### 11.3 範圍外

| 項目 | 處理方式 |
|---|---|
| ACH 代收代付 | 走批次媒體檔流程,另案設計 |
| 外幣現鈔買賣 | 涉及實體鈔券,另案設計 |
| 虛擬帳號收款 | 屬於「代收」業務,另案設計 |
| 票據託收 | 屬於「票券」業務,另案設計 |
| 匯入匯款解款 | 屬於「入帳」業務,另案設計 |
| 跨境匯款的稅務申報(扣繳憑單) | 屬於「稅務」業務,另案設計 |

---

## 12. 變更對照(預留)

> v1.0 為初始版本,本節預留未來變更紀錄。

---

## 13. 待開放問題(需業務方 / API owner 確認)

1. **A1 sequenceNumber 長度** — 仍是 13 或 22? API owner 確認了嗎?
2. **A3 跨境匯款 24 小時限制** — 是硬性規定?超過能否走「人工沖銷流程」?
3. **A5 originalSequenceNumber 唯一性** — 是否保證一個 partyId 內 sequenceNumber 全域唯一?若否,WF-C Lookup 需多鍵查詢
4. **A6 AML 命中退款時機** — 是否需要在 Core 階段 1 之後才扣款?即「先扣款後 AML」?或是「先 AML 後扣款」?
5. **A7 大額申報門檻** — 等值 USD 50,000 確認?若有調整,BR-P08 需同步更新
6. **A8 退匯流程** — webhook 介接時程?是 polling 還是事件驅動?
7. **T4 主機查詢端點** — 4 個主機端是否都有「依 seq 查狀態」的端點?影響 9.3 設計
8. **SWIFT MT103 cancel 報文** — SWIFT 主機接受嗎?若是不同格式(如 MT192)需另設端點
9. **FX 申報格式** — 央行規定格式是否已固定?欄位是否需調整?
10. **Parent 級冪等的 key** — 用 `sequenceNumber` 還是 `parent_workflow_id`?目前 v1.0 採前者
