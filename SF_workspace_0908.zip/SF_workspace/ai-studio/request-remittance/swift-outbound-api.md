# SWIFT 跨境匯款 API

**ver.** : `1.0`
**主機名稱** : SWIFT 跨境匯款主機 (SWIFT Outbound Gateway)
**通訊方式** : API
**訊息格式** : JSON (UTF-8)
**對應業務需求書** : `remittance-requirement.md` v1.0 §4.2、BR-201~208

> 本主機負責跨境 SWIFT 電匯作業,介接 SWIFT 網路發送 MT103 報文。所有 5 個端點由 Parent 的 Child Workflow (WF-B 階段 3、WF-B 階段 4 監控、WF-C 階段 3) 呼叫。

---

## 0. 端點清單

| # | 端點 | 用途 | 觸發 workflow 階段 |
|---|---|---|---|
| 1 | `POST /SWIFT/MT103/Send/Execute` | 送出 MT103 客戶匯款報文 | WF-B 階段 3 |
| 2 | `POST /SWIFT/MT103/Cancel/Execute` | 送出 MT103 取消報文(補償用) | WF-B 失敗補償、WF-C 階段 3 |
| 3 | `POST /SWIFT/MT199/Query/Execute` | 查詢報文狀態 | WF-B 對方 ack 監控 |
| 4 | `POST /SWIFT/MT900/Notify/Execute` | 入帳通知(對方行回傳) | 對方行入帳後通知 |
| 5 | `POST /SWIFT/MT192/Recall/Execute` | 退匯通知(對方行主動召回) | 對方行召回處理 |

---

## 1. MT103 送出 API

**URL** : `/SWIFT/MT103/Send/Execute`
**Method** : `POST`
**說明** : 產生並送出 SWIFT MT103 客戶匯款/匯款通知報文至受款銀行

### 1.1 Request 參數

| 參數名 | 類型 | 必填 | 說明 |
| --- | --- | --- | --- |
| partyId | `string` | ✓ | 匯款客戶統編 |
| transactionType | `string` | ✓ | 固定為 `REMITTANCE` |
| transactionDate | `string` | ✓ | 交易日期 (YYYYMMDD) |
| transactionDateTime | `string` | ✓ | 交易時間 (HHMMSSxx) |
| postingDayType | `string` | ✓ | A=本日 / B=次日 |
| postingDate | `string` | ✓ | 入帳日 |
| operationType | `string` | ✓ | 固定為 `A`(送出) |
| senderBIC | `string` | ✓ | 匯款行 BIC(如 `BANKUS33XXX`) |
| receiverBIC | `string` | ✓ | 受款行 BIC(如 `DEUTDEFFXXX`) |
| remitterAccount | `string` | ✓ | 匯款人帳號 |
| remitterName | `string` | ✓ | 匯款人姓名(英文,需與護照一致) |
| remitterAddress | `string` | ✓ | 匯款人地址(英文) |
| beneficiaryAccount | `string` | ✓ | 受款人帳號(IBAN 或一般帳號) |
| beneficiaryName | `string` | ✓ | 受款人姓名(英文) |
| beneficiaryAddress | `string` | ✗ | 受款人地址(英文) |
| currency | `string` | ✓ | 匯款幣別(ISO 4217) |
| amount | `string` | ✓ | 匯款金額(分,左補零) |
| fxRate | `string` | ✓ | 匯率(牌告) |
| purposeCode | `string` | ✓ | 匯款性質分類(央行規定) |
| remittanceInfo | `string` | ✗ | 匯款資訊(給受款人看的備註) |
| detailOfCharges | `string` | ✓ | `OUR` / `BEN` / `SHA` |
| correspondentBIC | `string` | ✗ | 中間行 BIC(若需中間行) |
| coreSequence | `string` | ✓ | 對應 Core 扣款的 sequenceNumber(`CR_` 前綴) |
| sequenceNumber | `string` | ✓ | SWIFT 報文序號(prefix `SW_` + 19 碼,共 22 字元) |

### 1.2 Request 範例

```json
{
    "transactionType": "REMITTANCE",
    "transactionDate": "20260907",
    "transactionDateTime": "16000000",
    "postingDayType": "A",
    "postingDate": "20260907",
    "operationType": "A",
    "senderBIC": "BANKUS33XXX",
    "receiverBIC": "DEUTDEFFXXX",
    "remitterAccount": "0098765432109",
    "remitterName": "CHEN DA-WEN",
    "remitterAddress": "NO. 100, SEC. 1, CHONGQING S. RD., TAIPEI, TAIWAN",
    "beneficiaryAccount": "DE89370400440532013000",
    "beneficiaryName": "Hans Schmidt",
    "beneficiaryAddress": "Friedrichstrasse 123, 10117 Berlin, Germany",
    "currency": "USD",
    "amount": "0000100000",
    "fxRate": "0000031500",
    "purposeCode": "10100",
    "remittanceInfo": "PAYMENT FOR GOODS",
    "detailOfCharges": "OUR",
    "correspondentBIC": "BKTRUS33XXX",
    "coreSequence": "CR_A1234567890000016000000",
    "sequenceNumber": "SW_A1234567890000016000000"
}
```

### 1.3 Success Response (報文送出成功)

```json
{
    "track_id": "sw1sw2sw3sw4sw5sw6sw7sw8sw9",
    "status": 0,
    "errors": null,
    "result": {
        "partyId": "A123456789",
        "swiftRefNo": "SWIFT20260907BANKUS33XXX000001",
        "senderBIC": "BANKUS33XXX",
        "receiverBIC": "DEUTDEFFXXX",
        "operationType": "A",
        "currency": "USD",
        "amount": "0000100000",
        "sequenceNumber": "SW_A1234567890000016000000",
        "sentAt": "20260907160005",
        "expectedAckBy": "20260909000000"
    }
}
```

### 1.4 Error Response

```json
{
    "track_id": "sw1sw2sw3sw4sw5sw6sw7sw8sw9",
    "status": 1,
    "errors": [
        {
            "error_code": "SW001",
            "message": "受款行 BIC 格式錯誤"
        }
    ],
    "result": null
}
```

### 1.5 常見錯誤代碼

| error_code | 訊息 | 業務處理 |
|---|---|---|
| SW001 | 受款行 BIC 格式錯誤 | SWIFT_SEND_FAILED,Parent 觸發退款 |
| SW002 | 受款行 BIC 不存在 | SWIFT_SEND_FAILED |
| SW003 | 受款行 BIC 已停用 | SWIFT_SEND_FAILED |
| SW004 | 匯款金額超過 SWIFT 限額 | SWIFT_SEND_FAILED |
| SW005 | 受款人資訊不完整(姓名/地址) | SWIFT_SEND_FAILED |
| SW006 | SWIFT 網路不通 | SWIFT_SEND_FAILED,可重試 |
| SW007 | 報文格式錯誤(欄位缺失) | SWIFT_SEND_FAILED |
| SW008 | AML 未通過(預先檢查) | AML_REJECTED |
| SW999 | SWIFT 系統錯誤 | timeout 處理 |

---

## 2. MT103 取消 API

**URL** : `/SWIFT/MT103/Cancel/Execute`
**Method** : `POST`
**說明** : 送出 SWIFT MT103 取消報文(用於失敗補償或業務沖銷)

### 2.1 Request 參數

| 參數名 | 類型 | 必填 | 說明 |
| --- | --- | --- | --- |
| partyId | `string` | ✓ | 匯款客戶統編 |
| originalSwiftRefNo | `string` | ✓ | 原報文的 SWIFT Ref No |
| originalSequenceNumber | `string` | ✓ | 原報文的 sequenceNumber(`SW_` 前綴) |
| transactionDate | `string` | ✓ | 取消日期 |
| transactionDateTime | `string` | ✓ | 取消時間 |
| operationType | `string` | ✓ | 固定為 `B`(取消) |
| cancelReason | `string` | ✓ | `REMITTER_RECALL` / `SYSTEM_FAILURE` / `AML_REJECTED` |
| cancelRemark | `string` | ✗ | 取消備註 |
| sequenceNumber | `string` | ✓ | 取消報文序號(prefix `SW_R_` + 19 碼,共 22 字元) |

### 2.2 Request 範例

```json
{
    "originalSwiftRefNo": "SWIFT20260907BANKUS33XXX000001",
    "originalSequenceNumber": "SW_A1234567890000016000000",
    "transactionDate": "20260907",
    "transactionDateTime": "16300000",
    "operationType": "B",
    "cancelReason": "REMITTER_RECALL",
    "cancelRemark": "客戶要求取消,款項已退回",
    "sequenceNumber": "SW_R_A1234567890000016300000"
}
```

### 2.3 Success Response

```json
{
    "track_id": "cx1cx2cx3cx4cx5cx6cx7cx8cx9",
    "status": 0,
    "errors": null,
    "result": {
        "partyId": "A123456789",
        "cancelSwiftRefNo": "SWIFT20260907BANKUS33XXX000002",
        "originalSwiftRefNo": "SWIFT20260907BANKUS33XXX000001",
        "cancelReason": "REMITTER_RECALL",
        "sequenceNumber": "SW_R_A1234567890000016300000",
        "sentAt": "20260907163005"
    }
}
```

### 2.4 常見錯誤代碼

| error_code | 訊息 | 業務處理 |
|---|---|---|
| SW010 | 原報文未找到 | SWIFT_ROLLBACK_FAILED |
| SW011 | 原報文已對方入帳,無法取消 | SWIFT_ROLLBACK_FAILED,告警人工 |
| SW012 | 原報文已過取消時限(72 小時) | SWIFT_ROLLBACK_FAILED |
| SW013 | 原報文已取消 | 視為冪等成功 |
| SW014 | 對方行已拒絕取消 | CANCEL_ROLLBACK_FAILED |
| SW999 | SWIFT 系統錯誤 | timeout 處理 |

---

## 3. MT199 查詢 API

**URL** : `/SWIFT/MT199/Query/Execute`
**Method** : `POST`
**說明** : 送出 SWIFT MT199 查詢報文,詢問對方行該筆報文狀態

### 3.1 Request 參數

| 參數名 | 類型 | 必填 | 說明 |
| --- | --- | --- | --- |
| partyId | `string` | ✓ | 匯款客戶統編 |
| originalSwiftRefNo | `string` | ✓ | 原報文的 SWIFT Ref No |
| queryType | `string` | ✓ | `STATUS` / `ACK` / `FULL` |
| sequenceNumber | `string` | ✓ | 查詢報文序號(prefix `SW_Q_` + 19 碼,共 22 字元) |

### 3.2 Request 範例

```json
{
    "originalSwiftRefNo": "SWIFT20260907BANKUS33XXX000001",
    "queryType": "FULL",
    "sequenceNumber": "SW_Q_A1234567890000018000000"
}
```

### 3.3 Success Response

```json
{
    "track_id": "qy1qy2qy3qy4qy5qy6qy7qy8qy9",
    "status": 0,
    "errors": null,
    "result": {
        "partyId": "A123456789",
        "originalSwiftRefNo": "SWIFT20260907BANKUS33XXX000001",
        "currentStatus": "ACK_RECEIVED",
        "ackReceivedAt": "20260908093000",
        "beneficiaryCreditedAt": "20260908094500",
        "sequenceNumber": "SW_Q_A1234567890000018000000"
    }
}
```

### 3.4 currentStatus 種類

| currentStatus | 業務處理 |
|---|---|
| `PENDING` | 報文已送出,尚未收到對方 ack |
| `ACK_RECEIVED` | 已收到對方 ack(尚未入帳) |
| `BENEFICIARY_CREDITED` | 對方已入帳(SUCCESS_AFTER_ACK) |
| `BENEFICIARY_REJECTED` | 對方拒絕,需走取消流程 |
| `RETURNED` | 對方已退回(Recall) |
| `CANCELLED` | 已取消 |

---

## 4. MT900 入帳通知 API

**URL** : `/SWIFT/MT900/Notify/Execute`
**Method** : `POST`
**說明** : 對方行透過 SWIFT MT900 通知入帳(由對方行主動發起,本端點為接收端)

### 4.1 Request 參數(對方行呼叫)

| 參數名 | 類型 | 必填 | 說明 |
| --- | --- | --- | --- |
| partyId | `string` | ✓ | 匯款客戶統編 |
| originalSwiftRefNo | `string` | ✓ | 原報文的 SWIFT Ref No |
| creditedAt | `string` | ✓ | 入帳時間 |
| creditedAmount | `string` | ✓ | 實際入帳金額(可能因匯率與中間行費與原匯出不同) |
| currency | `string` | ✓ | 入帳幣別 |
| ackRefNo | `string` | ✓ | 對方行的 ACK 報文編號 |
| sequenceNumber | `string` | ✓ | 通知序號(prefix `SW_N_` + 19 碼,共 22 字元) |

### 4.2 Request 範例

```json
{
    "partyId": "A123456789",
    "originalSwiftRefNo": "SWIFT20260907BANKUS33XXX000001",
    "creditedAt": "20260908094500",
    "creditedAmount": "0000099850",
    "currency": "USD",
    "ackRefNo": "ACK20260908DEUTDEFFXXX000001",
    "sequenceNumber": "SW_N_DEUTDEFFXXX000000001"
}
```

### 4.3 Success Response

```json
{
    "track_id": "no1no2no3no4no5no6no7no8no9",
    "status": 0,
    "errors": null,
    "result": {
        "partyId": "A123456789",
        "originalSwiftRefNo": "SWIFT20260907BANKUS33XXX000001",
        "creditedAt": "20260908094500",
        "creditedAmount": "0000099850",
        "sequenceNumber": "SW_N_DEUTDEFFXXX000000001",
        "notifiedAt": "20260908120000"
    }
}
```

---

## 5. MT192 退匯通知 API

**URL** : `/SWIFT/MT192/Recall/Execute`
**Method** : `POST`
**說明** : 對方行透過 SWIFT MT192 通知退匯(由對方行主動發起)

### 5.1 Request 參數(對方行呼叫)

| 參數名 | 類型 | 必填 | 說明 |
| --- | --- | --- | --- |
| partyId | `string` | ✓ | 匯款客戶統編 |
| originalSwiftRefNo | `string` | ✓ | 原報文的 SWIFT Ref No |
| recallReason | `string` | ✓ | `ACCOUNT_CLOSED` / `BENEFICIARY_UNKNOWN` / `DUPLICATE_PAYMENT` / `OTHER` |
| recallAmount | `string` | ✓ | 退匯金額 |
| currency | `string` | ✓ | 退匯幣別 |
| recallAt | `string` | ✓ | 退匯時間 |
| recallRefNo | `string` | ✓ | 對方行的退匯報文編號 |
| sequenceNumber | `string` | ✓ | 通知序號(prefix `SW_RN_` + 19 碼,共 22 字元) |

### 5.2 退匯處理流程

對方行發起退匯後,Parent 需:

1. 更新原交易狀態為 `RETURNED_PENDING`
2. 觸發 Core 退款(opType=B, seq=CR_R_xxx)
3. 退款成功 → 狀態 `RETURNED_REFUNDED`
4. 退款失敗 → 狀態 `RETURNED_PENDING`,告警人工

### 5.3 Success Response

```json
{
    "track_id": "rn1rn2rn3rn4rn5rn6rn7rn8rn9",
    "status": 0,
    "errors": null,
    "result": {
        "partyId": "A123456789",
        "originalSwiftRefNo": "SWIFT20260907BANKUS33XXX000001",
        "recallReason": "ACCOUNT_CLOSED",
        "recallAmount": "0000100000",
        "sequenceNumber": "SW_RN_DEUTDEFFXXX000000001",
        "receivedAt": "20260910120000"
    }
}
```

---

## 6. 冪等性契約

| 代號 | 規則 |
|---|---|
| **SW-IDM-01** | 同 `sequenceNumber` 重送 Send,回傳同結果(不重複發送報文) |
| **SW-IDM-02** | 同 `sequenceNumber` 重送 Cancel,回傳同結果 |
| **SW-IDM-03** | Send 的 `coreSequence` 必須對應一筆 Core SUCCESS 狀態的扣款 |
| **SW-IDM-04** | Cancel 的 `originalSequenceNumber` 必須對應一筆已送出的 Send 報文 |
| **SW-IDM-05** | Notify/Recall 接收端以 `originalSwiftRefNo + ackRefNo/recallRefNo` 為冪等鍵 |

---

## 7. SWIFT_PENDING 監控流程

```
WF-B 送出 MT103 (Send 成功)
    ↓
Parent 啟動監控排程
    ├─ 每 30 分鐘呼叫 Query (MT199)
    ├─ 收到 BENEFICIARY_CREDITED → 狀態 SUCCESS_AFTER_ACK
    ├─ 收到 BENEFICIARY_REJECTED → 觸發 Cancel (MT103 cancel)
    └─ 超過 24 小時無 ack → 告警 P2
```

---

## 8. 錯誤碼總表

| error_code | 訊息 | HTTP | 業務處理 |
|---|---|---|---|
| SW001 | 受款行 BIC 格式錯誤 | 200 | SWIFT_SEND_FAILED |
| SW002 | 受款行 BIC 不存在 | 200 | SWIFT_SEND_FAILED |
| SW003 | 受款行 BIC 已停用 | 200 | SWIFT_SEND_FAILED |
| SW004 | 匯款金額超過 SWIFT 限額 | 200 | SWIFT_SEND_FAILED |
| SW005 | 受款人資訊不完整 | 200 | SWIFT_SEND_FAILED |
| SW006 | SWIFT 網路不通 | 200 | SWIFT_SEND_FAILED,可重試 |
| SW007 | 報文格式錯誤 | 200 | SWIFT_SEND_FAILED |
| SW008 | AML 未通過(預先檢查) | 200 | AML_REJECTED |
| SW010 | 原報文未找到 | 200 | SWIFT_ROLLBACK_FAILED |
| SW011 | 原報文已對方入帳,無法取消 | 200 | SWIFT_ROLLBACK_FAILED |
| SW012 | 原報文已過取消時限 | 200 | SWIFT_ROLLBACK_FAILED |
| SW013 | 原報文已取消 | 200 | 冪等成功 |
| SW014 | 對方行已拒絕取消 | 200 | CANCEL_ROLLBACK_FAILED |
| SW999 | SWIFT 系統錯誤 | 500 | timeout 處理 |
