# 國內跨行通匯 (財金) API

**ver.** : `1.0`
**主機名稱** : 國內跨行通匯主機 (Domestic Clearing House,對接財金資訊)
**通訊方式** : API
**訊息格式** : JSON (UTF-8)
**對應業務需求書** : `remittance-requirement.md` v1.0 §4.1、BR-101~106

> 本主機負責國內跨行匯款的通匯作業,介接財金資訊的跨行通匯系統。所有 3 個端點由 Parent 的 Child Workflow (WF-A 階段 3、WF-A 退匯處理) 呼叫。

---

## 0. 端點清單

| # | 端點 | 用途 | 觸發 workflow 階段 |
|---|---|---|---|
| 1 | `POST /DomesticClearing/{partyId}/Outbound/Execute` | 跨行匯出 | WF-A 階段 3 |
| 2 | `POST /DomesticClearing/{partyId}/Query/Execute` | 查匯出狀態 | WF-A 監控、未知狀態查詢 |
| 3 | `POST /DomesticClearing/{partyId}/Return/Execute` | 退匯 | WF-A 退匯處理 |

---

## 1. 跨行匯出 API

**URL** : `/DomesticClearing/{partyId}/Outbound/Execute`
**Method** : `POST`
**說明** : 將款項從匯款行透過財金通匯系統匯至受款行

### 1.1 Request 參數

| 參數名 | 類型 | 必填 | 說明 |
| --- | --- | --- | --- |
| partyId | `string` | ✓ | 匯款客戶統編(URL path) |
| transactionType | `string` | ✓ | 固定為 `REMITTANCE` |
| transactionDate | `string` | ✓ | 交易日期 (YYYYMMDD) |
| transactionDateTime | `string` | ✓ | 交易時間 (HHMMSSxx) |
| postingDayType | `string` | ✓ | A=本日 / B=次日 |
| postingDate | `string` | ✓ | 入帳日 |
| operationType | `string` | ✓ | 固定為 `A`(匯出) |
| remitterAccount | `string` | ✓ | 匯款人帳號 |
| remitterName | `string` | ✓ | 匯款人姓名 |
| remitterBankCode | `string` | ✓ | 匯款行代號(3 碼) |
| beneficiaryAccount | `string` | ✓ | 受款人帳號 |
| beneficiaryName | `string` | ✓ | 受款人姓名 |
| beneficiaryBankCode | `string` | ✓ | 受款行代號(3 碼) |
| currency | `string` | ✓ | 幣別(僅 TWD) |
| amount | `string` | ✓ | 匯出金額(分,左補零) |
| feeAmount | `string` | ✓ | 手續費(分,通常 30 元) |
| feeBearer | `string` | ✓ | `OUR` / `BEN` / `SHA`,見下方 |
| purposeCode | `string` | ✗ | 匯款性質(國內選填) |
| memo | `string` | ✗ | 給受款人的備註(會出現在對方存摺) |
| coreSequence | `string` | ✓ | 對應 Core 扣款的 sequenceNumber(`CR_` 前綴) |
| sequenceNumber | `string` | ✓ | 通匯序號(prefix `DR_` + 19 碼,共 22 字元) |

### 1.2 繳款來源碼 (`feeBearer`)

| Code | 說明 |
|---|---|
| `OUR` | 手續費由匯款人全額負擔(已於 Core 扣款時一併扣除) |
| `BEN` | 手續費由受款人負擔(從匯出金額扣除) |
| `SHA` | 手續費各半分擔(本版不支援,僅記錄用) |

### 1.3 Request 範例

```json
{
    "transactionType": "REMITTANCE",
    "transactionDate": "20260907",
    "transactionDateTime": "15061655",
    "postingDayType": "A",
    "postingDate": "20260907",
    "operationType": "A",
    "remitterAccount": "0012345678901",
    "remitterName": "陳大文",
    "remitterBankCode": "070",
    "beneficiaryAccount": "9876543210987",
    "beneficiaryName": "王小明",
    "beneficiaryBankCode": "012",
    "currency": "TWD",
    "amount": "0000011758",
    "feeAmount": "0000000030",
    "feeBearer": "OUR",
    "purposeCode": "11000",
    "memo": "還款",
    "coreSequence": "CR_A1234567890000015061655",
    "sequenceNumber": "DR_A1234567890000015061655"
}
```

### 1.4 Success Response

```json
{
    "track_id": "dr1dr2dr3dr4dr5dr6dr7dr8dr9",
    "status": 0,
    "errors": null,
    "result": {
        "partyId": "A123456789",
        "remitterBankCode": "070",
        "beneficiaryBankCode": "012",
        "operationType": "A",
        "currency": "TWD",
        "amount": "0000011758",
        "feeAmount": "0000000030",
        "sequenceNumber": "DR_A1234567890000015061655",
        "clearingRefNo": "FI-20260907-070-012-000001",
        "settledAt": "20260907150630"
    }
}
```

### 1.5 Error Response

```json
{
    "track_id": "dr1dr2dr3dr4dr5dr6dr7dr8dr9",
    "status": 1,
    "errors": [
        {
            "error_code": "DC001",
            "message": "受款行暫停服務"
        }
    ],
    "result": null
}
```

### 1.6 常見錯誤代碼

| error_code | 訊息 | 業務處理 |
|---|---|---|
| DC001 | 受款行暫停服務 | ROLLED_BACK,Parent 觸發 Core 退款 |
| DC002 | 受款帳號不存在 | ROLLED_BACK,Parent 觸發 Core 退款 |
| DC003 | 受款帳號已凍結 | ROLLED_BACK |
| DC004 | 超過單筆限額(200 萬) | ROLLED_BACK |
| DC005 | 超過當日累計限額 | ROLLED_BACK |
| DC006 | 跨行通匯系統忙碌 | ROLLED_BACK,可重試 |
| DC007 | 匯款人帳號已被扣款但通匯失敗 | 視為 ROLLED_BACK,Parent 觸發 Core 退款 |
| DC999 | 通匯系統錯誤 | timeout 處理 |

---

## 2. 查匯出狀態 API

**URL** : `/DomesticClearing/{partyId}/Query/Execute`
**Method** : `POST`
**說明** : 依 sequenceNumber 查詢匯出狀態,用於監控與未知狀態查詢

### 2.1 Request 參數

| 參數名 | 類型 | 必填 | 說明 |
| --- | --- | --- | --- |
| partyId | `string` | ✓ | 匯款客戶統編(URL path) |
| queryType | `string` | ✓ | `OUTBOUND_STATUS` / `OUTBOUND_HISTORY` |
| sequenceNumber | `string` | ✓ | 通匯序號(prefix `DR_`) |

### 2.2 Request 範例

```json
{
    "queryType": "OUTBOUND_STATUS",
    "sequenceNumber": "DR_A1234567890000015061655"
}
```

### 2.3 Success Response

```json
{
    "track_id": "qs1qs2qs3qs4qs5qs6qs7qs8qs9",
    "status": 0,
    "errors": null,
    "result": {
        "partyId": "A123456789",
        "sequenceNumber": "DR_A1234567890000015061655",
        "clearingStatus": "SETTLED",
        "currency": "TWD",
        "amount": "0000011758",
        "feeAmount": "0000000030",
        "clearingRefNo": "FI-20260907-070-012-000001",
        "settledAt": "20260907150630"
    }
}
```

### 2.4 clearingStatus 種類

| clearingStatus | 業務處理 |
|---|---|
| `PENDING` | 已送出,尚未結算 |
| `SETTLED` | 已結算,款項已入受款帳戶 |
| `RETURNED` | 已退匯(受款行退回) |
| `FAILED` | 失敗,款項未送出 |

---

## 3. 退匯 API

**URL** : `/DomesticClearing/{partyId}/Return/Execute`
**Method** : `POST`
**說明** : 受款行主動退匯,或匯款行發現錯誤後主動召回

### 3.1 退匯觸發情境

| 情境 | 觸發方 |
|---|---|
| 受款帳號不存在,受款行退回 | 受款行(自動) |
| 受款帳號已凍結 | 受款行(自動) |
| 匯款人主動召回(尚未入受款帳) | 匯款行(透過 WF-C,本版未實作召回流程) |
| 金額錯誤 | 匯款行(透過 WF-C) |

### 3.2 Request 參數

| 參數名 | 類型 | 必填 | 說明 |
| --- | --- | --- | --- |
| partyId | `string` | ✓ | 匯款客戶統編(URL path) |
| originalSequenceNumber | `string` | ✓ | 原匯出的通匯序號(`DR_` 前綴) |
| transactionDate | `string` | ✓ | 退匯日期 |
| transactionDateTime | `string` | ✓ | 退匯時間 |
| operationType | `string` | ✓ | 固定為 `B`(退匯) |
| returnReason | `string` | ✓ | 退匯原因:`ACCOUNT_NOT_FOUND` / `ACCOUNT_FROZEN` / `AMOUNT_MISMATCH` / `REMITTER_RECALL` |
| returnRemark | `string` | ✗ | 退匯備註 |
| sequenceNumber | `string` | ✓ | 退匯序號(prefix `DR_R_` + 19 碼,共 22 字元) |

### 3.3 Request 範例

```json
{
    "originalSequenceNumber": "DR_A1234567890000015061655",
    "transactionDate": "20260907",
    "transactionDateTime": "17000000",
    "operationType": "B",
    "returnReason": "ACCOUNT_NOT_FOUND",
    "returnRemark": "受款帳號不存在",
    "sequenceNumber": "DR_R_A1234567890000017000000"
}
```

### 3.4 Success Response

```json
{
    "track_id": "rt1rt2rt3rt4rt5rt6rt7rt8rt9",
    "status": 0,
    "errors": null,
    "result": {
        "partyId": "A123456789",
        "originalSequenceNumber": "DR_A1234567890000015061655",
        "returnReason": "ACCOUNT_NOT_FOUND",
        "currency": "TWD",
        "amount": "0000011758",
        "sequenceNumber": "DR_R_A1234567890000017000000",
        "returnedAt": "20260907170005"
    }
}
```

### 3.5 Error Response

```json
{
    "track_id": "rt1rt2rt3rt4rt5rt6rt7rt8rt9",
    "status": 1,
    "errors": [
        {
            "error_code": "DC011",
            "message": "原交易已過退匯時限(當日)"
        }
    ],
    "result": null
}
```

### 3.6 常見錯誤代碼

| error_code | 訊息 | 業務處理 |
|---|---|---|
| DC010 | 原交易找不到 | FAILED,需人工核對 |
| DC011 | 原交易已過退匯時限(當日) | FAILED,需走 WF-C 沖銷 |
| DC012 | 原交易已退匯 | 視為冪等成功 |
| DC013 | 原交易尚未結算 | 等待結算後再退匯 |

---

## 4. 冪等性契約

| 代號 | 規則 |
|---|---|
| **DC-IDM-01** | 同 `sequenceNumber` 重送 Outbound,回傳同結果 |
| **DC-IDM-02** | 同 `sequenceNumber` 重送 Return,回傳同結果 |
| **DC-IDM-03** | Outbound 的 `coreSequence` 必須對應一筆 Core SUCCESS 狀態的扣款 |

---

## 5. 退匯處理流程(配合 WF-C)

當 Domestic Clearing 回傳 `clearingStatus=RETURNED` 或受款行主動發起退匯:

```
1. Domestic Clearing 主機發起退匯(透過 webhook 或 polling)
   ↓
2. Parent 收到退匯通知
   ↓
3. Parent 查原交易 row,確認原狀態為 SUCCESS
   ↓
4. Parent 更新原交易狀態為 RETURNED
   ↓
5. Parent 觸發 Core 退款(opType=B, seq=CR_R_xxx)
   ├─ 成功 → 狀態 RETURNED_REFUNDED
   └─ 失敗 → 狀態 RETURNED_PENDING,告警人工
```

> 退匯流程在本版 v1.0 為**設計預留**,實際 webhook 介接在下一版實作。

---

## 6. 錯誤碼總表

| error_code | 訊息 | HTTP | 業務處理 |
|---|---|---|---|
| DC001 | 受款行暫停服務 | 200 | ROLLED_BACK |
| DC002 | 受款帳號不存在 | 200 | ROLLED_BACK |
| DC003 | 受款帳號已凍結 | 200 | ROLLED_BACK |
| DC004 | 超過單筆限額 | 200 | ROLLED_BACK |
| DC005 | 超過當日累計限額 | 200 | ROLLED_BACK |
| DC006 | 跨行通匯系統忙碌 | 200 | ROLLED_BACK,可重試 |
| DC007 | 扣款成功但通匯失敗 | 200 | ROLLED_BACK |
| DC010 | 原交易找不到 | 200 | FAILED |
| DC011 | 已過退匯時限 | 200 | FAILED |
| DC012 | 原交易已退匯 | 200 | 冪等成功 |
| DC013 | 原交易尚未結算 | 200 | 等待 |
| DC999 | 通匯系統錯誤 | 500 | timeout 處理 |
