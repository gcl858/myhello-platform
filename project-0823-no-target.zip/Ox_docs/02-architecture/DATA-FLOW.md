# DATA-FLOW — 一筆轉帳從 HTTP 到對帳落地的全鏈路

> 所屬:[Ox_docs](../README.md) / 02 架構
> 追蹤對象:`saga2-transfer-workflow` v2.2.0(`domain-transfer/transfer-workflow/src/main/resources/saga2-transfer-workflow.sw.yaml`)
> 所有事實基於原始碼核對(引用格式:`類別#方法` 或檔名;行號為輔且**可能隨版本變動**)。

> **勘誤聲明**:本工作流實際為 **18 個 states**(以 YAML 解析逐一驗證,canonical 與 distribution 副本 diff 一致)。部分舊口徑稱「19 states」係計數錯誤;本文一切以 18 為準。

---

## 目錄

1. [場景設定](#1-場景設定)
2. [全鏈路總覽 sequenceDiagram(主幹)](#2-全鏈路總覽-sequencediagram主幹)
3. [分段精解](#3-分段精解)
4. [失敗路徑全展開](#4-失敗路徑全展開)
5. [state data 演進表(逐 state 核對)](#5-state-data-演進表逐-state-核對)
6. [五種 finalStatus × 最終輸出 × HTTP code 對照](#6-五種-finalstatus--最終輸出--http-code-對照)
7. [冪等性注意](#7-冪等性注意)
8. [常見錯誤](#8-常見錯誤)

---

## 1. 場景設定

追蹤一筆轉帳請求:

```json
POST http://localhost:8080/saga2-transfer-workflow
{ "Account_A": "A123456789", "Account_B": "B987654321", "AMT": 100 }
```

- `AMT=100`:滿足 A16229 的成功規則(AMT>50)、A16220 的成功規則(AMT<1000),且 ≤500 → 走**直接成功**主幹。
- 其他金額區間的分支(≤50、≥1000、>500)在[第 4 節](#4-失敗路徑全展開)展開。

---

## 2. 全鏈路總覽 sequenceDiagram(主幹)

涵蓋:HTTP → RuntimeFilter 快取 → 引擎 ValidateInput → 18 states 主幹(成功路徑經過 8 個)→ MyOpenApiService → mock API → AuditLog → status-rewrite 回應。失敗分支以【】標記並於第 4 節全展開。

```mermaid
sequenceDiagram
    autonumber
    actor C as Client
    participant RF as RuntimeFilter<br/>(SonataFlowSecurityConfig<br/>priority USER=2000)
    participant ENG as Workflow Engine<br/>(SonataFlow/Kogito)
    participant MOS as MyOpenApiService<br/>#callOpenApi
    participant MOCK as A16229Resource /<br/>A16220Resource<br/>(8080 self-call)
    participant ALS as AuditLogService<br/>saveLog→doSaveLog
    participant OAS as OpsAlertService#raise
    participant UF as UnwrapResponseFilter<br/>(USER=2000 先跑)
    participant WSF as WorkflowStatusFilter<br/>(USER−10=1990 後跑)

    C->>RF: POST /saga2-transfer-workflow<br/>{Account_A, Account_B, AMT}
    Note over RF: 非 POST 一律 403<br/>快取 rawInputPayload + startTimeNano<br/>ByteArrayInputStream 重設串流
    RF->>ENG: 反序列化後的請求

    rect rgb(235, 245, 255)
        note over ENG: State 1 ValidateInput(switch,jq 驗證)
        ENG->>ENG: 帳號 regex ^[A-Za-z0-9_]+$<br/>AMT 為 number 且 > 0<br/>Account_A 不等於 Account_B
        Note over ENG: 全數通過 → defaultCondition<br/>【任一命中 → §4.1 驗證失敗短路】
    end

    rect rgb(235, 255, 240)
        note over ENG,MOCK: States 2–3 CallA16229State → CheckA16229Result
        ENG->>MOS: callApiViaOpenAPI<br/>schemaRef specs/A16229-api.yaml#executeA16229<br/>payload {Account_A, AMT, EC:false}
        Note over MOS: 四層快取(operation/baseUrl/specAst/requestFields)<br/>Base URL 四規則 → http://localhost:8080<br/>HTTP timeout 預設 10s
        MOS->>MOCK: POST /A16229 {Account_A, AMT:100, EC:false}
        Note over MOCK: AMT > 50 → 成功
        MOCK-->>MOS: 200 {code:"100", message:"成功", Account}
        Note over MOS: normalizeResponse:<br/>body 自帶 code="100" → 不加 errorType<br/>補 _httpStatus=200
        MOS-->>ENG: 標準化回應
        Note over ENG: actionDataFilter → state data 新增 a16229Result
        ENG->>ENG: State 3 CheckA16229Result<br/>.a16229Result.code == "100" ✓ → CallA16220State<br/>【否則 default → §4.2 業務失敗短路】
    end

    rect rgb(235, 255, 240)
        note over ENG,MOCK: States 4–5 CallA16220State → CheckA16220Result
        ENG->>MOS: schemaRef specs/A16220-api.yaml#executeA16220<br/>payload {Account_B, AMT, EC:false}
        MOS->>MOCK: POST /A16220 {Account_B, AMT:100, EC:false}
        Note over MOCK: AMT < 1000 → 成功
        MOCK-->>MOS: 200 {code:"100", message:"成功", Account}
        MOS-->>ENG: 標準化回應(errorType 不存在,_httpStatus=200)
        Note over ENG: state data 新增 a16220Result
        ENG->>ENG: State 5 CheckA16220Result<br/>code == "100" ✓ → DecideByEvaluation<br/>【否則 default 或 platformError → §4.3 只回沖 A16229】
    end

    rect rgb(255, 248, 235)
        note over ENG: State 6 DecideByEvaluation(switch)
        ENG->>ENG: .AMT <= 500 ✓ → InjectSuccessStatus<br/>【AMT > 500 → 全回沖 LIFO,見 §3.6】
    end

    rect rgb(245, 235, 255)
        note over ENG: Inject → State 18 FinalAuditAndEnd
        ENG->>ENG: InjectSuccessStatus 注入<br/>finalStatus="SUCCESS" finalMessage="交易成功"
        ENG->>ALS: recordAuditLog(workflowId,<br/>businessKey=Account_A,<br/>processInstanceId=$WORKFLOW.instanceId,<br/>inputData/outputData 含全部結果)
        Note over ALS: WAL/busy_timeout=5000 已於啟動就緒<br/>INSERT INTO workflow_execution_log<br/>例外自吞(不拋出)
        ALS-->>ENG: {saved:true, workflowId, status}
        Note over ENG: actionDataFilter → state data 新增 auditResult
        ENG->>OAS: notifyOps(finalStatus="SUCCESS", ...)
        Note over OAS: ALERT_ON_STATUS 僅 ROLLBACK_FAILED<br/>非該狀態 → 靜默返回
        OAS-->>ENG: {raised:false}
        Note over ENG: state data 新增 opsAlert<br/>stateDataFilter.output 投影最終輸出
        ENG-->>UF: {id, workflowdata:{status, message, AMT,<br/>a16229Result, a16220Result,<br/>a16229Rollback, a16220Rollback,<br/>auditSaved, opsAlertRaised}}
    end

    Note over UF: 剝殼僅回傳 workflowdata 子物件<br/>強制 HTTP 200
    UF-->>WSF: 解包後的 entity
    Note over WSF: status="SUCCESS" 不在改寫映射<br/>(僅 VALIDATION_FAILED/ROLLBACK_FAILED)<br/>維持 200;記錄 [HTTP-AUDIT]
    WSF-->>C: HTTP 200<br/>{status:"SUCCESS", message:"交易成功", AMT:100,<br/>a16229Result:{...}, a16220Result:{...},<br/>a16229Rollback:null, a16220Rollback:null,<br/>auditSaved:true, opsAlertRaised:false}
```

> 主幹成功路徑只經過 **8 個 states**:ValidateInput → CallA16229State → CheckA16229Result → CallA16220State → CheckA16220Result → DecideByEvaluation → InjectSuccessStatus → FinalAuditAndEnd。其餘 10 個 states 服務於驗證失敗、業務失敗、平台錯誤與回沖分支([第 4 節](#4-失敗路徑全展開))。

---

## 3. 分段精解

### 3.1 HTTP 入口與 filter 鏈

進入引擎前,`RuntimeFilter`(inner class of `SonataFlowSecurityConfig`,`@Priority(USER)`=2000)執行:

| 步驟 | 行為 | 依據 |
|------|------|------|
| 路徑排除 | 去前導 `/` 後,若以 `q/` 開頭、結尾為 `.html/.js/.css/.ico`,或**包含** `reconciliation/specs/instances/jobs/trace` 字樣 → 直接放行 | `RuntimeFilter#filter` |
| 方法限制 | 非 POST → `abortWith(403 {"error": "Only POST method is allowed"})` | 同上 |
| Payload 快取 | 讀取 entity stream 為字串存入 property `rawInputPayload`,並記錄 `startTimeNano` | 同上 |
| 串流重設 | 以 `ByteArrayInputStream` 重設串流,供 SonataFlow 反序列化 | 同上 |

兩個快取值的用途:回應階段由 `WorkflowStatusFilter` 取用輸出 `[HTTP-AUDIT]`(URI/HTTP/Cost/INPUT/OUTPUT)——見 [OBSERVABILITY](OBSERVABILITY.md#3-支柱二http-狀態碼改寫status-rewrite)。

> 注意:self-call(`/A16229`、`/A16220`)同樣穿過 RuntimeFilter——這些路徑不在排除清單且是 POST,故放行並被再次快取(不影響行為)。

### 3.2 引擎啟動與 ValidateInput

YAML 宣告 `start: ValidateInput`、`workflowExecTimeout: PT5M`。ValidateInput 是 **switch state**,以 jq 條件做 workflow 內建驗證(dataInputSchema 已停用;`schemas/saga-transfer-input-schema.json` 為同步後的文件化契約):

| # | 條件名 | jq 條件 | 命中去向 |
|---|--------|---------|----------|
| 1 | accountAInvalid | `((.Account_A // "") \| match("^[A-Za-z0-9_]+$") // false) == false` | InjectValidationFailedStatus |
| 2 | accountBInvalid | 同上(Account_B) | InjectValidationFailedStatus |
| 3 | amtInvalid | `.AMT \| type != "number"`(缺失/null 自然落入) | InjectValidationFailedStatus |
| 4 | amtNotPositive | `.AMT <= 0` | InjectValidationFailedStatus |
| 5 | sameAccount | `.Account_A == .Account_B` | InjectValidationFailedStatus |
| — | defaultCondition | (以上皆未命中) | CallA16229State |

技術細節(來自 YAML 註解):jackson-jq 不支援 `test()`,改用 `match(...) // false == false` 判斷是否匹配;欄位缺失/null 先以 `// ""` 收斂為空字串,避免對 null 做 match 拋例外繞過驗證。**條件順序即回報優先序**:多欄位同時錯誤時僅回報第一個命中的分類。

此 state 也掛 `onErrors → platformError → InjectValidationFailedStatus`(jq 評估本身出錯也收斂到統一終點)。

### 3.3 CallA16229State 與 MyOpenApiService 內部

CallA16229State(operation state,`actionExecTimeout: PT15S` / `stateExecTimeout: PT30S`——刻意大於服務層 HTTP 逾時,讓服務層先回傳標準化錯誤而非引擎層中斷)透過函數定義呼叫 Java 服務:

```yaml
functions:
  - name: callApiViaOpenAPI
    operation: 'service:com.example.transfer.workflow.MyOpenApiService::callOpenApi'
    type: custom
```

`MyOpenApiService#callOpenApi(JsonNode arguments)` 內部流程:

**(1) schemaRef 解析**

- 必須含 `#`,格式如 `specs/A16229-api.yaml#executeA16229`;
- 剝除 `classpath:` 前綴後經 `PlatformPaths.normalizeClasspath()` 正規化(Windows `\` → `/`)。

**(2) 四層快取命中流程**(皆為 ConcurrentHashMap,O(1))

| 快取 | Key | 內容 | 填充者 |
|------|-----|------|--------|
| `operationCache` | `specPath#operationId` | ApiEndpoint(path, method, specDeclaredBaseUrl) | `resolveEndpoint()` 掃 paths 找 operationId |
| `baseUrlCache` | `functionName#specPath` | Base URL 字串 | `resolveBaseUrl()` → `doResolveBaseUrl()` |
| `specAstCache` | `specPath` | OpenAPI YAML 根 AST | `getSpecAst()` 由 classpath 讀取並解析 |
| `requestFieldsCache` | schemaRef | requestBody 欄位名稱清單 | `resolveRequestFieldNames()`(供 payload 過濾) |

首次呼叫依序填充(specAst → operation → baseUrl),後續呼叫全部快取命中。

**(3) Base URL 解析四規則**(`doResolveBaseUrl`,依序嘗試;全敗拋 IllegalStateException → 外層 catch 分類為 TRANSPORT):

| 規則 | 配置鍵 | 本專案實況 |
|------|--------|------------|
| 1 | `kogito.sw.functions.<functionName>.base_url` 或 `.url` | 未配置 |
| 2 | `kogito.sw.functions.<functionName>.protocol/.scheme + host + port` | **命中**:`callApiViaOpenAPI.protocol=http host=localhost port=8080`(`distribution/transfer-app/src/main/resources/application.properties` 第 48–50 行)→ `http://localhost:8080` |
| 3 | `kogito.sw.openapi.<specKey>.base_url` 或 `quarkus.rest-client.<specKey>.url`(specKey = 規格路徑把 `/`、`.` 換成 `_`) | 未配置 |
| 4 | OpenAPI spec 內 `servers[0].url`(兩支 specs 皆宣告 `http://localhost:8080/`) | 備援(本例未走到) |

**(4) 請求組裝與發送**

- timeout 三級:`arguments.timeoutSeconds` → 全域 `kogito.sw.openapi.timeout-seconds` → **預設 10 秒**(`resolveTimeout`);
- URL 組裝:`buildTargetUrl()` 替換 `{param}` 路徑參數(URL-encoded);GET/DELETE/HEAD/OPTIONS 把剩餘 payload 轉 query string;
- 支援自訂 headers(`arguments.headers`);body publisher 依 HTTP 方法決定;
- 發送走 `sendWithRetry()`:僅「未取得 HTTP 回應」的傳輸失敗才重試;已收到回應者一律交給 normalizeResponse、絕不重試——詳見[§4.5](#45-傳輸層失敗與指數退避重試)。

**(5) 回應標準化 `normalizeResponse`**

- body 為 JSON object 且自帶 `code` → 保留該碼(視為目標系統的業務碼);否則補 `code = statusCode>=400 ? "999" : "100"`;
- array body 包裝成 `{data:[...]}`;非 JSON 文字存入 `rawResponse`;204/空 body 產生 code 999/100;
- 一律補 `_httpStatus`;**僅當 code ≠ "100"** 才附加 `errorType`(成功不加,向後相容)——分類契約詳見 [OBSERVABILITY](OBSERVABILITY.md#2-支柱一errortype-四分類契約)。

**(6) 寫回 state data**

actionDataFilter 把標準化回應投影進 state data:

```yaml
actionDataFilter:
  results: '{code: .code, message: .message, Account: .Account, errorType: .errorType, _httpStatus: ._httpStatus}'
  toStateData: '${ .a16229Result }'
```

成功時來源回應不含 errorType,投影值為 null;`_httpStatus` 恆有值。

### 3.4 Mock API 的判定規則

Mock 主機端在 transfer-api 模組(同一個 8080 app 內,self-call):

| API | 成功條件 | 失敗/特殊行為 | 出處 |
|-----|----------|----------------|------|
| POST /A16229 | `AMT > 50` → 200 `{code:"100", message:"成功"(EC=true 時 "成功(EC)")}` | AMT ≤ 50 → 403 `{code:"999", message:"AMT必須大於50"}`;request null → 403 code 999;**RBFAIL 哨兵**:EC=true 且 Account_A="RBFAIL" → 403 `{code:"401", message:"回沖失敗(測試哨兵)"}` | `A16229Resource#execute` |
| POST /A16220 | `AMT < 1000` → 200 `{code:"100", ...}` | AMT ≥ 1000 → 403 `{code:"999", message:"AMT必須小於1000"}`;null → 403 code 999;RBFAIL 哨兵看 Account_B | `A16220Resource#execute` |

契約細節(`specs/A16229-api.yaml`、`specs/A16220-api.yaml`):code 為字串("100"/"999"/"401");失敗時 Account 可能為 null。mock 的 4xx 回應**body 自帶業務碼**,因此 normalizeResponse 將其分類為 BUSINESS(結果確定),而非 HTTP_4XX——這正是 RBFAIL 能穩定驅動 ROLLBACK_FAILED 測試路徑的原因。

### 3.5 Switch 分流語意

v2.2.0 樣板慣例(P2-1,YAML 註解明載):**只列正向條件,其餘一律落 default 安全分支**。三個關鍵 switch:

| State | 正向條件 | default 安全分支 | onErrors(platformError) |
|-------|----------|------------------|--------------------------|
| CheckA16229Result | `.a16229Result.code == "100"` → CallA16220State | → InjectFailedStatus(**錢還沒扣**,直接 FAILED 收尾) | → InjectFailedStatus |
| CheckA16220Result | `.a16220Result.code == "100"` → DecideByEvaluation | → RollbackA16229Only(**A16229 已扣款,必須補償**) | → RollbackA16229Only |
| DecideByEvaluation | `.AMT <= 500` → InjectSuccessStatus | → RollbackA16220(**全回沖,避免雙邊扣款卻無補償**) | → RollbackA16220 |

安全哲學:**「結果未知」視同失敗處理**(TRANSPORT/HTTP_5XX 都會讓 code ≠ "100" 落 default 走補償),寧可多回沖不可漏補償。

### 3.6 Saga LIFO 回沖

LIFO = Last-In-First-Out:**後執行者先回沖**(術語表定義)。

```mermaid
flowchart TB
    subgraph Full["全回沖路徑(AMT > 500 或評估異常)"]
        A[DecideByEvaluation<br/>default] --> B[RollbackA16220<br/>EC=true 先回沖後執行的]
        B --> C[RollbackA16229<br/>EC=true 最後回沖最先執行的]
        C --> D{CheckRollbackResults:<br/>任一回沖 code != 100?}
        D -->|是| E[InjectRollbackFailedStatus]
        D -->|否| F[InjectRolledBackStatus]
    end
    subgraph Partial["部分回沖路徑(A16220 失敗,階段 2 未扣款)"]
        G[CheckA16220Result<br/>default / platformError] --> H[RollbackA16229Only<br/>EC=true 只回沖 A16229]
        H --> I{CheckRollbackA16229OnlyResult:<br/>a16229Rollback.code == 100?}
        I -->|是| J[InjectRolledBackOnlyStatus]
        I -->|否| E
    end
    E & F & J --> K[FinalAuditAndEnd]
```

要點:

1. EC 參數語意:`false`=正常交易扣款;`true`=回沖(補償)呼叫(術語統一表);
2. 三個回沖 state 的 actionDataFilter 結構相同(results 投影五欄位),但 `toStateData` 不同:RollbackA16220 → `.a16220Rollback`;RollbackA16229 與 RollbackA16229Only → `.a16229Rollback`(單一實例只會走其中一條路徑,key 不衝突);
3. 任一回沖 state 掛 platformError → InjectRollbackFailedStatus(連「回沖動作本身炸掉」都收斂到 ROLLBACK_FAILED,不靜默);
4. CheckRollbackResults 用單一失敗條件偵測:`.a16229Rollback.code != "100" or .a16220Rollback.code != "100"` → 其餘視為全部成功。

### 3.7 FinalAuditAndEnd:對帳落地與條件告警

統一終點(operation state,`actionExecTimeout: PT10S` / `stateExecTimeout: PT20S`,**唯一不掛 onErrors 的 operation state**)依序執行兩個 action:

**Action 1 — saveFinalAuditLog(recordAuditLog)**

```yaml
arguments:
  workflowId: "saga2-transfer-workflow"
  businessKey: '${ .Account_A }'
  processInstanceId: '${ $WORKFLOW.instanceId }'
  inputData: { Account_A, Account_B, AMT }
  outputData: { status, message, AMT, a16229Result, a16220Result, a16229Rollback, a16220Rollback }
```

鏈路:`AuditLogService#saveLog(JsonNode)` → `doSaveLog()`:

1. 從 outputData 抽出 `status`/`message` 欄位(找不到時 status="UNKNOWN");
2. `INSERT INTO workflow_execution_log(workflow_id, business_key, process_instance_id, status, message, input_data, output_data)`(表結構由 `V1.0.0__create_workflow_execution_log.sql` 建立);
3. 成功回 `{saved:true, workflowId, status}`;
4. **任何例外自吞**,回 `{saved:false, error:...}`——所以本 state 不需要 onErrors,寫入結果經 actionDataFilter 收進 `auditResult.saved`(P0-5 可觀測性設計:saved=false 時輸出仍可見,不再靜默丟失)。

**Action 2 — raiseOpsAlertIfRequired(notifyOps)**

傳入 finalStatus/finalMessage/detail(兩個 rollback 結果)。`OpsAlertService#raise`:

- `finalStatus != "ROLLBACK_FAILED"` → 直接返回 `{raised:false}`,零日誌噪音;
- 命中 → 以專屬 logger `OPS-ALERT` 輸出 ERROR 級 `[OPS-ALERT]` 日誌(供 ELK/Splunk 依關鍵字接單),返回 `{raised:true}`;
- 告警通道本身故障 → 降級為一般 LOG.error 並返回 `{raised:false}`,**不阻斷交易收尾**。

結果收進 `opsAlert.raised`(P2-6)。最後 `stateDataFilter.output` 投影出最終輸出(見[第 5 節](#5-state-data-演進表逐-state-核對)表格末列)。

### 3.8 回應改寫與解包

引擎結束後,回應依序穿過兩個 response filter(JAX-RS response filter 以 priority **降序**執行):

1. `UnwrapResponseFilter`(USER=2000,先跑):entity 含 `workflowdata` 節點(Map/JsonNode/POJO 三型別皆相容)→ 剝殼只留 workflowdata 子物件,**強制 status=200**;
2. `WorkflowStatusFilter`(USER−10=1990,後跑,刻意晚於 Unwrap 以覆蓋其強制 200):
   - 取 entity 內 `status`(或 `workflowdata.status`),路徑第一段命中 `platform.status-rewrite.workflows` 名單時查映射;
   - 命中 `platform.status-rewrite.mapping`(VALIDATION_FAILED→400、ROLLBACK_FAILED→409)則覆寫 HTTP code;
   - 記錄 `[HTTP-AUDIT] URI: ... | HTTP: ... | Cost: ...ms | INPUT: ... | OUTPUT: ...`。

最終客戶端拿到的是純業務資料 + 語意正確的 HTTP 狀態碼。

---

## 4. 失敗路徑全展開

### 4.1 驗證失敗短路(VALIDATION_FAILED → HTTP 400)

```mermaid
sequenceDiagram
    autonumber
    actor C as Client
    participant ENG as Engine
    participant ALS as AuditLogService
    participant WSF as WorkflowStatusFilter

    C->>ENG: POST {Account_A:"A-12!", ...}(regex 不符)
    ENG->>ENG: ValidateInput 條件1 accountAInvalid 命中
    Note over ENG: 直接短路——不呼叫任何外部 API<br/>A16229/A16220 都不會被打到
    ENG->>ENG: InjectValidationFailedStatus 注入<br/>finalStatus="VALIDATION_FAILED"
    ENG->>ALS: FinalAuditAndEnd recordAuditLog
    ALS-->>ENG: {saved:true,...}(驗證失敗也留對帳紀錄)
    ENG-->>WSF: workflowdata.status="VALIDATION_FAILED"
    WSF-->>C: HTTP 400(映射改寫,覆蓋 Unwrap 強制的 200)
```

要點:即使輸入錯誤,AuditLog 仍落地(status=VALIDATION_FAILED)——對帳視角「沒有缺口」;HTTP 層以 400 表達「客戶端輸入錯」。

### 4.2 業務失敗短路(FAILED → HTTP 200)

觸發例:A16229 回 `403 {code:"999", message:"AMT必須大於50"}`(AMT ≤ 50)。

```mermaid
sequenceDiagram
    autonumber
    actor C as Client
    participant MOS as MyOpenApiService
    participant MOCK as A16229Resource
    participant ENG as Engine

    C->>ENG: POST {..., AMT:30}
    ENG->>MOS: CallA16229State(EC=false)
    MOS->>MOCK: POST /A16229 {AMT:30}
    MOCK-->>MOS: 403 {code:"999", message:"AMT必須大於50"}
    Note over MOS: normalizeResponse:<br/>body 自帶 code 且 != "100"<br/>errorType=BUSINESS,_httpStatus=403<br/>(結果確定)
    MOS-->>ENG: a16229Result={code:"999", errorType:BUSINESS,...}
    ENG->>ENG: CheckA16229Result 正向條件不成立<br/>default → InjectFailedStatus
    Note over ENG: 此時 A16229 未扣款成功<br/>無需補償,直接 FAILED 收尾
    ENG-->>C: HTTP 200(FAILED 不在改寫映射)<br/>{status:"FAILED", message:"業務失敗或 API 錯誤",<br/>a16229Result:{...}, a16220Result:null}
```

要點:

- 「業務確定失敗」與「結果未知」在此分流上待遇相同(都落 default),差別在 state data 裡的 errorType 供稽核判讀;
- A16220 階段的業務失敗**不走此短路**,而走[§4.3](#43-平台錯誤兜底platformerror-收斂)的部分回沖路徑(A16229 已扣款);
- FAILED 維持 HTTP 200(映射未列出者保持引擎原碼)——語意:「流程完成且已記錄,但業務結果為失敗」。

### 4.3 平台錯誤兜底(platformError 收斂)

`errors.platformError`(code='PLATFORM_ERROR';Kogito codegen 要求 error 定義必須含 code)攔截各 state 的非預期例外:state/action timeout 中斷、jq 評估錯誤、引擎或服務層未攔截的例外。設計目標(YAML 第 49–56 行):**任何錯誤都收斂到 FinalAuditAndEnd,避免 AuditLog 缺失造成對帳缺口**。注意:MyOpenApiService 自吞例外回標準化 body,因此 HTTP 業務/傳輸失敗**不會**走這條路,仍由 switch 判斷。

兜底分流依「錢動了沒」:

```mermaid
flowchart TB
    PE[platformError 觸發點] -->|ValidateInput| IVF[InjectValidationFailedStatus]
    PE -->|CallA16229State / CheckA16229Result<br/>錢還沒動| IF[InjectFailedStatus]
    PE -->|CallA16220State / CheckA16220Result<br/>A16229 已扣款| R29O[RollbackA16229Only]
    PE -->|DecideByEvaluation<br/>兩筆都扣款| RA220[RollbackA16220]
    R29O --> CR29O{CheckRollbackA16229OnlyResult}
    CR29O -->|回沖 code==100| IRBO[InjectRolledBackOnlyStatus]
    CR29O -->|失敗| IRF[InjectRollbackFailedStatus]
    RA220 --> LIFO[LIFO 全回沖鏈<br/>RollbackA16220 → RollbackA16229]
    LIFO --> CRR{CheckRollbackResults}
    CRR -->|皆成功| IRB[InjectRolledBackStatus]
    CRR -->|任一失敗| IRF
    IF & IVF & IRBO & IRB & IRF --> FAE[FinalAuditAndEnd]
```

時序範例(CallA16220State 平台錯誤):

```mermaid
sequenceDiagram
    autonumber
    actor C as Client
    participant ENG as Engine
    participant MOS as MyOpenApiService
    participant MOCK as A16229Resource
    participant OAS as OpsAlertService

    C->>ENG: POST {..., AMT:100}
    ENG->>MOS: CallA16229State 成功(a16229Result.code="100")
    Note over ENG: CallA16220State 執行中引擎層中斷<br/>(actionExecTimeout PT15S 或未捕捉例外)
    Note over ENG: onErrors platformError 攔截
    ENG->>ENG: → RollbackA16229Only(EC=true)<br/>補償階段 1 已成功的 A16229
    ENG->>MOS: POST /A16229 {Account_A, AMT, EC:true}
    MOCK-->>MOS: 200 {code:"100", message:"成功(EC)"}
    ENG->>ENG: CheckRollbackA16229OnlyResult 通過<br/>→ InjectRolledBackOnlyStatus<br/>finalMessage="A16220 業務失敗,僅回沖 A16229"
    ENG->>OAS: notifyOps(finalStatus="ROLLED_BACK") → raised:false
    ENG-->>C: HTTP 200 {status:"ROLLED_BACK", ...}
```

> 若 RollbackA16229Only 本身也失敗(其 platformError 或 CheckRollbackA16229OnlyResult default)→ InjectRollbackFailedStatus → 接續 [§4.4](#44-回沖失敗rollback_failed--ops-alert--http-409) 流程。

### 4.4 回沖失敗(ROLLBACK_FAILED → [OPS-ALERT] → HTTP 409)

標準測法(RBFAIL 哨兵):帳號填 `RBFAIL` 且 EC=true 時,mock 強制回 403 + code 401(`A16229Resource#execute` / `A16220Resource#execute`)。以下以「AMT=600 且 Account_A=RBFAIL」走全回沖路徑為例:

```mermaid
sequenceDiagram
    autonumber
    actor C as Client
    participant ENG as Engine
    participant MOS as MyOpenApiService
    participant MOCK as Mock Resources<br/>(A16220 / A16229)
    participant ALS as AuditLogService
    participant OAS as OpsAlertService#raise
    participant WSF as WorkflowStatusFilter

    C->>ENG: POST {Account_A:"RBFAIL", AMT:600}
    Note over ENG: A16229 扣款成功(600>50)、<br/>DecideByEvaluation:600>500 → 全回沖
    ENG->>MOS: RollbackA16220(EC=true)先執行
    MOS->>MOCK: POST /A16220 {Account_B, AMT, EC:true}
    MOCK-->>MOS: 200 {code:"100", message:"成功(EC)"}
    Note over ENG: a16220Rollback.code="100"<br/>接著 RollbackA16229(EC=true)
    ENG->>MOS: POST /A16229 {Account_A:"RBFAIL", EC:true}
    Note over MOS: 轉發至 A16229Resource:<br/>RBFAIL 哨兵命中
    MOS-->>ENG: a16229Rollback={code:"401",<br/>errorType:BUSINESS,_httpStatus:403}
    Note over ENG: CheckRollbackResults:<br/>anyRollbackFailed 條件命中<br/>(a16229Rollback.code != "100")
    ENG->>ENG: InjectRollbackFailedStatus<br/>finalStatus="ROLLBACK_FAILED"
    ENG->>ALS: recordAuditLog(outputData 含兩個 rollback 結果)
    ALS-->>ENG: {saved:true}
    ENG->>OAS: notifyOps(finalStatus="ROLLBACK_FAILED",<br/>detail={a16229Rollback, a16220Rollback})
    Note over OAS: ALERT_ON_STATUS 命中<br/>logger "OPS-ALERT" 輸出 ERROR:<br/>[OPS-ALERT] 回沖失敗,需人工介入 | ...
    OAS-->>ENG: {raised:true}
    ENG-->>WSF: status="ROLLBACK_FAILED"
    WSF-->>C: HTTP 409(映射 ROLLBACK_FAILED=409)<br/>{status:"ROLLBACK_FAILED", opsAlertRaised:true,...}
```

三層防護一次到位:**對帳紀錄**(status=ROLLBACK_FAILED 完整落地)、**運維告警**([OPS-ALERT] ERROR 日誌供接單)、**HTTP 語意**(409 Conflict 表達「需人工介入」)。

### 4.5 傳輸層失敗與指數退避重試

`MyOpenApiService#sendWithRetry`:僅 `exceptionally`(連線拒絕、逾時、IO 錯誤等**未取得 HTTP 回應**)才重試;已收到 HTTP 回應(含 4xx/5xx)一律不重試。

```mermaid
flowchart TB
    SEND["sendAsync"] -->|"有回應"| NORM["normalizeResponse<br/>(絕不重試)"]
    SEND -->|exceptionally 傳輸失敗| CHK{"attempt < maxAttempts?"}
    CHK -->|"是"| SLEEP["sleep backoffMs =<br/>delayMs × 2^(attempt−1)"]
    SLEEP --> SEND2["重送(attempt+1)"]
    CHK -->|"否(達上限)"| TE["transportError:<br/>{code:'999', errorType:TRANSPORT,<br/>_httpStatus:0}"]
    NORM --> SW["switch 判斷 code != '100'<br/>→ 視同失敗分流"]
    TE --> SW
```

參數解析(`resolveRetryMaxAttempts` / `resolveRetryDelayMs`):`arguments.retryMaxAttempts` / `arguments.retryDelayMs`(單次覆寫)→ 全域 `kogito.sw.openapi.transport-retry.max-attempts`(預設 **1 = 不重試**)/ `.delay-ms`(預設 500ms);次數上限防呆 5 次、退避因子固定 2.0。

語意關鍵:TRANSPORT 代表「結果未知」——目標系統可能已執行。工作流端把它與業務失敗同等處理(落 default → FAILED 或補償),但 state data 的 errorType 保留「未知」訊號供人工/稽核判讀。金融場景下這正是 Saga 模式「寧可保守」的體現。

> 注意:mock API 是 self-call(localhost:8080),傳輸失敗在實務上多見於真實外部依賴;transfer-app 的 `%test` profile 將測試 port 固定 8080 讓 self-call 可命中。

### 4.6 兜底中的兜底:對帳寫入失敗與告警降級

FinalAuditAndEnd 自身的兩個依賴也可能故障,但兩者都被設計成**不阻斷收尾**:

| 故障 | 行為 | 輸出訊號 | 依據 |
|------|------|----------|------|
| AuditLogService 寫入例外(如 SQLITE_BUSY 逾時) | `doSaveLog` catch 全部例外,回 `{saved:false, error:...}`,不拋出 | `auditSaved=false` 浮現於最終輸出與 [HTTP-AUDIT] 日誌;失敗細節由服務層 ERROR 日誌追查 | `AuditLogService#doSaveLog`(第 204–210 行) |
| OpsAlertService 告警通道故障 | catch 後改以一般 logger 記錄,回 `{raised:false}` | `opsAlertRaised=false`;不重拋、不影響 HTTP 回應 | `OpsAlertService#raise`(catch 區塊) |

設計哲學:稽核與告警是「最佳努力」——它們的故障不得讓一筆已完成的業務交易卡死;但結果必須**可見**(輸出欄位 + 日誌),不能靜默丟失。

---

## 5. state data 演進表(逐 state 核對)

核對方法:逐一檢視 saga2 YAML 每個 state 的 `actionDataFilter.toStateData` / inject `data` / `stateDataFilter.output`,下表即原始碼的逐項映射。**初始鍵**來自啟動請求 body(引擎將其載入 state data)。

### 5.1 初始 state data

| 鍵 | 來源 | 備註 |
|----|------|------|
| `Account_A` | 請求 body | ValidateInput 驗證;後續作為 businessKey |
| `Account_B` | 請求 body | ValidateInput 驗證 |
| `AMT` | 請求 body | number 且 >0;決定 DecideByEvaluation 分流 |
| (其他請求欄位) | 請求 body | 未驗證、未使用,僅存於 input 快取 |

### 5.2 各 state 執行後新增/變動的鍵

| # | State | 型別 | 新增鍵 | 內容結構 | YAML 依據(`toStateData`/data) |
|---|-------|------|--------|----------|-------------------------------|
| 1 | ValidateInput | switch | —(無 action) | — | dataConditions 僅讀取 |
| 2 | CallA16229State | operation | **`a16229Result`** | `{code, message, Account, errorType?, _httpStatus}`(成功時 errorType 為 null) | `'${ .a16229Result }'` |
| 3 | CheckA16229Result | switch | — | — | 讀 `.a16229Result.code` |
| 4 | CallA16220State | operation | **`a16220Result`** | 同上結構 | `'${ .a16220Result }'` |
| 5 | CheckA16220Result | switch | — | — | 讀 `.a16220Result.code` |
| 6 | DecideByEvaluation | switch | — | — | 讀 `.AMT` |
| 7 | RollbackA16220 | operation | **`a16220Rollback`** | `{code, message, Account, errorType?, _httpStatus}`(EC=true 呼叫) | `'${ .a16220Rollback }'` |
| 8 | RollbackA16229 | operation | **`a16229Rollback`** | 同上(EC=true) | `'${ .a16229Rollback }'` |
| 9 | RollbackA16229Only | operation | **`a16229Rollback`** | 同上;與 #8 同鍵但單一實例只走其一 | `'${ .a16229Rollback }'` |
| 10 | CheckRollbackResults | switch | — | — | 讀兩個 rollback 的 code |
| 11 | CheckRollbackA16229OnlyResult | switch | — | — | 讀 `.a16229Rollback.code` |
| 12 | InjectValidationFailedStatus | inject | **`finalStatus`**, **`finalMessage`** | `"VALIDATION_FAILED"` / "輸入欄位格式錯誤 (帳號僅限英數字與底線且兩者不得相同;AMT 須為大於 0 的數字)" | `data:` 區塊 |
| 13 | InjectSuccessStatus | inject | finalStatus, finalMessage | `"SUCCESS"` / "交易成功" | `data:` |
| 14 | InjectFailedStatus | inject | finalStatus, finalMessage | `"FAILED"` / "業務失敗或 API 錯誤" | `data:` |
| 15 | InjectRolledBackStatus | inject | finalStatus, finalMessage | `"ROLLED_BACK"` / "AMT > 500 觸發 saga 回沖 (LIFO)" | `data:` |
| 16 | InjectRolledBackOnlyStatus | inject | finalStatus, finalMessage | `"ROLLED_BACK"` / "A16220 業務失敗,僅回沖 A16229" | `data:` |
| 17 | InjectRollbackFailedStatus | inject | finalStatus, finalMessage | `"ROLLBACK_FAILED"` / "⚠️ 回沖失敗,需人工介入處理" | `data:` |
| 18 | FinalAuditAndEnd(action1 saveFinalAuditLog) | operation | **`auditResult`** | `{saved: true|false}`(服務端另回 workflowId/status,被 results 過濾掉) | `'${ .auditResult }'` |
| 18 | FinalAuditAndEnd(action2 raiseOpsAlertIfRequired) | operation | **`opsAlert`** | `{raised: true|false}` | `'${ .opsAlert }'` |

### 5.3 最終輸出投影(stateDataFilter.output)

State data 內部累積了上述所有鍵,但 FinalAuditAndEnd 的 `stateDataFilter.output` 只投影以下九欄成為 workflowdata(即解包後的客戶端回應):

```jq
{
  status: .finalStatus,
  message: .finalMessage,
  AMT: .AMT,
  a16229Result: (.a16229Result // null),
  a16220Result: (.a16220Result // null),
  a16229Rollback: (.a16229Rollback // null),
  a16220Rollback: (.a16220Rollback // null),
  auditSaved: (.auditResult.saved // false),
  opsAlertRaised: (.opsAlert.raised // false)
}
```

`// null` / `// false` 保證未走到分支時輸出仍形狀完整(null/false 而非缺欄)——這是契約穩定性的關鍵:客戶端永遠拿到同一組欄位。

### 5.4 三條代表性路徑的實際演進

| 路徑 | state data 累積順序 |
|------|---------------------|
| 直接成功(50<AMT≤500<1000) | Account_A/B, AMT → `a16229Result` → `a16220Result` → finalStatus/finalMessage → `auditResult` → `opsAlert` |
| A16220 失敗(AMT≥1000) | … → `a16229Result` → `a16220Result`(code=999)→ `a16229Rollback`(RollbackA16229Only)→ finalStatus/finalMessage → `auditResult` → `opsAlert` |
| 全回沖且 RBFAIL(AMT>500) | … → `a16229Result` → `a16220Result` → `a16220Rollback` → `a16229Rollback`(code=401)→ finalStatus/finalMessage → `auditResult` → `opsAlert` |

---

## 6. 五種 finalStatus × 最終輸出 × HTTP code 對照

| finalStatus | 觸發路徑 | a16229Result | a16220Result | rollback 欄位 | auditSaved | opsAlertRaised | HTTP |
|-------------|----------|--------------|--------------|----------------|------------|----------------|------|
| `SUCCESS` | 50<AMT≤500 全數成功 | code=100 | code=100 | null/null | true(預期) | false | **200** |
| `FAILED` | A16229 失敗/未知短路 | code≠100 | null | null/null | true(預期) | false | **200** |
| `ROLLED_BACK`(全回沖) | AMT>500 或評估異常 | code=100 | code=100 | 兩者皆 code=100 | true(預期) | false | **200** |
| `ROLLED_BACK`(僅回沖) | A16220 階段失敗/平台錯誤 | code=100 | code≠100 或不存在 | 僅 a16229Rollback=100 | true(預期) | false | **200** |
| `VALIDATION_FAILED` | ValidateInput 任一條件命中 | null | null | null/null | true(預期) | false | **400** |
| `ROLLBACK_FAILED` | 任一回沖結果 code≠100 | (依路徑) | (依路徑) | 至少一個 code≠100 | true(預期) | **true**([OPS-ALERT]) | **409** |

> `auditSaved=true` 為「正常預期」;一旦為 false,代表對帳落地失敗(見[§4.6](#46-兜底中的兜底對帳寫入失敗與告警降級)),需由維運從服務層 ERROR 日誌與 [HTTP-AUDIT] 追查。

---

## 7. 冪等性注意

YAML 描述區明確聲明:**本 workflow 未內建請求去重**——同一請求重送將產生獨立的流程實例與重複交易。金融場景建議:

1. 呼叫端於 Header 攜帶 Idempotency-Key,由 API Gateway / 入口層依 key 去重;或
2. 於業務 API 層對業務鍵建唯一約束。

這在重試語意上尤其重要:TRANSPORT 類錯誤代表「目標系統可能已執行」,若呼叫端自行重試整筆交易而無去重保護,可能造成雙重扣款。

---

## 8. 常見錯誤

1. **以為 switch 條件要寫成敘列**(success/failure 各一條)→ v2.2.0 樣板慣例(P2-1)只寫正向條件 + 安全 default;多寫的全覆蓋條件是冗餘且易與 default 打架。
2. **把 actionDataFilter.results 寫成整顆回應**(`.`)→ 樣板刻意投影五個欄位(code/message/Account/errorType/_httpStatus),避免 mock 未來加欄位時污染 state data。
3. **誤以為 HTTP 4xx/5xx 一定分類為 HTTP_4XX/HTTP_5XX** → 只要 body 自帶業務碼(如 mock 的 403+code 999、RBFAIL 的 403+code 401),一律歸 BUSINESS。判定流程詳見 [OBSERVABILITY](OBSERVABILITY.md#2-支柱一errortype-四分類契約)。
4. **期待 FAILED 也回 HTTP 非 2xx** → 改寫映射只含 VALIDATION_FAILED→400 與 ROLLBACK_FAILED→409;其餘 status(SUCCESS/FAILED/ROLLED_BACK)保持引擎原碼 200。要新增映射改 `platform.status-rewrite.mapping` 即可,免改 Java。
5. **在回沖 state 上漏掛 onErrors** → 回沖中的 platformError 若未收斂會直接炸掉實例且 AuditLog 缺失;樣板中三個回沖 state 都掛 InjectRollbackFailedStatus,新 workflow 必須照抄。
6. **FinalAuditAndEnd 加上 onErrors「以防萬一」** → 多此一舉且誤導:`doSaveLog` 與 `raise` 都自吞例外,platformError 在此 state 幾乎不可能;真要防的是上層 `workflowExecTimeout: PT5M`。
7. **忘記 `$WORKFLOW.instanceId` 是表達式而非字串** → businessKey/processInstanceId 要能關聯 Data Index,靠的就是正確的表達式取值;寫死字串會讓對帳紀錄對不上流程實例。
8. **把 timeout 防線調得比 HTTP 逾時短** → `actionExecTimeout` 必須大於 MyOpenApiService 的 10 秒 HTTP timeout(樣板用 PT15S),否則引擎先中斷走 platformError,失去標準化 errorType 分類資訊。
9. **引用 states 數量說「19」** → v2.2.0 實際為 **18**;新增/刪除 state 後請重新以 YAML 解析計數並同步所有文件。
10. **驗證規則改了卻忘了同步 finalMessage 與 JSON schema 文件** → InjectValidationFailedStatus 的訊息與 `schemas/saga-transfer-input-schema.json` 都必須與 ValidateInput 的 jq 條件三者一致(YAML 註解明言此同步義務)。

---

## 相關文件

- [ARCHITECTURE](ARCHITECTURE.md) — 三層架構、部署模型、filter 鏈排序原理
- [OBSERVABILITY](OBSERVABILITY.md) — errorType 判定流程、status-rewrite 配置、節點軌跡
- [SAGA2-TEMPLATE-DEEP-DIVE](../03-workflow-dev-guide/SAGA2-TEMPLATE-DEEP-DIVE.md) — 18 個 states 逐段精解
- [WORKFLOW-COOKBOOK](../03-workflow-dev-guide/WORKFLOW-COOKBOOK.md) — Saga LIFO / 安全 switch / jq 寫法配方
- [SERVICE-REFERENCE](../04-reference/SERVICE-REFERENCE.md) — MyOpenApiService/AuditLogService/OpsAlertService 手冊
- [REST-API-REFERENCE](../04-reference/REST-API-REFERENCE.md) — 啟動 API 與 mock API 規格
- [TESTING-GUIDE](../06-testing/TESTING-GUIDE.md) — RBFAIL 哨兵與四測試類實操
