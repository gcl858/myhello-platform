# Ox_docs — myhello-platform 完整技術文件集

> 本文件集為 **全新撰寫**(100% 基於原始碼分析),以 `domain-transfer/transfer-workflow/src/main/resources/saga2-transfer-workflow.sw.yaml`(v2.2.0)作為新 workflow 開發的核心範本。
> 讀者對象:人類開發者。風格:百科詳盡,所有關鍵論述附原始碼位置(以「類別#方法」為主,行號為輔且可能隨版本變動)。

## 專案一句話簡介

`myhello-platform` 是一個 Maven 多模組 **SonataFlow/Kogito 10.2.0 + Quarkus 3.27.2** 企業級工作流平台:平台層(`platform-*`)提供安全過濾、Data Index 與 SQLite 擴展;業務域(`domain-transfer` 轉帳 / `domain-reconciliation` 對帳)以 Serverless Workflow YAML 定義 Saga 補償流程;最終由 `distribution/*` 組裝成兩個可執行 Quarkus 應用(8080 讀寫交易、8090 唯讀對帳),共享單一 `reconciliation.db`(WAL 模式)。

## 文件總索引

| # | 文件 | 內容 | 適合誰 |
|---|------|------|--------|
| — | [本頁 README](README.md) | 總索引與閱讀路徑 | 所有人 |
| 01 | [GETTING-STARTED](01-getting-started/GETTING-STARTED.md) | 環境需求、建置(mvn/離線)、啟動雙 app、跑第一筆轉帳 | 所有人 |
| 01 | [PROJECT-LAYOUT](01-getting-started/PROJECT-LAYOUT.md) | 目錄地圖、模組依賴 DAG、單一事實來源規則 | 所有人 |
| 02 | [ARCHITECTURE](02-architecture/ARCHITECTURE.md) | 三層架構、雙 app 部署模型、SQLite WAL 共享、核心不變式 | 架構師/後端 |
| 02 | [DATA-FLOW](02-architecture/DATA-FLOW.md) | 一筆轉帳從 HTTP 到對帳落地的全鏈路時序 | 後端/維運 |
| 02 | [OBSERVABILITY](02-architecture/OBSERVABILITY.md) | errorType 分類、HTTP 改寫、OPS-ALERT、節點軌跡、GraphQL | 後端/SRE |
| 03 | [SAGA2-TEMPLATE-DEEP-DIVE](03-workflow-dev-guide/SAGA2-TEMPLATE-DEEP-DIVE.md) ★ | saga2 v2.2.0 全部 18 states 逐段精解 | workflow 開發者 |
| 03 | [NEW-WORKFLOW-GUIDE](03-workflow-dev-guide/NEW-WORKFLOW-GUIDE.md) ★ | 從零開發新 workflow 的 8 步 SOP + 上線 checklist | workflow 開發者 |
| 03 | [WORKFLOW-COOKBOOK](03-workflow-dev-guide/WORKFLOW-COOKBOOK.md) ★ | 12 道模式配方(Saga LIFO/安全 switch/jq 寫法…) | workflow 開發者 |
| 04 | [REST-API-REFERENCE](04-reference/REST-API-REFERENCE.md) | 轉帳 mock API、workflow 啟動 API、對帳 16 endpoints | 前後端/測試 |
| 04 | [SERVICE-REFERENCE](04-reference/SERVICE-REFERENCE.md) | MyOpenApiService/AuditLogService/OpsAlertService/SagaApiService 手冊 | 後端 |
| 04 | [DATABASE-REFERENCE](04-reference/DATABASE-REFERENCE.md) | reconciliation.db 全表、view、遷移體系、WAL 運維 | 後端/DBA |
| 04 | [CONFIG-REFERENCE](04-reference/CONFIG-REFERENCE.md) | application.properties 全參數、環境變數、kogito.sw.* | 後端/維運 |
| 05 | [PLATFORM-MODULES](05-platform/PLATFORM-MODULES.md) | platform-common/security/data-index/extensions 元件手冊 | 平台開發者 |
| 06 | [TESTING-GUIDE](06-testing/TESTING-GUIDE.md) | 4 測試類 37 tests 詳解(18+3+2+14)、RBFAIL 哨兵、新測試模板 | QA/開發者 |
| 07 | [TROUBLESHOOTING](07-operations/TROUBLESHOOTING.md) | 已知地雷症狀→原因→解法對照 | 維運/開發者 |
| 07 | [UI-PAGES](07-operations/UI-PAGES.md) | 8 個內建 HTML 頁面功能導覽 | 所有人 |

★ = 核心三份,開發新 workflow 前必讀

## 依角色建議閱讀路徑

```mermaid
flowchart LR
    subgraph 新進成員
        A1[GETTING-STARTED] --> A2[PROJECT-LAYOUT] --> A3[ARCHITECTURE] --> A4[UI-PAGES]
    end
    subgraph 要開發新 Workflow
        B1[SAGA2-TEMPLATE-DEEP-DIVE] --> B2[NEW-WORKFLOW-GUIDE] --> B3[WORKFLOW-COOKBOOK] --> B4[SERVICE-REFERENCE] --> B5[TESTING-GUIDE]
    end
    subgraph 維運值班
        C1[TROUBLESHOOTING] --> C2[CONFIG-REFERENCE] --> C3[OBSERVABILITY] --> C4[DATABASE-REFERENCE]
    end
    subgraph 整合測試
        D1[REST-API-REFERENCE] --> D2[DATA-FLOW] --> D3[TESTING-GUIDE]
    end
```

## 模組全景圖

```mermaid
flowchart TB
    subgraph Platform["platform-* 平台層"]
        PC[platform-common<br/>PlatformPaths]
        PS[platform-security<br/>filter 鏈]
        PE[platform-extensions<br/>SQLite Data Index 擴展]
        PDI[platform-data-index<br/>Dialect/ConfigSource/Tracing]
    end
    subgraph DomainTransfer["domain-transfer 轉帳域"]
        TAPI[transfer-api<br/>A16220/A16229 mock+spec]
        TWF[transfer-workflow<br/>saga2 + saga v15 .sw.yaml]
        TSAMP[transfer-samples<br/>示範 workflows]
    end
    subgraph DomainRec["domain-reconciliation 對帳域"]
        RAPI[reconciliation-api<br/>AuditLog/CsvExporter/REST]
    end
    subgraph Distribution["distribution 可執行應用"]
        TA[transfer-app :8080<br/>讀寫 reconciliation.db]
        RA[reconciliation-app :8090<br/>read-only]
    end
    PC --> PS & PDI & TAPI
    PDI --> RAPI
    TAPI --> TWF
    TAPI --> TSAMP
    TWF -. "僅用 AuditLogService 介面" .-> RAPI
    PC & PS & PDI --> TA
    TAPI & TWF & TSAMP & RAPI --> TA
    PC & PS & PDI --> RA
    RAPI --> RA
    TA -. "共享 volume" .-> RA
```

## 術語統一表(全套文件通用)

| 術語 | 意義 |
|------|------|
| `saga2-transfer-workflow` v2.2.0 | 本文件集的開發範本 workflow(MyOpenApiService 路線,18 states:6 switch + 6 operation + 6 inject) |
| `saga-transfer-workflow` v15 | 舊版主流程(SagaApiService 直打 REST 路線),僅作對照 |
| Saga LIFO 回沖 | 補償順序=後執行者先回沖(RollbackA16220 → RollbackA16229) |
| EC 參數 | `false`=正常交易扣款;`true`=回沖(補償)呼叫 |
| finalStatus | 工作流輸出狀態:`SUCCESS` / `FAILED` / `ROLLED_BACK` / `ROLLBACK_FAILED` / `VALIDATION_FAILED` |
| errorType | MyOpenApiService 回應錯誤分類:`TRANSPORT` / `BUSINESS` / `HTTP_4XX` / `HTTP_5XX` |
| RBFAIL 哨兵 | 帳號填 `RBFAIL` 且 EC=true 時,mock API 強制回沖失敗(code=401),供測試 ROLLBACK_FAILED→HTTP 409 |
| status-rewrite | `platform.status-rewrite.*` 配置:依輸出 status 改寫 HTTP code(400/409) |
| OPS-ALERT | 專屬 SLF4J logger 名稱,`[OPS-ALERT]` ERROR 日誌通道,僅 ROLLBACK_FAILED 觸發 |
| 單一事實來源 | canonical 資源在 `domain-*` 各模組;`distribution/transfer-app/src/main/resources` 為建置同步副本,勿手改 |
| 版本基準 | Java 17 · Quarkus 3.27.2 · KIE/Kogito 10.2.0 · sqlite-jdbc 3.45.1.0 |

## 引用慣例

- 原始碼引用格式:`類別#方法`(如 `MyOpenApiService#callOpenApi`)或檔名(如 `saga2-transfer-workflow.sw.yaml`)。
- 行號僅在必要時輔助,並標注「行號可能隨版本變動」。
- 文件間連結使用相對路徑。
