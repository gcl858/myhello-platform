# WORKFLOW-COOKBOOK — 12 道模式配方

> 每道配方 = 問題 / 解法 / YAML 片段(**全部取自 `saga2-transfer-workflow.sw.yaml` 實碼**,標注來源 state)/ 變體。原理深究見 [SAGA2-TEMPLATE-DEEP-DIVE](SAGA2-TEMPLATE-DEEP-DIVE.md);落地步驟見 [NEW-WORKFLOW-GUIDE](NEW-WORKFLOW-GUIDE.md)。

## 配方總索引

| # | 配方 | 一句話 |
|---|------|--------|
| ① | Saga LIFO 補償編排 | 後執行者先回沖 |
| ② | 安全 switch | default 同向策略 |
| ③ | 平台錯誤收斂 | onErrors 表驅動 |
| ④ | 統一終點+輸出模板 | 形狀固定的回應 |
| ⑤ | 條件運維告警 | OpsAlertService 模式 |
| ⑥ | 對帳落地 | AuditLogService + 吞例外 |
| ⑦ | OpenAPI 動態呼叫 | schemaRef#operationId |
| ⑧ | timeout 防線配置 | 四層由內到外遞增 |
| ⑨ | jq 安全寫法大全 | null 收斂/match 替代 test/type 檢查 |
| ⑩ | Data Index metadata 標籤查詢 | 四標籤+已驗證 GraphQL |
| ⑪ | HTTP status 對外語義化 | status-rewrite 400/409 |
| ⑫ | 冪等性策略 | Idempotency-Key 於 Gateway 層 |

---

## 配方①:Saga LIFO 補償編排

**問題**:兩階段外部動帳(A16229 扣款 → A16220 入帳),任一階段失敗或業務規則要求取消時,必須把「已完成」的階段逆序退回,且不得多退、少退或中途中斷。

**解法**:為每個已執行的外部呼叫準備 EC=true 的補償版;按 **LIFO(後執行先回沖)** 鏈式串接;每條回沖路徑末端設結果檢查 switch。saga2 有兩條路徑:全回沖(RollbackA16220→RollbackA16229)與僅回沖階段1(RollbackA16229Only)。

```yaml
# LIFO 第一步: 回沖 A16220 (EC=true)
- name: RollbackA16220
  type: operation
  ...
  actions:
    - name: rollbackA16220Action
      functionRef:
        refName: callApiViaOpenAPI
        arguments:
          functionName: "callApiViaOpenAPI"
          schemaRef: 'specs/A16220-api.yaml#executeA16220'
          payload:
            Account_B: '${ .Account_B }'
            AMT: '${ .AMT }'
            EC: true
      actionDataFilter:
        results: '{code: .code, message: .message, Account: .Account, errorType: .errorType, _httpStatus: ._httpStatus}'
        toStateData: '${ .a16220Rollback }'
  transition: RollbackA16229
```
(來源:`saga2-transfer-workflow.sw.yaml` state `RollbackA16220`;`RollbackA16229` 以 EC=true 呼叫 A16229 接 `CheckRollbackResults`)

結果檢查——單一失敗條件,未知狀態歸入失敗側:

```yaml
- name: CheckRollbackResults
  type: switch
  dataConditions:
    - name: anyRollbackFailed
      condition: '${ .a16229Rollback.code != "100" or .a16220Rollback.code != "100" }'
      transition: InjectRollbackFailedStatus
  defaultCondition:
    transition: InjectRolledBackStatus
```
(來源:state `CheckRollbackResults`)

**變體**:
- A16220 失敗時階段 2 未扣款 → 走 `RollbackA16229Only`(只回沖 A16229),不要對未發生的扣款送補償請求(v15 description 明言此重構理由)。
- N>2 個階段:LIFO 鏈直接加長;每新增一階段就多一個 Check。
- 補償本身可能失敗:一律標記 ROLLBACK_FAILED + 觸發 [OPS-ALERT](配方⑤),不重試不中斷(LIFO 不中斷:測試 [17] 證明 A16220 回沖失敗後 A16229 仍繼續回沖)。

---

## 配方②:安全 switch(default 同向策略)

**問題**:switch 的條件若企圖窮舉所有分支,資料異形/求值異常會造成漏路由;業務判斷 state 本身出錯時更可能走到危險方向。

**解法**(P2-1):僅列正向條件,default 即安全分支;onErrors 目標與 default **同向**。

```yaml
- name: DecideByEvaluation
  type: switch
  onErrors:
    # 安全策略:評估本身出錯時與 default 同向,全回沖避免雙邊扣款卻無補償
    - errorRef: platformError
      transition: RollbackA16220
  dataConditions:
    # 樣板慣例 (P2-1):僅列小額成功條件;未明確成功(含 AMT 異常)一律全回沖
    - name: successPath
      condition: '${ .AMT <= 500 }'
      transition: InjectSuccessStatus
  defaultCondition:
    # 安全策略：異常時全回沖,避免雙邊扣款卻無回沖
    transition: RollbackA16220
```
(來源:`saga2-transfer-workflow.sw.yaml` state `DecideByEvaluation`)

**變體**:
- 危險明列型(CheckRollbackResults):把「任一回沖非 100」寫成顯式條件導向 ROLLBACK_FAILED,default 才是成功——適用「正常路徑唯一、異常多元」的場景;精神相同:**default 與未知都落在保守側**。
- 驗證型(ValidateInput):非法情況逐一列舉、合法交給 default(見 DEEP-DIVE §5.2)。

---

## 配方③:平台錯誤收斂(onErrors 表驅動)

**問題**:state timeout、jq 求值錯誤、引擎例外等平台層錯誤若不攔截,實例直接 ERROR,對帳紀錄缺席(timeout 對帳缺口)。

**解法**:定義單一 platformError,每個 operation/switch state 掛 onErrors,收斂目標由「該 state 的業務位置」決定(扣款前/扣款後/回沖中),最終全部抵達 FinalAuditAndEnd。

```yaml
errors:
  - name: platformError
    code: 'PLATFORM_ERROR'   # 必填:漏 code 會被 Kogito codegen 忽略
    description: 平台層非預期錯誤 (state timeout / 引擎例外 / 服務未攔截例外)
```
(來源:`saga2-transfer-workflow.sw.yaml` errors 區塊;各 state 的 onErrors 區塊)

收斂目標表(saga2 實值):

| state 位置 | onErrors 收斂目標 |
|------------|-------------------|
| ValidateInput | `InjectValidationFailedStatus` |
| CallA16229State / CheckA16229Result(扣款前)| `InjectFailedStatus` |
| CallA16220State / CheckA16220Result(A16229 已扣款)| `RollbackA16229Only` |
| DecideByEvaluation(兩階段已扣款;與 default 同向)| `RollbackA16220` |
| RollbackA16220 / RollbackA16229 / RollbackA16229Only / CheckRollbackResults / CheckRollbackA16229OnlyResult | `InjectRollbackFailedStatus` |

完整逐 state 表與理由見 [SAGA2-TEMPLATE-DEEP-DIVE](SAGA2-TEMPLATE-DEEP-DIVE.md) §4.2。注意:**HTTP 業務/傳輸失敗不走此路徑**——MyOpenApiService 吞例外回 code=999 標準化 body,由 Check* switch 分流;onErrors 只兜平台層。

**變體**:多種 error(name/code 不同)按 state 差異化導向;但金融主流程建議維持單一 platformError + 位置決策,避免收斂矩陣爆炸。

---

## 配方④:統一終點+輸出模板

**問題**:多終點 workflow 若各終點自帶 stateDataFilter.output(v15 做法),欄位形狀互異,消費端要寫 N 套解析。

**解法**:所有路徑先進 Inject 設 finalStatus/finalMessage,再匯流到唯一 FinalAuditAndEnd;輸出模板以 `// null`/`// false` 固定鍵集合:

```yaml
stateDataFilter:
  output: |
    {
      status: .finalStatus,
      message: .finalMessage,
      AMT: .AMT,
      a16229Result: (.a16229Result // null),
      a16220Result: (.a16220Result // null),
      a16229Rollback: (.a16229Rollback // null),
      a16220Rollback: (.a16220Rollback // null),
      auditSaved: (.auditResult.saved // false),
      opsAlertRaised: (.opsAlert.raised // false)
    }
end: true
```
(來源:`saga2-transfer-workflow.sw.yaml` state `FinalAuditAndEnd`;6 個 Inject 全部 transition 到此)

**變體**:
- 不需要告警的 workflow 可刪 opsAlert 相關兩處(action+輸出欄);auditSaved 建議保留。
- 需要新欄位時**只增不刪**,並同步測試斷言。
- `// null` 改 `// {}` 可讓弱型別客戶端免判 null,但失去「未發生 vs 空結果」語義;saga2 選擇保留 null。

---

## 配方⑤:條件運維告警(OpsAlertService 模式)

**問題**:回沖失敗需人工介入,但不能對每筆交易都發告警(噪音),也不能讓告警通道故障阻斷收尾。

**解法**:workflow **無條件呼叫**(每筆都打),條件判斷放服務端;不符條件靜默回 `raised=false`;通道異常 catch 後降級日誌、仍回 false。

```yaml
functions:
  - name: notifyOps
    operation: 'service:com.example.reconciliation.OpsAlertService::raise'
    type: custom

# ...於統一終點:
    - name: raiseOpsAlertIfRequired
      functionRef:
        refName: notifyOps
        arguments:
          workflowId: "saga2-transfer-workflow"
          processInstanceId: '${ $WORKFLOW.instanceId }'
          businessKey: '${ .Account_A }'
          finalStatus: '${ .finalStatus }'
          finalMessage: '${ .finalMessage }'
          detail:
            a16229Rollback: '${ .a16229Rollback }'
            a16220Rollback: '${ .a16220Rollback }'
      actionDataFilter:
        results: '{raised: .raised}'
        toStateData: '${ .opsAlert }'
```
(來源:`saga2-transfer-workflow.sw.yaml` functions 區塊 + state `FinalAuditAndEnd` action `raiseOpsAlertIfRequired`)

服務端關鍵碼(`OpsAlertService#raise`):`ALERT_ON_STATUS = "ROLLBACK_FAILED"`;命中才以專屬 logger `"OPS-ALERT"` 輸出 ERROR(`[OPS-ALERT] 回沖失敗,需人工介入 | workflowId=... | detail=...`),供 ELK/Splunk/ticketing 依關鍵字接單。

**變體**:多狀態觸發 → 改服務端 ALERT_ON_STATUS 為集合,workflow 零改動(契約不變是本模式核心價值);換通道(Kafka/webhook/ITSM)→ 在 raise 內追加(原始碼留有擴充點);驗證 → RBFAIL 哨兵打出 opsAlertRaised=true(測試 [17])、一般成功斷言 false(測試 [1])。

---

## 配方⑥:對帳落地(AuditLogService 模式+吞例外設計)

**問題**:稽核寫入若會拋例外,「收尾失敗」需要「收尾失敗的收尾」,無限遞迴;DB 故障也不能影響主流程結束。

**解法**:服務層吞一切例外回 `{saved:false[, error]}`(`AuditLogService#doSaveLog` catch 後建 response);workflow 端以 actionDataFilter 捕捉 saved 浮現於輸出;失敗細節交服務層 LOG 追查。

```yaml
functions:
  - name: recordAuditLog
    operation: 'service:com.example.reconciliation.AuditLogService::saveLog'
    type: custom

# ...於統一終點:
    - name: saveFinalAuditLog
      functionRef:
        refName: recordAuditLog
        arguments:
          workflowId: "saga2-transfer-workflow"
          businessKey: '${ .Account_A }'
          processInstanceId: '${ $WORKFLOW.instanceId }'
          inputData:
            Account_A: '${ .Account_A }'
            Account_B: '${ .Account_B }'
            AMT: '${ .AMT }'
          outputData:
            status: '${ .finalStatus }'
            message: '${ .finalMessage }'
            AMT: '${ .AMT }'
            a16229Result: '${ .a16229Result }'
            a16220Result: '${ .a16220Result }'
            a16229Rollback: '${ .a16229Rollback }'
            a16220Rollback: '${ .a16220Rollback }'
      actionDataFilter:
        results: '{saved: .saved}'
        toStateData: '${ .auditResult }'
```
(來源:`saga2-transfer-workflow.sw.yaml` functions 區塊 + state `FinalAuditAndEnd` action `saveFinalAuditLog`)

工程要點:① businessKey 選對帳主鍵(saga2 用扣款帳號);② `$WORKFLOW.instanceId` 把稽核紀錄與 Data Index 實例串起;③ outputData 的 status/message 會被 doSaveLog 抽出存欄位,其餘整包存 JSON 字串;④ 因此 FinalAuditAndEnd **不掛 onErrors**(見配方③的 inject/收尾例外原則)。

**變體**:
- 寫入結果分級處理:saved=false 時可加後續 switch 補寫本地檔案;但 saga2 選擇僅揭露(auditSaved)+靠 log,保持終點單一。
- 對帳查詢端:`vw_saga_reconciliation` view / `/reconciliation/*` REST / CSV 匯出(測試 [7]-[10]),詳見 [../04-reference/DATABASE-REFERENCE.md](../04-reference/DATABASE-REFERENCE.md)。

---

## 配方⑦:OpenAPI 動態呼叫(schemaRef#operationId)

**問題**:每接一個新 API 就寫一個 custom service 方法,樣板碼爆炸(v15 時代的痛)。

**解法**:統一走 MyOpenApiService;workflow 端只給「定位點」,端點解析/URL 組裝/重試/標準化全部由服務承擔:

```yaml
- name: CallA16229State
  type: operation
  actions:
    - name: callA16229Action
      functionRef:
        refName: callApiViaOpenAPI
        arguments:
          functionName: "callApiViaOpenAPI"
          schemaRef: 'specs/A16229-api.yaml#executeA16229'
          payload:
            Account_A: '${ .Account_A }'
            AMT: '${ .AMT }'
            EC: false
      actionDataFilter:
        results: '{code: .code, message: .message, Account: .Account, errorType: .errorType, _httpStatus: ._httpStatus}'
        toStateData: '${ .a16229Result }'
```
(來源:`saga2-transfer-workflow.sw.yaml` state `CallA16229State`;A16220/Rollback 各 state 同構)

規則備忘(`MyOpenApiService#callOpenApi`):schemaRef 必含 `#`;spec 路徑相對 classpath(specs 隨 transfer-api jar 提供);operationId 在 spec 內唯一;Base URL 解析優先序 `kogito.sw.functions.<fn>.*` → `kogito.sw.openapi.<specKey>.*` → spec `servers[0].url`。

**變體**:
- path-param API:`payload` 內同名欄位自動填 `{param}` 並 URL-encode;GET/DELETE 剩餘欄位轉 query string(`MyOpenApiService#buildTargetUrl`)。
- 自訂 headers / 單次逾時 / 單次重試:`arguments.headers`、`arguments.timeoutSeconds`、`arguments.retryMaxAttempts/retryDelayMs`(上限 5)。
- 同步 EC 語義:補償呼叫只改 `EC: true`,schemaRef 不變(見配方①)。

---

## 配方⑧:timeout 防線配置

**問題**:外部服務掛起時,要讓「服務層先回標準化錯誤」而不是引擎層中斷;同時防止任何路徑無限掛起。

**解法**:四層預算遞增,外層大於內層;只對含外部呼叫的 operation state 設 state 級 timeout。

```yaml
timeouts:
  workflowExecTimeout: PT5M          # 工作流整體上限

- name: CallA16229State
  type: operation
  timeouts:
    actionExecTimeout: PT15S         # > MyOpenApiService HTTP 10s
    stateExecTimeout: PT30S
```
(來源:`saga2-transfer-workflow.sw.yaml` timeouts 區塊 + state `CallA16229State`;六個 operation state 中五個為 PT15S/PT30S,**FinalAuditAndEnd 為 PT10S/PT20S**——它只打本地 Java 服務,無 HTTP 10s 約束)

數值全景與設計原則(「服務層先回標準化錯誤,引擎層才中斷」)見 [SAGA2-TEMPLATE-DEEP-DIVE](SAGA2-TEMPLATE-DEEP-DIVE.md) §3。

**變體**:
- 目標服務較慢 → 先調大 `kogito.sw.openapi.timeout-seconds`,再同步放大 actionExecTimeout/stateExecTimeout。
- 啟用傳輸重試(max-attempts>1)→ 重估最壞耗時:N×HTTP逾時 + Σ退避延遲(500ms 起 ×2 成長),防線必須涵蓋。
- switch/inject state 不設 timeout(jq 求值異常走 onErrors,不需時間防線)。

---

## 配方⑨:jq 安全寫法大全(null 收斂/match 替代 test/type 檢查)

**問題**:jackson-jq 行為與標準 jq 有差;null 參與運算常拋例外導致條件被跳過或 state 失敗。

**解法**:三招定天下(全部出自 saga2 實碼):

**(1) match 替代 test(驗證是否匹配)**

```yaml
condition: '${ ((.Account_A // "") | match("^[A-Za-z0-9_]+$") // false) == false }'
```
(來源:state `ValidateInput` condition `accountAInvalid`)
原理:jackson-jq 不支援 `test()`;`match()` 不匹配時拋錯而非回 false,故以 `// false` 收斂錯誤再比對 `== false`。整句 =「未匹配(非法)」。

**(2) null 收斂(先兜底再運算)**

```yaml
.Account_A // ""      # 缺失/null/false → 空字串(避免對 null 做 match 拋例外繞過驗證)
(.a16229Result // null)          # 輸出模板:鍵恆存在,值可為 null
(.auditResult.saved // false)    # 布林形狀保證
```
(來源:state `ValidateInput`;state `FinalAuditAndEnd` stateDataFilter.output)

**(3) type 檢查(一條涵蓋多種異形)**

```yaml
condition: '${ .AMT | type != "number" }'   # 缺失/null 的 type 是 "null",自然命中
```
(來源:state `ValidateInput` condition `amtInvalid`;後續 `.AMT <= 0` 到達時必為數字)

**變體/禁則**:
- 禁止假設欄位存在:任何跨物件取值前先 `//` 收斂。
- 字串比較一律與字面值比(`.code == "100"`);mock 回應的 code 是字串型。
- 多條件用 `or`/`and` 明確括號(CheckRollbackResults 的 anyRollbackFailed)。

---

## 配方⑩:Data Index metadata 標籤查詢

**問題**:多 workflow 並存,營運/檢索需要統一的治理標籤與實例查詢入口。

**解法**:workflow 層級掛四標籤(查詢過濾的語義基礎),再以 GraphQL 查定義與實例。

```yaml
metadata:
  domain: transfer
  pattern: saga-lifo-compensation
  criticality: high
  owner: platform-team
```
(來源:`saga2-transfer-workflow.sw.yaml` metadata 區塊;註解原文:「工作流標籤 — Data Index GraphQL / 營運查詢過濾用」)

已驗證的查詢路徑(本專案原始碼可考):

```bash
# 實例查詢(含節點軌跡)——query 形狀取自 tester.html fetchGraphQLTrace
curl -s -X POST http://localhost:8080/graphql \
  -H 'Content-Type: application/json' \
  -d '{"query":"query{ ProcessInstances(where:{processId:{equal:\"saga2-transfer-workflow\"}}){ id processId state start end variables nodes { id name enter exit } } }"}'

# 定義清單——dashboard.html loadGraphQLData 所用
# ProcessDefinitions { id name version }
```

- 圖形介面:`/q/dev-ui/org.kie.kogito.kogito-addons-quarkus-data-index-graphql-ui/graphql-ui`(index.html「GraphiQL 開發中樞」卡片);跨域場景走 8090 代理 `POST /api/reconciliation/graphql`(`ReconciliationAuditResource#proxyGraphQL`)。
- **誠實邊界**:metadata 四鍵的價值首先是**治理一致性**(人工檢索、營運盤點、告警接單對象);至於能否作為 Data Index GraphQL 的第一級過濾欄位,取決於 Data Index schema 版本——專案內已驗證的一級過濾是 `ProcessInstances(processId/state…)` 與 `ProcessDefinitions`。請以當前 /graphql 的 schema introspection 為準,勿假設 metadata 可直接 where。
- 節點軌跡來源:`NodeTracingProcessEventListener`(platform-data-index)。

**變體**:按 domain/criticality 分類盤點(人工或自建報表);owner 對齊 [OPS-ALERT](#配方⑤條件運維告警opsalertservice模式) 接單對象。

---

## 配方⑪:HTTP status 對外語義化(400/409)

**問題**:引擎回應預設一律 200(UnwrapResponseFilter 解包時強制 setStatus(200)),輸入錯/需人工介入與成功在外部監控眼中無法區分。

**解法**:配置驅動的 status-rewrite——依回應 body 的 `status` 欄位改寫 HTTP code,**零 Java 改動**:

```properties
platform.status-rewrite.workflows=saga2-transfer-workflow,my-new-workflow
platform.status-rewrite.mapping=VALIDATION_FAILED=400,ROLLBACK_FAILED=409
```
(來源:`distribution/transfer-app/src/main/resources/application.properties` Workflow 狀態碼改寫區塊;慣例:VALIDATION_FAILED=400 客戶端輸入錯、ROLLBACK_FAILED=409 需人工介入,SUCCESS/FAILED/ROLLED_BACK 保持 200 不列)

實作機制(`SonataFlowSecurityConfig$WorkflowStatusFilter`,ContainerResponseFilter):

- priority = `USER - 10`,**刻意晚於 UnwrapResponseFilter(USER)執行**——JAX-RS response filter 以 priority 降序執行,晚跑才能取得解包後的最終 entity,並讓改寫碼覆蓋 Unwrap 強制設定的 200。
- 只處理 POST;比對路徑第一段 = workflow id;entity 相容 Map/JsonNode/JSON 字串三型(`normalizeEntityToMap`)。
- 改寫同時輸出 `[HTTP-AUDIT]` 日誌(URI/HTTP/Cost/INPUT/OUTPUT)。

**變體**:新狀態碼需求只加 mapping(如 `FAILED=422`);名單未列的 workflow 完全不受影響;測試斷言 `statusCode(400)`/[17] `statusCode(409)`。

---

## 配方⑫:冪等性策略(Idempotency-Key 於 Gateway 層)

**問題**:workflow 未內建去重——同一請求重送將產生獨立流程實例與重複交易(YAML description 明文警示)。

**解法**(description 原文的兩層防護):

1. **入口去重**:呼叫端 Header 帶 Idempotency-Key,API Gateway/入口層依 key 快取首次回應並回放;
2. **底線約束**:業務 API 層對業務鍵(帳號+日期+金額+序號)建唯一約束,擋住穿透的重複動帳。

平台現況核對:RuntimeFilter/UnwrapResponseFilter/WorkflowStatusFilter 均無去重邏輯;mock Resource(A16229/A16220)亦無。因此**去重責任明確在 Gateway 或核心系統**,這是有意的架構決策而非缺陷。

**變體**:
- 對帳補救:`vw_saga_reconciliation` 事後稽核重複(businessKey+AMT+時間窗);詳見 [../04-reference/DATABASE-REFERENCE.md](../04-reference/DATABASE-REFERENCE.md)。
- 補償呼叫冪等:EC=true 回沖設計成「退回指定金額」,搭配唯一約束避免多重複;RBFAIL 哨兵測的是回沖失敗路徑,非重複防護。
- description 冪等性段落的維護:每個新 workflow 都要寫自己的去重策略聲明(GUIDE 步驟③骨架已含)。

---

## 常見錯誤

| # | 錯誤 | 後果 | 正確做法 |
|---|------|------|----------|
| 1 | onErrors 收斂目標亂填(如扣款後直接 FAILED)| 已扣款無補償,資金損失 | 按「位置決策表」:扣款後一律先 Rollback* |
| 2 | errors 定義漏 code | codegen 忽略,onErrors 全失效 | 一律補 code |
| 3 | jq 用 test() 或裸 match(null)| 求值錯誤/繞過驗證 | 配方⑨三招 |
| 4 | timeout 小於 HTTP 逾時 | 引擎先斷,拿不到標準化錯誤 | 配方⑧四層遞增 |
| 5 | 手改 distribution 副本 | 建置覆蓋,變更蒸發 | 只改 canonical 模組 |
| 6 | 在收尾 state 掛會拋例外的服務/onErrors | 收尾失敗無人接,audit 缺口 | 吞例外+回布林契約(配方⑥)|
| 7 | Inject finalMessage 與驗證規則不同步 | 回應文字誤導 + 測試紅 | 規則/訊息/測試三處同步 |
| 8 | 假設 metadata 可直接 GraphQL where | 查詢失敗 | 以 schema introspection 為準(配方⑩)|
| 9 | status-rewrite 只加 mapping 沒加 workflows 名單 | 改寫不生效 | 兩個 key 一起配(配方⑪)|
| 10 | 把 RBFAIL 哨兵當一般錯誤處理邏輯 | 生產誤觸 401 | 哨兵僅供測試,條件=EC=true+特定帳號 |

---

## 相關文件

- [SAGA2-TEMPLATE-DEEP-DIVE](SAGA2-TEMPLATE-DEEP-DIVE.md):樣板逐區塊原理(onErrors/timeout/jq 全表)。
- [NEW-WORKFLOW-GUIDE](NEW-WORKFLOW-GUIDE.md):8 步 SOP 與上線 checklist。
- [../04-reference/SERVICE-REFERENCE.md](../04-reference/SERVICE-REFERENCE.md)/[../02-architecture/OBSERVABILITY.md](../02-architecture/OBSERVABILITY.md)/[../06-testing/TESTING-GUIDE.md](../06-testing/TESTING-GUIDE.md)。
