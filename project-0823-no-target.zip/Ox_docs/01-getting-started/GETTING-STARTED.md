# 01 — GETTING STARTED：環境建置、建置、啟動與第一筆交易

> 本文是 myhello-platform 新人入門的第一份文件：從零把平台建置起來、啟動雙應用程式，並發出第一筆轉帳交易。
> 目錄地圖請搭配 [PROJECT-LAYOUT](./PROJECT-LAYOUT.md)；架構原理見 [ARCHITECTURE](../02-architecture/ARCHITECTURE.md)。
> 引用慣例：`類別#方法` 或檔名為主，行號為輔且可能隨版本變動；術語以 [Ox_docs README 術語統一表](../README.md#術語統一表全套文件通用) 為準。

## 目錄

1. [環境需求](#1-環境需求)
2. [一般建置（線上）](#2-一般建置線上)
3. [離線建置（offline-build.sh / offline-build.ps1）](#3-離線建置offline-buildsh--offline-buildps1)
4. [啟動雙 App（quarkus-run.jar）](#4-啟動雙-appquarkus-runjar)
5. [Dev mode（mvn quarkus:dev）](#5-dev-modemvn-quarkusdev)
6. [發出第一筆交易：五種情境完整驗證](#6-發出第一筆交易五種情境完整驗證)
7. [環境變數 MYHELLO_DATA_DIR / MYHELLO_LOGS_DIR](#7-環境變數-myhello_data_dir--myhello_logs_dir)
8. [`logs/` 與 `data/` 產物說明](#8-logs-與-data-產物說明)
9. [常見錯誤](#9-常見錯誤)

---

## 1. 環境需求

### 1.1 必要軟體

| 軟體 | 版本需求 | 原始碼依據 |
|------|---------|-----------|
| JDK | **17**（必要） | 根 `pom.xml`：`<maven.compiler.release>17</maven.compiler.release>` |
| Maven | **3.9+**（Quarkus 3.x 建議基準） | 根 `pom.xml` 以 `quarkus-maven-plugin`（`<extensions>true</extensions>`）驅動打包 |
| 網路 | 一般建置需連 Maven Central；斷網環境走[離線建置](#3-離線建置offline-buildsh--offline-buildps1) | 根 `pom.xml` `<repositories>`：`central`（repo.maven.apache.org）與 `apache-public-repository-group` |

### 1.2 版本基準（全平台統一，定義於根 `pom.xml` `<properties>`）

| 元件 | 版本 | 屬性鍵 |
|------|------|--------|
| Quarkus Platform | **3.27.2** | `quarkus.platform.version` |
| KIE / Kogito | **10.2.0** | `kie.version` / `kie.tooling.version` |
| SQLite JDBC（xerial） | **3.45.1.0** | `sqlite-jdbc.version`（根 pom 註解：「全平台唯一允許的 sqlite 驅動」） |
| Rest Assured（測試） | 5.5.0 | `rest-assured.version` |

> 子模組一律不自寫版本號，只以 artifactId 引用（根 `pom.xml` `<dependencyManagement>` 集中管理）。升版只需改根 pom 一處。

### 1.3 你將會建出什麼

一次完整建置產出**兩個可執行 Quarkus 應用**（`offline-build.sh` 尾端訊息即明示這兩個路徑）：

| 產物 | Port | 角色 |
|------|------|------|
| `distribution/transfer-app/target/quarkus-app/quarkus-run.jar` | 8080 | 讀寫交易（SonataFlow workflow + mock API + Data Index） |
| `distribution/reconciliation-app/target/quarkus-app/quarkus-run.jar` | 8090 | 唯讀對帳查詢（read-only datasource） |

---

## 2. 一般建置（線上）

在**專案根目錄**執行：

```bash
mvn clean package -DskipTests
```

### 2.1 參數逐項解釋

| 片段 | 作用 |
|------|------|
| `clean` | 刪除所有子模組的 `target/`，確保乾淨建置（多模組專案的殘留 class 容易造成難查的靈異問題） |
| `package` | 走完生命週期到 `package`；兩個 app 模組經 `quarkus-maven-plugin` 的 `build` goal 產出 `target/quarkus-app/quarkus-run.jar` |
| `-DskipTests` | 跳過測試。測試集中在 `distribution/transfer-app/src/test/java/`（4 個測試類，詳見 [TESTING-GUIDE](../06-testing/TESTING-GUIDE.md)）；首次驗證環境可拿掉此參數跑完整測試 |

### 2.2 建置過程中會發生什麼（Maven reactor 順序）

1. **platform-extensions** 最先建置——三個 KIE/Kogito SQLite 修補子模組（groupId 屬 `org.kie` / `org.kie.kogito`，屬上游套件的在地修補版；根 pom 註解「修補模組本地版本」）。要單獨組裝某個 distribution 前，需確保這些修補模組已存在於本地 repo（完整 reactor 建置會自動涵蓋）。
2. **platform-common → platform-security / platform-data-index** 平台層。
3. **domain-transfer**（transfer-api → transfer-workflow、transfer-samples）與 **domain-reconciliation**（reconciliation-api）業務域。
4. **distribution/transfer-app**：於 `initialize` 階段執行 **sync-domain-resources**（把三個 domain 模組的 resources 同步進自己的 `src/main/resources`，詳見 [PROJECT-LAYOUT §6](./PROJECT-LAYOUT.md#6-sync-domain-resources單一事實來源機制)），再打包成可執行應用。
5. **distribution/reconciliation-app**：同樣組裝為唯讀對帳應用。

> ⚠️ 建置期間 `distribution/transfer-app/src/main/resources` 下的 `*.sw.yaml`、`schemas/`、`specs/` 會被**靜默覆蓋同步**——它們是建置產物，不要手改。

---

## 3. 離線建置（offline-build.sh / offline-build.ps1）

專案內建離線套件庫 `offline-packages/maven-repo/`，可在**完全斷網（Air-Gapped）**環境建置。兩支腳本的核心指令相同：

```
mvn clean package -o -Dmaven.repo.local=<離線庫路徑>
```

`-o`（offline）強制 Maven 不碰任何遠端 repository；`-Dmaven.repo.local` 把本地倉庫指到專案內建庫。

### 3.1 Linux / macOS：bash 版

```bash
./offline-build.sh                # 使用預設離線庫 offline-packages/maven-repo
./offline-build.sh -DskipTests    # 額外參數原樣轉傳給 mvn（"$@"）
```

腳本流程（`offline-build.sh`）：

1. 以 `SCRIPT_DIR` 定位腳本目錄，組出預設離線庫 `${SCRIPT_DIR}/offline-packages/maven-repo`。
2. 目錄不存在 → 印出 `❌ 錯誤：找不到離線套件庫目錄` 並 `exit 1`。
3. 執行 `mvn clean package -o -Dmaven.repo.local="${OFFLINE_REPO}" "$@"`；腳本開頭 `set -e`，任一步失敗即中止。
4. 成功後列出兩個 `quarkus-run.jar` 產出路徑。

### 3.2 Windows：PowerShell 版

```powershell
.\offline-build.ps1                        # 使用預設離線套件庫
.\offline-build.ps1 -SkipTests             # 其餘未命名參數轉傳給 mvn
.\offline-build.ps1 -OfflineRepo D:\repo   # 指定其他離線套件庫路徑
```

腳本流程（`offline-build.ps1`）：

1. `[Console]::OutputEncoding` 設 UTF-8（中文訊息正常顯示）；`$ErrorActionPreference='Stop'`。
2. 未指定 `-OfflineRepo` 時，預設 `Join-Path $PSScriptRoot 'offline-packages\maven-repo'`。
3. 兩道防呆：離線庫存在性檢查（`Test-Path -PathType Container`）、`mvn` 是否在 PATH（`Get-Command mvn`），任一失敗即紅字退出。
4. 組合參數陣列 `@('clean','package','-o',"-Dmaven.repo.local=$OfflineRepo") + $RemainingArgs` 後以 `& mvn @mvnArgs` 執行；檢查 `$LASTEXITCODE` 決定退出碼。

### 3.3 兩版參數差異對照表

| 面向 | `offline-build.sh` | `offline-build.ps1` |
|------|--------------------|---------------------|
| 指定離線庫 | 無具名參數，固定使用專案內 `offline-packages/maven-repo` | 具名參數 `-OfflineRepo` 可直接覆寫 |
| 額外 mvn 參數 | `"$@"` 原樣轉傳 | `$RemainingArgs`（`ValueFromRemainingArguments`）收集後附加 |
| mvn 存在性檢查 | 無（缺 mvn 時直接 command not found） | 有（`Get-Command mvn` 明確報錯） |
| 中文輸出編碼 | 無特別處理 | 明確設 UTF-8 |
| 失敗即停 | `set -e` | `$ErrorActionPreference='Stop'` + `$LASTEXITCODE` 檢查 |

---

## 4. 啟動雙 App（quarkus-run.jar）

開兩個終端機，於**專案根目錄**分別執行：

```bash
# 終端機 1：交易 App（port 8080）
java -jar distribution/transfer-app/target/quarkus-app/quarkus-run.jar

# 終端機 2：對帳 App（port 8090）
java -jar distribution/reconciliation-app/target/quarkus-app/quarkus-run.jar
```

### 4.1 為什麼建議在專案根目錄啟動？

`PlatformPaths#findProjectRoot()` 從 JVM 工作目錄（`user.dir`）**逐層向上**尋找包含 `.git`、或同時包含 `pom.xml` 與 `distribution/` 的目錄作為專案根；`data/`、`logs/` 的預設位置皆錨定於該根目錄之下（`PlatformPaths` class 的 static 初始化區塊會在載入時自動補上系統屬性）。從深層子目錄啟動通常仍找得到根，但若在毫無標記的目錄執行，fallback 是 `user.dir` 本身——DB 與 log 會落到意料之外的位置。

### 4.2 埠與角色速查

| App | Port | Host | 關鍵配置來源 |
|-----|------|------|--------------|
| transfer-app | 8080 | 0.0.0.0 | `quarkus.http.port=8080`（`distribution/transfer-app/src/main/resources/application.properties`） |
| reconciliation-app | 8090 | 0.0.0.0 | `quarkus.http.port=8090`；並設定 `quarkus.datasource.jdbc.read-only=true`（寫入一律由 transfer-app 端 `AuditLogService` 進行） |

> 臨時換埠不必改檔：`java -Dquarkus.http.port=9080 -jar ...quarkus-run.jar` 即可以 System Property 覆寫。

### 4.3 共享同一個 SQLite（reconciliation.db）

兩個 App 的 JDBC URL 都是 `jdbc:sqlite:${MYHELLO_DATA_DIR:data}/reconciliation.db`：

- **transfer-app 自身 properties 未定義 datasource**，繼承 **platform-data-index 模組的 base 配置**（`platform-data-index/src/main/resources/application.properties`）：driver `org.sqlite.JDBC`、`max-size=1`、`foreign_keys=true`、`journal_mode=WAL`、`synchronous=NORMAL`；
- **reconciliation-app** 在自身 properties 明示同一 URL，並加掛 `read-only=true`。

SQLite 於 WAL 模式下支援「多讀者＋單寫者」併存：8080 寫入、8090 唯讀互不阻塞。細節見 [ARCHITECTURE](../02-architecture/ARCHITECTURE.md)、[DATABASE-REFERENCE](../04-reference/DATABASE-REFERENCE.md)。

### 4.4 健康檢查

```bash
curl -s http://localhost:8080/q/health
curl -s http://localhost:8090/q/health
```

啟動成功後可瀏覽內建頁面（如 `http://localhost:8080/index.html`、`http://localhost:8090/reconciliation.html`），導覽見 [UI-PAGES](../07-operations/UI-PAGES.md)。

---

## 5. Dev mode（mvn quarkus:dev）

開發期熱載模式（改 Java／workflow YAML 即時重載）：

```bash
# 方式一：從專案根目錄指定模組
mvn quarkus:dev -pl distribution/transfer-app

# 方式二：進到模組目錄直接啟動
cd distribution/transfer-app
mvn quarkus:dev
```

要點：

- Dev UI 位於 `http://localhost:8080/q/dev`；Data Index GraphQL UI 一律啟用（base 配置 `quarkus.kogito.data-index.graphql.ui.always-include=true`、`kogito.data-index.blocking=true`）。
- `quarkus:dev` 會先推進 Maven 生命週期至 compile，因此綁定在 `initialize` 階段的 **sync-domain-resources 也會執行**——你在 `domain-transfer/*/src/main/resources` 改的 workflow YAML，會先同步到 app 再被載入（行為可能隨 Quarkus 版本變動，若未同步請先手動跑一次 `mvn package`）。
- OIDC／Keycloak 全域關閉（base 配置 `quarkus.oidc.enabled=false`、`quarkus.keycloak.devservices.enabled=false`），dev mode 不需要 Keycloak。
- `%test.*` 前綴設定（transfer-app `%test.quarkus.http.test-port=8080`、reconciliation-app `%test.quarkus.http.test-port=8081`、測試 DB `target/test-reconciliation.db`）只在 `mvn test` 生效，**不影響 dev mode**。
- 兩個 App 可同時各自開 dev mode（埠不同：8080 / 8090，互不衝突）。


---

## 6. 發出第一筆交易：五種情境完整驗證

### 6.1 端點與輸入契約

workflow 啟動端點即 workflow id：

```
POST http://localhost:8080/saga2-transfer-workflow
Content-Type: application/json
```

輸入欄位（由 `saga2-transfer-workflow.sw.yaml` 的 `ValidateInput` state 以 jq 驗證；`dataInputSchema` 已停用，規則與文件化契約 `schemas/saga-transfer-input-schema.json` 同步）：

| 欄位 | 型別 | 規則 |
|------|------|------|
| `Account_A` | string | 必須匹配 `^[A-Za-z0-9_]+$`（僅英數字與底線，非空） |
| `Account_B` | string | 同上，且**不得等於** `Account_A` |
| `AMT` | number | 必須為數字且 `> 0` |

驗證失敗 → `finalStatus=VALIDATION_FAILED`，HTTP 由 status-rewrite 改寫為 **400**。

### 6.2 Mock API 規則（curl 情境的設計依據）

workflow 經 `MyOpenApiService#callOpenApi` 自呼本機 8080 的兩個 mock API（配置鍵 `kogito.sw.functions.callApiViaOpenAPI.*`＝`http://localhost:8080`，定義於 transfer-app `application.properties`）：

| Mock 端點 | 成功條件（回 `code="100"`） | 失敗回應 | RBFAIL 哨兵（僅 EC=true 回沖時觸發） |
|-----------|---------------------------|----------|--------------------------------------|
| `POST /A16229`（扣款方） | `AMT > 50` | `code="999"`「AMT必須大於50」、HTTP 403 | `Account_A=="RBFAIL"` → `code="401"`「回沖失敗(測試哨兵)」 |
| `POST /A16220`（入帳方） | `AMT < 1000` | `code="999"`「AMT必須小於1000」、HTTP 403 | `Account_B=="RBFAIL"` → `code="401"` |

> 證據：`A16229Resource#execute`、`A16220Resource#execute`（domain-transfer/transfer-api）。哨兵在一般交易（EC=false）不觸發。

主流程決策（`saga2-transfer-workflow.sw.yaml`）：兩段呼叫皆成功後，`DecideByEvaluation` 以 **`AMT <= 500`** 分流——小額走 `SUCCESS`；大額觸發 **Saga LIFO 回沖**（先回沖 A16220、再回沖 A16229），全數成功走 `ROLLED_BACK`。若 A16220 業務失敗（AMT≥1000），僅回沖 A16229（`RollbackA16229Only`），回沖成功同樣收 `ROLLED_BACK`。

### 6.3 五種情境總表

基底請求皆為 `POST http://localhost:8080/saga2-transfer-workflow`，JSON 基底為 `{"Account_A":"Alice_001","Account_B":"Bob_002","AMT":...}`，各情境差異如下：

| # | 情境 | 輸入差異 | 預期 HTTP | 輸出 `status` | 觸發路徑（state 鏈） |
|---|------|----------|-----------|---------------|----------------------|
| 1 | 正常小額成功 | `"AMT": 300` | **200** | `SUCCESS` | A16229 ✓（300>50）→ A16220 ✓（300<1000）→ 300≤500 → InjectSuccessStatus |
| 2 | 業務失敗 | `"AMT": 30` | **200** | `FAILED` | A16229 ✗（30≤50，code=999）→ CheckA16229Result default → InjectFailedStatus（尚未扣款，免回沖） |
| 3 | Saga 全回沖 | `"AMT": 800` | **200** | `ROLLED_BACK` | 兩段 ✓ → 800>500 → LIFO：RollbackA16220→RollbackA16229（EC=true 皆 code=100）→ CheckRollbackResults default → InjectRolledBackStatus |
| 4 | 輸入驗證失敗 | `{"Account_A":"Same_Acct","Account_B":"Same_Acct","AMT":100}` | **400** | `VALIDATION_FAILED` | ValidateInput `sameAccount` 命中 → InjectValidationFailedStatus → FinalAuditAndEnd |
| 5 | 回沖失敗（RBFAIL 哨兵） | `"Account_B": "RBFAIL", "AMT": 600` | **409** | `ROLLBACK_FAILED` | 兩段 ✓ → 回沖 → RollbackA16220（EC=true）踩哨兵 code=401 → anyRollbackFailed → InjectRollbackFailedStatus ＋ [OPS-ALERT] |

### 6.4 逐一操作（curl 指令與預期結果）

> `-w "\nHTTP %{http_code}\n"` 用來顯示 HTTP 狀態碼。回應 body 已由 `UnwrapResponseFilter` 剝去 `workflowdata` 外殼，直接是業務欄位：`status`、`message`、`AMT`、`a16229Result`、`a16220Result`、`a16229Rollback`、`a16220Rollback`、`auditSaved`、`opsAlertRaised`。

**情境 1：SUCCESS（HTTP 200）**

```bash
curl -s -w "\nHTTP %{http_code}\n" -X POST http://localhost:8080/saga2-transfer-workflow \
  -H "Content-Type: application/json" \
  -d '{"Account_A":"Alice_001","Account_B":"Bob_002","AMT":300}'
```

預期輸出（節錄）：`"status":"SUCCESS"`、`"message":"交易成功"`、`a16229Result.code=="100"`、`a16220Result.code=="100"`、rollback 欄位為 null、`"auditSaved":true`、`"opsAlertRaised":false`。

**情境 2：FAILED（HTTP 200）**

```bash
curl -s -w "\nHTTP %{http_code}\n" -X POST http://localhost:8080/saga2-transfer-workflow \
  -H "Content-Type: application/json" \
  -d '{"Account_A":"Alice_001","Account_B":"Bob_002","AMT":30}'
```

預期：`"status":"FAILED"`、`"message":"業務失敗或 API 錯誤"`、`a16229Result.code=="999"`（mock 訊息「AMT必須大於50」）、`a16220Result` 為 null。HTTP 維持 200——`FAILED` 不在 status-rewrite 映射中。

**情境 3：ROLLED_BACK（HTTP 200）**

```bash
curl -s -w "\nHTTP %{http_code}\n" -X POST http://localhost:8080/saga2-transfer-workflow \
  -H "Content-Type: application/json" \
  -d '{"Account_A":"Alice_001","Account_B":"Bob_002","AMT":800}'
```

預期：`"status":"ROLLED_BACK"`、`"message":"AMT > 500 觸發 saga 回沖 (LIFO)"`、`a16220Rollback.code=="100"`、`a16229Rollback.code=="100"`（順序：先 A16220 再 A16229）。

**情境 4：VALIDATION_FAILED（HTTP 400）**

```bash
curl -s -w "\nHTTP %{http_code}\n" -X POST http://localhost:8080/saga2-transfer-workflow \
  -H "Content-Type: application/json" \
  -d '{"Account_A":"Same_Acct","Account_B":"Same_Acct","AMT":100}'
```

預期：`"status":"VALIDATION_FAILED"`、`"message":"輸入欄位格式錯誤 (帳號僅限英數字與底線且兩者不得相同;AMT 須為大於 0 的數字)"`、**HTTP 400**。其他等效觸發方式：帳號含非法字元（如 `"acct-001"`）、`AMT` 為 0／負數／非數字／缺欄。

**情境 5：ROLLBACK_FAILED（HTTP 409，RBFAIL 哨兵）**

```bash
curl -s -w "\nHTTP %{http_code}\n" -X POST http://localhost:8080/saga2-transfer-workflow \
  -H "Content-Type: application/json" \
  -d '{"Account_A":"Alice_001","Account_B":"RBFAIL","AMT":600}'
```

預期：`"status":"ROLLBACK_FAILED"`、`"message":"⚠️ 回沖失敗,需人工介入處理"`、`a16220Rollback.code=="401"`、**HTTP 409**、`"opsAlertRaised":true`（transfer-app log 出現 `[OPS-ALERT]` ERROR 日誌）。哨兵原理：`Account_B=="RBFAIL"` 且 `EC=true` 時 `A16220Resource#execute` 強制回 code=401。（以 `Account_A:"RBFAIL"` 觸發 `A16229Resource` 側哨兵亦可。）

### 6.5 HTTP 狀態碼是誰決定的？（status-rewrite 速覽）

`SonataFlowSecurityConfig$WorkflowStatusFilter`（platform-security，priority 排在 `UnwrapResponseFilter` 之後執行）依 transfer-app `application.properties` 的兩個 key 運作：

```properties
platform.status-rewrite.workflows=saga2-transfer-workflow
platform.status-rewrite.mapping=VALIDATION_FAILED=400,ROLLBACK_FAILED=409
```

未列入映射的 `SUCCESS` / `FAILED` / `ROLLED_BACK` 保持引擎原狀態碼（200）。新增 workflow 要納入改寫只需註冊此兩處，免改 Java。完整機制見 [OBSERVABILITY](../02-architecture/OBSERVABILITY.md)；全部 endpoints 詳列於 [REST-API-REFERENCE](../04-reference/REST-API-REFERENCE.md)。


---

## 7. 環境變數 MYHELLO_DATA_DIR / MYHELLO_LOGS_DIR

兩個變數控制**執行期資料（DB、CSV）與日誌的落盤位置**，由 `PlatformPaths`（platform-common）統一解析，避免各模組自行處理路徑。

### 7.1 解析順序（`PlatformPaths#dataDirectory()` / `PlatformPaths#logsDirectory()`）

| 優先序 | 來源 | 說明 |
|--------|------|------|
| 1 | 環境變數 `MYHELLO_DATA_DIR`／`MYHELLO_LOGS_DIR` | 需為**絕對路徑**；容器化掛 volume 時使用 |
| 2 | 同名 System Property | `java -DMYHELLO_DATA_DIR=/abs/path -jar ...` |
| 3 | 專案根目錄下的 `data/`／`logs/` | 由 `PlatformPaths#findProjectRoot()` 向上找 `.git` 或「`pom.xml`＋`distribution/`」判定根目錄 |

> 補充：class 載入時的 static 區塊會在兩者皆未設定時，自動把解析好的預設路徑寫回 System Property。`dataDirectory()`/`logsDirectory()` 本身**不會**建目錄；需要落盤時由呼叫端走 `ensureDataDirectory()`/`ensureLogsDirectory()`（`mkdir -p` 語意）。

### 7.2 在配置中的引用點

| 配置（檔案） | 內容 |
|--------------|------|
| transfer-app `application.properties` | `quarkus.log.file.path=${MYHELLO_LOGS_DIR:logs}/transfer-app.log` |
| reconciliation-app `application.properties` | `quarkus.log.file.path=${MYHELLO_LOGS_DIR:logs}/reconciliation-app.log`、`quarkus.datasource.jdbc.url=jdbc:sqlite:${MYHELLO_DATA_DIR:data}/reconciliation.db` |
| platform-data-index base `application.properties` | `quarkus.datasource.jdbc.url=jdbc:sqlite:${MYHELLO_DATA_DIR:data}/reconciliation.db`（transfer-app 由此繼承） |

語法 `${VAR:default}` 表示「未設定時用 default」，因此即使完全不設環境變數也能以相對路徑 `data/`、`logs/` 運作。

### 7.3 一致性警告（重要）

`AuditLogService#getConnection` 的備用路徑（DataSource 未注入時改用 `DriverManager`）所用的 JDBC URL 是 **class 載入當下**由 `PlatformPaths.sqliteUrl("reconciliation.db")` 解析的靜態值——它只看 `MYHELLO_DATA_DIR`，**不會**跟 `quarkus.datasource.jdbc.url` 的覆寫同步。若你只改其中一處，可能造成「同一台機器兩個 DB 檔」的資料分裂（服務層會 LOG warn 提醒）。**結論：要換資料位置，一律優先設定環境變數 `MYHELLO_DATA_DIR`，讓兩條路徑自然一致。**

---

## 8. `logs/` 與 `data/` 產物說明

### 8.1 `data/`（執行期資料）

| 檔案 | 產生者 | 說明 |
|------|--------|------|
| `data/reconciliation.db` | 雙 App 共享 | 唯一 SQLite 資料庫（WAL 模式）；schema 由 Flyway 遷移腳本建立（`DatabaseMigrationRunner` 啟動時執行各模組遷移） |
| `data/reconciliation.db-wal`、`-shm` | SQLite 引擎 | WAL 附屬檔案；**App 運行中不可刪除或搬移** |
| `data/reconciliation-<yyyyMMdd-HHmmss>.csv` | 對帳匯出 | CSV 報表（時間戳命名；實際檔名可於 `data/` 目錄觀察）。詳見 [DATABASE-REFERENCE](../04-reference/DATABASE-REFERENCE.md) |

以上皆被 `.gitignore` 排除（`*.db*`、`data/*.csv`），僅保留 `.gitkeep` 維持目錄結構——它們是純執行期產物，不該進版控。

### 8.2 `logs/`（執行期日誌）

| 檔案 | Rotation 設定（application.properties） |
|------|------------------------------------------|
| `logs/transfer-app.log` | `max-file-size=10M`、`max-backup-index=10`、歷史檔後綴 `.yyyyMMdd_HHmm`、`rotate-on-boot=true` |
| `logs/reconciliation-app.log` | `max-file-size=20M`、`max-backup-index=14`、同款後綴與 rotate-on-boot |

輪替備份形如 `transfer-app.log.1`、`transfer-app.log.20260820_2135` 等（同樣 gitignore：`logs/`、`*.log`）。排查交易問題時，先看 `logs/transfer-app.log` 內的 `[HTTP-AUDIT]` 行（URI、HTTP code、耗時、INPUT/OUTPUT payload 全記錄，見 §6.5 與 [OBSERVABILITY](../02-architecture/OBSERVABILITY.md)）；對帳查詢與 CSV 匯出紀錄看 `logs/reconciliation-app.log`。

---

## 9. 常見錯誤

### 9.1 Port 衝突

- **症狀**：啟動即失敗，訊息含 `Port 8080 in use`（或 8090）。
- **原因**：8080 已被舊的 transfer-app process 或其他服務占用。
- **解法**：
  - 找出並停掉舊 process：`lsof -i:8080`（Linux/macOS）或 `netstat -ano | findstr 8080`（Windows）；
  - 或臨時換埠啟動：`java -Dquarkus.http.port=9080 -jar ...quarkus-run.jar`；
  - 注意 dev mode 與 run.jar 同時開也會互搶 8080。
- **預防**：雙 App 固定 8080/8090 分工（reconciliation-app 的 properties 註解即明言「為了避免與 transfer-app 衝突」才另立埠），勿隨意改動 `quarkus.http.port`。

### 9.2 SQLite 檔案鎖

- **症狀**：寫入拋 `SQLITE_BUSY`／database is locked；或外部工具（DB Browser 等）開著 `reconciliation.db` 導致 App 寫入卡住。
- **原因**：SQLite 單寫者模型；WAL 模式下仍只允許一個 writer。平台已設 `journal_mode=WAL`、`busy_timeout=5000`、連線池 `max-size=1`（base properties＋`AuditLogService` 初始化）緩解，但無法消除人為佔鎖。
- **解法**：
  - 關閉開著 DB 檔的外部工具再重試；
  - 確認雙 App 指向**同一個** `MYHELLO_DATA_DIR`（指向不同目錄會各自開檔，看似正常實則資料分裂）;
  - Windows 環境留意防毒／備份軟體短暫鎖定 `-wal`/`-shm` 檔；
  - App 運行中**絕不**手刪 `reconciliation.db-wal`／`-shm`。

### 9.3 離線 repo 空（或不完整）

- **症狀 A**：腳本立刻退出，訊息 `❌ 錯誤：找不到離線套件庫目錄: .../offline-packages/maven-repo` → 離線庫根本不存在（clone 不完整或被清掉）。
- **症狀 B**：`mvn -o` 中途報 `The following artifacts could not be resolved ... (offline mode)` → 離線庫存在但缺件。
- **解法**：
  - 症狀 A：重新取得完整的 `offline-packages/maven-repo/`（此目錄應隨專案交付）；
  - 症狀 B：在**有網路**的機器以相同 Maven 版本把缺件補進離線庫（或整庫重建），再到斷網環境使用；`-o` 是嚴格模式，任何一件快取 miss 都會失敗，這是設計行為而非 bug；
  - PowerShell 環境另注意：腳本會先檢查 `mvn` 是否在 PATH，未裝 Maven 會被擋在最前面。

### 9.4 其他高頻地雷

| 症狀 | 原因與解法 |
|------|-----------|
| 改了 `distribution/transfer-app/src/main/resources/saga2-transfer-workflow.sw.yaml` 卻「沒生效」或下次建置被改回 | 該檔是同步副本（建置產物）。請改 canonical 來源 `domain-transfer/transfer-workflow/src/main/resources/`，詳見 [PROJECT-LAYOUT §6](./PROJECT-LAYOUT.md#6-sync-domain-resources單一事實來源機制) |
| GET 打 workflow 端點回 `403 {"error": "Only POST method is allowed"}` | `SonataFlowSecurityConfig$RuntimeFilter` 全域僅放行 POST（少數白名單路徑除外）。workflow 啟動、mock API 一律用 POST |
| `AMT` 用字串（如 `"300"`）收到 400 | `ValidateInput` 要求 `type == "number"`，JSON 數字不要加引號 |
| RBFAIL 測試沒觸發 409 | 哨兵只在**回沖（EC=true）**階段生效且區分大小寫：情境 5 需要 `AMT > 500`（才會走到回沖）且帳號恰為大寫 `RBFAIL` |
| 單模組 `mvn quarkus:dev` 找不到 platform-* 依賴 | 先在根目錄跑過一次完整建置（或改用 `mvn quarkus:dev -pl distribution/transfer-app` 於根目錄執行），確保 reactor 內模組已安裝至本地 repo |

---

## 下一步

- [PROJECT-LAYOUT](./PROJECT-LAYOUT.md)：目錄地圖、模組依賴 DAG、「單一事實來源」規則
- [ARCHITECTURE](../02-architecture/ARCHITECTURE.md)：三層架構、WAL 共享、核心不變式
- [SAGA2-TEMPLATE-DEEP-DIVE](../03-workflow-dev-guide/SAGA2-TEMPLATE-DEEP-DIVE.md)：saga2 v2.2.0 全 18 states 精解（開發新 workflow 必讀）
- [TROUBLESHOOTING](../07-operations/TROUBLESHOOTING.md)：更多「症狀→原因→解法」對照
