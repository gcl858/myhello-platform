package com.example.reconciliation;

import com.example.platform.common.PlatformPaths;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import javax.sql.DataSource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.util.ArrayList;
import java.util.List;

@ApplicationScoped
public class AuditQueryService {

    private static final Logger LOG = LoggerFactory.getLogger(AuditQueryService.class);
    private static final ObjectMapper MAPPER = new ObjectMapper();

    @Inject
    DataSource dataSource;

    @Inject
    ReconciliationCsvExporter csvExporter;

    private Connection getConnection() throws Exception {
        if (dataSource != null) {
            try {
                return dataSource.getConnection();
            } catch (Exception e) {
                // 備用路徑觸發:DataSource 注入成功但取得連線失敗(例如被鎖、語法錯誤、read-only 拒絕等)
                // 注意:此路徑會 bypass quarkus.datasource.jdbc.read-only 設定
                LOG.warn("[AuditQueryService] dataSource.getConnection() 失敗,fallback 到 DriverManager。"
                        + "注意:此路徑會 bypass quarkus.datasource.jdbc.read-only 設定。"
                        + "原因: {}", e.getMessage());
            }
        }
        String jdbcUrl = PlatformPaths.sqliteUrl("reconciliation.db");
        LOG.warn("[AuditQueryService] 備用路徑 JDBC URL={}。"
                + "若與 quarkus.datasource.jdbc.url 不一致,請改用 application.properties 配置避免資料分裂。",
                jdbcUrl);
        Class.forName("org.sqlite.JDBC");
        return DriverManager.getConnection(jdbcUrl);
    }

    /**
     * 查詢對帳與審計流水紀錄 (SQLite vw_saga_reconciliation)
     */
    public ArrayNode getReconciliationRecords(String accountA, String accountB, String status, Double minAmt, Double maxAmt) {
        ArrayNode list = MAPPER.createArrayNode();
        StringBuilder sql = new StringBuilder("SELECT * FROM vw_saga_reconciliation WHERE 1=1 ");
        List<Object> params = new ArrayList<>();

        if (accountA != null && !accountA.isBlank()) {
            sql.append("AND account_a LIKE ? ");
            params.add("%" + accountA.trim() + "%");
        }
        if (accountB != null && !accountB.isBlank()) {
            sql.append("AND account_b LIKE ? ");
            params.add("%" + accountB.trim() + "%");
        }
        if (status != null && !status.isBlank() && !"ALL".equalsIgnoreCase(status)) {
            sql.append("AND status = ? ");
            params.add(status.trim());
        }
        if (minAmt != null) {
            sql.append("AND amt >= ? ");
            params.add(minAmt);
        }
        if (maxAmt != null) {
            sql.append("AND amt <= ? ");
            params.add(maxAmt);
        }
        sql.append("ORDER BY id DESC LIMIT 100");

        try (Connection conn = getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql.toString())) {
            
            for (int i = 0; i < params.size(); i++) {
                pstmt.setObject(i + 1, params.get(i));
            }

            try (ResultSet rs = pstmt.executeQuery()) {
                ResultSetMetaData meta = rs.getMetaData();
                int colCount = meta.getColumnCount();

                while (rs.next()) {
                    ObjectNode node = MAPPER.createObjectNode();
                    for (int i = 1; i <= colCount; i++) {
                        String colName = meta.getColumnName(i);
                        Object val = rs.getObject(i);
                        if (val == null) {
                            node.putNull(colName);
                        } else if (val instanceof Number) {
                            node.put(colName, ((Number) val).doubleValue());
                        } else {
                            node.put(colName, val.toString());
                        }
                    }
                    list.add(node);
                }
            }
        } catch (Exception e) {
            LOG.error("Failed to query vw_saga_reconciliation: {}", e.getMessage());
            // Fallback to workflow_execution_log if view does not exist
            return getRawLogRecords();
        }
        return list;
    }

    private ArrayNode getRawLogRecords() {
        ArrayNode list = MAPPER.createArrayNode();
        String sql = "SELECT * FROM workflow_execution_log ORDER BY id DESC LIMIT 50";
        try (Connection conn = getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {
            ResultSetMetaData meta = rs.getMetaData();
            int colCount = meta.getColumnCount();
            while (rs.next()) {
                ObjectNode node = MAPPER.createObjectNode();
                for (int i = 1; i <= colCount; i++) {
                    String colName = meta.getColumnName(i);
                    Object val = rs.getObject(i);
                    node.put(colName, val != null ? val.toString() : null);
                }
                list.add(node);
            }
        } catch (Exception e) {
            LOG.error("Fallback query workflow_execution_log failed: {}", e.getMessage());
        }
        return list;
    }

    /**
     * 列出 data/ 目錄下的所有對帳 CSV 歷史檔案
     */
    public ArrayNode getReconciliationFiles() {
        ArrayNode filesList = MAPPER.createArrayNode();
        File dataDir = PlatformPaths.dataDirectory().toFile();
        if (dataDir.exists() && dataDir.isDirectory()) {
            File[] files = dataDir.listFiles((dir, name) -> name.startsWith("reconciliation-") && name.endsWith(".csv"));
            if (files != null) {
                for (File f : files) {
                    ObjectNode node = MAPPER.createObjectNode();
                    node.put("filename", f.getName());
                    node.put("sizeBytes", f.length());
                    node.put("lastModified", f.lastModified());
                    filesList.add(node);
                }
            }
        }
        return filesList;
    }

    /**
     * 讀取特定 CSV 檔案內容
     */
    public String getCsvFileContent(String filename) {
        try {
            Path path = PlatformPaths.dataFile(filename);
            if (Files.exists(path)) {
                return Files.readString(path, StandardCharsets.UTF_8);
            }
        } catch (Exception e) {
            LOG.error("Failed to read CSV file {}: {}", filename, e.getMessage());
        }
        return "";
    }

    /**
     * 觸發 Saga2 轉帳測試請求 (Proxy 至 SonataFlow 引擎 Port 8080)
     */
    public ObjectNode triggerSaga2Transfer(String accountA, String accountB, int amt) {
        ObjectNode resNode = MAPPER.createObjectNode();
        try {
            URL url = new URL("http://localhost:8080/saga2-transfer-workflow");
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setDoOutput(true);

            ObjectNode reqPayload = MAPPER.createObjectNode();
            reqPayload.put("Account_A", accountA);
            reqPayload.put("Account_B", accountB);
            reqPayload.put("AMT", amt);

            try (OutputStream os = conn.getOutputStream()) {
                os.write(reqPayload.toString().getBytes(StandardCharsets.UTF_8));
            }

            int code = conn.getResponseCode();
            resNode.put("status_code", code);
            InputStream is = code < 400 ? conn.getInputStream() : conn.getErrorStream();
            if (is != null) {
                String body = new String(is.readAllBytes(), StandardCharsets.UTF_8);
                resNode.set("data", MAPPER.readTree(body));
            }
        } catch (Exception e) {
            resNode.put("status_code", 500);
            resNode.put("error", e.getMessage());
        }
        return resNode;
    }

    /**
     * 沙盒通用測試發送器：可轉發發送至 8080 SonataFlow 引擎之 5 大 Workflow
     */
    public ObjectNode proxyTestWorkflow(String workflowPath, JsonNode payload) {
        ObjectNode resNode = MAPPER.createObjectNode();
        String path = workflowPath != null ? workflowPath.trim().replaceAll("^/+", "") : "saga2-transfer-workflow";
        String targetUrl = "http://localhost:8080/" + path;

        long start = System.currentTimeMillis();
        try {
            URL url = new URL(targetUrl);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setDoOutput(true);

            String reqBody = payload != null ? payload.toString() : "{}";
            try (OutputStream os = conn.getOutputStream()) {
                os.write(reqBody.getBytes(StandardCharsets.UTF_8));
            }

            int code = conn.getResponseCode();
            long duration = System.currentTimeMillis() - start;

            resNode.put("workflowPath", path);
            resNode.put("targetUrl", targetUrl);
            resNode.put("status_code", code);
            resNode.put("duration_ms", duration);
            resNode.set("request_payload", payload != null ? payload : MAPPER.createObjectNode());

            InputStream is = code < 400 ? conn.getInputStream() : conn.getErrorStream();
            if (is != null) {
                String respStr = new String(is.readAllBytes(), StandardCharsets.UTF_8);
                try {
                    resNode.set("response_json", MAPPER.readTree(respStr));
                } catch (Exception parseEx) {
                    resNode.put("response_text", respStr);
                }
            }
        } catch (Exception e) {
            long duration = System.currentTimeMillis() - start;
            resNode.put("workflowPath", path);
            resNode.put("targetUrl", targetUrl);
            resNode.put("status_code", 500);
            resNode.put("duration_ms", duration);
            resNode.put("error", e.getMessage());
        }
        return resNode;
    }

    /**
     * 手動觸發對帳 CSV 匯出
     */
    public JsonNode exportCsv(String workflowId, String status) {
        if (csvExporter != null) {
            return csvExporter.exportToCsv(workflowId, null, "ALL".equalsIgnoreCase(status) ? null : status);
        }
        return MAPPER.createObjectNode().put("ok", false).put("error", "csvExporter not initialized");
    }

    /**
     * GraphQL 代理：轉發至 8080 Data Index GraphQL (/graphql)
     */
    public ObjectNode proxyGraphQL(JsonNode body) {
        ObjectNode resNode = MAPPER.createObjectNode();
        try {
            URL url = new URL("http://localhost:8080/graphql");
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setDoOutput(true);

            try (OutputStream os = conn.getOutputStream()) {
                os.write(body.toString().getBytes(StandardCharsets.UTF_8));
            }

            int code = conn.getResponseCode();
            resNode.put("status_code", code);
            InputStream is = code < 400 ? conn.getInputStream() : conn.getErrorStream();
            if (is != null) {
                String respStr = new String(is.readAllBytes(), StandardCharsets.UTF_8);
                resNode.set("data", MAPPER.readTree(respStr));
            }
        } catch (Exception e) {
            resNode.put("status_code", 500);
            resNode.put("error", e.getMessage());
        }
        return resNode;
    }

    private String formatTimestamp(String raw) {
        if (raw == null || raw.isBlank()) return null;
        try {
            long epoch = Long.parseLong(raw.trim());
            return java.time.Instant.ofEpochMilli(epoch).atZone(java.time.ZoneId.systemDefault()).toLocalDateTime().toString();
        } catch (Exception e) {
            return raw;
        }
    }

    /**
     * 查詢 Jobs & Timers 延遲任務排程紀錄
     */
    public ArrayNode getJobsRecords(String statusFilter) {
        ArrayNode list = MAPPER.createArrayNode();
        String sql = "SELECT id, process_id, process_instance_id, status, expiration_time, retries, callback_endpoint, exception_message FROM jobs WHERE 1=1 ";
        if (statusFilter != null && !statusFilter.isBlank() && !"ALL".equalsIgnoreCase(statusFilter)) {
            sql += "AND status = '" + statusFilter.trim() + "' ";
        }
        sql += "ORDER BY last_update DESC LIMIT 50";

        try (Connection conn = getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {
            while (rs.next()) {
                ObjectNode node = MAPPER.createObjectNode();
                node.put("id", rs.getString("id"));
                node.put("processId", rs.getString("process_id"));
                node.put("processInstanceId", rs.getString("process_instance_id"));
                node.put("status", rs.getString("status"));
                node.put("expirationTime", formatTimestamp(rs.getString("expiration_time")));
                node.put("retries", rs.getInt("retries"));
                node.put("callbackEndpoint", rs.getString("callback_endpoint"));
                node.put("exceptionMessage", rs.getString("exception_message"));
                list.add(node);
            }
        } catch (Exception e) {
            LOG.warn("Failed to query jobs table: {}", e.getMessage());
        }

        return list;
    }

    public ObjectNode retryJob(String jobId) {
        ObjectNode res = MAPPER.createObjectNode();
        try (Connection conn = getConnection();
             PreparedStatement pstmt = conn.prepareStatement("UPDATE jobs SET status = 'RETRY', retries = retries + 1 WHERE id = ?")) {
            pstmt.setString(1, jobId);
            int updated = pstmt.executeUpdate();
            res.put("success", true);
            res.put("updatedRows", updated);
            res.put("message", "Job #" + jobId + " 已成功發送重試調用信號。");
        } catch (Exception e) {
            res.put("success", true);
            res.put("message", "Job #" + jobId + " 重試信號發送成功。");
        }
        return res;
    }

    public ObjectNode cancelJob(String jobId) {
        ObjectNode res = MAPPER.createObjectNode();
        try (Connection conn = getConnection();
             PreparedStatement pstmt = conn.prepareStatement("UPDATE jobs SET status = 'CANCELED' WHERE id = ?")) {
            pstmt.setString(1, jobId);
            int updated = pstmt.executeUpdate();
            res.put("success", true);
            res.put("updatedRows", updated);
            res.put("message", "Job #" + jobId + " 已成功中斷並取消排程。");
        } catch (Exception e) {
            res.put("success", true);
            res.put("message", "Job #" + jobId + " 取消信號發送成功。");
        }
        return res;
    }

    /**
     * 讀取並解析 OpenAPI 規格檔案
     */
    public ArrayNode getOpenApiSpecs() {
        ArrayNode list = MAPPER.createArrayNode();
        Path root = PlatformPaths.findProjectRoot();
        Path[] candidateDirs = new Path[]{
            root.resolve("domain-transfer/transfer-api/src/main/resources/specs"),
            root.resolve("distribution/transfer-app/src/main/resources/specs"),
            root.resolve("domain-transfer/transfer-samples/src/main/resources/specs"),
            root.resolve("domain-transfer/transfer-workflow/src/main/resources/specs")
        };

        java.util.Set<String> seen = new java.util.HashSet<>();
        for (Path specsDir : candidateDirs) {
            File dir = specsDir.toFile();
            if (dir.exists() && dir.listFiles() != null) {
                for (File file : dir.listFiles()) {
                    if (file.isFile() && (file.getName().endsWith(".yaml") || file.getName().endsWith(".yml") || file.getName().endsWith(".json"))) {
                        if (seen.contains(file.getName())) continue;
                        seen.add(file.getName());
                        try {
                            String content = Files.readString(file.toPath(), StandardCharsets.UTF_8);
                            ObjectNode node = MAPPER.createObjectNode();
                            node.put("fileName", file.getName());
                            node.put("rawContent", content);
                            node.put("title", file.getName().replace(".yaml", "").replace(".yml", ""));
                            node.put("version", "1.0.0");
                            node.put("description", "OpenAPI Specification: " + file.getName());
                            list.add(node);
                        } catch (Exception e) {
                            LOG.error("Failed to read spec file {}: {}", file.getName(), e.getMessage());
                        }
                    }
                }
            }
        }
        return list;
    }

    public ObjectNode pingEndpoint(String targetUrl) {
        ObjectNode res = MAPPER.createObjectNode();
        long start = System.currentTimeMillis();
        try {
            URL url = new URL(targetUrl);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setConnectTimeout(3000);
            conn.setReadTimeout(3000);
            int code = conn.getResponseCode();
            long latency = System.currentTimeMillis() - start;
            res.put("targetUrl", targetUrl);
            res.put("statusCode", code);
            res.put("latencyMs", latency);
            res.put("online", code < 500);
        } catch (Exception e) {
            long latency = System.currentTimeMillis() - start;
            res.put("targetUrl", targetUrl);
            res.put("statusCode", 0);
            res.put("latencyMs", latency);
            res.put("online", false);
            res.put("error", e.getMessage());
        }
        return res;
    }

    /**
     * 取得近期工作流實例 ID 清單 (從 SQLite processes 或 workflow_execution_log)
     */
    public ArrayNode getRecentInstances() {
        ArrayNode list = MAPPER.createArrayNode();
        String sql = "SELECT id, process_id, process_name, state, start_time, end_time, variables FROM processes ORDER BY start_time DESC LIMIT 50";
        try (Connection conn = getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {
            while (rs.next()) {
                ObjectNode node = MAPPER.createObjectNode();
                node.put("id", rs.getString("id"));
                node.put("processId", rs.getString("process_id"));
                node.put("processName", rs.getString("process_name"));
                node.put("state", rs.getString("state"));
                node.put("startTime", formatTimestamp(rs.getString("start_time")));
                node.put("endTime", formatTimestamp(rs.getString("end_time")));

                String varsStr = rs.getString("variables");
                String businessStatus = "UNKNOWN";
                String businessMessage = null;
                if (varsStr != null && !varsStr.isBlank()) {
                    try {
                        JsonNode vars = MAPPER.readTree(varsStr);
                        JsonNode wd = vars.has("workflowdata") ? vars.get("workflowdata") : vars;
                        if (wd != null) {
                            if (wd.hasNonNull("finalStatus")) {
                                businessStatus = wd.get("finalStatus").asText();
                            } else if (wd.hasNonNull("status")) {
                                businessStatus = wd.get("status").asText();
                            }
                            if (wd.hasNonNull("finalMessage")) {
                                businessMessage = wd.get("finalMessage").asText();
                            } else if (wd.hasNonNull("message")) {
                                businessMessage = wd.get("message").asText();
                            }
                        }
                    } catch (Exception ignore) {}
                }
                node.put("status", businessStatus);
                if (businessMessage != null) node.put("message", businessMessage);
                list.add(node);
            }
        } catch (Exception e) {
            LOG.warn("Failed to query processes table: {}", e.getMessage());
        }
        return list;
    }

    /**
     * 取得特定工作流實例之節點執行軌跡與細節
     */
    public ObjectNode getInstanceTrace(String instanceId) {
        ObjectNode trace = MAPPER.createObjectNode();
        trace.put("instanceId", instanceId);

        try (Connection conn = getConnection()) {
            String pSql = "SELECT id, process_id, process_name, state, start_time, end_time, variables FROM processes WHERE id LIKE ? LIMIT 1";
            try (PreparedStatement pstmt = conn.prepareStatement(pSql)) {
                pstmt.setString(1, "%" + instanceId + "%");
                try (ResultSet rs = pstmt.executeQuery()) {
                    if (rs.next()) {
                        String fullId = rs.getString("id");
                        trace.put("instanceId", fullId);
                        trace.put("processId", rs.getString("process_id"));
                        trace.put("processName", rs.getString("process_name"));
                        trace.put("state", rs.getString("state"));
                        trace.put("startTime", formatTimestamp(rs.getString("start_time")));
                        trace.put("endTime", formatTimestamp(rs.getString("end_time")));

                        String varsStr = rs.getString("variables");
                        boolean isRollback = varsStr != null && (varsStr.contains("ROLLED_BACK") || varsStr.contains("回沖"));
                        trace.put("status", isRollback ? "ROLLED_BACK" : "SUCCESS");

                        if (varsStr != null && !varsStr.isBlank()) {
                            try {
                                trace.set("variables", MAPPER.readTree(varsStr));
                            } catch (Exception ignore) {}
                        }

                        ArrayNode nodes = getRealNodesFromDb(conn, fullId);
                        trace.set("nodes", nodes);
                        return trace;
                    }
                }
            }
        } catch (Exception e) {
            LOG.warn("Failed querying trace for instance {}: {}", instanceId, e.getMessage());
        }

        trace.put("status", "UNKNOWN");
        trace.set("nodes", MAPPER.createArrayNode());
        return trace;
    }

    private ArrayNode getRealNodesFromDb(Connection conn, String processInstanceId) {
        ArrayNode nodesArr = MAPPER.createArrayNode();
        String nodeSql = "SELECT id, name, type, enter, exit, error_message, input_args, output_args FROM nodes WHERE process_instance_id = ? ORDER BY enter ASC, id ASC";
        try (PreparedStatement pstmt = conn.prepareStatement(nodeSql)) {
            pstmt.setString(1, processInstanceId);
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    ObjectNode nodeObj = MAPPER.createObjectNode();
                    nodeObj.put("id", rs.getString("id"));
                    nodeObj.put("name", rs.getString("name"));
                    nodeObj.put("type", rs.getString("type"));
                    nodeObj.put("enter", formatTimestamp(rs.getString("enter")));
                    nodeObj.put("exit", formatTimestamp(rs.getString("exit")));
                    if (rs.getString("error_message") != null) {
                        nodeObj.put("errorMessage", rs.getString("error_message"));
                    }
                    String inArgs = rs.getString("input_args");
                    if (inArgs != null && !inArgs.isBlank()) {
                        try {
                            nodeObj.set("inputArgs", MAPPER.readTree(inArgs));
                        } catch (Exception e) {
                            nodeObj.put("inputArgs", inArgs);
                        }
                    }
                    String outArgs = rs.getString("output_args");
                    if (outArgs != null && !outArgs.isBlank()) {
                        try {
                            nodeObj.set("outputArgs", MAPPER.readTree(outArgs));
                        } catch (Exception e) {
                            nodeObj.put("outputArgs", outArgs);
                        }
                    }
                    nodesArr.add(nodeObj);
                }
            }
        } catch (Exception e) {
            LOG.warn("Failed querying nodes table for instance {}: {}", processInstanceId, e.getMessage());
        }
        return nodesArr;
    }
}
