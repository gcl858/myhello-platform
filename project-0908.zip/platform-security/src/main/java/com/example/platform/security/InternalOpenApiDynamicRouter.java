package com.example.platform.security;

import io.quarkus.runtime.StartupEvent;
import io.vertx.core.Vertx;
import io.vertx.core.buffer.Buffer;
import io.vertx.core.http.HttpMethod;
import io.vertx.core.json.JsonObject;
import io.vertx.ext.web.Router;
import io.vertx.ext.web.RoutingContext;
import io.vertx.ext.web.client.HttpRequest;
import io.vertx.ext.web.client.HttpResponse;
import io.vertx.ext.web.client.WebClient;
import io.vertx.ext.web.handler.BodyHandler;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.enterprise.event.Observes;
import jakarta.inject.Inject;
import org.eclipse.microprofile.config.ConfigProvider;
import org.jboss.logging.Logger;
import org.yaml.snakeyaml.Yaml;

import java.io.InputStream;
import java.net.JarURLConnection;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * ===================================================================
 * InternalOpenApiDynamicRouter - OpenAPI 內部規格動態路由代理
 * ===================================================================
 *
 * 功能描述:
 *  1. 應用啟動時自動掃描 classpath 下 specs/internal/ 目錄的所有 OpenAPI YAML/YML 規格。
 *  2. 解析 paths 與 HTTP 方法 (特別是 POST)，將 OpenAPI 路徑模板 (如 /Omni/{creditcardid}/Repayment/Execute)
 *     轉為 Vert.x 路由格式 (/Omni/:creditcardid/Repayment/Execute)。
 *  3. 讀取 x-workflow-id (或 x-kogito-workflow-id) 擴充屬性，並向 Vert.x Router 動態註冊路由處理器。
 *  4. 執行期擷取所有 Path Parameters，自動合併至傳入的 Request Payload JSON 頂層。
 *  5. 使用非阻塞 WebClient 轉發至本地 SonataFlow 端點 (/{workflowId})，
 *     完整相容 UnwrapResponseFilter (解包) 與 WorkflowStatusFilter (狀態碼改寫)。
 */
@ApplicationScoped
public class InternalOpenApiDynamicRouter {

    private static final Logger LOG = Logger.getLogger(InternalOpenApiDynamicRouter.class);
    private static final Pattern PATH_PARAM_PATTERN = Pattern.compile("\\{([^}]+)\\}");

    @Inject
    Vertx vertx;

    private WebClient webClient;

    void onStart(@Observes StartupEvent ev, Router router) {
        this.webClient = WebClient.create(vertx);
        LOG.info("[DynamicRouter] 開始掃描 specs/internal/ 動態路由...");

        Set<String> specPaths = scanInternalSpecs();
        if (specPaths.isEmpty()) {
            LOG.info("[DynamicRouter] 未發現 specs/internal/ 規格檔案。");
            return;
        }

        int registeredCount = 0;
        for (String specPath : specPaths) {
            registeredCount += registerSpecRoutes(router, specPath);
        }
        LOG.infof("[DynamicRouter] 動態路由註冊完成，共註冊 %d 條端點路由。", registeredCount);
    }

    /**
     * 掃描 specs/internal/ 目錄下的所有 YAML/YML 規格檔案。
     * 兼顧 IDE 檔案目錄、JAR 打包環境與預設 fallback 檢查。
     */
    private Set<String> scanInternalSpecs() {
        Set<String> results = new LinkedHashSet<>();
        try {
            Enumeration<URL> urls = Thread.currentThread().getContextClassLoader().getResources("specs/internal");
            while (urls != null && urls.hasMoreElements()) {
                URL url = urls.nextElement();
                String protocol = url.getProtocol();
                if ("file".equalsIgnoreCase(protocol)) {
                    try {
                        Path dir = Paths.get(url.toURI());
                        if (Files.isDirectory(dir)) {
                            try (var stream = Files.walk(dir, 1)) {
                                stream.filter(p -> Files.isRegularFile(p) && isYamlFile(p.getFileName().toString()))
                                      .forEach(p -> results.add("specs/internal/" + p.getFileName().toString()));
                            }
                        }
                    } catch (Exception e) {
                        LOG.warnf("[DynamicRouter] 無法列舉 file 目錄 %s: %s", url, e.getMessage());
                    }
                } else if ("jar".equalsIgnoreCase(protocol)) {
                    try {
                        JarURLConnection conn = (JarURLConnection) url.openConnection();
                        try (JarFile jar = conn.getJarFile()) {
                            Enumeration<JarEntry> entries = jar.entries();
                            while (entries.hasMoreElements()) {
                                JarEntry entry = entries.nextElement();
                                String name = entry.getName();
                                if (name.startsWith("specs/internal/") && isYamlFile(name) && !entry.isDirectory()) {
                                    results.add(name);
                                }
                            }
                        }
                    } catch (Exception e) {
                        LOG.warnf("[DynamicRouter] 無法列舉 JAR 資源 %s: %s", url, e.getMessage());
                    }
                }
            }
        } catch (Exception e) {
            LOG.warnf("[DynamicRouter] 掃描 specs/internal 失敗: %s", e.getMessage());
        }

        return results;
    }

    private boolean isYamlFile(String filename) {
        if (filename == null) return false;
        String lower = filename.toLowerCase();
        return lower.endsWith(".yaml") || lower.endsWith(".yml");
    }

    /**
     * 解析單一規格檔案並向 Vert.x Router 註冊路由
     */
    @SuppressWarnings("unchecked")
    private int registerSpecRoutes(Router router, String specResourcePath) {
        int count = 0;
        try (InputStream is = Thread.currentThread().getContextClassLoader().getResourceAsStream(specResourcePath)) {
            if (is == null) {
                LOG.warnf("[DynamicRouter] 找不到規格檔 InputStream: %s", specResourcePath);
                return 0;
            }

            Yaml yaml = new Yaml();
            Map<String, Object> root = yaml.load(is);
            if (root == null) return 0;

            Map<String, Object> paths = (Map<String, Object>) root.get("paths");
            if (paths == null || paths.isEmpty()) return 0;

            for (Map.Entry<String, Object> pathEntry : paths.entrySet()) {
                String openApiPath = pathEntry.getKey();
                if (!(pathEntry.getValue() instanceof Map<?, ?> ops)) continue;

                for (Map.Entry<?, ?> opEntry : ops.entrySet()) {
                    String httpMethodName = String.valueOf(opEntry.getKey()).toUpperCase();
                    if (!(opEntry.getValue() instanceof Map<?, ?> opDetail)) continue;

                    // 僅針對 POST 等能夠觸發 workflow 的請求進行路由代理
                    if (!"POST".equalsIgnoreCase(httpMethodName)) {
                        continue;
                    }

                    // 取得目標 workflow ID (優先使用 x-workflow-id，其次 x-kogito-workflow-id)
                    String workflowId = null;
                    if (opDetail.containsKey("x-workflow-id")) {
                        workflowId = String.valueOf(opDetail.get("x-workflow-id")).trim();
                    } else if (opDetail.containsKey("x-kogito-workflow-id")) {
                        workflowId = String.valueOf(opDetail.get("x-kogito-workflow-id")).trim();
                    }

                    if (workflowId == null || workflowId.isBlank()) {
                        LOG.warnf("[DynamicRouter] 規格 %s 路徑 %s 未指定 x-workflow-id，略過註冊",
                                specResourcePath, openApiPath);
                        continue;
                    }

                    String vertxPath = toVertxPath(openApiPath);
                    final String targetWorkflowUri = workflowId.startsWith("/") ? workflowId : "/" + workflowId;

                    LOG.infof("[DynamicRouter] 註冊動態路由: %s %s -> %s (來源: %s)",
                            httpMethodName, vertxPath, targetWorkflowUri, specResourcePath);

                    router.route(HttpMethod.valueOf(httpMethodName), vertxPath)
                          .handler(BodyHandler.create())
                          .handler(rc -> handleForward(rc, targetWorkflowUri));

                    count++;
                }
            }
        } catch (Exception e) {
            LOG.errorf(e, "[DynamicRouter] 解析規格檔 %s 時發生錯誤", specResourcePath);
        }
        return count;
    }

    /**
     * 將 OpenAPI 的 {param} 格式轉換為 Vert.x 的 :param 格式
     */
    private String toVertxPath(String openApiPath) {
        Matcher matcher = PATH_PARAM_PATTERN.matcher(openApiPath);
        return matcher.replaceAll(":$1");
    }

    /**
     * 處理轉發核心：擷取路徑參數、注入 Request Body，並透過非阻塞 WebClient 轉發至本機工作流程端點
     */
    private void handleForward(RoutingContext rc, String targetWorkflowUri) {
        JsonObject payload;
        try {
            Buffer bodyBuffer = rc.body().buffer();
            if (bodyBuffer != null && bodyBuffer.length() > 0) {
                payload = new JsonObject(bodyBuffer);
            } else {
                payload = new JsonObject();
            }
        } catch (Exception e) {
            rc.response()
              .setStatusCode(400)
              .putHeader("content-type", "application/json")
              .end("{\"error\":\"Invalid JSON body: " + e.getMessage() + "\"}");
            return;
        }

        // 將所有 URL 路徑參數注入傳入 Payload 的頂層
        Map<String, String> pathParams = rc.pathParams();
        if (pathParams != null && !pathParams.isEmpty()) {
            for (Map.Entry<String, String> entry : pathParams.entrySet()) {
                payload.put(entry.getKey(), entry.getValue());
            }
        }

        // 動態偵測本伺服器監聽 Port (相容正式 port 與測試隨機/自訂 port)
        int localPort = (rc.request().localAddress() != null && rc.request().localAddress().port() > 0)
                ? rc.request().localAddress().port()
                : ConfigProvider.getConfig().getOptionalValue("quarkus.http.port", Integer.class).orElse(8080);

        LOG.infof("[DynamicRouter] forward %s %s -> %s (client=%s)",
            rc.request().method(),
            rc.request().path(),
            targetWorkflowUri,
            rc.request().remoteAddress());
            
        HttpRequest<Buffer> forwardReq = webClient.post(localPort, "127.0.0.1", targetWorkflowUri);

        // 轉發除特定逐跳標頭以外的 Client Headers (如 Authorization、Correlation ID 等)
        for (Map.Entry<String, String> header : rc.request().headers()) {
            String name = header.getKey();
            if (!name.equalsIgnoreCase("host") &&
                !name.equalsIgnoreCase("content-length") &&
                !name.equalsIgnoreCase("connection")) {
                forwardReq.putHeader(name, header.getValue());
            }
        }
        forwardReq.putHeader("content-type", "application/json");

        forwardReq.sendJsonObject(payload, ar -> {
            if (ar.succeeded()) {
                HttpResponse<Buffer> response = ar.result();
                rc.response().setStatusCode(response.statusCode());

                // 回傳 Headers (過濾掉逐跳標頭)
                for (Map.Entry<String, String> header : response.headers()) {
                    String name = header.getKey();
                    if (!name.equalsIgnoreCase("transfer-encoding") &&
                        !name.equalsIgnoreCase("content-length") &&
                        !name.equalsIgnoreCase("connection")) {
                        rc.response().putHeader(name, header.getValue());
                    }
                }

                Buffer respBody = response.bodyAsBuffer();
                if (respBody != null && respBody.length() > 0) {
                    rc.response().end(respBody);
                } else {
                    rc.response().end();
                }
            } else {
                LOG.errorf(ar.cause(), "[DynamicRouter] 轉發至本地 Workflow 端點 %s (port=%d) 失敗",
                        targetWorkflowUri, localPort);
                rc.response()
                  .setStatusCode(502)
                  .putHeader("content-type", "application/json")
                  .end("{\"error\":\"Bad Gateway: unable to forward request to " + targetWorkflowUri + "\"}");
            }
        });
    }
}

