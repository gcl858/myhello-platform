package com.example.transfer.workflow;

import com.fasterxml.jackson.databind.JsonNode;
import jakarta.enterprise.context.ApplicationScoped;

import java.util.ArrayList;
import java.util.List;

/**
 * ===================================================================
 * OmniCashBusinessRuleValidator - omni_cash_transaction 業務規則
 * ===================================================================
 *
 * 自 OpenApiSchemaValidator 抽離之 omni 專屬業務規則:
 *   1. operationType 必須為 A 或 B
 *   2. amount 必須大於 0
 *   3. operationType=A 時,不可填 originalSequenceNumber
 *   4. operationType=B 時,originalSequenceNumber 為必填
 *
 * 對應 x-workflow-id = "omni_cash_transaction"。
 */
@ApplicationScoped
public class OmniCashBusinessRuleValidator implements BusinessRuleValidator {

    private static final String OMNI_WORKFLOW_ID = "omni_cash_transaction";

    @Override
    public String workflowId() {
        return OMNI_WORKFLOW_ID;
    }

    @Override
    public List<OpenApiSchemaValidator.ValidationError> validate(JsonNode payload) {
        List<OpenApiSchemaValidator.ValidationError> errors = new ArrayList<>();

        String operationType = payload.has("operationType") ? payload.get("operationType").asText() : "";
        String origSeq = payload.has("originalSequenceNumber") ? payload.get("originalSequenceNumber").asText() : "";
        String amount = payload.has("amount") ? payload.get("amount").asText() : "";

        // 1. operationType 必須為 A 或 B
        if (!"A".equals(operationType) && !"B".equals(operationType)) {
            errors.add(new OpenApiSchemaValidator.ValidationError("operationType", "E0001",
                    "operationType 必須為 A 或 B"));
        }

        // 2. amount 必須大於 0
        if (!amount.isBlank()) {
            if ("0".equals(amount) || "0000000000".equals(amount)) {
                errors.add(new OpenApiSchemaValidator.ValidationError("amount", "E0001", "amount 必須大於 0"));
            } else {
                try {
                    String cleanAmount = amount.startsWith("FAIL_") ? amount.substring(5) : amount;
                    if (Long.parseLong(cleanAmount) <= 0) {
                        errors.add(new OpenApiSchemaValidator.ValidationError("amount", "E0001",
                                "amount 必須大於 0"));
                    }
                } catch (NumberFormatException ignored) {
                }
            }
        }

        // 3. 條件必填:
        // operationType=A 時,不可填 originalSequenceNumber
        if ("A".equals(operationType) && !origSeq.isBlank()) {
            errors.add(new OpenApiSchemaValidator.ValidationError("originalSequenceNumber", "E0002",
                    "operationType=A 時不可帶 originalSequenceNumber"));
        }

        // operationType=B 時,originalSequenceNumber 為必填
        if ("B".equals(operationType) && origSeq.isBlank()) {
            errors.add(new OpenApiSchemaValidator.ValidationError("originalSequenceNumber", "E0002",
                    "operationType=B 時, originalSequenceNumber 為必填"));
        }

        return errors;
    }
}
