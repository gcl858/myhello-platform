package com.example.transfer.workflow;

import com.fasterxml.jackson.databind.JsonNode;
import jakarta.enterprise.context.ApplicationScoped;

import java.util.ArrayList;
import java.util.List;

/**
 * ===================================================================
 * RemittanceBusinessRuleValidator - remittance_transaction 業務規則
 * ===================================================================
 *
 * 自 OpenApiSchemaValidator 抽離之 remittance 專屬業務規則 (H13a):
 *   1. operationType 必須為 A, B 或 C
 *   2. amount 必須大於 0 (支援 FAIL_ 哨兵豁免)
 *   3. operationType=A 時, 不可填 originalSequenceNumber 與 cancellationReason
 *   4. operationType=B 時, 不可填 originalSequenceNumber 與 cancellationReason; 必填 currency, fxRate, beneficiaryBankBIC, purposeCode
 *   5. operationType=C 時, originalSequenceNumber 與 cancellationReason 為必填
 *
 * 對應 x-workflow-id = "remittance_transaction"。
 */
@ApplicationScoped
public class RemittanceBusinessRuleValidator implements BusinessRuleValidator {

    private static final String REMITTANCE_WORKFLOW_ID = "remittance_transaction";

    @Override
    public String workflowId() {
        return REMITTANCE_WORKFLOW_ID;
    }

    @Override
    public List<OpenApiSchemaValidator.ValidationError> validate(JsonNode payload) {
        List<OpenApiSchemaValidator.ValidationError> errors = new ArrayList<>();

        String operationType = payload.has("operationType") ? payload.get("operationType").asText() : "";
        String origSeq = payload.has("originalSequenceNumber") ? payload.get("originalSequenceNumber").asText() : "";
        String cancelReason = payload.has("cancellationReason") ? payload.get("cancellationReason").asText() : "";
        String amount = payload.has("amount") ? payload.get("amount").asText() : "";

        // 1. operationType 必須為 A, B 或 C
        if (!"A".equals(operationType) && !"B".equals(operationType) && !"C".equals(operationType)) {
            errors.add(new OpenApiSchemaValidator.ValidationError("operationType", "E0001",
                    "operationType 必須為 A, B 或 C"));
        }

        // 2. amount 必須大於 0
        if (!amount.isBlank()) {
            if ("0".equals(amount) || "0000000000".equals(amount)) {
                errors.add(new OpenApiSchemaValidator.ValidationError("amount", "E0001", "amount 必須大於 0"));
            } else {
                try {
                    String cleanAmount = amount.startsWith("FAIL_") ? amount.substring(5) : amount;
                    if (Long.parseLong(cleanAmount) <= 0) {
                        errors.add(new OpenApiSchemaValidator.ValidationError("amount", "E0001",
                                "amount 必須大於 0"));
                    }
                } catch (NumberFormatException ignored) {
                }
            }
        }

        // 3. 條件必填 / 禁填約束
        if ("A".equals(operationType)) {
            if (!origSeq.isBlank()) {
                errors.add(new OpenApiSchemaValidator.ValidationError("originalSequenceNumber", "E0002",
                        "operationType=A 時不可帶 originalSequenceNumber"));
            }
            if (!cancelReason.isBlank()) {
                errors.add(new OpenApiSchemaValidator.ValidationError("cancellationReason", "E0002",
                        "operationType=A 時不可帶 cancellationReason"));
            }
        } else if ("B".equals(operationType)) {
            if (!origSeq.isBlank()) {
                errors.add(new OpenApiSchemaValidator.ValidationError("originalSequenceNumber", "E0002",
                        "operationType=B 時不可帶 originalSequenceNumber"));
            }
            if (!cancelReason.isBlank()) {
                errors.add(new OpenApiSchemaValidator.ValidationError("cancellationReason", "E0002",
                        "operationType=B 時不可帶 cancellationReason"));
            }
            if (!payload.has("currency") || payload.get("currency").asText().isBlank()) {
                errors.add(new OpenApiSchemaValidator.ValidationError("currency", "E0002",
                        "operationType=B 跨境匯款幣別 currency 為必填"));
            }
            if (!payload.has("fxRate") || payload.get("fxRate").asText().isBlank()) {
                errors.add(new OpenApiSchemaValidator.ValidationError("fxRate", "E0002",
                        "operationType=B 跨境匯款匯率 fxRate 為必填"));
            }
            if (!payload.has("beneficiaryBankBIC") || payload.get("beneficiaryBankBIC").asText().isBlank()) {
                errors.add(new OpenApiSchemaValidator.ValidationError("beneficiaryBankBIC", "E0002",
                        "operationType=B 跨境匯款受款行 BIC 為必填"));
            }
            if (!payload.has("purposeCode") || payload.get("purposeCode").asText().isBlank()) {
                errors.add(new OpenApiSchemaValidator.ValidationError("purposeCode", "E0002",
                        "operationType=B 跨境匯款申報性質代碼 purposeCode 為必填"));
            }
        } else if ("C".equals(operationType)) {
            if (origSeq.isBlank()) {
                errors.add(new OpenApiSchemaValidator.ValidationError("originalSequenceNumber", "E0002",
                        "operationType=C 匯款沖銷時, originalSequenceNumber 為必填"));
            }
            if (cancelReason.isBlank()) {
                errors.add(new OpenApiSchemaValidator.ValidationError("cancellationReason", "E0002",
                        "operationType=C 匯款沖銷時, cancellationReason 為必填"));
            }
        }

        return errors;
    }
}
