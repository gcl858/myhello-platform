package com.example.transfer.workflow;

import com.fasterxml.jackson.databind.JsonNode;

import java.util.List;

/**
 * ===================================================================
 * BusinessRuleValidator - 各 workflow 業務規則擴展點
 * ===================================================================
 *
 * 用於將特定 workflow 之業務規則從 OpenApiSchemaValidator 抽離。
 * OpenApiSchemaValidator 於啟動時掃描所有實作此介面之 CDI Bean,
 * 並以 workflowId() 為鍵建立 dispatch map。
 *
 * 實作時應標註 @ApplicationScoped,並於 workflowId() 回傳
 * 該 workflow 之 x-workflow-id(對應 specs/internal/*.yaml)。
 *
 * 若無業務規則需額外檢核,可不提供實作;Validator 將略過此步驟。
 */
public interface BusinessRuleValidator {

    /**
     * @return 此實作對應之 workflowId (即 OpenAPI x-workflow-id)
     */
    String workflowId();

    /**
     * 執行業務規則檢核;呼叫端應於 OpenAPI Schema 驗證通過後再呼叫此方法。
     *
     * @param payload 請求負載(JSON Object)
     * @return 錯誤清單;若空集合表示通過
     */
    List<OpenApiSchemaValidator.ValidationError> validate(JsonNode payload);
}
