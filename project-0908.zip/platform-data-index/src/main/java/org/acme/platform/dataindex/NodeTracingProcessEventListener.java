package org.acme.platform.dataindex;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import io.quarkus.arc.Unremovable;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import org.kie.api.event.process.ErrorEvent;
import org.kie.api.event.process.ProcessCompletedEvent;
import org.kie.api.event.process.ProcessNodeLeftEvent;
import org.kie.api.event.process.ProcessNodeTriggeredEvent;
import org.kie.api.runtime.process.NodeInstanceContainer;
import org.kie.api.runtime.process.WorkflowProcessInstance;
import org.kie.kogito.internal.process.event.DefaultKogitoProcessEventListener;
import org.kie.kogito.internal.process.runtime.KogitoNodeInstance;
import org.kie.kogito.internal.process.runtime.KogitoWorkflowProcessInstance;
import org.kie.kogito.internal.process.runtime.KogitoWorkItemNodeInstance;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * ProcessEventListener 負責在所有節點執行時自動記錄:
 * 1) input_args: 進入節點時的輸入參數 / 流程狀態 snapshot，並附帶 _trace (seq, prev, parent)
 * 2) output_args: 離開節點時的輸出結果 / 流程狀態 snapshot
 * 3) error_message: 節點或流程發生錯誤時的詳細錯誤訊息
 *
 * 確保 nodes 資料表 (reconciliation.db) 中所有節點 (Split, ActionNode, StartNode, EndNode,
 * WorkItemNode, CompositeContextNode, Join 等) 均有完整 I/O、錯誤紀錄與前後階層關係。
 */
@ApplicationScoped
@Unremovable
public class NodeTracingProcessEventListener extends DefaultKogitoProcessEventListener {

    private static final Logger LOG = LoggerFactory.getLogger(NodeTracingProcessEventListener.class);
    private static final String INPUT_ARGS_KEY = "inputArgs";
    private static final String OUTPUT_ARGS_KEY = "outputArgs";
    private static final String ERROR_MESSAGE_KEY = "errorMessage";
    private static final String WORKFLOW_DATA_KEY = "workflowdata";

    @Inject
    ObjectMapper objectMapper;

    private final ObjectMapper fallbackMapper = new ObjectMapper();

    private final Map<String, AtomicInteger> seqCounters = Collections.synchronizedMap(
            new LinkedHashMap<>(128, 0.75f, true) {
                @Override
                protected boolean removeEldestEntry(Map.Entry<String, AtomicInteger> eldest) {
                    return size() > 500;
                }
            });

    private final Map<String, String> lastNodeMap = Collections.synchronizedMap(
            new LinkedHashMap<>(128, 0.75f, true) {
                @Override
                protected boolean removeEldestEntry(Map.Entry<String, String> eldest) {
                    return size() > 500;
                }
            });

    private static final String TRACE_SNAPSHOT_KEY = "_trace_snapshot";

    @Override
    public void beforeNodeTriggered(ProcessNodeTriggeredEvent event) {
        try {
            if (event.getNodeInstance() instanceof KogitoNodeInstance nodeInstance) {
                String piId = event.getProcessInstance() != null ? event.getProcessInstance().getId() : null;
                int seq = 0;
                String prevNode = null;
                if (piId != null) {
                    seq = seqCounters.computeIfAbsent(piId, k -> new AtomicInteger(0)).incrementAndGet();
                    prevNode = lastNodeMap.put(piId, nodeInstance.getNodeName());
                }

                String parentStateName = null;
                NodeInstanceContainer container = nodeInstance.getNodeInstanceContainer();
                if (container instanceof KogitoNodeInstance parentNode) {
                    parentStateName = parentNode.getNodeName();
                }

                Map<String, Object> metaData = nodeInstance.getMetaData();
                if (metaData != null) {
                    ObjectMapper mapper = objectMapper != null ? objectMapper : fallbackMapper;
                    ObjectNode traceNode = mapper.createObjectNode();
                    traceNode.put("seq", seq);
                    if (prevNode != null) {
                        traceNode.put("prev", prevNode);
                    }
                    if (parentStateName != null) {
                        traceNode.put("parent", parentStateName);
                    }
                    metaData.put(TRACE_SNAPSHOT_KEY, traceNode);

                    Object existingInput = metaData.get(INPUT_ARGS_KEY);
                    Object inputArgs = (existingInput != null) ? existingInput : extractInputArgs(event, nodeInstance);
                    JsonNode inputSnapshot = snapshotValue(inputArgs);
                    ObjectNode inputWrapper;
                    if (inputSnapshot instanceof ObjectNode on) {
                        inputWrapper = on;
                    } else if (inputSnapshot != null) {
                        inputWrapper = mapper.createObjectNode();
                        inputWrapper.set("data", inputSnapshot);
                    } else {
                        inputWrapper = mapper.createObjectNode();
                    }

                    inputWrapper.set("_trace", traceNode);
                    metaData.put(INPUT_ARGS_KEY, inputWrapper);
                }
            }
        } catch (Exception e) {
            LOG.warn("Failed to capture inputArgs for node {}: {}",
                    event.getNodeInstance() != null ? event.getNodeInstance().getNodeName() : "unknown",
                    e.getMessage());
        }
    }

    @Override
    public void beforeNodeLeft(ProcessNodeLeftEvent event) {
        try {
            if (event.getNodeInstance() instanceof KogitoNodeInstance nodeInstance) {
                Map<String, Object> metaData = nodeInstance.getMetaData();
                if (metaData != null) {
                    // Re-enrich inputArgs with _trace if WorkItemHandler overwrote it during execution
                    Object traceSnapshot = metaData.get(TRACE_SNAPSHOT_KEY);
                    if (traceSnapshot instanceof JsonNode traceNode) {
                        Object currentInput = metaData.get(INPUT_ARGS_KEY);
                        if (currentInput != null) {
                            ObjectMapper mapper = objectMapper != null ? objectMapper : fallbackMapper;
                            JsonNode inputJson = snapshotValue(currentInput);
                            ObjectNode inputWrapper;
                            if (inputJson instanceof ObjectNode on) {
                                inputWrapper = on;
                            } else {
                                inputWrapper = mapper.createObjectNode();
                                inputWrapper.set("data", inputJson);
                            }
                            if (!inputWrapper.has("_trace")) {
                                inputWrapper.set("_trace", traceNode);
                                metaData.put(INPUT_ARGS_KEY, inputWrapper);
                            }
                        }
                    }

                    if (metaData.get(OUTPUT_ARGS_KEY) == null) {
                        Object outputArgs = extractOutputArgs(event, nodeInstance);
                        if (outputArgs != null) {
                            metaData.put(OUTPUT_ARGS_KEY, outputArgs);
                        }
                    }
                }
            }
        } catch (Exception e) {
            LOG.warn("Failed to capture outputArgs for node {}: {}",
                    event.getNodeInstance() != null ? event.getNodeInstance().getNodeName() : "unknown",
                    e.getMessage());
        }
    }

    @Override
    public void onError(ErrorEvent event) {
        try {
            if (event.getProcessInstance() instanceof KogitoWorkflowProcessInstance pi) {
                String errorMessage = pi.getErrorMessage();
                if (errorMessage == null && pi.getErrorCause().isPresent()) {
                    Throwable cause = pi.getErrorCause().get();
                    errorMessage = cause.getMessage() != null ? cause.getMessage() : cause.toString();
                }
                if (errorMessage == null) {
                    errorMessage = "Process execution error";
                }

                if (event.getNodeInstance() instanceof KogitoNodeInstance nodeInstance) {
                    Map<String, Object> metaData = nodeInstance.getMetaData();
                    if (metaData != null) {
                        metaData.put(ERROR_MESSAGE_KEY, errorMessage);
                        if (metaData.get(OUTPUT_ARGS_KEY) == null) {
                            Map<String, Object> errorOutput = new LinkedHashMap<>();
                            errorOutput.put("error", errorMessage);
                            metaData.put(OUTPUT_ARGS_KEY, errorOutput);
                        }
                    }
                }
            }
        } catch (Exception e) {
            LOG.warn("Failed to record error_message on error event: {}", e.getMessage());
        }
    }

    @Override
    public void afterProcessCompleted(ProcessCompletedEvent event) {
        try {
            if (event.getProcessInstance() != null && event.getProcessInstance().getId() != null) {
                String piId = event.getProcessInstance().getId();
                seqCounters.remove(piId);
                lastNodeMap.remove(piId);
            }
        } catch (Exception ignore) {
        }
    }

    private Object extractInputArgs(ProcessNodeTriggeredEvent event, KogitoNodeInstance nodeInstance) {
        if (nodeInstance instanceof KogitoWorkItemNodeInstance workItemNode) {
            if (workItemNode.getWorkItem() != null && workItemNode.getWorkItem().getParameters() != null) {
                Map<String, Object> params = workItemNode.getWorkItem().getParameters();
                if (!params.isEmpty()) {
                    return snapshotValue(params);
                }
            }
        }
        return extractProcessStateSnapshot(event.getProcessInstance());
    }

    private Object extractOutputArgs(ProcessNodeLeftEvent event, KogitoNodeInstance nodeInstance) {
        if (nodeInstance instanceof KogitoWorkItemNodeInstance workItemNode) {
            if (workItemNode.getWorkItem() != null && workItemNode.getWorkItem().getResults() != null) {
                Map<String, Object> results = workItemNode.getWorkItem().getResults();
                if (!results.isEmpty()) {
                    return snapshotValue(results);
                }
            }
        }
        return extractProcessStateSnapshot(event.getProcessInstance());
    }

    private Object extractProcessStateSnapshot(org.kie.api.runtime.process.ProcessInstance pi) {
        if (pi instanceof org.kie.kogito.internal.process.runtime.KogitoProcessInstance kpi) {
            Map<String, Object> variables = kpi.getVariables();
            if (variables != null && !variables.isEmpty()) {
                if (variables.containsKey(WORKFLOW_DATA_KEY)) {
                    Object wfData = variables.get(WORKFLOW_DATA_KEY);
                    if (wfData != null) {
                        return snapshotValue(wfData);
                    }
                }
                return snapshotValue(variables);
            }
        }
        return null;
    }

    private JsonNode snapshotValue(Object value) {
        if (value == null) {
            return null;
        }
        if (value instanceof JsonNode jsonNode) {
            return jsonNode.deepCopy();
        }
        ObjectMapper mapper = objectMapper != null ? objectMapper : fallbackMapper;
        try {
            return mapper.valueToTree(value);
        } catch (Exception e) {
            if (value instanceof Map<?, ?> map) {
                try {
                    return mapper.valueToTree(new LinkedHashMap<>(map));
                } catch (Exception ex) {
                    return mapper.valueToTree(map.toString());
                }
            }
            return mapper.valueToTree(String.valueOf(value));
        }
    }
}
