-- Draft: draft-remittance | 假設既有最大版本 V1.2.4 → 遞增為 V1.2.5 (見 spec.md H12)
-- 下游整併至 domain-reconciliation/reconciliation-api/src/main/resources/db/migration/
-- View IN 用 snake_case workflow id (remittance_transaction / remittance_domestic / remittance_swift / remittance_cancellation)

CREATE VIEW IF NOT EXISTS vw_remittance_reconciliation AS
SELECT
    id, created_at, workflow_id, business_key, process_instance_id, status, message,
    json_extract(input_data, '$.partyId') AS party_id,
    json_extract(input_data, '$.operationType') AS operation_type,
    json_extract(input_data, '$.amount') AS amount,
    json_extract(input_data, '$.currency') AS currency,
    json_extract(input_data, '$.sequenceNumber') AS sequence_number,
    json_extract(input_data, '$.originalSequenceNumber') AS original_sequence_number,
    cancelled_by, cancelled_at
FROM workflow_execution_log
WHERE workflow_id IN ('remittance_transaction', 'remittance_domestic', 'remittance_swift', 'remittance_cancellation');

CREATE INDEX IF NOT EXISTS idx_wel_remittance_seq ON workflow_execution_log(business_key);
CREATE INDEX IF NOT EXISTS idx_wel_remittance_cancelled ON workflow_execution_log(cancelled_by);
