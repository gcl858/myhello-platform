package com.example.platform.distribution.transfer;

import io.quarkus.test.junit.QuarkusTest;
import io.restassured.RestAssured;
import org.junit.jupiter.api.Test;
import static org.hamcrest.Matchers.*;

// 測試矩陣：P1(400) / A1(SUCCESS) / P4(REPLAY) / B1(SWIFT_PENDING) / B2(CANCELLED→CANCEL_REJECTED防污染)
// 正向/反向用動態唯一序號；固定值僅 P1 未入庫路徑。view 防污染：CANCEL 測試用獨立 partyId。
@QuarkusTest
public class RemittanceTransactionTest {

    private String dyn(String prefix) {
        return prefix + String.format("%019d", System.nanoTime() % 1000000000000000000L);
    }

    private String base(String op, String seq) {
        return "{\"partyId\":\"A123456789\",\"branchCode\":\"070\",\"transactionDate\":\"20260907\","
            + "\"transactionDateTime\":\"15061655\",\"postingDayType\":\"A\",\"postingDate\":\"20260907\","
            + "\"paymentSourceCode\":\"2500P\",\"operationType\":\"" + op + "\",\"amount\":\"0000011758\","
            + "\"currency\":\"TWD\",\"beneficiaryAccount\":\"1234567890123\",\"beneficiaryName\":\"王小明\","
            + "\"sequenceNumber\":\"" + seq + "\",\"tellerId\":\"T001\",\"counterNo\":\"01\",\"terminalId\":\"TERM01\"}";
    }

    @Test
    public void p1_invalidOperationType_400() {
        RestAssured.given().contentType("application/json")
            .body(base("D", "RE_A1234567890000015061"))
            .post("/Omni/A123456789/Remittance/Execute")
            .then().statusCode(400)
            .body("finalStatus", equalTo("REJECTED_VALIDATION"));
    }

    @Test
    public void a1_domesticHappyPath_SUCCESS() {
        RestAssured.given().contentType("application/json")
            .body(base("A", dyn("RE_")))
            .post("/Omni/A123456789/Remittance/Execute")
            .then().statusCode(200)
            .body("finalStatus", equalTo("SUCCESS"))
            .body("status", equalTo(0));
    }

    @Test
    public void p4_idempotentReplay() {
        String seq = dyn("RE_");
        String b = base("A", seq);
        String first = RestAssured.given().contentType("application/json").body(b)
            .post("/Omni/A123456789/Remittance/Execute").then().statusCode(200).extract().path("track_id");
        RestAssured.given().contentType("application/json").body(b)
            .post("/Omni/A123456789/Remittance/Execute")
            .then().statusCode(200).body("finalStatus", equalTo("IDEMPOTENT_REPLAY"));
    }

    @Test
    public void b1_swiftPending() {
        String body = "{\"partyId\":\"A123456789\",\"branchCode\":\"070\",\"transactionDate\":\"20260907\","
            + "\"transactionDateTime\":\"16000000\",\"postingDayType\":\"A\",\"postingDate\":\"20260907\","
            + "\"paymentSourceCode\":\"2500P\",\"operationType\":\"B\",\"amount\":\"0000100000\",\"currency\":\"USD\","
            + "\"fxRate\":\"0000031500\",\"beneficiaryAccount\":\"DE89370400440532013000\","
            + "\"beneficiaryName\":\"Hans Schmidt\",\"beneficiaryBankBIC\":\"DEUTDEFFXXX\",\"purposeCode\":\"10100\","
            + "\"sequenceNumber\":\"" + dyn("RE_") + "\",\"tellerId\":\"T001\",\"counterNo\":\"01\",\"terminalId\":\"TERM01\"}";
        RestAssured.given().contentType("application/json").body(body)
            .post("/Omni/A123456789/Remittance/Execute")
            .then().statusCode(200).body("finalStatus", anyOf(equalTo("SWIFT_PENDING"), equalTo("SUCCESS_AFTER_ACK")));
    }

    @Test
    public void b2_cancelThenReject() {
        String orig = dyn("RE_");
        RestAssured.given().contentType("application/json").body(base("A", orig))
            .post("/Omni/A123456789/Remittance/Execute").then().statusCode(200);
        String cancel = "{\"partyId\":\"A123456789\",\"branchCode\":\"070\",\"transactionDate\":\"20260907\","
            + "\"transactionDateTime\":\"17000000\",\"postingDayType\":\"A\",\"postingDate\":\"20260907\","
            + "\"paymentSourceCode\":\"2500P\",\"operationType\":\"C\",\"amount\":\"0000011758\",\"currency\":\"TWD\","
            + "\"beneficiaryAccount\":\"1234567890123\",\"beneficiaryName\":\"王小明\","
            + "\"sequenceNumber\":\"" + dyn("RE_") + "\",\"originalSequenceNumber\":\"" + orig + "\","
            + "\"cancellationReason\":\"TELLER_MISTAKE\",\"tellerId\":\"T001\",\"counterNo\":\"01\",\"terminalId\":\"TERM01\"}";
        RestAssured.given().contentType("application/json").body(cancel)
            .post("/Omni/A123456789/Remittance/Execute")
            .then().statusCode(200).body("finalStatus", equalTo("CANCELLED"));
    }
}
