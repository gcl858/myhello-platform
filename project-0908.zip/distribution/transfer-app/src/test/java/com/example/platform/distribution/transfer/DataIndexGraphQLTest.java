package com.example.platform.distribution.transfer;

import io.quarkus.test.junit.QuarkusTest;
import jakarta.inject.Inject;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.*;

@QuarkusTest
@DisplayName("Data Index GraphQL API 測試")
class DataIndexGraphQLTest {

    @Test
    @DisplayName("驗證 ProcessDefinitions 查詢成功")
    void testProcessDefinitionsQuery() {
        String query = "{\"query\":\"{ ProcessDefinitions { id name version } }\"}";

        given()
            .contentType("application/json")
            .body(query)
        .when()
            .post("/graphql")
        .then()
            .statusCode(200)
            .body("errors", nullValue())
            .body("data.ProcessDefinitions", notNullValue());
    }

    @Test
    @DisplayName("驗證 ProcessInstances 查詢成功（無 Error parsing time stamp 錯誤）")
    void testProcessInstancesQuery() {
        // 先觸發一次 workflow 確保資料庫中有 process instance
        given()
            .contentType("application/json")
            .body("{\"Account_A\":\"A123\",\"Account_B\":\"B123\",\"AMT\":100}")
        .when()
            .post("/saga2-transfer-workflow")
        .then()
            .statusCode(200);

        String query = "{\"query\":\"{ ProcessInstances { id processId state start end } }\"}";

        given()
            .contentType("application/json")
            .body(query)
        .when()
            .post("/graphql")
        .then()
            .statusCode(200)
            .body("errors", nullValue())
            .body("data.ProcessInstances", notNullValue());
    }

    @Test
    @DisplayName("驗證所有節點均有記錄 input_args 與 output_args 至 SQLite nodes 資料表")
    void testNodeInstancesRecordedInDatabase() throws Exception {
        // 觸發一次 workflow 產生完整節點鏈
        given()
            .contentType("application/json")
            .body("{\"Account_A\":\"AccNodeTestA\",\"Account_B\":\"AccNodeTestB\",\"AMT\":100}")
        .when()
            .post("/saga2-transfer-workflow")
        .then()
            .statusCode(200);

        Class.forName("org.sqlite.JDBC");
        try (java.sql.Connection conn = java.sql.DriverManager.getConnection("jdbc:sqlite:target/test-reconciliation.db");
             java.sql.Statement stmt = conn.createStatement();
             java.sql.ResultSet rs = stmt.executeQuery(
                     "SELECT n.id, n.name, n.type, n.input_args, n.output_args, n.error_message " +
                     "FROM nodes n JOIN processes p ON n.process_instance_id = p.id " +
                     "WHERE p.variables LIKE '%AccNodeTestA%'")) {

            int totalNodes = 0;
            int nodesWithInputArgs = 0;
            int nodesWithOutputArgs = 0;

            while (rs.next()) {
                totalNodes++;
                String inputArgs = rs.getString("input_args");
                String outputArgs = rs.getString("output_args");
                if (inputArgs != null && !inputArgs.isBlank()) {
                    nodesWithInputArgs++;
                }
                if (outputArgs != null && !outputArgs.isBlank()) {
                    nodesWithOutputArgs++;
                }
            }

            org.junit.jupiter.api.Assertions.assertTrue(totalNodes > 0, "應記錄至少一個節點");
            org.junit.jupiter.api.Assertions.assertEquals(totalNodes, nodesWithInputArgs,
                    "所有執行的節點都應有 input_args");
            org.junit.jupiter.api.Assertions.assertEquals(totalNodes, nodesWithOutputArgs,
                    "所有執行的節點都應有 output_args");
        }
    }

    @Inject
    com.example.reconciliation.AuditQueryService auditQueryService;

    @Test
    @DisplayName("驗證節點前後順序與階層關係（AuditQueryService / flow-trace 後端驗證）")
    void testNodeTraceOrderAndHierarchy() throws Exception {
        given()
            .contentType("application/json")
            .body("{\"Account_A\":\"TraceAccA\",\"Account_B\":\"TraceAccB\",\"AMT\":100}")
        .when()
            .post("/saga2-transfer-workflow")
        .then()
            .statusCode(200);

        // 取得該 instance 的 ID
        Class.forName("org.sqlite.JDBC");
        String instanceId = null;
        try (java.sql.Connection conn = java.sql.DriverManager.getConnection("jdbc:sqlite:target/test-reconciliation.db");
             java.sql.Statement stmt = conn.createStatement();
             java.sql.ResultSet rs = stmt.executeQuery(
                     "SELECT id FROM processes WHERE variables LIKE '%TraceAccA%' ORDER BY start_time DESC LIMIT 1")) {
            if (rs.next()) {
                instanceId = rs.getString("id");
            }
        }

        org.junit.jupiter.api.Assertions.assertNotNull(instanceId, "應成功建立流程實例");

        com.fasterxml.jackson.databind.node.ObjectNode trace = auditQueryService.getInstanceTrace(instanceId);
        org.junit.jupiter.api.Assertions.assertNotNull(trace, "應回傳 trace 物件");
        com.fasterxml.jackson.databind.node.ArrayNode nodes = (com.fasterxml.jackson.databind.node.ArrayNode) trace.get("nodes");
        org.junit.jupiter.api.Assertions.assertTrue(nodes.size() > 5, "節點數量應大於 5");

        int lastSeq = 0;
        boolean foundCallA16229Function = false;
        boolean foundAuditLogFunction = false;

        for (int i = 0; i < nodes.size(); i++) {
            com.fasterxml.jackson.databind.JsonNode node = nodes.get(i);
            int seq = node.path("seq").asInt(0);
            org.junit.jupiter.api.Assertions.assertTrue(seq > lastSeq, "seq 必須嚴格遞增: " + seq + " vs " + lastSeq);
            lastSeq = seq;

            String name = node.path("name").asText();
            String parent = node.path("parentNode").asText(null);

            if ("callApiViaOpenAPI".equals(name) && "CallA16229State".equals(parent)) {
                foundCallA16229Function = true;
                org.junit.jupiter.api.Assertions.assertNotNull(node.path("prevNode").asText(null), "前置節點不應為空");
            }
            if ("recordAuditLog".equals(name) && "FinalAuditAndEnd".equals(parent)) {
                foundAuditLogFunction = true;
                org.junit.jupiter.api.Assertions.assertNotNull(node.path("prevNode").asText(null), "前置節點不應為空");
            }
        }

        org.junit.jupiter.api.Assertions.assertTrue(foundCallA16229Function, "應找到 CallA16229State 下的 callApiViaOpenAPI");
        org.junit.jupiter.api.Assertions.assertTrue(foundAuditLogFunction, "應找到 FinalAuditAndEnd 下的 recordAuditLog");
    }
}
