package com.example.platform.distribution.transfer;

import io.quarkus.test.junit.QuarkusTest;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.notNullValue;
import static org.hamcrest.Matchers.nullValue;

/**
 * saga3-transfer-workflow (精簡企業級架構版) 整合測試
 * 驗證 6 大核心情境:
 *   - [1] AMT=100 → 200 SUCCESS (兩階段 API 均成功)
 *   - [2] AMT=600 → 200 ROLLED_BACK (AMT > 500 觸發 LIFO 兩階段回沖)
 *   - [3] AMT=30 → 200 FAILED (A16229 扣款失敗短路，未動帳無需補償)
 *   - [4] AMT=2000 → 200 ROLLED_BACK (A16220 入帳失敗，僅回沖 A16229)
 *   - [5] 輸入校驗 (缺失、非法字元、金額<=0、同帳號) → 400 VALIDATION_FAILED
 *   - [6] 哨兵回沖失敗 (Account_A=RBFAIL) → 409 ROLLBACK_FAILED + opsAlertRaised=true
 */
@QuarkusTest
@DisplayName("saga3-transfer-workflow 精簡企業版測試")
class Saga3TransferWorkflowTest {

    private static final String WORKFLOW_URL = "/saga3-transfer-workflow";

    private static final String PAYLOAD_TEMPLATE =
            "{\"Account_A\":\"A123\",\"Account_B\":\"B123\",\"AMT\":%d}";

    private static final String INVALID_PAYLOAD_TEMPLATE =
            "{\"Account_A\":\"%s\",\"Account_B\":\"%s\",\"AMT\":%s}";

    @Test
    @DisplayName("[1] AMT=100 → SUCCESS (兩階段 API 皆成功)")
    void testAmt100Success() {
        given()
            .contentType("application/json")
            .body(String.format(PAYLOAD_TEMPLATE, 100))
        .when()
            .post(WORKFLOW_URL)
        .then()
            .statusCode(200)
            .body("status", equalTo("SUCCESS"))
            .body("message", equalTo("交易成功"))
            .body("AMT", equalTo(100))
            .body("a16229Result.code", equalTo("100"))
            .body("a16229Result._httpStatus", equalTo(200))
            .body("a16220Result.code", equalTo("100"))
            .body("a16220Result._httpStatus", equalTo(200))
            .body("a16229Rollback", nullValue())
            .body("a16220Rollback", nullValue())
            .body("auditSaved", equalTo(true))
            .body("opsAlertRaised", equalTo(false));
    }

    @Test
    @DisplayName("[2] AMT=600 → ROLLED_BACK LIFO (兩階段皆成功但超額，觸發 LIFO 全回沖)")
    void testAmt600RolledBackLifo() {
        given()
            .contentType("application/json")
            .body(String.format(PAYLOAD_TEMPLATE, 600))
        .when()
            .post(WORKFLOW_URL)
        .then()
            .statusCode(200)
            .body("status", equalTo("ROLLED_BACK"))
            .body("message", equalTo("AMT > 500 觸發 saga 回沖 (LIFO)"))
            .body("AMT", equalTo(600))
            .body("a16229Result.code", equalTo("100"))
            .body("a16220Result.code", equalTo("100"))
            .body("a16220Rollback.code", equalTo("100"))
            .body("a16220Rollback.message", equalTo("成功(EC)"))
            .body("a16229Rollback.code", equalTo("100"))
            .body("a16229Rollback.message", equalTo("成功(EC)"))
            .body("auditSaved", equalTo(true))
            .body("opsAlertRaised", equalTo(false));
    }

    @Test
    @DisplayName("[3] AMT=30 → FAILED (A16229 業務失敗短路，未扣款無需回沖)")
    void testAmt30Failed() {
        given()
            .contentType("application/json")
            .body(String.format(PAYLOAD_TEMPLATE, 30))
        .when()
            .post(WORKFLOW_URL)
        .then()
            .statusCode(200)
            .body("status", equalTo("FAILED"))
            .body("message", equalTo("業務失敗或 API 錯誤"))
            .body("a16229Result.code", equalTo("999"))
            .body("a16229Result.message", equalTo("AMT必須大於50"))
            .body("a16220Result", nullValue())
            .body("a16229Rollback", nullValue())
            .body("a16220Rollback", nullValue())
            .body("auditSaved", equalTo(true))
            .body("opsAlertRaised", equalTo(false));
    }

    @Test
    @DisplayName("[4] AMT=2000 → ROLLED_BACK (A16220 業務失敗，僅回沖 A16229)")
    void testAmt2000RolledBackA16229Only() {
        given()
            .contentType("application/json")
            .body(String.format(PAYLOAD_TEMPLATE, 2000))
        .when()
            .post(WORKFLOW_URL)
        .then()
            .statusCode(200)
            .body("status", equalTo("ROLLED_BACK"))
            .body("message", equalTo("A16220 業務失敗,僅回沖 A16229"))
            .body("a16229Result.code", equalTo("100"))
            .body("a16220Result.code", equalTo("999"))
            .body("a16220Result.message", equalTo("AMT必須小於1000"))
            .body("a16220Rollback", nullValue())
            .body("a16229Rollback.code", equalTo("100"))
            .body("a16229Rollback.message", equalTo("成功(EC)"))
            .body("auditSaved", equalTo(true))
            .body("opsAlertRaised", equalTo(false));
    }

    @Test
    @DisplayName("[5] 缺失欄位 → 400 VALIDATION_FAILED (P2-1 正向防禦檢測)")
    void testValidationFailedMissingField() {
        given()
            .contentType("application/json")
            .body("{\"Account_A\":\"123456\"}")
        .when()
            .post(WORKFLOW_URL)
        .then()
            .statusCode(400)
            .body("status", equalTo("VALIDATION_FAILED"))
            .body("message", equalTo("輸入欄位格式錯誤 (帳號僅限英數字與底線且兩者不得相同;AMT 須為大於 0 的數字)"))
            .body("a16229Result", nullValue())
            .body("a16220Result", nullValue())
            .body("auditSaved", equalTo(true))
            .body("opsAlertRaised", equalTo(false));
    }

    @Test
    @DisplayName("[6] Account_B 含非法字元 → 400 VALIDATION_FAILED")
    void testValidationFailedBadChars() {
        given()
            .contentType("application/json")
            .body(String.format(INVALID_PAYLOAD_TEMPLATE, "123456", "A@0001", "100"))
        .when()
            .post(WORKFLOW_URL)
        .then()
            .statusCode(400)
            .body("status", equalTo("VALIDATION_FAILED"));
    }

    @Test
    @DisplayName("[7] AMT=0 (非正數) → 400 VALIDATION_FAILED")
    void testValidationFailedAmtZero() {
        given()
            .contentType("application/json")
            .body(String.format(INVALID_PAYLOAD_TEMPLATE, "123456", "A00001", "0"))
        .when()
            .post(WORKFLOW_URL)
        .then()
            .statusCode(400)
            .body("status", equalTo("VALIDATION_FAILED"))
            .body("AMT", equalTo(0));
    }

    @Test
    @DisplayName("[8] 同帳號轉帳 → 400 VALIDATION_FAILED")
    void testValidationFailedSameAccount() {
        given()
            .contentType("application/json")
            .body(String.format(INVALID_PAYLOAD_TEMPLATE, "123456", "123456", "100"))
        .when()
            .post(WORKFLOW_URL)
        .then()
            .statusCode(400)
            .body("status", equalTo("VALIDATION_FAILED"));
    }

    @Test
    @DisplayName("[9] 哨兵觸發回沖失敗 (Account_A=RBFAIL) → 409 ROLLBACK_FAILED, opsAlertRaised=true")
    void testRollbackFailedSentinel() {
        // Account_A="RBFAIL", AMT=600:
        // 扣款成功 (EC=false 不觸發哨兵) -> 入帳成功 -> AMT>500 觸發 LIFO 回沖 ->
        // RollbackA16220 成功 -> RollbackA16229 因 Account_A=RBFAIL 且 EC=true 觸發哨兵失敗 (403/401)
        given()
            .contentType("application/json")
            .body("{\"Account_A\":\"RBFAIL\",\"Account_B\":\"B123\",\"AMT\":600}")
        .when()
            .post(WORKFLOW_URL)
        .then()
            .statusCode(409)
            .body("status", equalTo("ROLLBACK_FAILED"))
            .body("message", equalTo("⚠️ 回沖失敗,需人工介入處理"))
            .body("a16229Rollback.code", equalTo("401"))
            .body("opsAlertRaised", equalTo(true))
            .body("auditSaved", equalTo(true));
    }
}
