package com.example.reconciliation;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

/**
 * Parent 級冪等服務 (H6 假設 FQCN 落地 — 簡化版)
 *
 * 對應 draft-omni-counter-repayment/spec/spec.md §0 H6 + §5.1:
 *   - workflow functionRef: checkIdempotency
 *   - 用途: 依 sequenceNumber (businessKey) 查 workflow_execution_log 是否已有最終狀態記錄
 *   - 命中且 finalStatus 非 PENDING → 視為 IDEMPOTENT_REPLAY
 *
 * v1.0 簡化實作:
 *   - 僅查 workflow_id = 'omni-cash-transaction' 的 row (Parent 級)
 *   - 查無 / 命中但 finalStatus 空 / 命中且 cancelled_by 有值 → 都視為可重做
 *   - 完整實作 (含分散式鎖、跨 workflow 查詢) 留待 v1.1
 *
 * 函數簽名設計:
 *   - 展開參數版: findBySequenceNumber(String workflowId, Object businessKey)
 *   - 對應 SonataFlow arguments 反射綁定 (與 AuditLogService 既有風格一致)
 */
@ApplicationScoped
public class IdempotencyService {

    private static final Logger LOG = LoggerFactory.getLogger(IdempotencyService.class);
    private static final ObjectMapper MAPPER = new ObjectMapper();

    @Inject
    DataSource dataSource;

    /**
     * 展開參數版進入點 (對應 SonataFlow arguments 反射綁定)
     *
     * @param workflowId  workflow id (e.g. "omni-cash-transaction")
     * @param businessKey sequenceNumber 字串
     * @return JsonNode {found, priorFinalStatus, priorResult}
     */
    public JsonNode findBySequenceNumber(String workflowId, Object businessKey) {
        String wId = workflowId != null ? workflowId : "omni-cash-transaction";
        String bKeyStr = businessKey != null ? businessKey.toString() : null;
        return doFindBySequenceNumber(wId, bKeyStr);
    }

    /**
     * 跨工作流命名相容多載 (remittance 傳 sequenceNumber、omni 傳 businessKey)
     */
    public JsonNode findBySequenceNumber(String workflowId, String sequenceNumber) {
        String wId = workflowId != null ? workflowId : "omni-cash-transaction";
        return doFindBySequenceNumber(wId, sequenceNumber);
    }

    /**
     * 單一 JsonNode 參數進入點
     */
    public JsonNode findBySequenceNumber(JsonNode arguments) {
        if (arguments == null) {
            return MAPPER.createObjectNode().put("found", false).put("idempotentReplay", false);
        }
        String workflowId = arguments.has("workflowId")
                ? arguments.get("workflowId").asText()
                : "omni-cash-transaction";
        String businessKey = arguments.has("businessKey")
                ? arguments.get("businessKey").asText()
                : (arguments.has("sequenceNumber") ? arguments.get("sequenceNumber").asText() : null);
        return doFindBySequenceNumber(workflowId, businessKey);
    }

    /**
     * 實際查詢邏輯
     */
    private JsonNode doFindBySequenceNumber(String workflowId, String businessKey) {
        ObjectNode response = MAPPER.createObjectNode();
        response.put("found", false);
        response.put("idempotentReplay", false);

        if (businessKey == null || businessKey.isBlank()) {
            return response;
        }

        // 簡化: 僅查 Parent 級 row,看 status 是否已是收斂終態
        String sql = "SELECT id, status, message, output_data, cancelled_by " +
                "FROM workflow_execution_log " +
                "WHERE workflow_id = ? AND business_key = ? " +
                "ORDER BY id DESC LIMIT 1";

        try (Connection conn = dataSource.getConnection();
                PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, workflowId);
            pstmt.setString(2, businessKey);

            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    String status = rs.getString("status");
                    String message = rs.getString("message");
                    String outputData = rs.getString("output_data");
                    String cancelledBy = rs.getString("cancelled_by");

                    response.put("found", true);
                    response.put("idempotentReplay", true);
                    response.put("priorFinalStatus", status != null ? status : "UNKNOWN");
                    response.put("priorMessage", message != null ? message : "");
                    response.put("priorResult", outputData != null ? outputData : "{}");
                    if (cancelledBy != null && !cancelledBy.isBlank()) {
                        response.put("cancelledBy", cancelledBy);
                    }

                    LOG.info("[IdempotencyService] 命中冪等記錄: workflowId={}, businessKey={}, status={}",
                            workflowId, businessKey, status);
                }
            }
        } catch (Exception e) {
            LOG.error("[IdempotencyService] 冪等查詢失敗 (視為未命中,讓 dispatcher 繼續): {}",
                    e.getMessage(), e);
        }

        return response;
    }
}
