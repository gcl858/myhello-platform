package com.example.reconciliation;

import com.example.platform.common.PlatformPaths;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import io.quarkus.runtime.StartupEvent;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.enterprise.event.Observes;
import jakarta.inject.Inject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.sql.DataSource;
import java.nio.file.Path;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;

import com.example.reconciliation.migration.DatabaseMigrationRunner;

/**
 * 通用型 Workflow 執行紀錄與對帳服務 (Audit & Reconciliation Service)
 *
 * 高併發優化與模組化 Migration 版本:
 * 1. 啟用 SQLite WAL (Write-Ahead Logging) 模式與 busy_timeout=5000
 * 2. 注入 Quarkus Agroal DataSource 連線池管理連線
 * 3. 透過 DatabaseMigrationRunner 自動執行各模組之 SQL 遷移腳本 (解耦表結構與業務專屬 View)
 * 4. 使用 AtomicBoolean 確保資料庫結構與 PRAGMA 配置僅初始化一次
 */
@ApplicationScoped
public class AuditLogService {

    private static final Logger LOG = LoggerFactory.getLogger(AuditLogService.class);
    private static final ObjectMapper MAPPER = new ObjectMapper();
    /**
     * SQLite 連線 URL — 透過 {@link PlatformPaths} 跨平台解析,
     * Linux 與 Windows 都會使用對應平台的路徑分隔符。
     */
    private static final String DB_FILE_NAME = "reconciliation.db";
    private final AtomicBoolean initialized = new AtomicBoolean(false);

    /** 跨平台 SQLite JDBC URL — 啟動時由 {@link #initDatabase()} 解析。 */
    private static final String DB_URL = PlatformPaths.sqliteUrl(DB_FILE_NAME);

    @Inject
    DataSource dataSource;

    /**
     * 應用程式啟動時，確保 data 目錄與 SQLite 表格/視圖已初始化
     */
    void onStart(@Observes StartupEvent ev) {
        initDatabase();
    }

    private Connection getConnection() throws Exception {
        if (dataSource != null) {
            return dataSource.getConnection();
        }
        // 備用路徑:DataSource 未注入(例如非 Quarkus 環境或單元測試)。
        // DB_URL 為 static final,於 class 載入時由 PlatformPaths.sqliteUrl() 解析,
        // 只看 MYHELLO_DATA_DIR 環境變數 / 系統參數,不會跟 quarkus.datasource.jdbc.url 同步。
        // 若兩者設定不一致,備用路徑會寫到不同檔案,請改用 application.properties 配置。
        LOG.warn("[AuditLogService] DataSource 未注入,fallback 到 DriverManager(JDBC URL={})."
                + "若與 quarkus.datasource.jdbc.url 不一致,請改用 application.properties 配置避免資料分裂。",
                DB_URL);
        Class.forName("org.sqlite.JDBC");
        return DriverManager.getConnection(DB_URL);
    }

    /**
     * 初始化 SQLite 資料庫結構 (透過 DatabaseMigrationRunner 執行各模組遷移腳本)，全效能 WAL 模式設定
     */
    public void initDatabase() {
        if (initialized.get()) {
            return;
        }
        synchronized (this) {
            if (initialized.get()) {
                return;
            }
            try {
                // 確保 data 目錄存在 — 跨平台 (Windows/Linux) 共用 PlatformPaths
                Path dataDir = PlatformPaths.ensureDataDirectory();
                LOG.info("[AuditLogService] 使用 data 目錄: {}", dataDir.toAbsolutePath());

                try (Connection conn = getConnection();
                        Statement stmt = conn.createStatement()) {

                    // 0. 啟用高併發 WAL 模式與繁忙超時設定
                    stmt.execute("PRAGMA journal_mode=WAL;");
                    stmt.execute("PRAGMA synchronous=NORMAL;");
                    stmt.execute("PRAGMA busy_timeout=5000;");

                    // 1. 執行模組化資料庫遷移腳本 (包含 V1.0.0 基礎稽核表、V1.1.0 業務專屬 View 等)
                    DatabaseMigrationRunner.runMigrations(conn);

                    initialized.set(true);
                    LOG.info(
                            "[AuditLogService] SQLite 資料庫 (WAL 模式) 結構與模組化遷移已就緒。");
                }
            } catch (Exception e) {
                LOG.error("[AuditLogService] 初始化 SQLite 資料庫失敗: {}", e.getMessage(), e);
            }
        }
    }

    /**
     * 多參數進入點 (對應 SonataFlow 反射將 arguments key 展開為獨立參數)
     */
    // Backwards-compatible 4-arg overload retained for any generated handlers
    public JsonNode saveLog(String workflowId, Object businessKey, Object inputData, Object outputData) {
        return saveLog(workflowId, businessKey, null, inputData, outputData);
    }

    public JsonNode saveLog(String workflowId, Object businessKey, Object processInstanceId, Object inputData,
            Object outputData) {
        String bKeyStr = businessKey != null ? businessKey.toString() : null;
        String pInstStr = processInstanceId != null ? processInstanceId.toString() : null;
        JsonNode inputNode = MAPPER.valueToTree(inputData);
        JsonNode outputNode = MAPPER.valueToTree(outputData);
        return doSaveLog(workflowId, bKeyStr, pInstStr, inputNode, outputNode);
    }

    /**
     * 支援 (workflowId, sequenceNumber, finalStatus) 3 參數呼叫 (向下相容)
     */
    public JsonNode saveLog(String workflowId, Object sequenceNumber, Object finalStatus) {
        String bKeyStr = sequenceNumber != null ? sequenceNumber.toString() : null;
        ObjectNode outputNode = MAPPER.createObjectNode();
        if (finalStatus != null) {
            outputNode.put("status", finalStatus.toString());
            outputNode.put("finalStatus", finalStatus.toString());
        }
        return doSaveLog(workflowId, bKeyStr, null, null, outputNode);
    }

    /**
     * 單一 JsonNode 參數進入點
     */
    public JsonNode saveLog(JsonNode arguments) {
        if (arguments == null) {
            return MAPPER.createObjectNode().put("saved", false);
        }
        String workflowId = arguments.has("workflowId") ? arguments.get("workflowId").asText() : "unknown-workflow";
        String businessKey = arguments.has("businessKey") ? arguments.get("businessKey").asText() : null;
        String processInstanceId = arguments.has("processInstanceId") ? arguments.get("processInstanceId").asText()
                : null;
        JsonNode inputDataNode = arguments.get("inputData");
        JsonNode outputDataNode = arguments.get("outputData");
        return doSaveLog(workflowId, businessKey, processInstanceId, inputDataNode, outputDataNode);
    }

    /**
     * 單一 Map 參數進入點
     */
    public JsonNode saveLog(Map<String, Object> arguments) {
        if (arguments == null) {
            return MAPPER.createObjectNode().put("saved", false);
        }
        JsonNode node = MAPPER.valueToTree(arguments);
        return saveLog(node);
    }

    /**
     * 實際執行 DB 寫入邏輯
     */
    private JsonNode doSaveLog(String workflowId, String businessKey, String processInstanceId, JsonNode inputDataNode,
            JsonNode outputDataNode) {
        try {
            String inputDataJson = inputDataNode != null ? inputDataNode.toString() : "{}";
            String outputDataJson = outputDataNode != null ? outputDataNode.toString() : "{}";

            String status = "UNKNOWN";
            String message = "";
            if (outputDataNode != null) {
                if (outputDataNode.has("status") && !outputDataNode.get("status").isNull() && !outputDataNode.get("status").asText().isBlank()) {
                    status = outputDataNode.get("status").asText();
                } else if (outputDataNode.has("finalStatus") && !outputDataNode.get("finalStatus").isNull() && !outputDataNode.get("finalStatus").asText().isBlank()) {
                    status = outputDataNode.get("finalStatus").asText();
                }
                if (outputDataNode.has("message") && !outputDataNode.get("message").isNull()) {
                    message = outputDataNode.get("message").asText();
                } else if (outputDataNode.has("finalMessage") && !outputDataNode.get("finalMessage").isNull()) {
                    message = outputDataNode.get("finalMessage").asText();
                }
            }

            if (!initialized.get()) {
                initDatabase();
            }

            String insertSql = "INSERT INTO workflow_execution_log " +
                    "(workflow_id, business_key, process_instance_id, status, message, input_data, output_data) " +
                    "VALUES (?, ?, ?, ?, ?, ?, ?);";

            try (Connection conn = getConnection();
                    PreparedStatement pstmt = conn.prepareStatement(insertSql)) {
                pstmt.setString(1, workflowId);
                pstmt.setString(2, businessKey);
                pstmt.setString(3, processInstanceId);
                pstmt.setString(4, status);
                pstmt.setString(5, message);
                pstmt.setString(6, inputDataJson);
                pstmt.setString(7, outputDataJson);

                int rows = pstmt.executeUpdate();
                LOG.info("[AuditLogService] 成功寫入對帳紀錄! Workflow: {}, BusinessKey: {}, Status: {}, Rows: {}",
                        workflowId, businessKey, status, rows);
            }

            ObjectNode response = MAPPER.createObjectNode();
            response.put("saved", true);
            response.put("workflowId", workflowId);
            response.put("status", status);
            return response;

        } catch (Exception e) {
            LOG.error("[AuditLogService] 寫入對帳紀錄失敗: {}", e.getMessage(), e);
            ObjectNode response = MAPPER.createObjectNode();
            response.put("saved", false);
            response.put("error", e.getMessage());
            return response;
        }
    }

    // ═══════════════════════════════════════════════════════════════════════
    // [v1.0] 為 omni-cash-transaction / repayment-cash-cancellation 提供之擴充介面
    // 對應 draft-omni-counter-repayment/spec/spec.md H6 細節 + H14 細節
    //   - findBySequenceNumber: WF-B Lookup 階段用,查原 REPAYMENT 是否存在 + 已被取消
    //   - markCancelledBy: WF-B 收尾用,將原 REPAYMENT row 標記為已取消
    // ═══════════════════════════════════════════════════════════════════════

    /**
     * 依 workflowId + businessKey (sequenceNumber) 查詢最新一筆 audit log。
     * 對應 WF-B Lookup 階段 (repayment-cash-cancellation.sw.yaml LookupOriginalTransaction)。
     *
     * @param workflowId  workflow id (e.g. "repayment-cash-deposit" 查原 REPAYMENT)
     * @param businessKey sequenceNumber 字串
     * @return JsonNode {found, originalFinalStatus, cancelledBy, cancelledAt, partyId, amount, originalSequenceNumber}
     */
    public JsonNode findBySequenceNumber(String workflowId, Object businessKey) {
        String wId = workflowId != null ? workflowId : "repayment-cash-deposit";
        String bKeyStr = businessKey != null ? businessKey.toString() : null;
        return doFindBySequenceNumber(wId, bKeyStr);
    }

    /**
     * 跨工作流命名相容多載 (remittance 傳 sequenceNumber、omni 傳 businessKey)
     */
    public JsonNode findBySequenceNumber(String workflowId, String sequenceNumber) {
        return findBySequenceNumber(workflowId, (Object) sequenceNumber);
    }

    /**
     * 單一 JsonNode 參數進入點
     */
    public JsonNode findBySequenceNumber(JsonNode arguments) {
        if (arguments == null) {
            return MAPPER.createObjectNode().put("found", false);
        }
        String workflowId = arguments.has("workflowId")
                ? arguments.get("workflowId").asText()
                : "repayment-cash-deposit";
        String businessKey = arguments.has("businessKey")
                ? arguments.get("businessKey").asText()
                : (arguments.has("sequenceNumber") ? arguments.get("sequenceNumber").asText() : null);
        return doFindBySequenceNumber(workflowId, businessKey);
    }

    private JsonNode doFindBySequenceNumber(String workflowId, String businessKey) {
        ObjectNode response = MAPPER.createObjectNode();
        response.put("found", false);

        if (businessKey == null || businessKey.isBlank()) {
            return response;
        }

        String sql = "SELECT id, status, message, input_data, cancelled_by, cancelled_at " +
                "FROM workflow_execution_log " +
                "WHERE workflow_id = ? AND business_key = ? " +
                "ORDER BY id DESC LIMIT 1";

        try (Connection conn = getConnection();
                PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, workflowId);
            pstmt.setString(2, businessKey);

            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    String status = rs.getString("status");
                    String message = rs.getString("message");
                    String inputData = rs.getString("input_data");
                    String cancelledBy = rs.getString("cancelled_by");
                    String cancelledAt = rs.getString("cancelled_at");

                    response.put("found", true);
                    response.put("status", status != null ? status : "UNKNOWN");
                    response.put("originalFinalStatus", status != null ? status : "UNKNOWN");
                    response.put("originalMessage", message != null ? message : "");
                    if (inputData != null && !inputData.isBlank()) {
                        try {
                            JsonNode inputNode = MAPPER.readTree(inputData);
                            if (inputNode.has("partyId")) {
                                response.put("partyId", inputNode.get("partyId").asText());
                            }
                            if (inputNode.has("amount")) {
                                response.put("amount", inputNode.get("amount").asText());
                            }
                            if (inputNode.has("sequenceNumber")) {
                                response.put("originalSequenceNumber", inputNode.get("sequenceNumber").asText());
                            }
                        } catch (Exception parseEx) {
                            LOG.warn("[AuditLogService] parse input_data 失敗: {}", parseEx.getMessage());
                        }
                    }
                    if (cancelledBy != null && !cancelledBy.isBlank()) {
                        response.put("cancelledBy", cancelledBy);
                    }
                    if (cancelledAt != null && !cancelledAt.isBlank()) {
                        response.put("cancelledAt", cancelledAt);
                    }

                    LOG.info("[AuditLogService] findBySequenceNumber 命中: workflowId={}, businessKey={}, status={}",
                            workflowId, businessKey, status);
                }
            }
        } catch (Exception e) {
            LOG.error("[AuditLogService] findBySequenceNumber 查詢失敗: {}", e.getMessage(), e);
        }
        return response;
    }

    /**
     * 支援 workflowId 參數化的 markCancelledBy
     */
    public JsonNode markCancelledBy(String workflowId, Object originalSequenceNumber, Object cancelledBy, Object cancelledAt) {
        return doMarkCancelledBy(
                workflowId,
                originalSequenceNumber != null ? originalSequenceNumber.toString() : null,
                cancelledBy != null ? cancelledBy.toString() : null,
                cancelledAt != null ? cancelledAt.toString() : null);
    }

    public JsonNode markCancelledBy(String workflowId, Object sequenceNumber, Object cancelledBy) {
        return doMarkCancelledBy(
                workflowId,
                sequenceNumber != null ? sequenceNumber.toString() : null,
                cancelledBy != null ? cancelledBy.toString() : null,
                null);
    }

    /**
     * 向下相容簽名 (未傳 workflowId)
     */
    public JsonNode markCancelledBy(Object originalSequenceNumber, Object cancelledBy, Object cancelledAt) {
        return doMarkCancelledBy(
                null,
                originalSequenceNumber != null ? originalSequenceNumber.toString() : null,
                cancelledBy != null ? cancelledBy.toString() : null,
                cancelledAt != null ? cancelledAt.toString() : null);
    }

    /**
     * 單一 JsonNode 參數進入點
     */
    public JsonNode markCancelledBy(JsonNode arguments) {
        if (arguments == null) {
            return MAPPER.createObjectNode().put("marked", false);
        }
        String workflowId = arguments.has("workflowId") ? arguments.get("workflowId").asText() : null;
        String origSeq = arguments.has("originalSequenceNumber")
                ? arguments.get("originalSequenceNumber").asText()
                : (arguments.has("sequenceNumber") ? arguments.get("sequenceNumber").asText() : null);
        String cancelledBy = arguments.has("cancelledBy")
                ? arguments.get("cancelledBy").asText() : null;
        String cancelledAt = arguments.has("cancelledAt")
                ? arguments.get("cancelledAt").asText() : null;
        return doMarkCancelledBy(workflowId, origSeq, cancelledBy, cancelledAt);
    }

    private JsonNode doMarkCancelledBy(String workflowId, String originalSequenceNumber, String cancelledBy, String cancelledAt) {
        ObjectNode response = MAPPER.createObjectNode();
        response.put("marked", false);
        response.put("originalSequenceNumber", originalSequenceNumber);

        if (originalSequenceNumber == null || originalSequenceNumber.isBlank()) {
            response.put("error", "originalSequenceNumber is required");
            return response;
        }

        String targetWId = (workflowId != null && !workflowId.isBlank()) ? workflowId : "repayment-cash-deposit";
        String updateSql = "UPDATE workflow_execution_log " +
                "SET cancelled_by = ?, cancelled_at = ? " +
                "WHERE workflow_id = ? " +
                "AND business_key = ? " +
                "AND (cancelled_by IS NULL OR cancelled_by = '')";

        try (Connection conn = getConnection();
                PreparedStatement pstmt = conn.prepareStatement(updateSql)) {
            pstmt.setString(1, cancelledBy != null ? cancelledBy : "unknown");
            pstmt.setString(2, cancelledAt != null ? cancelledAt
                    : new java.sql.Timestamp(System.currentTimeMillis()).toString());
            pstmt.setString(3, targetWId);
            pstmt.setString(4, originalSequenceNumber);

            int rows = pstmt.executeUpdate();
            response.put("marked", rows > 0);
            response.put("rowsUpdated", rows);

            LOG.info("[AuditLogService] markCancelledBy: workflowId={}, originalSequenceNumber={}, rowsUpdated={}, cancelledBy={}",
                    targetWId, originalSequenceNumber, rows, cancelledBy);
        } catch (Exception e) {
            LOG.error("[AuditLogService] markCancelledBy 失敗: {}", e.getMessage(), e);
            response.put("error", e.getMessage());
        }
        return response;
    }
}
