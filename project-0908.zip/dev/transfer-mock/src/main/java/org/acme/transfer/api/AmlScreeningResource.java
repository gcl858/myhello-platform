package org.acme.transfer.api;

import jakarta.ws.rs.*;
import jakarta.ws.rs.core.*;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import java.util.UUID;

// Mock: AML 主機。partyName/beneficiaryName 含 "HIT" → 命中 (status 1, HTTP 200)。
@Path("/AML")
public class AmlScreeningResource {
    private static final ObjectMapper M = new ObjectMapper();

    @POST
    @Path("/Party/Screen/Execute")
    public Response party(JsonNode body) {
        String name = body.path("partyName").asText("");
        String seq = body.path("sequenceNumber").asText("");
        if (name.contains("HIT") || seq.startsWith("FAIL_")) {
            return Response.status(200).entity(hit("AML001", "命中制裁名單 (OFAC SDN)", seq)).build();
        }
        return Response.status(200).entity(ok(seq)).build();
    }

    @POST
    @Path("/Beneficiary/Screen/Execute")
    public Response bene(JsonNode body) {
        String name = body.path("beneficiaryName").asText("");
        String seq = body.path("sequenceNumber").asText("");
        if (name.contains("HIT")) return Response.status(200).entity(hit("AML005", "受款人命中制裁國家 (IRN)", seq)).build();
        return Response.status(200).entity(ok(seq)).build();
    }

    @POST
    @Path("/Transaction/Check/Execute")
    public Response txn(JsonNode body) {
        return Response.status(200).entity(ok(body.path("sequenceNumber").asText(""))).build();
    }

    private ObjectNode ok(String seq) {
        ObjectNode r = M.createObjectNode();
        r.put("track_id", UUID.randomUUID().toString().replace("-", ""));
        r.put("code", "0");
        r.put("sequenceNumber", seq);
        return r;
    }
    private ObjectNode hit(String c, String m, String seq) {
        ObjectNode r = M.createObjectNode();
        r.put("track_id", UUID.randomUUID().toString().replace("-", ""));
        r.put("code", "1");
        r.putArray("errors").addObject().put("error_code", c).put("message", m);
        r.put("sequenceNumber", seq);
        return r;
    }
}
