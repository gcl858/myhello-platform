package org.acme.transfer.api;

import jakarta.ws.rs.*;
import jakarta.ws.rs.core.*;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import java.util.UUID;

// Mock: SWIFT + FX (合併一檔以控制檔案數；下游可拆分)。
// SWIFT receiverBIC 以 FAIL_ 開頭 → SW001；FX purposeCode=99999 → 申報失敗 (FX_REPORT_FAILED)。
@Path("/SWIFT")
public class SwiftOutboundResource {
    private static final ObjectMapper M = new ObjectMapper();

    @POST
    @Path("/MT103/Send/Execute")
    public Response send(JsonNode body) {
        String bic = body.path("receiverBIC").asText("");
        String seq = body.path("sequenceNumber").asText("");
        ObjectNode r = M.createObjectNode();
        r.put("track_id", UUID.randomUUID().toString().replace("-", ""));
        if (bic.startsWith("FAIL_")) {
            r.put("code", "1");
            r.putArray("errors").addObject().put("error_code", "SW001").put("message", "受款行 BIC 格式錯誤");
            r.putNull("result");
            return Response.status(200).entity(r).build();
        }
        r.put("code", "0");
        r.put("sequenceNumber", seq);
        r.put("swiftRefNo", "SWIFT20260907BANKUS33XXX000001");
        return Response.status(200).entity(r).build();
    }

    @POST
    @Path("/MT103/Cancel/Execute")
    public Response cancel(JsonNode body) {
        ObjectNode r = M.createObjectNode();
        r.put("track_id", UUID.randomUUID().toString().replace("-", ""));
        r.put("code", "0");
        r.put("sequenceNumber", body.path("sequenceNumber").asText(""));
        return Response.status(200).entity(r).build();
    }

    @POST
    @Path("/MT199/Query/Execute")
    public Response query(JsonNode body) {
        ObjectNode r = M.createObjectNode();
        r.put("track_id", UUID.randomUUID().toString().replace("-", ""));
        r.put("code", "0");
        r.put("currentStatus", "BENEFICIARY_CREDITED");
        return Response.status(200).entity(r).build();
    }
}
