package org.acme.transfer.api;

import jakarta.ws.rs.*;
import jakarta.ws.rs.core.*;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import java.util.UUID;

// Mock: FX Report。purposeCode=99999 → 申報失敗 (FX_REPORT_FAILED，仍視 SWIFT 成功)。
@Path("/FXReport/Transaction/Report/Execute")
public class FxReportResource {
    private static final ObjectMapper M = new ObjectMapper();
    @POST
    public Response report(JsonNode body) {
        ObjectNode r = M.createObjectNode();
        r.put("track_id", UUID.randomUUID().toString().replace("-", ""));
        if ("99999".equals(body.path("purposeCode").asText(""))) {
            r.put("code", "1");
            r.putArray("errors").addObject().put("error_code", "FX001").put("message", "申報資料缺失");
            r.putNull("result");
            return Response.status(200).entity(r).build();
        }
        r.put("code", "0");
        r.put("sequenceNumber", body.path("sequenceNumber").asText(""));
        return Response.status(200).entity(r).build();
    }
}
