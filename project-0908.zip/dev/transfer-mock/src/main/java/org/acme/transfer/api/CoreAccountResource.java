package org.acme.transfer.api;

import jakarta.ws.rs.*;
import jakarta.ws.rs.core.*;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import java.util.UUID;

// Mock: CoreAccount 主機 (dev profile)。@Path 須與 spec paths 一致。
// Sentinel 模式 A：amount 以 FAIL_ 開頭 → 業務拒絕 (E0011)；sequenceNumber 以 RBFAIL 開頭 → 退款失敗路徑。
// validator 側需 FAIL_ 豁免 (見 spec.md H13a)，switch 用 startswith 守衛。
@Path("/CoreAccount/{partyId}")
public class CoreAccountResource {
    private static final ObjectMapper M = new ObjectMapper();

    @POST
    @Path("/Debit/Execute")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response execute(@PathParam("partyId") String partyId, JsonNode body) {
        String amount = body.path("amount").asText("");
        String seq = body.path("sequenceNumber").asText("");
        if (amount.startsWith("FAIL_") || amount.equals("0") || amount.equals("0000000000")) {
            return Response.status(200).entity(err("E0011", "帳戶餘額不足", seq)).build();
        }
        if (seq.startsWith("RBFAIL") || seq.startsWith("CR_R_RBFAIL")) {
            return Response.status(200).entity(err("E0033", "原交易非 SUCCESS 狀態,不可退款", seq)).build();
        }
        ObjectNode r = M.createObjectNode();
        r.put("track_id", UUID.randomUUID().toString().replace("-", ""));
        r.put("code", "0");
        r.put("status", 0);
        ObjectNode result = r.putObject("result");
        result.put("sequenceNumber", seq);
        r.put("coreSequence", seq);
        return Response.status(200).entity(r).build();
    }

    @POST
    @Path("/Refund/Execute")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response refund(@PathParam("partyId") String partyId, JsonNode body) {
        String seq = body.path("sequenceNumber").asText("");
        if (seq.startsWith("RBFAIL") || seq.startsWith("CR_R_RBFAIL")) {
            return Response.status(200).entity(err("E0033", "原交易非 SUCCESS 狀態,不可退款", seq)).build();
        }
        ObjectNode r = M.createObjectNode();
        r.put("track_id", UUID.randomUUID().toString().replace("-", ""));
        r.put("code", "0");
        r.put("status", 0);
        ObjectNode result = r.putObject("result");
        result.put("sequenceNumber", seq);
        r.put("coreSequence", seq);
        return Response.status(200).entity(r).build();
    }

    private ObjectNode err(String code, String msg, String seq) {
        ObjectNode r = M.createObjectNode();
        r.put("track_id", UUID.randomUUID().toString().replace("-", ""));
        r.put("code", "1");
        r.put("status", 1);
        r.putArray("errors").addObject().put("error_code", code).put("message", msg);
        r.putNull("result");
        return r;
    }
}
