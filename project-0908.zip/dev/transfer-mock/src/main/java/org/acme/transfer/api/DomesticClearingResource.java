package org.acme.transfer.api;

import jakarta.ws.rs.*;
import jakarta.ws.rs.core.*;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import java.util.UUID;

// Mock: Domestic Clearing。beneficiaryAccount 以 FAIL_ 開頭 → DC002 (ROLLED_BACK 路徑)。
@Path("/DomesticClearing/{partyId}/Outbound/Execute")
public class DomesticClearingResource {
    private static final ObjectMapper M = new ObjectMapper();
    @POST
    public Response execute(@PathParam("partyId") String partyId, JsonNode body) {
        String acct = body.path("beneficiaryAccount").asText("");
        String seq = body.path("sequenceNumber").asText("");
        ObjectNode r = M.createObjectNode();
        r.put("track_id", UUID.randomUUID().toString().replace("-", ""));
        if (acct.startsWith("FAIL_")) {
            r.put("code", "1");
            r.putArray("errors").addObject().put("error_code", "DC002").put("message", "受款帳號不存在");
            r.putNull("result");
            return Response.status(200).entity(r).build();
        }
        r.put("code", "0");
        r.put("sequenceNumber", seq);
        r.put("clearingRefNo", "FI-20260907-070-012-000001");
        return Response.status(200).entity(r).build();
    }
}
