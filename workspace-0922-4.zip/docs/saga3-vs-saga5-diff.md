# Saga3 vs Saga5 Transfer Workflow 差異分析

> 對標檔案:
> - `project/domain-transfer/transfer-workflow/src/main/resources/saga3-transfer-workflow.sw.yaml`(v1.0.0,338 行,15 個 State)
> - `project/domain-transfer/transfer-workflow/src/main/resources/saga5-transfer-workflow.sw.yaml`(v1.0.0,475 行,16 個 State)

---

## 一、TL;DR

Saga5 = **Saga3 的精簡決策結構 + Saga4 的標準補償架構**。換句話說,Saga5 是在 Saga4(標準 `compensatedBy` + `FailureSignal` 閘門 + 雙終點)的基礎上,把 Saga3 的「`CheckA16220Result` + `DecideByEvaluation` 合併為 `CheckA16220AndEvaluate`」決策精簡風格引入,作為「**精簡決策版標準補償**」的最終形態。

| 面向 | Saga3 v1.0.0 | Saga5 v1.0.0 |
|---|---|---|
| **定位** | Saga2 v2.2.0 的**純結構精簡版** | Saga4 的**精簡決策版**(Saga4 + Saga3 風格) |
| **State 總數** | 15 | 16(+1,因新增 `FinalAuditFallbackAndEnd` 兜底終點) |
| **核心業務/決策 state 數** | 8 | **8**(完全相同) |
| **補償模型** | 手動 Rollback state 串接(共用 `RollbackA16229`) | **SW 標準 `compensatedBy`**(`CompensateA16220` + `CompensateA16229`) |
| **業務失敗判定** | switch `defaultCondition` 走 `RollbackA16229` | **`FailureSignal` 閘門拋 `BusinessStepFailedException`** |
| **決策合併** | ✅ `CheckA16220AndEvaluate`(三出口) | ✅ **繼承 Saga3 風格,同為 `CheckA16220AndEvaluate`** |
| **輸入驗證** | ✅ Saga3 P2-1 正向防禦(1 條 `and` 條件) | ✅ **繼承 Saga3 風格,完全相同** |
| **錯誤定義** | 1 個:`platformError` | **2 個**:`platformError` + `businessStepFailed` |
| **Functions** | 3 個 | **4 個**(新增 `failureSignal`) |
| **終點** | 1 個:`FinalAuditAndEnd` | **2 個**:`FinalAuditAndEnd` + `FinalAuditFallbackAndEnd` 兜底 |
| **輸出契約** | 9 欄位 | **完全相同** |

> **Saga5 的設計哲學**:既然 Saga3 是「精簡決策版」,Saga5 就是「精簡決策版 + 標準補償架構」—— 把兩個維度的最佳實踐合體,達成「**state 數更少 + 規範合規 + 雙終點兜底**」三者兼得。

---

## 二、五個 Saga 的演進全景

```
Saga1 ─→ Saga2 ─┬─→ Saga3 ─┬─→ (路徑 1:繼續精簡) ─→ ?
                │          │
                │          └─→ (路徑 2:加標準補償) ─→ Saga5 ← 你在這裡
                │
                └─→ Saga4 ─┬─→ (路徑 1:沿用) ─→ ?
                           │
                           └─→ (路徑 2:合併決策) ─→ Saga5 ← 你在這裡
```

| Saga | State 數 | 補償模型 | 決策合併 | 業務失敗判定 | 終點 | 設計動機 |
|---|---:|---|---|---|---|---|
| Saga1 | — | — | — | — | — | 初始 |
| Saga2 v2.2.0 | 18 | 手動 Rollback 鏈 | ❌ | switch default | 單終點 | 可靠性強化 |
| **Saga3 v1.0.0** | **15** | 手動 Rollback(已合併) | ✅ | switch default | 單終點 | **可讀性 / 精簡** |
| Saga4 v1.0.0 | 17 | **標準 `compensatedBy`** | ❌ | **`FailureSignal` 閘門** | **雙終點** | 合規性 / 可維護性 |
| **Saga5 v1.0.0** | **16** | **標準 `compensatedBy`** | ✅ | **`FailureSignal` 閘門** | **雙終點** | **精簡 + 合規 + 兜底三合一** |

> **Saga5 是 4 個特性的最佳交會點**:標準補償(Saga4)+ 決策合併(Saga3)+ 雙終點兜底(Saga4)+ 8 個核心業務/決策 state(Saga3 同等級)。

---

## 三、State 結構對比

### 3.1 完整 State 列表對比

| # | Saga3 v1.0.0 | Saga5 v1.0.0 | 變更類型 |
|---:|---|---|---|
| 1 | `ValidateInput` | `ValidateInput` | ✅ **完全相同**(1 條 `and` 正向條件) |
| 2 | `CallA16229State` | `CallA16229State` | 🔧 **加 `compensatedBy: CompensateA16229`** |
| 3 | `CheckA16229Result` | `CheckA16229Result` | ✅ 完全相同 |
| 4 | `CallA16220State` | `CallA16220State` | 🔧 **加 `compensatedBy` + `gateA16220Result` action + `businessStepFailed` onErrors** |
| 5 | `CheckA16220AndEvaluate` | `CheckA16220AndEvaluate` | 🔧 **defaultCondition 改為 `compensate: true`** |
| 6 | `RollbackA16220` | `CompensateA16220` | 🔁 **重命名 + `usedForCompensation: true`** |
| 7 | `RollbackA16229` | `CompensateA16229` | 🔁 **重命名 + `usedForCompensation: true`** |
| 8 | `CheckRollbackResult` | `CheckCompensationResult` | 🔁 **重命名**(邏輯完全相同) |
| 9 | `InjectValidationFailedStatus` | `InjectValidationFailedStatus` | ✅ 完全相同 |
| 10 | `InjectSuccessStatus` | `InjectSuccessStatus` | ✅ 完全相同 |
| 11 | `InjectFailedStatus` | `InjectFailedStatus` | ✅ 完全相同 |
| 12 | `InjectRolledBackStatus` | `InjectRolledBackStatus` | ✅ 完全相同 |
| 13 | `InjectRolledBackOnlyStatus` | `InjectRolledBackOnlyStatus` | ✅ 完全相同 |
| 14 | `InjectRollbackFailedStatus` | `InjectRollbackFailedStatus` | ✅ 完全相同 |
| 15 | `FinalAuditAndEnd` | `FinalAuditAndEnd` | 🔧 **新增 `onErrors → FinalAuditFallbackAndEnd`** |
| 16 | — | `FinalAuditFallbackAndEnd` | 🆕 **兜底終點** |
| | **15** | **16** | **+1** |

### 3.2 核心業務/決策 State 對比(8 vs 8)

| 編號 | Saga3 核心 | Saga5 核心 | 等價? |
|---:|---|---|---|
| 1 | `ValidateInput` | `ValidateInput` | ✅ 完全相同 |
| 2 | `CallA16229State` | `CallA16229State` | 🔧 補償宣告 |
| 3 | `CheckA16229Result` | `CheckA16229Result` | ✅ 完全相同 |
| 4 | `CallA16220State` | `CallA16220State` | 🔧 補償宣告 + gate |
| 5 | `CheckA16220AndEvaluate` | `CheckA16220AndEvaluate` | 🔧 default→compensate |
| 6 | `RollbackA16220` | `CompensateA16220` | 🔁 重命名+usedForCompensation |
| 7 | `RollbackA16229`(共用) | `CompensateA16229`(共用) | 🔁 重命名+usedForCompensation |
| 8 | `CheckRollbackResult` | `CheckCompensationResult` | 🔁 僅重命名 |

> **核心數完全相同(8 個)**,Saga5 比 Saga3 多出的 1 個 state 是 `FinalAuditFallbackAndEnd`(兜底終點,屬於「服務基礎設施」,非業務/決策)。

### 3.3 視覺化對比圖

```
Saga3 v1.0.0 (15 states)                       Saga5 v1.0.0 (16 states)
──────────────────────────                      ──────────────────────────

ValidateInput (P2-1 正向)                    ValidateInput (P2-1 正向,Saga3 同款)
     ↓                                            ↓
CallA16229State                              CallA16229State   [compensatedBy: CompensateA16229]
     ↓                                            ↓
CheckA16229Result                            CheckA16229Result
     ↓                                            ↓
CallA16220State                              CallA16220State   [compensatedBy: CompensateA16220]
     ↓                                            ↓             [+ gateA16220Result action]
CheckA16220AndEvaluate                       CheckA16220AndEvaluate  [default: compensate: true]
(Saga3 風格:三出口)                          (繼承 Saga3 三出口 + Saga4 compensate 語法)
     ↓ (超額/失敗)                                 ↓ (compensate)
RollbackA16220 → RollbackA16229            ╔════════════════════════════════════════╗
              → CheckRollbackResult         ║  引擎依 compensatedBy 自動逆序調度      ║
                                            ║  CompensateA16220 → CompensateA16229   ║
                                            ║        ↓                                ║
                                            ║  CheckCompensationResult (邏輯同 Saga3) ║
                                            ╚════════════════════════════════════════╝
Inject×6 (完全相同)                          Inject×6 (完全相同)
     ↓                                            ↓
FinalAuditAndEnd                             FinalAuditAndEnd  [+ onErrors]
(無兜底)                                         ↓ (error)
                                            FinalAuditFallbackAndEnd  [🆕 兜底]
```

---

## 四、核心差異詳解

### 4.1 補償模型:手動 Rollback 鏈 → 標準 `compensatedBy`

#### Saga3:手動 Rollback state(共用 `RollbackA16229`,已合併版本)

```yaml
# 觸發路徑 1:CheckA16220AndEvaluate(exceedAmountLimit) → RollbackA16220
# 觸發路徑 2:CheckA16220AndEvaluate(default) → RollbackA16229
- name: RollbackA16220
  actions: [EC: true 回沖 A16220]
  transition: RollbackA16229           # 手寫接到 A16229
- name: RollbackA16229                 # 共用節點(取代 Saga2 的 RollbackA16229Only)
  actions: [EC: true 回沖 A16229]
  transition: CheckRollbackResult
```

#### Saga5:標準 `compensatedBy`(引擎自動 LIFO)

```yaml
# 在 forward state 上宣告
- name: CallA16229State
  compensatedBy: CompensateA16229      # 🆕 宣告
  actions: [EC: false 扣款 A16229]
  transition: CheckA16229Result

- name: CallA16220State
  compensatedBy: CompensateA16220      # 🆕 宣告
  actions: [EC: false 入帳 A16220, gate 檢查]
  transition: CheckA16220AndEvaluate

# 補償 state(usedForCompensation: true)
- name: CompensateA16220
  usedForCompensation: true           # 🆕
  actions: [EC: true 沖正 A16220]

- name: CompensateA16229
  usedForCompensation: true           # 🆕
  actions: [EC: true 沖正 A16229]
```

**Saga5 比 Saga3 改進的觸發語法**:
```yaml
# Saga5 CheckA16220AndEvaluate.defaultCondition
defaultCondition:
  transition:
    compensate: true                  # 🆕 一行取代手寫 Rollback 鏈
    nextState: CheckCompensationResult
```

**對比**:

| 維度 | Saga3 | Saga5 |
|---|---|---|
| LIFO 順序 | transition 鏈隱含(開發者維護) | 引擎自動按完成順序逆序 |
| 新增補償步驟 | 改多處 transition + 新 Rollback state | 只在 forward state 加 `compensatedBy` |
| 規範合規 | 自定義 | **符合 SW 0.8 §Defining Compensation** |
| 命名 | `Rollback*` | `Compensate*` + `usedForCompensation: true` |
| 單/全補償區分 | 在 `CheckRollbackResult` 用 `a16220Rollback==null` 區分(因為 `RollbackA16229` 共用) | **由引擎根據 forward state 是否失敗自動決定**,效果一樣但語意更清晰 |

---

### 4.2 業務失敗判定:`switch default` → `FailureSignal` 通用閘門

#### Saga3:業務失敗判定在 `CheckA16220AndEvaluate` 的 default 條件

```yaml
- name: CheckA16220AndEvaluate
  type: switch
  dataConditions:
    - name: transferSuccess
      condition: '${ .a16220Result.code == "100" and .AMT <= 500 }'
      transition: InjectSuccessStatus
    - name: exceedAmountLimitRollbackBoth
      condition: '${ .a16220Result.code == "100" and .AMT > 500 }'
      transition: RollbackA16220          # ← 寫死超額補償鏈
  defaultCondition:
    transition: RollbackA16229            # ← 寫死失敗單退路徑
```

**問題**:
- 成功碼 `"100"` 寫死在 workflow 的 `condition` 內
- 業務失敗靠 default 兜底間接判斷
- 三條出口分散到不同 transition target

#### Saga5:`FailureSignal` 閘門 + 參數化判定 + 三條出口顯式化

```yaml
# 在 CallA16220State 內加入 gate action
- name: CallA16220State
  compensatedBy: CompensateA16220
  actions:
    - name: callA16220Action
      actions: [EC: false 呼叫 A16220]
    - name: gateA16220Result             # 🆕 通用閘門
      functionRef:
        refName: failureSignal
        arguments:
          stepName: "CallA16220State"
          excluded: '${ .a16220Result.code != "100" }'   # ← 判定式參數化
          businessCode: '${ .a16220Result.code }'
      actionDataFilter:
        useResults: false                 # 不污染 state data
  onErrors:
    - errorRef: businessStepFailed        # 🆕 閘門拋出的錯誤
      transition:
        compensate: true
        nextState: CheckCompensationResult
```

```yaml
# CheckA16220AndEvaluate 變得更簡潔(default 變安全網)
- name: CheckA16220AndEvaluate
  dataConditions:
    - name: transferSuccess
      condition: '${ .a16220Result.code == "100" and .AMT <= 500 }'
      transition: InjectSuccessStatus
    - name: exceedAmountLimitCompensateBoth   # 🆕 改名(更精準)
      condition: '${ .a16220Result.code == "100" and .AMT > 500 }'
      transition:
        compensate: true
        nextState: CheckCompensationResult
  defaultCondition:
    # 安全網 (正常不可達):保守觸發補償,避免雙邊扣款卻無補償
    transition:
      compensate: true
      nextState: CheckCompensationResult
```

**Saga5 的關鍵改進**:

| 維度 | Saga3 | Saga5 |
|---|---|---|
| 成功碼規則 | 寫死在 `condition`(workflow 端) | **參數化在 `excluded` jq**,workflow 端可調 |
| 跨工作流重用 | 每個工作流重寫 `code == "100"` | `FailureSignal` 全專案共用 |
| 業務失敗判定時機 | 在下一個 switch 內 | **在 forward state action 階段**,引擎視角「state 失敗」 |
| `exceedAmountLimitRollbackBoth` 命名 | `exceedAmountLimitRollbackBoth` | 保留 + 更精準的註解 |
| `CheckA16220AndEvaluate` 的 default 角色 | 業務失敗的實際判定點 | **退化為安全網**(實際失敗已被 gate 攔截) |

> **Saga5 的關鍵抽象**:`FailureSignal` 把「業務失敗」提升為與「平台錯誤」同等地位 —— 都是 forward state 的失敗,都會被引擎識別並排除 `compensatedBy`。`CheckA16220AndEvaluate` 的 default 因此**不再是業務失敗的主要判定點**,而是退化成「誤入安全網」。

---

### 4.3 補償結果判定:`CheckRollbackResult` → `CheckCompensationResult`(僅重命名)

**這部分 Saga5 與 Saga3 邏輯完全相同**,僅 state 名稱從 `CheckRollbackResult` 改為 `CheckCompensationResult`(對應 Saga5 的整體補償語彙)。

```yaml
# Saga3 CheckRollbackResult vs Saga5 CheckCompensationResult(邏輯完全相同)
dataConditions:
  - name: lifoRollbackSuccess     # Saga3
    condition: '${ .a16220Rollback != null and .a16220Rollback.code == "100" and .a16229Rollback.code == "100" }'
    transition: InjectRolledBackStatus
  - name: singleRollbackSuccess   # Saga3
    condition: '${ .a16220Rollback == null and .a16229Rollback.code == "100" }'
    transition: InjectRolledBackOnlyStatus
  # Saga5 把 lifoRollbackSuccess / singleRollbackSuccess 改名為 lifoCompensationSuccess / singleCompensationSuccess
defaultCondition:
  transition: InjectRollbackFailedStatus
```

**注意**:
- Saga3 與 Saga5 都用 `a16220Rollback==null` 區分「單退」與「全退」,這個判斷邏輯依賴 **`CompensateA16229` 是共用節點**(Saga3) / **由引擎自動排除失敗步驟的補償**(Saga5)
- 兩種實作路徑殊途同歸,但 Saga5 的語意更清晰(由引擎保證)

---

### 4.4 終點設計:單終點 → 雙終點(沿用 Saga4 改進)

#### Saga3:單終點
```yaml
- name: FinalAuditAndEnd
  type: operation
  # 無 onErrors → 若 audit service 拋例外,workflow 直接終止,輸出丟失
  actions: [saveAuditLog, raiseOpsAlert]
```

#### Saga5:雙終點(Saga4 風格)
```yaml
- name: FinalAuditAndEnd
  type: operation
  onErrors:                            # 🆕 audit 階段錯誤有兜底
    - errorRef: platformError
      transition: FinalAuditFallbackAndEnd
  actions: [saveAuditLog, raiseOpsAlert]

- name: FinalAuditFallbackAndEnd        # 🆕 兜底終點
  type: inject                         # 純 Inject,不呼叫外部服務
  data:
    auditFallback: true
  stateDataFilter:
    output: |                          # 完整 9 欄位輸出模板
      {
        status: .finalStatus,
        message: .finalMessage,
        AMT: .AMT,
        a16229Result: (.a16229Result // null),
        a16220Result: (.a16220Result // null),
        a16229Rollback: (.a16229Rollback // null),
        a16220Rollback: (.a16220Rollback // null),
        auditSaved: false,
        opsAlertRaised: false
      }
  end: true
```

> Saga5 的雙終點設計與 Saga4 完全相同,是 Saga4 帶過來的最佳實踐。

---

### 4.5 錯誤定義:1 個 → 2 個(沿用 Saga4)

| Error | Saga3 | Saga5 |
|---|---|---|
| `platformError` | ✅ | ✅ |
| `businessStepFailed`(對應 `BusinessStepFailedException`) | ❌ | 🆕 |

### 4.6 Functions 區塊:3 個 → 4 個(沿用 Saga4)

| Function | Saga3 | Saga5 |
|---|---|---|
| `callApiViaOpenAPI` | ✅ | ✅ |
| `failureSignal` | ❌ | 🆕 `FailureSignal::raiseIfExcluded` |
| `recordAuditLog` | ✅ | ✅ |
| `notifyOps` | ✅ | ✅ |

---

## 五、Saga3 vs Saga5 — State 級逐項對比

| 項目 | Saga3 v1.0.0 | Saga5 v1.0.0 | 等價? |
|---|---|---|---|
| `ValidateInput` 條件 | 1 條 `and` 正向 | **完全相同** | ✅ |
| `CallA16229State` | 普通 operation | + `compensatedBy: CompensateA16229` | 🔧 |
| `CheckA16229Result` | 1 條正向 + default | **完全相同** | ✅ |
| `CallA16220State` | 1 個 action(calling) | + `compensatedBy` + `gateA16220Result` action + `businessStepFailed` onErrors | 🔧🔧 |
| `CheckA16220AndEvaluate` | 3 條出口(正向/超額/default) | **繼承 Saga3 結構,default 改為 `compensate: true`** | 🔧 |
| `RollbackA16220` / `CompensateA16220` | 普通 operation | 重命名 + `usedForCompensation: true` | 🔁 |
| `RollbackA16229` / `CompensateA16229` | 普通 operation(共用) | 重命名 + `usedForCompensation: true`(由引擎調度) | 🔁 |
| `CheckRollbackResult` / `CheckCompensationResult` | 2 條正向 + default | **邏輯完全相同**,僅重命名 | 🔁 |
| `InjectValidationFailedStatus / Success / Failed / RolledBack / RolledBackOnly / RollbackFailed` | 完全相同 | **完全相同** | ✅ |
| `FinalAuditAndEnd` | 無 onErrors | + `onErrors → FinalAuditFallbackAndEnd` | 🔧 |
| `FinalAuditFallbackAndEnd` | ❌ | 🆕 兜底終點 | 🆕 |
| 輸出 JSON schema | 9 欄位 | **完全相同** | ✅ |
| workflowId | `"saga3-transfer-workflow"` | `"saga5-transfer-workflow"` | — |

---

## 六、行為等價性速查表(給 reviewer)

| 場景 | Saga3 路徑 | Saga5 路徑 | 輸出等價? |
|---|---|---|---|
| 輸入欄位失敗 | `InjectValidationFailedStatus` → `FinalAuditAndEnd` | 完全相同 | ✅ |
| A16229 失敗 | `CheckA16229Result(default)` → `InjectFailedStatus` | 完全相同 | ✅ |
| **A16220 業務失敗(僅回沖 A16229)** | `CheckA16220AndEvaluate(default)` → `RollbackA16229` → `CheckRollbackResult(singleRollbackSuccess)` → `InjectRolledBackOnlyStatus` | `gateA16220Result` 拋錯 → onErrors(businessStepFailed) → `compensate: true` → 引擎僅調度 `CompensateA16229` → `CheckCompensationResult(singleCompensationSuccess)` → `InjectRolledBackOnlyStatus` | ✅ |
| 兩階段成功 + AMT≤500 | `CheckA16220AndEvaluate(transferSuccess)` → `InjectSuccessStatus` | 完全相同 | ✅ |
| 兩階段成功 + AMT>500(全回沖) | `CheckA16220AndEvaluate(exceedAmountLimitRollbackBoth)` → `RollbackA16220` → `RollbackA16229` → `CheckRollbackResult(lifoRollbackSuccess)` → `InjectRolledBackStatus` | `CheckA16220AndEvaluate(exceedAmountLimitCompensateBoth)` → `compensate: true` → 引擎逆序調度 `CompensateA16220 → CompensateA16229` → `CheckCompensationResult(lifoCompensationSuccess)` → `InjectRolledBackStatus` | ✅ |
| A16220 platformError | `CallA16220State.onErrors(platformError)` → `RollbackA16229`(注:Saga3 沒有 platformError onErrors) | `CallA16220State.onErrors(platformError)` → `compensate: true` → 引擎僅調度 `CompensateA16229` | 🔧 **Saga3 在 `CallA16220State` 沒有 platformError onErrors**(見下方註) |
| 任一回沖失敗 | `InjectRollbackFailedStatus` → `FinalAuditAndEnd` | 完全相同 | ✅ |
| audit service 階段錯誤 | 無兜底,輸出丟失 | `FinalAuditAndEnd.onErrors` → `FinalAuditFallbackAndEnd`,輸出仍 9 欄位但 `auditSaved: false` | 🆕 **Saga5 更安全** |
| 輸出 JSON schema | 9 欄位 | 9 欄位 | ✅ |

> **⚠️ Saga3 的 `CallA16220State` 沒有 platformError onErrors!**
> 比較發現,Saga3 的 `CallA16220State` 只在 description 區註記了錯誤處理,但**沒有實際的 `onErrors` 區塊** —— 也就是說,如果 MyOpenApiService 真的拋出 platformError(state timeout / 引擎例外),Saga3 會**直接終止 workflow,沒有補償路徑**。
>
> Saga5 修補了這個缺口:`CallA16220State.onErrors(platformError)` → `compensate: true`,確保即使服務層拋例外也會補償 A16229。
>
> 這是 Saga5 比 Saga3 更穩健的關鍵之一 —— 順手補上 Saga3 的可靠性缺口。

---

## 七、Saga5 vs Saga4 — 同架構底下的差異

兩者都用標準 `compensatedBy`,差異僅在「決策合併」一項:

| 面向 | Saga4 v1.0.0 | Saga5 v1.0.0 |
|---|---|---|
| 補償模型 | 標準 `compensatedBy` | **相同** |
| 業務失敗判定 | `FailureSignal` 閘門 | **相同** |
| 終點 | 雙終點 | **相同** |
| **決策合併** | ❌ `CheckA16220Result` + `DecideByEvaluation` 兩個 state | ✅ `CheckA16220AndEvaluate` 單一 state |
| `ValidateInput` 樣式 | 5 條負向條件 | ✅ **沿用 Saga3 的 1 條 `and` 正向** |
| State 總數 | 17 | 16(−1) |
| 核心業務/決策 state 數 | 9 | **8** |
| `CallA16220State.onErrors(platformError)` | ✅ 已加 | ✅ 已加 |

> **Saga5 是「Saga4 的精簡決策版」**:把 Saga4 採用的「Saga2 風格決策」(兩個獨立 switch)改為 Saga3 風格(單一合併 switch),State 數從 17 → 16。

---

## 八、Saga5 比 Saga3 多了什麼?(從 Saga3 升級 Saga5 的價值)

### 8.1 新增的可靠性強化

| 強化項 | Saga3 | Saga5 | 說明 |
|---|---|---|---|
| 補償語法合規 | 自定義 Rollback 鏈 | **SW 0.8 標準** | Saga5 符合 Serverless Workflow 規範 |
| 業務失敗判定抽象 | 寫死在 workflow | **`FailureSignal` 通用閘門** | 改成功碼零 Java 修改 |
| 業務失敗的「一等公民」化 | 靠 default 兜底 | **有專屬 error 與 Java 例外** | 引擎可識別並排除補償 |
| `CallA16220State` platformError 兜底 | ❌ 缺失 | ✅ `compensate: true` | **Saga3 的可靠性缺口,Saga5 補上** |
| audit 階段兜底終點 | ❌ 單終點,輸出丟失風險 | ✅ `FinalAuditFallbackAndEnd` | 「任何例外皆有終態輸出」 |
| Functions 重用性 | 3 個,workflow 專用 | **4 個,`failureSignal` 全專案共用** | 跨工作流可重用 |

### 8.2 新增的 Java 元件

從 Saga3 升級到 Saga5 需要新增兩個 Java 元件(同 Saga4):

| 元件 | 必要性 | 跨工作流可重用? |
|---|---|---|
| `BusinessStepFailedException` | 必須 | ✅ |
| `FailureSignal.raiseIfExcluded` | 必須 | ✅(全專案共用) |

> 兩個元件都是**全專案通用**,一次寫好所有 workflow 都能用。

### 8.3 行為差異點(罕見但需注意)

| 點 | Saga3 | Saga5 | 影響 |
|---|---|---|---|
| `CallA16220State` 拋 platformError | 終止 workflow,無補償 | 走 `compensate: true` 補償 A16229 | Saga5 更安全 |
| audit service 超時/錯誤 | 輸出丟失 | 走 `FinalAuditFallbackAndEnd`,`auditSaved: false` | Saga5 更安全 |
| 業務失敗判定時機 | 在 `CheckA16220AndEvaluate` 內 | 在 `CallA16220State` action 階段 | Saga5 引擎視角更清晰 |
| 補償 state 名稱 | `RollbackA16220 / RollbackA16229` | `CompensateA16220 / CompensateA16229` | 若監控有針對 state 名稱的告警需更新 |

---

## 九、為什麼 Saga5 是「最優形態」?

Saga5 達成了一個優雅的三合一:

1. **Saga3 的精簡決策**:8 個核心業務/決策 state(全 saga 系列最少)
2. **Saga4 的標準補償**:`compensatedBy` + `FailureSignal` 通用閘門
3. **Saga4 的雙終點兜底**:`FinalAuditFallbackAndEnd` 保障輸出永遠在

```
              ┌────────────────────────────────────────┐
              │              Saga5 (16 states)         │
              │                                        │
              │   ┌──────────────────────────────┐     │
              │   │ 標準補償 (compensatedBy)     │     │
              │   │ 來自 Saga4                   │     │
              │   └──────────────────────────────┘     │
              │   ┌──────────────────────────────┐     │
              │   │ FailureSignal 通用閘門       │     │
              │   │ 來自 Saga4                   │     │
              │   └──────────────────────────────┘     │
              │   ┌──────────────────────────────┐     │
              │   │ 雙終點兜底                   │     │
              │   │ 來自 Saga4                   │     │
              │   └──────────────────────────────┘     │
              │   ┌──────────────────────────────┐     │
              │   │ CheckA16220AndEvaluate 合併  │     │
              │   │ 來自 Saga3                   │     │
              │   └──────────────────────────────┘     │
              │   ┌──────────────────────────────┐     │
              │   │ ValidateInput P2-1 正向       │     │
              │   │ 來自 Saga3                   │     │
              │   └──────────────────────────────┘     │
              └────────────────────────────────────────┘
```

**Saga5 = Saga3 + Saga4 = (精簡 + 合規 + 兜底)**

如果你的團隊正在選型,**Saga5 是推薦選項**,理由:
- ✅ state 數最少(16,僅比 Saga3 多 1 個兜底終點)
- ✅ 規範合規(SW 0.8 標準補償)
- ✅ 業務失敗閘門化(`FailureSignal` 全專案共用)
- ✅ 雙終點兜底(audit 失敗也有輸出)
- ✅ 補上 Saga3 的 `CallA16220State` platformError 可靠性缺口

---

## 十、總結

> **Saga5 v1.0.0 是 Saga3 v1.0.0 的「標準補償架構升級版」**。
>
> 保留 Saga3 的兩大精簡(8 核心 state、`CheckA16220AndEvaluate` 合併、`ValidateInput` P2-1 正向),引入 Saga4 的四大改進(`compensatedBy` 標準補償、`FailureSignal` 閘門、`businessStepFailed` error 定義、`FinalAuditFallbackAndEnd` 兜底終點)。
>
> **狀態數 +1**(因新增兜底終點),但**核心業務/決策 state 數仍是 8 個**(全 saga 系列最少)。
>
> 從 Saga3 升級到 Saga5 需要新增兩個 Java 通用元件(`BusinessStepFailedException` + `FailureSignal`),但這兩個元件跨工作流可重用,屬於一次性投入。
>
> **Saga5 是 5 個 saga 版本中最均衡的選擇** —— 既精簡又合規,既簡潔又穩健,推薦作為新建工作流的起點。
