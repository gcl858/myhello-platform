# 零侵入獨立特徵外掛 (Feature Overlay Autonomous Plugin) 方案總結

為解決過去使用 `sonataflow-integration` 將業務套件分散至專案 5 大模組導致耦合過深、抽離困難的問題，本方案設計並實作了 **「零侵入獨立特徵外掛架構 (Feature Overlay Architecture)」**。

現在，`ai-studio/draft-digital-loan-disbursement` 的完整業務資產已完全收斂於單一自主目錄：
`project/features/draft-digital-loan-disbursement/`

未來抽離此功能時，**只需直接刪除該特徵目錄 (`rm -rf`)**，全專案無須手動還原任何 Java 程式碼或 `application.properties` 設定，且 Maven 建置與全模組測試立即 100% 通過。

---

## 核心架構與設計

```mermaid
flowchart TD
    subgraph FeatureDirectory["自主特徵目錄 (project/features/draft-digital-loan-disbursement/)"]
        F1["feature.yaml (元資料)"]
        F2["workflows/*.sw.yaml"]
        F3["specs/internal & external/*.yaml"]
        F4["mocks/*.java & dto/*.java"]
        F5["db/migration/*.sql & teardown.sql"]
        F6["tests/*WorkflowTest.java"]
    end

    subgraph BuildPhase["Maven Initialize 階段動態裝配 (零污染)"]
        A1["maven-antrun-plugin (transfer-mock)<br/>探測 features/*/mocks -> src/.../features/"]
        A2["maven-antrun-plugin (transfer-app)<br/>探測 features/* -> resources & tests/.../features/"]
        C1["maven-clean-plugin<br/>建置開始時自動清理所有暫存裝配產物"]
    end

    subgraph CorePlatform["平台核心層 (已解耦與泛型化)"]
        P1["platform-security: SonataFlowSecurityConfig<br/>支援萬用字元 platform.status-rewrite.workflows=*"]
        P2["transfer-app: OpenApiSchemaValidator<br/>自動掃描 specs/internal 動態註冊驗證器"]
        P3["transfer-app: application.properties<br/>移除特徵硬編碼 ID，使用萬用字元配置"]
    end

    FeatureDirectory -->|Maven 初始化探測裝配| BuildPhase
    BuildPhase --> CorePlatform
```

---

## 檔案變更清單與目錄結構

### 1. 自主特徵目錄結構 (`project/features/draft-digital-loan-disbursement/`)

| 檔案路徑 | 作用說明 |
|---|---|
| [feature.yaml](file:///media/op/acer_sata/2026_AI_Hack/SonataFlow/workspace-0910/project/features/draft-digital-loan-disbursement/feature.yaml) | 特徵元資料（名稱、版本、維護團隊、工作流 ID 清單） |
| `workflows/*.sw.yaml` | `loan_transaction` (Parent)、`loan_disbursement` (Child)、`loan_cancellation` (Child) |
| `specs/internal/*.yaml` | `loan-transaction-api.yaml`（含 `x-workflow-id: loan_transaction` 動態路由入口） |
| `specs/external/*.yaml` | `core-loan-account-disbursement-api.yaml`、`risk-credit-assessment-api.yaml`、`core-deposit-credit-api.yaml` |
| `mocks/*.java` | `CoreLoanAccountResource`、`LoanRiskAssessmentResource`、`CoreDepositCreditResource` 與 DTOs |
| `db/migration/*.sql` | `V1.2.7__create_loan_reconciliation_view.sql` (Flyway SQLite 視圖) |
| `db/teardown.sql` | `DROP VIEW IF EXISTS vw_loan_reconciliation;` (抽離時的資料庫清理腳本) |
| `tests/*.java` | `LoanTransactionWorkflowTest.java` (5 大 E2E 情境測試，package 隔離於 `.features`) |
| `docs/` | 需求規格書與設計決策說明文件 |

### 2. 核心模組散落檔案清理 (Core Decoupling)

已從以下專案核心模組中徹底清除貸款相關的業務檔案，回歸純淨基線：
- **`domain-transfer/transfer-workflow`**: 刪除 `loan_*.sw.yaml` 與 `specs/internal|external/*loan*`。
- **`domain-reconciliation/reconciliation-api`**: 刪除 `V1.2.7__create_loan_reconciliation_view.sql`。
- **`dev/transfer-mock`**: 刪除 `CoreLoanAccountResource.java`、`LoanRiskAssessmentResource.java` 等。
- **`distribution/transfer-app`**: 刪除核心 test 目錄下的 `LoanTransactionWorkflowTest.java`。

### 3. 平台底座升級 (Platform Enablement)

- [SonataFlowSecurityConfig.java](file:///media/op/acer_sata/2026_AI_Hack/SonataFlow/workspace-0910/project/platform-security/src/main/java/com/example/platform/security/SonataFlowSecurityConfig.java)：
  支援 `platform.status-rewrite.workflows=*` 萬用字元匹配，未來任何新特徵上線均**無須修改平台設定**。
- [application.properties](file:///media/op/acer_sata/2026_AI_Hack/SonataFlow/workspace-0910/project/distribution/transfer-app/src/main/resources/application.properties)：
  配置 `platform.status-rewrite.workflows=*`，移除所有寫死的貸款工作流 ID。
- [transfer-mock/pom.xml](file:///media/op/acer_sata/2026_AI_Hack/SonataFlow/workspace-0910/project/dev/transfer-mock/pom.xml)：
  使用離線快取的 `maven-clean-plugin` 與 `maven-antrun-plugin`，在 `initialize` 階段自動探測並同步 `../../features/*/mocks` 至暫存目錄 `.../api/features/`（排除既有共用 DTO 避免重複定義）。
- [transfer-app/pom.xml](file:///media/op/acer_sata/2026_AI_Hack/SonataFlow/workspace-0910/project/distribution/transfer-app/pom.xml)：
  在 `initialize` 階段自動探測並動態掛載所有 `features/*/` 的工作流、規格、SQL 與測試。
- [offline-build.sh](file:///media/op/acer_sata/2026_AI_Hack/SonataFlow/workspace-0910/project/offline-build.sh) / `offline-build.ps1`：
  加入 `features/*/workflows/*.sw.yaml` 至 `${DATA_DIR}/workflows` 的動態收集，供對帳前端 UI 檢視。
- [.gitignore](file:///media/op/acer_sata/2026_AI_Hack/SonataFlow/workspace-0910/project/.gitignore)：
  排除所有動態掛載的暫存目標路徑，確保 Git 工作區完全乾淨。
- [SKILL.md](file:///media/op/acer_sata/2026_AI_Hack/SonataFlow/workspace-0910/ai-studio/.agents/skills/sonataflow-integration/SKILL.md)：
  擴充 `v3.0 零侵入獨立特徵目錄模式` SOP 規範供後續開發與 Agent 遵循。

---

## 驗證結果

### 1. 特徵存在時的完整建置與測試

執行全專案 22 個模組測試：
```bash
mvn test
```
- **測試結果**：**113 個測試全數通過（含 5 個貸款交易 E2E 測試），0 失敗，0 錯誤**。
- **建置狀態**：**BUILD SUCCESS**。
- **動態註冊**：`OpenApiSchemaValidator` 於啟動時成功動態註冊 3 個工作流程 Schema（包含 `loan_transaction`）。

### 2. 雙向無痛抽離實測 (Proof of Seamless Uninstallation)

為了驗證「未來抽離僅須刪除目錄」的硬性要求，進行了真實的特徵移除模擬測試：

1. **抽離特徵**：
   ```bash
   mv project/features/draft-digital-loan-disbursement /tmp/...
   ```
2. **立即執行全專案建置**：
   ```bash
   mvn test
   ```
   - **測試結果**：**108 個基礎測試全數通過，0 失敗，0 錯誤**。
   - **建置狀態**：**BUILD SUCCESS**（22 個模組全部通過）。
   - **驗證確認**：`OpenApiSchemaValidator` 自動縮減為載入 2 個基礎工作流 Schema；未殘留任何缺少 Mock、缺少 Bean 或工作流找不到的編譯/執行期錯誤。
3. **還原特徵**：
   ```bash
   mv /tmp/... project/features/draft-digital-loan-disbursement
   mvn test
   ```
   - **測試結果**：再次自動裝配，**113 個測試立即全數通過，BUILD SUCCESS**。

---

## 未來抽離操作手冊 (Uninstallation Guide)

未來若需將 `draft-digital-loan-disbursement` 徹底從專案中抽離，僅需執行以下兩步驟：

```bash
# 步驟 1: 清理本機 SQLite 中的對帳 View (若有需要)
sqlite3 data/reconciliation.db < project/features/draft-digital-loan-disbursement/db/teardown.sql

# 步驟 2: 刪除特徵目錄
rm -rf project/features/draft-digital-loan-disbursement

# 步驟 3: 驗證建置 (完全無需修改 pom.xml 或 application.properties)
mvn test
```

