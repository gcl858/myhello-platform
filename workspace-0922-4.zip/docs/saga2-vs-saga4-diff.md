# Saga2 vs Saga4 Transfer Workflow 差異分析

> 對標檔案:
> - `project/domain-transfer/transfer-workflow/src/main/resources/saga2-transfer-workflow.sw.yaml`(v2.2.0,447 行,18 個 State)
> - `project/domain-transfer/transfer-workflow/src/main/resources/saga4-transfer-workflow.sw.yaml`(v1.0.0,507 行,17 個 State)

---

## 一、TL;DR

Saga4 是 Saga2 v2.2.0 的 **「架構升級版」**,不是精簡版 —— 兩者**對外行為等價**(同樣兩階段轉帳 + Saga LIFO 補償 + 同樣 9 欄位輸出契約),但 **Saga4 採用 Serverless Workflow 0.8 標準補償語法**(`compensatedBy` + `usedForCompensation`),把 Saga2 的「手動 Rollback state 串接」改成「引擎自動 LIFO 調度」,並新增 `FailureSignal` 通用閘門與 `FinalAuditFallbackAndEnd` 兜底終點。

| 面向 | Saga2 v2.2.0 | Saga4 v1.0.0 |
|---|---|---|
| **補償模型** | 手動 Rollback state 串接(自寫 LIFO) | **SW 標準 `compensatedBy`**(引擎自動逆序調度) |
| **State 總數** | 18 | 17(−1) |
| **核心補償 state** | `RollbackA16220 / RollbackA16229 / RollbackA16229Only`(3 個手動串接) | `CompensateA16220 / CompensateA16229`(2 個,引擎調度) |
| **業務失敗判定** | 在 switch `defaultCondition` 走補償路徑 | **新閘門 `FailureSignal.raiseIfExcluded`**:`excluded` jq 參數化 |
| **錯誤定義** | 1 個:`platformError` | **2 個**:`platformError` + `businessStepFailed`(對應 `BusinessStepFailedException`) |
| **終點數** | 1 個:`FinalAuditAndEnd` | **2 個**:`FinalAuditAndEnd`(正常)+ `FinalAuditFallbackAndEnd`(兜底) |
| **輸出契約** | 9 欄位 | **完全相同**(刻意維持) |

> **關鍵設計意圖**:Saga4 不是為了改業務,而是為了「**合規與可維護性**」—— 把補償語法交給引擎,業務失敗判定參數化,Java 端零修改即可換成功碼規則。

---

## 二、版本與演進路徑

```
Saga2 v2.0  ─→  v2.1.0  ─→  v2.2.0  ───┐
  (初始)        (可靠性)    (OpsAlert)   │
                                       ├── 兩條平行遷移路徑:
                                       │
                                       ├─→ Saga3 v1.0.0  (純結構精簡,行為等價)
                                       │
                                       └─→ Saga4 v1.0.0  (架構升級,標準補償)
                                            └─ 你現在看到的這個
```

- **Saga3 路徑**:`state 數量縮減`、`switch 條件合併`(P2-1 正向化)
- **Saga4 路徑**:`compensatedBy 標準化`、`FailureSignal 通用化`、`FinalAuditFallbackAndEnd 兜底化`
- 兩者**業務語意與輸出契約完全等價**,選擇哪條路徑取決於團隊偏好:精簡可讀 vs 標準合規。

---

## 三、State 結構對比

### 3.1 完整 State 列表對比

| # | Saga2 v2.2.0 | Saga4 v1.0.0 | 變更類型 |
|---:|---|---|---|
| 1 | `ValidateInput` | `ValidateInput` | ✅ 完全相同 |
| 2 | `CallA16229State` | `CallA16229State` | 🔧 **加 `compensatedBy: CompensateA16229`** |
| 3 | `CheckA16229Result` | `CheckA16229Result` | ✅ 完全相同 |
| 4 | `CallA16220State` | `CallA16220State` | 🔧 **加 `compensatedBy` + `gateA16220Result` action + `businessStepFailed` onErrors** |
| 5 | `CheckA16220Result` | `CheckA16220Result` | 🔧 **defaultCondition 改為 `compensate: true`** |
| 6 | `DecideByEvaluation` | `DecideByEvaluation` | 🔧 **defaultCondition 改為 `compensate: true`** |
| 7 | `RollbackA16220` | `CompensateA16220` | 🔁 **重命名 + `usedForCompensation: true`** |
| 8 | `RollbackA16229` | `CompensateA16229` | 🔁 **重命名 + `usedForCompensation: true`** |
| 9 | `RollbackA16229Only` | **(移除)** | ❌ 由引擎自動調度取代 |
| 10 | `CheckRollbackResults` | `CheckCompensationResult` | 🔁 **合併重命名(原兩個檢查 state 合併為一)** |
| 11 | `CheckRollbackA16229OnlyResult` | **(併入上者)** | ❌ |
| 12 | `InjectValidationFailedStatus` | `InjectValidationFailedStatus` | ✅ 完全相同 |
| 13 | `InjectSuccessStatus` | `InjectSuccessStatus` | ✅ 完全相同 |
| 14 | `InjectFailedStatus` | `InjectFailedStatus` | ✅ 完全相同 |
| 15 | `InjectRolledBackStatus` | `InjectRolledBackStatus` | ✅ 完全相同 |
| 16 | `InjectRolledBackOnlyStatus` | `InjectRolledBackOnlyStatus` | ✅ 完全相同 |
| 17 | `InjectRollbackFailedStatus` | `InjectRollbackFailedStatus` | ✅ 完全相同 |
| 18 | `FinalAuditAndEnd` | `FinalAuditAndEnd` | 🔧 **新增 `onErrors → FinalAuditFallbackAndEnd`** |
| 19 | — | `FinalAuditFallbackAndEnd` | 🆕 **兜底終點** |
| | **18** | **17** | **−1** |

### 3.2 視覺化對比圖

```
Saga2 v2.2.0 (18 states)                          Saga4 v1.0.0 (17 states)
─────────────────────────────                      ─────────────────────────────
                                                      
ValidateInput                                    ValidateInput  (相同)
     ↓                                                ↓
CallA16229State                                  CallA16229State   [compensatedBy: CompensateA16229]
     ↓                                                ↓
CheckA16229Result                                CheckA16229Result
     ↓                                                ↓
CallA16220State                                  CallA16220State   [compensatedBy: CompensateA16220]
     ↓                                                ↓             [+ gateA16220Result action]
CheckA16220Result                                CheckA16220Result  [default: compensate: true]
     ↓                                                ↓
DecideByEvaluation                               DecideByEvaluation  [default: compensate: true]
     ↓ (default)                                       ↓ (compensate)
RollbackA16220 ──→ RollbackA16229 ──→ CheckRollbackResults       ╔═══════════╗
                           ↓                  ↓                  ║  引擎依 compensatedBy  ║
                       RollbackA16229Only ──→ CheckRollbackA16229OnlyResult  ║  自動逆序(LIFO)調度 ║
                                                       ↓                 ║  CompensateA16220    ║
                                                       ↓                 ║       ↓             ║
                                                  [失敗處理]           ║  CompensateA16229   ║
                                                                        ║       ↓             ║
                                                                        ║ CheckCompensationResult ║
                                                                        ╚═══════════╝
Inject×6 (完全相同)                                Inject×6 (完全相同)
     ↓                                                ↓
FinalAuditAndEnd                                  FinalAuditAndEnd  [+ onErrors]
                                                       ↓ (error)
                                                  FinalAuditFallbackAndEnd  [🆕 兜底]
```

---

## 四、核心差異詳解

### 4.1 補償模型:手動 Rollback → 標準 `compensatedBy`

這是 Saga4 最大的語意改變。

#### Saga2:手動 Rollback state 串接(LIFO 由開發者手寫)

```yaml
# 觸發路徑:DecideByEvaluation default → RollbackA16220
- name: RollbackA16220
  actions: [EC: true 回沖 A16220]
  transition: RollbackA16229          # 寫死接到 A16229
- name: RollbackA16229
  actions: [EC: true 回沖 A16229]
  transition: CheckRollbackResults
```

**痛點**:
- 開發者必須手動維護 `transition` 鏈,新增/調整補償順序要改多處
- 「LIFO」是靠 transition 順序隱含表達的,不是宣告式
- 業務失敗的單退路徑(`RollbackA16229Only`)是另一條平行鏈,程式碼重複

#### Saga4:標準 `compensatedBy`(引擎自動 LIFO)

```yaml
# 在 forward state 上宣告補償對象
- name: CallA16229State
  compensatedBy: CompensateA16229      # 🆕 宣告
  actions: [EC: false 扣款 A16229]
  transition: CheckA16229Result

- name: CallA16220State
  compensatedBy: CompensateA16220      # 🆕 宣告
  actions: [EC: false 入帳 A16220, gate 檢查]
  transition: CheckA16220Result

# 補償 state(usedForCompensation: true)
- name: CompensateA16220
  usedForCompensation: true           # 🆕 標記
  actions: [EC: true 沖正 A16220]

- name: CompensateA16229
  usedForCompensation: true           # 🆕 標記
  actions: [EC: true 沖正 A16229]
```

**補償觸發**:
```yaml
# 在 transition 上標 compensate: true
- name: DecideByEvaluation
  defaultCondition:
    transition:
      compensate: true                # 🆕 引擎自動逆序調度所有 compensatedBy
      nextState: CheckCompensationResult
```

**優勢**:
| 面向 | Saga2 手動 | Saga4 標準 |
|---|---|---|
| LIFO 順序 | transition 鏈隱含 | 引擎自動按完成順序逆序 |
| 新增補償步驟 | 改多處 transition | 只在 forward state 加 `compensatedBy` |
| 規範合規 | 自定義 | **符合 SW 0.8 §Defining Compensation** |
| 可視性 | 需 trace transition | 一行 `compensatedBy` 自描述 |
| 單/全補償區分 | 兩個 Rollback state(`RollbackA16229` vs `RollbackA16229Only`) | **由引擎根據 forward state 是否成功自動決定**(見 4.3) |

---

### 4.2 業務失敗判定:`defaultCondition` → `FailureSignal` 通用閘門

#### Saga2:業務失敗判定寫死在 switch 內

```yaml
- name: CheckA16220Result
  type: switch
  dataConditions:
    - name: a16220Success
      condition: '${ .a16220Result.code == "100" }'
      transition: DecideByEvaluation
  defaultCondition:                  # ← 業務失敗走這裡
    transition: RollbackA16229Only    # 手動接到單退
```

**問題**:
- 成功碼 `"100"` 寫死在 workflow 內,跨工作流無法重用
- 業務失敗靠「default 兜底」間接判斷,可讀性差

#### Saga4:`FailureSignal` 閘門 + 參數化判定

```yaml
- name: CallA16220State
  actions:
    - name: callA16220Action
      actions: [EC: false 呼叫 A16220]
    - name: gateA16220Result         # 🆕 第二個 action:通用閘門
      functionRef:
        refName: failureSignal
        arguments:
          stepName: "CallA16220State"
          excluded: '${ .a16220Result.code != "100" }'   # ← 判定式參數化
          businessCode: '${ .a16220Result.code }'
      actionDataFilter:
        useResults: false             # 不污染 state data
  onErrors:
    - errorRef: businessStepFailed     # 🆕 觸發閘門拋出的錯誤
      transition:
        compensate: true
        nextState: CheckCompensationResult
```

**`FailureSignal` 服務定義**:
```yaml
functions:
  - name: failureSignal
    operation: 'service:com.example.transfer.workflow.FailureSignal::raiseIfExcluded'
    # 全專案共用:不寫死成功碼;判斷式由 state 端 excluded jq 承載
    # Java 端僅在被指示排除時拋 BusinessStepFailedException
```

**優勢**:
| 面向 | Saga2 | Saga4 |
|---|---|---|
| 成功碼規則 | 寫死在 switch `condition` | **參數化在 `excluded` jq**,workflow 端可調 |
| 跨工作流重用 | 每個工作流重寫 `code == "100"` | `FailureSignal` 全專案共用,改成功碼只需改 `excluded` |
| Java 端耦合 | 0(無業務失敗例外) | 0(FailureSignal 是通用閘門,Java 只負責拋) |
| 判定時機 | 在下一個 switch 內 | **在 forward state 結束前(action 階段)** → 引擎視角「state 失敗」,自動排除其補償 |

> **Saga4 的關鍵抽象**:`FailureSignal` 把「業務失敗」提升為與「平台錯誤」同等地位 —— 都是 forward state 的失敗,都會被引擎識別並排除 `compensatedBy`。

---

### 4.3 單/全補償區分:兩條平行鏈 → 引擎自動判斷

#### Saga2:兩條手動 Rollback 鏈

```
全補償路徑:                          單補償路徑:
  DecideByEvaluation(default)          CheckA16220Result(default)
        ↓                                  ↓
  RollbackA16220                       RollbackA16229Only
        ↓                                  ↓
  RollbackA16229                       CheckRollbackA16229OnlyResult
        ↓                                  ↓
  CheckRollbackResults                 InjectRolledBackOnlyStatus
        ↓
  InjectRolledBackStatus
```

兩條鏈**完全平行且重複** Rollback 動作。

#### Saga4:引擎按 forward state 成功狀態自動決定

```
補償觸發點:
  DecideByEvaluation(default)
  CheckA16220Result(default)
  CallA16220State(businessStepFailed or platformError)
        ↓ (compensate: true)
     [引擎介入]
        ├─ 若 A16229 forward 成功 且 A16220 forward 失敗:
        │      → 僅調度 CompensateA16229(CompensateA16220 自動排除)
        │
        └─ 若 A16229 與 A16220 forward 都成功:
               → 依完成順序逆序:CompensateA16220 → CompensateA16229
        ↓
  CheckCompensationResult(用 a16220Rollback==null 區分流動)
        ├─ 兩者皆 100 → InjectRolledBackStatus
        ├─ 僅 A16229 100 → InjectRolledBackOnlyStatus
        └─ 其他 → InjectRollbackFailedStatus
```

**判斷依據**(`CheckCompensationResult`):
```yaml
dataConditions:
  - name: lifoCompensationSuccess
    condition: '${ .a16220Rollback != null and .a16220Rollback.code == "100" and .a16229Rollback.code == "100" }'
    transition: InjectRolledBackStatus
  - name: singleCompensationSuccess
    condition: '${ .a16220Rollback == null and .a16229Rollback.code == "100" }'
    transition: InjectRolledBackOnlyStatus
defaultCondition:
  transition: InjectRollbackFailedStatus
```

> **Saga4 的魔法**:`FailureSignal` 拋錯讓 forward state 被引擎標記為「失敗」,其 `compensatedBy` 即被排除 —— 「僅補償真正成功的步驟」由引擎保證,不再需要寫 `RollbackA16229Only` 副本。

---

### 4.4 終點設計:單終點 → 雙終點(正常 + 兜底)

#### Saga2:`FinalAuditAndEnd` 無 onErrors

```yaml
- name: FinalAuditAndEnd
  type: operation
  # 無 onErrors → 若 audit service 拋例外,workflow 直接終止,輸出丟失
  actions: [saveAuditLog, raiseOpsAlert]
```

**風險**:`actionExecTimeout` / `stateExecTimeout` 中斷或 jq 評估錯誤可能拋 `platformError`,此時 workflow 無終態輸出。

#### Saga4:`FinalAuditAndEnd` + `FinalAuditFallbackAndEnd`

```yaml
- name: FinalAuditAndEnd
  type: operation
  onErrors:                            # 🆕 audit 階段錯誤有兜底
    - errorRef: platformError
      transition: FinalAuditFallbackAndEnd
  actions: [saveAuditLog, raiseOpsAlert]

- name: FinalAuditFallbackAndEnd        # 🆕 兜底終點
  type: inject                         # 純 Inject,不呼叫外部服務
  data:
    auditFallback: true
  stateDataFilter:
    output: |                          # 完整 9 欄位輸出模板
      {
        status: .finalStatus,
        message: .finalMessage,
        AMT: .AMT,
        a16229Result: (.a16229Result // null),
        a16220Result: (.a16220Result // null),
        a16229Rollback: (.a16229Rollback // null),
        a16220Rollback: (.a16220Rollback // null),
        auditSaved: false,             # 誠實標示 audit 失敗
        opsAlertRaised: false
      }
  end: true
```

**Saga4 設計原則**:
| 原則 | 說明 |
|---|---|
| 唯一正常終點 | `FinalAuditAndEnd` |
| 唯一異常兜底終點 | `FinalAuditFallbackAndEnd`(僅由前者 onErrors 到達) |
| 不二次拋錯 | Fallback 用 `inject`(不呼叫外部服務),保證不會再拋 `platformError` |
| 誠實輸出 | `auditSaved: false / opsAlertRaised: false`,不靜默丟失 |

---

### 4.5 錯誤定義:1 個 → 2 個

#### Saga2:`platformError` only
```yaml
errors:
  - name: platformError
    code: 'PLATFORM_ERROR'
    description: 平台層非預期錯誤
```

#### Saga4:`platformError` + `businessStepFailed`
```yaml
errors:
  - name: platformError
    code: 'PLATFORM_ERROR'
    description: 平台層非預期錯誤
  # 🆕 業務步驟失敗(FailureSignal 拋出)
  - name: businessStepFailed
    code: 'com.example.transfer.workflow.BusinessStepFailedException'
    description: 業務結果非成功碼 (code != "100"),排除該步驟補償
```

**關鍵**:`code` 是 Java 例外 **FQCN**,供引擎映射 Java Throwable → workflow error。

---

### 4.6 Functions 區塊:3 個 → 4 個

| Function | Saga2 | Saga4 |
|---|---|---|
| `callApiViaOpenAPI` | ✅ | ✅(相同) |
| `recordAuditLog` | ✅ | ✅(相同) |
| `notifyOps` | ✅ | ✅(相同) |
| `failureSignal` | ❌ | 🆕 `service:com.example.transfer.workflow.FailureSignal::raiseIfExcluded` |

> `failureSignal` 是 Saga4 的關鍵新增,但**僅做「排除訊號」動作**,業務成功碼判斷仍由 `excluded` jq 承載 —— Java 端與業務規則解耦。

---

### 4.7 onErrors 與 transition:從「轉移目標」升級為「轉移 + 補償指令」

Saga4 在多處使用 SW 0.8 標準的 `compensate: true` transition 語法:

```yaml
# Saga4 範例(DecideByEvaluation default)
defaultCondition:
  transition:
    compensate: true                # 🆕 補償指令
    nextState: CheckCompensationResult
```

**Saga2 等價寫法**:
```yaml
defaultCondition:
  transition: RollbackA16220        # 手動接補償鏈第一步
```

**對比**:

| 維度 | Saga2 `transition: Xxx` | Saga4 `transition: { compensate: true, nextState: Yyy }` |
|---|---|---|
| 補償啟動 | 開發者寫出完整補償鏈 | 一行 `compensate: true` 引擎全包 |
| 補償範圍 | 寫死(全鏈 / 單鏈) | 引擎根據 forward state 成功狀態自動決定 |
| 對 SW 規範 | 自定義 | 標準 |
| 維護成本 | 加步驟要改多處 | 加步驟只改 forward state |

---

## 五、行為等價性速查表(給 reviewer)

| 場景 | Saga2 路徑 | Saga4 路徑 | 輸出等價? |
|---|---|---|---|
| 輸入欄位失敗 | `InjectValidationFailedStatus` → `FinalAuditAndEnd` | 完全相同 | ✅ |
| A16229 失敗(code≠100) | `CheckA16229Result(default)` → `InjectFailedStatus` | 完全相同 | ✅ |
| A16220 業務失敗(僅回沖 A16229) | `CheckA16220Result(default)` → `RollbackA16229Only` → `CheckRollbackA16229OnlyResult` → `InjectRolledBackOnlyStatus` | `gateA16220Result` 拋錯 → onErrors(businessStepFailed) → `compensate: true` → 引擎僅調度 `CompensateA16229` → `CheckCompensationResult(singleCompensationSuccess)` → `InjectRolledBackOnlyStatus` | ✅ |
| 兩階段成功 + AMT≤500 | `DecideByEvaluation(successPath)` → `InjectSuccessStatus` | 完全相同 | ✅ |
| 兩階段成功 + AMT>500(全回沖) | `DecideByEvaluation(default)` → `RollbackA16220` → `RollbackA16229` → `CheckRollbackResults` → `InjectRolledBackStatus` | `DecideByEvaluation(default)` → `compensate: true` → 引擎逆序調度 `CompensateA16220 → CompensateA16229` → `CheckCompensationResult(lifoCompensationSuccess)` → `InjectRolledBackStatus` | ✅ |
| A16220 platformError | `CallA16220State.onErrors(platformError)` → `RollbackA16229Only` | `CallA16220State.onErrors(platformError)` → `compensate: true` → 引擎僅調度 `CompensateA16229` | ✅ |
| A16220 階段任何錯誤 → 全回沖(LIFO) | `DecideByEvaluation.default/onErrors(platformError)` | `DecideByEvaluation.default/onErrors(platformError)` → `compensate: true` | ✅ |
| 任一回沖失敗 | `InjectRollbackFailedStatus` → `FinalAuditAndEnd` | 完全相同 | ✅ |
| audit service 階段錯誤 | 無兜底,輸出丟失 | `FinalAuditAndEnd.onErrors` → `FinalAuditFallbackAndEnd`,輸出仍 9 欄位但 `auditSaved: false` | 🆕 **Saga4 更安全** |
| 輸出 JSON schema | 9 欄位 | 9 欄位 | ✅ |

---

## 六、Saga4 的關鍵設計哲學(Saga2 沒有的)

### 6.1 規範合規(SW 0.8 §Defining Compensation)

Saga4 嚴格遵守 SW 0.8 規範的補償語義:
- 補償 state 必須 `usedForCompensation: true`
- 不得被主流程直接 transition 進入(僅引擎調度)
- 補償 state 不可為 event state、不可定義 end、不可再設 compensatedBy
- forward state 用 `compensatedBy` 宣告

### 6.2 業務失敗的「一等公民」化

Saga2 把業務失敗視為 switch 的「default 兜底」,間接表達;
Saga4 把業務失敗提升為與 platformError 同等地位:
- 有專屬 error 定義(`businessStepFailed`)
- 有專屬 Java 例外(`BusinessStepFailedException`)
- 有專屬閘門服務(`FailureSignal`)
- 引擎可識別並自動排除其 `compensatedBy`

### 6.3 參數化解耦

Saga2 把成功碼 `"100"` 寫死在 workflow 的多個 `condition` 內;
Saga4 把成功碼規則抽到 `excluded` jq 參數,跨工作流改成功碼只需改 jq,Java 端零修改。

### 6.4 終點雙軌制

Saga2 只有一個終點,audit 階段錯誤會丟失輸出;
Saga4 雙終點(正常 + 兜底),保證「任何例外皆有終態輸出」。

---

## 七、Saga2 vs Saga3 vs Saga4 — 三條遷移路徑對比

| 維度 | Saga2 v2.2.0 | Saga3 v1.0.0 | Saga4 v1.0.0 |
|---|---|---|---|
| State 總數 | 18 | 15(−3) | 17(−1) |
| 補償模型 | 手動 Rollback 鏈 | 手動 Rollback 鏈(已合併) | **SW 標準 compensatedBy** |
| 業務失敗判定 | switch default | switch default(已合併) | **FailureSignal 閘門** |
| 終點 | 單終點 | 單終點 | **雙終點(兜底)** |
| 切換成功碼成本 | 改多處 workflow | 改多處 workflow | **只改 `excluded` jq** |
| 規範合規 | 自定義 | 自定義 | **SW 0.8 標準** |
| 設計動機 | 可靠性強化 | **可讀性 / 精簡** | **合規性 / 可維護性** |
| 適用情境 | 穩定樣板 | 想精簡的團隊 | 想合規的團隊 / 跨工作流共用 |

> **Saga3 與 Saga4 是兩條平行路徑**:
> - 想要 **state 更少、可讀性更高** → Saga3
> - 想要 **規範合規、Java 解耦、跨工作流可重用** → Saga4
> - 兩者**對外契約(輸出、finalStatus)完全一致**

---

## 八、從 Saga2 升級到 Saga4 的注意事項

### 8.1 對外契約:零變更

- HTTP API 介面、9 欄位輸出 schema、finalStatus 列舉值(`SUCCESS / FAILED / VALIDATION_FAILED / ROLLED_BACK / ROLLBACK_FAILED`)完全一致
- 業務流程呼叫端**無需任何修改**

### 8.2 需要新增的 Java 程式碼

| 元件 | Saga2 | Saga4 | 必要性 |
|---|---|---|---|
| `BusinessStepFailedException` | ❌ | ✅ 必須新增 | 對應 `errors.businessStepFailed.code` |
| `FailureSignal.raiseIfExcluded` | ❌ | ✅ 必須新增 | 對應 `functions.failureSignal` |
| `MyOpenApiService.callOpenApi` | ✅ | ✅(沿用) | 0 |
| `AuditLogService.saveLog` | ✅ | ✅(沿用) | 0 |
| `OpsAlertService.raise` | ✅ | ✅(沿用) | 0 |

> **Saga4 的設計要求 Java 端新增兩個類別**,但這兩個類別是**全專案通用元件**,其他 workflow 可共用。

### 8.3 行為差異點(罕見但需注意)

| 點 | Saga2 | Saga4 | 影響 |
|---|---|---|---|
| audit service 超時/錯誤 | 輸出丟失 | 走 `FinalAuditFallbackAndEnd`,`auditSaved: false` | Saga4 更安全,但若監控依賴 `auditSaved=true` 需更新告警 |
| 業務失敗判定時機 | 在下一個 switch 內 | 在 forward state action 階段 | 引擎視角下,Saga4 的 forward state 會被標記為「失敗」,這對 `compensatedBy` 排除至關重要 |
| 補償 state 名稱 | `RollbackA16220 / RollbackA16229` | `CompensateA16220 / CompensateA16229` | 若監控/日誌有針對 state 名稱的告警規則,需同步更新 |

---

## 九、總結

> **Saga4 v1.0.0 是 Saga2 v2.2.0 的「架構合規版」**,把補償語法從「手寫 transition 鏈」升級為「SW 標準 `compensatedBy`」,把業務失敗判定從「switch default」升級為「`FailureSignal` 閘門 + 參數化 jq」,並新增「雙終點兜底」設計。
>
> **對外契約零變更**,但需要 Java 端新增兩個通用元件(`BusinessStepFailedException` + `FailureSignal`)。
>
> 如果你的團隊**重視 SW 規範合規 / Java 與業務規則解耦 / 跨工作流可重用**,選 Saga4;
> 如果只想要**結構精簡可讀**,Saga3 是更輕量的選擇。
