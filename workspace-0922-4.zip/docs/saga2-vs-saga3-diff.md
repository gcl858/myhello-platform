# Saga2 vs Saga3 Transfer Workflow 差異分析

> 對標檔案:
> - `project/domain-transfer/transfer-workflow/src/main/resources/saga2-transfer-workflow.sw.yaml`(v2.2.0,447 行,18 個 State)
> - `project/domain-transfer/transfer-workflow/src/main/resources/saga3-transfer-workflow.sw.yaml`(v1.0.0,338 行,15 個 State)

---

## 一、TL;DR

Saga3 是 **Saga2 v2.2.0 的精簡重構版**,兩者**業務語意完全等價**(同樣兩階段轉帳 + Saga LIFO 補償),但 Saga3 把 **18 個 State 精簡為 15 個,核心業務/決策狀態從 11 個壓到 8 個**,主要靠三組合併:

| 合併項 | Saga2(v2.2.0) | Saga3(v1.0.0) |
|---|---|---|
| 階段 2 結果檢查 + 業務決策 | `CheckA16220Result` + `DecideByEvaluation`(2 個) | `CheckA16220AndEvaluate`(1 個) |
| A16229 回沖(全/單) | `RollbackA16229` + `RollbackA16229Only`(2 個) | `RollbackA16229`(1 個) |
| 回沖結果檢查(全/單) | `CheckRollbackResults` + `CheckRollbackA16229OnlyResult`(2 個) | `CheckRollbackResult`(1 個) |

> **關鍵不變項**:錯誤兜底(`platformError` + `onErrors`)、四層 timeouts、`MyOpenApiService` 服務調用、統一終點 `FinalAuditAndEnd`(寫 AuditLog + OpsAlert)、`metadata`、`workflowExecTimeout: PT5M`、`stateDataFilter.output` 輸出結構,均完全保留。

---

## 二、版本與元資料差異

| 項目 | Saga2 v2.2.0 | Saga3 v1.0.0 |
|---|---|---|
| `id` | `saga2-transfer-workflow` | `saga3-transfer-workflow` |
| `version` | `2.2.0`(從 2.0 演進而來) | `1.0.0`(全新重構,語意對齊 2.2.0) |
| `name` | Saga2 Transfer Workflow | Saga3 Transfer Workflow |
| `metadata` | `domain/pattern/criticality/owner` 四項 | 完全相同 |
| 變更註記 | 內嵌 v2.1.0 / v2.2.0 兩段歷史 | 內嵌「相對 saga2 v2.2.0 的精簡變更」六點 |
| 冪等性註記 | 詳細說明:未內建去重 + 建議在 Gateway/業務層處理 | 簡化版本:僅一句建議 |

> Saga3 把版本號重置為 `1.0.0`,表示這是一個**全新的精簡樣板**,而不是 Saga2 的下一個 patch。但從 `description` 自述可知,其語意基線對齊 Saga2 v2.2.0。

---

## 三、State 數量與結構對比

### 3.1 總覽對比圖

```
                    Saga2 v2.2.0 (18 states)                  Saga3 v1.0.0 (15 states)
                    ─────────────────────────                  ─────────────────────────
  階段 0            ValidateInput                       ┐     ValidateInput
  階段 1            CallA16229State                     │     CallA16229State
                    CheckA16229Result                   │     CheckA16229Result
  階段 2            CallA16220State                     │     CallA16220State
                    CheckA16220Result ─┐                │     CheckA16220AndEvaluate  ← 合併
                    DecideByEvaluation ┘ 合併            │
                                              ────────────────────►
  LIFO 回沖         RollbackA16220                      │     RollbackA16220
                    RollbackA16229 ─┐                   │     RollbackA16229        ← 合併
                    RollbackA16229Only ┘ 合併            │     (共用)
                                              ────────────────────►
  回沖結果檢查      CheckRollbackResults ─┐              │     CheckRollbackResult    ← 合併
                    CheckRollbackA16229OnlyResult ┘      │     (以 a16220Rollback==null 區分單/全)
                                              ────────────────────►
  Inject × 6        InjectValidationFailedStatus        │     InjectValidationFailedStatus
                    InjectSuccessStatus                 │     InjectSuccessStatus
                    InjectFailedStatus                  │     InjectFailedStatus
                    InjectRolledBackStatus              │     InjectRolledBackStatus
                    InjectRolledBackOnlyStatus          │     InjectRolledBackOnlyStatus
                    InjectRollbackFailedStatus          │     InjectRollbackFailedStatus
  統一終點          FinalAuditAndEnd                    ┘     FinalAuditAndEnd
```

### 3.2 數量明細

| 類別 | Saga2 | Saga3 | 差異 |
|---|---:|---:|---:|
| 核心業務/決策狀態(operation + switch) | 11 | **8** | −3 |
| Inject 狀態 | 6 | 6 | 0 |
| 統一終點 | 1 | 1 | 0 |
| **合計** | **18** | **15** | **−3** |

> Saga3 的 `description` 寫「從 18 個 State 降至 8 個核心業務/決策狀態」,其「8」= 11 − 3(合併掉 3 個),與本表一致。

---

## 四、逐項差異詳解

### 4.1 階段 2 決策合併:`CheckA16220Result + DecideByEvaluation` → `CheckA16220AndEvaluate`

#### Saga2(兩個 state 串接)
```
CallA16220State → CheckA16220Result → DecideByEvaluation → InjectSuccessStatus | RollbackA16220
```

`CheckA16220Result`(只檢查 A16220 結果):
```yaml
dataConditions:
  - name: a16220Success
    condition: '${ .a16220Result.code == "100" }'
    transition: DecideByEvaluation
defaultCondition:
  transition: RollbackA16229Only
```

`DecideByEvaluation`(只看 AMT):
```yaml
dataConditions:
  - name: successPath
    condition: '${ .AMT <= 500 }'
    transition: InjectSuccessStatus
defaultCondition:
  transition: RollbackA16220
```

#### Saga3(單一合併 state)
```yaml
- name: CheckA16220AndEvaluate
  type: switch
  onErrors:
    - errorRef: platformError
      transition: RollbackA16220
  dataConditions:
    - name: transferSuccess
      condition: '${ .a16220Result.code == "100" and .AMT <= 500 }'
      transition: InjectSuccessStatus
    - name: exceedAmountLimitRollbackBoth
      condition: '${ .a16220Result.code == "100" and .AMT > 500 }'
      transition: RollbackA16220
  defaultCondition:
    transition: RollbackA16229
```

**差異重點**:

| 面向 | Saga2 | Saga3 |
|---|---|---|
| 條件表達式 | 分兩個 switch,A16220 結果與 AMT 分開判讀 | 單一 switch,兩個 `dataConditions` 同時檢查 `code` 與 `AMT` |
| 路徑分支 | 4 條(成功/失敗 × 小額/超額) | 3 條(成功小額/成功超額/失敗 default) |
| `exceedAmountLimitRollbackBoth` 條件 | 不存在(超額統一走 default→RollbackA16220) | 顯式列出(`code=="100" and .AMT>500`→RollbackA16220) |
| 風格 | 「fail-fast default」:只列成功,其他全 default | 「正反向並列 + default」:成功小額、超額各自顯式,只有 A16220 失敗落 default |

> 行為完全等價,但 Saga3 把決策表攤平,讀者一眼就能看到三條出口。

---

### 4.2 A16229 回沖合併:`RollbackA16229 + RollbackA16229Only` → 共用 `RollbackA16229`

#### Saga2(兩個一模一樣的 operation state)

`RollbackA16229`(LIFO 第二步,從 RollbackA16220 來):
```yaml
- name: RollbackA16229
  actions:
    - functionRef:
        refName: callApiViaOpenAPI
        arguments:
          schemaRef: 'specs/A16229-api.yaml#executeA16229'
          payload: { Account_A, AMT, EC: true }
      actionDataFilter:
        toStateData: '${ .a16229Rollback }'
  transition: CheckRollbackResults
```

`RollbackA16229Only`(A16220 失敗時的單退):
```yaml
- name: RollbackA16229Only
  actions: ...完全相同的 payload / schemaRef / actionDataFilter...
  transition: CheckRollbackA16229OnlyResult
```

兩者**唯一差異**是 `transition`(後接不同的檢查節點)。

#### Saga3(單一共用 state)
```yaml
- name: RollbackA16229
  actions:
    - ...同 Saga2 的 action 內容...
  transition: CheckRollbackResult     # 不管從哪條路進來,統一接 CheckRollbackResult
```

**差異重點**:
- 刪除重複 state(`RollbackA16229Only`),所有 A16229 回沖共用同一節點
- Saga2 用「不同 transition」區分單退/全退;Saga3 用「進入 CheckRollbackResult 時 `a16220Rollback` 是否為 null」來區分(見 4.3)
- 程式碼/工作流定義都少了一份維護負擔

---

### 4.3 回沖結果檢查合併:`CheckRollbackResults + CheckRollbackA16229OnlyResult` → 共用 `CheckRollbackResult`

#### Saga2(兩個檢查 state)

`CheckRollbackResults`(LIFO 全回沖路徑用):
```yaml
dataConditions:
  - name: anyRollbackFailed
    condition: '${ .a16229Rollback.code != "100" or .a16220Rollback.code != "100" }'
    transition: InjectRollbackFailedStatus
defaultCondition:
  transition: InjectRolledBackStatus
```

`CheckRollbackA16229OnlyResult`(單退路徑用):
```yaml
dataConditions:
  - name: rollbackSuccess
    condition: '${ .a16229Rollback.code == "100" }'
    transition: InjectRolledBackOnlyStatus
defaultCondition:
  transition: InjectRollbackFailedStatus
```

#### Saga3(單一合併 state)
```yaml
- name: CheckRollbackResult
  dataConditions:
    - name: lifoRollbackSuccess
      condition: '${ .a16220Rollback != null and .a16220Rollback.code == "100" and .a16229Rollback.code == "100" }'
      transition: InjectRolledBackStatus
    - name: singleRollbackSuccess
      condition: '${ .a16220Rollback == null and .a16229Rollback.code == "100" }'
      transition: InjectRolledBackOnlyStatus
  defaultCondition:
    transition: InjectRollbackFailedStatus
```

**差異重點**:

| 面向 | Saga2 | Saga3 |
|---|---|---|
| 區分單/全回沖的方式 | 用**不同 state 進入** | 用**同一 state 內 `a16220Rollback == null` 判斷** |
| LIFO 成功條件 | default 兜底(沒顯式列) | 顯式列:`a16220Rollback != null and code=="100"` |
| 單退成功條件 | 顯式列:`a16229Rollback.code == "100"` | 顯式列:`a16220Rollback == null and .a16229Rollback.code == "100"` |
| 失敗處理 | 「任一回沖失敗」顯式條件 | 一切非成功路徑(包含任一回沖失敗)落入 default |
| 風格 | fail-fast default(僅列失敗) | P2-1 正向防禦(僅列成功,異常落 default) |

> 兩種寫法在**正常路徑上行為完全等價**,但 Saga3 的寫法在 `a16220Rollback` 為 null 時,**主動短路**避免對 null 取 `.code` 拋 jq 例外 —— 這是更安全的設計。

---

### 4.4 輸入驗證重寫:`ValidateInput`

#### Saga2(多條獨立 dataConditions,每條對應一種錯誤)
```yaml
dataConditions:
  - name: accountAInvalid
    condition: '${ ((.Account_A // "") | match("^[A-Za-z0-9_]+$") // false) == false }'
    transition: InjectValidationFailedStatus
  - name: accountBInvalid
    condition: '${ ((.Account_B // "") | match("^[A-Za-z0-9_]+$") // false) == false }'
    transition: InjectValidationFailedStatus
  - name: amtInvalid
    condition: '${ .AMT | type != "number" }'
    transition: InjectValidationFailedStatus
  - name: amtNotPositive
    condition: '${ .AMT <= 0 }'
    transition: InjectValidationFailedStatus
  - name: sameAccount
    condition: '${ .Account_A == .Account_B }'
    transition: InjectValidationFailedStatus
defaultCondition:
  transition: CallA16229State
```

#### Saga3(單一正向複合條件)
```yaml
dataConditions:
  - name: inputValid
    condition: '${ (((.Account_A // "") | match("^[A-Za-z0-9_]+$") // false) != false) and (((.Account_B // "") | match("^[A-Za-z0-9_]+$") // false) != false) and (.Account_A != .Account_B) and (.AMT | type == "number") and (.AMT > 0) }'
    transition: CallA16229State
defaultCondition:
  transition: InjectValidationFailedStatus
```

**差異重點**:

| 面向 | Saga2 | Saga3 |
|---|---|---|
| 樣式 | 「負向列舉」:5 條獨立失敗條件 | 「正向單條」:1 條複合成功條件 |
| 條件方向 | 列舉各類失敗,成功走 default | 顯式列出成功條件,失敗(含 null/格式/同帳號/非正數)走 default |
| 風格 | 細粒度錯誤分類(但其實所有失敗共用同一個 `InjectValidationFailedStatus`) | P2-1 正向防禦 |
| 行為等價 | ✅ | ✅(任何不符合條件都落入 `InjectValidationFailedStatus`) |
| 可讀性 | 中:5 條條件獨立清楚,但樣板冗長 | 高:一條 `and` 連接,所有規則一目了然 |
| 維護性 | 加新規則需複製整個 `dataConditions` block | 加新規則只需在複合 `and` 後加一段 |

> Saga3 用一條 `and` 把 5 條規則摺成 1 條。對齊 Saga2 自家 P2-1 慣例(只在 switch 列正向條件)。

---

### 4.5 onErrors 與錯誤兜底

#### 兩者完全保留一致的錯誤收斂策略

| State | platformError 兜底目標 |
|---|---|
| `ValidateInput` | `InjectValidationFailedStatus` |
| `CallA16229State` | `InjectFailedStatus`(A16229 尚未扣款,直接收尾) |
| `CheckA16229Result` | `InjectFailedStatus` |
| `CallA16220State` | **`RollbackA16229`**(A16229 已扣款,必須補償) |
| `CheckA16220Result` *(Saga2)* / `CheckA16220AndEvaluate` *(Saga3)* | `RollbackA16220` |
| `DecideByEvaluation` *(Saga2)* | `RollbackA16220` |
| `RollbackA16220` | `InjectRollbackFailedStatus` |
| `RollbackA16229` | `InjectRollbackFailedStatus` |
| `RollbackA16229Only` *(Saga2)* | `InjectRollbackFailedStatus` |
| `CheckRollbackResults` *(Saga2)* | `InjectRollbackFailedStatus` |
| `CheckRollbackA16229OnlyResult` *(Saga2)* / `CheckRollbackResult` *(Saga3)* | `InjectRollbackFailedStatus` |
| `FinalAuditAndEnd` | **(無 onErrors)** —— AuditLogService 自行吞例外,失敗以 `auditSaved=false` 浮現 |

> **不變項**:兩者對「哪個 state 出錯該走哪條補償路徑」的設計完全一致,這是 Saga 補償的關鍵正本,Saga3 沒有動。

---

### 4.6 timeouts 四層防線

| 層級 | Saga2 | Saga3 |
|---|---|---|
| `workflowExecTimeout` | `PT5M` | `PT5M` |
| `CallA16229State` action | `PT15S` / state `PT30S` | `PT15S` / state `PT30S` |
| `CallA16220State` action | `PT15S` / state `PT30S` | `PT15S` / state `PT30S` |
| 回沖 operation 各 state | `PT15S` / `PT30S` | `PT15S` / `PT30S` |
| `FinalAuditAndEnd` action | `PT10S` / state `PT20S` | `PT10S` / state `PT20S` |

> **完全相同**。Saga3 嚴格繼承 Saga2 的逾時設計哲學:operation timeout(15s) > MyOpenApiService HTTP 預設 timeout(10s),確保服務層先回標準化錯誤而非引擎層中斷。

---

### 4.7 Functions 與 Errors 區塊

| 區塊 | Saga2 | Saga3 |
|---|---|---|
| `errors.platformError` | ✅ 定義相同 | ✅ 定義相同 |
| `functions.callApiViaOpenAPI` | ✅ `service:com.example.transfer.workflow.MyOpenApiService::callOpenApi` | ✅ 完全相同 |
| `functions.recordAuditLog` | ✅ `service:com.example.reconciliation.AuditLogService::saveLog` | ✅ 完全相同 |
| `functions.notifyOps` | ✅ `service:com.example.reconciliation.OpsAlertService::raise` | ✅ 完全相同 |

> **完全相同**。Saga3 沒有引入新的服務或錯誤定義,純粹是 state 層級的重構。

---

### 4.8 FinalAuditAndEnd 終點

| 面向 | Saga2 | Saga3 |
|---|---|---|
| `workflowId` | `"saga2-transfer-workflow"` | `"saga3-transfer-workflow"` |
| `AuditLog` 寫入欄位 | inputData × 3 + outputData × 7 | 完全相同 |
| `raiseOpsAlertIfRequired` | 存在,`workflowId` 不同 | 完全相同 |
| `stateDataFilter.output` 模板 | 9 個欄位:`status / message / AMT / a16229Result / a16220Result / a16229Rollback / a16220Rollback / auditSaved / opsAlertRaised` | **完全相同** |

> 輸出 schema **完全一致**,表示對 API 消費者而言兩者介面等價(僅 workflowId 字串不同)。

---

## 五、Saga2 的「歷史註記」vs Saga3 的「精簡聲明」

### 5.1 Saga2 v2.2.0 description 中內嵌的歷史變更

```yaml
v2.1.0 變更 (可靠性強化):
  - 新增 errors.platformError 兜底定義
  - operation state 加 actionExecTimeout/stateExecTimeout 短防線
  - ValidateInput 強化:null-safety、AMT > 0、禁止同帳號
  - MyOpenApiService 回應新增 errorType
  - 輸出新增 auditSaved 欄位

v2.2.0 變更 (樣板精煉):
  - 新增 workflow metadata (domain/pattern/criticality/owner)
  - switch 條件精簡:僅保留正向條件 + 安全 default
  - 統一終點新增 OpsAlertService 條件告警
```

### 5.2 Saga3 v1.0.0 description 中的精簡聲明

```yaml
架構優化與精簡變更 (相較於 saga2 v2.2.0):
  1. 狀態深度精簡:從 18 個 State 降至 8 個核心業務/決策狀態
  2. 回沖邏輯消除重複:合併 RollbackA16229Only 與 RollbackA16229 為單一共用節點
  3. 判定合併:CheckA16220Result + DecideByEvaluation → CheckA16220AndEvaluate
  4. 回沖統一判定:CheckRollbackResult 統一處理全回沖與單階段回沖結果
  5. 輸入驗證遵從 P2-1 正向防禦:單一正向條件判定
  6. 維持嚴謹防線:完整保留四層 timeouts、platformError 兜底與統一終點 AuditLog 落地
```

> 兩者**保留了 Saga2 自 v2.1.0 起累積的所有可靠性強化**(platformError / 四層 timeouts / auditSaved / OpsAlert),Saga3 只做**結構層級**精簡,**沒有任何業務語意變更或可靠性降級**。

---

## 六、行為差異速查表(給 reviewer)

| 場景 | Saga2 行為 | Saga3 行為 | 等價? |
|---|---|---|---|
| 輸入欄位缺失/格式錯/同帳號/AMT≤0 | 落入 `InjectValidationFailedStatus` | 落入 `InjectValidationFailedStatus` | ✅ |
| A16229 失敗(code≠100 或 transport 錯) | `InjectFailedStatus` | `InjectFailedStatus` | ✅ |
| A16220 失敗(僅回沖 A16229) | `RollbackA16229Only` → `CheckRollbackA16229OnlyResult` → 成功→`InjectRolledBackOnlyStatus` | `RollbackA16229` → `CheckRollbackResult`(以 `a16220Rollback==null` 識別單退)→ 成功→`InjectRolledBackOnlyStatus` | ✅ |
| 兩階段成功 + AMT≤500 | `CheckA16220Result → DecideByEvaluation(successPath)` → `InjectSuccessStatus` | `CheckA16220AndEvaluate(transferSuccess)` → `InjectSuccessStatus` | ✅ |
| 兩階段成功 + AMT>500(全回沖) | `CheckA16220Result → DecideByEvaluation(default)` → `RollbackA16220` → `RollbackA16229` → `CheckRollbackResults` → `InjectRolledBackStatus` | `CheckA16220AndEvaluate(exceedAmountLimitRollbackBoth)` → `RollbackA16220` → `RollbackA16229` → `CheckRollbackResult(lifoRollbackSuccess)` → `InjectRolledBackStatus` | ✅ |
| 任意回沖失敗 | 落入 `InjectRollbackFailedStatus` | 落入 `InjectRollbackFailedStatus` | ✅ |
| `platformError`(state timeout / 引擎例外) | 透過 `onErrors` 收斂到對應終點 | 透過 `onErrors` 收斂到對應終點 | ✅ |
| AuditLog 寫入 + OpsAlert 觸發 | `FinalAuditAndEnd` 統一處理 | `FinalAuditAndEnd` 統一處理 | ✅ |
| 輸出 JSON schema | 9 個欄位 | 9 個欄位 | ✅(僅 workflowId 不同) |

---

## 七、為什麼 Saga3 比 Saga2 好(Saga3 設計動機推斷)

1. **消除冗餘**:`RollbackA16229` 與 `RollbackA16229Only` 兩個 operation state 的 action / timeouts / onErrors 完全相同,只是 `transition` 不同 —— 明顯可合併。
2. **決策扁平化**:`CheckA16220Result`(判結果)+ `DecideByEvaluation`(判金額)串接成 2 hop,Saga3 攤平成單一 switch,3 條出口一目了然。
3. **安全短路**:`CheckRollbackResult` 主動用 `a16220Rollback != null` 短路,避免對 null 取 `.code` 拋例外 —— 寫法比 Saga2 的「兩個獨立檢查 state」更安全。
4. **驗證正典化**:把 5 條負向條件折成 1 條正向 `and`,符合自家 P2-1 慣例,新規則維護成本更低。
5. **更乾淨的註解**:刪掉 Saga2 那段 20+ 行的「輸入驗證:由 workflow 內 ValidateInput 統一驗證...」自我解釋,因為 state 本身已足夠語意化。

---

## 八、總結

> **Saga3 v1.0.0 是 Saga2 v2.2.0 的純結構精簡版**,**業務語意、可靠性、輸出 schema、錯誤兜底、超時防線、AuditLog/OpsAlert 整合**均完全保留;差異僅在於把 11 個核心業務/決策 state 精簡為 8 個,並把 switch 條件樣式統一為「正向條件 + 安全 default」(P2-1 慣例)。

如果你的部署正在用 Saga2 v2.2.0,**可以無痛升級到 Saga3**(對外介面完全等價);如果還在用 Saga2 v2.1.0 之前的版本,**先升到 v2.2.0 再評估升 Saga3** 是比較保險的路徑。
