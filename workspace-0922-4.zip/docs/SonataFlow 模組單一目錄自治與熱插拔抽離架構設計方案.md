# SonataFlow 模組單一目錄自治與熱插拔抽離架構設計方案 (Decoupled Feature Architecture Plan)

本架構規劃旨在解決目前 `ai-studio/draft-digital-loan-disbursement` 仰賴 `sonataflow-integration` skill 整併時所產生的**高耦合問題**。設計目標是讓 draft 業務模組能作為**獨立的單一目錄**直接放置在 `project` 旗下（例如 `project/features/draft-digital-loan-disbursement/`），在不將檔案散落覆蓋至多個平台目錄的前提下正常編譯運行，且未來若需廢除或抽離該業務，**僅需刪除該目錄**即可乾淨解耦，不留殘留配置。

---

## 1. 現況整併模式痛點深度剖析 (Current Architecture Pain Points)

在既有架構與 `sonataflow-integration` skill (v2.0) 的 SOP 下，一個 Draft 的整併流程會將檔案徹底打散至專案的 6 個不同模組與位置：

```
draft-digital-loan-disbursement/ (原始集中狀態)
 ├── src/*.sw.yaml ───────────► domain-transfer/transfer-workflow/.../*.sw.yaml
 │                             └── distribution/transfer-app/.../*.sw.yaml (建置同步)
 ├── src/specs/internal/* ────► domain-transfer/transfer-workflow/.../specs/internal/*
 ├── src/specs/external/* ────► domain-transfer/transfer-workflow/.../specs/external/*
 ├── src/mocks/*.java ────────► dev/transfer-mock/.../org/acme/transfer/api/*.java
 ├── src/mocks/dto/*.java ────► dev/transfer-mock/.../org/acme/transfer/api/dto/*.java
 ├── src/db/*.sql ────────────► domain-reconciliation/reconciliation-api/.../db/migration/*.sql
 ├── src/config/snippet ──────► distribution/transfer-app/.../application.properties (追加字串)
 └── src/tests/*.java ────────► distribution/transfer-app/.../transfer/*.java
```

### 關鍵痛點分析：

1. **資產散落化 (Scattered Assets)**：
   - 一個貸款業務的邏輯被物理撕裂並混合在既有轉帳業務 (`domain-transfer`)、外部模擬器 (`transfer-mock`) 與對帳 API (`reconciliation-api`) 中。
   - 開發者無法從專案樹狀結構一目了然看清該業務的邊界。
2. **單一全域設定檔的侵入式編輯 (Monolithic Configuration Mutation)**：
   - `application.properties` 中 `platform.status-rewrite.workflows` 與 `platform.status-rewrite.mapping` 採單行逗號分隔（CSV）格式。
   - 每次整併都必須對既有字串進行追加；若多個 draft 並行開發，極易發生 Git 衝突；抽離時更需手動執行正則表達式或字串反向剔除，極度容易誤刪其他業務的名單。
3. **命名空間與 Mock 污染 (Mock Namespace Pollution)**：
   - 所有外部主機 Mock 與 DTO 全部被重寫 Package 強行丟進 `org.acme.transfer.api`。
   - 貸款主機（CoreLoanAccount、LoanRiskAssessment）與既有轉帳主機（A16220、A16229）混合，容易產生全域 `@Path` 衝突或 DTO 命名碰撞。
4. **資料庫遷移全域鎖定 (Global Flyway Version Contention)**：
   - SQL 直接寫死版號（如 `V1.2.7__...sql`）落入全域 `db/migration`。
   - 實體 SQLite 資料庫的 `reconciliation_schema_history` 記錄了該版本；抽離後若僅刪除 SQL 檔案，該版本號仍被 DB 視為已執行，導致其他分支無法復用或乾淨重建。
5. **抽離與維護成本極高 (High Extraction Blast Radius)**：
   - 抽離一個流程需人工或腳本跨越 6 個目錄精確搜尋並刪除 15+ 個檔案，並對設定檔做精準反向 Patch。一旦漏刪一個 Mock 類別或 DTO，就可能引發編譯報錯或孤兒端點殘留。

---

## 2. 核心架構願景與目標 (Design Goals & Invariants)

| 維度 | 目標規範 |
|---|---|
| **目錄自治性 (Directory Autonomy)** | 該業務的所有資產（Workflow、OpenAPI Spec、Mock JAX-RS、DTO、DB DDL、Config、Test）**100% 封裝於單一目錄**（如 `project/features/draft-digital-loan-disbursement`）。 |
| **正常運行 (Full Operability)** | 專案執行 `mvn clean package`、`mvn test`、`offline-build.sh`、`quarkus:dev` 時，該業務流程、動態路由、Mock 端點、狀態改寫全部正常生效。 |
| **極簡抽離 (Zero-Touch Extraction)** | 抽離時**僅需刪除該單一目錄** (`rm -rf project/features/draft-digital-loan-disbursement`)，無需手動還原 `application.properties` 或清理其他模組。再次建置即乾淨回到未安裝狀態。 |
| **零全域侵入 (Zero Global Invasiveness)** | 既有的 `domain-transfer`、`domain-reconciliation`、`dev/transfer-mock` 核心檔案保持乾淨，不作為業務暫存垃圾場。 |
| **離線建置與跨平台相容** | 兼容 Air-Gapped 離線 Maven 套件庫，支援 Linux、macOS、Windows 相對路徑。 |

---

## 3. 解決方案評估與架構決策 (Architectural Options & Decision)

針對「如何讓單一目錄下的資產被 Quarkus/SonataFlow 平台感知，同時支援刪除目錄即可抽離」，評估以下三種方案：

### 方案對比矩陣

| 評估維度 | 方案 A：Maven 動態條件子模組 (Conditional Maven Module) | 方案 B：Feature Overlay 自動裝配架構 (Convention-based Overlay) ⭐ 推薦 | 方案 C：獨立微服務分離架構 (Standalone Microservice) |
|---|---|---|---|
| **實體結構** | 每個 draft 變成一個 Maven Module (`pom.xml`)，置於 `project/features/*` | draft 保持目錄自治，由 Runnable distribution 在建置期自動探測掃描 | draft 獨立為另一個 Quarkus 應用，Port 8081 |
| **抽離難易度** | 需處理 Maven Reactor 對缺失目錄的報錯（需靠 `<profile><activation><file><exists>` 動態啟用） | **極高（僅需刪除目錄 `rm -rf`）** | 高（需維護跨服務連線、Port 管理與部署配置） |
| **Kogito 代碼生成** | 需解決 Kogito 跨 JAR 依賴掃描與 Classloader 問題 | **天然相容**（利用 `transfer-app` 既有的 resources 同步機制） | 需獨立生成，但失去平台共用 context |
| **設定檔解耦** | 需透過 MicroProfile Config SPI 聚合 | 結合通配符狀態改寫 + 目錄自動疊加 | 獨立配置 |
| **既有平台改動幅度** | 中等（需修改 parent POM 的 profile） | **極小（僅升級安全過濾器通配符 + 擴充 resources 掃描）** | 極大（架構與部署拓撲翻新） |

### 架構決策：採用【方案 B：Feature Overlay 自包含熱插拔架構】

**決策核心依據**：
1. 深入研究專案既有設計發現：`project/distribution/transfer-app/pom.xml` **本來就已經將 `src/main/resources` 視為建置暫存產物**！
   - 每次建置前，`maven-clean-plugin (clean-resources-dir)` 會自動清空 `src/main/resources` 中的 workflow 與 specs。
   - 隨後由 `maven-resources-plugin` 從 `domain-transfer/transfer-workflow` 同步資源。
2. 因此，**平台天然具備「以同步機制達成單一事實來源」的基礎**。只要將這個機制從「固定指向 `domain-transfer`」升級為「**同時自動掃描並疊加 `features/*` 目錄**」，就能實現完美的零侵入式熱插拔！

---

## 4. 推薦架構詳細設計規格 (Detailed Architecture Specification)

### 4.1 目錄佈局標準：`project/features/<feature-name>/`

將 `ai-studio/draft-digital-loan-disbursement` 直接放置於 `project/features/draft-digital-loan-disbursement`，內部保留完全自包含的標準結構：

```
project/features/draft-digital-loan-disbursement/
├── feature.yaml                        # [新增] 模組描述檔 (id, name, version, status)
├── docs/                               # 業務規格與設計文件
│   ├── README.md
│   ├── design-explanation.md
│   └── spec.md
├── workflows/                          # 工作流 YAML (所有 *.sw.yaml)
│   ├── loan_transaction.sw.yaml
│   ├── loan_disbursement.sw.yaml
│   └── loan_cancellation.sw.yaml
├── specs/                              # OpenAPI 規格 (Internal 對外 SSOT + External 被調主機)
│   ├── internal/
│   │   └── loan-transaction-api.yaml
│   └── external/
│       ├── core-deposit-credit-api.yaml
│       ├── core-loan-account-disbursement-api.yaml
│       └── risk-credit-assessment-api.yaml
├── mocks/                              # 專屬 Mock JAX-RS 與 DTO (自成 namespace)
│   ├── LoanRiskAssessmentResource.java
│   ├── CoreDepositCreditResource.java
│   ├── CoreLoanAccountResource.java
│   └── dto/
│       ├── CoreHostResponse.java
│       ├── RiskAssessmentResponse.java
│       └── ErrorDetail.java
├── db/                                 # 資料庫遷移與視圖
│   ├── migration/
│   │   └── V1.2.7__create_loan_reconciliation_view.sql
│   └── teardown.sql                    # [新增] 抽離清理腳本 (DROP VIEW IF EXISTS ...)
├── config/                             # 模組專屬配置片段
│   └── application.properties.snippet
└── tests/                              # 驗收測試案例
    └── LoanTransactionWorkflowTest.java
```

---

### 4.2 六大子機制解耦技術方案

#### 機制 1：SonataFlow 工作流與 OpenAPI 規格的自動探測與裝配 (Workflow & Spec Assembly)
- **原理**：`distribution/transfer-app/pom.xml` 在 `initialize` 階段由 `maven-resources-plugin` 進行全域資源裝配。
- **改進設計**：
  在 `transfer-app/pom.xml` 的 `resources` 複製任務中，新增對 `../../features/*/` 的動態裝配規則：
  ```xml
  <!-- 自動同步所有 features 下的工作流與規格 -->
  <execution>
      <id>sync-features-resources</id>
      <phase>initialize</phase>
      <goals><goal>copy-resources</goal></goals>
      <configuration>
          <outputDirectory>${project.basedir}/src/main/resources</outputDirectory>
          <overwrite>true</overwrite>
          <resources>
              <!-- 1. 複製所有 feature 的 workflows -->
              <resource>
                  <directory>../../features</directory>
                  <includes>
                      <include>*/workflows/*.sw.yaml</include>
                  </includes>
                  <!-- 拍平成 Kogito 要求的 root resources 或保留路徑 -->
              </resource>
              <!-- 2. 複製所有 feature 的 specs -->
              <resource>
                  <directory>../../features</directory>
                  <includes>
                      <include>*/specs/**</include>
                  </includes>
              </resource>
              <!-- 3. 複製所有 feature 的 db migration -->
              <resource>
                  <directory>../../features</directory>
                  <includes>
                      <include>*/db/migration/**</include>
                  </includes>
              </resource>
          </resources>
      </configuration>
  </execution>
  ```
- **抽離保證**：
  當執行 `rm -rf project/features/draft-digital-loan-disbursement` 後，下次建置時 `clean-resources-dir` 清空 `transfer-app/src/main/resources`，因 features 目錄已不存在，不會再有任何檔案被同步進來。**Kogito 重新編譯時自動不再生成該流程的 Process 與 REST 端點，0 行殘留！**

---

#### 機制 2：OpenAPI 動態路由自感知 (Internal OpenApi Dynamic Routing)
- **現狀**：`platform-security` 的 `InternalOpenApiDynamicRouter` 啟動時以 `Thread.currentThread().getContextClassLoader().getResources("specs/internal")` 掃描 Classpath 下的所有規格。
- **解耦效果**：
  - 特性目錄下的 `specs/internal/loan-transaction-api.yaml` 只要被同步至 `transfer-app` 的 `specs/internal/`，`InternalOpenApiDynamicRouter` 就會在啟動時自動為其註冊 `/Loan/Transaction/Execute` 等動態路由，並綁定 `x-workflow-id: loan_transaction`。
  - 當目錄被刪除，`specs/internal/loan-transaction-api.yaml` 消失，動態路由便不會註冊該端點，對外自動回應 404，無需修改任何 Router Java 程式碼！

---

#### 機制 3：Mock 服務與 DTO 的動態編譯與掛載 (Mock Resource & DTO Decoupling)
- **痛點**：舊模式強迫將 Mock 複製至 `dev/transfer-mock` 且硬改成 `org.acme.transfer.api`。
- **解耦設計**：
  - **獨立 Package 命名空間**：在 `features/draft-digital-loan-disbursement/mocks/` 中，保持獨立 package（例如 `com.example.features.loan.mock` 或 `org.acme.loan.api`），不再侵入轉帳命名空間。
  - **動態編譯掛載**：
    在 `dev/transfer-mock/pom.xml`（或 `transfer-app/pom.xml` 的 dev profile）中，利用 `build-helper-maven-plugin`（本地已存在的 3.3.0 版）動態掛載 source：
    ```xml
    <plugin>
        <groupId>org.codehaus.mojo</groupId>
        <artifactId>build-helper-maven-plugin</artifactId>
        <executions>
            <execution>
                <id>add-feature-mocks</id>
                <phase>generate-sources</phase>
                <goals><goal>add-source</goal></goals>
                <configuration>
                    <sources>
                        <!-- 動態掛載所有 feature 下的 mocks 原始碼 -->
                        <source>../../features/draft-digital-loan-disbursement/mocks</source>
                    </sources>
                </configuration>
            </execution>
        </executions>
    </plugin>
    ```
    *(註：若 features 目錄不存在，`build-helper-maven-plugin` 會直接略過，不會中斷建置；或採用建置期 initialize 腳本將 `features/*/mocks` 同步至 `transfer-mock/src/main/java-features/`)*。
  - **Quarkus CDI/JAX-RS 探測**：
    Quarkus RESTEasy Reactive 只要在編譯 Classpath 中掃描到 `@Path` 類別即會自動註冊為 HTTP 端點。

---

#### 機制 4：狀態碼改寫與設定檔解耦 (Status-Rewrite & Configuration Decoupling)
- **痛點**：`platform.status-rewrite.workflows` 每次都要硬改追加。
- **解耦改進設計（平台層極小升級）**：
  優化 `platform-security` 中的 `SonataFlowSecurityConfig.java`（僅改動 5 行）：
  ```java
  // 原程式碼: 必須嚴格命中 workflowNames 清單
  // if (workflowNames.contains(path)) { ... }
  
  // 優化後: 支援通配符 "*" 或預設自動改寫所有具備 finalStatus 的工作流
  boolean isEnabled = workflowNames.contains("*") || workflowNames.contains(path);
  if (isEnabled) {
      Object status = map.get("finalStatus");
      if (status == null) status = map.get("status");
      if (status != null && status instanceof String) {
          Integer rewrite = statusRewriteMap.get(status.toString());
          if (rewrite != null) {
              responseContext.setStatus(rewrite);
          }
      }
  }
  ```
  **效益**：
  - 將 `application.properties` 設定為 `platform.status-rewrite.workflows=*`（或預設包含所有內部工作流）。
  - 將全平台通用的狀態碼（`REJECTED_VALIDATION=400`、`ROLLBACK_FAILED=409`、`LOOKUP_FAILED=500`、`CANCEL_ROLLBACK_FAILED=409`）統一收攏在平台預設 mapping 中。
  - **所有新增的 feature 目錄，完全不需要修改全域 `application.properties`！**

---

#### 機制 5：資料庫遷移與視圖生命週期管理 (Database Migration & SQLite Lifecycle)
- **痛點**：V 版號衝突與抽離後的 DB 殘留。
- **解耦設計**：
  1. **建置期遷移檔掛載**：
     - 特性目錄下的 `db/migration/V*.sql` 在建置期同步至 `transfer-app` 的 `db/migration/`。
     - `DatabaseMigrationRunner` 啟動時自動透過 Classpath 掃描並執行。
  2. **抽離清理防護（提供 `teardown.sql`）**：
     - 特性目錄內提供 `db/teardown.sql`：
       ```sql
       DROP VIEW IF EXISTS vw_loan_alerts;
       DROP TABLE IF EXISTS loan_transaction_reconciliation;
       DELETE FROM reconciliation_schema_history WHERE script LIKE '%loan%';
       ```
     - 抽離該 feature 時，可選性執行一次 teardown 腳本，徹底恢復 DB 初始狀態，避免歷史表污染。

---

#### 機制 6：整合測試的動態掛載與自動排除 (Automated Test Lifecycle)
- **解耦設計**：
  - 測試代碼保留在 `features/draft-digital-loan-disbursement/tests/LoanTransactionWorkflowTest.java`。
  - 在 `transfer-app/pom.xml` 中，利用 `build-helper-maven-plugin:add-test-source`（或 initialize 階段同步至 `transfer-app/src/test/java/features/`）：
  - 當 feature 目錄存在時，`mvn test` 自動涵蓋該測試。
  - 當 feature 目錄被刪除時，測試原始碼同步消失，`mvn test` 依然 100% 通過，絕不因缺失類別而爆錯。

---

## 5. 未來抽離 (Uninstallation / Extraction) 標準作業程序 (SOP)

未來當 `draft-digital-loan-disbursement` 需抽離或移交時，操作者僅需執行以下兩步：

### Step 1: （可選）清理本地測試資料庫
```bash
sqlite3 project/data/reconciliation.db < project/features/draft-digital-loan-disbursement/db/teardown.sql
```

### Step 2: 物理刪除特性目錄
```bash
rm -rf project/features/draft-digital-loan-disbursement
```

### Step 3: 重新編譯驗證
```bash
mvn clean test -DskipTests
```
**結果預期**：
- `transfer-app` 的 `clean-resources-dir` 自動清除上一版本的臨時工作流與規格。
- 專案乾淨編譯成功，所有貸款端點、Mock、測試與路由完全消失，無任何殘留。

---

## 6. 與現有 `sonataflow-integration` Skill 的升級與整合方案

現有的 `sonataflow-integration` Skill (v2.0) 專注於「將草稿分散複製到既有模組」。配合本架構升級，該 Skill 可平滑升級為 **v3.0 (Feature Plug-in Architecture)**：

```
                    【舊模式 v2.0】                             【新模式 v3.0 (推薦)】
              sonataflow-integration                     sonataflow-feature-plugger
                        │                                            │
       ┌────────────────┴────────────────┐                           │
       ▼                                 ▼                           ▼
拷貝至 transfer-workflow         拷貝至 transfer-mock        整包移入 project/features/<name>
修改 application.properties      修改 Flyway SQL                    │
修改 transfer-app 測試           修改 Mock Package                   ▼
       │                                 │                   自動通過 5 大品質門禁
       ▼                                 ▼                           │
   【高耦合、抽離極難】             【變更點散落】                    ▼
                                                             平台建置期自動掃描與裝配
                                                                     │
                                                                     ▼
                                                             【單目錄自治、抽離僅需 rm】
```

1. **品質門禁前置 (Quality Gates Preserved)**：
   保留原有 Skill 的 5 大品質門禁（Gate 1 OpenAPI 自洽性、Gate 2 Mock 端點覆蓋、Gate 3 Java 服務契約、Kogito 10.2.0 hyphen bug 修正），但**直接在 feature 目錄內部進行修補，不污染外部**。
2. **雙軌相容**：
   - 既有核心業務（`saga2`、`omni-cash-transaction`）維持在 `domain-transfer`。
   - 所有新進 Draft（包括 `draft-digital-loan-disbursement`）一律採用 `features/` 獨立模組安裝。

---

## 7. 後續推動計劃 (Next Steps)

本階段為**先分析規劃、不進行實作**。待使用者審閱此架構設計並確認核可後，後續推動步驟將劃分為：

1. **Phase 1: 平台層通用支援升級 (Platform Foundation Upgrade)**
   - 於 `platform-security` 支援 `platform.status-rewrite.workflows=*` 通配符與預設 mappings。
   - 於 `distribution/transfer-app` 與 `dev/transfer-mock` 建立 `features/` 目錄的資源與原始碼動態裝配規則。
2. **Phase 2: 將 `draft-digital-loan-disbursement` 規範化移入 `features/`**
   - 將 `ai-studio/draft-digital-loan-disbursement` 整理成標準自包含結構，放置於 `project/features/draft-digital-loan-disbursement`。
   - 補充 `teardown.sql` 與模組自述檔案。
3. **Phase 3: 驗證建置與熱插拔抽離驗證 (Verification & Teardown Drill)**
   - 執行 `mvn clean package` 驗證端點與工作流正常生成。
   - 啟動服務執行 E2E 測試驗證功能。
   - 進行抽離演練：備份後刪除目錄，確認平台能否無損重構建置。

