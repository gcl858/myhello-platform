# VS Code 擴充套件規格書：Agent Dynamic Script Runner (Node.js 執行器)

## 1. 專案背景與目標 (Background & Objectives)

### 1.1 背景
在配合 AI Agent (如 Claude、Gemini、Antigravity、Cursor 等) 進行架構設計與程式碼檢測 (例如 `vibe-workflow-design-v2` skill) 時，傳統上常依賴特定 OS 的 Shell 腳本 (如 Bash、`grep`、`awk`、`sort -V`)。這在跨 Windows 與 Linux 時極易因為 Shell 語法、路徑分隔符與工具缺失而中斷。

### 1.2 目標
本擴充套件**不寫死任何特定領域的驗證邏輯**，而是作為一個通用的 **「VS Code Agent Bridge / Dynamic Script Runner」**：
1. **執行環境跨平台**：利用 VS Code 原生 Node.js 執行環境，抹平 Windows 與 Linux 的作業系統差異。
2. **邏輯動態化 (Code-as-Payload)**：AI Agent (Skill) 在需要時，透過本機 HTTP API 將 JavaScript 程式碼發送給本擴充執行。
3. **深度整合 VS Code**：動態代碼可直接存取工作區檔案，並調用 VS Code API（在編輯器繪製錯誤波浪線、更新「問題（Problems）」面板、狀態列即時反饋）。

---

## 2. 核心功能清單 (Features)

| 編號 | 功能模組 | 描述 |
|---|---|---|
| **F-01** | **本機 HTTP API Server** | 擴充啟動時在背景監聽 `127.0.0.1` 指定埠號（預設 `28088`），提供 REST API。 |
| **F-02** | **動態代碼執行器 (`/api/run`)** | 接收 JSON 傳入的 JavaScript 程式碼字串，注入工作區 Context 後於 Node.js 內非同步執行。 |
| **F-03** | **腳本檔案執行器 (`/api/run-file`)** | 接收相對工作區路徑的 `.js` 檔案，載入並執行。 |
| **F-04** | **健康檢查與狀態端點 (`/api/health`)** | 探測 Runner 是否存活、取得當前 VS Code 工作區路徑、已開啟檔案與版本。 |
| **F-05** | **VS Code 問題診斷面板整合** | 提供簡化的 Diagnostics 輔助函式，讓動態代碼能一鍵將 Error/Warning 標註於 Problems 面板。 |
| **F-06** | **狀態列與輸出頻道 (UI 反饋)** | 狀態列顯示 Runner 監聽狀態，並建立獨立 OutputChannel 記錄所有執行日誌。 |

---

## 3. API 規格與契約 (API Contracts)

伺服器僅監聽本機位址：`http://127.0.0.1:<PORT>` (預設 Port: `28088`)。

### 3.1 `GET /api/health`
探測擴充狀態與當前工作區環境。
- **Response `200 OK`**:
```json
{
  "status": "online",
  "version": "1.0.0",
  "workspaceRoot": "/media/op/.../workspace-0910",
  "activeFile": "/path/to/current/editing/file.yaml",
  "uptime": 128.5
}
```

---

### 3.2 `POST /api/run` (核心)
動態接收 JavaScript 字串並執行。

- **Request Body**:
```json
{
  "script": "const files = fs.readdirSync(path.join(workspaceRoot, args.dir)); console.log('Found:', files.length); return { count: files.length };",
  "args": {
    "dir": "ai-studio/draft-omni-counter-repayment-v2/src"
  },
  "timeoutMs": 30000
}
```

- **Response `200 OK` (執行成功)**:
```json
{
  "success": true,
  "result": {
    "count": 5
  },
  "logs": [
    "Found: 5"
  ],
  "executionTimeMs": 14
}
```

- **Response `200 OK` (腳本執行拋出錯誤)**:
```json
{
  "success": false,
  "error": "Directory does not exist",
  "stack": "Error: Directory does not exist\n    at ...",
  "logs": [],
  "executionTimeMs": 3
}
```

- **Response `400 Bad Request`**:
缺少 `script` 欄位。

- **Response `504 Gateway Timeout`**:
執行超過 `timeoutMs` (預設 30 秒)。

---

### 3.3 `POST /api/run-file`
執行專案目錄下的特定 `.js` 模組檔案。

- **Request Body**:
```json
{
  "filePath": "ai-studio/.agents/skills/vibe-workflow-design-v2/scripts/check_compatibility.js",
  "args": {
    "draftDir": "ai-studio/draft-omni-counter-repayment-v2"
  },
  "timeoutMs": 30000
}
```

- **Response**: 格式同 `POST /api/run`。

---

### 3.4 `POST /api/diagnostics/clear`
清除擴充套件在 VS Code「問題 (Problems)」面板中標註的所有診斷項目。

- **Response `200 OK`**:
```json
{ "cleared": true }
```

---

## 4. 動態腳本注入環境規格 (Runtime Context)

動態執行的 JavaScript 代碼以 `async` 函式執行，內建以下注入物件（可直接在腳本中使用）：

```javascript
// 動態代碼可直接存取的 Context 變數：
{
  workspaceRoot: string,    // 當前開啟的專案根目錄絕對路徑
  args: any,                // 由 API 傳入的 args 物件
  fs: fsModule,             // Node.js fs 模組 (promises 與 sync 皆可用)
  path: pathModule,         // Node.js path 模組
  vscode: vscode,           // 完整的 vscode 物件 (可調用所有 VS Code API)
  console: {                // 攔截式 console，所有輸出會彙整至 API response 的 logs 中
    log: (...args),
    warn: (...args),
    error: (...args)
  },
  
  // 專門為檢測腳本提供的便捷輔助工具
  helpers: {
    // 快速在 VS Code Problems 面板新增診斷
    // severity: 'error' | 'warning' | 'info'
    addDiagnostic(filePath: string, line: number, col: number, message: string, severity?: string): void,
    
    // 清除指定檔案或全部的診斷
    clearDiagnostics(filePath?: string): void,
    
    // 讀取工作區內的 YAML 檔案並轉為 Object (若專案有打包 js-yaml)
    readYaml(relativeFilePath: string): object,
    
    // 輸出到 VS Code 專屬 Output Channel
    output(message: string): void
  }
}
```

---

## 5. 擴充套件架構與檔案結構 (Architecture & Layout)

建議在現有 VS Code 擴充專案中按以下結構組織：

```
your-vscode-extension/
├── package.json
├── src/
│   ├── extension.ts (或 .js)       # 擴充進入點 (activate, deactivate)
│   ├── server/
│   │   ├── httpServer.ts          # 輕量本機 HTTP 伺服器 (REST API 路由)
│   │   └── routes.ts              # /api/run, /api/run-file, /api/health
│   ├── runner/
│   │   ├── scriptRunner.ts        # Node.js AsyncFunction / vm 執行引擎與超時保護
│   │   └── contextBuilder.ts      # 構建注入環境 (fs, path, helpers, console)
│   └── ui/
│       ├── statusBar.ts           # 狀態列管理 ($(radio-tower) Agent Runner)
│       ├── diagnosticsBridge.ts   # VS Code DiagnosticCollection 管理
│       └── outputChannel.ts       # 輸出日誌面板
```

---

## 6. 詳細實作細節指引 (Implementation Details)

### 6.1 伺服器安全與生命週期
1. **安全性**：`http.createServer` 必須且僅綁定 `127.0.0.1`，不可綁定 `0.0.0.0`。
2. **埠號佔用處理**：若預設 `28088` 被佔用，應嘗試自動遞增（`28089`...）並在狀態列與 OutputChannel 顯示當前埠號。
3. **擴充關閉銷毀**：在 `deactivate()` 務必調用 `server.close()`，釋放通訊埠。

### 6.2 執行器 (`ScriptRunner`) 設計
1. **非同步函式包裝**：
   ```javascript
   const AsyncFunction = Object.getPrototypeOf(async function(){}).constructor;
   const fn = new AsyncFunction('context', `with (context) { return (async () => { ${script} })(); }`);
   ```
2. **Timeout 保護**：
   使用 `Promise.race` 結合定時器，當腳本陷入無窮迴圈時拋出 `Timeout Error`，避免卡死 Node.js 事件迴圈。

### 6.3 Configuration 設定項 (`package.json`)
在 `contributes.configuration` 加入以下設定：
```json
{
  "agentRunner.port": {
    "type": "number",
    "default": 28088,
    "description": "Agent Runner 本機 HTTP 服務監聽埠號"
  },
  "agentRunner.autoStart": {
    "type": "boolean",
    "default": true,
    "description": "開啟工作區時是否自動啟動 Agent Runner"
  },
  "agentRunner.defaultTimeout": {
    "type": "number",
    "default": 30000,
    "description": "動態腳本預設最大執行超時時間 (毫秒)"
  }
}
```

---

## 7. 驗收測試案例 (Verification & Test Cases)

當 AI 完成此擴充後，可透過終端機執行下列測試以確認功能完整：

### 測試 1：健康檢查
```bash
curl -s http://127.0.0.1:28088/api/health
```
- **預期**：回傳 JSON，包含 `"status": "online"` 與當前 `workspaceRoot`。

### 測試 2：動態執行與運算
```bash
curl -s -X POST http://127.0.0.1:28088/api/run \
  -H "Content-Type: application/json" \
  -d '{"script": "console.log(\"Hello\"); return 1 + 1;"}'
```
- **預期**：`result` 為 `2`，`logs` 包含 `"Hello"`。

### 測試 3：跨平台檔案讀取
```bash
curl -s -X POST http://127.0.0.1:28088/api/run \
  -H "Content-Type: application/json" \
  -d '{"script": "return fs.existsSync(workspaceRoot);"}'
```
- **預期**：`result` 為 `true`。

### 測試 4：在 VS Code Problems 面板顯示紅線
```bash
curl -s -X POST http://127.0.0.1:28088/api/run \
  -H "Content-Type: application/json" \
  -d '{"script": "helpers.addDiagnostic(\"test.txt\", 1, 1, \"測試錯誤訊息\", \"error\"); return \"ok\";"}'
```
- **預期**：VS Code Problems 面板立刻出現 `test.txt: [錯誤] 測試錯誤訊息`。

