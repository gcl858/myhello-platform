package org.acme.transfer.api.features;

import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import org.acme.transfer.api.features.dto.CoreCashDepositRequest;
import org.acme.transfer.api.features.dto.CoreCashDepositResponse;

import java.util.UUID;

@Path("/CreditCard/{creditcardid}/Repayment")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class CreditCardRepaymentResource {
    @POST
    @Path("/Execute")
    public Response execute(@PathParam("creditcardid") String creditcardid, CoreCashDepositRequest request) {
        return Response.ok(new CoreCashDepositResponse(UUID.randomUUID().toString(), 0, null, null)).build();
    }

    @POST
    @Path("/Rollback")
    public Response rollback(@PathParam("creditcardid") String creditcardid, CoreCashDepositRequest request) {
        return Response.ok(new CoreCashDepositResponse(UUID.randomUUID().toString(), 0, null, null)).build();
    }
}