package com.example.platform.distribution.transfer;

import com.example.transfer.workflow.BusinessRuleValidator;
import com.example.transfer.workflow.OpenApiSchemaValidator;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@DisplayName("OpenApiSchemaValidator 單元測試")
class OpenApiSchemaValidatorTest {

    private static final ObjectMapper JSON = new ObjectMapper();
    private static OpenApiSchemaValidator validator;

    static class TestOmniCashBusinessRuleValidator implements BusinessRuleValidator {
        private static final String OMNI_WORKFLOW_ID = "omni_cash_transaction";

        @Override
        public String workflowId() {
            return OMNI_WORKFLOW_ID;
        }

        @Override
        public List<OpenApiSchemaValidator.ValidationError> validate(JsonNode payload) {
            List<OpenApiSchemaValidator.ValidationError> errors = new ArrayList<>();
            String operationType = payload.has("operationType") ? payload.get("operationType").asText() : "";
            String origSeq = payload.has("originalSequenceNumber") ? payload.get("originalSequenceNumber").asText() : "";
            String amount = payload.has("amount") ? payload.get("amount").asText() : "";

            if (!"A".equals(operationType) && !"B".equals(operationType)) {
                errors.add(new OpenApiSchemaValidator.ValidationError("operationType", "E0001", "operationType 必須為 A 或 B"));
            }
            if (!amount.isBlank()) {
                if ("0".equals(amount) || "0000000000".equals(amount)) {
                    errors.add(new OpenApiSchemaValidator.ValidationError("amount", "E0001", "amount 必須大於 0"));
                } else {
                    try {
                        String cleanAmount = amount.startsWith("FAIL_") ? amount.substring(5) : amount;
                        if (Long.parseLong(cleanAmount) <= 0) {
                            errors.add(new OpenApiSchemaValidator.ValidationError("amount", "E0001", "amount 必須大於 0"));
                        }
                    } catch (NumberFormatException ignored) {
                    }
                }
            }
            if ("A".equals(operationType) && !origSeq.isBlank()) {
                errors.add(new OpenApiSchemaValidator.ValidationError("originalSequenceNumber", "E0002", "operationType=A 時不可帶 originalSequenceNumber"));
            }
            if ("B".equals(operationType) && origSeq.isBlank()) {
                errors.add(new OpenApiSchemaValidator.ValidationError("originalSequenceNumber", "E0002", "operationType=B 時, originalSequenceNumber 為必填"));
            }
            return errors;
        }
    }

    @BeforeAll
    static void setUp() {
        validator = new OpenApiSchemaValidator();
        validator.initSchemas();
        validator.registerValidator(new TestOmniCashBusinessRuleValidator());
    }

    private ObjectNode createBasePayload() {
        ObjectNode payload = JSON.createObjectNode();
        payload.put("partyId", "A123456789");
        payload.put("branchCode", "070");
        payload.put("transactionDate", "20260805");
        payload.put("transactionDateTime", "15061655");
        payload.put("postingDayType", "A");
        payload.put("postingDate", "20260805");
        payload.put("paymentSourceCode", "2500P");
        payload.put("operationType", "A");
        payload.put("amount", "0000011758");
        payload.put("sequenceNumber", "CA_1234567890000015061655");
        return payload;
    }

    @Test
    @DisplayName("正向繳款 (operationType=A) 合法請求通過驗證")
    void testValidRepaymentA() {
        ObjectNode args = JSON.createObjectNode();
        args.put("workflowId", "omni_cash_transaction");
        args.set("payload", createBasePayload());

        JsonNode result = validator.validate(args);
        assertTrue(result.get("isValid").asBoolean(), "合法 A 請求應驗證通過: " + result.get("errors"));
        assertEquals(0, result.get("errors").size());
    }

    @Test
    @DisplayName("主動取消 (operationType=B) 帶 originalSequenceNumber 合法請求通過驗證")
    void testValidCancellationB() {
        ObjectNode payload = createBasePayload();
        payload.put("operationType", "B");
        payload.put("sequenceNumber", "CA_R_1234567890000016000000");
        payload.put("originalSequenceNumber", "CA_1234567890000015061655");

        ObjectNode args = JSON.createObjectNode();
        args.put("workflowId", "omni_cash_transaction");
        args.set("payload", payload);

        JsonNode result = validator.validate(args);
        assertTrue(result.get("isValid").asBoolean(), "合法 B 請求應驗證通過: " + result.get("errors"));
        assertEquals(0, result.get("errors").size());
    }

    @Test
    @DisplayName("operationType=C 非法操作類型應驗證失敗")
    void testInvalidOperationType() {
        ObjectNode payload = createBasePayload();
        payload.put("operationType", "C");

        ObjectNode args = JSON.createObjectNode();
        args.put("workflowId", "omni_cash_transaction");
        args.set("payload", payload);

        JsonNode result = validator.validate(args);
        assertFalse(result.get("isValid").asBoolean(), "operationType=C 應驗證失敗");
        assertTrue(result.get("errors").size() > 0);

        boolean foundField = false;
        for (JsonNode err : result.get("errors")) {
            if ("operationType".equals(err.get("field").asText())) {
                foundField = true;
                break;
            }
        }
        assertTrue(foundField, "錯誤清單中應指明 operationType 欄位");
    }

    @Test
    @DisplayName("operationType=A 帶了 originalSequenceNumber 應驗證失敗")
    void testOpTypeAWithOriginalSeq() {
        ObjectNode payload = createBasePayload();
        payload.put("operationType", "A");
        payload.put("originalSequenceNumber", "CA_ORIGINAL_123");

        ObjectNode args = JSON.createObjectNode();
        args.put("workflowId", "omni_cash_transaction");
        args.set("payload", payload);

        JsonNode result = validator.validate(args);
        assertFalse(result.get("isValid").asBoolean(), "operationType=A 帶原序號應驗證失敗");
    }

    @Test
    @DisplayName("operationType=B 缺少 originalSequenceNumber 應驗證失敗")
    void testOpTypeBMissingOriginalSeq() {
        ObjectNode payload = createBasePayload();
        payload.put("operationType", "B");
        payload.remove("originalSequenceNumber");

        ObjectNode args = JSON.createObjectNode();
        args.put("workflowId", "omni_cash_transaction");
        args.set("payload", payload);

        JsonNode result = validator.validate(args);
        assertFalse(result.get("isValid").asBoolean(), "operationType=B 缺原序號應驗證失敗");
    }

    @Test
    @DisplayName("必填欄位缺失 (缺少 partyId) 應驗證失敗")
    void testMissingRequiredField() {
        ObjectNode payload = createBasePayload();
        payload.remove("partyId");

        ObjectNode args = JSON.createObjectNode();
        args.put("workflowId", "omni_cash_transaction");
        args.set("payload", payload);

        JsonNode result = validator.validate(args);
        assertFalse(result.get("isValid").asBoolean(), "缺少 partyId 應驗證失敗");
    }

    @Test
    @DisplayName("正則格式不符 (transactionDate 格式錯誤) 應驗證失敗")
    void testPatternMismatch() {
        ObjectNode payload = createBasePayload();
        payload.put("transactionDate", "2026-08-05"); // 應該為 8 碼數字，含破折號

        ObjectNode args = JSON.createObjectNode();
        args.put("workflowId", "omni_cash_transaction");
        args.set("payload", payload);

        JsonNode result = validator.validate(args);
        assertFalse(result.get("isValid").asBoolean(), "transactionDate 格式不符應驗證失敗");
    }

    @Test
    @DisplayName("amount 為 0 應驗證失敗")
    void testZeroAmount() {
        ObjectNode payload = createBasePayload();
        payload.put("amount", "0000000000");

        ObjectNode args = JSON.createObjectNode();
        args.put("workflowId", "omni_cash_transaction");
        args.set("payload", payload);

        JsonNode result = validator.validate(args);
        assertFalse(result.get("isValid").asBoolean(), "amount 為 0 應驗證失敗");
    }
}
