package com.example.platform.distribution.transfer;

import io.quarkus.test.junit.QuarkusTest;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.nullValue;

/**
 * saga5-transfer-workflow 完整測試 (標準 compensation + 精簡合併決策版)
 * 以 saga4 標準補償模式為底,決策層沿用 saga3 精簡風格
 * (CheckA16220Result + DecideByEvaluation 合併為 CheckA16220AndEvaluate),
 * 驗證終態/輸出契約與 saga2/saga3 一致:
 *   - AMT=100 → SUCCESS
 *   - AMT=600 → ROLLED_BACK (標準補償 LIFO,兩階段皆沖正)
 *   - AMT=30 → FAILED (A16229 業務失敗短路)
 *   - AMT=2000 → ROLLED_BACK (A16220 失敗,僅補償 A16229)
 *   - 邊界 AMT=500/501
 *   - VALIDATION_FAILED → HTTP 400 (WorkflowStatusFilter 改寫)
 *   - ROLLBACK_FAILED → HTTP 409 (RBFAIL 測試哨兵)
 *   - SQLite workflow_execution_log 有 saga5 對帳紀錄 (FinalAuditAndEnd 收斂證明)
 *
 * 本測試透過 SonataFlow HTTP 端點 ({@code POST /saga5-transfer-workflow})
 * 啟動 workflow,並用 rest-assured 驗證輸出 JSON。
 */
@QuarkusTest
@DisplayName("saga5-transfer-workflow 標準補償精簡版測試")
class Saga5TransferWorkflowTest {

    private static final String WORKFLOW_URL = "/saga5-transfer-workflow";

    private static final String PAYLOAD_TEMPLATE =
            "{\"Account_A\":\"A123\",\"Account_B\":\"B123\",\"AMT\":%d}";

    @Test
    @DisplayName("[1] AMT=100 → SUCCESS (兩 API 都成功)")
    void testAmt100Success() {
        given()
            .contentType("application/json")
            .body(String.format(PAYLOAD_TEMPLATE, 100))
        .when()
            .post(WORKFLOW_URL)
        .then()
            .statusCode(200)
            .body("status", equalTo("SUCCESS"))
            .body("message", equalTo("交易成功"))
            .body("AMT", equalTo(100))
            .body("a16229Result.code", equalTo("100"))
            .body("a16229Result._httpStatus", equalTo(200))
            .body("a16220Result.code", equalTo("100"))
            .body("a16220Result._httpStatus", equalTo(200))
            .body("opsAlertRaised", equalTo(false));
    }

    @Test
    @DisplayName("[2] AMT=600 → ROLLED_BACK (標準補償 LIFO,兩階段皆沖正)")
    void testAmt600RolledBackLifo() {
        given()
            .contentType("application/json")
            .body(String.format(PAYLOAD_TEMPLATE, 600))
        .when()
            .post(WORKFLOW_URL)
        .then()
            .statusCode(200)
            .body("status", equalTo("ROLLED_BACK"))
            .body("message", equalTo("AMT > 500 觸發 saga 回沖 (LIFO)"))
            .body("AMT", equalTo(600))
            .body("a16229Result.code", equalTo("100"))
            .body("a16220Result.code", equalTo("100"))
            // 標準補償:兩個沖正都用 EC=true,輸出鍵名沿用 saga2 契約
            .body("a16229Rollback.code", equalTo("100"))
            .body("a16229Rollback.message", equalTo("成功(EC)"))
            .body("a16220Rollback.code", equalTo("100"))
            .body("a16220Rollback.message", equalTo("成功(EC)"));
    }

    @Test
    @DisplayName("[3] AMT=30 → FAILED (A16229 業務失敗短路,不呼叫 A16220)")
    void testAmt30Failed() {
        given()
            .contentType("application/json")
            .body(String.format(PAYLOAD_TEMPLATE, 30))
        .when()
            .post(WORKFLOW_URL)
        .then()
            .statusCode(200)
            .body("status", equalTo("FAILED"))
            .body("AMT", equalTo(30))
            .body("a16229Result.code", equalTo("999"))
            .body("a16229Result._httpStatus", equalTo(403))
            // 短路:A16220 與補償都不該被呼叫
            .body("a16220Result", nullValue())
            .body("a16229Rollback", nullValue())
            .body("a16220Rollback", nullValue());
    }

    @Test
    @DisplayName("[4] AMT=2000 → ROLLED_BACK (A16220 失敗,僅補償 A16229)")
    void testAmt2000RolledBackA16229Only() {
        given()
            .contentType("application/json")
            .body(String.format(PAYLOAD_TEMPLATE, 2000))
        .when()
            .post(WORKFLOW_URL)
        .then()
            .statusCode(200)
            .body("status", equalTo("ROLLED_BACK"))
            .body("message", equalTo("A16220 業務失敗,僅回沖 A16229"))
            .body("AMT", equalTo(2000))
            .body("a16229Result.code", equalTo("100"))
            .body("a16220Result.code", equalTo("999"))
            .body("a16220Result._httpStatus", equalTo(403))
            // 只補償 A16229 (A16220 本來就沒扣款,引擎不調度其補償)
            .body("a16229Rollback.code", equalTo("100"))
            .body("a16229Rollback.message", equalTo("成功(EC)"))
            .body("a16220Rollback", nullValue());
    }

    @Test
    @DisplayName("[5] AMT=500 邊界值 → SUCCESS (AMT <= 500 才算成功)")
    void testAmt500BoundarySuccess() {
        given()
            .contentType("application/json")
            .body(String.format(PAYLOAD_TEMPLATE, 500))
        .when()
            .post(WORKFLOW_URL)
        .then()
            .statusCode(200)
            .body("status", equalTo("SUCCESS"))
            .body("AMT", equalTo(500));
    }

    @Test
    @DisplayName("[6] AMT=501 邊界值 → ROLLED_BACK (AMT > 500 觸發補償)")
    void testAmt501BoundaryRolledBack() {
        given()
            .contentType("application/json")
            .body(String.format(PAYLOAD_TEMPLATE, 501))
        .when()
            .post(WORKFLOW_URL)
        .then()
            .statusCode(200)
            .body("status", equalTo("ROLLED_BACK"))
            .body("AMT", equalTo(501));
    }

    @Test
    @DisplayName("[7] SQLite 對帳紀錄:workflow_execution_log 有 saga5 紀錄 (FinalAuditAndEnd 收斂證明)")
    void testSqliteAuditRecords() throws Exception {
        Class.forName("org.sqlite.JDBC");
        try (java.sql.Connection conn = java.sql.DriverManager.getConnection("jdbc:sqlite:target/test-reconciliation.db");
             java.sql.Statement stmt = conn.createStatement();
             java.sql.ResultSet rs = stmt.executeQuery(
                     "SELECT workflow_id, business_key, status FROM workflow_execution_log WHERE workflow_id = 'saga5-transfer-workflow'")) {
            int count = 0;
            while (rs.next()) {
                count++;
                System.out.printf("[Saga5 Audit Test] Row %d -> WF: %s, BKey: %s, Status: %s%n",
                        count, rs.getString("workflow_id"), rs.getString("business_key"),
                        rs.getString("status"));
            }
            org.junit.jupiter.api.Assertions.assertTrue(count > 0, "workflow_execution_log 應包含 saga5 的對帳紀錄");
        }
    }

    // ═══════════════════════════════════════════════
    // 輸入驗證路徑 (VALIDATION_FAILED → HTTP 400,由 WorkflowStatusFilter 改寫)
    // ═══════════════════════════════════════════════

    private static final String INVALID_PAYLOAD_TEMPLATE =
            "{\"Account_A\":\"%s\",\"Account_B\":\"%s\",\"AMT\":%s}";

    @Test
    @DisplayName("[8] 缺失欄位 (null-safe) → 400 VALIDATION_FAILED,不拋 jq 例外")
    void testValidationFailedMissingField() {
        given()
            .contentType("application/json")
            .body("{\"Account_A\":\"123456\"}")
        .when()
            .post(WORKFLOW_URL)
        .then()
            .statusCode(400)
            .body("status", equalTo("VALIDATION_FAILED"))
            .body("message", equalTo("輸入欄位格式錯誤 (帳號僅限英數字與底線且兩者不得相同;AMT 須為大於 0 的數字)"))
            .body("a16229Result", nullValue())
            .body("a16220Result", nullValue())
            .body("auditSaved", equalTo(true))
            .body("opsAlertRaised", equalTo(false));
    }

    @Test
    @DisplayName("[9] Account_B 含非法字元 → 400 VALIDATION_FAILED")
    void testValidationFailedBadChars() {
        given()
            .contentType("application/json")
            .body(String.format(INVALID_PAYLOAD_TEMPLATE, "123456", "A@0001", "100"))
        .when()
            .post(WORKFLOW_URL)
        .then()
            .statusCode(400)
            .body("status", equalTo("VALIDATION_FAILED"));
    }

    @Test
    @DisplayName("[10] AMT=0 (非正數) → 400 VALIDATION_FAILED")
    void testValidationFailedAmtZero() {
        given()
            .contentType("application/json")
            .body(String.format(INVALID_PAYLOAD_TEMPLATE, "123456", "A00001", "0"))
        .when()
            .post(WORKFLOW_URL)
        .then()
            .statusCode(400)
            .body("status", equalTo("VALIDATION_FAILED"))
            .body("AMT", equalTo(0));
    }

    @Test
    @DisplayName("[11] 同帳號 → 400 VALIDATION_FAILED")
    void testValidationFailedSameAccount() {
        given()
            .contentType("application/json")
            .body(String.format(INVALID_PAYLOAD_TEMPLATE, "123456", "123456", "100"))
        .when()
            .post(WORKFLOW_URL)
        .then()
            .statusCode(400)
            .body("status", equalTo("VALIDATION_FAILED"));
    }

    // ═══════════════════════════════════════════════
    // errorType 契約 (成功不含欄位;業務失敗標記 BUSINESS)
    // ═══════════════════════════════════════════════

    @Test
    @DisplayName("[12] SUCCESS 時 errorType 不存在 (向後相容)")
    void testSuccessHasNoErrorType() {
        given()
            .contentType("application/json")
            .body(String.format(PAYLOAD_TEMPLATE, 100))
        .when()
            .post(WORKFLOW_URL)
        .then()
            .statusCode(200)
            .body("status", equalTo("SUCCESS"))
            .body("a16229Result.errorType", nullValue())
            .body("a16220Result.errorType", nullValue());
    }

    @Test
    @DisplayName("[13] A16229 業務失敗時 errorType=BUSINESS (HTTP 403 + body 自帶 code 999)")
    void testFailedPathErrorTypeBusiness() {
        given()
            .contentType("application/json")
            .body(String.format(PAYLOAD_TEMPLATE, 30))
        .when()
            .post(WORKFLOW_URL)
        .then()
            .statusCode(200)
            .body("status", equalTo("FAILED"))
            .body("a16229Result.code", equalTo("999"))
            .body("a16229Result._httpStatus", equalTo(403))
            .body("a16229Result.errorType", equalTo("BUSINESS"));
    }

    // ═══════════════════════════════════════════════
    // ROLLBACK_FAILED 路徑 (RBFAIL 測試哨兵 → HTTP 409,由 WorkflowStatusFilter 改寫)
    // ═══════════════════════════════════════════════

    @Test
    @DisplayName("[14] 全補償但 A16220 沖正失敗 (Account_B=RBFAIL) → 409 ROLLBACK_FAILED")
    void testRollbackFailedLifo() {
        given()
            .contentType("application/json")
            .body("{\"Account_A\":\"123456\",\"Account_B\":\"RBFAIL\",\"AMT\":600}")
        .when()
            .post(WORKFLOW_URL)
        .then()
            .statusCode(409)
            .body("status", equalTo("ROLLBACK_FAILED"))
            .body("message", equalTo("⚠️ 回沖失敗,需人工介入處理"))
            // 兩階段原本皆業務成功
            .body("a16229Result.code", equalTo("100"))
            .body("a16220Result.code", equalTo("100"))
            // 標準補償判定:A16220 沖正失敗 → ROLLBACK_FAILED
            .body("a16220Rollback.code", equalTo("401"))
            .body("a16220Rollback.message", equalTo("回沖失敗(測試哨兵)"))
            .body("a16229Rollback.code", equalTo("100"))
            .body("auditSaved", equalTo(true))
            .body("opsAlertRaised", equalTo(true));
    }

    @Test
    @DisplayName("[15] A16220 業務失敗 + 僅補償 A16229 也失敗 (Account_A=RBFAIL) → 409 ROLLBACK_FAILED")
    void testRollbackFailedA16229Only() {
        given()
            .contentType("application/json")
            .body("{\"Account_A\":\"RBFAIL\",\"Account_B\":\"A00001\",\"AMT\":2000}")
        .when()
            .post(WORKFLOW_URL)
        .then()
            .statusCode(409)
            .body("status", equalTo("ROLLBACK_FAILED"))
            // EC=false 正常交易不受 RBFAIL 影響,階段 1 成功、階段 2 因 AMT>=1000 失敗
            .body("a16229Result.code", equalTo("100"))
            .body("a16220Result.code", equalTo("999"))
            .body("a16220Rollback", nullValue())
            .body("a16229Rollback.code", equalTo("401"))
            .body("opsAlertRaised", equalTo(true));
    }
}
