package com.example.reconciliation;

import com.example.platform.common.PlatformPaths;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Stream;

/**
 * 提供 sw.yaml 內容給前端,作為流程節點白名單的資料來源。
 *
 * 設計動機(方案 F + 原位自動探索):
 *   - 後端保持 dumb pipe:只搬檔案字串,不解析 sw.yaml schema
 *   - 前端用 js-yaml 解析,抽出 states[].name 做白名單過濾
 *   - 零複製 (Zero-Copy): 原位遞迴掃描 features/ 及 transfer-workflow 原始目錄，
 *     無需將 sw.yaml 複製至 data/workflows/ 或 transfer-app/src/main/resources
 *
 * 探索優先序:
 *   1. ${MYHELLO_WORKFLOWS_DIR} 外部目錄 (若環境變數有指定)
 *   2. ${MYHELLO_DATA_DIR}/workflows/ (向後相容外部掛載)
 *   3. /opt/workflows/ (容器標準掛載)
 *   4. 專案根目錄遞迴探索:
 *      - project/features/{feature}/workflows/*.sw.yaml (獨立特徵外掛工作流)
 *      - domain-transfer/transfer-workflow/src/main/resources/*.sw.yaml (核心轉帳工作流)
 *      - dev/transfer-samples/src/main/resources/*.sw.yaml
 *
 * API:
 *   GET /api/reconciliation/workflow-spec/processes
 *   GET /api/reconciliation/workflow-spec/{processId}
 *   GET /api/reconciliation/workflow-spec/{processId}/yaml
 *   POST /api/reconciliation/workflow-spec/reload
 */
@Path("/api/reconciliation/workflow-spec")
@Produces(MediaType.APPLICATION_JSON)
public class WorkflowSpecResource {

    private static final Logger LOG = LoggerFactory.getLogger(WorkflowSpecResource.class);

    /** processId → 絕對路徑 (啟動時建索引) */
    private final Map<String, java.nio.file.Path> index = new LinkedHashMap<>();

    /** processId → sw.yaml version (供前端 cache invalidation 與 banner 顯示) */
    private final Map<String, String> versions = new LinkedHashMap<>();

    public WorkflowSpecResource() {
        rebuildIndex();
    }

    /**
     * 掃描目錄 (支援遞迴),建立 processId → sw.yaml 路徑索引。
     * 失敗不致命:索引為空時,後續端點回傳空清單,前端走保險絲降級。
     */
    synchronized void rebuildIndex() {
        index.clear();
        versions.clear();
        List<java.nio.file.Path> searchDirs = buildSearchDirs();
        for (java.nio.file.Path dir : searchDirs) {
            if (!Files.isDirectory(dir)) continue;
            try (Stream<java.nio.file.Path> stream = Files.walk(dir, 5)) {
                stream.filter(Files::isRegularFile)
                      .filter(p -> {
                          String pathStr = p.toString();
                          return !pathStr.contains("/.git/") && !pathStr.contains("\\.git\\")
                              && !pathStr.contains("/target/") && !pathStr.contains("\\target\\");
                      })
                      .filter(p -> p.getFileName().toString().endsWith(".sw.yaml"))
                      .forEach(this::registerFile);
            } catch (IOException e) {
                LOG.warn("[WorkflowSpecResource] 掃描 {} 失敗: {}", dir, e.getMessage());
            }
        }
        LOG.info("[WorkflowSpecResource] 已註冊 {} 個 workflow: {}",
                index.size(), index.keySet());
    }

    /**
     * sw.yaml 搜尋目錄優先序:
     *   1. ${MYHELLO_WORKFLOWS_DIR}           (環境變數顯式指定)
     *   2. ${MYHELLO_DATA_DIR}/workflows/    (PlatformPaths 跨平台解析 / 相容掛載)
     *   3. /opt/workflows/                   (容器環境標準路徑)
     *   4. 專案原始碼 resources 與 features 目錄 (開發環境原位自動探索)
     */
    private List<java.nio.file.Path> buildSearchDirs() {
        Set<java.nio.file.Path> dirs = new LinkedHashSet<>();

        // 1. 環境變數顯式指定 (最高優先級)
        String envWorkflows = System.getProperty("MYHELLO_WORKFLOWS_DIR");
        if (envWorkflows == null || envWorkflows.isBlank()) {
            envWorkflows = System.getenv("MYHELLO_WORKFLOWS_DIR");
        }
        if (envWorkflows != null && !envWorkflows.isBlank()) {
            dirs.add(java.nio.file.Path.of(envWorkflows).toAbsolutePath().normalize());
        }

        // 2. 外部資料目錄 (相容傳統外部 mount)
        dirs.add(PlatformPaths.dataDirectory().resolve("workflows").toAbsolutePath().normalize());

        // 3. 容器環境標準路徑
        dirs.add(java.nio.file.Path.of("/opt/workflows").toAbsolutePath().normalize());

        // 4. 開發環境專案目錄自動探索 (zero-copy 原位自動掃描)
        try {
            java.nio.file.Path root = PlatformPaths.findProjectRoot();
            if (root != null) {
                // 特徵外掛模組 (features/<name>/workflows/*.sw.yaml)
                dirs.add(root.resolve("features").toAbsolutePath().normalize());
                // 核心轉帳流程
                dirs.add(root.resolve("domain-transfer/transfer-workflow/src/main/resources").toAbsolutePath().normalize());
                // 範例/樣本流程 (若存在)
                dirs.add(root.resolve("dev/transfer-samples/src/main/resources").toAbsolutePath().normalize());
                // 分發模組 resources (若有自定義流程)
                dirs.add(root.resolve("distribution/transfer-app/src/main/resources").toAbsolutePath().normalize());
            }
        } catch (Exception ignored) {
        }

        return new ArrayList<>(dirs);
    }

    /**
     * 解析 sw.yaml 頂層 id 與 version 兩個欄位。
     * 極簡 regex 實作:避免引入 SnakeYAML,降低依賴成本。
     * 支援行尾註解、引號脫逸與前 50 行探索。
     */
    private void registerFile(java.nio.file.Path yaml) {
        try {
            List<String> head = Files.readAllLines(yaml);
            String id = null;
            String version = null;
            int scanned = 0;
            for (String line : head) {
                if (++scanned > 50) break;
                if (id == null && line.matches("^\\s*id\\s*:\\s*\\S.*")) {
                    id = extractHeaderValue(line, "id");
                }
                if (version == null && line.matches("^\\s*version\\s*:\\s*\\S.*")) {
                    version = extractHeaderValue(line, "version");
                }
                if (id != null && version != null) break;
            }
            if (id != null && !id.isBlank()) {
                if (index.containsKey(id)) {
                    LOG.info("[WorkflowSpecResource] 註冊 workflow id={}: {} (取代舊路徑 {})",
                            id, yaml.toAbsolutePath(), index.get(id));
                }
                index.put(id, yaml.toAbsolutePath());
                versions.put(id, version != null ? version : "");
            } else {
                LOG.warn("[WorkflowSpecResource] {} 無法解析 id,跳過", yaml.getFileName());
            }
        } catch (IOException e) {
            LOG.warn("[WorkflowSpecResource] 讀取 {} 失敗: {}", yaml, e.getMessage());
        }
    }

    private String extractHeaderValue(String line, String key) {
        String val = line.replaceFirst("^\\s*" + key + "\\s*:\\s*", "").trim();
        if (val.startsWith("\"") && val.indexOf('"', 1) > 0) {
            val = val.substring(1, val.indexOf('"', 1));
        } else if (val.startsWith("'") && val.indexOf('\'', 1) > 0) {
            val = val.substring(1, val.indexOf('\'', 1));
        } else {
            int hashIdx = val.indexOf('#');
            if (hashIdx >= 0) {
                val = val.substring(0, hashIdx).trim();
            }
            val = val.replaceAll("^['\"]|['\"]$", "").trim();
        }
        return val;
    }

    /**
     * GET /api/reconciliation/workflow-spec/processes
     * 回傳所有已註冊的 processId 清單 + 版本 + 來源路徑(前端切換器用)
     */
    @GET
    @Path("/processes")
    public Response listProcesses() {
        List<Map<String, Object>> list = new ArrayList<>();
        index.forEach((pid, path) -> {
            Map<String, Object> entry = new LinkedHashMap<>();
            entry.put("processId", pid);
            entry.put("version", versions.getOrDefault(pid, ""));
            entry.put("sourcePath", path.toString());
            list.add(entry);
        });
        return Response.ok(Map.of("processes", list, "count", list.size())).build();
    }

    /**
     * GET /api/reconciliation/workflow-spec/{processId}
     * 預設回傳 JSON 包裹 {processId, version, sourcePath, yaml}
     * 若 queryParam format=yaml,直接回 text/plain 給前端 jsyaml.load() 使用
     */
    @GET
    @Path("/{processId}")
    @Produces({MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
    public Response getWorkflowSpec(
            @PathParam("processId") String processId,
            @QueryParam("format") String format) {

        java.nio.file.Path yaml = index.get(processId);
        if (yaml == null) {
            Map<String, Object> err = new LinkedHashMap<>();
            err.put("error", "processId not found");
            err.put("processId", processId);
            err.put("registered", index.keySet());
            return Response.status(404).entity(err).build();
        }

        try {
            String content = Files.readString(yaml);

            // format=yaml → 直接回傳原始字串(給前端 jsyaml 直接 load)
            if ("yaml".equalsIgnoreCase(format)) {
                return Response.ok(content)
                        .type(MediaType.TEXT_PLAIN + ";charset=UTF-8")
                        .header("Cache-Control", "max-age=300")
                        .build();
            }

            // 預設:JSON 包裹
            Map<String, Object> body = new LinkedHashMap<>();
            body.put("processId", processId);
            body.put("version", versions.getOrDefault(processId, ""));
            body.put("sourcePath", yaml.toString());
            body.put("yaml", content);
            return Response.ok(body)
                    .header("Cache-Control", "max-age=300")
                    .build();
        } catch (IOException e) {
            return Response.status(500)
                    .entity(Map.of("error", e.getMessage(), "processId", processId))
                    .build();
        }
    }

    /**
     * GET /api/reconciliation/workflow-spec/{processId}/yaml
     * 明確路徑版本,直接回 sw.yaml 原始字串(給前端 jsyaml.load()
     * 直接吃,避免 queryParam 的相容性問題)。
     */
    @GET
    @Path("/{processId}/yaml")
    @Produces(MediaType.TEXT_PLAIN)
    public Response getWorkflowYaml(@PathParam("processId") String processId) {
        java.nio.file.Path yaml = index.get(processId);
        if (yaml == null) {
            return Response.status(404)
                    .type(MediaType.TEXT_PLAIN)
                    .entity("processId not found: " + processId)
                    .build();
        }
        try {
            return Response.ok(Files.readString(yaml))
                    .type("application/x-yaml;charset=UTF-8")
                    .header("Cache-Control", "max-age=300")
                    .build();
        } catch (IOException e) {
            return Response.status(500)
                    .type(MediaType.TEXT_PLAIN)
                    .entity("read error: " + e.getMessage())
                    .build();
        }
    }

    /**
     * POST /api/reconciliation/workflow-spec/reload
     * 強制重建索引(dev mode 改 sw.yaml 後手動觸發)。
     * 產線環境通常不開放(可由 filter 控管)。
     */
    @POST
    @Path("/reload")
    public Response reload() {
        rebuildIndex();
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("reloaded", index.size());
        body.put("processes", index.keySet());
        return Response.ok(body).build();
    }
}
