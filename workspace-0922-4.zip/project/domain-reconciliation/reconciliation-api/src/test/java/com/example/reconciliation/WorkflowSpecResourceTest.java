package com.example.reconciliation;

import jakarta.ws.rs.core.Response;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

class WorkflowSpecResourceTest {

    private WorkflowSpecResource resource;

    @BeforeEach
    void setUp() {
        resource = new WorkflowSpecResource();
    }

    @Test
    void testAutoDiscoveryAndIndexBuilding() {
        Response response = resource.listProcesses();
        assertEquals(Response.Status.OK.getStatusCode(), response.getStatus());

        @SuppressWarnings("unchecked")
        Map<String, Object> body = (Map<String, Object>) response.getEntity();
        assertNotNull(body);

        @SuppressWarnings("unchecked")
        List<Map<String, Object>> processes = (List<Map<String, Object>>) body.get("processes");
        assertNotNull(processes);
        assertFalse(processes.isEmpty(), "Zero-copy auto-discovery should find workflows");

        List<String> processIds = processes.stream()
                .map(p -> (String) p.get("processId"))
                .toList();

        // 1. Check base workflow from core static module
        assertTrue(processIds.contains("saga2-transfer-workflow"),
                "Should discover saga2-transfer-workflow from transfer-workflow resources");

        // 2. Dynamic contract check: whatever sw.yaml files exist in features/ must be discovered
        java.nio.file.Path root = com.example.platform.common.PlatformPaths.findProjectRoot();
        if (root != null) {
            java.nio.file.Path featuresDir = root.resolve("features");
            if (java.nio.file.Files.isDirectory(featuresDir)) {
                try (java.util.stream.Stream<java.nio.file.Path> stream = java.nio.file.Files.walk(featuresDir, 5)) {
                    List<java.nio.file.Path> featureYamls = stream
                            .filter(java.nio.file.Files::isRegularFile)
                            .filter(p -> p.getFileName().toString().endsWith(".sw.yaml"))
                            .filter(p -> {
                                String s = p.toString();
                                return !s.contains("/target/") && !s.contains("\\target\\")
                                        && !s.contains("/.git/") && !s.contains("\\.git\\");
                            })
                            .toList();

                    for (java.nio.file.Path yaml : featureYamls) {
                        String id = extractWorkflowId(yaml);
                        if (id != null && !id.isBlank()) {
                            assertTrue(processIds.contains(id),
                                    "Dynamic feature workflow [" + id + "] in " + yaml + " should be discovered");
                        }
                    }
                } catch (java.io.IOException e) {
                    fail("Failed to scan features directory: " + e.getMessage());
                }
            }
        }
    }

    private String extractWorkflowId(java.nio.file.Path yaml) {
        try {
            List<String> lines = java.nio.file.Files.readAllLines(yaml);
            for (String line : lines) {
                if (line.matches("^\\s*id\\s*:\\s*\\S.*")) {
                    String val = line.replaceFirst("^\\s*id\\s*:\\s*", "").trim();
                    int hashIdx = val.indexOf('#');
                    if (hashIdx >= 0) {
                        val = val.substring(0, hashIdx).trim();
                    }
                    return val.replaceAll("^['\"]|['\"]$", "").trim();
                }
            }
        } catch (java.io.IOException ignored) {
        }
        return null;
    }

    @Test
    void testGetWorkflowSpec() {
        Response response = resource.getWorkflowSpec("saga2-transfer-workflow", null);
        assertEquals(Response.Status.OK.getStatusCode(), response.getStatus());

        @SuppressWarnings("unchecked")
        Map<String, Object> body = (Map<String, Object>) response.getEntity();
        assertNotNull(body);
        assertEquals("saga2-transfer-workflow", body.get("processId"));
        assertNotNull(body.get("yaml"));
        assertTrue(((String) body.get("yaml")).contains("id: saga2-transfer-workflow"));
    }

    @Test
    void testGetWorkflowYaml() {
        Response response = resource.getWorkflowYaml("saga2-transfer-workflow");
        assertEquals(Response.Status.OK.getStatusCode(), response.getStatus());
        String yaml = (String) response.getEntity();
        assertNotNull(yaml);
        assertTrue(yaml.contains("id: saga2-transfer-workflow"));
    }

    @Test
    void testGetNonExistentWorkflow() {
        Response response = resource.getWorkflowSpec("non-existent-workflow-id", null);
        assertEquals(Response.Status.NOT_FOUND.getStatusCode(), response.getStatus());

        Response yamlResponse = resource.getWorkflowYaml("non-existent-workflow-id");
        assertEquals(Response.Status.NOT_FOUND.getStatusCode(), yamlResponse.getStatus());
    }
}

