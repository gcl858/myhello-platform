#!/usr/bin/env bash
# ==============================================================================
# offline-build.sh
#
# 作用：在斷網/無外網連線 (Air-Gapped / Offline) 環境中，
#       使用專案內建的離線套件庫進行完整編譯與打包
#
# 用法：
#   ./offline-build.sh                                  # 預設 dev profile (含 transfer-samples + transfer-mock)
#   ./offline-build.sh dev                              # 明確指定 dev profile
#   ./offline-build.sh prod                             # prod profile (排除 dev/ 子樹,自動 -DskipTests)
#   ./offline-build.sh prod -DskipTests                 # 額外傳遞 Maven 參數
#   ./offline-build.sh dev  -Dquarkus.log.level=DEBUG
#   ./offline-build.sh prod -DskipTests -Dquarkus.http.port=9090
# ==============================================================================

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
OFFLINE_REPO="${SCRIPT_DIR}/offline-packages/maven-repo"

# 解析第一個位置參數作為 profile(dev | prod),預設 dev
BUILD_PROFILE="dev"
MVN_EXTRA_ARGS=()
if [ $# -gt 0 ]; then
    FIRST_ARG="$1"
    case "${FIRST_ARG}" in
        dev|prod)
            BUILD_PROFILE="${FIRST_ARG}"
            shift
            ;;
    esac
fi

# 收集剩餘參數傳給 mvn
MVN_EXTRA_ARGS=("$@")

if [ ! -d "${OFFLINE_REPO}" ]; then
    echo "❌ 錯誤：找不到離線套件庫目錄: ${OFFLINE_REPO}"
    exit 1
fi

echo "================================================================="
echo "開始執行 100% 嚴格離線編譯與打包 (mvn clean package -o)"
echo "使用離線 Maven Repository: ${OFFLINE_REPO}"
echo "建置模式: -P ${BUILD_PROFILE} (dev 含 transfer-samples + transfer-mock;prod 不含)"
echo "================================================================="

# prod 模式自動加 -DskipTests(測試依賴 mock,而 prod 不該帶 mock)
MVN_CMD=(clean package -o "-Dmaven.repo.local=${OFFLINE_REPO}" "-P" "${BUILD_PROFILE}")
if [ "${BUILD_PROFILE}" = "prod" ]; then
    MVN_CMD+=(-DskipTests)
    echo "⚠️  prod 模式自動套用 -DskipTests(prod 測試應於外部 IT 環境執行)"
fi

mvn "${MVN_CMD[@]}" "${MVN_EXTRA_ARGS[@]}"

# ============================================================================
# [v2.0 Zero-Copy] 流程規格由 WorkflowSpecResource 原位動態探索
#   (免複製 sw.yaml 至 data/workflows/，保持模組單一目錄自治)
# ============================================================================

echo "================================================================="
echo "✅ 離線編譯與打包成功！"
echo "建置模式: ${BUILD_PROFILE}"
echo "產出物："
echo "  - distribution/transfer-app/target/quarkus-app/quarkus-run.jar"
echo "  - distribution/reconciliation-app/target/quarkus-app/quarkus-run.jar"
echo "================================================================="
