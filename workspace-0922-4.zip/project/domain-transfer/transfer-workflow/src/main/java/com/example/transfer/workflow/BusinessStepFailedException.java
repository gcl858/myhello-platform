package com.example.transfer.workflow;

/**
 * 業務步驟失敗例外 — saga4 標準補償 gate 用。
 *
 * <p>背景:MyOpenApiService 將業務/傳輸失敗吞為標準化 body (code != "100"),
 * forward operation state 在引擎視角仍算「成功完成」,導致標準補償
 * (compensatedBy) 誤將業務失敗的步驟納入補償集合。
 * FailureSignal 在 workflow 指示排除時拋出此例外,使該 forward state
 * 被引擎標記為失敗,其 compensatedBy 即被排除,僅補償真正成功的步驟。
 */
public class BusinessStepFailedException extends RuntimeException {

    private final String stepName;
    private final String businessCode;

    public BusinessStepFailedException(String stepName, String businessCode) {
        super("業務步驟失敗 step=" + stepName + ", code=" + businessCode);
        this.stepName = stepName;
        this.businessCode = businessCode;
    }

    public String getStepName() {
        return stepName;
    }

    public String getBusinessCode() {
        return businessCode;
    }
}
