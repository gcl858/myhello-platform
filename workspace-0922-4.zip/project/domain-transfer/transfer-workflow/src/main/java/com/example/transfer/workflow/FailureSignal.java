package com.example.transfer.workflow;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.enterprise.context.ApplicationScoped;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * FailureSignal - 全專案共用：標準補償語義閘門。
 *
 * <p>定位:通用機制元件,不含任何業務判斷。「什麼算成功」由各 workflow
 * 在 yaml 以 jq 運算式決定 (見下),本服務只負責「被告知失敗就拋錯」。
 *
 * <p>背景:部分服務 (如 MyOpenApiService) 將業務/傳輸失敗吞為標準化 body,
 * forward operation state 在引擎視角仍算「成功完成」,導致標準補償
 * (compensatedBy) 誤將業務失敗的步驟納入補償集合。本服務作為 forward
 * state 內第二個 action (workflow 端以 actionDataFilter useResults=false
 * 丟棄回傳,不污染 state data):被告知排除時拋出
 * {@link BusinessStepFailedException},使該 state 被引擎標記為失敗,
 * 其 {@code compensatedBy} 即被排除,僅補償真正成功的步驟。
 * 已寫入 state data 的前一 action 結果不受影響,後續判定與稽核照常可用。
 *
 * <p>各 workflow 引用範本 (判斷式按自家成功碼撰寫):
 * <pre>
 * functions:
 *   - name: failureSignal
 *     operation: 'service:com.example.transfer.workflow.FailureSignal::raiseIfExcluded'
 *     type: custom
 * states:
 *   - name: CallSomething
 *     type: operation
 *     compensatedBy: CompensateSomething
 *     onErrors:
 *       - errorRef: businessStepFailed   # errors 需定義 code 為
 *         transition:                     # com.example.transfer.workflow.BusinessStepFailedException
 *           compensate: true
 *           nextState: CheckCompensationResult
 *     actions:
 *       - name: callSomethingAction
 *         functionRef: {refName: callApiViaOpenAPI, arguments: {...}}
 *         actionDataFilter: {..., toStateData: '${ .somethingResult }'}
 *       - name: gateSomethingResult
 *         functionRef:
 *           refName: failureSignal
 *           arguments:
 *             stepName: "CallSomething"
 *             excluded: '${ .somethingResult.code != "100" }'  # 轉帳流成功碼
 *             # excluded: '${ .somethingResult.status != 0 }'  # 貸款/還款流成功碼
 *             businessCode: '${ .somethingResult.code }'
 *         actionDataFilter:
 *           useResults: false
 * </pre>
 */
@ApplicationScoped
public class FailureSignal {

    private static final Logger LOG = LoggerFactory.getLogger(FailureSignal.class);
    private static final ObjectMapper MAPPER = new ObjectMapper();

    /**
     * 多參數進入點 (對應 SonataFlow 反射將 arguments key 展開為獨立參數)。
     *
     * @param stepName 步驟名稱 (除錯/例外訊息用)
     * @param excluded 是否排除該步驟補償 (yaml 端 jq 已算好;兼容 Boolean 與 "true"/"false" 字串)
     *   註:參數不可命名為 result,會與 Kogito codegen 產生的 handler 內部變數衝突。
     * @param businessCode 業務回傳碼 (僅用於例外訊息與追查,不參與判斷)
     * @return {allowed: true} (workflow 端以 useResults=false 丟棄,僅為滿足簽章)
     * @throws BusinessStepFailedException 當 excluded 為真
     */
    public JsonNode raiseIfExcluded(String stepName, Object excluded, Object businessCode) {
        boolean fail = excluded instanceof Boolean b
                ? b
                : Boolean.parseBoolean(String.valueOf(excluded));
        String codeStr = businessCode != null ? String.valueOf(businessCode) : null;
        if (fail) {
            LOG.info("[FailureSignal] step={} 被排除補償, businessCode={}, 拋出排除訊號", stepName, codeStr);
            throw new BusinessStepFailedException(stepName, codeStr);
        }
        return MAPPER.createObjectNode().put("allowed", true);
    }
}
