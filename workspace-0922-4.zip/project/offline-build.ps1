# ==============================================================================
# offline-build.ps1  (Windows / PowerShell 版本, v1.2 加 prod/dev profile 支援)
#
# 作用：在斷網/無外網連線 (Air-Gapped / Offline) 環境中,
#       使用專案內建的離線套件庫進行完整編譯與打包
#
# 用法:
#   .\offline-build.ps1                            # 預設 dev profile
#   .\offline-build.ps1 dev                        # 明確指定 dev profile (含 transfer-samples + transfer-mock)
#   .\offline-build.ps1 prod                       # prod profile (排除 dev/ 子樹,自動 -DskipTests)
#   .\offline-build.ps1 prod -ForceTests           # prod 模式但強制跑測試 (罕見,會帶來 mock 缺失風險)
#   .\offline-build.ps1 prod -Dquarkus.http.port=9090
#   .\offline-build.ps1 dev  -SkipTests            # 跳過測試 (向後相容舊版 -SkipTests 旗標)
#   .\offline-build.ps1 -OfflineRepo D:\repo       # 自訂離線套件庫
#
# 向後相容:
#   - 第一個位置參數若非 dev/prod,視為 mvn 參數繼續往後傳遞 (對應舊版行為)
#   - -SkipTests 旗標會被當作 mvn 參數 -DskipTests 處理 (對應舊版 -SkipTests)
# ==============================================================================

[CmdletBinding()]
param(
    [Parameter(Position = 0)]
    [ValidateSet('dev', 'prod')]
    [string]$Profile = '',

    [string]$OfflineRepo,

    [switch]$ForceTests,

    [Parameter(ValueFromRemainingArguments = $true)]
    [string[]]$RemainingArgs
)

# 讓中文輸出正常顯示
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$OutputEncoding = [System.Text.Encoding]::UTF8
$ErrorActionPreference = 'Stop'

# 取得腳本所在目錄
$ScriptDir = $PSScriptRoot

# Profile 預設值: dev
if ([string]::IsNullOrEmpty($Profile)) {
    $Profile = 'dev'
}

# 若使用者未指定 -OfflineRepo,預設使用專案內的離線套件庫
if (-not $OfflineRepo) {
    $OfflineRepo = Join-Path -Path $ScriptDir -ChildPath 'offline-packages\maven-repo'
}

# 檢查離線套件庫是否存在
if (-not (Test-Path -LiteralPath $OfflineRepo -PathType Container)) {
    Write-Host "❌ 錯誤：找不到離線套件庫目錄: $OfflineRepo" -ForegroundColor Red
    exit 1
}

# 確認 mvn 指令可用
if (-not (Get-Command mvn -ErrorAction SilentlyContinue)) {
    Write-Host "❌ 錯誤：找不到 'mvn' 指令,請確認 Maven 已安裝並加入 PATH。" -ForegroundColor Red
    exit 1
}

Write-Host "================================================================="
Write-Host "開始執行 100% 嚴格離線編譯與打包 (mvn clean package -o)..."
Write-Host "使用離線 Maven Repository: $OfflineRepo"
Write-Host "建置模式: -P $Profile (dev 含 transfer-samples + transfer-mock;prod 不含)"
Write-Host "================================================================="

# 組合 Maven 命令參數
$mvnArgs = @('clean', 'package', '-o', "-Dmaven.repo.local=$OfflineRepo", '-P', $Profile)

# prod 模式預設 -DskipTests(測試依賴 mock,而 prod 不該帶 mock)
if ($Profile -eq 'prod') {
    if ($ForceTests) {
        Write-Host "⚠️  -ForceTests 啟用:prod 模式將跑測試。確認 mock 端點已於外部 IT 環境就緒。" -ForegroundColor Yellow
    } else {
        $mvnArgs += '-DskipTests'
        Write-Host "⚠️  prod 模式自動套用 -DskipTests(prod 測試應於外部 IT 環境執行)"
    }
}

# 合併剩餘參數
$mvnArgs += $RemainingArgs

# 執行 Maven
& mvn @mvnArgs
if ($LASTEXITCODE -ne 0) {
    Write-Host "❌ Maven 建置失敗,退出代碼: $LASTEXITCODE" -ForegroundColor Red
    exit $LASTEXITCODE
}

# ============================================================================
# [v2.0 Zero-Copy] 流程規格由 WorkflowSpecResource 原位動態探索
#   (免複製 sw.yaml 至 data\workflows\，保持模組單一目錄自治)
# ============================================================================

Write-Host "================================================================="
Write-Host "✅ 離線編譯與打包成功！"
Write-Host "建置模式: $Profile"
Write-Host "產出物："
Write-Host "  - distribution\transfer-app\target\quarkus-app\quarkus-run.jar"
Write-Host "  - distribution\reconciliation-app\target\quarkus-app\quarkus-run.jar"
Write-Host "================================================================="
