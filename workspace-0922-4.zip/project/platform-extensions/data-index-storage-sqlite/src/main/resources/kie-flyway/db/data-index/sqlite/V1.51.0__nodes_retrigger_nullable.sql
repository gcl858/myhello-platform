/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

-- V1.51.0__nodes_retrigger_nullable.sql (SQLite port)
-- 背景:標準 compensation 流程的補償節點事件未帶 retrigger,
--      Kogito NodeInstanceEntity.retrigger 為 nullable Boolean,
--      Hibernate 顯式寫入 NULL,違反 V1.45.1.1 的 NOT NULL 約束,
--      造成 Data Index nodes 寫入失敗、整個流程實例 500。
-- 作法:重建 nodes 表,retrigger 改為可空 (INTEGER DEFAULT 0),
--      既有 NULL 回填 0;其餘欄位、PK、FK、索引原樣保留。
-- boolean -> INTEGER (0/1), varchar -> TEXT.
-- 注意:本檔僅含交易性 DDL,不含 PRAGMA (Flyway 禁止混合交易/非交易語句)。

CREATE TABLE nodes_new (
    id                   TEXT NOT NULL,
    definition_id        TEXT,
    enter                TEXT,
    exit                 TEXT,
    name                 TEXT,
    node_id              TEXT,
    type                 TEXT,
    process_instance_id  TEXT NOT NULL,
    sla_due_date         TEXT,
    retrigger            INTEGER DEFAULT 0,
    error_message        TEXT,
    cancel_type          TEXT,
    input_args           TEXT,
    output_args          TEXT,
    PRIMARY KEY (id),
    FOREIGN KEY (process_instance_id) REFERENCES processes(id) ON DELETE CASCADE
);

INSERT INTO nodes_new (
    id, definition_id, enter, exit, name, node_id, type, process_instance_id,
    sla_due_date, retrigger, error_message, cancel_type, input_args, output_args
)
SELECT
    id, definition_id, enter, exit, name, node_id, type, process_instance_id,
    sla_due_date, COALESCE(retrigger, 0), error_message, cancel_type, input_args, output_args
FROM nodes;

DROP TABLE nodes;

ALTER TABLE nodes_new RENAME TO nodes;

CREATE INDEX IF NOT EXISTS idx_nodes_piid ON nodes(process_instance_id);
