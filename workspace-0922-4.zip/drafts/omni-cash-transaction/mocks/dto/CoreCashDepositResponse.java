package org.acme.transfer.api.features.dto;

public class CoreCashDepositResponse {
    public String track_id;
    public int status;
    public ErrorDetail[] errors;

    public CoreCashDepositResponse(String trackId, int status, String errorCode, String message) {
        this.track_id = trackId;
        this.status = status;
        this.errors = errorCode == null ? null : new ErrorDetail[]{new ErrorDetail(errorCode, message)};
    }
}