package org.acme.transfer.api.features.dto;

public class CoreCashDepositRequest {
    public String partyId;
    public String branchCode;
    public String transactionDate;
    public String transactionDateTime;
    public String postingDayType;
    public String postingDate;
    public String paymentSourceCode;
    public String operationType;
    public String amount;
    public String sequenceNumber;
    public String rollbackSequenceNumber;
}