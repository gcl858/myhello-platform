package org.acme.transfer.api.features.dto;

public class ErrorDetail {
    public String error_code;
    public String message;

    public ErrorDetail(String errorCode, String message) {
        this.error_code = errorCode;
        this.message = message;
    }
}