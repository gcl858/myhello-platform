# Omni Cash Transaction 規格書

版本：1.0.0
設計模式：Mode B，Parent + 2 Child Subflow
平台：SonataFlow / Kogito 10.2.0 / Quarkus 3.x

## §0 假設清單

| # | 假設 | 為何這樣假設 | 待確認問題 | 落地策略 |
|---|---|---|---|---|
| H1 | Parent 接受 11 個欄位，`originalSequenceNumber` 僅 B 必填 | 業務需求 §6.2 | 無 | internal OpenAPI schema + ValidateInput |
| H2 | Parent 使用新 convention：`status` int 0/1 + `finalStatus` string | Omni API response | 無 | OutputFinal stateDataFilter |
| H3 | `A` 路由正向繳款，`B` 路由取消 | BR-P02 | 無 | CheckIdempotencyResult 後獨立 Dispatcher |
| H4 | 三個 workflow id 使用 snake_case；檔名保留 kebab-case | Kogito 10.2.0 subflow codegen | 無 | §8 Manifest 登記檔名與 id |
| H5 | Core 與 CreditCard 都是外部 host API，path param 為 `{creditcardid}` | 三份 API 文件 | 卡號欄位需確認是否等於 partyId | workflow payload 明確提供 `creditcardid` |
| H6 | API 範例中的 `paymentSourceCode=2500P` 優先於代碼表單一字元描述 | Omni/Core 範例 | 主機實際碼長度待確認 | pattern 允許 1-5 位大寫英數 |
| H7 | 原始序號 13 碼敘述與 20 碼範例矛盾時，以範例及現行 Parent 規則為準 | 需求文件互相矛盾 | 需主機確認正式長度 | schema 允許 13-22 碼，衍生 seq 使用 CA_/CC_ 前綴 |
| H8 | FQCN：`com.example.platform.distribution.transfer.IdempotencyService::findBySequenceNumber` | Parent 需 workflow 級冪等 | 需確認既有 bean | Handoff 新建 service，提供展開/Map/JsonNode 入口 |
| H9 | FQCN：`com.example.reconciliation.AuditLogService::findBySequenceNumber` | Child B 查原交易 | 需確認既有方法 | 擴充 AuditLogService，保留原始欄位 |
| H10 | FQCN：`com.example.reconciliation.AuditLogService::markCancelledBy` | 取消成功要標記原交易 | 需確認 signature | `workflowId` / `businessKey` 參數化，不寫死 workflow id |
| H11 | FQCN：`com.example.platform.security.MyOpenApiService::callOpenApi` 回傳 host 欄位於頂層 | 平台既有契約 | 無 | actionDataFilter 禁用 `.result.X` |
| H12 | FQCN：`com.example.reconciliation.OpsAlertService::raise` 需 6 參數 | 補償失敗須告警 | 無 | notifyOps 使用 workflowId/processInstanceId/businessKey/finalStatus/finalMessage/detail |
| H13 | mock 使用 `org.acme.transfer.api.features.dto` | transfer-mock antrun 同步目錄 | 無 | DTO 放 `mocks/dto/` 並使用 features package |
| H14 | 不使用 Kogito `dataInputSchema` | 驗證失敗仍須落 AuditLog | 無 | OpenApiSchemaValidator + CheckValidationResult |
| H15 | SQLite audit View 只讀實體欄位，業務欄位由 JSON 拆出 | 現有 V1.0.0 schema | 無 | V1.2.9 View + teardown |
| H16 | workflow timeout 依需求為 30 秒未知狀態，但本 draft 不建立查詢 host | 需求 §7.4/§9.1 | 查詢 API 尚未提供 | §9 明列限制，不虛構 endpoint |
| H17 | Parent 對外狀態含 SUCCESS/FAILED/ROLLED_BACK/CANCELLED/CANCEL_REJECTED/CANCEL_FAILED/LOOKUP_FAILED/ROLLBACK_FAILED/CANCEL_ROLLBACK_FAILED/IDEMPOTENT_REPLAY | 需求 §5.2 | 無 | status-rewrite mapping |
| H18 | `reason` 欄位尚未出現在四份 API request schema | 需求資料模型有 reason | 是否納入入口待業務拍板 | v1.0 不放 request required，audit 可保留 null |

## §1 概覽

唯一入口是 `/Omni/{creditcardid}/Repayment/Execute`。Parent 先驗證、檢查冪等，再以獨立 switch 將 A/B 委派到兩個 child。Child A 執行 Core → CreditCard，Child B 執行 lookup → Core rollback → CreditCard rollback。

## §2 輸入輸出

### §2.1 SSOT

輸入與輸出 schema 位於 `specs/internal/omni-counter-repayment-api.yaml`。Host schema 分別位於 `specs/external/core-account-cash-deposit-api.yaml` 與 `specs/external/credit-card-repayment-api.yaml`。

### §2.2 驗證

Parent 使用 `OpenApiSchemaValidator::validate` 的 operation state，接著由 `CheckValidationResult` 導向 `InjectValidationFailedStatus` 與 `FinalAuditAndEnd`。不使用 `dataInputSchema`。

### §2.3 終態對映

| finalStatus | HTTP | status |
|---|---:|---:|
| SUCCESS / CANCELLED / IDEMPOTENT_REPLAY | 200 | 0 |
| FAILED / ROLLED_BACK / CANCEL_REJECTED / CANCEL_FAILED | 200 | 1 |
| REJECTED_VALIDATION | 400 | 1 |
| LOOKUP_FAILED | 500 | 1 |
| ROLLBACK_FAILED / CANCEL_ROLLBACK_FAILED | 409 | 1 |

## §3 Workflow

- Parent：`omni_cash_transaction`
- Child A：`repayment_cash_deposit`
- Child B：`repayment_cash_cancellation`

三者 version 都是 `1.0.0`，subFlowRef 完全對齊。

## §4 Service 與 validator

需複用/擴充 `AuditLogService`、`OpsAlertService`、`MyOpenApiService`，並新建 `IdempotencyService`；若既有 OpenAPI validator 未支援條件必填，需註冊 `OmniCashBusinessRuleValidator`，覆蓋 B + originalSequenceNumber 規則。

## §5 資料庫

`db/migration/V1.2.9__create_view_omni_cash_transaction_reconciliation.sql` 建立對帳 View；不新增不存在於 audit entity 的欄位。`db/teardown.sql` 負責抽離 View。

## §6 測試矩陣

P1 驗證失敗、A1 正向成功、P4 冪等重送、B1 取消成功、B2 查無原交易。測試固定 package 為 `com.example.platform.distribution.transfer.features`。

## §7 組態

見 `config/application.properties.snippet`，含 status-rewrite、bean binding 與 dev/prod base URL fallback 註記。

## §8 Project Mapping Manifest

| Draft 檔案 | 下游正式路徑 |
|---|---|
| `feature.yaml` | `project/features/omni-cash-transaction/feature.yaml` |
| `workflows/*.sw.yaml` | `project/domain-transfer/transfer-workflow/src/main/resources/` |
| `specs/internal/*.yaml` | `project/domain-transfer/transfer-workflow/src/main/resources/specs/internal/`，並同步 distribution app |
| `specs/external/*.yaml` | `project/domain-transfer/transfer-workflow/src/main/resources/specs/external/`，並同步 distribution app |
| `mocks/*.java` | `project/dev/transfer-mock/src/main/java/org/acme/transfer/api/` |
| `mocks/dto/*.java` | `project/dev/transfer-mock/src/main/java/org/acme/transfer/api/features/dto/` |
| `db/migration/*.sql` | `project/domain-reconciliation/reconciliation-api/src/main/resources/db/migration/` |
| `config/application.properties.snippet` | `project/distribution/transfer-app/src/main/resources/application.properties` |
| `tests/*.java` | `project/distribution/transfer-app/src/test/java/com/example/platform/distribution/transfer/features/` |

### 檔名-ID Manifest

| 檔名 | YAML id |
|---|---|
| `omni-cash-transaction.sw.yaml` | `omni_cash_transaction` |
| `repayment-cash-deposit.sw.yaml` | `repayment_cash_deposit` |
| `repayment-cash-cancellation.sw.yaml` | `repayment_cash_cancellation` |

## §9 已知限制

1. timeout 後的未知狀態查詢 API 未在來源文件定義，本 draft 不虛構 host operation。
2. `reason` 尚未出現在入口 API，v1.0 先不強制要求。
3. 序號長度需主機確認；目前以 schema 限制保護明顯異常值。

## §10 下游整併門禁

執行 `preflight-checks.js` 全量檢查；確認 errors/errorRef、unreachable state、notifyOps 6 參數、DTO features package、View 實體欄位與 16 項平台預檢全綠後，再交給 `sonataflow-integration`。

## §11 自治架構對齊矩陣

| 項目 | 本 draft 決策 |
|---|---|
| 平台 | SonataFlow/Kogito 10.2.0 |
| 落點 | `drafts/omni-cash-transaction/` |
| OpenAPI | internal/external 二分 |
| DB | SQLite，接續 V1.2.8 為 V1.2.9 |
| Mock DTO | `org.acme.transfer.api.features.dto` |
| 測試 | `com.example.platform.distribution.transfer.features` |