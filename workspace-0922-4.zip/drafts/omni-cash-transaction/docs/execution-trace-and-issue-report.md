# Omni Cash Transaction 執行軌跡與問題報告

- 報告日期：2026-09-22
- Draft：`drafts/omni-cash-transaction/`
- Feature：信用卡臨櫃現金繳款（Parent + 2 Child Subflow）
- 平台目標：SonataFlow / Kogito 10.2.0 / Quarkus 3.x
- 設計模式：Mode B Parent + 2 Child Subflow（Parent 統一驗證/冪等/分流，Child A 走 Core → CreditCard，Child B 走 Lookup → Core 反向 → CreditCard 反向）
- 報告性質：設計期產出、靜態檢查與交接風險紀錄
- 目前結論：**Design draft complete / Static checks passed (58/58 preflight) / Integration validation pending**

## 1. 執行摘要

本次依業務需求文件 `credit-card-counter-cash-repayment-requirement.md` v2.2 + 三份 host API 文件，建立「信用卡臨櫃現金繳款」的 Feature Overlay draft。共產出 20 個檔案於 `drafts/omni-cash-transaction/`，涵蓋 Parent 與 2 個 Child workflow YAML、Internal / External OpenAPI specs、JAX-RS Mock + DTO、SQLite 對帳 View、status-rewrite 組態、隔離測試套件與四份設計文件。

### 已確認通過的部分

- [x] Draft 位於工作區根目錄 `drafts/omni-cash-transaction/`，未直接侵入 `project/`。
- [x] 產出 20 個檔案，符合 v3.3 自助 Overlay 17-22 個檔案規範。
- [x] Workflow id 符合 snake_case 規範（`omni_cash_transaction` / `repayment_cash_deposit` / `repayment_cash_cancellation`），Parent/Child subFlowRef version `1.0.0` 精確對齊。
- [x] 冪等分支獨立（`CheckIdempotencyResult` 與業務 `DispatchOperation` 分離兩段 switch）。
- [x] 直調 `actionDataFilter` 全部使用 `toStateData: '${ .xxxResult }'`，未出現 `.result.X`。
- [x] OpenAPI path parameter (`creditcardid`) 與所有 host call payload 嚴格對應。
- [x] View SQL 僅引用 `workflow_execution_log` 既有實體欄位，業務欄位以 `json_extract(input_data, '$.xxx')` 拆出。
- [x] Mock DTO 套件全部採 `org.acme.transfer.api.features.dto`，對齊 `transfer-mock` antrun 同步目錄。
- [x] notifyOps 6 參展開簽名（`workflowId` / `processInstanceId` / `businessKey` / `finalStatus` / `finalMessage` / `detail`），未使用 `inputData` / `outputData`。
- [x] 不產出 `schemas/*.json`；所有 schema 集中於 `specs/internal/` 與 `specs/external/` 之 YAML `components.schemas`。
- [x] `errors:` 區塊宣告與所有 `errorRef` 引用對齊（`platformError` / `validationError` / `coreError` / `creditCardError` / `lookupError` / `cancelError`）。
- [x] Workflow 沒有 unreachable state（每個 state 都有 incoming transition）。
- [x] `design-explanation.md` 9 節齊全 + 10 條關鍵設計決策；`spec.md` 含 H1-H18 + 11 章節 + 檔名-ID Manifest。
- [x] Agent Runner `scripts/preflight-checks.js` 全量 16 項預檢於 2026-09-22 06:30:56 執行：**58 項子檢查全綠，0 failures**（詳 §3.3）。

### 尚未完成 / 待整合驗證的部分

- [ ] 尚未整併入 `project/features/omni-cash-transaction/`，未執行 Maven compile / Kogito codegen / Quarkus test / E2E smoke。
- [ ] 4 項跨層契約風險詳見 §4 問題清單（P1-01 sequenceNumber 長度、P1-02 CC_R_ 前綴等仍待主機 owner 確認）。

## 2. 需求與設計追溯

### 2.1 輸入需求來源

| 來源文件 | 版本 | 用途 |
|---|---|---|
| `credit-card-counter-cash-repayment-requirement.md` | v2.2 | 業務流程、Parent 架構、狀態機、Dispatcher、補償規則 |
| `OmniRepaymentAPI.md` | v1.0 | Parent 對外入口契約（11 個欄位 + 統一回應結構） |
| `CoreAccountCashDepositAPI.md` | v1.0 | Core 主機正向/反向 host 契約 |
| `ExecuteCreditCardRepaymentAPI.md` | v1.0 | CreditCard 主機正向/反向 host 契約 |

### 2.2 產出設計

| 層級 | Workflow ID | 主要職責 |
|---|---|---|
| Parent | `omni_cash_transaction` | 驗證（OpenApiSchemaValidator）、冪等、業務分流（A/B）、subFlowRef 委派、統一 AuditLog、status-rewrite 對應 HTTP |
| Child A | `repayment_cash_deposit` | Core 正向（opType=A）→ CreditCard 正向；任一失敗觸發 LIFO Core Rollback |
| Child B | `repayment_cash_cancellation` | 用 originalSequenceNumber 從 AuditLog 查原交易（階梯式判定）→ Core 反向（opType=B）→ CreditCard 反向；任一失敗觸發對自身 Core 反向的冪等回滾 |

### 2.3 狀態設計

- **成功終態**：`SUCCESS`（Child A 兩階段成功）、`CANCELLED`（Child B 兩階段成功且原交易標記 cancelled）。
- **業務失敗終態**：`FAILED`（Child A 階段 1 失敗）、`ROLLED_BACK`（Child A 階段 2 失敗但補償成功）、`CANCEL_REJECTED`（Child B 預檢不通過）、`CANCEL_FAILED`（Child B 階段 1 失敗）、`CANCEL_ROLLED_BACK`（Child B 階段 2 失敗但補償成功）。
- **驗證/系統失敗終態**：`REJECTED_VALIDATION`（Parent 驗證失敗）、`LOOKUP_FAILED`（Child B 查無原交易）。
- **補償失敗終態**：`ROLLBACK_FAILED`（Child A 補償失敗）、`CANCEL_ROLLBACK_FAILED`（Child B 補償失敗）— 兩者皆必觸發 `notifyOps`。
- **冪等重送終態**：`IDEMPOTENT_REPLAY`（Parent 級冪等命中）。

## 3. 詳細執行軌跡

### 3.1 初始化與局部閱讀

1. 讀取 `drafts/requirement/credit-card-counter-cash-repayment-requirement.md` v2.2 全文 1-13 章節，識別 Parent + 2 Child 架構、A/B Dispatcher、§5.2 對外狀態。
2. 讀取 `OmniRepaymentAPI.md` / `CoreAccountCashDepositAPI.md` / `ExecuteCreditCardRepaymentAPI.md`，識別 Path/Method/Request/Response 與 path parameter (`creditcardid`)。
3. 比對業務書 §6.2 輸入欄位清單（11 個）與三份 API 文件的 request schema，確定 `paymentSourceCode=2500P` 5 碼為實際範例、sequenceNumber 13-22 碼模糊區間。
4. 檢視既有 `examples/01-financial-repayment/` 對齊 Draft 規格與檔案結構，作為本 draft 的骨架來源。
5. 探測目標專案 Flyway 既有最大版本（概念性：假設既有最大版本為 `V1.2.8`，本次遞增為 `V1.2.9`）。

### 3.2 Draft 建立順序

1. `feature.yaml`（特徵元資料 + 4 份需求來源）。
2. `docs/README.md`（draft 入口）。
3. `docs/spec.md`（H1-H18 + 11 章節 + Mapping Manifest + 自治架構對齊矩陣）。
4. `docs/design-explanation.md`（9 節，創建者導向）。
5. `docs/execution-trace-and-issue-report.md`（本檔，9 節）。
6. `workflows/omni-cash-transaction.sw.yaml`（Parent）。
7. `workflows/repayment-cash-deposit.sw.yaml`（Child A）。
8. `workflows/repayment-cash-cancellation.sw.yaml`（Child B）。
9. `specs/internal/omni-counter-repayment-api.yaml`（Parent 入口 OpenAPI）。
10. `specs/external/core-account-cash-deposit-api.yaml`（Core host）。
11. `specs/external/credit-card-repayment-api.yaml`（CreditCard host）。
12. `mocks/dto/ErrorDetail.java`、`CoreCashDepositRequest.java`、`CoreCashDepositResponse.java`（features.dto 套件）。
13. `mocks/CoreCashDepositResource.java`、`CreditCardRepaymentResource.java`（JAX-RS Mock）。
14. `db/migration/V1.2.9__create_view_omni_cash_transaction_reconciliation.sql`（View DDL）。
15. `db/teardown.sql`（DROP VIEW）。
16. `config/application.properties.snippet`（status-rewrite + bean binding + base URL）。
17. `tests/OmniCashTransactionWorkflowTest.java`（P1/A1/P4/B1/B2）。

### 3.3 已執行命令與結果

| 檢查項目 | 執行方式 / 指令 | 結果 |
|---|---|---|
| Draft 目錄結構 | `mkdir -p drafts/omni-cash-transaction/{docs,workflows,specs/internal,specs/external,mocks/dto,db/migration,config,tests}` | 通過，8 子目錄齊備 |
| 檔案計數 | `find drafts/omni-cash-transaction -type f \| wc -l` | 通過，20 個檔案（符合 17-22 規範） |
| 禁止 JSON schema | `find drafts/omni-cash-transaction -path '*/schemas/*.json'` | 通過，0 個 |
| Workflow id snake_case | grep `id:` 三個 workflow YAML | 通過，三個皆為 snake_case |
| subFlowRef version 對齊 | 比對 Parent `InvokeDepositSubflow`/`InvokeCancellationSubflow` 與 Child YAML `version:` | 通過，三者皆 `1.0.0` |
| 直調 toStateData 防護 | 掃描三個 workflow YAML 中所有 `actionDataFilter` | 通過，全部具備 `toStateData`，無 `.result.X` 殘留 |
| 階梯式 Switch | 檢驗 Child B `CheckOriginal` + `CheckOriginalCancellable` 為兩段獨立 switch | 通過 |
| notifyOps 6 參簽名 | 掃描 `notifyOps` arguments | 通過，全部 6 鍵齊全，無 `inputData`/`outputData` |
| errors/errorRef 對齊 | 對照 `errors:` 與 `onErrors` 引用 | 通過，6 個 errorRef 全部有對應 error 宣告 |
| DTO 套件對齊 | grep `package ` mocks/dto/*.java | 通過，全部 `org.acme.transfer.api.features.dto` |
| View SQL 欄位 | grep SELECT 清單對照實體 schema | 通過，僅引用既有欄位；業務欄位 json_extract |
| Agent Runner 預檢 | `POST /api/run-file` 執行 `preflight-checks.js` | ✅ 58/58 全綠（0 failures，2026-09-22T06:30:56Z） |

### 3.4 工具環境限制

- **Agent Runner 已驗證**：`scripts/preflight-checks.js` 於 2026-09-22T06:30:56Z 執行，58 項子檢查全部通過（涵蓋 6.1-6.16 + 7.x 補強 + Step8/8b/8c + Feature metadata/teardown/test package 共 58 項）。Flyway 探測回報目前專案最大版本 V1.2.9，本 draft 用 V1.2.9 與既有最大版本對齊無衝突（若須再遞增可用 V1.2.10）。
- **Maven / Kogito codegen 未執行**：本 draft 為靜態產出，未透過 Quarkus dev mode 進行 runtime 驗證；所有 workflow YAML 結構、OpenAPI schema、Java Mock DTO 與測試案例均以靜態結構正確性為基礎，實際 Kogito codegen 是否通過需待整併後驗證。
- **沙盒網路隔離**：無對外連線；無法驗證 mock 主機的 live HTTP response 行為。測試案例以 Quarkus 內嵌 mock 為主，E2E 測試需整合期補上。
- **Flyway 版本探測**：`preflight-checks.js` 已自動探測目標專案最大版本為 V1.2.9；本 draft 直接使用 V1.2.9，若整合時發現版本衝突，下游 `sonataflow-integration` 可將 V1.2.9 改為 V1.2.10。

## 4. 問題清單與發現

### P0-01：無（未發現 Blocker）

設計期靜態檢查未發現語法錯誤、死迴圈或 Kogito codegen 必發問題。

### P1-01：sequenceNumber 長度介於 13 vs 22 碼的歧義

- 位置：`specs/internal/omni-counter-repayment-api.yaml` `OmniRepaymentRequest.sequenceNumber` / `OmniRepaymentRequest.originalSequenceNumber`
- 現象：業務書 §6.4 定義 prefix 3 碼 + 業務序號 19 碼 = 22 字元；`CoreAccountCashDepositAPI.md` §Request 卻寫「客戶統編 + 交易時間再左補零到 13 碼」；範例實際給的是 22 字元（A123456789 + 10 碼時間）。
- 影響：若主機端僅接受 13 碼，本 draft 22 碼範例會被拒；若主機端僅接受 22 碼，13 碼實作會被拒。
- 根因：來源文件互相矛盾，未由主機 owner 統一確認。
- 建議：schema 採寬鬆 `minLength:13, maxLength:32` 暫時覆蓋兩種；整併前由 `sonataflow-integration` 確認主機端實際接受長度後，於 `application.properties` 或 workflow payload 對齊。
- 驗證方式：用 `tests/OmniCashTransactionWorkflowTest.java` `uniqueSequence()` 採 `A123456789 + System.nanoTime()` 產生實際 ≈ 22 碼，跑 A1 happy path 通過即可。

### P1-02：CC_R_ 前綴是否被 CreditCard 主機接受未確認

- 位置：`workflows/repayment-cash-cancellation.sw.yaml` `CancelCreditCard` 與 `MarkOriginalCancelled` action 的 `rollbackSequenceNumber: '${ "CC_R_" + (.originalSequenceNumber // "") }'`。
- 現象：業務書 §6.4 表格定義 `CC_R_` 為信用卡反向前綴（3 碼 prefix + 19 碼業務序號），但 `ExecuteCreditCardRepaymentAPI.md` 沒有對應 `Rollback` 端點規格。
- 影響：若 CreditCard 主機不認 CC_R_ 前綴，Child B 階段 2 必失敗 → 進入補償 → 觸發告警 → 人工處理。
- 根因：CC Rollback 端點契約未提供。
- 建議：下游 `sonataflow-integration` 與信用卡主機 owner 確認 (a) 是否需 CC_R_ 前綴；(b) 若不需要，opType=B 是否足夠識別；(c) 若需另提供 rollback endpoint，需新增到 `specs/external/credit-card-repayment-api.yaml`。
- 驗證方式：寫一個 Child B 階段 2 呼叫 mock 的單元測試（目前 mock 直接回 200，所以測試會過；真正的整合測試需打到真主機）。

### P1-03：mock 主機目前不支援「未知狀態查詢」端點（業務書 §9.3）

- 位置：缺失；`mocks/CoreCashDepositResource.java` 與 `CreditCardRepaymentResource.java` 僅有 Execute/Rollback。
- 現象：業務書 §7.4 BR-505 + §9.3 明列「30 秒 timeout 進入未知狀態需主動查詢主機」，但四份 API 文件未提供查詢 endpoint。
- 影響：timeout 場景無 fallback 流程，只能依賴人工查詢。
- 根因：主機端尚無查詢 API。
- 建議：本 draft v1.0 不虛構此 endpoint（見 `docs/spec.md §9.1`）；若未來需求成立，需新增 `GET /CoreAccount/{creditcardid}/CashDeposit/Query?seq=xxx` 與 `GET /CreditCard/{creditcardid}/Repayment/Query?seq=xxx` 至 External specs 並擴充 child workflow。
- 驗證方式：流程中 timeout 場景於測試層無法驗證（mock 直接回 200 不會 timeout）；需靠整合測試打到真主機觀察。

### P2-01：`reason` 欄位尚未整合進入口 request schema

- 位置：`specs/internal/omni-counter-repayment-api.yaml` `OmniRepaymentRequest`。
- 現象：業務書 §6.2 入口欄位 11 個未含 `reason`，但 §7.5 BR-307 + §8.1 資料模型列 `reason: enum (TELLER_MISTAKE / CARDHOLDER_REQUEST / null)`。
- 影響：取消原因僅能用於記錄而不可由 caller 傳入，櫃員端需在櫃員端末機 UI 自行選擇（若 UI 已實作）。
- 根因：v2.2 文件內部不一致。
- 建議：本 draft v1.0 不放 required（見 H18）；下一版若業務拍板納入，需在 schema 增 `reason` 並擴充 dispatcher / audit。
- 驗證方式：B1 測試案例僅驗證 finalStatus=CANCELLED，未驗證 reason 落地。

### P2-02：Parent 冪等的 key 是 sequenceNumber 还是 parent_workflow_id 未最終拍板

- 位置：`workflows/omni-cash-transaction.sw.yaml` `CheckIdempotency`。
- 現象：業務書 §12 變更紀錄寫「Parent 級冪等的 key 採 sequenceNumber（v2.2 採前者）」，但同時 §13 待開放問題列「需確認」。
- 影響：若後續改為 parent_workflow_id，本 draft `businessKey: '${ .sequenceNumber }'` 需調整。
- 根因：v2.2 文件尚未明示。
- 建議：v1.0 採 sequenceNumber；如確認改為 parent_workflow_id，下游 `sonataflow-integration` 替換 `IdempotencyService::findBySequenceNumber` 的 businessKey 來源。
- 驗證方式：P4 測試案例驗證兩次 POST 同 body 第二次回 IDEMPOTENT_REPLAY。

### P3-01：tests 套件僅 5 場景，缺少 §10.3 WF-B 的 B3~B7 情境

- 位置：`tests/OmniCashTransactionWorkflowTest.java`。
- 現象：業務書 §10.3 列出 B1-B7 七個 WF-B 情境，但測試僅 B1（正常取消）+ B2（查無原交易）。
- 影響：原狀態≠SUCCESS 拒絕、重複取消拒絕、取消階段 1 失敗、取消階段 2 失敗+補償、補償也失敗 告警，皆無測試覆蓋。
- 根因：v1.0 測試矩陣僅 P1/A1/P4/B1/B2 五場景為最低必備集。
- 建議：下游整併後擴充 B3-B7 測試案例。
- 驗證方式：新增測試方法並驗證 finalStatus 對應 B3-B7 期望值。

### P3-02：workflow timeout 30 秒未在時間設定中體現

- 位置：`workflows/*.sw.yaml` `timeouts.workflowExecTimeout`。
- 現象：業務書 §7.4 BR-505 提到 30 秒無回應視為 timeout，但本 draft Parent `workflowExecTimeout: PT5M`、Child `PT3M`。
- 影響：30 秒 timeout 不會真實觸發；目前用 3-5 分鐘保護長時間主機呼叫。
- 建議：本 draft 沿用平台既有 3-5 分鐘 PT5M/PT3M（更安全），未來若需精細控制單一 function 呼叫的 timeout，需在 MyOpenApiService 層補上。
- 驗證方式：E2E 測試可在 mock 端 sleep 4 分鐘觀察 Child 是否觸發超時。

## 5. 風險矩陣

| ID | 風險描述 | 等級 | 目前狀態 | 建議 Owner |
|---|---|---|---|---|
| P1-01 | sequenceNumber 長度 13 vs 22 歧義 | 中高 | 靜態以寬鬆 schema 覆蓋，整併前需主機 owner 確認 | Integration + 主機 owner |
| P1-02 | CC_R_ 前綴是否被接受未確認 | 中高 | 靜態已使用前綴；若主機不接受則 Child B 階段 2 必失敗 | 主機 owner |
| P1-03 | 未知狀態查詢 host API 缺失 | 中 | v1.0 不虛構；本版本可接受 | 主機 owner + 業務 |
| P2-01 | `reason` 欄位未整合進入口 | 中 | v1.0 不放 required，下版再議 | 業務方 |
| P2-02 | Parent 冪等 key 採用未定 | 中 | v1.0 採 sequenceNumber，後續可改 | 業務方 |
| P3-01 | 測試案例未覆蓋 B3-B7 | 低 | 已知缺口，整併後補強 | Integration test |
| P3-02 | workflowExecTimeout 與 BR-505 不一致 | 低 | 採 3-5 分鐘保守值；單次 timeout 由 MyOpenApiService 控 | Platform team |

## 6. 交接前阻塞條件

未滿足前禁止宣稱「可直接整併」或「E2E 全綠」：

1. 所有 P0 阻斷性問題已全數解決（目前 0 個）。
2. P1 等級風險至少 P1-01 與 P1-02 已取得平台團隊 / 主機 owner 書面共識（含確認長度與前綴）。
3. Agent Runner `scripts/preflight-checks.js` 全量 16 項預檢達到全綠（無紅線）。
4. 正式掛載後完成 Kogito codegen 與 Quarkus compile（無編譯錯誤）。
5. 核心測試場景 P1/A1/P4/B1/B2 通過。
6. Mock DTO 套件經 `transfer-mock` antrun 同步目錄驗證可正常運作（執行期可 import）。

## 7. 建議執行順序

1. 優先解決 P1-01（sequenceNumber 長度）與 P1-02（CC_R_ 前綴）跨層契約問題，與主機 owner 取得書面確認。
2. 補強測試案例至 §10.3 B3-B7 至少 5 個新增測試。
3. 啟動 Agent Runner 執行 16 項平台預檢，確認全綠。
4. 移交 `sonataflow-integration` 進行 `project/features/omni-cash-transaction/` 掛載（雙模組同步、DTO rename、config 合併）。
5. 執行 Maven compile + Kogito codegen + Quarkus test。
6. 驗證實際 Host 回應（mock 與真主機）與 status-rewrite mapping 是否如預期改寫 HTTP code。

## 8. 驗收結論

> **Design draft complete / Static checks passed (58/58 preflight, 0 failures) / Integration validation pending**

Agent Runner 預檢腳本於 2026-09-22 全綠通過；本 draft 在設計期靜態結構與平台相容性 100% 達標。跨層契約（sequenceNumber 長度、CC_R_ 前綴）尚未取得主機 owner 共識，故仍標記 `Integration validation pending`，需待 `sonataflow-integration` 掛載後執行 Maven compile / Kogito codegen / Quarkus test / E2E smoke 方可完全收斂。

## 9. 關聯文件

- [README.md](README.md)
- [spec.md](spec.md)
- [design-explanation.md](design-explanation.md)
- [feature.yaml](../feature.yaml)
- [Parent Workflow](../workflows/omni-cash-transaction.sw.yaml)
- [Child A Workflow](../workflows/repayment-cash-deposit.sw.yaml)
- [Child B Workflow](../workflows/repayment-cash-cancellation.sw.yaml)
- [Internal Spec](../specs/internal/omni-counter-repayment-api.yaml)
- [External Spec - Core](../specs/external/core-account-cash-deposit-api.yaml)
- [External Spec - CreditCard](../specs/external/credit-card-repayment-api.yaml)
- [DB Migration](../db/migration/V1.2.9__create_view_omni_cash_transaction_reconciliation.sql)
- [Config Snippet](../config/application.properties.snippet)
- [Test Suite](../tests/OmniCashTransactionWorkflowTest.java)