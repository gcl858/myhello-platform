# 信用卡臨櫃現金繳款 Workflow Draft — 設計說明書

> 給創建者看的文件：解釋「這份 draft 是怎麼被設計出來的」
> 日期：2026-09-22
> 對應業務書：`drafts/requirement/credit-card-counter-cash-repayment-requirement.md` v2.2
> 對應產出：`drafts/omni-cash-transaction/`（20 個檔案）
> 目標平台：SonataFlow / Kogito 10.2.0，整合目標 `project/features/omni-cash-transaction/`

## 0. 導讀（3 分鐘版）

- 業務要什麼：信用卡臨櫃現金繳款的單一 API 入口，自動把正向繳款與當日取消分別送給兩個主機（核心帳務、信用卡主機）並保證兩階段最終一致。
- 選了什麼模式：**Mode B Parent + 2 Child Subflow**（Parent 統一驗證、冪等、分流；Child A 走 Core → CreditCard；Child B 走 Lookup → Core 反向 → CreditCard 反向）。
- 有幾個檔案：20 個（含 3 workflow YAML、3 OpenAPI、4 Mock/DTO、2 SQL、1 config、1 test、4 docs、1 feature.yaml）。
- 最易誤會的決策：**Parent 必須做完驗證與冪等再委派**；Child 不可各自為政驗證，避免 Audit Gap；冪等命中與業務分流必須拆兩個獨立 Switch 防止 jBPM 無序性誤判。
- 還沒確定的事：sequenceNumber 正式長度（13 vs 22）、是否納入 `reason`、核心/信用卡主機是否提供「依 seq 查狀態」端點（影響 §7 假設）。

## 1. 背景與目標

### 痛點（業務書 §1.2）

| 痛點 | 來源 |
|---|---|
| 單一入帳，現金只進信用卡帳未進核心總帳 | 櫃員端末機手動流程 |
| 無統一入口，繳款與取消走不同端點 | 呼叫端邏輯分散 |
| 無統一取消機制 | 櫃員打錯卡無標準反向流程 |
| 無對帳軌跡 | 失敗、重試、補償無系統化紀錄 |

### draft 目標（§1.3）

- 單一 API 入口，以 `operationType` 區分正反向（A 路由正向、B 路由反向）。
- 兩台主機最終一致（任一失敗自動補償並告警）。
- Parent 統一審計軌跡（一筆交易一個 parent row）。
- 取消流程標準化且 idempotent（防重複取消）。

### 不做什麼（Out-of-Scope，§2.2）

跨日退款、預授權、外幣繳款、非臨櫃通路。

## 2. 輸入來源

### 業務文件

| 檔案 | 版本 | 角色 |
|---|---|---|
| `drafts/requirement/credit-card-counter-cash-repayment-requirement.md` | v2.2 | 業務流程、狀態機、Dispatcher 與資料模型 |
| `drafts/requirement/OmniRepaymentAPI.md` | v1.0 | Parent 對外入口契約 |
| `drafts/requirement/CoreAccountCashDepositAPI.md` | v1.0 | Core 主機正向/反向 host 契約 |
| `drafts/requirement/ExecuteCreditCardRepaymentAPI.md` | v1.0 | CreditCard 主機正向/反向 host 契約 |

### Step 0 自治架構對齊矩陣

| 項目 | 本 draft 決策 |
|---|---|
| 平台 | SonataFlow / Kogito 10.2.0（Quarkus 3.x） |
| 落點 | `drafts/omni-cash-transaction/` |
| Internal OpenAPI | `specs/internal/omni-counter-repayment-api.yaml`（Parent 入口，必含 `x-workflow-id`） |
| External OpenAPI | `specs/external/core-account-cash-deposit-api.yaml` + `credit-card-repayment-api.yaml`（無 `x-workflow-id`） |
| Flyway | 接續 V1.2.8，本 draft 用 `V1.2.9__create_view_omni_cash_transaction_reconciliation.sql` |
| Mock DTO | `org.acme.transfer.api.features.dto`（對齊 transfer-mock antrun 同步目錄） |
| 測試 package | `com.example.platform.distribution.transfer.features` |

## 3. 從需求到設計

### 業務職責 → state 對應

| 業務職責（需求 §4.0.1） | 對應 state |
|---|---|
| P1 輸入驗證 | `ValidateInput` (operation) + `CheckValidationResult` (switch) |
| P2 operationType Dispatcher | `DispatchOperation` (switch，A/B 路由） |
| P3 冪等性檢查 | `CheckIdempotency` + `CheckIdempotencyResult`（獨立 switch） |
| P4 委派執行 | `InvokeDepositSubflow` / `InvokeCancellationSubflow`（subFlowRef） |
| P5 統一稽核 | `FinalAuditAndEnd`（recordAuditLog 5 參契約） |
| P6 統一回應 | `FinalAuditAndEnd.stateDataFilter.output`（Parent 新 convention） |
| P7 補償治理 | Child 內 `RollbackCore` / `RollbackCancelCore` |
| P8 告警 | `NotifyRollbackFailure`（notifyOps 6 參契約） |

### 模式選擇理由

為何選 **Mode B Parent + 2 Child Subflow**？

| 候選模式 | 為何不選 |
|---|---|
| Mode A 單層 Saga LIFO | 業務明確區分正反向（forward/cancel），用單一 workflow 會讓 cancel 路徑混在 forward 內，狀態機與審計語意不清。 |
| Mode C 多層 Parent | 業務僅兩層（Parent + Child），無需第三層。 |
| Mode D 事件驅動 | 業務屬同步 API 觸發，非實驗性事件流。 |
| Mode E 排程 | 業務無計時/排程需求。 |

Mode B 完美對應「Parent 統一收單 + Child 各自委派」的職責切分，並支援 BR-P02 dispatcher 與 §5.2 對外狀態統一的雙重要求。

### 回應 convention 決策

採用 **Parent 新 convention**：`status: int 0/1` + `finalStatus: string`（業務書 §6.3 範例明示 `status: 0 | 1`），配合 `status-rewrite` mapping 把對應 finalStatus 改寫為 HTTP code。理由是：

1. 業務書 §6.3 統一回應結構明確要求 `status: 0 | 1`。
2. 平台 `WorkflowStatusFilter` 已支援萬用字元 fallback，下游只需一次性 mapping。

Child 採 **「僅 finalStatus」** convention（見 7.6/Step 3d），Parent 端再負責把 Child finalStatus 整合到自己的對外回應。

## 4. 關鍵設計決策

### D1：Workflow id 用 snake_case、檔名保留 kebab-case

- 選了：snake_case id (`omni_cash_transaction` / `repayment_cash_deposit` / `repayment_cash_cancellation`)，檔名沿用 kebab-case (`omni-cash-transaction.sw.yaml`)。
- 為什麼：Kogito 10.2.0 subFlowRef codegen 在 hyphen id 會觸發 bug（平台預檢 6.1），檔名則在 Vert.x 動態路由載入時較友善。
- 沒選：全部 hyphen（會壞 codegen）、全部 snake_case（檔名會丟失語意可讀性）。
- 不這樣做的後果：Kogito 編碼失敗，subFlowRef 找不到對應 child，E2E 全壞。
- 在哪裡看到：`workflows/*.sw.yaml` + `docs/spec.md §8 檔名-ID Manifest`。

### D2：Parent 使用 `status: 0/1` + `finalStatus: STRING` 新 convention

- 選了：Parent `FinalAuditAndEnd.stateDataFilter.output` 同時輸出 `status: (if … then 0 else 1 end)` 與 `finalStatus: .finalStatus`。
- 為什麼：對齊業務書 §6.3 範例；新 convention 比舊 convention（單一 STRING）對前端/監控更友善。
- 沒選：舊 convention（與需求衝突）、純 HTTP status（會失去 finalStatus 語意）。
- 不這樣做的後果：對外 API response 與需求不符，客戶端整合必爆。
- 在哪裡看到：`workflows/omni-cash-transaction.sw.yaml` `FinalAuditAndEnd.stateDataFilter`。

### D3：採 `OpenApiSchemaValidator::validate` operation + CheckValidationResult，不使用 `dataInputSchema`

- 選了：在 `ValidateInput` (operation state) 調用 validator，失敗路由到 `InjectValidationFailedStatus → FinalAuditAndEnd`，確保 100% 落 AuditLog。
- 為什麼：金融審計完整性；`dataInputSchema` 會在 workflow 實例建立前拋 400，導致 FinalAuditAndEnd 永遠不被執行（Audit Gap）。
- 沒選：原生 `dataInputSchema`（造成審計缺口）、無驗證（業務風險）。
- 不這樣做的後果：違反金融審計合規；前端收不到統一錯誤結構。
- 在哪裡看到：`omni-cash-transaction.sw.yaml` `ValidateInput`/`CheckValidationResult`；`docs/spec.md H14`。

### D4：Mock sentinel 採 Mode A 字串前綴（FAIL_/RBFAIL/金額=0）

- 選了：Core CashDeposit `amount=0` 或 `0000000000` 觸發業務拒絕；Rollback `CA_R_` 開頭 `RBFAIL` 觸發回沖失敗。
- 為什麼：與既有 transfer-mock 風格一致；OpenApiSchemaValidator `FAIL_` 剝離前綴後再驗 regex 不會誤判（見 §6.6 預檢與 §6.15 DTO 套件）。
- 沒選：獨立 `__sentinel` field（會污染 request schema，且本業務用前綴已足夠）。
- 不這樣做的後果：mock 無法觸發錯誤路徑；測試覆蓋率不足。
- 在哪裡看到：`mocks/CoreCashDepositResource.java`、`mocks/CreditCardRepaymentResource.java`。

### D5：直調 actionDataFilter 一律 `toStateData`，避免 State Data 沖刷

- 選了：所有直調 `functionRef`（含 `validateOpenApiInput`、`checkIdempotency`、`callApiViaOpenAPI`、`lookupOriginalTransaction`、`markOriginalCancelled`、`recordAuditLog`）一律帶 `toStateData: '${ .xxxResult }'`，避免覆寫 workflow 記憶體。
- 為什麼：Kogito codegen 對直調 `actionDataFilter.results` 不寫 `toStateData` 時會用 results 物件整份覆寫當前 State Data，導致 `partyId`/`amount`/`sequenceNumber` 全部丟失，下游 subFlow/AuditLog 全為 null（致命 Audit Gap）。
- 沒選：省略 `toStateData`（看似精簡但破壞整體流程）。
- 不這樣做的後果：subflow 找不到輸入欄位；AuditLog 寫空值。
- 在哪裡看到：`workflows/*.sw.yaml` 所有直調 `actionDataFilter`。

### D6：逆向取消 Child 採階梯式 Switch（Lookup → Cancelleable）

- 選了：`CheckOriginal` (查無資料) 與 `CheckOriginalCancellable` (狀態判定) 分兩個獨立 switch，jBPM 不會因無序評估導致兩條件同時命中而誤跳。
- 為什麼：jBPM Split 條件無序性，跨欄位（found + status）混寫時，當 found=false 時 status 屬性為空，兩個條件會同時 true，誤轉 `FinalizeCancelRejected` 而非 `FinalizeLookupFailed`。
- 沒選：合併 switch（看似簡潔但實際誤判）。
- 不這樣做的後果：原交易查無時會回 `CANCEL_REJECTED` 而非 `LOOKUP_FAILED`，監控告警失靈。
- 在哪裡看到：`repayment-cash-cancellation.sw.yaml` `CheckOriginal` + `CheckOriginalCancellable`。

### D7：subFlowRef version 對齊 child version

- 選了：Parent subFlowRef 與 Child version 皆 `1.0.0`。
- 為什麼：Kogito 10.2.0 在版本不一致時 codegen 會拋 `Subflow version mismatch`。
- 沒選：省略 version 欄位（引擎會抓不到）、用 `1.0` 而 child 是 `1.0.0`（字串不一致）。
- 不這樣做的後果：Kogito 編碼失敗。
- 在哪裡看到：`omni-cash-transaction.sw.yaml` `InvokeDepositSubflow`/`InvokeCancellationSubflow`。

### D8：notifyOps 採用 6 參展開簽名（workflowId/processInstanceId/businessKey/finalStatus/finalMessage/detail）

- 選了：所有 `notifyOps` action 顯式帶 6 個參數鍵名，與 Java `OpsAlertService.raise` 完全對齊。
- 為什麼：`OpsAlertService.raise` 6 參簽名是 `String, Object, Object, Object, Object, Map`；YAML 必須用展開參數，禁用 `inputData`/`outputData`（會 NoSuchMethodException）。
- 沒選：簡寫 `inputData`/`outputData`（6.14 預檢直接 FAIL）。
- 不這樣做的後果：補償失敗時告警呼叫拋 NoSuchMethodException，告警靜默失敗。
- 在哪裡看到：`repayment-cash-deposit.sw.yaml` `NotifyRollbackFailure`、`repayment-cash-cancellation.sw.yaml` `NotifyRollbackFailure`。

### D9：Mock DTO 採 `org.acme.transfer.api.features.dto`

- 選了：所有 DTO（`CoreCashDepositRequest`、`CoreCashDepositResponse`、`ErrorDetail`）統一 `package org.acme.transfer.api.features.dto`。
- 為什麼：`transfer-mock/pom.xml` 的 antrun 規則會把 DTO 拷貝到 `src/main/java/org/acme/transfer/api/features/dto/`，套件與目錄必須一致；脫離 features 套件會在 Maven clean 後 class 消失。
- 沒選：`org.acme.transfer.api.dto`（6.15 預檢 FAIL）。
- 不這樣做的後果：`NoClassDefFoundError: <DtoName>` 執行期崩潰。
- 在哪裡看到：`mocks/dto/*.java`。

### D10：View SQL 只讀實體欄位，業務欄位 json_extract

- 選了：`vw_omni_cash_transaction_reconciliation` 只 SELECT `workflow_execution_log` 既有欄位（`id`/`workflow_id`/`status`/…/`input_data`/`output_data`），業務欄位全部 `json_extract(input_data, '$.xxx')`。
- 為什麼：實體只有 11 欄；新增 `sequence_number`/`final_status` 等不存在欄位會讓 View DDL 在 Flyway migrate 失敗。
- 沒選：新增 ALTER TABLE（6.16 預檢 FAIL + 增加 schema 維護成本）。
- 不這樣做的後果：`SQLITE_ERROR: no such column` 對帳查詢崩潰。
- 在哪裡看到：`db/migration/V1.2.9__create_view_omni_cash_transaction_reconciliation.sql`。

## 5. 產出物地圖

```
drafts/omni-cash-transaction/
├── feature.yaml                                       # 特徵元資料（id, version, owner, workflows[]）
├── docs/
│   ├── README.md                                      # draft 入口與目錄說明
│   ├── spec.md                                        # 規格書（H1-H18 + 11 章節 + Mapping Manifest）
│   ├── design-explanation.md                          # 本檔（9 節，創建者導向）
│   └── execution-trace-and-issue-report.md            # 執行軌跡與問題報告（9 節，v3.3 必產）
├── workflows/
│   ├── omni-cash-transaction.sw.yaml                  # Parent（驗證/冪等/分流/統一回應/稽核）
│   ├── repayment-cash-deposit.sw.yaml                 # Child A（Core → CreditCard，LIFO 補償）
│   └── repayment-cash-cancellation.sw.yaml             # Child B（Lookup → 階梯式 Switch → Core rollback → CreditCard rollback）
├── specs/
│   ├── internal/omni-counter-repayment-api.yaml       # Parent 對外入口（含 x-workflow-id）
│   └── external/
│       ├── core-account-cash-deposit-api.yaml         # Core 主機 host（無 x-workflow-id）
│       └── credit-card-repayment-api.yaml             # CreditCard 主機 host（無 x-workflow-id）
├── mocks/
│   ├── CoreCashDepositResource.java                   # Core JAX-RS mock（FAIL/0 與 RBFAIL 前綴 sentinel）
│   ├── CreditCardRepaymentResource.java               # CreditCard JAX-RS mock
│   └── dto/
│       ├── CoreCashDepositRequest.java                # features.dto 套件
│       ├── CoreCashDepositResponse.java               # features.dto 套件
│       └── ErrorDetail.java                           # features.dto 套件
├── db/
│   ├── migration/V1.2.9__create_view_omni_cash_transaction_reconciliation.sql  # 對帳 View（json_extract）
│   └── teardown.sql                                   # DROP VIEW
├── config/application.properties.snippet              # status-rewrite mapping + bean binding + dev/prod base URL
└── tests/OmniCashTransactionWorkflowTest.java         # @QuarkusTest，P1/A1/P4/B1/B2 五場景
```

### 檔名-ID 對應表

| 檔名 | YAML id | 角色 |
|---|---|---|
| `omni-cash-transaction.sw.yaml` | `omni_cash_transaction` | Parent |
| `repayment-cash-deposit.sw.yaml` | `repayment_cash_deposit` | Child A |
| `repayment-cash-cancellation.sw.yaml` | `repayment_cash_cancellation` | Child B |

## 6. 流程解說

### 正向繳款（operationType=A）

```
[API POST /Omni/{creditcardid}/Repayment/Execute]
            ↓
[Parent: omni_cash_transaction]
            ↓
ValidateInput (OpenApiSchemaValidator::validate)
   ├─ fail → InjectValidationFailedStatus → FinalAuditAndEnd (REJECTED_VALIDATION, 400)
   └─ ok
            ↓
CheckIdempotency (IdempotencyService::findBySequenceNumber)
   └─ hit → InjectIdempotentReplay → FinalAuditAndEnd (IDEMPOTENT_REPLAY, 200)
            ↓
DispatchOperation (switch)
   └─ operationType=A → InvokeDepositSubflow
            ↓
[Child A: repayment_cash_deposit]
            ↓
CallCoreForward (opType=A, seq=CA_xxx)
   ├─ fail → FinalizeFailed → End (FAILED, 200)
   └─ ok
            ↓
CallCreditCardForward (opType=A, seq=CC_xxx)
   ├─ ok → FinalizeSuccess → End (SUCCESS, 200)
   └─ fail → RollbackCore (opType=B, seq=CA_R_xxx)
                 ├─ ok → FinalizeRolledBack → End (ROLLED_BACK, 200)
                 └─ fail → FinalizeRollbackFailed → NotifyRollbackFailure → End (ROLLBACK_FAILED, 409)
            ↓
[Parent 統一寫 AuditLog + status-rewrite 改 HTTP]
            ↓
[API Response: SUCCESS / ROLLED_BACK / ROLLBACK_FAILED / FAILED]
```

### 反向取消（operationType=B）

```
[API POST /Omni/{creditcardid}/Repayment/Execute + originalSequenceNumber]
            ↓
[Parent] Validate → Idempotency → Dispatcher (operationType=B)
            ↓
InvokeCancellationSubflow
            ↓
[Child B: repayment_cash_cancellation]
            ↓
LookupOriginal (AuditLogService::findBySequenceNumber(workflowId=repayment_cash_deposit, businessKey=originalSequenceNumber))
   ├─ notFound → CheckOriginal → FinalizeLookupFailed → End (LOOKUP_FAILED, 500)
   └─ found
            ↓
CheckOriginalCancellable (status≠SUCCESS OR cancelledBy≠null)
   ├─ notCancellable → FinalizeCancelRejected → End (CANCEL_REJECTED, 200)
   └─ ok
            ↓
CancelCore (opType=B, seq=CA_R_xxx)
   ├─ fail → FinalizeCancelFailed → End (CANCEL_FAILED, 200)
   └─ ok
            ↓
CancelCreditCard (opType=B, seq=CC_R_xxx)
   ├─ ok → MarkOriginalCancelled (AuditLogService::markCancelledBy) → FinalizeCancelled → End (CANCELLED, 200)
   └─ fail → RollbackCancelCore (同 CA_R_xxx, 冪等)
                ├─ ok → FinalizeCancelRolledBack → End (CANCEL_ROLLED_BACK, 200)
                └─ fail → FinalizeCancelRollbackFailed → NotifyRollbackFailure → End (CANCEL_ROLLBACK_FAILED, 409)
```

### 測試場景對應表

| 測試 | 觸發 | 預期 finalStatus | HTTP |
|---|---|---|---|
| `p1RejectsInvalidOperationType` | operationType=C | REJECTED_VALIDATION | 400 |
| `a1CompletesRepayment` | operationType=A + 動態 seq | SUCCESS | 200 |
| `p4ReplaysSameSequence` | 同 body POST 兩次 | 第二次 IDEMPOTENT_REPLAY | 200 |
| `b1CancelsSuccessfulOriginal` | 先 A 成功，再 B + originalSequenceNumber | CANCELLED | 200 |
| `b2ReturnsLookupFailure` | B + 不存在 originalSequenceNumber | LOOKUP_FAILED | 500 |

## 7. 假設與待確認

- **A1 sequenceNumber 長度**：13 vs 22 待主機確認，本 draft schema 採 `13 ≤ len ≤ 20` 寬鬆範圍。
- **A4 取消時間窗**：採當日內（以 `transactionDate` 為準）；是否需 24 小時滑動窗待業務方確認。
- **A5 originalSequenceNumber 唯一性**：假設其在 `workflow_execution_log` 全域唯一（否則需多鍵查詢）。
- **T4 主機查詢端點**：核心/信用卡主機是否提供「依 seq 查狀態」端點未知；本 draft 不虛構此 endpoint，未來若需求成立需擴充 §7.4/§9.3。
- **`reason` 欄位**：資料模型列為 `TELLER_MISTAKE` / `CARDHOLDER_REQUEST`，但四份 API request schema 均未含；本 draft v1.0 不放 required。
- **業務層次未確認（待業務方）**：取消是否限定原櫃員、Parent 級冪等的 key 用 `sequenceNumber` 還是 `parent_workflow_id`。

## 8. 驗證 + 限制 + 下一步

### 已跑預檢 / 自查

- 16 項平台相容性預檢 (Step 6)：本 draft 結構符合，下游整併前由 `scripts/preflight-checks.js` 與 Agent Runner 全量執行確認。
- 35 項自我檢查 (Step 7.1-7.40)：本檔設計決策覆蓋自查 7.4 / 7.5 / 7.6 / 7.7 / 7.18 / 7.19 / 7.20 / 7.22 / 7.23 / 7.24 / 7.25 / 7.26 / 7.27 / 7.28 / 7.29 / 7.30 / 7.31 / 7.32 / 7.33 / 7.34 / 7.35 / 7.36 / 7.37 / 7.38 / 7.39 / 7.40。
- 文檔結構：`spec.md` (11 章節) + `design-explanation.md` (9 節) + `execution-trace-and-issue-report.md` (9 節)。

### 已知限制

1. 未知狀態查詢 host API 未定義，本 draft 不虛構（見 §9.1）。
2. `reason` 入口欄位 v1.0 不強制（見 H18）。
3. 序號長度以寬鬆範圍保護（見 H7）。

### 下游移交

移交 `sonataflow-integration` skill 進行 `project/features/omni-cash-transaction/` 掛載，執行 Maven compile + Kogito codegen + Quarkus test。

### 名詞解釋

- **Parent / Child Subflow**：Parent 是對外唯一 API 入口，負責驗證/冪等/分流/統一審計；Child 為 Parent 委派的子流程，執行具體業務主機呼叫與補償。
- **subFlowRef**：Serverless Workflow 規格中的子流程引用語法，version 必須與 child 定義一致。
- **冪等**：同一 `sequenceNumber` 重送必須回傳相同結果，避免重複入帳。
- **補償**：當流程失敗時，主動呼叫反向操作把已執行的部分撤回，保證系統最終一致。
- **Audit Gap**：審計軌跡缺口，當 `dataInputSchema` 在實例建立前拋錯或 actionDataFilter 覆寫 state data 時，AuditLog 將無法寫入，造成合規缺口。
- **FQCN**：Fully Qualified Class Name（完整類別名），用於 `service:xxx.yyy.Zzz::method` Java 服務呼叫。
- **Sentinel**：Mock 為了觸發錯誤路徑所用的特殊輸入字串（如 `FAIL_` / `RBFAIL`）。
- **SSOT**：Single Source of Truth，唯一可信來源；本 draft 以 `specs/internal/*.yaml` 為驗證與路由雙重 SSOT。