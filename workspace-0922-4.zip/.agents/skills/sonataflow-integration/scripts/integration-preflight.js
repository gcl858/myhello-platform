/**
 * SonataFlow Integration Preflight Checks (v1.0 / Skill v3.0)
 *
 * 執行環境：SonataFlow Agent Dynamic Script Runner (Node.js)
 * 健康檢查：GET http://127.0.0.1:8091/api/health
 * 調用端點：POST http://127.0.0.1:8091/api/run-file 或 POST /api/run
 *
 * 功能：
 * 1. 對「整合後」的特徵目錄（project/features/<name>/）執行 6 項補強預檢
 * 2. 重跑 vibe-workflow-design-v3 6.12-6.16 設計期預檢（防止 draft 設計期未跑導致漏網）
 * 3. 補強 check 6️⃣：onErrors 覆蓋率 + *_FAILED 終態必觸發 notifyOps
 * 4. 檢測不通過時自動調用 helpers.addDiagnostic 在 VS Code 問題面板標註紅線
 *
 * 與 preflight-checks.js 的差異：
 * - preflight-checks.js（vibe）：設計期掃描 draft-<name>/，擋下可在設計階段發現的問題
 * - integration-preflight.js（本檔）：整合期掃描 project/features/<name>/，補強設計期漏網或環境特有的問題
 *
 * v1.0 變更（2026-09-21）：
 *   - 從 sonataflow-integration Step 1.5A.1 整合期 6 項檢查抽出，封裝為獨立檔案
 *   - 與 preflight-checks.js 11-15 邏輯對齊，但參數目錄指向 project/features/<name>/
 *
 * 觸發事件：2026-09 實戰整合 omni_cash_transaction 時暴露的 6 個整合期 trap
 *
 * args 範例：
 *   {
 *     "draftDir": "draft/draft-omni-cash-transaction",       // 來源 draft（可選，用於 cross-check）
 *     "featureDir": "project/features/draft-omni-cash-transaction",  // 整合目標（必填）
 *     "dbPath": "project/data/reconciliation.db"             // 用於 Flyway 版本交叉驗證（可選）
 *   }
 */

async function runIntegrationPreflight() {
  const logs = [];
  const log = (msg) => { logs.push(msg); console.log(msg); };

  // 1. 解析目標路徑
  const featureDir = args && args.featureDir
    ? (path.isAbsolute(args.featureDir) ? args.featureDir : path.join(workspaceRoot, args.featureDir))
    : (workspaceRoot);
  const draftDir = args && args.draftDir
    ? (path.isAbsolute(args.draftDir) ? args.draftDir : path.join(workspaceRoot, args.draftDir))
    : null;
  const dbPath = args && args.dbPath
    ? (path.isAbsolute(args.dbPath) ? args.dbPath : path.join(workspaceRoot, args.dbPath))
    : path.join(workspaceRoot, 'data/reconciliation.db');

  const results = {
    featureDir,
    draftDir,
    dbPath,
    timestamp: new Date().toISOString(),
    totalChecks: 0,
    passChecks: 0,
    failChecks: 0,
    failures: [],
    flyway: null
  };

  log(`🚀 開始執行 SonataFlow 整合期補強預檢 (v1.0)`);
  log(`📂 整合特徵目錄: ${featureDir}`);
  if (draftDir) log(`📂 來源 draft 目錄: ${draftDir}`);
  log(`💾 DB 路徑: ${dbPath}`);

  // 輔助函式：遞迴搜尋檔案
  function findFiles(dir, extFilter, nameFilter) {
    let list = [];
    if (!fs.existsSync(dir)) return list;
    try {
      const entries = fs.readdirSync(dir, { withFileTypes: true });
      for (const entry of entries) {
        const fullPath = path.join(dir, entry.name);
        if (entry.isDirectory()) {
          list = list.concat(findFiles(fullPath, extFilter, nameFilter));
        } else if (entry.isFile()) {
          if (extFilter && !entry.name.endsWith(extFilter)) continue;
          if (nameFilter && !entry.name.includes(nameFilter)) continue;
          list.push(fullPath);
        }
      }
    } catch (e) {
      log(`  ⚠️ 無法讀取目錄 ${dir}: ${e.message}`);
    }
    return list;
  }

  function recordCheck(name, pass, failureMsg, filePath, line = 1, col = 1) {
    results.totalChecks++;
    if (pass) {
      results.passChecks++;
      log(`  ✅ PASS: ${name}`);
      if (filePath && helpers.clearDiagnostics) {
        helpers.clearDiagnostics(filePath);
      }
    } else {
      results.failChecks++;
      const detail = `[${name}] ${failureMsg} (${filePath || '整體檢驗'})`;
      results.failures.push(detail);
      log(`  ❌ FAIL: ${detail}`);
      if (filePath && helpers.addDiagnostic) {
        helpers.addDiagnostic(filePath, line, col, `[${name}] ${failureMsg}`, 'error');
      }
    }
  }

  // 載入所有 workflow YAML（從整合後的 features/ 目錄）
  const swFiles = findFiles(featureDir, '.sw.yaml');
  const workflows = [];
  for (const f of swFiles) {
    try {
      const content = fs.readFileSync(f, 'utf8');
      const parsed = helpers.parseYaml(content);
      workflows.push({ filePath: f, content, parsed });
    } catch (e) {
      recordCheck('YAML Parse', false, `無法解析 YAML: ${e.message}`, f, 1, 1);
    }
  }

  log(`\n🔍 從整合特徵目錄發現 ${workflows.length} 個 Workflow 檔案: ${workflows.map(w => path.basename(w.filePath)).join(', ')}`);

  // ==========================================================================
  // 檢查 1️⃣: Workflow `errors:` 宣告與 `errorRef` 引用對齊 (對齊 6.12)
  // ==========================================================================
  for (const wf of workflows) {
    const declaredErrs = new Set((wf.parsed.errors || []).map(e => e.name));
    const refs = [...wf.content.matchAll(/errorRef:\s*[\x27"]?([a-zA-Z0-9_]+)/g)].map(m => m[1]);
    const uniqueRefs = [...new Set(refs)];
    let errAlignFail = false;
    for (const r of uniqueRefs) {
      if (!declaredErrs.has(r)) {
        errAlignFail = true;
        recordCheck('1-workflow-errors-alignment', false, `Workflow 引用 errorRef '${r}' 但 errors: 區塊未宣告（Kogito codegen 將拋 Cannot find any error definition）`, wf.filePath);
      }
    }
    if (!errAlignFail) {
      recordCheck('1-workflow-errors-alignment', true, null, wf.filePath);
    }
  }

  // ==========================================================================
  // 檢查 2️⃣: Workflow 沒有 unreachable 狀態 (dead code) (對齊 6.13)
  // ==========================================================================
  for (const wf of workflows) {
    const states = wf.parsed.states || [];
    const incoming = new Set();
    const start = wf.parsed.start;
    if (start) incoming.add(start);
    for (const s of states) {
      const targets = [s.transition, ...(s.dataConditions || []).map(d => d.transition), ...(s.defaultCondition ? [s.defaultCondition.transition] : []), ...(s.onErrors || []).map(e => e.transition)];
      for (const t of targets) if (t) incoming.add(t);
    }
    let unreachableFail = false;
    for (const s of states) {
      if (!incoming.has(s.name)) {
        unreachableFail = true;
        recordCheck('2-no-unreachable-state', false, `狀態 '${s.name}' 沒有任何 incoming transition，是 dead code（移除或補上 transition）`, wf.filePath);
      }
    }
    if (!unreachableFail) {
      recordCheck('2-no-unreachable-state', true, null, wf.filePath);
    }
  }

  // ==========================================================================
  // 檢查 3️⃣: notifyOps arguments 必須對齊 Java OpsAlertService 6 參簽名 (對齊 6.14)
  // ==========================================================================
  for (const wf of workflows) {
    const states = wf.parsed.states || [];
    const required = ['workflowId', 'processInstanceId', 'businessKey', 'finalStatus', 'finalMessage', 'detail'];
    const forbidden = ['inputData', 'outputData'];
    let notifyArgsFail = false;
    for (const state of states) {
      for (const act of (state.actions || [])) {
        if (act.functionRef && act.functionRef.refName === 'notifyOps') {
          const args = act.functionRef.arguments || {};
          for (const k of required) {
            if (!(k in args)) {
              notifyArgsFail = true;
              recordCheck('3-notifyops-6-args-signature', false, `狀態 '${state.name}' notifyOps 缺少必要參數 '${k}'（對齊 OpsAlertService.raise 6 參簽名）`, wf.filePath);
            }
          }
          for (const k of forbidden) {
            if (k in args) {
              notifyArgsFail = true;
              recordCheck('3-notifyops-6-args-signature', false, `狀態 '${state.name}' notifyOps 使用了錯誤參數 '${k}'（應改為 finalStatus/finalMessage/detail）`, wf.filePath);
            }
          }
        }
      }
    }
    if (!notifyArgsFail) {
      recordCheck('3-notifyops-6-args-signature', true, null, wf.filePath);
    }
  }

  // ==========================================================================
  // 檢查 4️⃣: Mock DTO 套件命名對齊 transfer-mock antrun 同步目錄 (對齊 6.15)
  // ==========================================================================
  const dtoDir = path.join(featureDir, 'mocks/dto');
  if (fs.existsSync(dtoDir)) {
    const dtoFiles = findFiles(dtoDir, '.java');
    let dtoFail = false;
    for (const df of dtoFiles) {
      const pkg = fs.readFileSync(df, 'utf8').match(/^package\s+([\w.]+);/m)?.[1];
      if (pkg && !pkg.includes('.features.')) {
        dtoFail = true;
        recordCheck('4-mock-dto-package-alignment', false, `DTO 套件 ${pkg} 與 transfer-mock antrun 同步目錄（features/dto/）不一致；應改為 org.acme.transfer.api.features.dto`, df);
      }
    }
    if (!dtoFail) {
      recordCheck('4-mock-dto-package-alignment', true, null, dtoDir);
    }
  } else {
    recordCheck('4-mock-dto-package-alignment', true, null, null, 1, 1);
    log(`  ℹ️  [4] 無 mocks/dto 目錄，視為通過`);
  }

  // ==========================================================================
  // 檢查 5️⃣: View SQL 欄位必須對齊 workflow_execution_log 實體 schema (對齊 6.16)
  // 注意：須排除以下場景避免誤判
  //   - SQL 註解 (-- xxx 或 /* xxx */)
  //   - 別名宣告 (json_extract(...) AS <forbidden>)
  //   - INDEX 名稱 (CREATE INDEX ... <forbidden>)
  // ==========================================================================
  const forbiddenCols = ['sequence_number', 'final_status', 'workflow_data', 'updated_at', 'inputData', 'outputData'];
  const viewSqlFiles = findFiles(featureDir, '.sql').filter(f => !f.endsWith('teardown.sql') && /CREATE\s+(OR\s+REPLACE\s+)?VIEW/i.test(fs.readFileSync(f, 'utf8')));
  let sqlColFail = false;
  for (const vf of viewSqlFiles) {
    const rawContent = fs.readFileSync(vf, 'utf8');

    // 5a. 檢查在 CREATE VIEW 之前是否已存在 DROP VIEW IF EXISTS <viewName>
    const createViewRegex = /CREATE\s+(?:OR\s+REPLACE\s+)?VIEW\s+(?:IF\s+NOT\s+EXISTS\s+)?([`"']?([a-zA-Z0-9_]+)[`"']?)/gi;
    let match;
    while ((match = createViewRegex.exec(rawContent)) !== null) {
      const viewName = match[2];
      const createIndex = match.index;
      const precedingSql = rawContent.slice(0, createIndex);
      const dropRegex = new RegExp(`DROP\\s+VIEW\\s+(?:IF\\s+EXISTS\\s+)?[\`"']?${viewName}[\`"']?\\s*;`, 'i');
      const hasDropBefore = dropRegex.test(precedingSql);
      recordCheck(
        '5-view-sql-drop-before-create',
        hasDropBefore,
        `Flyway 腳本 ${path.basename(vf)} 建立視圖 '${viewName}' 之前必須先包含 'DROP VIEW IF EXISTS ${viewName};'（確保 SQLite 視圖更新可生效）`,
        vf
      );
    }

    let txt = rawContent;
    // 移除 SQL 行註解 (-- 至行尾)
    txt = txt.replace(/--[^\n]*/g, '');
    // 移除 SQL 區塊註解 (/* ... */)
    txt = txt.replace(/\/\*[\s\S]*?\*\//g, '');
    // 移除 CREATE VIEW ... AS 標頭（其本身含 "AS"，會誤觸 AS 分割）
    // 支援 CREATE VIEW、CREATE OR REPLACE VIEW、CREATE VIEW IF NOT EXISTS
    txt = txt.replace(/CREATE\s+(OR\s+REPLACE\s+)?VIEW\s+(IF\s+NOT\s+EXISTS\s+)?\S+\s+AS/i, '');
    // 只檢查 AS 之前的 SELECT/FROM/WHERE 區塊（忽略別名）
    const selectClause = txt.split(/\s+AS\s+/i)[0];

    for (const col of forbiddenCols) {
      const re = new RegExp(`\\b${col}\\b`, 'i');
      if (re.test(selectClause)) {
        sqlColFail = true;
        recordCheck('5-view-sql-column-alignment', false, `View SQL 直接引用不存在的實體欄位 '${col}'（AS 別名之前的 SELECT 區塊；應改用 json_extract(input_data, '$.xxx') 或 json_extract(output_data, '$.xxx')）`, vf);
      }
    }
  }
  if (viewSqlFiles.length === 0) {
    recordCheck('5-view-sql-column-alignment', true, null, null, 1, 1);
    log(`  ℹ️  [5] 無 View SQL 檔案，視為通過`);
  } else if (!sqlColFail) {
    recordCheck('5-view-sql-column-alignment', true, null, viewSqlFiles[0]);
  }

  // ==========================================================================
  // 檢查 6️⃣: onErrors 覆蓋率 + *_FAILED 終態必觸發 notifyOps (整合期補強版)
  // 涵蓋更廣的 *_FAILED 終態（vibe 6.11 僅查 ROLLBACK_FAILED）
  // ==========================================================================
  const failedStatuses = ['ROLLBACK_FAILED', 'CANCEL_ROLLBACK_FAILED', 'SWIFT_ROLLBACK_FAILED', 'AML_REJECTED_ROLLBACK_FAILED', 'LOOKUP_FAILED'];
  for (const wf of workflows) {
    const states = wf.parsed.states || [];
    const ops = states.filter(s => s.type === 'operation');
    const errs = states.filter(s => s.onErrors && s.onErrors.length > 0);
    // 允許 terminal audit state 豁免 1 個
    if (ops.length > 1 && errs.length < (ops.length - 1)) {
      recordCheck('6-onerrors-coverage', false, `operation states 數量為 ${ops.length} 但 onErrors 僅宣告 ${errs.length} 處（未覆蓋 host 例外審計）`, wf.filePath);
    } else {
      recordCheck('6-onerrors-coverage', true, null, wf.filePath);
    }

    for (const fs2 of failedStatuses) {
      if (wf.content.includes(fs2)) {
        const hasNotify = wf.content.includes('refName: notifyOps') || wf.content.includes('refName: "notifyOps"');
        recordCheck(`6-notifyops-on-${fs2}`, hasNotify, `流程包含 ${fs2} 終態，但未在補償失敗時調用 notifyOps 告警`, wf.filePath);
      }
    }
  }

  // ==========================================================================
  // 額外檢查 A: Flyway 雙軌版本探測（檔案系統 + 實體 DB）
  // 防止 DatabaseMigrationRunner 靜默跳過新腳本（Step 4d 踩坑預警）
  // ==========================================================================
  log(`\n📦 Flyway 雙軌探測中...`);
  const migrationFiles = findFiles(featureDir, '.sql').filter(f => f.includes('/db/migration/'));
  let maxMajor = 0, maxMinor = 0, maxPatch = -1, latestStr = null;
  for (const mf of migrationFiles) {
    const base = path.basename(mf);
    const m = base.match(/^V(\d+)(?:\.(\d+))?(?:\.(\d+))?__/);
    if (m) {
      const maj = parseInt(m[1], 10) || 0;
      const min = parseInt(m[2] || '0', 10);
      const pat = parseInt(m[3] || '0', 10);
      if (maj > maxMajor || (maj === maxMajor && min > maxMinor) || (maj === maxMajor && min === maxMinor && pat >= maxPatch)) {
        maxMajor = maj; maxMinor = min; maxPatch = pat;
        latestStr = `V${maj}.${min}.${pat}`;
      }
    }
  }

  // 嘗試讀取實體 DB schema_history
  let dbLatestStr = null, dbMaxMajor = 0, dbMaxMinor = 0, dbMaxPatch = -1;
  try {
    if (fs.existsSync(dbPath)) {
      const { execSync } = require('child_process');
      const out = execSync(`sqlite3 ${dbPath} "SELECT version FROM reconciliation_schema_history WHERE success = 1;"`).toString();
      const versions = out.split('\n').map(l => l.trim()).filter(Boolean);
      for (const v of versions) {
        const m = v.match(/^(\d+)(?:\.(\d+))?(?:\.(\d+))?$/);
        if (m) {
          const maj = parseInt(m[1], 10) || 0;
          const min = parseInt(m[2] || '0', 10);
          const pat = parseInt(m[3] || '0', 10);
          if (maj > dbMaxMajor || (maj === dbMaxMajor && min > dbMaxMinor) || (maj === dbMaxMajor && min === dbMaxMinor && pat >= dbMaxPatch)) {
            dbMaxMajor = maj; dbMaxMinor = min; dbMaxPatch = pat;
            dbLatestStr = `V${maj}.${min}.${pat}`;
          }
        }
      }
      log(`  ✅ 實體 DB 探測成功: 最新版本 ${dbLatestStr || '無'}`);
    } else {
      log(`  ℹ️  找不到實體 DB (${dbPath})，僅掃檔案系統`);
    }
  } catch (e) {
    log(`  ⚠️  實體 DB 探測失敗 (將僅依檔案系統): ${e.message}`);
  }

  // 計算安全基線 = max(檔案系統 + 1, 實體 DB + 1)
  const fileNext = latestStr ? `V${maxMajor}.${maxMinor}.${maxPatch + 1}` : 'V1.0.0';
  let useMajor = maxMajor, useMinor = maxMinor, usePatch = maxPatch + 1;
  if (dbMaxMajor > useMajor || (dbMaxMajor === useMajor && dbMaxMinor > useMinor) || (dbMaxMajor === useMajor && dbMaxMinor === useMinor && (dbMaxPatch + 1) > usePatch)) {
    useMajor = dbMaxMajor; useMinor = dbMaxMinor; usePatch = dbMaxPatch + 1;
  }
  const safeNext = `V${useMajor}.${useMinor}.${usePatch}`;
  results.flyway = { fileLatest: latestStr, dbLatest: dbLatestStr, nextSuggested: safeNext };

  log(`\n  檔案系統最新版本: ${latestStr || '無'}`);
  log(`  實體 DB 最新版本: ${dbLatestStr || '無'}`);
  log(`  安全基線（下一版）: ${safeNext}`);
  log(`  ⚠️  新 migration V 編號必須 >= ${safeNext}`);

  // 若 migration 名稱已存在於檔案系統但小於 DB 版本，警告（會被靜默跳過）
  for (const mf of migrationFiles) {
    const base = path.basename(mf);
    const m = base.match(/^V(\d+)(?:\.(\d+))?(?:\.(\d+))?__/);
    if (m) {
      const fMaj = parseInt(m[1], 10) || 0;
      const fMin = parseInt(m[2] || '0', 10);
      const fPat = parseInt(m[3] || '0', 10);
      if (dbLatestStr) {
        if (fMaj < dbMaxMajor || (fMaj === dbMaxMajor && fMin < dbMaxMinor) || (fMaj === dbMaxMajor && fMin === dbMaxMinor && fPat <= dbMaxPatch)) {
          recordCheck('Flyway-stale-migration', false, `Migration ${base} 版本 <= DB 已套用版本 ${dbLatestStr}，將被 DatabaseMigrationRunner 靜默跳過！請改版號為 ${safeNext}`, mf);
        }
      }
    }
  }

  // ==========================================================================
  // 額外檢查 B: 來源 draft 與整合目標一致性交叉驗證（可選，僅在 draftDir 有提供時）
  // ==========================================================================
  if (draftDir && fs.existsSync(draftDir)) {
    log(`\n🔍 交叉驗證 draft 與整合目標...`);
    const draftFiles = findFiles(draftDir, '.yaml').filter(f => f.endsWith('.sw.yaml') || f.endsWith('.sql') || f.endsWith('.java'));
    const featureFiles = findFiles(featureDir, '.yaml').filter(f => f.endsWith('.sw.yaml') || f.endsWith('.sql') || f.endsWith('.java'));
    log(`  draft 檔案數: ${draftFiles.length}, 整合目標檔案數: ${featureFiles.length}`);
    if (draftFiles.length !== featureFiles.length) {
      log(`  ⚠️  檔案數不一致，可能漏拷貝或多了檔案，建議人工核對`);
    } else {
      log(`  ✅ 檔案數一致`);
    }
  }

  // ==========================================================================
  // 額外檢查 C: 整併執行軌跡與問題報告驗證 (Step 11 規範)
  // ==========================================================================
  const integrationReportPath = path.join(featureDir, 'docs/integration-execution-trace-and-issue-report.md');
  const docsDir = path.join(featureDir, 'docs');
  if (fs.existsSync(docsDir)) {
    if (fs.existsSync(integrationReportPath)) {
      const content = fs.readFileSync(integrationReportPath, 'utf8');
      const sectionMatches = content.match(/^##\s+\d+[\.、\s]/gm) || [];
      const sectionCount = sectionMatches.length;
      if (sectionCount >= 12) {
        recordCheck('Step11-integration-trace-report-sections', true, null, integrationReportPath);
        log(`  ✅ [Step 11] integration-execution-trace-and-issue-report.md 存在且包含 ${sectionCount} 個二級章節 (符合 12 節規範)`);
      } else {
        recordCheck('Step11-integration-trace-report-sections', false, `integration-execution-trace-and-issue-report.md 二級章節數為 ${sectionCount}（規範要求 12 節必須齊全）`, integrationReportPath);
      }

      // 若指定 draftDir，檢查雙向鏡像同步
      if (draftDir && fs.existsSync(draftDir)) {
        const draftReportPath = path.join(draftDir, 'docs/integration-execution-trace-and-issue-report.md');
        if (fs.existsSync(draftReportPath)) {
          recordCheck('Step11-integration-trace-report-mirrored', true, null, draftReportPath);
          log(`  ✅ [Step 11] 報告已成功鏡像同步至 draft 目錄`);
        } else {
          recordCheck('Step11-integration-trace-report-mirrored', false, `報告未鏡像同步至 draft 目錄: ${draftReportPath}`, draftDir);
        }
      }
    } else if (args && (args.postIntegration || args.checkReport)) {
      recordCheck('Step11-integration-trace-report', false, `缺少 docs/integration-execution-trace-and-issue-report.md 整併執行軌跡與問題報告（Step 11 規範必產）`, featureDir);
    } else {
      log(`  ℹ️  [Step 11] integration-execution-trace-and-issue-report.md 尚未產出（整併完成後 Step 11 必須產出）`);
    }
  }

  // ==========================================================================
  // 最終總結
  // ==========================================================================
  log(`\n=============================================================`);
  log(`📊 整合期補強預檢總結:`);
  log(`   共 ${results.totalChecks} 項檢查 | 通過: ${results.passChecks} | 失敗: ${results.failChecks}`);
  log(`=============================================================`);

  if (results.failChecks > 0) {
    log(`\n❌ 整合期預檢未通過，建議先修正以下問題再進行 mvn test:`);
    for (const f of results.failures) {
      log(`   - ${f}`);
    }
  } else {
    log(`\n✅ 全部檢查通過，可進行 mvn test 與 E2E 驗證`);
  }

  return results;
}

// 頂層直接執行並回傳
return await runIntegrationPreflight();