---
name: sonataflow-integration
description: 將 draft 階段的 SonataFlow workflow 套件(specs / workflow YAMLs / DDL / Mock Java / Test)整併到 project 多模組 Quarkus 平台。涵蓋 5 大通用品質門禁 (雙軌 Flyway 探測、Workflow↔Java 契約靜態比對、OpenAPI↔Mock 端點覆蓋門禁、Spec 自洽性預檢、組態 CSV 合併協議)、Kogito 10.2.0 已知陷阱 (hyphenated subflow workflow id、status-rewrite 對齊、path param 注入、toStateData 狀態保全、onErrors 健壯性)，並於整併完成後產出詳細的整併執行軌跡紀錄與問題報告 (docs/integration-execution-trace-and-issue-report.md)。
---

# SonataFlow Integration Skill (v3.0)

> 🌟 **v3.0 核心鐵律：全面強制「零侵入獨立特徵外掛 (Feature Overlay Autonomous Plugin)」架構**
>
> 平台現已全面採用特徵單一目錄自治與熱插拔抽離機制：
> 1. **單一目錄自治**：特徵的所有資源（workflows/、specs/、mocks/、services/、db/、tests/）**100% 集中於 `project/features/<feature-name>/`**。
> 2. **嚴禁手動拷貝**：**嚴禁手動將任何 sw.yaml、api.yaml、Java 或 SQL 拷貝至 `transfer-app/src/main/resources` 或 `domain-transfer/transfer-workflow`**！所有裝配全由 Maven Antrun 在建置期自動探測並掛載至暫態建置目標目錄。
> 3. **隨插即拔零殘留**：掛載只需 `cp -r draft-<name> project/features/<name>`；抽離只需執行 `db/teardown.sql` 並 `rm -rf project/features/<name>`，專案核心代碼與全域設定零殘留、零修改！
>
> 整合唯一標準指令：
> ```bash
> # 1. 掛載至特徵目錄
> cp -r draft-<name> project/features/<feature-name>
> # 2. 執行前置門禁 (Step 1.5)
> # 3. 觸發 Maven 動態裝配與測試驗證（⭐ 必須加 -am 帶入 transfer-mock 依賴，避免 Mock 404）
> mvn -B test -pl distribution/transfer-app -am
> ```

---

## 觸發條件

當使用者訊息包含以下任一,主動載入:
- 「整併 draft / workflow 到 project」
- 「把 sonataflow 套件整合進專案」
- 「新 workflow 要上線,幫我合併 / 掛載」
- 看到 draft 目錄結構含 `feature.yaml` 或 `workflows/*.sw.yaml` 或 `src/specs/`

---

## Step 0: 環境檢查

- 確認 Java 17、Maven 3.8+ 可用 (`which java mvn`)
- **⭐ 確認 SonataFlow Agent Dynamic Script Runner 已啟動**（強烈推薦）：
  - 通訊埠：`http://127.0.0.1:8091`
  - 端點：`POST /api/run` (inline script) 或 `POST /api/run-file` (引用 `vibe-workflow-design-v3/scripts/preflight-checks.js`)
  - 健康檢查：`curl http://127.0.0.1:8091/api/health`（預期回傳包含 `{"status":"online", ...}`）
  - 詳見 `vibe-workflow-design-v3/SKILL.md` v3.0 全面整合說明
- (備援) 確認 Python 3 與 pyyaml 套件可用 (`python3 -c "import yaml" 2>/dev/null || pip install pyyaml`) — 僅在 Agent Runner 不可用時降級使用
- 確認 Maven mirror 已設定 (Aliyun `https://maven.aliyun.com/repository/central`,mirrorOf=*)
- 確認 JVM truststore 含企業 proxy cert (`keytool -list -cacerts | grep mvn-proxy`)
- 確認 `/root/.m2/settings.xml` mirror 配置正確

---

## Step 1: 分析 draft 結構

預期 draft 內含下列結構 (基於 `vibe-workflow-design` skill 的標準產出):
```
draft-<name>/
├── notebooks/
│   ├── internal/             # Parent 對外入口 (必含 x-workflow-id，validator+router 唯一 SSOT)
│   │   └── <entry-api>.yaml
│   ├── external/             # 被調 host 規格 (必無 x-workflow-id；新案一律此處，root 不收)
│   │   ├── <api-2>-api.yaml
│   │   └── <api-3>-api.yaml
├── spec/
│   ├── <workflow-1>.sw.yaml  # Parent / Child workflow
│   ├── <workflow-2>.sw.yaml
│   ├── <workflow-3>.sw.yaml
│   ├── db/V<X>.<Y>.<Z>__<desc>.sql
│   ├── config/application.properties.snippet
│   ├── mocks/<Resource>1.java
│   ├── mocks/<Resource>2.java
│   ├── mocks/dto/*.java
│   └── tests/<TestName>.java
└── spec.md                    # 規格書,內含 H1-H18 假設清單
```

⛔ draft 若含 `spec/schemas/*.json` 一律丟棄（最終整併不可出 JSON；SSOT 為 notebook YAML 內 `components.schemas`，見 vibe 07）。預檢：`test -z "$(find draft -name '*.json' -path '*schemas*')"`；notebook YAML 內 `$ref: '../spec/schemas/*.json'` 必須先改為 `#/components/schemas/...` 內聯，否則 FAIL。

**關鍵讀取點**:
1. 讀 `spec.md` §0 假設清單 (H1-H14),找出需要新建 / 修改的 Java 服務
2. 讀 §8 Project Mapping Manifest,確認 draft 規劃的目標路徑
3. 檢查每個 `*.sw.yaml` 的 `functions:` section,識別需要新 service bean 的 FQCN

---

## Step 1.5: ⭐ 整合前置品質門禁 (Pre-flight Quality Gates)

> 核心原則：**門禁左移**。在實際拷貝檔案前，透過自動化腳本靜態檢測 3 大契約，杜絕事後晦澀的 Codegen 崩潰與執行期 404/400。

### ⭐ 推薦：使用 SonataFlow Agent Dynamic Script Runner（v3.0 規範）

> **2026-09 起全面改用 Agent Runner** — 跨平台、VS Code 紅線聯動、與上游 `vibe-workflow-design-v3` 統一工具鏈。
> Agent Runner 通訊埠 `8091` 提供 `helpers.parseYaml` / `helpers.addDiagnostic` / `helpers.clearDiagnostics` 等 helpers，自動於 VS Code Problems 面板呈現紅線。

#### Step 1.5A.0 — 一鍵全量預檢（推薦起手式）

直接呼叫 `vibe-workflow-design-v3` 已內建的 10 項平台預檢腳本，再加上整合期補強的 6 項檢查：

```bash
# 上游 10 項預檢（涵蓋 Step 1.5 Gate 1/2/3 的核心邏輯）
curl -s -X POST http://127.0.0.1:8091/api/run-file \
  -H "Content-Type: application/json" \
  -d '{
    "filePath": ".agents/skills/vibe-workflow-design-v3/scripts/preflight-checks.js",
    "args": { "draftDir": "draft/draft-omni-cash-transaction" }
  }'
```

> 💡 失敗時，Runner 會呼叫 `helpers.addDiagnostic(file, line, col, msg, severity)`，
> VS Code Problems 面板自動紅線；AI 依紅線位置呼叫 `replace_string_in_file` 後重跑。

#### Step 1.5A.1 — 整合期補強檢查（涵蓋本次整併發現的 6 大問題）

針對整合階段特有的 6 大坑（**整合後 workflow YAML 修補、Flyway 版本衝突、Mock 套件錯位、View 欄位錯、onErrors 覆蓋、notifyOps 參數簽名**），執行下列 6 項 Agent Runner 檢查（**任一失敗則必須修正後重跑，全部 PASS 才可進入 Step 2**）：

```bash
# ⭐ 整合期 6 項補強檢查 - 一鍵執行
curl -s -X POST http://127.0.0.1:8091/api/run-file \
  -H "Content-Type: application/json" \
  -d '{
    "filePath": ".agents/skills/sonataflow-integration/scripts/integration-preflight.js",
    "args": {
      "draftDir": "draft/draft-omni-cash-transaction",
      "projectDir": "project"
    }
  }'
```

**單項檢查細節**（腳本未內建時可手動呼叫）：

##### 檢查 1️⃣：Workflow YAML `errors:` 宣告與 `onErrors` 引用對齊
**目的**：杜絕 `Cannot find any error definition for errorRef platformError`。

```bash
curl -s -X POST http://127.0.0.1:8091/api/run \
  -H "Content-Type: application/json" \
  -d '{
    "script": "const dir = path.join(workspaceRoot, args.dir); let fail = false; for (const f of fs.readdirSync(dir).filter(x => x.endsWith(\".sw.yaml\"))) { const fp = path.join(dir, f); const wf = helpers.parseYaml(fs.readFileSync(fp, \"utf8\")); const declaredErrs = new Set((wf.errors || []).map(e => e.name)); const yamlStr = fs.readFileSync(fp, \"utf8\"); const refs = [...yamlStr.matchAll(/errorRef:\\s*[\\x27\"]?([a-zA-Z0-9_]+)/g)].map(m => m[1]); for (const r of new Set(refs)) { if (!declaredErrs.has(r)) { fail = true; helpers.addDiagnostic(fp, 1, 1, `Workflow 引用 errorRef \"${r}\" 但 errors: 區塊未宣告`, \"error\"); } } } return { success: !fail };",
    "args": { "dir": "draft/draft-omni-cash-transaction/workflows" }
  }'
```

##### 檢查 2️⃣：Workflow 沒有 unreachable 狀態（無 incoming connection）
**目的**：杜絕 jBPM `Node has no incoming connection / Has no connection to the start node`。

```bash
curl -s -X POST http://127.0.0.1:8091/api/run \
  -H "Content-Type: application/json" \
  -d '{
    "script": "const dir = path.join(workspaceRoot, args.dir); let fail = false; for (const f of fs.readdirSync(dir).filter(x => x.endsWith(\".sw.yaml\"))) { const fp = path.join(dir, f); const wf = helpers.parseYaml(fs.readFileSync(fp, \"utf8\")); const states = wf.states || []; const incoming = new Set(); const start = wf.start; for (const s of states) { if (s.name === start) incoming.add(s.name); } for (const s of states) { for (const t of [s.transition, ...(s.dataConditions || []).map(d => d.transition), ...(s.onErrors || []).map(e => e.transition)]) { if (t) incoming.add(t); } } for (const s of states) { if (!incoming.has(s.name)) { fail = true; helpers.addDiagnostic(fp, 1, 1, `狀態 \"${s.name}\" 沒有 incoming connection（unreachable / dead code）`, \"error\"); } } } return { success: !fail };",
    "args": { "dir": "draft/draft-omni-cash-transaction/workflows" }
  }'
```

##### 檢查 3️⃣：`notifyOps`/`raise` arguments 必須對齊 Java 6 參簽名
**目的**：杜絕 Kogito `NoSuchMethodException: OpsAlertService.raise(...)`。
**規則**：呼叫 `notifyOps` 時 `arguments` 必須含 `workflowId`, `processInstanceId`, `businessKey`, `finalStatus`, `finalMessage`, `detail`（不可用 `inputData` / `outputData`，那是 AuditLogService.saveLog 命名）。

```bash
curl -s -X POST http://127.0.0.1:8091/api/run \
  -H "Content-Type: application/json" \
  -d '{
    "script": "const dir = path.join(workspaceRoot, args.dir); let fail = false; const required = [\"workflowId\", \"processInstanceId\", \"businessKey\", \"finalStatus\", \"finalMessage\", \"detail\"]; const forbidden = [\"inputData\", \"outputData\"]; for (const f of fs.readdirSync(dir).filter(x => x.endsWith(\".sw.yaml\"))) { const fp = path.join(dir, f); const wf = helpers.parseYaml(fs.readFileSync(fp, \"utf8\")); for (const state of wf.states || []) { for (const act of state.actions || []) { if (act.functionRef?.refName === \"notifyOps\") { const args = act.functionRef.arguments || {}; for (const k of required) { if (!(k in args)) { fail = true; helpers.addDiagnostic(fp, 1, 1, `狀態 \"${state.name}\" notifyOps 缺少必要參數 \"${k}\" (對齊 OpsAlertService.raise 6 參簽名)`, \"error\"); } } for (const k of forbidden) { if (k in args) { fail = true; helpers.addDiagnostic(fp, 1, 1, `狀態 \"${state.name}\" notifyOps 使用了錯誤參數 \"${k}\" (應改為 finalStatus/finalMessage/detail)`, \"error\"); } } } } } } return { success: !fail };",
    "args": { "dir": "draft/draft-omni-cash-transaction/workflows" }
  }'
```

##### 檢查 4️⃣：Mock DTO 套件命名必須與同步目標目錄一致
**目的**：杜絕執行期 `NoClassDefFoundError`。v3.0 Feature Overlay 下，DTO 必須落在 `org.acme.transfer.api.features.dto`，不可寫成 `org.acme.transfer.api.dto`。

```bash
curl -s -X POST http://127.0.0.1:8091/api/run \
  -H "Content-Type: application/json" \
  -d '{
    "script": "const dir = path.join(workspaceRoot, args.dir); if (!fs.existsSync(dir)) return { success: true, skipped: true }; let fail = false; for (const f of fs.readdirSync(dir).filter(x => x.endsWith(\".java\"))) { const fp = path.join(dir, f); const txt = fs.readFileSync(fp, \"utf8\"); const pkg = txt.match(/^package\\s+([\\w.]+);/m)?.[1]; if (pkg && !pkg.includes(\".features.\")) { fail = true; helpers.addDiagnostic(fp, 1, 1, `DTO 套件 ${pkg} 與 features/ 同步目錄不一致 (應為 org.acme.transfer.api.features.dto)`, \"error\"); } } return { success: !fail };",
    "args": { "dir": "draft/draft-omni-cash-transaction/mocks/dto" }
  }'
```

##### 檢查 5️⃣：View SQL 欄位必須與 `workflow_execution_log` 實體 schema 對齊
**目的**：杜絕 `no such column: sequence_number` / `no such column: updated_at`。正確欄位：`workflow_id`, `business_key`, `process_instance_id`, `status`, `message`, `input_data` (JSON), `output_data` (JSON), `created_at`, `cancelled_by`, `cancelled_at`。業務欄位須用 `json_extract(input_data, '$.field')` 拆出。

```bash
curl -s -X POST http://127.0.0.1:8091/api/run \
  -H "Content-Type: application/json" \
  -d '{
    "script": "const dir = path.join(workspaceRoot, args.dir); const validCols = new Set([\"id\", \"created_at\", \"workflow_id\", \"business_key\", \"process_instance_id\", \"status\", \"message\", \"input_data\", \"output_data\", \"cancelled_by\", \"cancelled_at\"]); const forbiddenCols = new Set([\"sequence_number\", \"final_status\", \"workflow_data\", \"updated_at\"]); let fail = false; for (const f of fs.readdirSync(dir).filter(x => x.endsWith(\".sql\"))) { const fp = path.join(dir, f); const txt = fs.readFileSync(fp, \"utf8\"); for (const c of forbiddenCols) { if (new RegExp(`\\\\b${c}\\\\b`).test(txt)) { fail = true; helpers.addDiagnostic(fp, 1, 1, `View SQL 引用不存在的欄位 \"${c}\"（應改為 json_extract(input_data,...) 或 json_extract(output_data,...)）`, \"error\"); } } } return { success: !fail };",
    "args": { "dir": "draft/draft-omni-cash-transaction/db/migration" }
  }'
```

##### 檢查 6️⃣：`onErrors` 覆蓋率 + `notifyOps` 在 `*_FAILED` 終態必觸發
**目的**：杜絕 Audit Gap 稽核斷層，補償失敗靜默忽略。

```bash
curl -s -X POST http://127.0.0.1:8091/api/run \
  -H "Content-Type: application/json" \
  -d '{
    "script": "const dir = path.join(workspaceRoot, args.dir); let fail = false; for (const f of fs.readdirSync(dir).filter(x => x.endsWith(\".sw.yaml\"))) { const fp = path.join(dir, f); const txt = fs.readFileSync(fp, \"utf8\"); const wf = helpers.parseYaml(txt); const ops = (wf.states || []).filter(s => s.type === \"operation\"); const withOnErrors = (wf.states || []).filter(s => s.onErrors && s.onErrors.length > 0); if (ops.length > 1 && withOnErrors.length < (ops.length - 1)) { fail = true; helpers.addDiagnostic(fp, 1, 1, `onErrors 覆蓋不足 (${withOnErrors.length}/${ops.length})`, \"error\"); } if (/ROLLBACK_FAILED|CANCEL_ROLLBACK_FAILED|SWIFT_ROLLBACK_FAILED|LOOKUP_FAILED/.test(txt) && !txt.includes(\"refName: notifyOps\")) { fail = true; helpers.addDiagnostic(fp, 1, 1, `含有 *_FAILED 終態但未呼叫 notifyOps 告警`, \"error\"); } } return { success: !fail };",
    "args": { "dir": "draft/draft-omni-cash-transaction/workflows" }
  }'
```

---

### 備援方案 — Python one-liner Gates（Agent Runner 不可用時降級使用）

> 若 Agent Runner 未啟動或 port 8091 被佔用，可使用下列 Python one-liner 降級方案。
> 腳本支援直接傳入參數：`python3 -c "..." [<draft_dir>] [<project_dir>]`，預設自動偵測 `draft-*` 與 `project-0825-pd`。

### Gate 1: OpenAPI 自洽性預檢 (Spec Self-Consistency Linter)
* **目的**：檢查 `notebooks/internal/*.yaml` 內部是否自相矛盾（驗證 `example` 是否符合 `pattern`、`minLength`、`maxLength`，杜絕規格與測試資料長度衝突）。
* **⭐ 推薦優先使用 Agent Runner**：詳見 Step 1.5A.0 一鍵預檢 + Step 1.5A.1 檢查 5️⃣（同類規則）。本 Gate 保留作為 Agent Runner 不可用時的 Python 降級方案。
* **檢測**：
```bash
python3 -c '
import yaml, re, glob, sys, os
DRAFT = sys.argv[1] if len(sys.argv) > 1 else (glob.glob("draft-*")[0] if glob.glob("draft-*") else ".")
has_error = False
for f in glob.glob(f"{DRAFT}/notebooks/internal/*.yaml"):
    spec = yaml.safe_load(open(f))
    schemas = spec.get("components", {}).get("schemas", {})
    for sname, sdef in schemas.items():
        for pname, pdef in sdef.get("properties", {}).items():
            pattern = pdef.get("pattern")
            example = str(pdef.get("example", ""))
            min_l = pdef.get("minLength")
            max_l = pdef.get("maxLength")
            if example:
                if pattern:
                    clean_p = pattern.strip("^$")
                    if not re.fullmatch(clean_p, example):
                        print(f"❌ [Gate 1 FAIL] {f} -> {sname}.{pname}: example \"{example}\" 不符合 pattern \"{pattern}\"")
                        has_error = True
                if min_l and len(example) < min_l:
                    print(f"❌ [Gate 1 FAIL] {f} -> {sname}.{pname}: example 長度 {len(example)} < minLength {min_l}")
                    has_error = True
                if max_l and len(example) > max_l:
                    print(f"❌ [Gate 1 FAIL] {f} -> {sname}.{pname}: example 長度 {len(example)} > maxLength {max_l}")
                    has_error = True
if has_error:
    print("⚠️ 請放寬 OpenAPI 正則或修正 example 長度，否則正常測試皆會被 400 REJECTED_VALIDATION 攔截！")
    sys.exit(1)
print("✅ [Gate 1 PASS] OpenAPI Spec 自洽性檢查通過")
' draft-remittance
```

### Gate 2: OpenAPI ↔ Mock 端點覆蓋門禁 (Endpoint Coverage Gate)
* **目的**：防止 Draft 遺漏被調主機的補償或反向端點（例如核心帳務只寫了 `/Debit/Execute` 卻遺漏 `/Refund/Execute`），並精確拼接 JAX-RS 類別層級與方法層級 `@Path`，嚴禁子字串包含誤判。* **⭐ 推薦優先使用 Agent Runner**：詳見 Step 1.5A.0 一鍵預檢腳本（內含對應邏輯）。本 Gate 保留作為 Python 降級方案。* **檢測**：
```bash
python3 -c '
import yaml, glob, re, sys, os
DRAFT = sys.argv[1] if len(sys.argv) > 1 else "draft-remittance"
PROJECT = sys.argv[2] if len(sys.argv) > 2 else "project-0825-pd"
has_error = False

# 1. 蒐集工作流調用的所有 external schemaRef
called_ops = set()
for f in glob.glob(f"{DRAFT}/spec/*.sw.yaml"):
    for line in open(f):
        m = re.search(r"schemaRef:\s*[\x27\"]?specs/external/([^#]+)\.yaml#([a-zA-Z0-9_]+)", line)
        if m:
            called_ops.add((m.group(1), m.group(2)))

# 2. 解析所有 Mock Resource，拼接類別層級與方法層級 @Path 形成完整端點清單
mock_files = glob.glob(f"{DRAFT}/spec/mocks/*.java") + glob.glob(f"{PROJECT}/dev/transfer-mock/src/main/java/**/*.java", recursive=True)
mock_endpoints = set()
for mf in mock_files:
    content = open(mf, errors="ignore").read()
    paths = re.findall(r"@Path\(\s*\"([^\"]+)\"\s*\)", content)
    if not paths: continue
    c_idx = content.find("class ")
    p_idx = content.find("@Path")
    has_class_path = p_idx < c_idx if c_idx != -1 else False
    if has_class_path:
        cp = paths[0].rstrip("/")
        subs = paths[1:]
        if subs:
            for sp in subs:
                mock_endpoints.add(re.sub(r"\{[^}]+\}", "{x}", (cp + "/" + sp.lstrip("/")).replace("//", "/")))
        else:
            mock_endpoints.add(re.sub(r"\{[^}]+\}", "{x}", cp))
    else:
        for p in paths:
            mock_endpoints.add(re.sub(r"\{[^}]+\}", "{x}", p))

# 3. 比對 operationId 對應之 OpenAPI 端點是否在 Mock 中 100% 存在
for api_file, op_id in called_ops:
    yaml_path = glob.glob(f"{DRAFT}/notebooks/external/{api_file}.yaml")
    if not yaml_path: continue
    spec = yaml.safe_load(open(yaml_path[0]))
    for path, path_item in spec.get("paths", {}).items():
        for method, op in (path_item or {}).items():
            if isinstance(op, dict) and op.get("operationId") == op_id:
                skel = re.sub(r"\{[^}]+\}", "{x}", path)
                if skel not in mock_endpoints:
                    print(f"❌ [Gate 2 FAIL] 缺少 Mock 端點: {api_file}.yaml#{op_id} -> {method.upper()} {path}")
                    has_error = True
if has_error:
    print("⚠️ 缺少對應 Mock 端點，執行期將報 404 Not Found！請先於 draft/spec/mocks/ 補全 Resource 方法。")
    sys.exit(1)
print("✅ [Gate 2 PASS] 所有被調主機端點 Mock 覆蓋率達 100%")
' draft-remittance project-0825-pd
```

### Gate 3: Workflow ↔ Java 服務契約靜態比對 (Contract Linter)
* **目的**：驗證 Workflow 宣告的 Java 類別（FQCN）在專案中真實存在（**必須符合 Package 完整相對路徑，防跨 Package 誤放行**），且方法重載完整。
* **檢測**：
* **⭐ 推薦優先使用 Agent Runner**：詳見 Step 1.5A.0 一鍵預檢腳本（內含對應邏輯）。本 Gate 保留作為 Python 降級方案。
```bash
python3 -c '
import yaml, glob, re, sys, os
DRAFT = sys.argv[1] if len(sys.argv) > 1 else "draft-remittance"
PROJECT = sys.argv[2] if len(sys.argv) > 2 else "project-0825-pd"
has_error = False

for f in glob.glob(f"{DRAFT}/spec/*.sw.yaml"):
    wf = yaml.safe_load(open(f))
    for fn in wf.get("functions", []):
        op = fn.get("operation", "")
        if op.startswith("service:"):
            # 格式: service:com.package.Class::method
            target = op.replace("service:", "")
            fqcn, method = target.split("::")
            expected_rel = fqcn.replace(".", "/") + ".java"
            exact_hits = [h for h in glob.glob(f"{PROJECT}/**/*.java", recursive=True) if h.replace("\\", "/").endswith(expected_rel)]
            if not exact_hits:
                cls_name = fqcn.split(".")[-1]
                cls_hits = glob.glob(f"{PROJECT}/**/{cls_name}.java", recursive=True)
                if cls_hits:
                    print(f"❌ [Gate 3 FAIL] Package 命名空間不符: {fqcn} (宣告於 {f}，但實體類別位於 {cls_hits[0]})")
                else:
                    print(f"❌ [Gate 3 FAIL] 找不到 Java 服務類別: {fqcn} (宣告於 {f})")
                has_error = True
                continue
            content = open(exact_hits[0], errors="ignore").read()
            sigs = re.findall(r"public\s+\S+\s+" + re.escape(method) + r"\s*\(", content)
            if len(sigs) == 0:
                print(f"❌ [Gate 3 FAIL] 類別 {fqcn} 中找不到方法 {method}()！請檢閱該類別既有方法或建立對應實作。")
                has_error = True
            else:
                # 提示 AI 比對 YAML arguments 與既有簽名，優先對齊既有標準
                print(f"ℹ️ [Gate 3 CHECK] 命中 {fqcn}::{method} (現有 {len(sigs)} 個簽名)。請檢視該類別標準簽名，優先修改 Workflow YAML arguments 對齊平台，嚴禁濫造多載！")
if has_error:
    print("⚠️ Java 服務類別不存在、Package 錯誤或完全找不到方法，請依『平台優先原則』對齊簽名或建立類別。")
    sys.exit(1)
print("✅ [Gate 3 PASS] 所有 Workflow custom service FQCN 與既有 Java 方法對齊通過")
' draft-remittance project-0825-pd
```

---

## Step 2: 掛載特徵目錄 (零拷貝裝配，單一目錄自治)

> ⛔ **鐵律：嚴禁執行任何手動 `cp` 到主模組**。
> 絕不要把檔案手動複製到 `domain-transfer/transfer-workflow` 或 `distribution/transfer-app/src/main/resources`！
> 所有檔案一律集中於 `project/features/<feature-name>/`，由 Maven 建置期自動探測裝配。

```bash
# 標準掛載：只需將草稿目錄整包複製到 project/features/
cp -r draft-<name> project/features/<feature-name>
```

**特徵目錄自治規範**：
```
project/features/<feature-name>/
├── feature.yaml                    # 特徵元資料
├── docs/                           # 規格書與設計說明
├── workflows/                      # *.sw.yaml (Kogito 工作流程)
├── specs/
│   ├── internal/                   # 內部入口 API (*-api.yaml, 必含 x-workflow-id)
│   └── external/                   # 被調外部 host API (*-api.yaml, 必無 x-workflow-id)
├── mocks/                          # JAX-RS Mock 模擬服務
│   └── dto/                        # Mock DTO (package: org.acme.transfer.api.features.dto)
├── services/                       # 業務檢核器 (實作 BusinessRuleValidator, CDI 動態註冊)
├── db/
│   ├── migration/V*.sql            # 對帳視圖 (雙軌探測版本號)
│   └── teardown.sql                # 抽離專用回滾腳本
└── tests/                          # 整合測試 (package: com.example.platform.distribution.transfer.features)
```

---

## Step 3: 工作流規格校正 (特徵目錄內部原地修訂)

> 所有修訂均在 `project/features/<feature-name>/workflows/*.sw.yaml` 內完成，**嚴禁複製到主專案**。

### Step 3a: 版本字串精確匹配
`subFlowRef.version` 必須與 child 頂層 `version:` 字串完全相等（含 `"1.0"` vs `"1.0.0"` 差異）。在特徵目錄內逐一核對：
```bash
grep -n "version:" project/features/<feature-name>/workflows/*.sw.yaml
```

### Step 3b: ⭐ Kogito 10.2.0 codegen bug 修正

**症狀預兆**: 任何 workflow 有 `subFlowRef:` 且 workflow id 含 hyphen (`-`)。

**檢測**:
```bash
grep -l "subFlowRef" <project>/domain-transfer/transfer-workflow/src/main/resources/*.sw.yaml
# 若結果的 yaml 內有 id: xxx-yyy → 必須改名
```

**解法** (Python):
```python
mappings = {
    "omni-cash-transaction": "omni_cash_transaction",
    "repayment-cash-deposit": "repayment_cash_deposit",
    "repayment-cash-cancellation": "repayment_cash_cancellation",
    # ... 視實際 draft 而定
}
for f in workflow_yaml_files:
    content = open(f).read()
    for old, new in mappings.items():
        content = content.replace(old, new)
    open(f, "w").write(content)
```

**影響與對外路由透明代理**:
- Kogito 內部工作流 ID 與原生端點變更為 `/xxx_yyy`。
- **對外 API 端點完全不需要妥協變更**: 只要在 `specs/internal/*.yaml` 中宣告原始業務路徑（如 `/Omni/{creditcardid}/Repayment/Execute`）並標註 `x-workflow-id: xxx_yyy`，平台層的 `InternalOpenApiDynamicRouter` (Vert.x 動態路由代理) 便會自動攔截並透明轉發至內部端點，同時自動將 URL 路徑參數（如 `{creditcardid}`）注入 Request Body 頂層，**100% 維持原始對外契約，無需 hotfix 外部路徑**！

---

## Step 4: 補 Java 服務

### Step 4a: 識別需要新建 / 修改的 service

讀 draft 的 `spec.md §0` 假設清單,找出所有 `假設 FQCN` 的 service。例如:
- H6: `AuditLogService::findBySequenceNumber` → 擴充既有 (若 Gate 3 已 PASS 則跳過新建，僅核對 overload 簽名)
- H13: `IdempotencyService` → 若專案已存在則沿用，僅 H13a 類 `*BusinessRuleValidator` 為新建
- H14: `AuditLogService::markCancelledBy` → 擴充既有

> **存在即跳過**：Gate 3 通過的類別/方法嚴禁重建，否則造成重複定義衝突。

### Step 4b: 新建 service 類別

放在 `domain-reconciliation/reconciliation-api/src/main/java/com/example/reconciliation/` 或 `domain-transfer/transfer-workflow/...`

**模板** (以 `IdempotencyService` / `OpenApiSchemaValidator` 為例):
```java
@ApplicationScoped
public class IdempotencyService {
    @Inject DataSource dataSource;
    private static final ObjectMapper MAPPER = new ObjectMapper();

    // 1. 展開參數版入口: 必須完全精確吻合 Workflow YAML arguments 鍵名與型別！
    //    若 arguments 為 { workflowId: "...", businessKey: '${ .seq }' }
    //    Kogito codegen 會嚴格比對此簽名。若缺少，編譯將拋出 NoSuchMethodException / ProcessCodegenException！
    public JsonNode findBySequenceNumber(String workflowId, Object businessKey) {
        // ... v1.0 簡化實作: query workflow_execution_log
    }

    // 2. 跨工作流命名相容多載 (例如 remittance 傳 sequenceNumber、omni 傳 businessKey)
    public JsonNode findBySequenceNumber(String workflowId, Object sequenceNumber) {
        return findBySequenceNumber(workflowId, (Object) sequenceNumber);
    }

    // 3. 通用 JsonNode 單參數版入口 (供通用 custom 呼叫)
    public JsonNode findBySequenceNumber(JsonNode arguments) { ... }
}
```

**⭐ Java 服務三大防護鐵律 (防範方法爆炸與介面腐化)**:
1. **調用端主動對齊平台標準 (Caller Adapts to Callee)**:
   - 當 Kogito Codegen 報錯 `could not find a method called ...` 時，**嚴禁直覺性地在 Java 類別中新增臨時多載 (overload)**！
   - AI 必須先閱讀既有 Java 服務，找出 Canonical 標準簽名（例如 `AuditLogService.saveLog` 標準 5 參）。**第一優先是修改 Workflow YAML 的 `arguments` 去對齊平台標準**，絕不讓未經審核的草稿破壞共用平台架構。
2. **嚴禁只提供 `(JsonNode arguments)`**: 當 Workflow YAML 在 `arguments:` 宣告具名參數時，Kogito 代碼生成器不會包裝為單一 JsonNode，而是直接查找具名參數的方法簽名。因此新建服務時需提供標準展開參數版。
3. **回傳結構對齊 actionDataFilter**: 檢查工作流 YAML 內 `results: '{key: .key}'` 提取的鍵名（例如某些流程期望 `.found`，某些期望 `.idempotentReplay`），Java 回傳之 `ObjectNode` 必須同時滿足或提供別名欄位！

### Step 4c: 擴充既有 AuditLogService (⭐ 解除 SQL 硬編碼與對齊 5-arg 標準)

平台稽核日誌唯一標準入口（SSOT）為 5 參數介面：
```java
// ✅ 平台唯一標準入口：工作流必須一律以 5 參數宣告對齊此方法
public JsonNode saveLog(String workflowId, Object businessKey, Object processInstanceId, Object inputData, Object outputData) { ... }

// 既有 doSaveLog 維持不變,加對應重載與參數化查詢
public JsonNode findBySequenceNumber(String workflowId, Object businessKey) { ... }
public JsonNode findBySequenceNumber(JsonNode arguments) { ... }

// ⚠️ 嚴禁在 SQL 硬編碼 WHERE workflow_id = '特定業務流程'！
// 必須支援傳入 workflowId 參數化，或動態兼容歷史流程：
public JsonNode markCancelledBy(String workflowId, Object originalSequenceNumber, Object cancelledBy, Object cancelledAt) { ... }
public JsonNode markCancelledBy(Object originalSequenceNumber, Object cancelledBy, Object cancelledAt) { ... }
public JsonNode markCancelledBy(JsonNode arguments) { ... }
```

### Step 4d: ⭐ 若需新欄位或對帳 View,加 Flyway migration (雙軌版本探測)

**⚠️ 踩坑預警 (靜默跳過致命陷阱)**:
`DatabaseMigrationRunner.java` 在執行遷移時，會先檢查 `if (appliedVersions.contains(script.getVersion())) continue;`。
若僅用 `find` 掃描專案檔案系統，可能因其他分支或本地 SQLite 資料庫（`data/reconciliation.db`）早已套用過該版本（例如實體 DB 已有 `1.2.5`，而檔案只見 `1.2.0`），導致新腳本**被完全靜默跳過**，對帳 View 根本未被建立！

**雙軌自動探測演算法 (Dual-Track Migration Probe)**:
在為新 Draft 命名 Flyway 腳本前，版本號取：
$$\text{Target Version} = \max(\text{檔案系統最大版本}, \text{實體 DB schema\_history 最大版本}) + 1$$

```bash
# 雙軌探測指令 (需在 vibe_design_0907 父目錄執行；PROJECT 指向 project-0825-pd):
# 注意：reconciliation_schema_history 主鍵為 installed_rank（無 id 欄），
# 取版號必須 SELECT 全量再 sort -V，嚴禁 ORDER BY id。
file_v=$(find <project>/ -path "*/db/migration/V*.sql" 2>/dev/null | grep -oE "V[0-9]+(\.[0-9]+)*" | sort -V | tail -n 1 | sed 's/V//')
db_v=$(sqlite3 <project>/data/reconciliation.db "SELECT version FROM reconciliation_schema_history WHERE success = 1;" 2>/dev/null | sort -V | tail -n 1 || echo "0")

echo "=========================================="
echo "檔案系統最新版本: ${file_v:-0}"
echo "實體 DB 最新版本: ${db_v:-0}"
# 計算兩者較大者
max_v=$(echo -e "${file_v:-0}\n${db_v:-0}" | sort -V | tail -n 1)
echo "目前專案安全基線: $max_v (新腳本必須嚴格大於此版本，例如遞增末碼)"
echo "=========================================="
```

**⭐ 推薦：使用 Agent Runner 一鍵探測（涵蓋 DB 子進程調用）**

```bash
# 推薦方案：跨平台 + VS Code 紅線聯動 + 同時掃檔案與實體 DB
curl -s -X POST http://127.0.0.1:8091/api/run \
  -H "Content-Type: application/json" \
  -d '{
    "script": "const projectRoot = path.join(workspaceRoot, args.project); function findSqls(dir) { let r = []; if (!fs.existsSync(dir)) return r; for (const e of fs.readdirSync(dir, { withFileTypes: true })) { const fp = path.join(dir, e.name); if (e.isDirectory()) r = r.concat(findSqls(fp)); else if (e.name.endsWith(\".sql\") && fp.includes(\"/db/migration/\")) r.push(e.name); } return r; } function parseLatest(sqls) { let maxMaj = 0, maxMin = 0, maxPat = -1, latest = null; for (const s of sqls) { const m = s.match(/^V(\\d+)(?:\\.(\\d+))?(?:\\.(\\d+))?__/); if (m) { const maj = +m[1], min = +(m[2] || \"0\"), pat = +(m[3] || \"0\"); if (maj > maxMaj || (maj === maxMaj && min > maxMin) || (maj === maxMaj && min === maxMin && pat >= maxPat)) { maxMaj = maj; maxMin = min; maxPat = pat; latest = `V${maj}.${min}.${pat}`; } } } return { latest, maxMaj, maxMin, maxPat }; } const fileResult = parseLatest(findSqls(projectRoot)); let dbResult = { latest: null, maxMaj: 0, maxMin: 0, maxPat: -1 }; try { const dbPath = path.join(projectRoot, \"data/reconciliation.db\"); if (fs.existsSync(dbPath)) { const { execSync } = require(\"child_process\"); const out = execSync(`sqlite3 ${dbPath} \"SELECT version FROM reconciliation_schema_history WHERE success = 1;\"`).toString(); const versions = out.split(\"\\n\").map(l => l.trim()).filter(Boolean); dbResult = parseLatest(versions.map(v => `V${v}__dummy.sql`)); } } catch (e) { console.log(`⚠️ DB 探測失敗: ${e.message}`); } const fileMaj = fileResult.maxMaj, fileMin = fileResult.maxMin, filePat = fileResult.maxPat + 1; const dbMaj = dbResult.maxMaj, dbMin = dbResult.maxMin, dbPat = dbResult.maxPat + 1; let useMaj = fileMaj, useMin = fileMin, usePat = filePat; if (dbMaj > useMaj || (dbMaj === useMaj && dbMin > useMin) || (dbMaj === useMaj && dbMin === useMin && dbPat > usePat)) { useMaj = dbMaj; useMin = dbMin; usePat = dbPat; } const next = `V${useMaj}.${useMin}.${usePat}`; console.log(`檔案系統最新版本: ${fileResult.latest || \"無\"}`); console.log(`實體 DB 最新版本: ${dbResult.latest || \"無\"}`); console.log(`建議新版本: ${next}`); return { fileLatest: fileResult.latest, dbLatest: dbResult.latest, nextSuggested: next };",
    "args": { "project": "project" }
  }'
```

> 💡 此腳本同時掃描檔案系統 (`findSqls`) 與實體 DB (`execSync("sqlite3 ...")`)，自動取 `max + 1` 作為安全基線，杜絕 `DatabaseMigrationRunner` 靜默跳過新腳本。

**版本規範**: `V<X>.<Y>.<Z>__<description>.sql` (若安全基線為 `1.2.5`，則新版本必須命名為 `V1.2.6__...`)

```sql
-- 範例: 對帳檢視表
-- ⚠️ 重要：SQLite 不支援 CREATE OR REPLACE VIEW，且 CREATE VIEW IF NOT EXISTS 若 View 已存在則不會重新觸發或更新欄位定義。
-- 因此在 CREATE 之前務必先加上 DROP VIEW IF EXISTS，確保視圖修改與重構能確實生效！
DROP VIEW IF EXISTS vw_<workflow>_reconciliation;
CREATE VIEW IF NOT EXISTS vw_<workflow>_reconciliation AS
SELECT
    id, created_at, workflow_id, business_key, process_instance_id, status, message,
    json_extract(input_data, '$.partyId') AS party_id,
    cancelled_by, cancelled_at
FROM workflow_execution_log
WHERE workflow_id IN ('<parent_workflow_id>', '<child_a_id>', '<child_b_id>');
```

放置於 `project/features/<feature-name>/db/migration/V<X>.<Y>.<Z>__<desc>.sql`。
同時必須撰寫 `project/features/<feature-name>/db/teardown.sql` 供熱抽離時乾淨回滾：
```sql
DROP VIEW IF EXISTS vw_<workflow>_reconciliation;
DELETE FROM reconciliation_schema_history WHERE script LIKE '%<workflow>%';
```
> ⛔ **嚴禁手動拷貝到主專案** `db/migration/`！Maven 建置期會自動探測裝配。

---

## Step 5: Mock 模擬服務規範 (特徵目錄內部自治)

> Mock 原始碼直接放在 `project/features/<feature-name>/mocks/`，DTO 放在 `mocks/dto/`。
> 由 `dev/transfer-mock/pom.xml` 在 `initialize` 階段自動探測並同步至 `transfer-mock/src/main/java/org/acme/transfer/api/features/`（已在 `.gitignore`，抽離時零殘留）。
> ⛔ **嚴禁手動拷貝到 `dev/transfer-mock/src/main/java`**！

### Step 5a: Package 命名規範
- Resource: `package org.acme.transfer.api.features;`
- DTO: `package org.acme.transfer.api.features.dto;`
在 Draft 產出時即應對齊上述 package，嚴禁使用 `org.acme.transfer.api` 或 `org.acme.transfer.api.dto` 以免與既有核心共享類別衝突。

### Step 5b: ⭐ 避免 sed 二次替換陷阱

**坑**: 如果 draft 的 DTO 已經在 `org.acme.cashrepayment.api.dto` package,sed 兩次替換會變成 `org.acme.transfer.api.dto.dto` (錯誤)。

**預防**:
```python
# 用 Python 取代 sed,精準控制替換邏輯
# 或用兩階段 sed:
# 1. 先把 .cashrepayment.api.dto. 換成 .transfer.api.dto. (全詞匹配)
# 2. 再把 .cashrepayment.api. 換成 .transfer.api. (排除已換過的)
```

**⭐ 推薦：先用 Agent Runner 偵測套件錯位，再由 AI 顯式編輯**

```bash
# 整合前預檢：掃描 draft DTO 套件與 features/ 同步目錄的一致性
curl -s -X POST http://127.0.0.1:8091/api/run \
  -H "Content-Type: application/json" \
  -d '{
    "script": "const draftDir = path.join(workspaceRoot, args.dir); if (!fs.existsSync(draftDir)) return { success: true, skipped: true }; let bad = []; for (const f of fs.readdirSync(draftDir).filter(x => x.endsWith(\".java\"))) { const fp = path.join(draftDir, f); const pkg = fs.readFileSync(fp, \"utf8\").match(/^package\\s+([\\w.]+);/m)?.[1]; if (pkg && !pkg.includes(\".features.\")) { bad.push({ file: f, pkg }); helpers.addDiagnostic(fp, 1, 1, `DTO 套件 ${pkg} 與 features/ 同步目錄不一致 (應為 org.acme.transfer.api.features.dto)`, \"error\"); } } return { mismatched: bad.length };",
    "args": { "dir": "draft/draft-omni-cash-transaction/mocks/dto" }
  }'
```

> Runner 只負責**偵測錯位並標紅線**，實際的批次套件改名仍需 AI 透過 `replace_string_in_file` 完成（避免 Runner 越權做寫入）。詳見 Step 1.5A.1 檢查 4️⃣。

### Step 5c: DTO 放 `org.acme.transfer.api.dto/` 子目錄

### Step 5d: ⭐ Mock 端點完整性覆蓋與防重複覆寫 (Coverage & DTO Protection)

1. **正反向與補償端點 100% 覆蓋**:
   - 被調主機除了正向操作（如 `/Debit/Execute`、`/Send/Execute`），凡工作流具備補償或取消路徑（如 `/Refund/Execute`、`/Cancel/Execute`），Mock Resource 必須完整實作，嚴防集成測試時回傳 HTTP 404 Not Found。
2. **避免覆寫既有共享 DTO**:
   - 若目標專案 `dev/transfer-mock/.../dto/` 已存在共享類別（例如 `ErrorDetail.java`），落檔前先比對欄位，若結構相容則保留專案既有檔案，避免重複定義或覆寫破壞其他業務模組。

---

## Step 6: ⭐ 4 個 workflow 內容修正(整併特有的坑)

### 6a. Path parameter 注入

**症狀**: workflow 調用 OpenAPI 時報 `Illegal character in path ... {xxx}`。

**根因**: mock 的 `@Path("/foo/{xxx}/bar")` 但 workflow 沒在 payload 帶 `xxx`。

**解法**: 在每個 callApiViaOpenAPI 的 payload 內顯式加:
```yaml
payload:
  creditcardid: '${ .partyId }'   # ← 補上
  partyId: '${ .partyId }'
  ...
```

**小心**: YAML list item 不要 trailing comma:
```yaml
# ✗ 錯
creditcardid: '${ .partyId }',
# ✗ 對 (無 comma)
creditcardid: '${ .partyId }'
```

### 6b. actionDataFilter 結構對齊 MyOpenApiService

**症狀**: workflow 走到 FAILED 分支但 host API 回 200,因為 `.result.status` 是 null。

**根因**: `MyOpenApiService` 把 host API response 直接放頂層(`.code` / `.message` / `.Account` 等),不是 `.result` 底下。

**解法**: 改 actionDataFilter 直接讀頂層:
```yaml
# ✗ 錯 (假設 response 在 .result 下)
results: '{status: .result.status, message: .result.message, track_id: .result.track_id}'

# ✓ 對 (直接讀頂層)
results: '{status: .status, message: .message, track_id: .track_id, errorType: .errorType, _httpStatus: ._httpStatus, errors: .errors}'
```

### 6c. ⭐ status-rewrite filter 加 finalStatus 支援

**前置檢查（已修即跳過）**：若 `platform-security/.../SonataFlowSecurityConfig.java` 已含 `map.get("finalStatus")`，跳過 Java 修改，僅做 Step 7 mapping 追加，避免重複編輯造成 merge conflict。

**症狀**: workflow 回 `finalStatus: REJECTED_VALIDATION` 但 HTTP code 是 200(應該 400)。

**根因**: 既有 `WorkflowStatusFilter` 只讀 `status` 欄位。新 omni convention 用 `status: 0/1` (int) + `finalStatus: STRING`。

**解法**: 修改 `platform-security/.../SonataFlowSecurityConfig.java` 的 filter:
```java
// 改前
Object status = map.get("status");

// 改後 (優先 finalStatus,退回 status;且只對 String 映射)
Object status = map.get("finalStatus");
if (status == null) {
    status = map.get("status");  // 向下相容 saga2
}
if (status != null && status instanceof String) {
    Integer rewrite = statusRewriteMap.get(status.toString());
    if (rewrite != null) {
        responseContext.setStatus(rewrite);
    }
}
```

### 6d. SQL view workflow_id 對齊與 View 覆蓋更新

**症狀**: V<X> SQL view 套用後查詢回 0 筆，或更新了 View 欄位但實體 DB 依然讀取舊結構。

**根因**:
1. view 的 `WHERE workflow_id IN (...)` 用了 draft 的 hyphen id，實際是 underscore。
2. SQLite 的 `CREATE VIEW IF NOT EXISTS` 若 View 已存在則不會重新觸發或更新欄位定義；若腳本未在之前宣告 `DROP VIEW IF EXISTS`，則視圖定義不會更新。

**解法**: 改 V<X> SQL 內的 id 清單，並在 V<X> 腳本中的 `CREATE VIEW` 之前務必加上 `DROP VIEW IF EXISTS <view>;`（以確保可重複套用與更新定義）。

### 6e. ⭐ actionDataFilter 必須宣告 toStateData (防 State Data 沖洗)

**症狀**: workflow 執行後下游節點或 `FinalAuditAndEnd` 取得的欄位（如 `partyId`, `amount`, `sequenceNumber`）全部為 `null`，且回應中的業務資料遺失。

**根因**: 在 operation state 中若僅配置 `actionDataFilter.results: '{ ... }'` 但未指定 `toStateData`，Kogito 預設會將 action results 物件**整份覆蓋**當前 Workflow State Data。

**解法**: 永遠顯式指定 `toStateData`:
```yaml
# ❌ 錯 (state data 被覆寫為僅有 validationResult)
actionDataFilter:
  results: '${ { validationResult: . } }'

# ✅ 對 (保留所有原始輸入欄位，僅注入指定 key)
actionDataFilter:
  results: '{isValid: .isValid, message: .message, errors: .errors}'
  toStateData: '${ .validationResult }'
```

### 6f. ⭐ SQLite 對帳視圖測試的歷史資料污染防護

**症狀**: 測試案例（如 `testA6ReconciliationView`）比對 `rs.getString("operation_type")` 斷言失敗（例如預期 `"A"` 但得到 `"C"`）。

**根因**: SQLite DB 跨測試方法持久化。若 SQL 僅用 `WHERE workflow_id = 'xxx' AND amount = 'xxx' LIMIT 1`，會因未排序且無狀態過濾，撈到前面失敗測試（如 P1 `operationType=C`）遺留的舊資料。

**解法**: 測試 SQL 必須加入精確的狀態約束與倒序排列：
```java
// ✅ 對: 限制 status='SUCCESS' 並以 id 倒序取最新一筆
ResultSet rs = stmt.executeQuery(
    "SELECT id, workflow_id, business_key, status, operation_type, amount " +
    "FROM vw_omni_cash_transaction_reconciliation " +
    "WHERE workflow_id = 'omni_cash_transaction' AND status = 'SUCCESS' AND amount = '0000011758' " +
    "ORDER BY id DESC LIMIT 1"
);
```

### 6g. ⭐ 操作健壯性與稽核安全網 (onErrors & OpsAlert Guard)

**症狀 A (Audit Gap 稽核斷層)**: Host 呼叫逾時或網路中斷（SocketTimeoutException）時，Workflow 直接中斷拋 500，未走到 `FinalAuditAndEnd`，導致 DB 無任何執行日誌記錄。
- **解法**: 凡工作流頂層宣告 `errors: [{name: platformError}]`，**每個 `type: operation` 節點必須標註 `onErrors`**（轉移至補償或結尾狀態），嚴禁操作裸奔！

**症狀 B (jq Null Pointer 崩潰)**: switch 條件判斷式 `(.coreResult.status | tostring) != "0"`，當前置操作失敗導致 `coreResult` 為 null 時，jq 拋出異常。
- **解法**: 所有 `condition:` 讀取嵌套欄位時，**一律加入 `//` 預設值保護**：
  ```yaml
  # ❌ 易崩潰
  condition: '${ (.coreResult.status | tostring) != "0" }'
  # ✅ 安全守衛
  condition: '${ ((.coreResult.status // "999") | tostring) != "0" }'
  ```

**症狀 C (回沖失敗靜默忽略)**: 當流程流轉至 `*_ROLLBACK_FAILED` 時靜默結束，未觸發運維通道。
- **解法**: 凡具備 `ROLLBACK_FAILED` 終態的工作流程，必須在結尾節點調用 `notifyOps`（`OpsAlertService::raise`），確保輸出 `[OPS-ALERT]` 供日誌監控攔截。

**症狀 D (取消標記無檢查)**: `MarkCancelled` 類 operation 無 `actionDataFilter`、直接進終態輸出，`markCancelledBy` 回 `rowsUpdated=0` 無人發現。
- **解法**: `markCancelledBy` 節點必須加 `actionDataFilter.results/toStateData` 並檢查結果，失敗時轉 `CANCEL_ROLLBACK_FAILED` 分支，嚴禁裸調直出。

### 6h. 業務欄位 literal 告警 (P3，非阻擋)
`currency/BIC/country/address/fee/rate` 六類業務欄位僅允許 `OUR/BEN/A/B/C/R` 字面值，其餘必須 `${ .field }`；`amountInUSD` 類衍生欄位必須含運算式（含 `fxRate` 或 §0 假設註明）。整併時人工複核：
```bash
grep -nE "senderBIC|receiverBIC|beneficiaryCountry|remitterAddress|feeAmount|amountInUSD|fxRate" <project>/domain-transfer/transfer-workflow/src/main/resources/*.sw.yaml
```

### 6i. ⭐ Kogito jBPM Split 節點條件順序競態防護 (解耦冪等 Switch 與業務 Dispatcher)

**症狀**: 測試冪等重放（例如 `p4_idempotentReplay`）發送相同 sequenceNumber，期望 `IDEMPOTENT_REPLAY`，卻實際回傳 `SUCCESS` 再次執行了業務流程！
**根因**: 在 Kogito Serverless Workflow 中，單一 `switch` state 的多個 `dataConditions` 會被編譯為 jBPM `Split (XOR)` 節點。當 `replayHit` (`.idempotencyResult.idempotentReplay == true`) 與 `routeDomestic` (`.operationType == "A"`) 同時滿足時，jBPM 的條件求值順序是由內部集合 iteration 決定，**非 YAML 宣告的先後順序**！業務路由分支很容易掠奪冪等重放分支。
**解法**: 狀態機拓撲結構必須將「冪等結果判斷」與「業務路由分流」徹底解耦為前後兩個獨立的 Switch 狀態：
`CheckIdempotency` (operation) $\rightarrow$ `CheckIdempotencyResult` (switch，僅判斷 `idempotentReplay == true` 轉移至 `InjectIdempotentReplayStatus`，default 轉移至 `Dispatcher`) $\rightarrow$ `Dispatcher` (switch，僅依 `operationType` 路由至子工作流)。

### 6j. ⭐ 稽核日誌狀態雙向對齊與落庫保全 (`status` vs `finalStatus`)

**症狀**: 沖銷子流程查詢原交易時報 `badStatus`（狀態非 SUCCESS），或對帳紀錄中 `status` 為 `"UNKNOWN"`。
**根因**: 工作流結尾 `FinalAuditAndEnd` 呼叫 `recordAuditLog` 時，若 `outputData` 僅傳遞 `{finalStatus: .finalStatus}`，而底層 `AuditLogService` 僅解析 `status` 屬性，會導致落庫時 `status` 欄位被降級填入 `"UNKNOWN"`，破壞後續沖銷查詢與對帳校驗。
**解法**:
1. Workflow `outputData` 永遠同時提供雙向欄位：`outputData: '${ {status: .finalStatus, finalStatus: .finalStatus, message: (.finalMessage // "")} }'`。
2. `AuditLogService.doSaveLog` 實作兼顧 `has("status")` 與 `has("finalStatus")` 的雙重讀取。

---

## Step 7: ⭐ 合併 application.properties (組態合併協議)

修改 `<project>/distribution/transfer-app/src/main/resources/application.properties`:

**⚠️ 平台 MicroProfile Config 解析合約陷阱**:
專案中 `SonataFlowSecurityConfig.java` 對狀態碼改寫的讀取採用 **單行逗號分隔字串 (CSV)** 解析（`configuredMapping.split(",")`，每項為 `STATUS=CODE`）。
**嚴禁**將 Draft snippet 產出的展開格式（`platform.status-rewrite.mapping.STATUS=CODE`）直接貼入，否則會被 MicroProfile Config 靜默忽略，改寫完全失效！

### 7a. 正確合併三原則:

1. **工作流名單追加 (CSV Append)**:
   在 `platform.status-rewrite.workflows` 現有名單後以逗號追加新工作流程 ID：
   ```properties
   platform.status-rewrite.workflows=saga2-transfer-workflow,omni_cash_transaction,repayment_cash_deposit,repayment_cash_cancellation,<new_parent_id>,<new_child_id>
   ```

2. **狀態碼改寫追加 (CSV Append)**:
   在 `platform.status-rewrite.mapping` 現有映射後以逗號追加 `STATUS=HTTP_CODE`：
   ```properties
   platform.status-rewrite.mapping=VALIDATION_FAILED=400,ROLLBACK_FAILED=409,REJECTED_VALIDATION=400,LOOKUP_FAILED=500,CANCEL_ROLLBACK_FAILED=409,SWIFT_ROLLBACK_FAILED=409,AML_REJECTED_ROLLBACK_FAILED=409
   ```

3. **Function Bean Alias 註冊原則（嚴禁追加無效配置）**:
   - 工作流程中使用 `type: custom` 且 `operation: 'service:FQCN::method'`（例如 `validateOpenApiInput`、`checkIdempotency`、`recordAuditLog`、`notifyOps`）時，Kogito 10.2.0 Codegen 會自動生成對應的 Handler，並由 Quarkus Arc 依 **Java Type** 自動注入 `@ApplicationScoped` Bean。
   - **嚴禁**在 `application.properties` 追加 `%dev.kogito.sw.functions.<func>.bean=<beanName>`：
     - 此類設定不被 Quarkus 識別，啟動時會噴 `Unrecognized configuration key ... will be ignored` 警告。
     - 實質上為無效死配置（No-op），盲目追加會破壞「平台核心零修改」之特徵自治原則。
   - 僅有涉及 REST / OpenAPI 呼叫的端點連線覆寫時，才依需求設定 `.host` / `.port` / `.base_url`。

> 註: `RemittanceBusinessRuleValidator` 等實作 `BusinessRuleValidator` 的類別採 CDI 動態注入，`OpenApiSchemaValidator` 亦採自動掃描，皆無需在 properties 重複註冊 Bean。

---

## Step 8: 特徵整合測試規範 (特徵目錄內部自治)

> 測試檔案直接放在 `project/features/<feature-name>/tests/<Feature>WorkflowTest.java`。
> Package 命名：`package com.example.platform.distribution.transfer.features;`
> 由 `distribution/transfer-app/pom.xml` 在 `initialize` 階段自動探測並同步至 `transfer-app/src/test/java/.../features/`（已在 `.gitignore`，抽離時零殘留）。
> ⛔ **嚴禁手動拷貝到 `distribution/transfer-app/src/test/java/`**！

**測試撰寫注意事項**:
1. **動態唯一業務鍵**: 每個正向或反向測試，`sequenceNumber` 一律加上 `System.nanoTime()`，避免觸發 Parent 冪等快取。
2. **JDBC View 驗證防污染**: 如 6f 所述，查詢 View 時務必加上 `status = 'SUCCESS' ORDER BY id DESC LIMIT 1`。
3. **OpenAPI 動態路由斷言**: 透過 Vert.x 動態路由發送請求時，斷言應比對工作流程頂層回傳（如 `finalStatus`、`workflow`、`auditSaved`），避免依賴不存在的 `result.xxx` 嵌套欄位。

---

## Step 9: 編譯 → 測試 → package

### 9a: 編譯
```bash
mvn -B compile -DskipTests -fae -T 1 -Dmaven.wagon.http.retryHandler.count=10
```

### 9b: 測試

```bash
# ⭐ 推薦：特徵驗證必須加上 -am (also-make)！
# 根因：transfer-app 依賴 dev/transfer-mock。若單獨執行 -pl distribution/transfer-app，
# Maven 不會觸發 dev/transfer-mock 的 initialize 階段 Antrun，導致 features/*/mocks 未被拷貝，
# 核心 Host Mock 端點在 Quarkus runtime 未註冊而全部回傳 HTTP 404！
mvn -B test -pl distribution/transfer-app -am

# 全專案全模組回歸測試 (可選)
# 先清掉 .lastUpdated 失敗快取
find ~/.m2/repository -name "*.lastUpdated" -delete
find ~/.m2/repository -name "_remote.repositories" -delete
mvn -B test -fae -T 1 -Dmaven.wagon.http.retryHandler.count=10
```

### 9c: package
```bash
# 必須從根跑(子樹 -pl 會因 deployment extension descriptor 缺 jar 失敗)
mvn -B package -DskipTests -fae -T 1 -Dmaven.wagon.http.retryHandler.count=10
```

**預期時間**: 編譯 1-2min、測試 5-10min、package 3-5min(首次下載所有 deps 20-30min)。

---

## Step 10: 端對端 smoke test

```bash
# 啟動 (port 8080 是 mock 預期 port)
nohup java -Dquarkus.http.port=8080 -Dquarkus.profile=dev \
  -jar distribution/transfer-app/target/quarkus-app/quarkus-run.jar \
  > /tmp/transfer-app.log 2>&1 &

# 等 health
for i in {1..30}; do
  HC=$(curl -s -o /dev/null -w "%{http_code}" http://127.0.0.1:8080/q/health)
  [ "$HC" = "200" ] && break
  sleep 3
done

# 跑至少 5 個核心情境:
# 1. P1: operationType=C → 400 REJECTED_VALIDATION
# 2. A1: 正常 SUCCESS → 200,core+cc track_id 都有
# 3. B1: 正常 CANCELLED → 200,Core+CC 反向都成功
# 4. B2: 不存在的 originalSequenceNumber → 500 LOOKUP_FAILED
# 5. P4: Parent 級冪等 (同 seq 重送) → 第二次 IDEMPOTENT_REPLAY

# 查 DB 確認 audit log 落地
sqlite3 data/reconciliation.db \
  "SELECT workflow_id, COUNT(*) FROM workflow_execution_log
   WHERE workflow_id LIKE '%_cash%' OR workflow_id LIKE '%repayment_%' GROUP BY workflow_id;"
```

---

## Step 11: ⭐ 產出整併執行軌跡紀錄與問題報告 (integration-execution-trace-and-issue-report.md)（★ 必產）

> `docs/spec.md` 是技術規格，`docs/design-explanation.md` 是業務設計理由，`docs/execution-trace-and-issue-report.md` 是設計期草稿紀錄。
> **`integration-execution-trace-and-issue-report.md` 則是整併驗收的最高規格交接物**，記錄整併過程的真實命令歷程、Baseline 偵察、Kogito codegen 迭代修正、Mock 404 排查、Workflow 拓撲修訂、測試資料調整、Maven 驗收與 Checklist。

### 11a. 落位與雙向鏡像保全
- **主落位**：`project/features/<feature-name>/docs/integration-execution-trace-and-issue-report.md`
- **鏡像同步**：產出後必須同步複製回 `drafts/<feature-name>/docs/integration-execution-trace-and-issue-report.md`，使交付套件 (draft) 與運行特徵 (feature) 兩端皆具備完整的整併歷史紀錄。
- **寫作範本**：`.agents/skills/sonataflow-integration/references/integration-execution-trace-and-issue-report-template.md`。

### 11b. 強制 12 節結構（不可刪節，可加附錄）
| 節 | 標題 | 核心內容要求 |
|---|---|---|
| 1 | 執行摘要 | 依階段表格彙整結果（Step 0 ~ 10）、特徵自治與零侵入說明、最終結論 |
| 2 | 整合前 Baseline 偵察 | 平台動態裝配機制確認、既有 Java 服務簽名比對表、Flyway 雙軌探測結果 |
| 3 | 預檢執行紀錄 | 上游 46 項預檢、整合期 6 項補強檢查之真實指令與排除過程 |
| 4 | Kogito Codegen 迭代問題與修正 | 詳述每輪 Codegen 報錯（如 FQCN 錯、簽名不符）、根因與 Caller Adapts to Callee 修正 |
| 5 | HTTP 404 / 執行期端點與裝配根因分析 | 記錄 Mock 404 排查、`-am` (also-make) 依賴機制與 Antrun 動態同步細節 |
| 6 | Workflow 行為修正 | 記錄從測試失敗反推的狀態機拓撲修訂（如 Switch 拆分解耦、numeric 0 狀態相容、安全守衛） |
| 7 | 整合測試修正 | 記錄測試程式之修補（序號 System.nanoTime() 動態化防冪等污染、前置交易 Fixture 等） |
| 8 | 最終驗證結果 | 記錄 Feature 預檢最終結果、Maven 全 reactor 測試報表（90/90 等實際數字）、5 大核心場景結果表 |
| 9 | 變更清單 | 列出 feature-local 變更檔案清單、draft 鏡像同步情況、平台核心模組零修改保證 |
| 10 | 反模式與踩坑彙整 | 給下次整合者的實戰踩坑表（如 interfaceName 捲入、參數不匹配、Switch 條件競態） |
| 11 | 已知限制與後續建議 | 列出哨兵值補強、下一版 Flyway 版本號預留、CI/CD 落地建議 |
| 12 | 驗收 Checklist | 9 大項檢驗打勾清單（Maven 全綠、預檢全綠、Codegen 通過、5 場景通過、Audit 落庫、View 建立、零侵入、雙向同步、抽離驗證） |

### 11c. 填寫鐵律
1. **嚴禁虛報全綠**：測試數據（如 `Tests run: XX, Failures: 0`）必須直接來自真實執行的 Maven 輸出，嚴禁憑空捏造。
2. **命令軌跡真實記錄**：所有檢查與驗證必須包含真實執行的指令與返回摘要。
3. **問題六要素齊全**：每個遭遇的問題必須具備「位置、現象、影響、根因、建議、驗證方式」。
4. **章節數量強制要求**：二級章節 `## 1` 至 `## 12` 必須 12 節全數具備，不得任意刪減。

---

## 整合完成的驗收 checklist

- [ ] `mvn -B package -DskipTests` 全 22 modules BUILD SUCCESS
- [ ] `mvn -B test -pl distribution/transfer-app -am` 全綠 (含新特徵測試案例)
- [ ] `transfer-app/target/quarkus-app/quarkus-run.jar` 存在 (~122MB)
- [ ] 啟動後 `/q/health` 回 200
- [ ] 至少 5 個 E2E 情境通過
- [ ] audit log 落地 (workflow_execution_log 有新 workflow_id 的 row)
- [ ] DB view 存在且為最新定義 (`vw_<workflow-name>_reconciliation`，Flyway 腳本內含 `DROP VIEW IF EXISTS` 前置宣告)
- [ ] `docs/integration-execution-trace-and-issue-report.md` 已產出（詳細整併執行軌跡與問題報告，包含 12 節結構、真實 Maven 測試數據與變更清單，必產）
- [ ] `docs/integration-execution-trace-and-issue-report.md` 已鏡像同步至 `drafts/<feature-name>/docs/`
- [ ] 無 NEW critical build error(可有 Quarkus warning)

---

## 失敗模式速查

| 失敗訊息關鍵字 | 對應修正 |
|---|---|
| `KieMemoryCompilerException: ';' expected, <identifier> expected` | Kogito subflow hyphen bug → 改名 underscore |
| `Illegal character in path at index N: ...{xxx}` | path parameter 沒傳 → 6a |
| `expected <block end>, but found ','` | YAML trailing comma → 6a 注意 |
| `finalStatus: REJECTED_VALIDATION` 但 HTTP 200 | status-rewrite filter 沒認 finalStatus → 6c |
| `vw_xxx_reconciliation` 查詢回 0 筆 | view 的 WHERE 用舊 id → 6d |
| `result.status == 0` 永遠 false | actionDataFilter 結構錯誤 → 6b |
| `rowsUpdated=0` 在 markOriginalCancelled | transaction 隔離 / cancelled_by 已值 / 連線池問題,留 v1.1 排查 |
| `Expected status code <200> but was <400>` | 全域正則拒絕正常通路碼 (如 `2500P`) → 檢查 API 規格放寬正則 (如 `^[A-Za-z0-9]{1,10}$`) |
| `finalStatus: null` 在業務失敗分支 | jq condition `tonumber` 遇到非數字哨兵 (如 `FAIL_`) 拋錯 → 加上 startswith("FAIL_") 守衛 |
| `Expected: SUCCESS Actual: IDEMPOTENT_REPLAY` | 測試案例重複使用硬編碼 sequenceNumber 觸發冪等 → 測試改用 System.nanoTime() 動態序號 |
| `NullPointerException: ... getStart() is null` | `.sw.yaml` 根節點缺少 `start:` 宣告 → 於 workflow 頂層顯式定義 `start: <StateName>` |
| `ClassCastException: ... cannot be cast to JsonNode` | Java 重載方法參數綁定失配 → 於 functionRef arguments 明確傳遞 `workflowId` 與 `businessKey` |
| `ProcessCodegenException: could not find a method called "..." with proper arguments` | Kogito 工作項反射找不到對應具名參數的方法簽名 → Java 服務補上展開參數重載 (如 `(String, Object)`) |
| `JSON path result.xxx doesn't match / actual: null` | Operation state 缺少 `toStateData` 導致輸入 payload 被覆寫 → 在 `actionDataFilter` 補上 `toStateData: '${ .targetKey }'` (見 6e) |
| `AssertionFailedError: View 應包含一筆 REPAYMENT 成功紀錄` | SQLite 對帳 View 查詢撈到前置測試遺留舊資料 → SQL 補上 `status='SUCCESS' ORDER BY id DESC LIMIT 1` (見 6f) |
| `長度超限, 最多允許 X 字元` | OpenAPI Spec 的 maxLength 與 example/測試序號長度衝突 → 修改 OpenAPI spec 放寬限制 |
| `cannot find symbol: class <NewService>` | 子模組依賴更新但尚未安裝至本機庫 → 先執行 `mvn install -pl <module> -DskipTests` |
| `API 呼叫錯誤: 無法確定 API Base URL` | OpenAPI Spec 缺少 `servers:` 宣告且無全域 host → 於 Spec 補上 `servers: - url: http://localhost:8080` |
| `Expected status code <400> but was <404>` | `specs/internal` 被 `transfer-app` 的 clean plugin 刪除，或未放置於 `domain-transfer/transfer-workflow/src/main/resources/specs/internal/` → 補上 POM exclude 並於 SSOT 落檔 |
| `found JSON schema file in handoff`（`spec/schemas/*.json` 殘留） | 最終整併不可出 JSON → 丟棄 JSON 並將 notebook 內 `$ref: '../spec/schemas/*.json'` 改為 `#/components/schemas/...` 內聯 |
| `x-workflow-id in specs/external` 或 internal 缺標籤 | internal 必含、external 必無 → 按 vibe 6.9 修正後重落 |
| `new yaml landed in specs/ root` | root 禁放（`openapi.yaml` 除外）→ 搬入 `specs/external/`，`schemaRef` 改 `specs/external/...` |
| `internal/external 同名檔漂移`（除標籤外內容不一致，如 root omni 式放寬） | 以 internal 放寬版為準同步，刪除 root 舊檔 |
| `JSON path result.xxx doesn't match / actual: null (在動態路由測試時)` | 動態路由測試應斷言工作流程頂層欄位（如 `finalStatus`、`coreResult.status`），避免依賴不存在的 `result.xxx` |
| `sqlite3.OperationalError: no such column: updated_at` | 對帳 View 參照不存在欄位 → 修正 View 定義，移除 `updated_at`，僅保留 `created_at` |
| `no such table: vw_<name>_reconciliation` (即使有建 V 檔) | Flyway 版本號與實體 DB 衝突被靜默跳過 → 執行 Step 4d 雙軌探測，遞增版本號為安全基線+1 |
| `NoSuchMethodException: ... saveLog(...)` | Workflow 傳遞具名參數但 Java 服務缺少精確展開簽名 → 依 Step 4b 補上具名參數重載 |
| `404 Not Found (呼叫 Mock API 時)` | ① 測試時未帶 `-am` 參數，導致 `dev/transfer-mock` 的 initialize Antrun 未被觸發（動態 Mock Java 檔案未同步）→ 改為 `mvn -B test -pl distribution/transfer-app -am`；<br>② OpenAPI 宣告端點缺少對應 JAX-RS Resource (如漏寫 Refund) → 執行 Gate 2 並於 Mock 補全端點 |
| `Cannot index null with string "..."` | switch condition 讀取嵌套欄位未加安全守衛 → 依 Step 6g 加入 `((.status // "999") | tostring)` |
| `finalStatus: REJECTED_VALIDATION 但 HTTP 200 (已加 mapping)` | application.properties 使用了 dot-notation 被忽略 → 依 Step 7 改為單行 CSV 逗號追加格式 |
| `Audit Log 遺漏 (主機異常中斷時無記錄)` | operation 節點未宣告 onErrors 導致例外脫逸 → 依 Step 6g 補齊 onErrors 導流至 Audit 節點 |
| `maven.aliyun.com 503 Service Unavailable` | 重試 / 切換 mirror / 縮短單次 build |
| Java/Maven 突然 not found | sandbox 自動清掉,重裝 `apt-get install openjdk-17-jdk-headless maven` |
| `Cannot find any error definition for errorRef platformError` | 子 workflow `errors:` 區塊漏宣告 `platformError` → 補上；**預防：Step 1.5A.1 檢查 1️⃣** |
| `Node 'X' has no incoming connection / Has no connection to the start node` | Workflow 存在 unreachable 狀態（dead code） → 移除；**預防：Step 1.5A.1 檢查 2️⃣** |
| `could not find a method called "raise" with proper arguments [String, Object, Object, Map, Map]` | `notifyOps` arguments 使用了 `inputData`/`outputData` 命名（AuditLogService 慣例），應改為 `finalStatus`/`finalMessage`/`detail` 對齊 OpsAlertService 6 參簽名 → 依 Step 4b 修正；**預防：Step 1.5A.1 檢查 3️⃣** |
| `java.lang.NoClassDefFoundError: <DtoName>`（執行期） | Mock DTO 套件 `org.acme.transfer.api.dto` 與 transfer-mock antrun 同步目錄 `features/dto/` 不一致 → 改為 `org.acme.transfer.api.features.dto`；**預防：Step 1.5A.1 檢查 4️⃣** |
| `SQLITE_ERROR: no such column: sequence_number / updated_at / final_status / workflow_data` | View SQL 引用不存在的實體欄位 → 改用 `json_extract(input_data, '$.xxx')`；**預防：Step 1.5A.1 檢查 5️⃣** |
| `onErrors 覆蓋不足` / `*_FAILED 終態未調 notifyOps` | Workflow 每個 operation 必須顯式宣告 onErrors（含 platformError）；`*_FAILED` 終態必調 notifyOps → 依 Step 6g 修正；**預防：Step 1.5A.1 檢查 6️⃣** |

> ⭐ **預防勝於治療**：以上 6 個失敗模式皆可透過 **Step 1.5A.1 整合期補強檢查** 在落檔前自動偵測，VS Code Problems 面板紅線聯動；強烈建議在 `cp -r draft-X project/features/X` 之前先執行一鍵預檢。

---

## 反模式 (不要這樣做)

- ❌ 不要把整個 draft 資料夾丟進 project,挑選對應的檔案落對應目錄
- ❌ 不要跳過 Kogito bug 修正,直接編譯會 fail
- ❌ 不要改既有 saga2-transfer-workflow 的 convention(向後相容用 fallback)
- ❌ 不要用 `mvn install:install-file` 手動裝 jar,會破壞 reactor 一致性
- ❌ 不要在 test 階段才建 workflow URL prefix(應該是 dev profile 啟動時 Kogito 自動註冊)
- ❌ 不要省略 `creditcardid` 補上動作(6a),否則 mock 收到 `IllegalArgumentException`
- ❌ 不要在沒有 dev profile 下做 E2E(mocks 是 dev-only 模組,prod 會被排除)
- ❌ **不要執行缺少 `-am` 的 `mvn test -pl distribution/transfer-app`** — 該指令僅建置 transfer-app 子樹，不會觸發依賴模組 `dev/transfer-mock` 的 initialize Antrun，導致動態 Mock 端點未註冊而全數回傳 HTTP 404！特徵單元測試務必加上 `-am`。
- ❌ **不要跳過 Step 1.5A 整合期 Agent Runner 預檢** — 6 項補強檢查涵蓋本次整併發現的所有致命坑（platformError 漏宣告、unreachable state、notifyOps 參數錯置、DTO 套件錯位、View SQL 欄位錯、onErrors 覆蓋），未跑必落入整合期 trap
- ❌ **不要用 sed 二代取代（Step 5b）** — 必觸發 `.dto.dto` 雙重替換陷阱；應先用 Agent Runner 偵測 + Python 顯式批次替換
- ❌ **不要省略 integration-execution-trace-and-issue-report.md 或虛報測試數據** — 整併是驗證架構設計最關鍵的一環，必須誠實記錄真實 Maven 命令歷程、Codegen 踩坑修正、Mock 裝配排查與 12 節結構，否則後續維護與抽離時將無跡可循（見 Step 11）

---

## v3.0: 零侵入獨立特徵目錄模式 (Feature Overlay Autonomous Pattern)

> 為了解決傳統整併將檔案分散到 5 大模組、且未來難以完全抽離的架構痛點，自 v3.0 起支援「獨立特徵目錄 (Feature Overlay)」架構。
> **優勢**：特徵所有資源（工作流、OpenAPI 規格、Mock 服務、DB 視圖、測試）均集中在單一目錄下。未來若要抽離特徵，**只需直接刪除該特徵目錄 (`rm -rf`)**，專案核心代碼與全域設定零殘留、零修改，編譯與測試 100% 維持綠燈。

### 1. 特徵目錄結構規範 (`project/features/<feature-name>/`)

```
project/features/<feature-name>/
├── feature.yaml                    # 特徵元資料 (名稱、版本、維護團隊、工作流清單)
├── docs/                           # 規格書、設計說明與執行報告
│   ├── README.md                   # 特徵交接指引
│   ├── spec.md                     # 技術規格書
│   ├── design-explanation.md       # 設計理由書
│   ├── execution-trace-and-issue-report.md            # 設計期執行軌跡與問題報告 (draft 移入)
│   └── integration-execution-trace-and-issue-report.md # ★ 整併期執行軌跡與問題報告 (Step 11 必產)
├── workflows/                      # SonataFlow 工作流程定義
│   ├── <parent_workflow>.sw.yaml
│   └── <child_workflow>.sw.yaml
├── specs/                          # OpenAPI 規格定義
│   ├── internal/                   # 內部 API (含 x-workflow-id，動態路由器入口)
│   │   └── <workflow>-api.yaml
│   └── external/                   # 外部 API (被調用之主機規格)
│       └── <upstream-service>-api.yaml
├── mocks/                          # JAX-RS Mock 模擬服務與 DTO (僅 dev 裝配)
│   ├── <Service>Resource.java
│   └── dto/
│       └── <Response>.java
├── db/                             # 資料庫遷移與回滾腳本
│   ├── migration/
│   │   └── V<X>.<Y>.<Z>__<desc>.sql
│   └── teardown.sql                # 抽離時的回滾腳本 (例如 DROP VIEW)
├── config/
│   └── application.properties.snippet # 特徵特定配置說明 (非必填)
└── tests/                          # 特徵整合/單元測試
    └── <Feature>WorkflowTest.java  # package 必須為 com.example.platform.distribution.transfer.features;
```

### 2. 平台動態裝配機制 (Dynamic Assembly)

1. **Maven Antrun 自動探測裝配**：
   - `transfer-mock/pom.xml`：於 `initialize` 階段自動探測 `features/*/mocks`，同步至 `src/main/java/org/acme/transfer/api/features/`（已加入 `.gitignore`）。
   - `transfer-app/pom.xml`：於 `initialize` 階段自動探測 `features/*/workflows`、`features/*/specs`、`features/*/db/migration` 與 `features/*/tests`（已加入 `.gitignore`）。
2. **零配置動態全域支援**：
   - 狀態重寫過濾器已支援萬用字元 `platform.status-rewrite.workflows=*`，新增工作流時**無需修改 `application.properties`**。
   - `OpenApiSchemaValidator` 自動掃描所有裝配至 `specs/internal` 的規格，動態註冊驗證器。
3. **自動清理與無痛抽離 (Zero-Debt Uninstallation)**：
   - `transfer-app` 與 `transfer-mock` 的 `clean-resources-dir` 在每次建置的 `initialize` 階段自動清空暫存同步目錄。
   - **抽離特徵**：
     ```bash
     # 1. 執行 DB 清理 (若有)
     sqlite3 data/reconciliation.db < project/features/<feature-name>/db/teardown.sql
     # 2. 刪除特徵目錄
     rm -rf project/features/<feature-name>
     # 3. 驗證建置 (零代碼修改，立即編譯測試成功)
     mvn test
     ```
