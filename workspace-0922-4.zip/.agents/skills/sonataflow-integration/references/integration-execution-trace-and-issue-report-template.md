# Reference 01: integration-execution-trace-and-issue-report.md 寫作模板（整併執行軌跡紀錄與問題報告，必產）

> 對應 `SKILL.md` Step 11 + 整合完成驗收 Checklist。
> 定位：`docs/spec.md` 是技術規格，`docs/design-explanation.md` 是設計理由，`docs/execution-trace-and-issue-report.md` 是設計期草稿紀錄。
> 本檔是給**審查者、平台架構師、維運團隊與後續維護者**看的**整併期詳細執行軌跡紀錄與問題報告**。
> 落位：`project/features/<feature-name>/docs/integration-execution-trace-and-issue-report.md`（與 `docs/spec.md` 同層，並鏡像同步至 `drafts/<feature-name>/docs/`）。

---

## 強制 12 節結構（不可刪節，可加附錄）

```markdown
# <特徵業務名稱> 整併執行軌跡與問題報告

- 報告日期：<YYYY-MM-DD>
- Draft 來源：`drafts/<feature-name>/`
- 整合目標 Feature：`project/features/<feature-name>/`
- 平台：SonataFlow / Kogito 10.2.0 / Quarkus 3.x / Java 17 或 21
- 設計模式：<Mode A/B/C/D/E，架構簡述>
- 整併規範：`sonataflow-integration` skill v3.0（Feature Overlay 自治）
- 性質：**整合期**執行軌跡與問題報告（與 `drafts/<feature-name>/docs/execution-trace-and-issue-report.md` 設計期紀錄對偶）
- 最終結論：<客觀結論，例如：90 tests, 0 failures, 0 errors, BUILD SUCCESS（transfer-app 全 reactor）>

---

## 1. 執行摘要

簡述本次依 `sonataflow-integration` v3.0 規範把 draft 整併至 `project/features/<feature-name>/` 的概況，強調特徵目錄自治與平台核心模組零修改。

| 階段 | 結果 |
|---|---|
| Step 0 環境檢查 | Java、Maven、Agent Runner 8091 狀態（`curl http://127.0.0.1:8091/api/health` 回應 online） |
| Step 1 draft 結構分析 | 檔案結構與自治目錄規範核對 |
| Step 1.5A.0 上游預檢（preflight-checks.js） | 執行結果與修復歷程 |
| Step 1.5A.1 整合期補強預檢（integration-preflight.js） | 執行結果與補強項目 |
| Step 2 掛載 | `cp -r drafts/<name> project/features/<name>`，零主模組侵入 |
| Step 3-7 workflow / Java / 組態調整 | 契約對齊、FQCN 修正、方法簽名調整摘要 |
| Step 5d mock 覆蓋 | 被調主機端點覆蓋與正反向實作確認 |
| Step 8 測試整合 | 動態裝配路徑與隔離測試確認 |
| Step 9 Maven 驗證 | 編譯、Kogito codegen 迭代修正與 reactor 測試結果 |
| Step 10 E2E smoke test | 端對端場景驗收與 audit log 落庫確認 |

---

## 2. 整合前 Baseline 偵察

### 2.1 平台動態裝配確認
說明 Maven Antrun 自動探測與同步機制（如 `features/*/workflows`、`features/*/specs`、`features/*/mocks`、`features/*/tests` 等），確認抽離機制（`clean-plugin`、`teardown.sql`）就緒。

### 2.2 既有 Java 服務簽名比對
依 Step 1.5 Gate 3 比對 draft 宣告的 FQCN 與專案既有實作：
| draft 宣告 | 既有實作 | 一致？ |
|---|---|---|
| `<fqcn>::<method>` | `<fqcn>`，簽名 `(...)` | ✅ 一致 / ❌ Package 錯 / ⚠️ 參數不符 |

### 2.3 Flyway 雙軌探測
記錄檔案系統與實體 DB（如 `data/reconciliation.db`）的版本探測結果，並確認 View DDL 具備前置 DROP：
| 來源 / 檢驗項 | 最高版本 / 結果 |
|---|---|
| 檔案系統 `*/db/migration/` | `V...` |
| 實體 DB `reconciliation_schema_history` | `V...` |
| **安全基線（下一版）** | **V...** |
| draft 採用版本 | `V...`（確認未被靜默跳過） |
| View DDL 前置 DROP 檢查 | ✅ 通過（CREATE VIEW 之前已宣告 DROP VIEW IF EXISTS） |

---

## 3. 預檢執行紀錄

### 3.1 上游 46 項設計期預檢（preflight-checks.js）
記錄 `POST http://127.0.0.1:8091/api/run-file` 的真實執行指令、參數、首次失敗項與修補後重跑結果。

### 3.2 整合期 6 項補強檢查（integration-preflight.js）
記錄 6 大整合門禁（errors 宣告、unreachable 狀態、notifyOps 6 參、Mock DTO 套件、View SQL 欄位、onErrors 覆蓋）之執行與排除過程。

---

## 4. Kogito Codegen 迭代問題與修正

依輪次詳實記錄 `mvn -B test -pl distribution/transfer-app -am` 在 `generateSources` 階段碰到的 Codegen 異常與修復歷程：

### 第 1 輪：<問題簡述，如 FQCN 類別找不到>
- 報錯訊息：`ProcessCodegenException: ...`
- 根因：<說明原因>
- 修正：<列出具體 YAML 或代碼修改>

### 第 2 輪：<問題簡述，如方法簽名不匹配>
- 報錯訊息：`NoSuchMethodException: ... with proper arguments [...]`
- 根因：<說明原因>
- 修正：<遵循「Caller Adapts to Callee」原則調整 workflow arguments>

*(依實際修復輪次增加)*

---

## 5. HTTP 404 / 執行期端點與裝配根因分析

記錄執行期呼叫 Mock API 時發生的連線或 404 異常排查過程：
- 現象：`Property 'workflowdata.coreResult' ... HTTP 狀態碼: 404`
- 根因：Maven 指令範圍未涵蓋依賴模組（如未加 `-am` 導致 `dev/transfer-mock` 的 `initialize` Antrun 未觸發）或 JAX-RS Resource 遺漏端點。
- 解法與指令：`mvn -B test -pl distribution/transfer-app -am`。

---

## 6. Workflow 行為修正（從測試失敗反推）

記錄測試失敗反推 workflow 拓撲與狀態機邏輯的修訂歷程：

### 6.1 <測試案例名稱> 失敗（現象與預期差異）
- 日誌關鍵：<日誌片段>
- 根因：<如 jBPM Split 節點條件競態、跨 workflow 查詢 lookup 使用錯誤 id、狀態值為數字 0 非字串 SUCCESS 等>
- 修正：<列出狀態機拆分、安全守衛加強等修改片段>

---

## 7. 整合測試修正

記錄為適應真實整合環境對測試程式碼所作的修正：
- 序號動態化：避免硬編碼序號觸發 Parent 冪等快取（改用 `System.nanoTime()`）。
- 測試前置資料 (Fixture)：正向沖銷流程需先發送並確認原交易成功。
- 測試隔離與斷言：針對 SQLite View 查詢加入排序與狀態約束。

---

## 8. 最終驗證結果

### 8.1 Feature 預檢最終結果
記錄 Preflight 最終 PASS 狀態與版本號建議。

### 8.2 Maven 全 Reactor / 特徵測試數據
記錄建置指令與測試報表：
```bash
mvn -B test -pl distribution/transfer-app -am
```
```
Tests run: XX, Failures: 0, Errors: 0, Skipped: 0
BUILD SUCCESS
```
| 測試類別 | Tests | Failures | Errors |
|---|---:|---:|---:|
| <既有測試類別 1> | XX | 0 | 0 |
| <本特徵測試類別> | XX | 0 | 0 |
| **合計** | **XX** | **0** | **0** |

### 8.3 核心驗收情境結果表
| 情境代號 | 業務情境說明 | 預期 finalStatus | 實際 finalStatus | HTTP 狀態碼 | 結果 |
|---|---|---|---|---|---|
| P1 | 欄位檢核失敗 | REJECTED_VALIDATION | REJECTED_VALIDATION | 400 | ✅ |
| A1 | 正向業務成功 | SUCCESS | SUCCESS | 200 | ✅ |
| P4 | 冪等重放 | IDEMPOTENT_REPLAY | IDEMPOTENT_REPLAY | 200 | ✅ |
| B1 | 原交易沖正/取消 | CANCELLED | CANCELLED | 200 | ✅ |
| B2 | 查無原交易 | LOOKUP_FAILED | LOOKUP_FAILED | 500 | ✅ |

---

## 9. 變更清單（特徵自治與零侵入確認）

### 9.1 特徵目錄內部變更 (`project/features/<feature-name>/`)
列出所有新增或修改的特徵檔案與改動說明。

### 9.2 Draft 鏡像同步 (`drafts/<feature-name>/`)
說明特徵目錄內修復之檔案已完整回灌至 `drafts/`，確保交付件一致。

### 9.3 平台核心零修改保證
明列專案主模組（如 `transfer-app`、`transfer-mock`、`transfer-workflow` 等核心代碼與 pom.xml）零修改，特徵支援隨插即拔。

---

## 10. 反模式與踩坑彙整（給下次整合者）

條列本次整合過程中排查出的架構陷阱與防範經驗：
| 現象 | 真正根因 | 預防與規範 |
|---|---|---|
| `class not found for interfaceName` | Package 命名空間不一致 | 整合前嚴格執行 Gate 3 比對既有 FQCN |
| `NoSuchMethodException` 參數不匹配 | 草稿私自擴充具名參數 | 遵循「Caller Adapts to Callee」，不濫加 Java 多載 |
| Mock 端點回傳 404 | 單模組測試未觸發 mock initialize | 執行指令一律帶 `-am`（also-make） |
| Switch 條件搶佔分流 | jBPM Split 節點條件求值無序 | 拆解為前後兩個獨立 Switch 狀態 |

---

## 11. 已知限制與後續建議

列出後續維運或升級建議（如：哨兵值覆蓋、CI/CD 整合、下一版 Flyway 版本號預留等）。

---

## 12. 驗收 Checklist

- [x] `mvn -B test -pl distribution/transfer-app -am` 全綠（BUILD SUCCESS）
- [x] Feature 預檢無紅線全數 PASS
- [x] 所有 Workflow 皆通過 Kogito Codegen
- [x] 核心驗收情境全部符合預期 finalStatus 與 HTTP code
- [x] Audit log 成功落庫寫入 `workflow_execution_log`
- [x] 資料庫 View 成功建立且可正常查詢
- [x] 平台核心模組零修改、零污染
- [x] Feature 與 Draft 雙向同步一致
- [x] 抽離測試驗證（執行 teardown.sql 後刪除特徵，系統仍維持綠燈）
```

---

## 填寫鐵律與品質原則

1. **數據實事求是，禁止虛構全綠**：
   - 所有的 Maven 測試數據（如 `Tests run: 90, Failures: 0`）必須來自實際執行的 console output，嚴禁未跑先填。
2. **命令軌跡完整且可復現**：
   - §3 與 §8 必須記載實際在 shell 執行的命令與回應，供審查者復現。
3. **問題修復具備完整脈絡**：
   - §4、§5、§6 的每個問題必須清晰交代「現象、報錯關鍵字、根本原因、修復手段」，展現工程深度。
4. **章節數量強制要求**：
   - 二級章節 `## 1` 至 `## 12` 必須 12 節全數具備，不得任意刪除或合併。
5. **雙向鏡像保全**：
   - 報告產出後，必須同時存在於 `project/features/<feature-name>/docs/integration-execution-trace-and-issue-report.md` 與 `drafts/<feature-name>/docs/integration-execution-trace-and-issue-report.md`。

