---
name: vibe-workflow-design-v3
description: 從業務需求與 host API 規格出發，設計符合「零侵入獨立特徵外掛 (Feature Overlay Autonomous Plugin)」架構的 workflow 套件。涵蓋 10 項設計期自我檢查守則、透過 SonataFlow Agent Dynamic Script Runner 全自動預檢與 VS Code 問題面板紅線聯動，整合前置產出物 (feature.yaml / OpenAPI specs / workflows / DDL+teardown / Mock Java / 隔離 Test / 規格書 / 創建者導向 design-explanation)。**v3.1 起本 skill 強制把所有產出置於工作區根目錄的 `drafts/<feature-name>/`，下游整併由 `sonataflow-integration` skill 接手。**
description: 從業務需求與 host API 規格出發，設計符合「零侵入獨立特徵外掛 (Feature Overlay Autonomous Plugin)」架構的 workflow 套件。涵蓋 10 項設計期自我檢查守則、透過 SonataFlow Agent Dynamic Script Runner 全自動預檢與 VS Code 問題面板紅線聯動，整合前置產出物 (feature.yaml / OpenAPI specs / workflows / DDL+teardown / Mock Java / 隔離 Test / 規格書 / 創建者導向 design-explanation / 詳細執行軌跡紀錄與問題報告 execution-trace-and-issue-report)。**v3.1 起本 skill 強制把所有產出置於工作區根目錄的 `drafts/<feature-name>/`，下游整併由 `sonataflow-integration` skill 接手。**
---

# Vibe Workflow Design v3

> v3.1 重點：全面整合 **SonataFlow Agent Dynamic Script Runner**（單一通訊埠 8091 / `/api/run`）與 **零侵入特徵外掛架構 (Feature Overlay Autonomous Plugin)**，並**強制把所有設計期產出置於工作區根目錄的 `drafts/<feature-name>/`**（不可再寫入 `project/features/`，那是 `sonataflow-integration` skill 整併後的落地點）。相容性預檢、Flyway 探測與規範自查全面改寫為跨平台 Node.js API 執行；每個 draft 必須具備獨立生命週期元資料 (`feature.yaml`)、回滾清理 (`teardown.sql`) 與隔離測試 (`com.example.platform.distribution.transfer.features`)。

## 📦 套件內容

```
vibe-workflow-design-v3/
├── SKILL.md                          # 本檔 (SOP 主文件，全預檢改用 Agent Runner)
├── scripts/
│   └── preflight-checks.js           # ★ v3.0 新增：一鍵全自動 10 項平台檢查 + Flyway 探測腳本
│   └── preflight-checks.js           # ★ 一鍵全自動 16 項平台檢查 + Flyway 探測 + 交付目錄規範腳本
├── examples/                         # 範例（01 完整真實案例；02/03 最小可跑骨架）
│   ├── 01-financial-repayment/       # 金融信用卡繳款 (Mode B,真實案例，完整)
│   ├── 02-ecommerce-order/           # 電商訂單履行 (Mode A，最小可跑骨架)
│   └── 03-insurance-claim/           # 保險理賠 (Mode B 跨領域，最小可跑骨架)
└── references/                       # 可重用資源
    ├── 01-platform-checks/           # 10 項平台相容性預檢 01-10 (各含 Agent Runner API 調用)
    ├── 02-self-check/                # 29 項 self-check 清單 (7.1-7.29，含一鍵 preflight 調用)
    ├── 02-self-check/                # 35 項 self-check 清單 (7.1-7.35，含一鍵 preflight 調用)
    ├── 03-templates/                 # 5 種 workflow YAML 範本（A/B/C 生產可用；D/E 實驗性）
    ├── 04-config-snippets/           # application.properties.snippet 完整模板（含 %dev/%prod 與 baseUrl fallback 註解）
    ├── 05-fqcn-template/             # docs/spec.md §0 H1-H18 假設清單完整模板
    └── 06-design-explanation-template/ # docs/design-explanation.md 寫作模板（創建者導向，必產）
    ├── 06-design-explanation-template/ # docs/design-explanation.md 寫作模板（創建者導向，必產）
    └── 07-execution-trace-template/  # docs/execution-trace-and-issue-report.md 寫作模板（執行軌跡紀錄與問題報告，必產）
```

**第一次使用**: 先讀 `examples/01-financial-repayment/` (最完整,真實案例)
**對應業務找範本**: 看 `examples/` 找最接近的模式
**遇到特定問題**: 翻 `references/01-platform-checks/` 找對應的預檢 + 自動檢查腳本

---

## 觸發條件

當使用者訊息包含以下任一:
- 「設計 / 起草 / 規劃 workflow」
- 「從業務需求做一份 draft」
- 「新業務要做 workflow 雛型」
- 「產生可直接整併的 workflow spec」
- 看到業務需求書 (BR-xxx) + host API 規格 + sample payloads

**不要**用於:
- ❌ 已存在的 draft 整併 (用 `sonataflow-integration` skill)
- ❌ 純文件撰寫 (用一般寫作工具)
- ❌ 既有 workflow 修改 (用 `vibe-workflow-design` v1 + 手動)

---

## Step 0: 前置探測與自治架構對齊 (慣例優先，非阻塞)

> 🌟 **「模組單一目錄自治與熱插拔抽離架構 (Feature Overlay Autonomous Plugin)」執行準則**：
> 在此架構下，**目標平台、產出落點、目錄規範、Mock 套件與 Flyway 探測已全數固化為標準慣例**。
> Agent 應遵循**「慣例優先 (Convention over Configuration)」**原則：
> 1. **自動對齊與套用預設**：直接掃描環境並套用下方 5 項自治慣例，於輸出開頭列出「📋 自治架構對齊矩陣」。
> 2. **零摩擦無縫推進**：**嚴禁因架構常數阻礙流程或向使用者反覆確認已固化項目；列出對齊矩陣後直接推進 Step 1！**
> 3. **嚴禁破壞自治原則的提問**：**嚴禁詢問「是否整合至既有 transfer-workflow 模組」或「是否使用既有 transfer-mock」**！所有產出 100% 集中於 `drafts/<feature-name>/`，下游一律由 `sonataflow-integration` 掛載至 `project/features/<feature-name>/`。

### 0.1 Agent Runner 環境健康檢查 (強烈推薦)

在執行後續版本探測與平台預檢前，建議先確認 SonataFlow Agent Dynamic Script Runner 已啟動：
```bash
curl -s http://127.0.0.1:8091/api/health
```
- **預期響應**：HTTP 200，回傳包含 `"status": "online"`、`"workspaceRoot"` 等欄位的 JSON。
- **若連線失敗**：確認 VS Code 是否已啟動擴充套件，或依環境啟動 Agent Runner；若暫無法使用，後續探測降級為手動或本機腳本備援。

### 自治架構預設矩陣 (Auto-Detected Defaults)

| # | 項目 | 自治架構標準慣例 (預設值 / 自動探測) | 處理規則 |
|---|---|---|---|
| **0a** | **目標平台** | **SonataFlow / Kogito 10.2.0 (Quarkus 3.x)** | **預設鎖定，免問**。僅在使用者明確指定其他引擎 (如 Camunda/Airflow) 時切換。 |
| **0b** | **模組架構與落點** | **`drafts/<feature-name>/` (單一目錄自治)** | **預設鎖定，免問**。⛔ 嚴禁提問或落點至 `domain-transfer/transfer-workflow`。下游統一由 `sonataflow-integration` 掛載至 `project/features/<feature-name>`。 |
| **0c** | **Host API 與規格來源** | **依需求材料自動分類 (Internal 入口 vs External 被調)** | **自動推導，免問格式**。直接將 Parent 對外 API 落為 `src/specs/internal/`，被調 host API 落為 `src/specs/external/`。 |
| **0d** | **DB 與 Flyway 版本** | **SQLite + Flyway，自動探測最高版本並接續 (如 V1.1.0 → V1.1.1)** | **自動遞增，免問**。特徵 DDL 放置於 `db/migration/V<next>__<feature-name>.sql`，若包含 View 必須於 `CREATE VIEW` 之前加上 `DROP VIEW IF EXISTS <view>;`，並必備 `db/teardown.sql`。 |
| **0e** | **Mock 與 DTO 套件** | **Mock 內部自治，DTO 套件固定為 `org.acme.transfer.api.features.dto`** | **預設鎖定，免問**。符合 6.15/7.33 隔離防護規範；測試套件固定為 `com.example.platform.distribution.transfer.features;`。⛔ 嚴禁詢問是否使用既有 `transfer-mock`。 |

### 何時才允許提問？ (業務層面唯一阻礙例外)

**僅在遇到以下純業務層面缺失且無法由需求書推斷時，才允許向使用者提問**：
1. 需求書完全未定義特徵業務名稱，且上下文無法推斷 `<feature-name>`（影響目錄命名）。
2. 業務流程有重大架構分歧（例如 Parent-Child 拆解邊界不明、多系統調用順序衝突）。
3. 缺少關鍵 host API 端點定義且需求書亦無提及欄位細節，致使無法建立 OpenAPI spec。

**其餘架構、路徑、平台、版本、套件等技術項目，一律直接套用上述矩陣，立即進入 Step 1 展開設計！**

---

## Step 1: 業務需求拆解 (與平台無關)

### 1a. 寫一份 `spec.md` 草稿 (§0 假設清單 + §1 概覽 + §2 輸入輸出)

**§0 假設清單強制結構** (H1-Hn):

| # | 假設 | 為何這樣假設 | 待確認問題 | 落地策略 |
|---|---|---|---|---|
| H1 | 輸入欄位 N 個 | 業務書 §X | — | spec §2.1 schema 對應 |
| H2 | 終態 finalStatus 有 M 個 | 業務書 §Y | — | spec §2.3 + status-rewrite config 對應 |
| H3 | ... | ... | ... | ... |
| H<sub>n</sub> | 新增 service FQCN: `xxx.Yyy::method` | 既有 service 未提供 | 需實作 service bean | 在 Step 4 補 Java service |

**⭐ 關鍵**: H<sub>n</sub> 必須明確標註「FQCN 假設」,這是下游 `sonataflow-integration` 識別要新建 / 擴充 service 的唯一依據。

### 1b. 識別 workflow 結構模式 (5 種常見)

| 模式 | 適用情境 | 典型架構 |
|---|---|---|
| **A. 單層 Saga LIFO** | 跨 1 個外部系統,2 階段提交 | workflow 內: ForwardState → CheckResult → (RollbackState if fail) → EndState |
| **B. Parent + 2 個 Child Subflow** | 業務多入口,依 dispatcher 路由 | Parent: Validate → CheckIdempotency → **CheckIdempotencyResult (獨立 switch)** → Dispatcher → (subflow) → FinalAuditAndEnd<br>Child A: 對應業務 A<br>Child B: 對應業務 B |
| **C. 多層 Parent** | 多層級審批 / 多階段業務流 | 多個 Parent 互相 subflow 委派 |
| **D. 事件驅動** | 接收外部事件觸發 | EventListener → Validate → Process |
| **E. 計時 / 排程** | 排程觸發 | Timer → Validate → Process |

**⭐ 識別結果決定 YAML 結構**:
1. B 模式 → 有 subflow，Step 6 「平台相容性預檢」必須過 hyphen ID 檢查。
2. **Kogito jBPM Split 條件順序防護**: Parent 狀態機中，**`CheckIdempotencyResult` 必須作為獨立 Switch 狀態**（僅判斷 `idempotentReplay == true` 轉移至重放終態，未命中 default 進入 `Dispatcher`）。嚴禁將冪等重放與 `operationType` 業務分流混寫在同一個 switch，否則 jBPM Split 節點條件無序性會導致業務分支掠奪冪等重放！
3. **平台標準 Action 簽名**: 調用 `recordAuditLog` 必須採用平台標準 5 參數契約：`arguments: {workflowId, businessKey, processInstanceId, inputData, outputData}`，其中 `outputData` 需包含 `{status: .finalStatus, finalStatus: .finalStatus, message: ...}`。
4. **階梯式 Switch 模式 (Cascading Switch Pattern)**: 當流程需同時評估「前置實體是否存在」與「實體狀態是否允許操作」時，**嚴禁合併於單一 Switch 狀態**！例如逆向取消 Child 流程，必須拆為兩段獨立 Switch：
   - Stage 1 (`CheckOriginalExists`): 僅判定 `.found != true` $\rightarrow$ `FinalizeLookupFailed`；`default` $\rightarrow$ 進入 Stage 2。
   - Stage 2 (`CheckOriginalCancellable`): 僅判定狀態與沖銷欄位 $\rightarrow$ `FinalizeCancelRejected`；`default` $\rightarrow$ 進入核心沖正操作。
   *根因*：當查無資料時，狀態屬性為空字串或 null，此時兩條件在 jq 評估下可能同時為 true，jBPM 無序性會直接跳過查無資料判定而轉向拒絕！
5. **逆向工作流跨流程關聯鐵律 (Cross-Workflow Reference)**: 在 Mode B 或 Saga 逆向補償流程（取消 / 沖正 / 退款）中，調用 `lookupOriginalTransaction` 或 `markOriginalCancelled` 時，**`workflowId` 參數必須指定為原正向發起流程之 ID**（例如 `repayment_cash_deposit`），**嚴禁使用逆向流程自身的 ID**！因為對帳底庫中紀錄是由正向流程所寫入。
6. **狀態雙軌安全守衛表達式 (Dual-Track jq Guard)**: 查詢對帳日誌底庫時，底層 `status` 欄位存入的是數值（`0` / `1`），而在部分業務層是字串（`"SUCCESS"` / `"FAILED"`）。Switch 條件必須具備雙軌型態相容與 null 守衛：
   `((.originalResult.originalStatus // "") | tostring) != "SUCCESS" and ((.originalResult.originalStatus // "") | tostring) != "0"`

### 1c. 識別「終態 vs 業務碼」分離需求

**重要設計決策**: 對外 API response 要用以下哪種 convention?

| Convention | 適用情境 | 對應 HTTP 改寫需求 |
|---|---|---|
| **舊 convention** (saga2-transfer-workflow) | `status: STRING` 一個欄位 | 需 status-rewrite 改寫 HTTP code |
| **新 convention** (omni-cash-transaction) | `status: 0/1` (int) + `finalStatus: STRING` 兩欄位 | 需 status-rewrite 改寫 HTTP code |
| **純 HTTP status** | 對外不需 finalStatus,直接靠 HTTP code 區分 | 不需 status-rewrite |

**對應 platform 對齊**:
- 若 target platform 有 `WorkflowStatusFilter` 改寫機制 → 須沿用其 convention
- 若無 → 可自由設計

### 1d. 識別輸入驗證策略 (OpenAPI SSOT 驗證器 vs Kogito dataInputSchema 禁忌)

**⭐ 核心鐵律 (金融交易審計原則)**:
1. **嚴禁使用 Kogito 原生 `dataInputSchema`**:
   - 原生 `dataInputSchema` 會在 Workflow 實例建立前遭引擎中斷拋出 400，**無法抵達 `FinalAuditAndEnd` 寫入 AuditLog**，造成金融審計與對帳缺口 (Audit Gap)，且錯誤回傳結構非企業統一規範。
2. **推薦採用 OpenAPI Schema 驅動驗證 (方案 A / OpenApiSchemaValidator)**:
   - 以 `draft/src/specs/internal/*.yaml`（整併後為 `specs/internal/*.yaml`）的 `requestBody.content['application/json'].schema` 作為 Single Source of Truth (SSOT)。
   - 在 Workflow 起始狀態宣告 `ValidateInput` (operation state) 調用 `OpenApiSchemaValidator::validate`，搭配 `toStateData: '${ .validationResult }'`。
   - 經 `CheckValidationResult` (switch state) 路由：失敗時走 `InjectValidationFailedStatus` $\rightarrow$ `FinalAuditAndEnd` 確保 100% 審計軌跡落地，再由 `WorkflowStatusFilter` 改寫為 HTTP 400。
3. **分流適用範圍（對齊 project-0825-pd 20 workflow 實況：1/5+2/12）**:
   - Parent-Omni 型（完整三件套）：僅當 Parent 為對外入口且需嚴格審計時採用 `ValidateInput(operation)+CheckValidationResult+FinalAuditAndEnd`（如 `omni_cash_transaction`）。
   - Parent-通用型：其餘 Parent 可用 `ValidateInput(switch)+FinalAuditAndEnd`，無 `CheckValidationResult`（如 `fund_investment_order` 等 5 個）。
   - Child 型：用 `ValidateChildInput(switch)/LookupOriginal/Call* + End/ChildFinalAuditAndEnd`，不強制 validator（如 10 個 child + 2 saga）。下游詳見 `sonataflow-integration Step 6`。

---

## Step 2: 產出 OpenAPI specs (3 種角色)

### 2a. 對外契約 / 內部代理 spec (e.g., `omni-counter-repayment-api.yaml`)

- 目錄落位原則（draft→project 映射，下游詳見 `sonataflow-integration Step 2`；嚴格 internal/external 二分，root 禁放業務 yaml）:
  - **draft 側**：`draft/src/specs/internal/<entry-name>.yaml`（Parent 對外入口，必含 `x-workflow-id`，validator+router 唯一 SSOT）+ `draft/src/specs/external/<host>-api.yaml`（被調 host 規格，必無 `x-workflow-id`，`MyOpenApiService schemaRef` 來源）。
  - **整併後**：分別落到 `<project>/.../resources/specs/internal/` 與 `specs/external/`，再同步到 `distribution/transfer-app/.../specs/` 下同名子目錄（雙模組同步，transfer-workflow 為 SSOT）。root `specs/*.yaml` 僅相容舊案 20 檔，新案禁止再落 root；入口 API 禁止落 root（現 root 舊 `omni-counter-repayment-api.yaml` 無標籤嚴格版視為待刪，以 internal 放寬版為準）。
- 內容要素:
  - `info.title` 與 `description` 明確標記「此為 Parent / 對外 entry」
  - 僅 Parent 對外入口需要在操作路徑顯式宣告 `x-workflow-id: <workflow_id>`（供 `InternalOpenApiDynamicRouter` 自動註冊路由；host specs 不需要。實況 21 specs 僅 1 有，此為正常）。
  - `servers[0].url` 建議填 `http://localhost:8080`，但缺失時可用 `kogito.sw.functions.callApiViaOpenAPI` 的 `base_url>%dev.host>spec servers` fallback 鏈補救（實況 `fx-exchange-api.yaml` 缺 servers 仍可運行）。
  - 請求/回應 schema 完整，包含正則 pattern、minLength、maxLength、enum 與條件必填說明
  - `operationId` 唯一且具語意 (e.g., `executeOmniRepayment`)
  - ⭐ **Spec Schema 與 Example 嚴格一致性守則**:
    - Schema 內的 `maxLength` / `minLength` / `pattern` 必須與 example 內容完全相容。
    - **禁止出現「宣告 maxLength: 4 但 example 給 5 碼 (如 2500P)」或「宣告 maxLength: 22 但 example 含 prefix 達 25 碼」的內部矛盾**。

### 2b. Host API 規格 (e.g., `core-account-cash-deposit-api.yaml`)

- 一個 host 一個 spec，落放至 `specs/`
- `parameters: [in: path]` 區段務必明確 (下游整合會自動掃描)
- `paths` 完整含所有 operation (正向 + 反向 + 取消 + 查詢)

### 2c. Mock 規格 (給 dev profile mock 用)

- 通常等同 host API 規格 (mock 實作 host API)
- 但**重要**: mock 的 `@Path` 與 spec 的 `paths` 必須一致 (e.g., `/CoreAccount/{creditcardid}/CashDeposit/Execute`)
- 若有 path param,設計時就要明確標出,否則下游整合時 workflow 會丟 `Illegal character in path`

---

## Step 3: 產出 workflow YAML (Serverless Workflow v0.8)

### 3a. 平台相容性預檢 (設計期必跑 10 項，詳見 Step 6)

| 檢查 | 命令 | 不通過時 |
|---|---|---|
| Kogito 10.2.0 + 含 subFlowRef + workflow id 含 hyphen | 設計時主動詢問: 「workflow id 命名用 snake_case 或 hyphen-case?」 | 改 snake_case,或 spec.md 標註 v1.0 hotfix |
| actionDataFilter 是否用 `.result.X`（僅直調 functionRef 才查；subFlowRef 豁免） | 自我檢查清單 (見 Step 7) | 改用頂層欄位 |
| path param 是否在 payload | 自我檢查清單 | 自動加 |
| output 是否含 `status: 0/1` + `finalStatus: STRING` 兩欄位 (僅 Parent 新 convention；Child 僅 finalStatus、Saga 用 status/message，見 3d 分流) | 自我檢查清單 | 補上 |
| YAML 是否有 trailing comma | 自我檢查清單 | 移除 |
| subFlowRef version 是否等於 child version（如 parent 1.0.1 vs subFlow 1.0 即 FAIL） | Step 6.10 檢查 | 對齊為同一版本 |
| 檔名-id Manifest 是否齊全（hyphen 檔名 vs underscore id 視為合法，需登記） | Step 7.14 / §8 | 補 Manifest 行 |
| errors 有宣告但 operation 缺 onErrors，或有 ROLLBACK_FAILED 終態卻零 notifyOps | Step 6.11 檢查 | 補 onErrors + ROLLBACK_FAILED 告警 |

### 3b. YAML 結構樣板 (3 種模式對應)

**模式 A 範本 (單層 Saga LIFO)**:
```yaml
id: <workflow_id>
version: '1.0.0'
specVersion: '0.8'
name: <human readable name>
start: <first_state>
metadata:
  domain: <business-domain>
  pattern: saga-lifo-compensation
  criticality: <low|medium|high>
  owner: <team>
timeouts:
  workflowExecTimeout: PT5M
errors:
  - name: platformError
    code: 'PLATFORM_ERROR'
functions:
  - name: validateOpenApiInput
    operation: 'service:com.example.transfer.workflow.OpenApiSchemaValidator::validate'
    type: custom
  - name: callApiViaOpenAPI
    operation: 'service:com.example.transfer.workflow.MyOpenApiService::callOpenApi'
    type: custom
  - name: recordAuditLog
    operation: 'service:com.example.reconciliation.AuditLogService::saveLog'
    type: custom
  - name: notifyOps
    operation: 'service:com.example.reconciliation.OpsAlertService::raise'
    type: custom
states:
  # 階段 0: OpenAPI Schema 驅動驗證 (SSOT,取代冗長 jq)
  - name: ValidateInput
    type: operation
    onErrors:
      - errorRef: platformError
        transition: InjectValidationFailedStatus
    actions:
      - name: validateOpenApiSchemaAction
        functionRef:
          refName: validateOpenApiInput
          arguments:
            workflowId: "<workflow_id>"
            payload: '${ . }'
        actionDataFilter:
          results: '{isValid: .isValid, message: .message, errors: .errors}'
          toStateData: '${ .validationResult }'    # ⭐ 必須指定 toStateData 保全原始輸入資料
    transition: CheckValidationResult

  - name: CheckValidationResult
    type: switch
    onErrors:
      - errorRef: platformError
        transition: InjectValidationFailedStatus
    dataConditions:
      - name: inputValidationFailed
        condition: '${ .validationResult.isValid == false }'
        transition: InjectValidationFailedStatus
    defaultCondition:
      transition: CallCoreForward

  - name: CallCoreForward
    type: operation
    actions:
      - functionRef:
          refName: callApiViaOpenAPI
          arguments:
            functionName: "callApiViaOpenAPI"
            schemaRef: 'specs/<host-api>.yaml#<operationId>'
            payload:
              <path_param_1>: '${ .<input_field> }'   # ⭐ 自動注入
              <field_1>: '${ .<input_field> }'
              ...
        actionDataFilter:
          results: '{status: .code, message: .message, ...}'  # ⭐ 頂層,非 .result
          toStateData: '${ .coreResult }'
  ...
```

**模式 B 範本 (Parent + 2 Child)**:
- Parent workflow YAML 含 `subFlowRef: { workflowId: <child_id>, version: ... }`
- ⭐ **重要**: child workflow id 必須是 snake_case (見 3a 預檢)
- Child workflow YAML 各自獨立,但 functions 與 services 沿用
- ⭐ **payload 鐵律 (見 7.29)**: `currency/BIC/country/address/fee/rate` 一律 `'${ .field }'`，僅允許 `OUR/BEN/A/B/C/R` literal；衍生欄位（如 `amountInUSD`）必須含運算式

**模式 D 範本 (事件驅動，實驗性)**:
- ⚠️ 實驗性：`project-0825-pd` 20 workflow 零 `event` state，生產前需先驗證。
- 起點是 event trigger state
- 含 `eventConditions` 過濾事件

### 3c. ActionDataFilter 結構守則 (跨模式通用，子流豁免)

**鐵律 1: 頂層欄位對齊（雙軌）**:
`MyOpenApiService::callOpenApi` 回傳 response 是**頂層欄位**,不是 `.result` 底下。注意雙軌：host 業務碼為 `code(string)`，新 convention 對外為 `status(int 0/1)`，兩者不要混用。另有 `track_id/trackId`、`_httpStatus`、`errorType`、`errors` 頂層 metadata。下游詳見 `sonataflow-integration Step 6b`。
```yaml
# ✅ 對（新 convention：把 code 映射為 status，保留雙軌來源；schemaRef 指向 external）
results: '{status: .code, message: .message, track_id: .track_id, errorType: .errorType, _httpStatus: ._httpStatus, errors: .errors}'
# 對應 arguments: schemaRef: 'specs/external/<host>.yaml#<operationId>'（新案；舊案 specs/<host>.yaml 僅相容）

# ❌ 錯
results: '{status: .result.code, message: .result.message, ...}'
```

**鐵律 2: 直調必須宣告 `toStateData`，子流/終端豁免 (State Data 保全原則)**:
直調 `functionRef` 若只宣告 `results: '{ ... }'` 而漏掉 `toStateData`，Kogito 會將 results 物件**整份覆寫**當前的 Workflow State Data，導致先前的輸入欄位（如 `partyId`, `amount`, `sequenceNumber`）全部遺失，造成下游 Subflow 與 AuditLog 欄位全為 null！下游詳見 `sonataflow-integration Step 6e`。
豁免：`subFlowRef` invoke（12 處實況全無 actionDataFilter 屬正常）、terminal `recordAuditLog`、`MarkOriginalCancelled` 非關鍵路徑可免（child End 8 處無 actionDataFilter 屬正常）。
```yaml
# ✅ 對: 將 action 執行結果隔離注入指定 key，完整保留既有 State Data
actionDataFilter:
  results: '{isValid: .isValid, message: .message, errors: .errors}'
  toStateData: '${ .validationResult }'

# ❌ 錯: 缺少 toStateData，整份 Workflow 記憶體將被覆蓋成只有 isValid, message, errors
actionDataFilter:
  results: '{isValid: .isValid, message: .message, errors: .errors}'
```

**若有 `result` sub-object** (例如 host 回 `{status: 0, result: {sequenceNumber: "xxx"}}`):
```yaml
# ✅ 對: sub-object 內的欄位直接寫進 results,不要包 .result
results: '{status: .status, sequenceNumber: .result.sequenceNumber}'
```

### 3d. StateDataFilter Output 結構守則 (Parent/Child/Saga 分流)

依 convention 與 workflow 層級決定（下游 `WorkflowStatusFilter` 讀 `finalStatus→status` fallback，詳見 `sonataflow-integration Step 6c`）:

```yaml
# Parent 舊 convention (saga2-transfer-workflow 風格，僅 Parent-Saga 用)
stateDataFilter:
  output: |
    {
      status: .finalStatus,
      message: .finalMessage,
      ...
    }

# Parent 新 convention (omni-cash-transaction 風格,推薦，僅 Parent 用)
stateDataFilter:
  output: |
    {
      track_id: .<key_id_field>,
      workflow: (if .<dispatch_field> == "A" then "REPAYMENT" else "CANCELLATION" end),
      status: (if .finalStatus == "SUCCESS" or ... then 0 else 1 end),  # int 0/1
      finalStatus: .finalStatus,  # string
      message: .finalMessage,
      <host_api_result_1>: (.coreResult // null),
      ...
    }

# Child End（僅 finalStatus，不加 status；實況 10 child 皆如此）
stateDataFilter:
  output: |
    {
      finalStatus: .finalStatus,
      finalMessage: .finalMessage,
      <child_result>: (.coreResult // null)
    }
```

---

## Step 4: 補 Java 服務 (當 spec 標註新 FQCN 時)

### 4a. 識別需要新建 / 修改的 service

讀 `docs/spec.md §0 H<sub>n</sub>` 假設清單,找出所有 FQCN:

```yaml
H13a: XxxBusinessRuleValidator::validate  # 新業務有條件必填/FAIL_哨兵時新建，否則複用通用 validator
H13b: IdempotencyService::findBySequenceNumber  # 新建
H14: AuditLogService::markCancelledBy          # 擴充既有（注意 workflow_id 必須參數化，不可寫死）
```

### 4b. 通用 service 模板

業務服務放 `<project>/domain-*/.../src/main/java/com/example/<domain>/<ClassName>.java`（業務沿用 `com.example.*`；Mock 另見 Step 5，用 `org.acme.transfer.api`，兩軌不要混用）。下游 Java 落檔詳見 `sonataflow-integration Step 4`。

```java
package com.example.<domain>;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Map;

@ApplicationScoped
public class <ClassName> {

    private static final Logger LOG = LoggerFactory.getLogger(<ClassName>.class);
    private static final ObjectMapper MAPPER = new ObjectMapper();

    @Inject
    DataSource dataSource;

    // 1. 展開參數版入口 (對應 Kogito reflection 具名綁定，鍵名必須與 YAML arguments 完全一致，含 workflowId/businessKey)
    public JsonNode <methodName>(String arg1, Object arg2) {
        return do<MethodName>(arg1, arg2 != null ? arg2.toString() : null);
    }

    // 1b. Map 版入口（核心 5 服務實況皆有，補齊以防 codegen 傳 Map）
    public JsonNode <methodName>(String arg1, Map<String, Object> arg2) {
        return do<MethodName>(arg1, arg2 != null ? String.valueOf(arg2.get("businessKey")) : null);
    }

    // 2. JsonNode 單參數版入口 (Kogito codegen 預設生成)
    public JsonNode <methodName>(JsonNode arguments) {
        if (arguments == null) {
            return MAPPER.createObjectNode().put("<key>", false);
        }
        // 從 arguments 解析 arg1, arg2
        return do<MethodName>(arg1, arg2);
    }

    private JsonNode do<MethodName>(String arg1, String arg2) {
        // 實際 SQL 邏輯
    }
}
```

### 4c. 平台標準共用服務清冊與擴充原則

**平台共用服務清冊 (SSOT Canonical Package)**:
在 Workflow YAML 的 `functions:` 宣告中，若調用平台既有核心服務，**必須使用下列唯一標準 FQCN 與參數契約**，嚴禁使用過時的 `platform.security` 或自行編造 package：

| 服務類別 | 標準 FQCN | 標準參數契約 (Caller 必須嚴格對齊) | 說明 |
|---|---|---|---|
| `OpenApiSchemaValidator` | `com.example.transfer.workflow.OpenApiSchemaValidator` | `validate(Map arguments)` 或 `(JsonNode)` | Parent 入口 OpenAPI 驗證 |
| `MyOpenApiService` | `com.example.transfer.workflow.MyOpenApiService` | `callOpenApi(Map arguments)` 或 `(JsonNode)` | OpenAPI spec 驅動之外部 HTTP 調用 |
| `IdempotencyService` | `com.example.reconciliation.IdempotencyService` | `findBySequenceNumber(String workflowId, Object businessKey)` | 冪等性查詢 (嚴格 2 參，**禁傳** sequenceNumber) |
| `AuditLogService` | `com.example.reconciliation.AuditLogService` | `saveLog(String, Object, Object, Object, Object)` (5 參)<br>`findBySequenceNumber(String workflowId, Object businessKey)` (2 參)<br>`markCancelledBy(String, Object, Object, Object)` (4 參) | 稽核紀錄、原交易查詢與沖銷標記 |
| `OpsAlertService` | `com.example.reconciliation.OpsAlertService` | `raise(String, Object, Object, Object, Object, Map)` (6 參) | 補償失敗人工介入告警 (`notifyOps`) |

- 既有 `AuditLogService` / `OpsAlertService` / `MyOpenApiService` / `IdempotencyService` 必須優先複用，不重造。
- **「Caller 嚴格對齊 Callee」原則**：不得為單一 workflow 隨意在 Java 增添 overload；Workflow YAML 傳遞的 arguments 鍵名與數量必須與 Java 方法宣告 100% 精準一致（如 `findBySequenceNumber` 只接受 `workflowId` 與 `businessKey`，多傳 `sequenceNumber` 會直接引發 Kogito NoSuchMethodException）。
- 擴充方法須「展開參數版（鍵名對齊 YAML arguments）」+「Map 版」+「JsonNode 版」三進入點 (Kogito reflection 三種都可能用；舊 `SagaApiService` 僅展開參數為例外，新服務不可學)。
- `markCancelledBy` 的 `workflow_id` 必須參數化，不可寫死為 `repayment-cash-deposit`（實況硬編碼為已知坑，設計期就要在 H14 落地策略寫明參數化）。
- 新業務若有條件必填（如 operationType=A/B 與 originalSequenceNumber 連動）或 `FAIL_` 哨兵，需新建 `XxxBusinessRuleValidator implements BusinessRuleValidator` 並在 `OpenApiSchemaValidator` dispatch 註冊（仿 `OmniCashBusinessRuleValidator`）；無特殊規則則複用通用 validator 即可（實況新 5 域缺 validator 導致 FAIL_* 零覆蓋，不可重蹈）。

### 4d. Flyway migration (若有新欄位或對帳 View 需求)

**自動探測既有最大版本號 (透過 Agent Dynamic Script Runner)**:
在為新 Draft 決定 Flyway 版本號前，建議先確認 Runner 存活（`curl -s http://127.0.0.1:8091/api/health`），再呼叫 Agent Runner 自動掃描目標專案中現有的最大版本：

```bash
curl -s -X POST http://127.0.0.1:8091/api/run \
  -H "Content-Type: application/json" \
  -d '{
    "script": "const projectRoot = path.join(workspaceRoot, args.project || \"\"); function findSqls(dir) { let r = []; if (!fs.existsSync(dir)) return r; for (const e of fs.readdirSync(dir, { withFileTypes: true })) { const fp = path.join(dir, e.name); if (e.isDirectory()) r = r.concat(findSqls(fp)); else if (e.name.endsWith(\".sql\") && fp.includes(\"/db/migration/\")) r.push(e.name); } return r; } const sqls = findSqls(projectRoot); let maxMaj = 1, maxMin = 0, maxPat = 0, latest = null; for (const s of sqls) { const m = s.match(/^V(\\d+)(?:\\.(\\d+))?(?:\\.(\\d+))?__/); if (m) { const maj = parseInt(m[1]), min = parseInt(m[2] || \"0\"), pat = parseInt(m[3] || \"0\"); if (maj > maxMaj || (maj === maxMaj && min > maxMin) || (maj === maxMaj && min === maxMin && pat >= maxPat)) { maxMaj = maj; maxMin = min; maxPat = pat; latest = `V${maj}.${min}.${pat}`; } } } const next = latest ? `V${maxMaj}.${maxMin}.${maxPat + 1}` : \"V1.0.0\"; console.log(`目前專案既有最大版本: ${latest || \"無\"}，建議新版號: ${next}`); return { latest, nextSuggested: next };",
    "args": { "project": "project-0825-pd" }
  }'
```

**版本號制定原則**:
- 若既有最大版本為 `V1.2.4`，則新 Draft 必須自動遞增為 `V1.2.5__<description>.sql`。
- 檔案命名格式：`V<X>.<Y>.<Z>__<description>.sql`（`description` 為英文小寫，底線分隔）。

放在 `drafts/<feature-name>/db/migration/V<X>.<Y>.<Z>__<description>.sql`（後續由 `sonataflow-integration` 整併至 `<project>/.../src/main/resources/db/migration/`）：

```sql
-- 範例 1: 欄位擴充 (若有新欄位需求)
ALTER TABLE workflow_execution_log ADD COLUMN <new_col> TEXT;
CREATE INDEX IF NOT EXISTS idx_<table>_<col> ON <table>(<col>);

-- 範例 2: 業務對帳檢視表 (View DDL)
-- ⚠️ 重要：SQLite 不支援 CREATE OR REPLACE VIEW，且 CREATE VIEW IF NOT EXISTS 若 View 已存在則不會重新觸發或更新欄位定義。
-- 因此在 CREATE 之前務必先加上 DROP VIEW IF EXISTS，確保視圖重構或修改能確實生效！
DROP VIEW IF EXISTS vw_<workflow>_reconciliation;
CREATE VIEW IF NOT EXISTS vw_<workflow>_reconciliation AS
SELECT
    id, created_at, workflow_id, business_key, process_instance_id, status, message,
    json_extract(input_data, '$.partyId') AS party_id,
    json_extract(input_data, '$.operationType') AS operation_type,
    json_extract(input_data, '$.amount') AS amount,
    cancelled_by, cancelled_at
FROM workflow_execution_log
WHERE workflow_id IN ('<parent_workflow_id>', '<child_a_id>', '<child_b_id>');
```

---

## Step 5: 產出 Mock Resources (dev profile)

### 5a. 命名對齊既有 project 模組 (設計期先問，下游 rename兜底)

**設計期先問**:
- 既有 mock 模組的 package 是? (e.g., `org.acme.transfer.api`)
- 若無既有,新模組該叫? (e.g., `org.acme.cashrepayment.api` 佔位亦可)

draft 可用佔位 package（如 `org.acme.cashrepayment.api`），下游 `sonataflow-integration Step 5a-5b` 會統一 `replace → org.acme.transfer.api`（注意 DTO 兩階段替換，避免 `.dto.dto`）。設計期若已知既有 package，直接對齊可省 rename 工時，但非強制。

### 5b. Mock Resource 樣板 (2 種 sentinel 模式)

**Sentinel 模式 A: 業務 payload 內字串前綴**
```java
@Path("/CoreAccount/{creditcardid}/CashDeposit/Execute")
public class CoreCashDepositResource {
    @POST
    public Response execute(@PathParam("creditcardid") String creditcardid,
                            CoreCashDepositRequest request) {
        // 業務拒絕 sentinel: amount = "0" 或 "0000000000" 或以 "FAIL" 開頭
        if (isBusinessReject(request.amount)) {
            return Response.status(403).entity(buildError("E0024", "金額不符", null)).build();
        }
        // RBFAIL sentinel: operationType=B 且 sequenceNumber 以 "RBFAIL" 開頭
        if ("B".equals(request.operationType) && request.sequenceNumber != null
                && request.sequenceNumber.startsWith("RBFAIL")) {
            return Response.status(403).entity(buildError("E0050", "回沖失敗", null)).build();
        }
        // 正常成功
        ...
    }
}
```

**Sentinel 模式 B: 獨立 sentinel field** (避免破壞 input validation)
```java
public class CoreCashDepositRequest {
    public String partyId;
    public String branchCode;
    public String amount;
    public String sequenceNumber;
    public String operationType;
    public String __sentinel;  // 設計期專用,真實 API 不會有
}
```

**設計期決策（實況主力為 A，B 備選）**:
- 預設採模式 A（字串前綴），並在 `OpenApiSchemaValidator::validate` 加 `FAIL_` 豁免（剝離前綴後再測 regex，實況 `OpenApiSchemaValidator.java:401-403` 已如此），同時 switch 條件用 `tonumber? //` 或 `startswith("FAIL_")` 守衛避免 jq 拋錯（詳見 `references/01-platform-checks/06-mock-sentinel-vs-input-validation.md` 陷阱 2）。
- 僅當業務 regex 絕對不可放行任何非數字且 validator 不可改時，才採模式 B（獨立 `__sentinel` field；實況零使用，屬備選）。
- 新業務若新建 `BusinessRuleValidator`，必須同步覆蓋 `FAIL_*` 剝離邏輯，否則新 workflow 的業務失敗路徑零覆蓋（實況新 5 域即如此）。

### 5c. DTO 設計守則

- 一個 request + 一個 response + 一個 result sub-object (e.g., `CoreCashDepositRequest` / `CoreCashDepositResponse` / `CoreCashDepositResult`)
- 極簡風格: 純 public field,無 getter/setter (與既有 transfer-mock 一致)
- ErrorDetail 共用 DTO 放 `org.acme.<project>.api.dto.ErrorDetail`

---

## Step 6: 平台相容性預檢 (★ v3 全面改用 Agent Dynamic Script Runner)

設計期就跑這 10 項檢查（6.1-6.11），任何一項不通過就修正 draft，不交付。
在 v3 中，**所有預檢全面改用 SonataFlow Agent Dynamic Script Runner（單一通訊埠 8091 / `POST /api/run`）**，完全跨平台且在檢測失敗時自動透過 `helpers.addDiagnostic` 於 VS Code 問題（Problems）面板標註紅線。

> 💡 **一鍵全量預檢 (推薦)**：先探測 Runner 存活狀態，再發送請求執行全套檢查：
> ```bash
> # 0. 先行探測 Runner 存活狀態
> curl -s http://127.0.0.1:8091/api/health
>
> # 1. 執行一鍵全量預檢
> curl -s -X POST http://127.0.0.1:8091/api/run-file \
>   -H "Content-Type: application/json" \
>   -d '{"filePath": ".agents/skills/vibe-workflow-design-v3/scripts/preflight-checks.js", "args": {"draftDir": "drafts/<feature-name>"}}'
> ```

以下為各單項獨立檢查之 Runner 調用：

### 6.1 Workflow ID 命名 (Kogito 10.2.0 相容性)

```bash
curl -s -X POST http://127.0.0.1:8091/api/run \
  -H "Content-Type: application/json" \
  -d '{
    "script": "const targetDir = path.join(workspaceRoot, args.draftDir || \"drafts/<feature-name>/src\"); const files = fs.readdirSync(targetDir).filter(f => f.endsWith(\".sw.yaml\")); let fail = false; for (const file of files) { const filePath = path.join(targetDir, file); const content = fs.readFileSync(filePath, \"utf8\"); if (content.includes(\"subFlowRef\")) { const wf = helpers.parseYaml(content); if (wf.id && wf.id.includes(\"-\")) { fail = true; console.log(`❌ FAIL: ${file} workflow id \"${wf.id}\" 含連字號，會觸發 Kogito 10.2.0 codegen bug！`); helpers.addDiagnostic(filePath, 1, 1, `Workflow id \"${wf.id}\" 含連字號，請改為 snake_case`, \"error\"); } else { helpers.clearDiagnostics(filePath); } } } return { success: !fail };",
    "args": { "draftDir": "drafts/<feature-name>/src" }
  }'
```

不通過: 改 snake_case + 在 spec.md 標註 v1.0 hotfix

### 6.2 actionDataFilter 結構 (MyOpenApiService 相容性)

```bash
curl -s -X POST http://127.0.0.1:8091/api/run \
  -H "Content-Type: application/json" \
  -d '{
    "script": "const targetDir = path.join(workspaceRoot, args.draftDir || \"drafts/<feature-name>/src\"); const files = fs.readdirSync(targetDir).filter(f => f.endsWith(\".sw.yaml\")); let fail = false; for (const file of files) { const filePath = path.join(targetDir, file); const wf = helpers.parseYaml(fs.readFileSync(filePath, \"utf8\")); for (const state of (wf.states || [])) { if (state.type === \"operation\" && state.actions) { for (const act of state.actions) { if (act.actionDataFilter && act.actionDataFilter.results) { const match = String(act.actionDataFilter.results).match(/\\.result\\.[a-zA-Z_]+/g); if (match) { fail = true; console.log(`❌ FAIL: ${file} 狀態 \"${state.name}\" actionDataFilter 誤用 .result: ${match.join(\", \")}`); helpers.addDiagnostic(filePath, 1, 1, `actionDataFilter 誤用 .result: ${match.join(\", \")}，請改為頂層欄位存取`, \"error\"); } } } } } if (!fail) helpers.clearDiagnostics(filePath); } return { success: !fail };",
    "args": { "draftDir": "drafts/<feature-name>/src" }
  }'
```

不通過: 改為直接讀頂層 `.X`

### 6.3 Path Parameter 自動注入

```bash
curl -s -X POST http://127.0.0.1:8091/api/run \
  -H "Content-Type: application/json" \
  -d '{
    "script": "const draftRoot = path.join(workspaceRoot, args.draftDir || \"drafts/<feature-name>\"); const swDir = path.join(draftRoot, \"src\"); const files = fs.readdirSync(swDir).filter(f => f.endsWith(\".sw.yaml\")); let fail = false; for (const file of files) { const filePath = path.join(swDir, file); const wf = helpers.parseYaml(fs.readFileSync(filePath, \"utf8\")); for (const state of (wf.states || [])) { for (const act of (state.actions || [])) { const fnRef = act.functionRef; if (fnRef && fnRef.arguments && fnRef.arguments.schemaRef) { const [relSpec, opId] = String(fnRef.arguments.schemaRef).split(\"#\"); const specPath = path.join(draftRoot, \"src\", relSpec); if (!fs.existsSync(specPath)) { fail = true; continue; } const spec = helpers.parseYaml(fs.readFileSync(specPath, \"utf8\")); const pathParams = []; for (const pMethods of Object.values(spec.paths || {})) { for (const op of Object.values(pMethods || {})) { if (op && op.operationId === opId && Array.isArray(op.parameters)) { for (const p of op.parameters) if (p.in === \"path\") pathParams.push(p.name); } } } const payload = fnRef.arguments.payload || {}; for (const p of pathParams) { if (!(p in payload)) { fail = true; console.log(`❌ FAIL: ${file} 操作 \"${opId}\" 缺少 path param: \"${p}\"`); helpers.addDiagnostic(filePath, 1, 1, `操作 \"${opId}\" 缺少 URL Path Parameter \"${p}\"，必須在 payload 顯式提供`, \"error\"); } } } } } } return { success: !fail };",
    "args": { "draftDir": "drafts/<feature-name>" }
  }'
```

不通過: 在每個對應的 workflow YAML 的 payload 加 `xxx: '${ .對應欄位 }'`

### 6.4 StateDataFilter.output 欄位 (Convention 對齊)

```bash
curl -s -X POST http://127.0.0.1:8091/api/run \
  -H "Content-Type: application/json" \
  -d '{
    "script": "const targetDir = path.join(workspaceRoot, args.draftDir || \"drafts/<feature-name>/src\"); const files = fs.readdirSync(targetDir).filter(f => f.endsWith(\".sw.yaml\")); let fail = false; for (const file of files) { const filePath = path.join(targetDir, file); const content = fs.readFileSync(filePath, \"utf8\"); if (!content.includes(\"stateDataFilter\")) continue; const wf = helpers.parseYaml(content); for (const state of (wf.states || [])) { if (state.stateDataFilter && state.stateDataFilter.output) { const outStr = String(state.stateDataFilter.output); const hasStatusInt = /status:\\s*\\(?if/m.test(outStr); const hasFinalStatus = outStr.includes(\"finalStatus\"); if (!hasStatusInt || !hasFinalStatus) { fail = true; console.log(`❌ FAIL: ${file} 狀態 \"${state.name}\" 新 convention 必須含 status (int 0/1) 與 finalStatus 雙軌欄位`); helpers.addDiagnostic(filePath, 1, 1, `stateDataFilter.output 必須同時包含 status: 0/1 與 finalStatus: .finalStatus`, \"error\"); } } } } return { success: !fail };",
    "args": { "draftDir": "drafts/<feature-name>/src" }
  }'
```

不通過: 補上 `status: 0/1` (jq expression) 與 `finalStatus: .finalStatus`

### 6.5 YAML 語法嚴格性

```bash
curl -s -X POST http://127.0.0.1:8091/api/run \
  -H "Content-Type: application/json" \
  -d '{
    "script": "const targetDir = path.join(workspaceRoot, args.draftDir || \"drafts/<feature-name>/src\"); const files = fs.readdirSync(targetDir).filter(f => f.endsWith(\".sw.yaml\")); let fail = false; for (const file of files) { const filePath = path.join(targetDir, file); const lines = fs.readFileSync(filePath, \"utf8\").split(\"\\n\"); for (let i = 0; i < lines.length; i++) { if (/^\\s+\\w+:\\s+.*,\\s*$/.test(lines[i])) { fail = true; console.log(`❌ FAIL: ${file}:${i + 1} 行尾存在多餘逗號: \"${lines[i].trim()}\"`); helpers.addDiagnostic(filePath, i + 1, 1, `語法錯誤：不可包含 trailing comma (,)`, \"error\"); } } } return { success: !fail };",
    "args": { "draftDir": "drafts/<feature-name>/src" }
  }'
```

不通過: 移除 trailing comma

### 6.6 Mock sentinel vs input validation 相容性

```bash
curl -s -X POST http://127.0.0.1:8091/api/run \
  -H "Content-Type: application/json" \
  -d '{
    "script": "const draftRoot = path.join(workspaceRoot, args.draftDir || \"drafts/<feature-name>\"); const mockDir = path.join(draftRoot, \"src/mocks\"); const mockFiles = fs.existsSync(mockDir) ? fs.readdirSync(mockDir).filter(f => f.endsWith(\".java\")) : []; const sentinels = new Set(); for (const mf of mockFiles) { const txt = fs.readFileSync(path.join(mockDir, mf), \"utf8\"); const matches = txt.match(/\"(FAIL_[A-Za-z0-9_]+|RBFAIL|[0-9]{10})\"/g); if (matches) matches.forEach(m => sentinels.add(m.replace(/\"/g, \"\"))); } console.log(\"ℹ️ Mock 哨兵清單:\", Array.from(sentinels)); return { sentinels: Array.from(sentinels) };",
    "args": { "draftDir": "drafts/<feature-name>" }
  }'
```

不通過: 改用模式 B (獨立 sentinel field) 或放寬 validation regex

### 6.7 OpenAPI Spec Schema 與 Example 一致性預檢

```bash
curl -s -X POST http://127.0.0.1:8091/api/run \
  -H "Content-Type: application/json" \
  -d '{
    "script": "const draftRoot = path.join(workspaceRoot, args.draftDir || \"drafts/<feature-name>\"); const specDirs = [path.join(draftRoot, \"src/specs/internal\"), path.join(draftRoot, \"src/specs/external\")]; let fail = false; for (const d of specDirs) { if (!fs.existsSync(d)) continue; for (const f of fs.readdirSync(d).filter(x => x.endsWith(\".yaml\"))) { const specPath = path.join(d, f); const spec = helpers.parseYaml(fs.readFileSync(specPath, \"utf8\")); function checkProps(props, prefix) { if (!props) return; for (const [name, val] of Object.entries(props)) { if (val && typeof val === \"object\") { const ex = val.example, maxL = val.maxLength, minL = val.minLength; if (typeof ex === \"string\") { if (maxL !== undefined && ex.length > maxL) { fail = true; console.log(`❌ FAIL: ${f} ${prefix}${name} example \"${ex}\" (len=${ex.length}) > maxLength ${maxL}`); helpers.addDiagnostic(specPath, 1, 1, `欄位 ${prefix}${name} example 長度超出 maxLength: ${ex.length} > ${maxL}`, \"error\"); } if (minL !== undefined && ex.length < minL) { fail = true; console.log(`❌ FAIL: ${f} ${prefix}${name} example \"${ex}\" (len=${ex.length}) < minLength ${minL}`); helpers.addDiagnostic(specPath, 1, 1, `欄位 ${prefix}${name} example 長度小於 minLength: ${ex.length} < ${minL}`, \"error\"); } } } } } for (const s of Object.values(spec.components?.schemas || {})) checkProps(s.properties, \"#schema.\"); for (const pMethods of Object.values(spec.paths || {})) { for (const op of Object.values(pMethods || {})) { const schema = op.requestBody?.content?.[\"application/json\"]?.schema; if (schema) checkProps(schema.properties, \"#requestBody.\"); } } } } return { success: !fail };",
    "args": { "draftDir": "drafts/<feature-name>" }
  }'
```

不通過: 修正 OpenAPI Schema 內之 `maxLength` / `minLength` 或範例值，保持兩者 100% 一致。

### 6.8 ActionDataFilter 漏設 toStateData 檢查 (State Data 保全，直調才查)

```bash
curl -s -X POST http://127.0.0.1:8091/api/run \
  -H "Content-Type: application/json" \
  -d '{
    "script": "const targetDir = path.join(workspaceRoot, args.draftDir || \"drafts/<feature-name>/src\"); const files = fs.readdirSync(targetDir).filter(f => f.endsWith(\".sw.yaml\")); let fail = false; for (const file of files) { const filePath = path.join(targetDir, file); const wf = helpers.parseYaml(fs.readFileSync(filePath, \"utf8\")); for (const state of (wf.states || [])) { if (state.type === \"operation\" && state.actions) { for (const act of state.actions) { if (act.functionRef && act.actionDataFilter && act.actionDataFilter.results) { const isSubFlow = Boolean(act.subFlowRef); const isTerminalAudit = act.functionRef.refName === \"recordAuditLog\"; if (!isSubFlow && !isTerminalAudit && !act.actionDataFilter.toStateData) { fail = true; console.log(`❌ FAIL: ${file} 狀態 \"${state.name}\" 直調缺少 toStateData`); helpers.addDiagnostic(filePath, 1, 1, `狀態 \"${state.name}\" 的直調 actionDataFilter 缺少 toStateData，會造成輸入 Payload 被覆寫！`, \"error\"); } } } } } } return { success: !fail };",
    "args": { "draftDir": "drafts/<feature-name>/src" }
  }'
```

不通過: 直調必須顯式補上 `toStateData: '${ .targetField }'`，避免 Workflow 輸入 Payload 遭覆蓋。下游詳見 `sonataflow-integration Step 6e`。

### 6.9 OpenAPI 內外目錄 + 動態路由標籤預檢 (x-workflow-id 宣告，僅 Parent 入口)

```bash
curl -s -X POST http://127.0.0.1:8091/api/run \
  -H "Content-Type: application/json" \
  -d '{
    "script": "const draftRoot = path.join(workspaceRoot, args.draftDir || \"drafts/<feature-name>\"); const internalDir = path.join(draftRoot, \"src/specs/internal\"); const externalDir = path.join(draftRoot, \"src/specs/external\"); const rootSpecDir = path.join(draftRoot, \"src/specs\"); let fail = false; if (fs.existsSync(internalDir)) { for (const f of fs.readdirSync(internalDir).filter(x => x.endsWith(\".yaml\"))) { const specPath = path.join(internalDir, f); const spec = helpers.parseYaml(fs.readFileSync(specPath, \"utf8\")); let hasTag = false; for (const ops of Object.values(spec.paths || {})) if (ops.post && ops.post[\"x-workflow-id\"]) hasTag = true; if (!hasTag) { fail = true; console.log(`❌ FAIL: ${f} internal 缺少 x-workflow-id`); helpers.addDiagnostic(specPath, 1, 1, `對外入口 spec 的 post 操作缺少 x-workflow-id 標籤`, \"error\"); } } } if (fs.existsSync(externalDir)) { for (const f of fs.readdirSync(externalDir).filter(x => x.endsWith(\".yaml\"))) { const specPath = path.join(externalDir, f); if (fs.readFileSync(specPath, \"utf8\").includes(\"x-workflow-id\")) { fail = true; console.log(`❌ FAIL: ${f} external 禁止含有 x-workflow-id`); helpers.addDiagnostic(specPath, 1, 1, `External host spec 禁止含有 x-workflow-id`, \"error\"); } } } if (fs.existsSync(rootSpecDir)) { for (const rf of fs.readdirSync(rootSpecDir).filter(x => x.endsWith(\".yaml\") && x !== \"openapi.yaml\")) { fail = true; console.log(`❌ FAIL: root ${rf} 請搬入 internal 或 external`); helpers.addDiagnostic(path.join(rootSpecDir, rf), 1, 1, `root src/specs/ 禁止放業務 yaml，請搬入 internal/ 或 external/`, \"error\"); } } return { success: !fail };",
    "args": { "draftDir": "drafts/<feature-name>" }
  }'
```

不通過: internal 的 `post:` 補 `x-workflow-id`；external 刪標籤；root yaml 搬入 external。`servers` 缺失可用 baseUrl fallback 鏈補救，不在此項 FAIL。

### 6.10 subFlowRef version 對齊檢查

```bash
curl -s -X POST http://127.0.0.1:8091/api/run \
  -H "Content-Type: application/json" \
  -d '{
    "script": "const targetDir = path.join(workspaceRoot, args.draftDir || \"drafts/<feature-name>/src\"); const files = fs.readdirSync(targetDir).filter(f => f.endsWith(\".sw.yaml\")); const wfMap = new Map(); files.forEach(f => { const w = helpers.parseYaml(fs.readFileSync(path.join(targetDir, f), \"utf8\")); wfMap.set(w.id, w); }); let fail = false; for (const [id, wf] of wfMap.entries()) { for (const state of (wf.states || [])) { for (const act of (state.actions || [])) { if (act.subFlowRef) { const cId = act.subFlowRef.workflowId; const refVer = act.subFlowRef.version; const cWf = wfMap.get(cId); if (cWf && cWf.version && cWf.version !== refVer) { fail = true; console.log(`❌ FAIL: subFlowRef ${cId} 版本 ${refVer} 與定義 ${cWf.version} 不符！`); } } } } } return { success: !fail };",
    "args": { "draftDir": "drafts/<feature-name>/src" }
  }'
```

不通過: 統一為 child 實際 version（如 `1.0.1`），Parent 與 Child 同步改。

### 6.11 onErrors 覆蓋 + notifyOps 告警 (Audit Gap 防線)

```bash
curl -s -X POST http://127.0.0.1:8091/api/run \
  -H "Content-Type: application/json" \
  -d '{
    "script": "const targetDir = path.join(workspaceRoot, args.draftDir || \"drafts/<feature-name>/src\"); const files = fs.readdirSync(targetDir).filter(f => f.endsWith(\".sw.yaml\")); let fail = false; for (const file of files) { const filePath = path.join(targetDir, file); const txt = fs.readFileSync(filePath, \"utf8\"); const wf = helpers.parseYaml(txt); const ops = (wf.states || []).filter(s => s.type === \"operation\"); const errs = (wf.states || []).filter(s => s.onErrors && s.onErrors.length > 0); if (ops.length > 1 && errs.length < (ops.length - 1)) { fail = true; console.log(`❌ FAIL: ${file} operation=${ops.length} 但 onErrors=${errs.length}`); helpers.addDiagnostic(filePath, 1, 1, `onErrors 覆蓋不足 (${errs.length}/${ops.length})`, \"error\"); } if (txt.includes(\"ROLLBACK_FAILED\") && !txt.includes(\"refName: notifyOps\") && !txt.includes(\"refName: \\\"notifyOps\\\"\")) { fail = true; console.log(`❌ FAIL: ${file} 含有 ROLLBACK_FAILED 終態卻未調用 notifyOps`); helpers.addDiagnostic(filePath, 1, 1, `存在 ROLLBACK_FAILED 終態，必須調用 notifyOps 告警`, \"error\"); } } return { success: !fail };",
    "args": { "draftDir": "drafts/<feature-name>/src" }
  }'
```

不通過: 每個 `type: operation` 補 `onErrors: [{errorRef: platformError, transition: Finalize*}]`（terminal audit state 豁免）；有 `ROLLBACK_FAILED` 終態必須至少一處調用 `notifyOps`（建議 Java 側僅對該終態發告警）。

---

### 6.12-6.16: ⭐ v2.5 整合期補強檢查（源自 sonataflow-integration 反饋）

> **歷史教訓**：v2.4 之前的 10 項預檢能擋下大部分 Kogito/OpenAPI 陷阱，但實戰整合 `omni_cash_transaction` (2026-09) 時仍暴露 5 個**只在整合期才能發現**的隱性問題。為貫徹「門禁左移」，v2.5 起新增以下 5 項補強檢查，於設計期一併擋下。

### 6.12 Workflow `errors:` 宣告與 `errorRef` 引用對齊

**目的**：杜絕 Kogito codegen 拋 `Cannot find any error definition for errorRef X`。
**場景**：`RollbackCore.onErrors` 引用 `errorRef: platformError`，但 `errors:` 區塊只宣告 `CoreFailed` / `CreditCardFailed`，漏宣告 `platformError`，導致 Kogito 編碼失敗。

```bash
curl -s -X POST http://127.0.0.1:8091/api/run \
  -H "Content-Type: application/json" \
  -d '{
    "script": "const dir = path.join(workspaceRoot, args.draftDir || \"drafts/<feature-name>/src\"); const files = fs.readdirSync(dir).filter(f => f.endsWith(\".sw.yaml\")); let fail = false; for (const file of files) { const fp = path.join(dir, file); const wf = helpers.parseYaml(fs.readFileSync(fp, \"utf8\")); const declaredErrs = new Set((wf.errors || []).map(e => e.name)); const yamlStr = fs.readFileSync(fp, \"utf8\"); const refs = [...yamlStr.matchAll(/errorRef:\\s*[\\x27\"]?([a-zA-Z0-9_]+)/g)].map(m => m[1]); for (const r of new Set(refs)) { if (!declaredErrs.has(r)) { fail = true; console.log(`❌ FAIL: ${file} 引用 errorRef \"${r}\" 但 errors: 區塊未宣告`); helpers.addDiagnostic(fp, 1, 1, `Workflow 引用 errorRef \"${r}\" 但 errors: 區塊未宣告（Kogito codegen 將拋 Cannot find any error definition）`, \"error\"); } } } return { success: !fail };",
    "args": { "draftDir": "drafts/<feature-name>/src" }
  }'
```

不通過: 在 `errors:` 區塊補上對應的 `name: <errorRef>`（例如 `platformError` / `CoreFailed` / `CreditCardFailed` 等）。

---

### 6.13 Workflow 沒有 unreachable 狀態 (dead code)

**目的**：杜絕 jBPM `Node 'X' has no incoming connection / Has no connection to the start node`。
**場景**：開發者從舊版 child workflow 複製了 `FinalizeCancelRejected` 注入狀態，但忘了新設計下根本沒有任何 transition 指向它（Parent 已先一步處理取消），成為 dead code。

```bash
curl -s -X POST http://127.0.0.1:8091/api/run \
  -H "Content-Type: application/json" \
  -d '{
    "script": "const dir = path.join(workspaceRoot, args.draftDir || \"drafts/<feature-name>/src\"); const files = fs.readdirSync(dir).filter(f => f.endsWith(\".sw.yaml\")); let fail = false; for (const file of files) { const fp = path.join(dir, file); const wf = helpers.parseYaml(fs.readFileSync(fp, \"utf8\")); const states = wf.states || []; const incoming = new Set(); const start = wf.start; if (start) incoming.add(start); for (const s of states) { const targets = [s.transition, ...(s.dataConditions || []).map(d => d.transition), ...(s.defaultCondition ? [s.defaultCondition.transition] : []), ...(s.onErrors || []).map(e => e.transition)]; for (const t of targets) if (t) incoming.add(t); } for (const s of states) { if (!incoming.has(s.name)) { fail = true; console.log(`❌ FAIL: ${file} 狀態 \"${s.name}\" 沒有 incoming connection (unreachable / dead code)`); helpers.addDiagnostic(fp, 1, 1, `狀態 \"${s.name}\" 沒有任何 incoming transition，是 dead code（移除或補上 transition）`, \"error\"); } } } return { success: !fail };",
    "args": { "draftDir": "drafts/<feature-name>/src" }
  }'
```

不通過: 移除 dead state，或在父狀態補上 `transition` 指入。

---

### 6.14 notifyOps arguments 必須對齊 Java OpsAlertService 6 參展開簽名

**目的**：杜絕 `NoSuchMethodException: OpsAlertService.raise(...)`。
**場景**：開發者誤把 `AuditLogService.saveLog` 的命名慣例（`inputData` / `outputData`）套到 `notifyOps`，但 `OpsAlertService.raise` 簽名為 `(String, Object, Object, Object, Object, Map)`，6 個參數的**鍵名**必須是 `workflowId` / `processInstanceId` / `businessKey` / `finalStatus` / `finalMessage` / `detail`。

```bash
curl -s -X POST http://127.0.0.1:8091/api/run \
  -H "Content-Type: application/json" \
  -d '{
    "script": "const dir = path.join(workspaceRoot, args.draftDir || \"drafts/<feature-name>/src\"); const files = fs.readdirSync(dir).filter(f => f.endsWith(\".sw.yaml\")); let fail = false; const required = [\"workflowId\", \"processInstanceId\", \"businessKey\", \"finalStatus\", \"finalMessage\", \"detail\"]; const forbidden = [\"inputData\", \"outputData\"]; for (const file of files) { const fp = path.join(dir, file); const wf = helpers.parseYaml(fs.readFileSync(fp, \"utf8\")); for (const state of wf.states || []) { for (const act of state.actions || []) { if (act.functionRef?.refName === \"notifyOps\") { const args = act.functionRef.arguments || {}; for (const k of required) { if (!(k in args)) { fail = true; console.log(`❌ FAIL: ${file} 狀態 \"${state.name}\" notifyOps 缺少 \"${k}\"`); helpers.addDiagnostic(fp, 1, 1, `狀態 \"${state.name}\" notifyOps 缺少必要參數 \"${k}\" (對齊 OpsAlertService.raise 6 參簽名)`, \"error\"); } } for (const k of forbidden) { if (k in args) { fail = true; console.log(`❌ FAIL: ${file} 狀態 \"${state.name}\" notifyOps 使用了錯誤參數 \"${k}\"`); helpers.addDiagnostic(fp, 1, 1, `狀態 \"${state.name}\" notifyOps 使用了錯誤參數 \"${k}\" (應改為 finalStatus/finalMessage/detail)`, \"error\"); } } } } } } return { success: !fail };",
    "args": { "draftDir": "drafts/<feature-name>/src" }
  }'
```

不通過: 把 `notifyOps` 的 `arguments` 改成 6 參展開簽名（`workflowId` / `processInstanceId` / `businessKey` / `finalStatus` / `finalMessage` / `detail`），並用 `detail` Map 收容業務欄位（取代 `inputData` / `outputData`）。

---

### 6.15 Mock DTO 套件命名對齊 `transfer-mock` antrun 同步目錄 (`features/dto/`)

**目的**：杜絕執行期 `java.lang.NoClassDefFoundError: <DtoName>`。
**場景**：Draft 用 `package org.acme.transfer.api.dto;`，但 v3.0 Feature Overlay 下，`transfer-mock/pom.xml` 的 antrun 規則會把 DTO 拷貝到 `src/main/java/org/acme/transfer/api/features/dto/` 目錄——**目錄與套件宣告不一致**，Maven clean 時會清掉，執行期找不到 class。

```bash
curl -s -X POST http://127.0.0.1:8091/api/run \
  -H "Content-Type: application/json" \
  -d '{
    "script": "const draftRoot = path.join(workspaceRoot, args.draftDir || \"drafts/<feature-name>\"); const dtoDir = path.join(draftRoot, \"src/mocks/dto\"); if (!fs.existsSync(dtoDir)) return { success: true, skipped: true, message: \"無 mocks/dto 目錄，視為通過\" }; let fail = false; for (const f of fs.readdirSync(dtoDir).filter(x => x.endsWith(\".java\"))) { const fp = path.join(dtoDir, f); const pkg = fs.readFileSync(fp, \"utf8\").match(/^package\\s+([\\w.]+);/m)?.[1]; if (pkg && !pkg.includes(\".features.\")) { fail = true; console.log(`❌ FAIL: ${f} 套件 ${pkg} 與 features/ 同步目錄不一致`); helpers.addDiagnostic(fp, 1, 1, `DTO 套件 ${pkg} 與 transfer-mock antrun 同步目錄（features/dto/）不一致；應改為 org.acme.transfer.api.features.dto`, \"error\"); } } return { success: !fail };",
    "args": { "draftDir": "drafts/<feature-name>" }
  }'
```

不通過: 把 `mocks/dto/*.java` 的 `package` 從 `org.acme.transfer.api.dto` 改為 `org.acme.transfer.api.features.dto`，並同步更新 `mocks/*.java` 中的 import。

---

### 6.16 View SQL 欄位必須對齊 `workflow_execution_log` 實體 schema

**目的**：杜絕 `SQLITE_ERROR: no such column: sequence_number / updated_at / final_status / workflow_data`。
**場景**：Draft 用 `SELECT sequence_number, final_status FROM ...` 直接引用欄位，但 `workflow_execution_log` 實體只有 `business_key` / `status` / `message` / `input_data` (JSON) / `output_data` (JSON)；業務欄位須用 `json_extract(input_data, '$.xxx')` 拆出。

```bash
curl -s -X POST http://127.0.0.1:8091/api/run \
  -H "Content-Type: application/json" \
  -d '{
    "script": "const dir = path.join(workspaceRoot, args.draftDir || \"drafts/<feature-name>\"); const validCols = new Set([\"id\", \"created_at\", \"workflow_id\", \"business_key\", \"process_instance_id\", \"status\", \"message\", \"input_data\", \"output_data\", \"cancelled_by\", \"cancelled_at\"]); const forbidden = [\"sequence_number\", \"final_status\", \"workflow_data\", \"updated_at\", \"inputData\", \"outputData\"]; let fail = false; function scanDir(d) { if (!fs.existsSync(d)) return; for (const f of fs.readdirSync(d)) { const fp = path.join(d, f); if (fs.statSync(fp).isDirectory()) { scanDir(fp); continue; } if (!f.endsWith(\".sql\")) continue; const txt = fs.readFileSync(fp, \"utf8\"); for (const c of forbidden) { const re = new RegExp(`\\\\b${c}\\\\b`, \"i\"); if (re.test(txt) && /CREATE\\s+(OR\\s+REPLACE\\s+)?VIEW/i.test(txt)) { fail = true; console.log(`❌ FAIL: ${fp} 引用不存在欄位 \"${c}\"`); helpers.addDiagnostic(fp, 1, 1, `View SQL 引用不存在的實體欄位 \"${c}\"（應改用 json_extract(input_data, '$.xxx') 或 json_extract(output_data, '$.xxx')）`, \"error\"); } } } } scanDir(path.join(dir, \"src/db\")); scanDir(path.join(dir, \"db\")); return { success: !fail };",
    "args": { "draftDir": "drafts/<feature-name>" }
  }'
```

不通過: 將 View SQL 改寫為 `json_extract(input_data, '$.field')` / `json_extract(output_data, '$.field')` 模式，對齊 `V1.2.0` (omni-counter-repayment) 與 `V1.2.6` (remittance) 既定風格。

---

## Step 7: 自我檢查清單 (★ v2 設計期 SOP 核心)

設計完成後,逐項檢查:

| # | 檢查項 | 通過條件 |
|---|---|---|
| 7.1 | `docs/spec.md §0 假設清單` 含 FQCN 假設（含 H13a validator + H13b/H14 service） | ✅ 每個新 service/validator 都有 FQCN + 落地策略 |
| 7.2 | `docs/spec.md §0` 含 `id 命名決策` 標記（含檔名-id Manifest） | ✅ 明確寫出 snake_case + 檔名≠id 登記，或註明 v1.0 hotfix |
| 7.3 | `docs/spec.md §0` 含 `convention 決策` (status / finalStatus，Parent/Child/Saga 分流) | ✅ 標明 Parent 用舊 / 新 / 純 HTTP，Child 僅 finalStatus |
| 7.4 | OpenAPI spec 的 path param 與 workflow YAML 的 payload 對應 | ✅ 每個 `{xxx}` 都有對應 payload key |
| 7.5 | 直調 actionDataFilter 全部用頂層欄位 (非 .result.X；subFlowRef 豁免) | ✅ 直調 grep 不到 `.result.X` 配對 |
| 7.6 | stateDataFilter.output 對應選定的 convention 與層級，且 output key 皆有賦值 | ✅ Parent 舊:`status: STRING`；Parent 新:`status: 0/1` + `finalStatus`；Child:僅 `finalStatus`；output 每個 key 至少在一個 inject/operation 被賦值 |
| 7.7 | Mock sentinel 字串能通過 input validation（Mode A + validator FAIL_ 豁免優先） | ✅ 設計期實測；B 僅備選 |
| 7.8 | Mock package 命名（draft 佔位可，下游 rename 兜底；DTO 防 `.dto.dto`） | ✅ spec §8 註明 rename 映射或已對齊 |
| 7.9 | SQL migration V 編號遞增 | ✅ 從既有最大 +1 |
| 7.10 | YAML 沒有 trailing comma | ✅ grep 不到 `,$\|,$` 結尾的 list item |
| 7.11 | `src/config/application.properties.snippet` 含 status-rewrite 完整配置（含 %dev/%prod bean 與 baseUrl 註解） | ✅ workflows + mapping + bean 三者齊全 |
| 7.12 | 測試套件包含 happy path + 主要 error path（對齊 P1/A1/P4/B1/B2 五場） | ✅ 至少 5 個測試案例（P1 400/A1 SUCCESS/P4 REPLAY/B1 CANCELLED/B2 LOOKUP_FAILED），置於 `src/tests/` |
| 7.13 | 測試資料字串能通過 input validation | ✅ 每個測試 payload 都驗過 |
| 7.14 | `docs/spec.md §8 Project Mapping Manifest` 完整（含檔名-id、draft→project 雙模組路徑） | ✅ 每個 draft 檔案都有對應正式路徑 + 檔名-id 行 |
| 7.15 | `docs/spec.md §9` 已知限制有列 | ✅ v1.0 留白 / 簡化項目都明確標出 |
| 7.16 | Input Validation Regex 與 API Sample 相容 | ✅ 通路代碼/欄位正則相容真實範例（如 `2500P`） |
| 7.17 | 測試案例採用動態唯一序號 | ✅ 正向/反向用 `System.nanoTime()`，固定值僅 P1/B2 未入庫路徑 |
| 7.18 | jq 條件表達式 `tonumber` 防呆 + null guard | ✅ 用 `tonumber? //` 或 `startswith("FAIL_")` 守衛；所有讀 `.xxx.status` 的 condition 必須帶 `//` 預設值（如 `((.coreResult.status // "999")\|tostring)!="0"`） |
| 7.19 | Workflow Root 顯式定義 `start: <StateName>` | ✅ 避免 Kogito 拋出 `Workflow.getStart() is null` NPE（值可為 ValidateInput/ValidateChildInput/LookupOriginal/Call* 四類） |
| 7.20 | Service Function 參數鍵值精準對齊 Java Overload 簽名 | ✅ `workflowId` 與 `businessKey` 齊全，展開/Map/JsonNode 三入口，避免 ClassCastException |
| 7.21 | OpenAPI Spec `servers[0].url`（建議有，缺失可用 fallback，不 FAIL） | ✅ 有則填 `http://localhost:8080`；缺則在 §0 註明 fallback 鏈 |
| 7.22 | OpenAPI Spec 欄位約束與 Example/測試 Payload 嚴格相容 | ✅ `maxLength`/`minLength` 覆蓋 example 與真實序號，無內部衝突 |
| 7.23 | 直調 Operation State 若使用 results 必須顯式宣告 `toStateData`（subFlow/終端豁免） | ✅ 嚴防 State Data 沖刷覆蓋，保證下游欄位與審計完整 |
| 7.24 | 金融工作流程輸入驗證避免使用原生 `dataInputSchema`（Parent-Omni 型完整三件套，其餘分流見 1d） | ✅ 改採 `OpenApiSchemaValidator` 於流程內校驗，杜絕 Audit Gap 審計斷點 |
| 7.25 | Parent 對外入口置於 `draft/src/specs/internal/` 且含 `x-workflow-id`；host 置於 `draft/src/specs/external/` 且必無標籤；root 禁放業務 yaml | ✅ Vert.x 動態路由解析；external 零標籤 |
| 7.26 | subFlowRef version 對齊 child version | ✅ 如 omni parent 1.0.1 則 subFlow 亦 1.0.1，不可殘留 1.0 |
| 7.27 | `docs/design-explanation.md` 已產出且與 draft 一致（創建者導向，必產） | ✅ 9 節齊全 + 決策/假設/檔案地圖與實際產出一致，無虛構欄位 |
| 7.28 | onErrors 覆蓋 + ROLLBACK_FAILED 必告警（見 6.11） | ✅ `onErrors` 數 ≥ `operation` 數 −1（terminal 豁免 1 個）；有 `ROLLBACK_FAILED` 終態則必調用 `notifyOps` |
| 7.29 | 業務欄位禁止 literal 硬編碼，衍生欄位須含運算式 | ✅ `currency/BIC/country/address/fee/rate` 一律 `${ .field }`（僅允許 OUR/BEN/A/B/C/R）；`amountInUSD` 類必須含 `fxRate` 運算或 §0 假設註明 |
| 7.30 | Workflow `errors:` 區塊宣告與所有 `errorRef` 引用對齊（見 6.12） | ✅ grep 不到「`errorRef: X` 但 `errors:` 沒 X」配對 |
| 7.31 | Workflow 沒有 unreachable 狀態（見 6.13） | ✅ 每個 state 至少有一個 incoming transition（`start:` 或前驅的 `transition` / `dataConditions` / `defaultCondition` / `onErrors`） |
| 7.32 | `notifyOps` arguments 對齊 Java `OpsAlertService.raise` 6 參簽名（見 6.14） | ✅ 含 `workflowId` / `processInstanceId` / `businessKey` / `finalStatus` / `finalMessage` / `detail`；不可用 `inputData` / `outputData` |
| 7.33 | Mock DTO 套件命名對齊 `transfer-mock` 同步目錄 `features/dto/`（見 6.15） | ✅ `package org.acme.transfer.api.features.dto;`（**不可** `org.acme.transfer.api.dto`，會落入 Maven clean 後遺失） |
| 7.34 | View SQL 欄位對齊 `workflow_execution_log` 實體 schema（見 6.16） | ✅ 僅引用實體欄位（`business_key` / `status` / `message` / `input_data` / `output_data` / `cancelled_by` / `cancelled_at`）；業務欄位用 `json_extract(input_data, '$.field')` 拆出 |
| 7.35 | `docs/execution-trace-and-issue-report.md` 已產出且 9 節齊全（詳細執行軌跡與 P0-P3 問題報告，必產） | ✅ 9 節齊全 + 包含真實已執行命令與結果 + P0-P3 問題清單與風險矩陣完整，無虛構全綠 |
| 7.36 | 平台標準服務 FQCN 對齊 SSOT（見 4c） | ✅ `MyOpenApiService` / `OpenApiSchemaValidator` 用 `com.example.transfer.workflow`；`AuditLogService` / `IdempotencyService` / `OpsAlertService` 用 `com.example.reconciliation` |
| 7.37 | `findBySequenceNumber` 參數契約對齊 2 參 | ✅ 僅帶 `workflowId` 與 `businessKey`，嚴禁夾帶額外 `sequenceNumber` 參數引發 NoSuchMethodException |
| 7.38 | 逆向取消/沖正流程原交易查詢 `workflowId` 綁定 | ✅ 查原交易必須綁定被沖正的正向 workflowId，嚴禁誤設為取消流程自身的 workflowId |
| 7.39 | 階梯式 Switch 分離存在性與業務狀態檢查（見 1b.4） | ✅ `notFound` 獨立 Switch，`notCancellable` 獨立 Switch，杜絕 jBPM 條件無序分流錯亂 |
| 7.40 | 逆向測試採用 Arrange-Act 雙階段生命週期與動態序號 | ✅ 取消測試先 POST 正向交易成功再 POST 取消；序號一律 `System.nanoTime()` 避免冪等污染 |

---

## Step 8: 交付前最後一次檢查 (Feature Overlay 規範)

- [ ] 完整自主特徵目錄結構產出 (`docs/`, `workflows/`, `specs/internal/`, `specs/external/`, `mocks/`, `mocks/dto/`, `db/migration/`, `config/`, `tests/`)
- [ ] 必備 `feature.yaml` 特徵元資料（含 id, name, version, workflows[], owner）
- [ ] Agent Runner 存活檢查通過（`curl -s http://127.0.0.1:8091/api/health` 回應 `{"status":"online",...}`）
- [ ] 若有新增 View，Flyway 腳本在 `CREATE VIEW` 之前必須包含 `DROP VIEW IF EXISTS <view>;`，且特徵目錄必備 `db/teardown.sql` 抽離清理腳本（`DROP VIEW IF EXISTS vw_<name>_reconciliation;`）
- [ ] 測試套件（`tests/*.java`）package 明確宣告為 `com.example.platform.distribution.transfer.features;` 以達裝配隔離
- [ ] 17-22 個檔案 (依業務複雜度；02/03 最小可跑骨架至少 12 檔；含必產 `docs/design-explanation.md` 與 `docs/execution-trace-and-issue-report.md`)
- [ ] ⛔ 禁止產出 `schemas/*.json`（JSON 僅允許設計期草稿，禁止進 handoff 套件；SSOT 為 specs/ YAML 內 `components.schemas`，見 07）。由 `scripts/preflight-checks.js` 自動檢測，違者 FAIL。
- [ ] spec.md H1-H18 假設清單 + 11 個章節齊全（含檔名-id Manifest、validator 註冊、fallback 聲明）
- [ ] `docs/design-explanation.md` 已產出（創建者導向，見 Step 8b；必產，違者 FAIL）
- [ ] `docs/execution-trace-and-issue-report.md` 已產出（詳細執行軌跡與 P0-P3 問題報告，見 Step 8c；必產，違者 FAIL）
- [ ] **20 項平台相容性預檢 + 特徵外掛規範全綠**（由 `POST /api/run-file` 執行 `scripts/preflight-checks.js` 驗證）
- [ ] 自我檢查（7.1-7.40）全綠
- [ ] **套件必須置於工作區根目錄的 `drafts/<feature-name>/`**（v3.1 起強制；嚴禁直接寫入 `project/features/`）；移交 `sonataflow-integration` skill 進行整併

## Step 8b: 產出 design-explanation.md（★ v2.2 新增，必產）

`spec.md` 是給下游工程師看的技術規格；`design-explanation.md` 是給**創建者（業務/出資方）**看的設計說明，回答「為什麼這樣設計」。兩份缺一不可。

### 8b.1 落位與命名

- 落位：`drafts/<feature-name>/docs/design-explanation.md`（v3.1 起強制 `drafts/` 目錄；與 `docs/spec.md` 同層；進 handoff zip）。
- 範本：`references/06-design-explanation-template/design-explanation-template.md`。
- 語言：與創建者一致（本系列預設繁中），業務語言為主，技術術語首次出現加白話括號。

### 8b.2 強制 9 節結構（不可刪節，可加附錄）

| 節 | 標題 | 內容要求 |
|---|---|---|
| 0 | 導讀（3 分鐘版） | 5 點以內：業務要什麼 / 選了什麼模式 / 有幾個檔案 / 最易誤會的決策 / 還沒確定的事 |
| 1 | 背景與目標 | 痛點表 + draft 目標 + 不做什麼（對應業務書 In/Out-Scope） |
| 2 | 輸入來源 | 用了哪版業務書 + 哪幾份 host API（檔名+版本）+ Step 0 特徵自治架構對齊矩陣 |
| 3 | 從需求到設計 | 業務職責→state 對應表 + 模式選擇理由（為何是 A/B/C/D/E 其中之一）+ 回應 convention 決策 |
| 4 | 關鍵設計決策 | 至少 5 條，每條含「選了什麼 / 為什麼 / 沒選什麼 / 不這樣做的後果 / 在哪裡看到」 |
| 5 | 產出物地圖 | 全部檔案一句话分工 + 檔名-id 對應表 |
| 6 | 流程解說 | 正向/反向各走一遍 + 測試場景對應表（P1/A1/P4/B1/B2 或等價矩陣） |
| 7 | 假設與待確認 | H1-H18 精簡為業務語言，只列需人拍板的 |
| 8 | 驗證 + 限制 + 下一步 | 預檢/自查結果 + 已知限制 + 移交下游對照表 + 名詞解釋附錄 |

### 8b.3 一致性鐵律

- `design-explanation.md` 提到的每個 id / 檔名 / 欄位 / 狀態 / 數字，必須與實際產出一致（7.27 檢查）。禁止虛構範例值；範例值必須來自 notebooks YAML 的 `example` 或測試 payload。
- 決策條數不可少於 5 條，且必須覆蓋：id 命名、convention、驗證策略、sentinel、toStateData/version 任一。
- 寫完後跑：由 `scripts/preflight-checks.js` 自動驗證章節數 ≥ 9，再人工抽 3 個檔名/id/數字核對。

---

## Step 8c: 產出 execution-trace-and-issue-report.md（★ v3.3 新增，必產）

`spec.md` 是給下游工程師看的技術規格；`design-explanation.md` 是給創建者看的設計理由；`execution-trace-and-issue-report.md` 則是給**審查者、平台架構師與下游整合工程師**看的**詳細執行軌跡紀錄與問題報告**。它記錄設計過程的真實命令歷程、靜態分析結果、環境邊界與跨層契約識別出的所有潛在問題，確保技術交接透明可信。

### 8c.1 落位與命名

- 落位：`drafts/<feature-name>/docs/execution-trace-and-issue-report.md`（v3.1 起強制 `drafts/` 目錄；與 `docs/spec.md` 同層；進 handoff zip）。
- 範本：`references/07-execution-trace-template/execution-trace-and-issue-report-template.md`。
- 語言：與團隊一致（預設繁中），客觀嚴謹，依數據與代碼證據說話。

### 8c.2 強制 9 節結構（不可刪節，可加附錄）

| 節 | 標題 | 內容要求 |
|---|---|---|
| 1 | 執行摘要 | 已確認通過部分清單 + 尚未完成/待整合驗證部分清單 + 總體結論 |
| 2 | 需求與設計追溯 | 2.1 輸入需求來源表 + 2.2 產出設計表 (Parent/Child 職責) + 2.3 狀態設計分類 |
| 3 | 詳細執行軌跡 | 3.1 初始化與局部閱讀 + 3.2 Draft 建立順序 + 3.3 已執行命令與結果表 + 3.4 工具環境限制 |
| 4 | 問題清單與發現 | 依 P0/P1/P2/P3 嚴格分級，每題必備 6 要素（位置/現象/影響/根因/建議/驗證方式） |
| 5 | 風險矩陣 | 風險 ID、描述、等級 (高/中高/中/低)、目前狀態、建議 Owner |
| 6 | 交接前阻塞條件 | 阻斷交接的硬性檢驗門檻（未通過禁止宣稱可直接整併） |
| 7 | 建議執行順序 | 下一步修正、預檢、整併與測試的優先步序 |
| 8 | 驗收結論 | 明確標註階段結論標籤（如：Design draft complete / Static checks partially passed / Integration validation pending） |
| 9 | 關聯文件 | 本草稿內 README.md、spec.md、design-explanation.md、feature.yaml、workflows、OpenAPI 等連結 |

### 8c.3 品質鐵律與分級原則

- **嚴禁虛報全綠**：在未由 `sonataflow-integration` 掛載至專案並執行 Maven compile / Quarkus test / Kogito codegen 前，嚴禁宣稱「測試全過」或「E2E 全綠」；結論一律客觀標記為 `Integration validation pending`。
- **問題分級標準**：
  - `P0` (Blocker)：阻斷基本運行（語法錯誤、死迴圈、Kogito bug 必發）。
  - `P1` (Critical)：整併前應修正（path parameter 傳遞斷裂、告警範圍錯置、測試缺少 fixture 等）。
  - `P2` (Major)：測試、規格或 Mock 補強（preflight 待跑、未編譯、Mock DTO 未全對齊、長度約束衝突等）。
  - `P3` (Minor)：文件、未使用的 error 宣告、代碼整潔度改善。
- **寫完後跑**：由 `scripts/preflight-checks.js` 自動驗證章節數 ≥ 9，違者判定 FAIL 並標註紅線。

---

## 通用化考量 (跨領域)

### 適用領域

此 skill 不只限於「信用卡臨櫃現金繳款」,可應用於:

| 業務領域 | 範例 |
|---|---|
| 金融交易 | 信用卡現金繳款 (本次案例)、轉帳、匯款 |
| 電商訂單 | 下單 → 付款 → 出貨 → 退貨 |
| 保險理賠 | 申請 → 審核 → 撥款 |
| 物流配送 | 接單 → 揀貨 → 出貨 → 簽收 |
| 醫療掛號 | 預約 → 報到 → 看診 → 繳費 |

**共通特性** (這些領域都適用):
- 多階段業務流 (saga)
- 跨多個外部系統 (Core + CC 等)
- 需要對帳 (audit log)
- 需要 idempotency
- 需要 failure rollback

### 不適用場景

- 純 CRUD 應用 (無業務流)
- 純批次處理 (用 Airflow 而非 workflow engine)
- 純 event streaming (用 Kafka Streams)

---

## 與其他 skill 的關係

```
vibe-workflow-design-v3 (本 skill, 上游/Draft 階段)
  │
  │  強制產出至 drafts/<feature-name>/ (v3.1 起)
  │  (含 16-21 個檔案,符合 16 項預檢 + 34 項 self-check + H1-H18 + design-explanation)
  │  (含 17-22 個檔案,符合 16 項預檢 + 35 項 self-check + H1-H18 + design-explanation + execution-trace)
  │  (Java/配置模板與下游部分重複屬正常，每處重複皆標下游 Step 號)
  │
  ▼
sonataflow-integration (下游/Integration 階段)
  │
  │  把 drafts/<feature-name>/ 整併進 project-0825-pd (含 project/features/<feature-name>/)
  │  (10 步 SOP + 失敗模式速查：雙模組同步、rename、編譯測試、E2E 以下游為準)
  │
  ▼
最終產出:quarkus-run.jar + 通過 E2E smoke test
```

**本 skill 完成後,移交給 `sonataflow-integration` 即可預期整合階段工時 < 1 小時**(若上游預檢全綠)。

---

## 反模式 (不要這樣做)

- ❌ **不要產出 hyphen id + subflow 的 workflow** — 必觸發 Kogito 10.2.0 bug
- ❌ **不要在 actionDataFilter 用 `.result.X`** — 與 MyOpenApiService response 結構不符
- ❌ **不要忘了 path param** — 必在 payload 內顯式提供
- ❌ **不要設計 input validation regex 攔截 mock sentinel** — 預設用 Mode A + validator `FAIL_` 豁免 + `tonumber?` 守衛（B 僅備選）
- ❌ **不要強制 draft package 已對齊** — 佔位可，下游 `sonataflow-integration Step 5` 會 rename（DTO 注意兩階段替換）
- ❌ **不要用 trailing comma** — YAML 解析失敗
- ❌ **不要用未對齊 platform 的 convention** — 必觸發 status-rewrite 問題
- ❌ **不要省略 status-rewrite config snippet** — 下游必再摸索一次
- ❌ **不要省略 FQCN 假設清單** — 下游無法識別要新建/修改的 service
- ❌ **不要省略測試套件** — 整合後無法快速驗證
- ❌ **不要省略 design-explanation.md** — 創建者看不懂設計依據，驗收時必返工（v2.2 必產，見 Step 8b + 7.27）
- ❌ **不要省略 execution-trace-and-issue-report.md 或虛報「E2E全綠」** — 未經 Maven codegen / E2E 驗證前，必須誠實記錄執行軌跡與 P0-P3 潛在風險，結論標為 pending，否則下游整併必踩雷（v3.3 必產，見 Step 8c + 7.35）
- ❌ **不要宣告 errors 卻不寫 onErrors** — host 拋錯繞過 audit 成 Audit Gap（見 6.11 + 7.28）
- ❌ **不要有 ROLLBACK_FAILED 終態卻不調 notifyOps** — 補償失敗靜默結束（見 6.11 + 7.28）
- ❌ **不要硬編碼 BIC/country/address/fee** — 業務欄位一律 `${ .field }`，衍生欄位須含運算式（見 7.29）
- ❌ **不要在 `errors:` 區塊漏宣告 `platformError` 等通用 error** — 凡 `onErrors` 引用 `errorRef` 必須在 `errors:` 同步宣告（見 6.12 + 7.30）
- ❌ **不要留 unreachable / dead-code state** — 任何 state 都必須有 incoming transition（見 6.13 + 7.31）
- ❌ **不要把 `notifyOps` arguments 寫成 `inputData` / `outputData`** — `OpsAlertService.raise` 6 參簽名為 `workflowId` / `processInstanceId` / `businessKey` / `finalStatus` / `finalMessage` / `detail`（見 6.14 + 7.32）
- ❌ **不要讓 Mock DTO 套件脫離 `features/dto/` 同步目錄** — 必須 `package org.acme.transfer.api.features.dto;`（見 6.15 + 7.33）
- ❌ **不要在 View SQL 直接 SELECT 不存在的實體欄位** — `sequence_number` / `final_status` / `workflow_data` / `updated_at` 等皆不存在；改用 `json_extract(input_data, '$.xxx')`（見 6.16 + 7.34）

---

## 輸出物結構 (drafts/<feature-name>/，v3.1 起強制)

> ⛔ **v3.1 鐵律**：本 skill 產出必須落在工作區根目錄 `drafts/<feature-name>/`；不得直接寫入 `project/features/`（那是 `sonataflow-integration` skill 整併後的目標）。若發現既有產出位於 `project/features/`，請先 `mv` 至 `drafts/` 再繼續。

```
drafts/<feature-name>/
├── feature.yaml                               # ★ 特徵元資料 (id, name, version, workflows[], owner)
├── docs/                                      # 設計期文件（handoff zip 必含）
│   ├── README.md                              # draft 入口說明（業務摘要 + 引用文件）
│   ├── design-explanation.md                  # ★ 創建者導向設計說明（9 節，見 Step 8b）
│   ├── execution-trace-and-issue-report.md    # ★ 詳細執行軌跡紀錄與問題報告（9 節，見 Step 8c）
│   └── spec.md                                # 規格書 (H1-H18 假設 + 11 章節，含檔名-id Manifest)
├── workflows/                                 # 工作流定義 (snake_case id；.sw.yaml)
│   ├── <workflow-parent>.sw.yaml              # Parent workflow (subFlowRef version 須等於 child version)
│   ├── <workflow-child-A>.sw.yaml             # Child A（End 僅 finalStatus）
│   └── <workflow-child-B>.sw.yaml             # Child B
├── specs/                                     # OpenAPI specs
│   ├── internal/                              # Parent 對外入口 (必含 x-workflow-id，validator+router 唯一 SSOT)
│   │   └── <entry-api>.yaml
│   └── external/                              # 被調 host 規格 (必無 x-workflow-id；schemaRef='specs/external/<host>.yaml#op')
│       ├── <host-api-1>-api.yaml
│       └── <host-api-2>-api.yaml
├── mocks/                                     # JAX-RS mock（Mode A 前綴為主，dev 模式動態掛載）
│   ├── <Resource1>.java
│   ├── <Resource2>.java
│   └── dto/                                   # DTO 群 (共享 DTO 如 ErrorDetail 排除)
│       ├── <Resource1>Request.java
│       ├── <Resource1>Response.java
│       └── <Resource1>Result.java
├── db/                                        # 資料庫遷移與回滾
│   ├── migration/
│   │   └── V<X>.<Y>.<Z>__<desc>.sql           # Flyway DDL (從既有最大 +1；View IN 用 snake_case)
│   └── teardown.sql                           # ★ 特徵抽離清理腳本 (DROP VIEW IF EXISTS ...)
├── config/
│   └── application.properties.snippet         # 平台組態備忘（平台已支援 status-rewrite 萬用字元，免手動合入）
└── tests/
    └── <WorkflowTest>.java                    # @QuarkusTest，★ package 必須為 com.example.platform.distribution.transfer.features;
```

⛔ 禁止產出 `schemas/*.json`（JSON 僅允許設計期草稿，禁止進 handoff zip；SSOT 為 specs/ YAML 內 `components.schemas`，見 07）。由 `scripts/preflight-checks.js` 自動檢測，違者 FAIL。

---

## 版本演進

| 版本 | 重點 |
|---|---|
| v1.0 | 基礎 draft 產出 (notebooks/spec/mocks/tests) |
| v1.1 | 加入 H1-H14 假設清單 + spec.md 11 章節 |
| v2.0 | 加入 6 項平台相容性預檢 + 15 項自我檢查 + 9 項可上移守則 + 3 個 examples + 5 個 reference 模組 |
| v2.1 | 統一 9 項預檢 + 25+1 項自查 + H1-H18 + 8 目錄；放寬 toStateData/servers/x-workflow-id/Validate 三件套為 Parent/Child/Saga 分流；新增 version 對齊 + 檔名-id Manifest + validator 註冊 + 雙軌 results + P1/A1/P4/B1/B2 測試矩陣；02/03 補為最小可跑骨架；D/E 標實驗性 |
| v2.2 | 新增必產 `design-explanation.md`（創建者導向 9 節，Step 8b + 7.27 + 06 模板）；檔案數改為 16-21；其餘沿用 v2.1 |
| v2.3 | 新增 6.11 onErrors+notifyOps 預檢 + 7.28/7.29；擴充 7.6（output key 必有賦值）+ 7.18（status 判斷必帶 `//`）；新增 `10-onerrors-and-opsalert.md`（源自 remittance_swift 審查） |
| v2.4 | 目錄結構重整：`notebooks/` → `src/specs/{internal,external}/`；`spec/*.sw.yaml` → `src/*.sw.yaml`；`spec/{config,db,mocks,tests}/` → `src/{config,db,mocks,tests}/`；`spec.md` 與 `design-explanation.md` 與 `README.md` 統一移至 `docs/`；廢止 `spec/schemas/*.json`（SSOT 為 `src/specs/ YAML` 內 `components.schemas`）；6.x 預檢與 7.x 自查路徑全數更新；其餘沿用 v2.3 |
| **v2.5** (本版) | **新增整合期補強 5 項預檢（6.12-6.16）+ 自查 5 項（7.30-7.34）**：源自 2026-09 實戰整合 `omni_cash_transaction` 時暴露的 5 個隱性問題——①`errors:` 區塊漏宣告 errorRef ② unreachable dead-code state ③ `notifyOps` arguments 命名錯置（`inputData`/`outputData` 而非 6 參展開簽名）④ Mock DTO 套件與 `features/dto/` 同步目錄不一致 ⑤ View SQL 直接 SELECT 不存在的實體欄位（`sequence_number`/`final_status`/`workflow_data`/`updated_at`）。預檢總數 10 → 16 項；自查總數 29 → 34 項。其餘沿用 v2.4 |
| **v3.1** | **強制輸出目錄**：本 skill 所有產出必須置於工作區根目錄 `drafts/<feature-name>/`；廢止 `draft-<name>/` 與 `project/features/<feature-name>/` 雙軌寫法（後者為 `sonataflow-integration` 的整合目標）。同步更新 SKILL 描述、Step 8、Step 8b、套件關係與預檢預設 `draftDir=drafts/<feature-name>` |
| **v3.2** | **Step 0 自治架構升級 (慣例優先)**：全面相容「模組單一目錄自治與熱插拔抽離架構 (Feature Overlay Autonomous Plugin)」，將原本阻斷式的「Step 0: 前置調研 (5 個必問)」升級為「前置探測與自治架構對齊」。將平台、落點 (`drafts/<feature-name>/`)、Mock DTO 套件 (`features/dto`)、Flyway 探測固化為非阻塞標準慣例，免除反覆逼問使用者架構常數，實現零摩擦直進 Step 1。 |
| v2.5 | 新增整合期補強 5 項預檢（6.12-6.16）+ 自查 5 項（7.30-7.34）：源自 2026-09 實戰整合 `omni_cash_transaction` 時暴露的 5 個隱性問題——①`errors:` 區塊漏宣告 errorRef ② unreachable dead-code state ③ `notifyOps` arguments 命名錯置 ④ Mock DTO 套件與 `features/dto/` 同步目錄不一致 ⑤ View SQL 直接 SELECT 不存在的實體欄位。預檢總數 10 → 16 項；自查總數 29 → 34 項。其餘沿用 v2.4 |
| v3.1 | **強制輸出目錄**：本 skill 所有產出必須置於工作區根目錄 `drafts/<feature-name>/`；廢止 `draft-<name>/` 與 `project/features/<feature-name>/` 雙軌寫法（後者為 `sonataflow-integration` 的整合目標）。同步更新 SKILL 描述、Step 8、Step 8b、套件關係與預檢預設 `draftDir=drafts/<feature-name>` |
| v3.2 | **Step 0 自治架構升級 (慣例優先)**：全面相容「模組單一目錄自治與熱插拔抽離架構 (Feature Overlay Autonomous Plugin)」，將原本阻斷式的「Step 0: 前置調研 (5 個必問)」升級為「前置探測與自治架構對齊」。將平台、落點 (`drafts/<feature-name>/`)、Mock DTO 套件 (`features/dto`)、Flyway 探測固化為非阻塞標準慣例，免除反覆逼問使用者架構常數，實現零摩擦直進 Step 1。 |
| v3.0 | 全方位整合 SonataFlow Agent Dynamic Script Runner（單一通訊埠 8091）：所有平台檢查與 Flyway 探測改寫為跨平台 Node.js API，支援一鍵全量預檢腳本 `scripts/preflight-checks.js`，深度整合 VS Code 問題面板自動紅線標記，徹底擺脫 Bash / Python CLI 環境相容問題 |
| **v3.3** (本版) | **新增必產 execution-trace-and-issue-report.md（詳細執行軌跡紀錄與問題報告）**：記錄完整指令歷程、已執行結果、環境限制、P0-P3 結構化問題清單、風險矩陣、交接阻塞條件與客觀驗收結論（杜絕虛報全綠）。同步新增 Step 8c、Reference 07 模板、自查 7.35 與 Node.js 全自動預檢 `Step8c-execution-trace-report-sections`。檔案數調整為 17-22 個。 |

---

## 對應 reference / example 速查

設計中遇到下列問題,直接翻對應 reference:

| 問題 | 翻哪個 reference | 對應 example |
|---|---|---|
| workflow id 怎麼命名才不會觸發 Kogito bug? | `references/01-platform-checks/01-workflow-id-naming.md`（含 9 處改名連動 + 檔名-id Manifest） | 全部 examples |
| actionDataFilter 怎麼寫才對（含雙軌 + 豁免）? | `references/01-platform-checks/02-action-data-filter.md` + `08-tostatedata-scope.md` | 全部 workflow YAML |
| path param 怎麼注入? | `references/01-platform-checks/03-path-parameter-injection.md` | 全部 workflow YAML |
| stateDataFilter 該用哪種 convention（Parent/Child/Saga 分流）? | `references/01-platform-checks/04-state-data-filter-convention.md` | 01-financial, 03-insurance |
| YAML 語法有什麼陷阱? | `references/01-platform-checks/05-yaml-strictness.md` | 全部 |
| mock sentinel 怎麼設計才不違反 input validation（A 為主 + validator 豁免）? | `references/01-platform-checks/06-mock-sentinel-vs-input-validation.md` | 01-financial |
| spec example 與 maxLength 怎麼對齊? | `references/01-platform-checks/07-spec-example-consistency.md` | 02/03 notebooks YAML components |
| toStateData 何時可免? | `references/01-platform-checks/08-tostatedata-scope.md` | 全部 workflow YAML |
| x-workflow-id/servers 何時必填? | `references/01-platform-checks/09-xworkflowid-and-servers.md` | 01 internal |
| operation 有宣告 errors 卻無 onErrors / ROLLBACK_FAILED 無告警怎麼辦? | `references/01-platform-checks/10-onerrors-and-opsalert.md` | remittance_swift 審查案例 |
| 設計完成後怎麼驗證? | `references/02-self-check/self-check-list.md` | 對所有 examples 套用 |
| workflow YAML 結構該長怎樣? | `references/03-templates/workflow-yaml-templates.md` | 全部 examples |
| application.properties 該加什麼? | `references/04-config-snippets/application-properties-snippet.md` | 01-financial, 03-insurance |
| docs/spec.md §0 假設清單怎麼寫? | `references/05-fqcn-template/spec-assumption-template.md` | 01-financial/docs/spec.md |
| design-explanation.md 怎麼寫（創建者看得懂）? | `references/06-design-explanation-template/design-explanation-template.md`（9 節強制結構 + 一致性鐵律） | 本次 `design-explanation.md` 實例 |
| execution-trace-and-issue-report.md 怎麼寫（執行軌跡與問題報告）? | `references/07-execution-trace-template/execution-trace-and-issue-report-template.md`（9 節強制結構 + P0-P3 分級與六要素規範） | 本次 `drafts/omni-cash-transaction/docs/execution-trace-and-issue-report.md` 實例 |

---

## 對應 example 速查

| 業務情境 | 用哪個 example | 為何 |
|---|---|---|
| 金融交易 (繳款/轉帳/匯款) | `examples/01-financial-repayment/` | 真實案例,最完整 |
| 電商 (下單/出貨/退貨) | `examples/02-ecommerce-order/` | Mode A 最小可跑骨架,3 階段 LIFO |
| 保險/金融審批 (理賠/核保) | `examples/03-insurance-claim/` | Mode B 跨領域最小可跑骨架,結構相同但語意不同 |
| 物流配送 | 參考 `02-ecommerce-order` Mode A 改寫 | — |
| 醫療掛號 | 參考 `01-financial-repayment` Mode B 改寫 | — |
| 純 CRUD 應用 | ❌ 不適用 | 改用一般 API 設計 |
| 純批次處理 | ❌ 不適用 | 改用 Airflow skill |
