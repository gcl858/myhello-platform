/**
 * SonataFlow Workflow Design Preflight Checks (v3.2 / 20 項相容性門禁)
 * 
 * 執行環境：SonataFlow Agent Dynamic Script Runner (Node.js)
 * 健康檢查：GET http://127.0.0.1:8091/api/health
 * 調用端點：POST http://127.0.0.1:8091/api/run-file 或 POST /api/run
 * 
 * 功能：
 * 1. 執行 20 項平台相容性預檢（含 v3.2 新增 17-20 整合期防護 4 項）
 * 2. 探測 Flyway 最大版本號
 * 3. 檢查交付目錄規範（禁止 schemas/*.json、驗證 design-explanation.md 9 節結構、驗證 execution-trace-and-issue-report.md 9 節結構）
 * 4. 檢測不通過時自動調用 helpers.addDiagnostic 在 VS Code 問題面板標註紅線
 * 
 * v3.2 變更：新增 17-20 整合期防護 4 項預檢
 *   - 17-platform-services-fqcn-alignment: 檢測標準共用服務 Package 是否對齊 SSOT
 *   - 18-findbysequencenumber-signature: 檢測 findBySequenceNumber 2 參數契約
 *   - 19-cancellation-workflowid-cross-reference: 檢測逆向流程查原交易是否誤填自身 workflowId
 *   - 20-subflow-onerrors-coverage: 檢測 subFlowRef 呼叫狀態是否覆蓋 onErrors
 * 
 * 貫徹「門禁左移」精神，將整併期遇到的 Codegen 與拓撲錯誤於設計期一併擋下。
 */

async function runPreflightChecks() {
  const logs = [];
  const log = (msg) => { logs.push(msg); console.log(msg); };
  
  // 1. 解析目標路徑
  const targetDir = args && args.draftDir 
    ? (path.isAbsolute(args.draftDir) ? args.draftDir : path.join(workspaceRoot, args.draftDir))
    : workspaceRoot;

  const results = {
    targetDir,
    timestamp: new Date().toISOString(),
    totalChecks: 0,
    passedChecks: 0,
    failedChecks: 0,
    failures: [],
    flyway: null
  };

  log(`🚀 開始執行 SonataFlow Workflow 設計期相容性預檢 (v3.0)`);
  log(`📂 目標目錄: ${targetDir}`);

  // 輔助函式：遞迴搜尋檔案
  function findFiles(dir, extFilter, nameFilter) {
    let list = [];
    if (!fs.existsSync(dir)) return list;
    const entries = fs.readdirSync(dir, { withFileTypes: true });
    for (const entry of entries) {
      const fullPath = path.join(dir, entry.name);
      if (entry.isDirectory()) {
        list = list.concat(findFiles(fullPath, extFilter, nameFilter));
      } else if (entry.isFile()) {
        if (extFilter && !entry.name.endsWith(extFilter)) continue;
        if (nameFilter && !entry.name.includes(nameFilter)) continue;
        list.push(fullPath);
      }
    }
    return list;
  }

  function recordCheck(name, pass, failureMsg, filePath, line = 1, col = 1) {
    results.totalChecks++;
    if (pass) {
      results.passedChecks++;
      log(`  ✅ PASS: ${name}`);
      if (filePath && helpers.clearDiagnostics) {
        helpers.clearDiagnostics(filePath);
      }
    } else {
      results.failedChecks++;
      const detail = `[${name}] ${failureMsg} (${filePath || '整體檢驗'})`;
      results.failures.push(detail);
      log(`  ❌ FAIL: ${detail}`);
      if (filePath && helpers.addDiagnostic) {
        helpers.addDiagnostic(filePath, line, col, `[${name}] ${failureMsg}`, 'error');
      }
    }
  }

  // 搜尋工作流程 YAML 檔 (包含 src/*.sw.yaml 或 root *.sw.yaml)
  const swFiles = findFiles(targetDir, '.sw.yaml');
  const workflows = [];
  for (const f of swFiles) {
    try {
      const content = fs.readFileSync(f, 'utf8');
      const parsed = helpers.parseYaml(content);
      workflows.push({ filePath: f, content, parsed });
    } catch (e) {
      recordCheck('YAML Parsing', false, `無法解析 YAML: ${e.message}`, f, 1, 1);
    }
  }

  log(`\n🔍 發現 ${workflows.length} 個 Workflow 檔案: ${workflows.map(w => path.basename(w.filePath)).join(', ')}`);

  // =========================================================================
  // 檢查 01: Workflow ID 命名 (Kogito 10.2.0 bug 規避)
  // =========================================================================
  for (const wf of workflows) {
    const hasSubFlow = wf.content.includes('subFlowRef');
    const id = wf.parsed.id || '';
    if (hasSubFlow) {
      if (id.includes('-')) {
        recordCheck('01-workflow-id-naming', false, `Workflow id '${id}' 含有連字號 (hyphen)，含 subFlowRef 時會引發 Kogito 10.2.0 codegen bug，必須改為 snake_case`, wf.filePath);
      } else {
        recordCheck('01-workflow-id-naming', true, null, wf.filePath);
      }
    } else {
      recordCheck('01-workflow-id-naming (單層豁免)', true, null, wf.filePath);
    }
  }

  // =========================================================================
  // 檢查 02: actionDataFilter 頂層欄位存取 (禁 .result.X)
  // =========================================================================
  for (const wf of workflows) {
    let hasResultWrapper = false;
    const states = wf.parsed.states || [];
    for (const state of states) {
      if (state.type === 'operation' && state.actions) {
        for (const act of state.actions) {
          if (act.functionRef && act.actionDataFilter && act.actionDataFilter.results) {
            const resStr = String(act.actionDataFilter.results);
            if (/\.result\.[a-zA-Z_]+/.test(resStr)) {
              hasResultWrapper = true;
              recordCheck('02-action-data-filter', false, `actionDataFilter.results 誤用了 '.result.X' 封裝 (MyOpenApiService 回傳為頂層欄位): ${resStr}`, wf.filePath);
            }
          }
        }
      }
    }
    if (!hasResultWrapper) {
      recordCheck('02-action-data-filter', true, null, wf.filePath);
    }
  }

  // =========================================================================
  // 檢查 03: Path Parameter 自動注入檢驗
  // =========================================================================
  const specFiles = findFiles(targetDir, '.yaml').filter(f => f.includes('/specs/'));
  const specsMap = new Map();
  for (const sf of specFiles) {
    try {
      specsMap.set(path.basename(sf), helpers.parseYaml(fs.readFileSync(sf, 'utf8')));
    } catch (_) {}
  }

  for (const wf of workflows) {
    const states = wf.parsed.states || [];
    let pathParamFail = false;
    for (const state of states) {
      if (state.type === 'operation' && state.actions) {
        for (const act of state.actions) {
          const fnRef = act.functionRef;
          if (fnRef && fnRef.arguments && fnRef.arguments.schemaRef) {
            const schemaRef = String(fnRef.arguments.schemaRef);
            const [specFileRel, opId] = schemaRef.split('#');
            const specFileName = path.basename(specFileRel);
            const spec = specsMap.get(specFileName);
            if (spec && opId) {
              // 找尋對應 operation 的 path parameters
              const requiredPathParams = [];
              for (const [pUrl, pMethods] of Object.entries(spec.paths || {})) {
                for (const [m, op] of Object.entries(pMethods || {})) {
                  if (op && op.operationId === opId && Array.isArray(op.parameters)) {
                    for (const param of op.parameters) {
                      if (param.in === 'path' && param.name) {
                        requiredPathParams.push(param.name);
                      }
                    }
                  }
                }
              }
              const payload = fnRef.arguments.payload || {};
              for (const pName of requiredPathParams) {
                if (!(pName in payload)) {
                  pathParamFail = true;
                  recordCheck('03-path-parameter-injection', false, `Operation '${opId}' 缺少 URL Path Parameter: '${pName}'，必須在 payload 顯式提供`, wf.filePath);
                }
              }
            }
          }
        }
      }
    }
    if (!pathParamFail) {
      recordCheck('03-path-parameter-injection', true, null, wf.filePath);
    }
  }

  // =========================================================================
  // 檢查 04: stateDataFilter.output Convention
  // =========================================================================
  for (const wf of workflows) {
    const states = wf.parsed.states || [];
    const isParent = wf.content.includes('subFlowRef');
    let conventionPass = true;
    for (const state of states) {
      if (state.stateDataFilter && state.stateDataFilter.output) {
        const outStr = String(state.stateDataFilter.output);
        if (isParent) {
          // Parent 新 Convention 應包含 status (0/1) 與 finalStatus
          if (!outStr.includes('finalStatus') || !/status:\s*\(?if/m.test(outStr)) {
            conventionPass = false;
            recordCheck('04-state-data-filter-convention', false, `Parent workflow stateDataFilter.output 必須同時包含 status: (int 0/1) 與 finalStatus 雙軌欄位`, wf.filePath);
          }
        }
      }
    }
    if (conventionPass) {
      recordCheck('04-state-data-filter-convention', true, null, wf.filePath);
    }
  }

  // =========================================================================
  // 檢查 05: YAML 語法嚴格性 (trailing comma)
  // =========================================================================
  for (const wf of workflows) {
    const lines = wf.content.split('\n');
    let commaFail = false;
    let inBlockScalar = false;
    let blockScalarIndent = 0;
    for (let i = 0; i < lines.length; i++) {
      const line = lines[i];
      const indent = line.search(/\S/);
      
      if (inBlockScalar) {
        if (indent !== -1 && indent <= blockScalarIndent) {
          inBlockScalar = false;
        } else {
          continue; // 處於多行區塊字串中（如 output: |），略過逗號檢測
        }
      }

      if (/:\s*[|>][-+]?\s*$/.test(line)) {
        inBlockScalar = true;
        blockScalarIndent = indent >= 0 ? indent : 0;
        continue;
      }

      if (/^\s+\w+:\s+'[^']*',\s*$/.test(line) || /^\s+\w+:\s+"[^"]*",\s*$/.test(line) || /^\s+-\s+\w+:\s+[^,\n]+,\s*$/.test(line)) {
        commaFail = true;
        recordCheck('05-yaml-strictness', false, `第 ${i + 1} 行發現尾端多餘逗號 (trailing comma): "${line.trim()}"`, wf.filePath, i + 1, 1);
      }
    }
    if (!commaFail) {
      recordCheck('05-yaml-strictness', true, null, wf.filePath);
    }
  }

  // =========================================================================
  // 檢查 06: Mock Sentinel vs Input Validation 相容性
  // =========================================================================
  const mockFiles = findFiles(path.join(targetDir, 'src/mocks'), '.java');
  const sentinels = new Set();
  for (const mf of mockFiles) {
    const text = fs.readFileSync(mf, 'utf8');
    const matches = text.match(/"(FAIL_[A-Za-z0-9_]+|RBFAIL|[0-9]{10})"/g);
    if (matches) {
      matches.forEach(m => sentinels.add(m.replace(/"/g, '')));
    }
  }
  log(`  ℹ️  從 Mock Java 發現哨兵值: ${Array.from(sentinels).join(', ') || '無'}`);
  recordCheck('06-mock-sentinel-check', true, null);

  // =========================================================================
  // 檢查 07: Spec Schema 與 Example 一致性預檢
  // =========================================================================
  for (const [sName, spec] of specsMap.entries()) {
    let exampleFail = false;
    function walkProps(props, prefix) {
      if (!props) return;
      for (const [pName, pVal] of Object.entries(props)) {
        if (pVal && typeof pVal === 'object') {
          const ex = pVal.example;
          const maxL = pVal.maxLength;
          const minL = pVal.minLength;
          if (typeof ex === 'string') {
            if (maxL !== undefined && ex.length > maxL) {
              exampleFail = true;
              recordCheck('07-spec-example-consistency', false, `欄位 ${prefix}${pName} example "${ex}" 長度 (${ex.length}) 大於 maxLength (${maxL})`, sName);
            }
            if (minL !== undefined && ex.length < minL) {
              exampleFail = true;
              recordCheck('07-spec-example-consistency', false, `欄位 ${prefix}${pName} example "${ex}" 長度 (${ex.length}) 小於 minLength (${minL})`, sName);
            }
          }
        }
      }
    }
    for (const [_, ops] of Object.entries(spec.paths || {})) {
      for (const [_, op] of Object.entries(ops || {})) {
        if (op && op.requestBody && op.requestBody.content) {
          const jsonSchema = op.requestBody.content['application/json']?.schema;
          if (jsonSchema && jsonSchema.properties) walkProps(jsonSchema.properties, 'reqBody.');
        }
      }
    }
    for (const [schName, sch] of Object.entries(spec.components?.schemas || {})) {
      if (sch && sch.properties) walkProps(sch.properties, `${schName}.`);
    }
    if (!exampleFail) {
      recordCheck(`07-spec-example-consistency (${sName})`, true, null);
    }
  }

  // =========================================================================
  // 檢查 08: 直調 functionRef 遺漏 toStateData 檢查
  // =========================================================================
  for (const wf of workflows) {
    const states = wf.parsed.states || [];
    let toStateDataFail = false;
    for (const state of states) {
      if (state.type === 'operation' && Array.isArray(state.actions)) {
        for (const act of state.actions) {
          // 直調 functionRef 具備 results 但缺少 toStateData (豁免 subFlowRef 與 terminal recordAuditLog)
          if (act.functionRef && act.actionDataFilter && act.actionDataFilter.results) {
            const isSubFlow = Boolean(act.subFlowRef);
            const isTerminalAudit = act.functionRef.refName === 'recordAuditLog';
            if (!isSubFlow && !isTerminalAudit && !act.actionDataFilter.toStateData) {
              toStateDataFail = true;
              recordCheck('08-tostatedata-scope', false, `狀態 '${state.name}' 的直調 actionDataFilter 缺少 toStateData，會導致流程既有資料遭整份覆寫！`, wf.filePath);
            }
          }
        }
      }
    }
    if (!toStateDataFail) {
      recordCheck('08-tostatedata-scope', true, null, wf.filePath);
    }
  }

  // =========================================================================
  // 檢查 09: OpenAPI internal/external 目錄與 x-workflow-id 標籤二分
  // =========================================================================
  const internalSpecs = findFiles(path.join(targetDir, 'src/specs/internal'), '.yaml');
  const externalSpecs = findFiles(path.join(targetDir, 'src/specs/external'), '.yaml');
  const rootSpecs = findFiles(path.join(targetDir, 'src/specs'), '.yaml')
    .filter(f => !f.includes('/internal/') && !f.includes('/external/') && !path.basename(f).includes('openapi.yaml'));

  for (const f of internalSpecs) {
    const parsed = helpers.parseYaml(fs.readFileSync(f, 'utf8'));
    let hasXWfId = false;
    for (const [_, ops] of Object.entries(parsed.paths || {})) {
      if (ops.post && ops.post['x-workflow-id']) hasXWfId = true;
    }
    recordCheck('09-internal-x-workflow-id', hasXWfId, `Parent 對外入口 ${path.basename(f)} 缺少 x-workflow-id 標籤供動態路由註冊`, f);
  }

  for (const f of externalSpecs) {
    const text = fs.readFileSync(f, 'utf8');
    const hasForbidden = text.includes('x-workflow-id');
    recordCheck('09-external-no-x-workflow-id', !hasForbidden, `External host spec ${path.basename(f)} 禁止含有 x-workflow-id`, f);
  }

  for (const f of rootSpecs) {
    recordCheck('09-root-specs-prohibition', false, `root src/specs/${path.basename(f)} 違規落放，請依角色搬入 internal/ 或 external/`, f);
  }

  // =========================================================================
  // 檢查 6.10: subFlowRef version 對齊檢查
  // =========================================================================
  const wfMap = new Map();
  workflows.forEach(w => wfMap.set(w.parsed.id, w.parsed));
  for (const wf of workflows) {
    const states = wf.parsed.states || [];
    for (const state of states) {
      if (state.type === 'operation' && state.actions) {
        for (const act of state.actions) {
          if (act.subFlowRef) {
            const childId = act.subFlowRef.workflowId;
            const refVer = act.subFlowRef.version;
            const childWf = wfMap.get(childId);
            if (childWf && childWf.version && childWf.version !== refVer) {
              recordCheck('6.10-subflow-version-alignment', false, `Parent subFlowRef '${childId}' version '${refVer}' 與子流程定義 '${childWf.version}' 不對齊`, wf.filePath);
            } else {
              recordCheck('6.10-subflow-version-alignment', true, null, wf.filePath);
            }
          }
        }
      }
    }
  }

  // =========================================================================
  // 檢查 10: onErrors 覆蓋率 + notifyOps 告警 (Audit Gap 防線)
  // =========================================================================
  for (const wf of workflows) {
    const states = wf.parsed.states || [];
    const ops = states.filter(s => s.type === 'operation');
    const errs = states.filter(s => s.onErrors && s.onErrors.length > 0);
    // 允許 terminal audit state 豁免 1 個
    if (ops.length > 1 && errs.length < (ops.length - 1)) {
      recordCheck('10-onerrors-coverage', false, `operation states 數量為 ${ops.length} 但 onErrors 僅宣告 ${errs.length} 處（未覆蓋 host 例外審計）`, wf.filePath);
    } else {
      recordCheck('10-onerrors-coverage', true, null, wf.filePath);
    }

    if (wf.content.includes('ROLLBACK_FAILED')) {
      const hasNotify = wf.content.includes('refName: notifyOps') || wf.content.includes('refName: "notifyOps"');
      recordCheck('10-notifyops-alert', hasNotify, `流程包含 ROLLBACK_FAILED 終態，但未在補償失敗時調用 notifyOps 告警`, wf.filePath);
    }
  }

  // =========================================================================
  // 檢查 11: Workflow `errors:` 宣告與 `errorRef` 引用對齊 (v2.5 / 6.12)
  // 觸發場景：RollbackCore.onErrors 引用 errorRef: platformError，但 errors: 區塊只宣告 CoreFailed/CreditCardFailed，漏宣告 platformError
  // 失敗症狀：Kogito codegen 拋 'Cannot find any error definition for errorRef X'
  // =========================================================================
  for (const wf of workflows) {
    const declaredErrs = new Set((wf.parsed.errors || []).map(e => e.name));
    const refs = [...wf.content.matchAll(/errorRef:\s*[\x27"]?([a-zA-Z0-9_]+)/g)].map(m => m[1]);
    const uniqueRefs = [...new Set(refs)];
    let errAlignFail = false;
    for (const r of uniqueRefs) {
      if (!declaredErrs.has(r)) {
        errAlignFail = true;
        recordCheck('11-workflow-errors-alignment', false, `Workflow 引用 errorRef '${r}' 但 errors: 區塊未宣告（Kogito codegen 將拋 Cannot find any error definition）`, wf.filePath);
      }
    }
    if (!errAlignFail) {
      recordCheck('11-workflow-errors-alignment', true, null, wf.filePath);
    }
  }

  // =========================================================================
  // 檢查 12: Workflow 沒有 unreachable 狀態 (dead code) (v2.5 / 6.13)
  // 觸發場景：從舊版 child 複製了 FinalizeCancelRejected 注入狀態，但新設計下沒有任何 transition 指向它
  // 失敗症狀：jBPM 'Node X has no incoming connection / Has no connection to the start node'
  // =========================================================================
  for (const wf of workflows) {
    const states = wf.parsed.states || [];
    const incoming = new Set();
    const start = wf.parsed.start;
    if (start) incoming.add(start);
    for (const s of states) {
      const targets = [s.transition, ...(s.dataConditions || []).map(d => d.transition), ...(s.defaultCondition ? [s.defaultCondition.transition] : []), ...(s.onErrors || []).map(e => e.transition)];
      for (const t of targets) if (t) incoming.add(t);
    }
    let unreachableFail = false;
    for (const s of states) {
      if (!incoming.has(s.name)) {
        unreachableFail = true;
        recordCheck('12-no-unreachable-state', false, `狀態 '${s.name}' 沒有任何 incoming transition，是 dead code（移除或補上 transition）`, wf.filePath);
      }
    }
    if (!unreachableFail) {
      recordCheck('12-no-unreachable-state', true, null, wf.filePath);
    }
  }

  // =========================================================================
  // 檢查 13: notifyOps arguments 必須對齊 Java OpsAlertService 6 參簽名 (v2.5 / 6.14)
  // 觸發場景：誤把 AuditLogService.saveLog 的命名 (inputData/outputData) 套到 notifyOps
  // 失敗症狀：NoSuchMethodException: OpsAlertService.raise with proper arguments [String, Object, Object, Map, Map]
  // =========================================================================
  for (const wf of workflows) {
    const states = wf.parsed.states || [];
    const required = ['workflowId', 'processInstanceId', 'businessKey', 'finalStatus', 'finalMessage', 'detail'];
    const forbidden = ['inputData', 'outputData'];
    let notifyArgsFail = false;
    for (const state of states) {
      for (const act of (state.actions || [])) {
        if (act.functionRef && act.functionRef.refName === 'notifyOps') {
          const args = act.functionRef.arguments || {};
          for (const k of required) {
            if (!(k in args)) {
              notifyArgsFail = true;
              recordCheck('13-notifyops-6-args-signature', false, `狀態 '${state.name}' notifyOps 缺少必要參數 '${k}'（對齊 OpsAlertService.raise 6 參簽名）`, wf.filePath);
            }
          }
          for (const k of forbidden) {
            if (k in args) {
              notifyArgsFail = true;
              recordCheck('13-notifyops-6-args-signature', false, `狀態 '${state.name}' notifyOps 使用了錯誤參數 '${k}'（應改為 finalStatus/finalMessage/detail）`, wf.filePath);
            }
          }
        }
      }
    }
    if (!notifyArgsFail) {
      recordCheck('13-notifyops-6-args-signature', true, null, wf.filePath);
    }
  }

  // =========================================================================
  // 檢查 14: Mock DTO 套件命名對齊 transfer-mock antrun 同步目錄 (v2.5 / 6.15)
  // 觸發場景：Draft 用 package org.acme.transfer.api.dto，但 antrun 會把 DTO 拷貝到 features/dto/ 目錄
  // 失敗症狀：執行期 java.lang.NoClassDefFoundError
  // =========================================================================
  const dtoDir = path.join(targetDir, 'src/mocks/dto');
  if (fs.existsSync(dtoDir)) {
    const dtoFiles = findFiles(dtoDir, '.java');
    let dtoFail = false;
    for (const df of dtoFiles) {
      const pkg = fs.readFileSync(df, 'utf8').match(/^package\s+([\w.]+);/m)?.[1];
      if (pkg && !pkg.includes('.features.')) {
        dtoFail = true;
        recordCheck('14-mock-dto-package-alignment', false, `DTO 套件 ${pkg} 與 transfer-mock antrun 同步目錄（features/dto/）不一致；應改為 org.acme.transfer.api.features.dto`, df);
      }
    }
    if (!dtoFail) {
      recordCheck('14-mock-dto-package-alignment', true, null, dtoDir);
    }
  } else {
    recordCheck('14-mock-dto-package-alignment', true, null, null, 1, 1);
    log(`  ℹ️  [14] 無 src/mocks/dto 目錄，視為通過`);
  }

  // =========================================================================
  // 檢查 15: View SQL 欄位必須對齊 workflow_execution_log 實體 schema (v2.5 / 6.16)
  // 觸發場景：View SQL 直接 SELECT 不存在的實體欄位 (sequence_number / updated_at / final_status / workflow_data)
  // 失敗症狀：SQLITE_ERROR no such column
  // 注意：須排除以下場景避免誤判
  //   - SQL 註解 (-- xxx 或 /* xxx */)
  //   - 別名宣告 (json_extract(...) AS <forbidden>)
  //   - INDEX 名稱 (CREATE INDEX ... <forbidden>)
  // =========================================================================
  const forbiddenCols = ['sequence_number', 'final_status', 'workflow_data', 'updated_at', 'inputData', 'outputData'];
  const viewSqlFiles = findFiles(targetDir, '.sql').filter(f => /CREATE\s+(OR\s+REPLACE\s+)?VIEW/i.test(fs.readFileSync(f, 'utf8')));
  let sqlColFail = false;
  for (const vf of viewSqlFiles) {
    let txt = fs.readFileSync(vf, 'utf8');
    // 移除 SQL 行註解 (-- 至行尾)
    txt = txt.replace(/--[^\n]*/g, '');
    // 移除 SQL 區塊註解 (/* ... */)
    txt = txt.replace(/\/\*[\s\S]*?\*\//g, '');
    // 移除 CREATE VIEW ... AS 標頭（其本身含 "AS"，會誤觸 AS 分割）
    // 支援 CREATE VIEW、CREATE OR REPLACE VIEW、CREATE VIEW IF NOT EXISTS
    txt = txt.replace(/CREATE\s+(OR\s+REPLACE\s+)?VIEW\s+(IF\s+NOT\s+EXISTS\s+)?\S+\s+AS/i, '');
    // 只檢查 AS 之前的 SELECT/FROM/WHERE 區塊（忽略別名）
    const selectClause = txt.split(/\s+AS\s+/i)[0];

    for (const col of forbiddenCols) {
      const re = new RegExp(`\\b${col}\\b`, 'i');
      if (re.test(selectClause)) {
        sqlColFail = true;
        recordCheck('15-view-sql-column-alignment', false, `View SQL 直接引用不存在的實體欄位 '${col}'（AS 別名之前的 SELECT 區塊；應改用 json_extract(input_data, '$.xxx') 或 json_extract(output_data, '$.xxx')）`, vf);
      }
    }
  }
  if (viewSqlFiles.length === 0) {
    recordCheck('15-view-sql-column-alignment', true, null, null, 1, 1);
    log(`  ℹ️  [15] 無 View SQL 檔案，視為通過`);
  } else if (!sqlColFail) {
    recordCheck('15-view-sql-column-alignment', true, null, viewSqlFiles[0]);
  }

  // =========================================================================
  // 檢查 17: 平台標準共用服務 FQCN 對齊 SSOT (v3.2)
  // 觸發場景：Workflow functions 誤用 platform.security 或 platform.distribution.transfer 等舊 package
  // 失敗症狀：Kogito codegen 拋 Invalid work item: class not found for interfaceName
  // =========================================================================
  const canonicalServices = [
    { className: 'MyOpenApiService', expected: 'com.example.transfer.workflow.MyOpenApiService' },
    { className: 'OpenApiSchemaValidator', expected: 'com.example.transfer.workflow.OpenApiSchemaValidator' },
    { className: 'AuditLogService', expected: 'com.example.reconciliation.AuditLogService' },
    { className: 'IdempotencyService', expected: 'com.example.reconciliation.IdempotencyService' },
    { className: 'OpsAlertService', expected: 'com.example.reconciliation.OpsAlertService' }
  ];

  for (const wf of workflows) {
    let fqcnFail = false;
    for (const fn of (wf.parsed.functions || [])) {
      const op = String(fn.operation || '');
      if (op.startsWith('service:')) {
        const fullClassMethod = op.replace(/^service:/, '');
        const classNamePart = fullClassMethod.split('::')[0];
        for (const s of canonicalServices) {
          if (classNamePart.endsWith(s.className) && classNamePart !== s.expected) {
            fqcnFail = true;
            recordCheck('17-platform-services-fqcn-alignment', false, `服務 '${fn.name}' 使用了錯誤的 Package: '${classNamePart}'，平台 SSOT 標準 FQCN 應為 '${s.expected}'`, wf.filePath);
          }
        }
      }
    }
    if (!fqcnFail) {
      recordCheck('17-platform-services-fqcn-alignment', true, null, wf.filePath);
    }
  }

  // =========================================================================
  // 檢查 18: findBySequenceNumber 簽名契約對齊 (v3.2)
  // 觸發場景：Workflow 調用 findBySequenceNumber 時傳入 3 個參數 (含 sequenceNumber)
  // 失敗症狀：NoSuchMethodException with proper arguments [String, Object, Object]
  // =========================================================================
  for (const wf of workflows) {
    const fnMap = new Map();
    (wf.parsed.functions || []).forEach(f => fnMap.set(f.name, f.operation || ''));
    let sigFail = false;
    const states = wf.parsed.states || [];
    for (const s of states) {
      if (s.type === 'operation' && Array.isArray(s.actions)) {
        for (const act of s.actions) {
          if (act.functionRef) {
            const refName = act.functionRef.refName;
            const op = fnMap.get(refName) || '';
            if (op.includes('findBySequenceNumber')) {
              const args = act.functionRef.arguments || {};
              if (args.sequenceNumber && args.businessKey) {
                sigFail = true;
                recordCheck('18-findbysequencenumber-signature', false, `狀態 '${s.name}' 調用 findBySequenceNumber 時同時傳遞了 businessKey 與冗餘的 sequenceNumber（僅接受 workflowId, businessKey 2 參數契約）`, wf.filePath);
              }
            }
          }
        }
      }
    }
    if (!sigFail) {
      recordCheck('18-findbysequencenumber-signature', true, null, wf.filePath);
    }
  }

  // =========================================================================
  // 檢查 19: 逆向流程跨工作流關聯檢查 (v3.2)
  // 觸發場景：取消/沖銷/退款流程調用 findBySequenceNumber 或 markCancelledBy 誤傳自身 workflowId
  // 失敗症狀：原交易查詢永遠為 found: false (因為對帳記錄是由正向流程寫入)
  // =========================================================================
  for (const wf of workflows) {
    const wfId = wf.parsed.id || '';
    const isReverseWf = /cancel|rollback|reversal|refund/i.test(wfId) || /cancel|rollback|reversal|refund/i.test(wf.content);
    if (isReverseWf) {
      let crossFail = false;
      const states = wf.parsed.states || [];
      for (const s of states) {
        if (s.type === 'operation' && Array.isArray(s.actions)) {
          for (const act of s.actions) {
            if (act.functionRef && act.functionRef.arguments) {
              const argWfId = act.functionRef.arguments.workflowId;
              const refName = act.functionRef.refName;
              if ((refName.includes('lookup') || refName.includes('mark') || refName.includes('Original')) && argWfId === wfId) {
                crossFail = true;
                recordCheck('19-cancellation-workflowid-cross-reference', false, `逆向流程 '${wfId}' 於狀態 '${s.name}' 調用 ${refName} 時 workflowId 誤填自身 id，必須填入被沖正之正向流程 id`, wf.filePath);
              }
            }
          }
        }
      }
      if (!crossFail) {
        recordCheck('19-cancellation-workflowid-cross-reference', true, null, wf.filePath);
      }
    } else {
      recordCheck('19-cancellation-workflowid-cross-reference (非逆向流程豁免)', true, null, wf.filePath);
    }
  }

  // =========================================================================
  // 檢查 20: Subflow 調用節點 onErrors 覆蓋 (v3.2)
  // 觸發場景：Parent 狀態機中 InvokeChildSubflow 節點漏宣告 onErrors
  // 失敗症狀：子流程拋出非受檢例外或引擎失敗時缺乏 Audit 降級節點，引發 Audit Gap
  // =========================================================================
  for (const wf of workflows) {
    let subflowErrFail = false;
    const states = wf.parsed.states || [];
    for (const s of states) {
      if (s.type === 'operation' && Array.isArray(s.actions)) {
        for (const act of s.actions) {
          if (act.subFlowRef) {
            if (!s.onErrors || s.onErrors.length === 0) {
              subflowErrFail = true;
              recordCheck('20-subflow-onerrors-coverage', false, `狀態 '${s.name}' 調用 subFlowRef '${act.subFlowRef.workflowId}' 缺少 onErrors 宣告，子流程異常中斷時無法安全落地審計`, wf.filePath);
            }
          }
        }
      }
    }
    if (!subflowErrFail) {
      recordCheck('20-subflow-onerrors-coverage', true, null, wf.filePath);
    }
  }

  // =========================================================================
  // 額外檢查: 禁止 schemas/*.json (SSOT 規範)
  // =========================================================================
  const forbiddenJsons = findFiles(targetDir, '.json').filter(f => f.includes('/schemas/'));
  recordCheck('Step8-prohibit-schemas-json', forbiddenJsons.length === 0, `發現違法殘留的 schemas/*.json (${forbiddenJsons.map(f => path.basename(f)).join(', ')})，OpenAPI YAML 即為 SSOT`, forbiddenJsons[0]);

  // =========================================================================
  // 額外檢查: docs/design-explanation.md 結構
  // =========================================================================
  const explanationFile = path.join(targetDir, 'docs/design-explanation.md');
  if (fs.existsSync(explanationFile)) {
    const expText = fs.readFileSync(explanationFile, 'utf8');
    const sectionCount = (expText.match(/^##\s+/gm) || []).length;
    recordCheck('Step8b-design-explanation-sections', sectionCount >= 9, `design-explanation.md 二級章節數為 ${sectionCount} (規範要求 9 節必須齊全)`, explanationFile);
  } else {
    recordCheck('Step8b-design-explanation-sections', false, `缺少 docs/design-explanation.md 設計說明書檔案（規範要求必產）`, targetDir);
  }

  // =========================================================================
  // 額外檢查: docs/execution-trace-and-issue-report.md 結構
  // =========================================================================
  const traceReportFile = path.join(targetDir, 'docs/execution-trace-and-issue-report.md');
  if (fs.existsSync(traceReportFile)) {
    const trText = fs.readFileSync(traceReportFile, 'utf8');
    const sectionCount = (trText.match(/^##\s+/gm) || []).length;
    recordCheck('Step8c-execution-trace-report-sections', sectionCount >= 9, `execution-trace-and-issue-report.md 二級章節數為 ${sectionCount} (規範要求 9 節必須齊全)`, traceReportFile);
  } else {
    recordCheck('Step8c-execution-trace-report-sections', false, `缺少 docs/execution-trace-and-issue-report.md 執行軌跡紀錄與問題報告檔案（規範要求必產）`, targetDir);
  }

  // =========================================================================
  // 特徵外掛規範檢查 (Feature Overlay Autonomous Pattern)
  // =========================================================================
  // 1. feature.yaml 元資料宣告
  const featureYamlFile = path.join(targetDir, 'feature.yaml');
  if (fs.existsSync(featureYamlFile)) {
    try {
      const featContent = fs.readFileSync(featureYamlFile, 'utf8');
      const featParsed = helpers.parseYaml(featContent);
      const hasReqKeys = featParsed && featParsed.id && featParsed.name && featParsed.version && Array.isArray(featParsed.workflows);
      recordCheck('Feature-metadata-yaml', hasReqKeys, `feature.yaml 缺少必要欄位 (id, name, version, workflows[])`, featureYamlFile);
    } catch (e) {
      recordCheck('Feature-metadata-yaml', false, `無法解析 feature.yaml: ${e.message}`, featureYamlFile);
    }
  } else {
    recordCheck('Feature-metadata-yaml', false, `缺少 feature.yaml 特徵元資料檔案，無法進行零侵入自主裝配`, targetDir);
  }

  // 2. db/teardown.sql 乾淨抽離清理腳本
  const sqlFiles = findFiles(targetDir, '.sql').filter(f => !f.endsWith('teardown.sql'));
  const hasViewCreation = sqlFiles.some(f => /CREATE\s+(?:OR\s+REPLACE\s+)?VIEW/i.test(fs.readFileSync(f, 'utf8')));
  if (hasViewCreation) {
    const teardownPath = path.join(targetDir, 'db/teardown.sql');
    const hasTeardown = fs.existsSync(teardownPath);
    if (hasTeardown) {
      const tdContent = fs.readFileSync(teardownPath, 'utf8');
      const hasDropView = /DROP\s+VIEW\s+IF\s+EXISTS/i.test(tdContent);
      recordCheck('Feature-teardown-sql', hasDropView, `db/teardown.sql 必須包含 'DROP VIEW IF EXISTS' 回滾指令`, teardownPath);
    } else {
      recordCheck('Feature-teardown-sql', false, `特徵包含 CREATE VIEW 遷移，但未提供 db/teardown.sql 抽離清理腳本`, targetDir);
    }

    // 2b. Flyway migration SQL 中的 View 必須在 CREATE 之前加 DROP VIEW IF EXISTS <view>;
    for (const sf of sqlFiles) {
      const sContent = fs.readFileSync(sf, 'utf8');
      const createViewRegex = /CREATE\s+(?:OR\s+REPLACE\s+)?VIEW\s+(?:IF\s+NOT\s+EXISTS\s+)?([`"']?([a-zA-Z0-9_]+)[`"']?)/gi;
      let match;
      while ((match = createViewRegex.exec(sContent)) !== null) {
        const viewName = match[2];
        const createIndex = match.index;
        const precedingSql = sContent.slice(0, createIndex);
        const dropRegex = new RegExp(`DROP\\s+VIEW\\s+(?:IF\\s+EXISTS\\s+)?[\`"']?${viewName}[\`"']?\\s*;`, 'i');
        const hasDropBefore = dropRegex.test(precedingSql);
        recordCheck(
          'Feature-view-drop-before-create',
          hasDropBefore,
          `Flyway 腳本 ${path.basename(sf)} 建立視圖 '${viewName}' 之前必須先包含 'DROP VIEW IF EXISTS ${viewName};'（確保 SQLite 視圖更新可生效）`,
          sf
        );
      }
    }
  }

  // 3. 測試套件 package 命名空間隔離 (package com.example.platform.distribution.transfer.features;)
  const testFiles = findFiles(targetDir, '.java').filter(f => f.includes('Test.java') || f.includes('/tests/'));
  for (const tf of testFiles) {
    const tContent = fs.readFileSync(tf, 'utf8');
    const isFeaturePkg = /package\s+com\.example\.platform\.distribution\.transfer\.features\s*;/.test(tContent);
    recordCheck('Feature-test-package', isFeaturePkg, `測試類別 package 必須為 'com.example.platform.distribution.transfer.features;' 以確保裝配隔離`, tf);
  }

  // =========================================================================
  // Flyway 最大版本自動探測 (若有指定 targetProject)
  // =========================================================================
  const projectToScan = args && args.targetProject 
    ? (path.isAbsolute(args.targetProject) ? args.targetProject : path.join(workspaceRoot, args.targetProject))
    : targetDir;
  
  const migrationFiles = findFiles(projectToScan, '.sql').filter(f => f.includes('/db/migration/') || f.includes('/db/'));
  let maxMajor = 1, maxMinor = 0, maxPatch = 0, latestStr = null;
  for (const mf of migrationFiles) {
    const base = path.basename(mf);
    const m = base.match(/^V(\d+)(?:\.(\d+))?(?:\.(\d+))?__/);
    if (m) {
      const maj = parseInt(m[1], 10) || 0;
      const min = parseInt(m[2] || '0', 10);
      const pat = parseInt(m[3] || '0', 10);
      if (maj > maxMajor || (maj === maxMajor && min > maxMinor) || (maj === maxMajor && min === maxMinor && pat >= maxPatch)) {
        maxMajor = maj; maxMinor = min; maxPatch = pat;
        latestStr = `V${maj}.${min}.${pat}`;
      }
    }
  }
  const nextVer = latestStr ? `V${maxMajor}.${maxMinor}.${maxPatch + 1}` : 'V1.0.0';
  results.flyway = { latest: latestStr, nextSuggested: nextVer };
  log(`\n📦 Flyway 掃描結果: 目前最大版本: ${latestStr || '無'}，新 Draft 建議版本: ${nextVer}`);

  log(`\n=============================================================`);
  log(`📊 檢驗總結: 共 ${results.totalChecks} 項檢查 | 通過: ${results.passedChecks} | 失敗: ${results.failedChecks}`);
  log(`=============================================================`);

  return results;
}

// 頂層直接執行並回傳
return await runPreflightChecks();
