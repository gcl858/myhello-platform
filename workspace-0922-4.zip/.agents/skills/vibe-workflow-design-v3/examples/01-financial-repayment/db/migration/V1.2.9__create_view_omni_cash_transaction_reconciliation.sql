DROP VIEW IF EXISTS vw_omni_cash_transaction_reconciliation;
CREATE VIEW IF NOT EXISTS vw_omni_cash_transaction_reconciliation AS
SELECT
    id,
    created_at,
    workflow_id,
    business_key,
    process_instance_id,
    status,
    message,
    json_extract(input_data, '$.partyId') AS party_id,
    json_extract(input_data, '$.branchCode') AS branch_code,
    json_extract(input_data, '$.operationType') AS operation_type,
    json_extract(input_data, '$.amount') AS amount,
    json_extract(input_data, '$.sequenceNumber') AS sequence_number,
    json_extract(input_data, '$.originalSequenceNumber') AS original_sequence_number,
    json_extract(output_data, '$.finalStatus') AS final_status,
    json_extract(output_data, '$.coreResult') AS core_result,
    json_extract(output_data, '$.creditCardResult') AS credit_card_result
FROM workflow_execution_log
WHERE workflow_id IN ('omni_cash_transaction', 'repayment_cash_deposit', 'repayment_cash_cancellation');
