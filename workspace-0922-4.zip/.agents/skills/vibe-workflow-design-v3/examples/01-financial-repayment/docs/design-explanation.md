# 信用卡臨櫃現金繳款設計說明

## 0. 導讀（3 分鐘版）

1. 業務要一個入口，同時支援正向繳款與當日取消。
2. 採 Parent `omni_cash_transaction` 加兩個 Child：`repayment_cash_deposit`、`repayment_cash_cancellation`。
3. Draft 共 19 個檔案，包含 workflow、內外 OpenAPI、mock、View、測試與組態。
4. 最容易誤會的決策是：冪等檢查與 operation dispatcher 分成兩個 state，避免重放被業務分支攔截。
5. 尚待拍板的是主機正式序號長度，以及 timeout 後查詢 API。

## 1. 背景與目標

現況由櫃員操作信用卡主機，現金未同步核心帳務，也缺少統一取消與補償軌跡。本 draft 的目標是讓一筆請求可被驗證、分流、記錄並在第二階段失敗時執行 LIFO 補償。

本版不處理跨日退款、外幣、非臨櫃通路與 timeout 查詢 host。

## 2. 輸入來源

- `credit-card-counter-cash-repayment-requirement.md` v2.2：Parent/Child、狀態、補償與資料規則。
- `OmniRepaymentAPI.md` v1.0：唯一對外入口與 11 欄位。
- `CoreAccountCashDepositAPI.md` v1.0：核心帳務 host。
- `ExecuteCreditCardRepaymentAPI.md` v1.0：信用卡 host。

自治對齊：平台為 SonataFlow/Kogito 10.2.0，落點為 `drafts/omni-cash-transaction/`，OpenAPI 分 internal/external，migration 接續 V1.2.8 為 V1.2.9，DTO 使用 `org.acme.transfer.api.features.dto`。

## 3. 從需求到設計

| 業務職責 | 實作 state |
|---|---|
| 驗證入口 | `ValidateInput` → `CheckValidationResult` |
| 冪等 | `CheckIdempotency` → `CheckIdempotencyResult` |
| A/B 分流 | `DispatchOperation` |
| 正向兩階段 | Child A `CallCoreForward` → `CallCreditCardForward` |
| 正向補償 | Child A `RollbackCore` |
| 取消查原交易 | Child B `LookupOriginal` → `CheckOriginal` |
| 取消兩階段 | Child B `CancelCore` → `CancelCreditCard` |
| 統一稽核 | Parent/Child `recordAuditLog` |

選 Mode B 是因為 A 與 B 的前置條件、主機動作及補償順序不同，但都需要 Parent 統一入口與回應。

回應採新 convention：成功為 `status=0`，失敗為 `status=1`，並永遠保留 `finalStatus`。

## 4. 關鍵設計決策

1. **snake_case workflow id**：避開 Kogito 10.2.0 subflow codegen 對 hyphen id 的問題；實際 mapping 在 spec §8。
2. **OpenAPI 驗證放 workflow 內**：不用 `dataInputSchema`，讓驗證失敗仍能進 AuditLog。
3. **冪等與分流拆開**：先判斷 replay，再判斷 A/B，避免 switch 條件順序搶走 replay。
4. **直調保留 state data**：所有 host/service action 的 results 都指定 `toStateData`，避免輸入欄位被覆蓋。
5. **補償失敗才告警**：`ROLLBACK_FAILED` 與 `CANCEL_ROLLBACK_FAILED` 經 `NotifyRollbackFailure` 呼叫 6 參數 OpsAlertService。
6. **View 只讀實體欄位**：業務欄位由 `json_extract(input_data/output_data)` 取得，避免引用不存在的 `final_status` 或 `updated_at` 實體欄位。

## 5. 產出物地圖

- `feature.yaml`：生命週期與 workflow manifest。
- `docs/spec.md`：H1-H18、契約、限制與 Project Mapping。
- `workflows/*.sw.yaml`：Parent、正向 Child、取消 Child。
- `specs/internal/omni-counter-repayment-api.yaml`：唯一對外入口。
- `specs/external/*.yaml`：兩個 host 的 operation 與 path parameter。
- `mocks/*.java` 與 `mocks/dto/*.java`：dev profile mock。
- `db/migration/V1.2.9__...sql`、`db/teardown.sql`：對帳 View 與撤除。
- `config/application.properties.snippet`：status rewrite、bean 與 host fallback。
- `tests/OmniCashTransactionWorkflowTest.java`：五個核心情境。

## 6. 流程解說

正向 A：入口驗證 → 冪等 → Child A 核心入帳 → 信用卡還款 → 成功；信用卡失敗則 Core rollback，回 `ROLLED_BACK` 或 `ROLLBACK_FAILED`。

反向 B：入口驗證 → 冪等 → Child B 查原交易；非 SUCCESS 或已取消回 `CANCEL_REJECTED`；通過後 Core 沖正 → CreditCard 沖銷 → 標記原交易。第二階段失敗會回滾第一階段。

| 案例 | 預期 |
|---|---|
| P1 | operationType 不合法，400 / REJECTED_VALIDATION |
| A1 | Core + CreditCard 成功，200 / SUCCESS |
| P4 | 相同序號重送，200 / IDEMPOTENT_REPLAY |
| B1 | 原交易 SUCCESS 且取消成功，200 / CANCELLED |
| B2 | 查不到原交易，500 / LOOKUP_FAILED |

## 7. 假設與待確認

業務需要拍板：主機序號正式長度（文件有 13 碼描述但範例為 20 碼）、`creditcardid` 是否就是 `partyId`、timeout 查詢 operation、取消原因是否加入入口 request。這些已分別記在 spec 的 H5-H7、H16、H18。

## 8. 驗證、限制與下一步

已在 draft 內加入：snake_case id、subflow version 對齊、path payload、頂層 host response、toStateData、errorRef 宣告、6 參數 notifyOps、features DTO package、View JSON extraction 與 teardown。

下一步交給 `sonataflow-integration`：執行 preflight、將 internal spec 雙模組同步、掛載 mock/DTO、補 service implementation、執行隔離測試與 E2E。

### 名詞

- Parent：統一入口、驗證、冪等、分流與回應的 workflow。
- Child：實際呼叫 host 並負責局部補償的 workflow。
- LIFO：後完成的階段先反向補償。
- finalStatus：給業務與 status-rewrite 使用的終態字串。
