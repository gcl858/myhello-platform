# Omni Cash Transaction 整併執行軌跡與問題報告

- 報告日期：2026-09-22
- Draft 來源：`drafts/omni-cash-transaction/`
- 整合目標 Feature：`project/features/omni-cash-transaction/`
- 平台：SonataFlow / Kogito 10.2.0 / Quarkus 3.27.2 / Java 21
- 設計模式：Mode B，Parent + 2 Child Subflow
- 整併規範：`sonataflow-integration` skill v3.0（Feature Overlay 自治）
- 性質：**整合期**執行軌跡與問題報告（與 `drafts/omni-cash-transaction/docs/execution-trace-and-issue-report.md` 設計期紀錄對偶）
- 最終結論：**90 tests, 0 failures, 0 errors, BUILD SUCCESS**（transfer-app 全 reactor）

---

## 1. 執行摘要

依 `sonataflow-integration` v3.0 規範把 draft 整併至 `project/features/omni-cash-transaction/`，全程只動 feature 目錄與 draft 本身，平台核心模組零修改。

| 階段 | 結果 |
|---|---|
| Step 0 環境檢查 | Java 21、Maven 3.8.7、Agent Runner 8091 已啟動（`curl http://127.0.0.1:8091/api/health` 回應 online） |
| Step 1 draft 結構分析 | 3 workflow + 2 spec + 3 mock + 3 DTO + 1 SQL + 1 test + docs/snippet/teardown，符合自治目錄規範 |
| Step 1.5A.0 上游預檢（preflight-checks.js） | 45/46 PASS，1 FAIL（parent subflow `onErrors` 未覆蓋） |
| Step 1.5A.0 上游預檢（修補後） | **46/46 PASS** |
| Step 2 掛載 | `cp -r drafts/omni-cash-transaction project/features/omni-cash-transaction`，零主模組侵入 |
| Step 3-7 workflow / Java / 組態調整 | 3 個 draft workflow 共 4 處 service FQCN / 2 處 argument 簽名 / 1 處 subflow 例外導流修正 |
| Step 5d mock 覆蓋 | CoreCashDepositResource / CreditCardRepaymentResource 已含 Execute/Rollback，覆蓋正反向 |
| Step 8 測試整合 | 動態裝配至 `distribution/transfer-app/src/test/java/...features/`，無需手動複製 |
| Step 9 Maven 驗證 | 經 5 輪 iterative codegen 修正，最終 `mvn -B test -pl distribution/transfer-app -am` → **BUILD SUCCESS** |

---

## 2. 整合前 Baseline 偵察

### 2.1 平台動態裝配確認（重要）

`project/distribution/transfer-app/pom.xml` 與 `project/dev/transfer-mock/pom.xml` 已內建 Maven Antrun 於 `initialize` 階段自動探測 `features/*` 並同步：

| 來源 | 同步目標 |
|---|---|
| `features/*/workflows/*.sw.yaml` | `distribution/transfer-app/target/generated-resources` |
| `features/*/specs/internal/` | 同上 `/specs/internal/` |
| `features/*/specs/external/` | 同上 `/specs/external/` |
| `features/*/db/migration/*.sql` | `target/generated-resources/db/migration/` |
| `features/*/tests/*.java` | `distribution/transfer-app/src/test/java/.../features/`（`.gitignore`） |
| `features/*/services/*.java` | `distribution/transfer-app/src/main/java/.../features/`（`.gitignore`） |
| `features/*/mocks/*.java` | `dev/transfer-mock/src/main/java/org/acme/transfer/api/features/`（`.gitignore`） |

`transfer-mock` 與 `transfer-app` 在 `initialize` 階段另有 `clean-plugin` 清空動態掛載目錄（除 `application.properties` 與 `META-INF/`），確保抽離時零殘留。

### 2.2 既有 Java 服務簽名比對

依 Step 1.5 Gate 3 精神，逐一比對 draft workflow 宣告的 FQCN 與現有實作：

| draft 宣告 | 既有實作 | 一致？ |
|---|---|---|
| `com.example.platform.security.OpenApiSchemaValidator::validate` | `com.example.transfer.workflow.OpenApiSchemaValidator` | ❌ Package 錯 |
| `com.example.platform.security.MyOpenApiService::callOpenApi` | `com.example.transfer.workflow.MyOpenApiService` | ❌ Package 錯 |
| `com.example.platform.distribution.transfer.IdempotencyService::findBySequenceNumber` | `com.example.reconciliation.IdempotencyService` | ❌ Package 錯 |
| `com.example.reconciliation.AuditLogService::findBySequenceNumber` | `com.example.reconciliation.AuditLogService`，簽名 `(String workflowId, Object businessKey)` | ⚠️ draft 額外傳 `sequenceNumber` 3 參數 |
| `com.example.reconciliation.AuditLogService::saveLog` | 既有 5 參 canonical `(String, Object, Object, Object, Object)` | ✅ 一致 |
| `com.example.reconciliation.AuditLogService::markCancelledBy` | 既有 `(String, Object, Object, Object)` | ✅ 一致 |
| `com.example.reconciliation.OpsAlertService::raise` | 既有 6 參 canonical `(String, Object, Object, Object, Object, Map)` | ✅ 一致 |

### 2.3 Flyway 雙軌探測

| 來源 | 最高版本 |
|---|---|
| 檔案系統 `domain-reconciliation/.../db/migration/` | `V1.1.0` |
| 實體 DB `data/reconciliation.db` `reconciliation_schema_history` | `V1.2.8` |
| **安全基線（下一版）** | **V1.2.9** |
| draft 採用版本 | `V1.2.9`（與既有 migration_runner 雙軌探測結果一致） |

---

## 3. 預檢執行紀錄

### 3.1 上游 46 項設計期預檢（preflight-checks.js）

```
POST http://127.0.0.1:8091/api/run-file
  args: { draftDir: "drafts/omni-cash-transaction" }

首次：passed 45 / failed 1
  ❌ [10-onerrors-coverage] operation states 數量為 5 但 onErrors 僅宣告 3 處
      file: workflows/omni-cash-transaction.sw.yaml
```

**修正**：為 parent 的 `InvokeDepositSubflow` 與 `InvokeCancellationSubflow` 兩個 subflow operation 加上 `onErrors` → `InjectWorkflowFailedStatus`，新增 `InjectWorkflowFailedStatus` inject 節點 `finalStatus: FAILED / status: 1`。

```
重跑：passed 46 / failed 0
📦 Flyway 掃描結果: 目前最大版本 V1.2.9，建議 V1.2.10
```

### 3.2 整合期 6 項補強檢查（integration-preflight.js）

```
POST http://127.0.0.1:8091/api/run-file
  args: { draftDir: "drafts/omni-cash-transaction", projectDir: "project" }

結果：passed 117 / failed 48
⚠️ 失敗項目集中於：
  - .agents/skills/.../examples/01..03（教材示例，並非本 feature）
  - project/distribution/.../target/{classes,generated-resources}（建置快取，並非 SSOT）
  - 既有 migration 1.0.0~1.1.0 與實體 DB V1.2.8 落差（與本 draft 無關）
✅ 本 draft 對應的 omni-cash-transaction 工作流均通過 6 項補強檢查
```

---

## 4. Kogito Codegen 5 輪迭代問題與修正

`mvn -B test -pl distribution/transfer-app -am` 經 5 輪執行才進入測試階段，每次錯誤均由 Kogito jBPM codegen 在 `generateSources` 階段拋出。

### 第 1 輪：MyOpenApiService FQCN 錯誤

```
ProcessCodegenException: Error while elaborating process id = "repayment_cash_deposit"
  Invalid work item "callApiViaOpenAPI": class not found for interfaceName
  "com.example.platform.security.MyOpenApiService"
```

**根因**：draft 沿用 vibe skill 範例的 `platform.security` package，專案既有實作位於 `com.example.transfer.workflow`（同樣現象見 `saga2~saga5` 既有 workflow）。

**修正**（feature-local）：
```yaml
# workflows/repayment-cash-deposit.sw.yaml
# workflows/repayment-cash-cancellation.sw.yaml
operation: 'service:com.example.transfer.workflow.MyOpenApiService::callOpenApi'
```

### 第 2 輪：OpenApiSchemaValidator FQCN 錯誤

```
ProcessCodegenException: Error while elaborating process id = "omni_cash_transaction"
  Invalid work item "validateOpenApiInput": class not found for interfaceName
  "com.example.platform.security.OpenApiSchemaValidator"
```

**修正**（feature-local）：
```yaml
# workflows/omni-cash-transaction.sw.yaml
operation: 'service:com.example.transfer.workflow.OpenApiSchemaValidator::validate'
```

### 第 3 輪：IdempotencyService FQCN 錯誤

```
ProcessCodegenException: Invalid work item "checkIdempotency":
  class not found for interfaceName
  "com.example.platform.distribution.transfer.IdempotencyService"
```

**修正**（feature-local）：
```yaml
# workflows/omni-cash-transaction.sw.yaml
operation: 'service:com.example.reconciliation.IdempotencyService::findBySequenceNumber'
```

### 第 4 輪：findBySequenceNumber 簽名不匹配（parent）

```
NoSuchMethodException: ... in class "com.example.reconciliation.AuditLogService"
  with proper arguments
  [Argument{type='java.lang.String', name='workflowId'},
   Argument{type='java.lang.Object', name='businessKey'},
   Argument{type='java.lang.Object', name='sequenceNumber'}]
```

**根因**：既有 canonical 簽名為 `(String workflowId, Object businessKey)`；draft 額外傳了 `sequenceNumber` 試圖對齊既有 `doSaveLog` 5 參風格，但查詢方法並未開放多載。

**依規範「Caller Adapts to Callee」修正**（feature-local，不新增 Java overload）：
```yaml
# workflows/omni-cash-transaction.sw.yaml（CheckIdempotency arguments）
arguments:
  workflowId: omni_cash_transaction
  businessKey: '${ .sequenceNumber }'
  # 移除 sequenceNumber: '${ .sequenceNumber }'
```

### 第 5 輪：findBySequenceNumber 簽名不匹配（child B）

```
NoSuchMethodException: ... in class "com.example.reconciliation.AuditLogService"
  with proper arguments
  [...] Argument{type='java.lang.Object', name='sequenceNumber'}
  (LookupOriginal, repayment_cash_cancellation)
```

**同樣原因修正**（feature-local）：
```yaml
# workflows/repayment-cash-cancellation.sw.yaml（LookupOriginal arguments）
arguments:
  workflowId: repayment_cash_deposit  # 詳見第 7 節修正
  businessKey: '${ .originalSequenceNumber }'
  # 移除 sequenceNumber: '${ .originalSequenceNumber }'
```

---

## 5. HTTP 404 根因分析

第 1-5 輪解決 codegen 後，測試階段暴露**所有 child host call 回傳 HTTP 404**：

```
Property 'workflowdata.coreResult' changed value from: 'null',
  to: '{"status":"999","message":"HTTP 狀態碼: 404","track_id":null,...}'
```

**根因**：執行指令 `mvn -B test -pl distribution/transfer-app` 只建置 transfer-app 子樹，**沒有** 觸發 `dev/transfer-mock` 的 `initialize` 階段，因此 `dev/transfer-mock/src/main/java/org/acme/transfer/api/features/` 為空，核心 host endpoint 沒有被註冊到 Quarkus runtime。

**修正**：改用 Maven reactor 模式讓 mock 與 transfer-app 一起被建置與測試：
```bash
mvn -B test -pl distribution/transfer-app -am
# -am = also-make，把 transfer-app 依賴的 dev/transfer-mock 一併建置
```

`transfer-mock` 的 Antrun 在 `initialize` 階段把 `features/omni-cash-transaction/mocks/*.java` 與 `mocks/dto/*.java` 動態複製到正確位置，Mock 端點註冊成功，HTTP 404 解除。

---

## 6. Workflow 行為修正（從 B 系列測試失敗反推）

修正 mock 裝配後，5 個 draft 測試中 3 個失敗，逐步反推並修正 workflow 拓撲。

### 6.1 B2 失敗（finalStatus = CANCEL_REJECTED，預期 LOOKUP_FAILED）

**日誌關鍵**：
```
Property 'workflowdata.originalResult' changed value from: 'null',
  to: '{"found":false,"originalStatus":"","originalTrackId":null,"cancelledBy":null}'
Triggered node 'FinalizeCancelRejected' for process 'repayment_cash_cancellation'
```

**根因**：取消 child 的 `CheckOriginal` 是單一 switch，內含三個條件：
1. `notFound`：`found != true` → `LOOKUP_FAILED`
2. `notCancellable`：`originalStatus != "SUCCESS" or cancelledBy != null` → `CANCEL_REJECTED`
3. default → `CancelCore`

問題：當 `found=false` 時 `originalStatus` 為空字串，**`notFound` 與 `notCancellable` 同時成立**，jBPM switch 不保證依 YAML 宣告順序執行，造成資料缺失也被誤判為不可取消。

**修正**（feature-local，遵循 skill 6i 規範「冪等與業務路由解耦」）：
```yaml
# workflows/repayment-cash-cancellation.sw.yaml
- name: CheckOriginal
  type: switch
  dataConditions:
    - name: notFound
      condition: '${ .originalResult.found != true }'
      transition: FinalizeLookupFailed
  defaultCondition:
    transition: CheckOriginalCancellable      # 新增

- name: CheckOriginalCancellable              # 新增獨立 switch
  type: switch
  dataConditions:
    - name: notCancellable
      condition: '${ ... originalStatus != "SUCCESS" ... or cancelledBy != null }'
      transition: FinalizeCancelRejected
  defaultCondition:
    transition: CancelCore
```

### 6.2 B1 失敗（HTTP 500，finalStatus = LOOKUP_FAILED）

**日誌關鍵**：
```
Property 'workflowdata.originalResult' changed value from: 'null',
  to: '{"found":true,"originalStatus":"0","originalTrackId":null,"cancelledBy":null}'
finalStatus = LOOKUP_FAILED
```

**根因**：測試 B1 先發 A 交易（原 sequenceNumber）成功，再發 B 取消；取消 child 用 `workflowId: repayment_cash_cancellation` 查詢原交易，但 audit log 是由 `repayment_cash_deposit` 寫入，因此即使是剛成功的原交易也「查無資料」。

**修正**（feature-local）：lookup 與 mark cancelled 都改以原交易 workflow id：
```yaml
# workflows/repayment-cash-cancellation.sw.yaml
# LookupOriginal arguments
workflowId: repayment_cash_deposit   # 原 repayment_cash_cancellation

# MarkOriginalCancelled arguments
workflowId: repayment_cash_deposit   # 原 repayment_cash_cancellation
```

### 6.3 B1 失敗（finalStatus = CANCEL_REJECTED，預期 CANCELLED）

**日誌關鍵**：
```
Property 'workflowdata.originalResult' changed value from: 'null',
  to: '{"found":true,"originalStatus":"0",...}'
finalStatus = CANCEL_REJECTED
```

**根因**：`CheckOriginalCancellable` 的守衛只接受 `originalStatus == "SUCCESS"`，但 `AuditLogService` 對成功的 child 落庫時 `status` 欄位為 integer `0`，不是 `SUCCESS` 字串。

**修正**（feature-local，雙向相容）：
```yaml
# workflows/repayment-cash-cancellation.sw.yaml
- name: notCancellable
  condition: >
    ${ ((.originalResult.originalStatus // "") | tostring) != "SUCCESS"
       and ((.originalResult.originalStatus // "") | tostring) != "0"
       or .originalResult.cancelledBy != null }
  transition: FinalizeCancelRejected
```

`// ""` 是 skill 6g 要求的安全守衛，避免 null 拋 NPE。

---

## 7. 整合測試修正

### 7.1 修正前問題

draft 測試用硬編碼 sequenceNumber（P1/A1/P4/B1/B2），且 B1/B2 共用同一個 `A1234567890000015061655` 當作原交易，未考慮：

1. **冪等污染**：同 seq 重送會命中 parent 冪等 cache（實測 P4 第二次回 `IDEMPOTENT_REPLAY`，其他測試若重送則同樣命中）。
2. **B1 前置資料缺失**：B1 直接發 B 取消 + `originalSequenceNumber`，但沒有先建立對應 A 交易 → 取消 child lookup 必然查無資料。
3. **B2 測試目的誤判**：B2 想測 lookup 查不到 → LOOKUP_FAILED，但若沿用 B1 同樣 hardcoded seq，會被 parent 冪等直接命中，回傳 IDEMPOTENT_REPLAY。

### 7.2 修正（feature-local，測試本體）

```java
// tests/OmniCashTransactionWorkflowTest.java
// - 全部 sequenceNumber 改為 System.nanoTime() 動態產生
// - B1 先 POST A 成功再 POST B 取消
// - B2 用動態不存在的原交易，確保 lookup 一定查不到
private String uniqueSequence() {
    return "A123456789" + System.nanoTime();
}
```

---

## 8. 最終驗證結果

### 8.1 Feature 預檢最終

```
POST http://127.0.0.1:8091/api/run-file
  args: { draftDir: "project/features/omni-cash-transaction" }
result: passed 46 / failed 0
flyway: latest=V1.2.9 nextSuggested=V1.2.10
```

### 8.2 Maven 全 reactor 驗收

```bash
cd project
mvn -B test -pl distribution/transfer-app -am
```

```
Tests run: 90, Failures: 0, Errors: 0, Skipped: 0
BUILD SUCCESS
```

| 測試類別 | tests | failures |
|---|---:|---:|
| DataIndexGraphQLTest | 4 | 0 |
| MyOpenApiServiceRetryTest | 2 | 0 |
| OpenApiSchemaValidatorTest | 8 | 0 |
| ReconciliationCsvTest | 14 | 0 |
| Saga2TransferWorkflowTest | 18 | 0 |
| Saga3TransferWorkflowTest | 9 | 0 |
| Saga4TransferWorkflowTest | 15 | 0 |
| Saga5TransferWorkflowTest | 15 | 0 |
| **OmniCashTransactionWorkflowTest（本 feature）** | **5** | **0** |
| **合計** | **90** | **0** |

### 8.3 Feature 5 個情境結果

| 情境 | 預期 | 實際 | HTTP | 結果 |
|---|---|---|---|---|
| P1（無效 operationType=C） | 400 REJECTED_VALIDATION | finalStatus=REJECTED_VALIDATION | 400 | ✅ |
| A1（正向繳款） | 200 SUCCESS | finalStatus=SUCCESS | 200 | ✅ |
| P4（同 seq 重送） | 第二次 200 IDEMPOTENT_REPLAY | finalStatus=IDEMPOTENT_REPLAY | 200 | ✅ |
| B1（取消成功原交易） | 200 CANCELLED | finalStatus=CANCELLED | 200 | ✅ |
| B2（取消不存在的原交易） | 500 LOOKUP_FAILED | finalStatus=LOOKUP_FAILED | 500 | ✅ |

---

## 9. 變更清單（feature-local，零侵入核心模組）

### 9.1 修改檔案

| 檔案 | 修改類型 |
|---|---|
| `project/features/omni-cash-transaction/workflows/omni-cash-transaction.sw.yaml` | 修正 OpenApiSchemaValidator/IdempotencyService FQCN；CheckIdempotency 移除冗餘 sequenceNumber argument；InvokeDepositSubflow/InvokeCancellationSubflow 補 onErrors → InjectWorkflowFailedStatus；新增 InjectWorkflowFailedStatus inject |
| `project/features/omni-cash-transaction/workflows/repayment-cash-deposit.sw.yaml` | 修正 MyOpenApiService FQCN |
| `project/features/omni-cash-transaction/workflows/repayment-cash-cancellation.sw.yaml` | 修正 MyOpenApiService FQCN；LookupOriginal 移除冗餘 sequenceNumber argument；LookupOriginal/MarkOriginalCancelled 改用 `workflowId: repayment_cash_deposit`；CheckOriginal 拆為 CheckOriginal + CheckOriginalCancellable；notCancellable 守衛同時接受 `SUCCESS` 與 numeric `0` |
| `project/features/omni-cash-transaction/tests/OmniCashTransactionWorkflowTest.java` | sequenceNumber 改為 System.nanoTime() 動態產生；B1 先建立 A 成功再取消；B2 使用不存在原交易 |

### 9.2 draft（`drafts/omni-cash-transaction/`）鏡像同步

`cp -r drafts/omni-cash-transaction project/features/omni-cash-transaction` 為一次性掛載。為使 draft 與 feature 同步，在 draft 也同步上述 4 處變更，避免 draft 重發時把錯誤回灌。

### 9.3 平台核心未動

`distribution/transfer-app/pom.xml`、`dev/transfer-mock/pom.xml`、`platform-security/SonataFlowSecurityConfig.java`、`reconciliation-api/AuditLogService.java` 等零修改。

抽離只需：
```bash
sqlite3 data/reconciliation.db < project/features/omni-cash-transaction/db/teardown.sql
rm -rf project/features/omni-cash-transaction
mvn test  # 仍應維持綠燈（90 - 5 = 85 既有測試）
```

---

## 10. 反模式與踩坑彙整（給下次整合者）

| 現象 | 真正根因 | 預防 |
|---|---|---|
| `class not found for interfaceName ...MyOpenApiService` | draft 沿用 vibe skill 範例的 `platform.security` package，專案既有為 `com.example.transfer.workflow` | 整合前先以 `grep -r "service:com.example.*MyOpenApiService" project/**/sw.yaml` 比對既有 FQCN；Step 1.5 Gate 3 |
| `NoSuchMethodException: findBySequenceNumber` | draft 傳 3 參數（`workflowId` + `businessKey` + `sequenceNumber`），既有 canonical 為 2 參數 | 不要為單一 workflow 加 Java overload；讓 caller 對齊既有 canonical 簽名（skill 4b 防護鐵律） |
| `ProcessCodegenException` 後看不到錯誤細節 | Surefire 把 Kogito codegen 錯誤捲進 `class not found` 訊息 | 從 `[ERROR] Caused by: java.lang.IllegalArgumentException: Invalid work item` 字串找 interfaceName |
| `mvn test -pl distribution/transfer-app` 全部 child host 404 | `-pl` 不會觸發 `dev/transfer-mock` 的 `initialize` Antrun，動態 mock source 未同步 | 整合期驗證必須 `mvn -B test -pl distribution/transfer-app -am` 或從根 reactor `mvn test` |
| Switch 條件同時滿足導致錯誤分流 | jBPM switch 不保證依 YAML 條件宣告順序執行 | 拆成多個獨立 switch（skill 6i 解耦規範） |
| 取消 child 用自身 workflowId 查原交易 | audit log 是由「原交易 workflow」寫入，跨 workflow 查詢需指定原 workflowId | 在 spec.md §0 假設清單明確聲明「跨 child 查詢需帶原 workflow id」 |

---

## 11. 已知限制與後續建議

1. **Maven reactor 範圍警覺**：整合期驗證務必使用 `-am` 帶入 dev mock 依賴，否則 mock 缺失會誤導為 host 契約問題。
2. **mock 哨兵值未啟用**：本 draft 未設計 RBFAIL 等 mock 哨兵，可後續依 `vibe-workflow-design-v3` 06-mock-sentinel-check 補強 `ROLLBACK_FAILED` / `CANCEL_ROLLBACK_FAILED` 場景測試。
3. **V1.2.10 預留**：預檢建議下一版從 `V1.2.10` 起算，後續若新增欄位或 View 應跳過 2.9 直接到 2.10。
4. **status-rewrite filter 已使用 `*` 通配**：本 feature 不需修改 `application.properties`；後續若新增 child workflow，可直接由 `*` 自動覆蓋（既有 v1.0 設計）。
5. **CI/CD 落地**：建置指令建議固化為 `./offline-build.sh` 或 CI 腳本，預期 compile 1-2 min、test 5-10 min（含 dev mock reactor）。

---

## 12. 驗收 Checklist

- [x] `mvn -B test -pl distribution/transfer-app -am` 全綠（90 tests, 0 failures, BUILD SUCCESS）
- [x] Feature 預檢 46/46 PASS
- [x] 三個 workflow 都已通過 Kogito codegen
- [x] 5 個 P/A/B 情境全部符合預期 finalStatus 與 HTTP code
- [x] Audit log 落庫（測試報告可見 `[AuditLogService] 成功寫入對帳紀錄!`）
- [x] V1.2.9 SQLite View 建立
- [x] 平台核心模組零修改
- [x] draft 與 feature 兩邊的 workflow / test 已同步
