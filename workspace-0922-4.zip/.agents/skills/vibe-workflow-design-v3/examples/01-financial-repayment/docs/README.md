# Omni Cash Transaction Draft

這是信用卡臨櫃現金繳款的 Feature Overlay draft，供 `sonataflow-integration` 後續掛載至 `project/features/omni-cash-transaction/`。

## 業務入口

`POST /Omni/{creditcardid}/Repayment/Execute`

- `operationType=A`：正向繳款，委派 `repayment_cash_deposit`
- `operationType=B`：當日取消，委派 `repayment_cash_cancellation`

## 目錄

- `workflows/`：Parent 與兩個 Child
- `specs/internal/`：唯一對外入口與 `x-workflow-id`
- `specs/external/`：Core 與 CreditCard host 契約
- `mocks/`：dev profile mock 與 DTO
- `db/`：V1.2.9 migration 與 teardown
- `tests/`：P1/A1/P4/B1/B2 隔離測試

## 交接注意

此 draft 不直接修改 `project/`。`docs/spec.md` 的 Project Mapping Manifest 是下游整併 SSOT。
