# Omni Cash Transaction 執行軌跡與問題報告

- 報告日期：2026-09-22
- Draft：`drafts/omni-cash-transaction/`
- Feature：信用卡臨櫃現金繳款
- 平台目標：SonataFlow / Kogito 10.2.0 / Quarkus 3.x
- 設計模式：Mode B，Parent + 2 Child Subflow
- 報告性質：設計期產出、靜態檢查與交接風險紀錄
- 目前結論：Draft 結構與 45/46 項正式 preflight 通過，但尚未達到可宣稱平台門禁、Maven/E2E 全綠的程度

## 1. 執行摘要

本次依四份需求文件建立一個自治 Feature Overlay draft，包含 Parent workflow、正向繳款 Child、取消 Child、Internal/External OpenAPI、Mock、DTO、SQLite 對帳 View、組態、測試與設計文件。

已確認通過的部分：

- Draft 位於工作區根目錄 `drafts/omni-cash-transaction/`，沒有直接寫入 `project/`。
- 產出 19 個檔案，符合 skill 要求的 16-21 個檔案範圍。
- 三個 workflow id 使用 snake_case，Parent 與 Child 的 version 均為 `1.0.0`。
- `CheckIdempotencyResult` 與 `DispatchOperation` 分離。
- 直調 actionDataFilter 使用 `toStateData`，沒有發現 `.result.X` 取值。
- OpenAPI path parameter `creditcardid` 已在 host call payload 明確提供。
- SQLite View 在記憶體資料庫中可以成功建立。
- 沒有產出禁止的 `schemas/*.json`。

尚未完成的部分：

- 已呼叫 SonataFlow Agent Dynamic Script Runner 的正式 `preflight-checks.js`，結果為 46 項中 45 項通過、1 項失敗。
- 尚未把 draft 整併到 `project/`，因此尚未執行 Maven compile、Quarkus test、Kogito codegen 或真正 E2E。
- 靜態檢查發現至少三個應在整併前修正的高風險問題：path state 傳遞、告警觸發範圍、B1 測試前置資料。

## 2. 需求與設計追溯

### 2.1 輸入需求來源

| 來源 | 用途 |
|---|---|
| `credit-card-counter-cash-repayment-requirement.md` v2.2 | Parent/Child 架構、狀態、補償、資料規則 |
| `OmniRepaymentAPI.md` v1.0 | 對外臨櫃還款 API |
| `CoreAccountCashDepositAPI.md` v1.0 | Core 現金入帳 host API |
| `ExecuteCreditCardRepaymentAPI.md` v1.0 | Credit Card 還款 host API |

### 2.2 產出設計

| 層級 | Workflow id | 主要職責 |
|---|---|---|
| Parent | `omni_cash_transaction` | 驗證、冪等、A/B 分流、統一回應與稽核 |
| Child A | `repayment_cash_deposit` | Core 入帳、Credit Card 還款、LIFO Core rollback |
| Child B | `repayment_cash_cancellation` | 查原交易、Core 沖正、Credit Card 沖銷、失敗補償 |

### 2.3 狀態設計

- 成功：`SUCCESS`、`CANCELLED`
- 業務失敗：`FAILED`、`ROLLED_BACK`、`CANCEL_REJECTED`、`CANCEL_FAILED`
- 驗證/系統失敗：`REJECTED_VALIDATION`、`LOOKUP_FAILED`
- 補償失敗：`ROLLBACK_FAILED`、`CANCEL_ROLLBACK_FAILED`
- 冪等重送：`IDEMPOTENT_REPLAY`

## 3. 詳細執行軌跡

### 3.1 初始化與局部閱讀

1. 讀取四份需求文件，確認唯一對外入口為 `POST /Omni/{creditcardid}/Repayment/Execute`。
2. 確認 `operationType=A` 是正向繳款，`operationType=B` 是取消。
3. 讀取現有金融 repayment example，沿用 Mode B、snake_case workflow id、internal/external spec 分層與新 convention。
4. 掃描正式 migration，確認既有 reconciliation 版本最高為 `V1.2.8`，因此 draft View 使用 `V1.2.9`。
5. 讀取現有 `workflow_execution_log` schema，確認實體欄位為 `id`、`created_at`、`workflow_id`、`business_key`、`process_instance_id`、`status`、`message`、`input_data`、`output_data`。

### 3.2 Draft 建立

依序建立以下內容：

1. `feature.yaml`：feature metadata、owner、workflow manifest。
2. `docs/README.md`：draft 入口與下游交接說明。
3. `docs/spec.md`：H1-H18、輸入輸出、狀態、mapping、限制與 manifest。
4. `docs/design-explanation.md`：創建者導向的 9 節設計說明。
5. Parent workflow：驗證 → 冪等 → 獨立 replay switch → A/B dispatcher → child → final audit。
6. Child A：Core forward → Credit Card forward → rollback 或成功。
7. Child B：lookup → Core cancel → Credit Card cancel → mark original 或補償。
8. Internal OpenAPI：唯一對外入口與 `x-workflow-id`。
9. External OpenAPI：Core 與 Credit Card host operation，包含 path parameter。
10. Config：status-rewrite、CDI bean binding、host fallback 備註。
11. DB：`V1.2.9__create_view_omni_cash_transaction_reconciliation.sql` 與 `teardown.sql`。
12. Mock/DTO：Core、Credit Card resource 與 `features.dto` package。
13. Test：P1、A1、P4、B1、B2 五個測試案例。

### 3.3 已執行命令與結果

| 檢查 | 執行方式 | 結果 |
|---|---|---|
| Draft 檔案數 | `find drafts/omni-cash-transaction -type f \| wc -l` | 通過，19 個檔案 |
| 禁止 JSON schema | 搜尋 `*/schemas/*.json` | 通過，0 個 |
| YAML parse | Python `yaml.safe_load` 解析 7 個 YAML | 通過 |
| Workflow id/version | Python 讀取三份 `.sw.yaml` | 通過，三個 snake_case id、version `1.0.0` |
| `errorRef` 對齊 | Python 收集 references 與 errors 宣告 | 通過，所有引用均有宣告 |
| `toStateData` | Python 掃描含 `results` 的 operation | 通過 |
| `.result.X` 禁用檢查 | grep 掃描 workflow | 通過，未發現誤用 |
| SQLite migration | SQLite 記憶體資料庫建立 audit table 後套用 View SQL | 通過，View 建立成功 |
| View 欄位檢查 | 檢查實體欄位與 `json_extract` | 通過；`sequence_number`、`final_status` 是 alias，不是實體欄位讀取 |
| 設計文件章節 | `grep '^## '` | 通過，至少 9 節 |
| 編輯器 diagnostics | `get_errors` | Java 檔被視為非 Maven project；沒有以此證明編譯成功 |
| Maven compile/test | 未執行 | 未整併，無法在 draft 目錄直接執行正式測試 |
| Agent Runner preflight | `POST http://127.0.0.1:8091/api/run-file` 執行 `preflight-checks.js` | 部分通過：46 項中 45 項通過，Parent 的 onErrors coverage 失敗 |

### 3.4 工具環境限制

本次環境沒有 `rg` 與 Ruby/YAML CLI，因此部分檢查改用 Python、grep、SQLite 與既有編輯器 diagnostics 完成。Python 的 YAML parse 已通過，但這不等同於 SonataFlow/Kogito schema validation 或 code generation 通過。

## 4. 問題清單

問題依風險排序。`P0` 表示不可交接，`P1` 表示整併前應修正，`P2` 表示測試或規格補強，`P3` 表示文件/可維護性改善。

### P1-01：`creditcardid` 沒有明確進入 workflow state

- 位置：`specs/internal/omni-counter-repayment-api.yaml`、三份 workflow 的 host payload。
- 現象：Internal API 將 `creditcardid` 宣告為 URL path parameter，但 request body schema 沒有此欄位；Child workflow 卻使用 `${ .creditcardid }`。
- 影響：若 dynamic router 沒有把 path parameter 注入 workflow state，host URL 可能得到空的 `creditcardid`，造成錯誤路徑或錯誤主機交易。
- 根因：API path parameter、workflow state data 與 host payload 的 mapping 尚未明確串接。
- 建議：在整併前確認 `InternalOpenApiDynamicRouter` 的 path injection contract；若 router 不會注入，Parent 應在入口明確把 path parameter 映射到 state，並在 spec H5 固化 `creditcardid` 與 `partyId` 的關係。不要只依賴 `${ .creditcardid }` 的隱含存在。
- 驗證方式：以實際 `/Omni/A123456789/Repayment/Execute` 呼叫檢查 Core/CreditCard mock 收到的 path parameter。

### P1-02：Parent `FinalAuditAndEnd` 無條件呼叫 `notifyOps`

- 位置：`workflows/omni-cash-transaction.sw.yaml` 的 `FinalAuditAndEnd`。
- 現象：Parent 在所有終態，包括 `SUCCESS`、`CANCELLED`、`REJECTED_VALIDATION`、`IDEMPOTENT_REPLAY`，都呼叫 `notifyOps`。
- 影響：正常交易與一般驗證失敗可能被當作營運告警，造成告警噪音；也不符合需求中「child 進入 `*_FAILED` 終態才告警」的語意。
- 根因：`notifyOps` 被放入共用 final state，而沒有先用終態 switch 過濾。
- 建議：移除 Parent final state 的無條件 `notifyOps`，或新增 `NotifyParentFailure` switch，只對 `FAILED`、`ROLLBACK_FAILED`、`CANCEL_FAILED`、`CANCEL_ROLLBACK_FAILED`、`LOOKUP_FAILED` 等需監控狀態觸發。正常 audit 仍保留 `recordAuditLog`。
- 驗證方式：測試 SUCCESS、REJECTED_VALIDATION、ROLLBACK_FAILED 三種情境，確認只有後者產生 OpsAlert。

### P1-03：B1 測試沒有先建立可取消的 SUCCESS 原交易

- 位置：`tests/OmniCashTransactionWorkflowTest.java` 的 `b1CancelsSuccessfulOriginal`。
- 現象：B1 直接送出取消請求，但沒有先執行 A1 建立 `originalSequenceNumber` 對應的 SUCCESS audit row。
- 影響：依 Child B 的 lookup 規則，B1 很可能實際得到 `LOOKUP_FAILED`，而非測試宣告的 `CANCELLED`。
- 根因：測試把原交易存在視為固定 fixture，但 draft 內沒有提供 fixture、setup 或先行 A workflow。
- 建議：B1 先以動態序號執行一筆 A request，確認回傳 `SUCCESS`，再以該序號送 B；或在 `@BeforeEach` 建立可控的 audit fixture，並確保測試資料不與 P4 互相污染。
- 驗證方式：執行 B1 前後讀取 audit log，確認原交易 `finalStatus=SUCCESS` 且取消後具有 `cancelledBy`。

### P1-04：測試 request 的 path 與 workflow business state 契約未被驗證

- 位置：`tests/OmniCashTransactionWorkflowTest.java` 的 `URL` 與 request helper。
- 現象：URL 帶有 `A123456789`，body 的 `partyId` 也帶相同值，但測試沒有檢查 mock 實際收到的 `creditcardid`。
- 影響：即使 workflow 使用了空 path parameter，測試仍可能只驗證 HTTP/finalStatus，漏掉真正的 host routing 缺陷。
- 建議：Mock resource 記錄或回傳收到的 path value；測試增加 path/body 對應 assertion。

### P1-05：正式 preflight 的 Parent onErrors coverage 失敗

- 現象：正式 Agent Runner 已執行，回報 `operation states=5`，但 Parent workflow 的 `onErrors` 僅 3 處；失敗檔案為 `workflows/omni-cash-transaction.sw.yaml`。
- 影響：部分 host/service 例外可能未經由 audit-safe error path 處理，存在審計缺口或 workflow 異常終止風險。
- 根因：Parent 的 `InvokeDepositSubflow`、`InvokeCancellationSubflow` 與 `FinalAuditAndEnd` 等 operation state 沒有完整配置 `onErrors`；預檢規則要求 operation state 的 host 例外覆蓋。
- 建議：依實際 terminal/audit 豁免規則，為需要覆蓋的 operation state 補上 `onErrors`，導向對應的 failure injection/final audit path；補完後重新執行同一個 Agent Runner preflight。
- 本次 Runner 結果：46 項檢查中 45 項通過、1 項失敗；其餘 workflow id、actionDataFilter、path parameter、toStateData、version、error alignment、unreachable state、notifyOps signature、DTO、View SQL、design explanation 與 execution trace 檢查均通過。
- 重現命令：

  ```bash
  curl -s -X POST http://127.0.0.1:8091/api/run-file \
    -H 'Content-Type: application/json' \
    -d '{"filePath":".agents/skills/vibe-workflow-design-v3/scripts/preflight-checks.js","args":{"draftDir":"drafts/omni-cash-transaction"}}'
  ```

- 完成條件：`failedChecks=0`，且 Problems 面板沒有新增 error diagnostics。

### P2-01：正式 preflight 曾未在初次驗證階段執行

- 現象：初次 draft 驗證只執行了 Python YAML parse、grep、SQLite migration 與局部 contract checks，沒有立即呼叫 skill 指定的 Agent Runner。
- 原因：當時把局部檢查誤判為足以先形成報告，並因環境缺少 `rg`/Ruby 而改用現有工具；這只能解決語法與局部結構問題，不能取代 skill 的正式 16 項平台門禁。
- 評估：這是執行流程判斷失誤，不是 Agent Runner 不適用，也不是 8091 不可用。後續探測確認腳本存在、8091 可連線，正式執行後也確實抓到 1 個局部檢查漏網問題。
- 結論：本項已補執行，但結果為 partial pass；正式驗收仍被 P1-05 阻塞。

### P2-02：尚未執行 Kogito codegen 與 Maven 測試

- 現象：`get_errors` 將 Java 檔視為非 Maven project；draft 本身不是 Maven module。
- 影響：尚未驗證 Java import、Quarkus CDI bean、Kogito reflection overload、OpenAPI codegen、workflow graph 與實際 status-rewrite。
- 建議：先交由 `sonataflow-integration` 掛載至正式 module，再執行窄範圍 compile、測試與 E2E；不要把目前的 Python YAML parse 當成編譯通過。

### P2-03：Mock response DTO 與 host OpenAPI response 的 `result` shape 尚未完整對齊

- 現象：Mock `CoreCashDepositResponse` 只建立 `track_id`、`status`、`errors`，沒有 response `result` 內容；Credit Card mock 重用 Core DTO。
- 影響：目前 workflow 主要取 status/track_id，因此 happy path 可能可走，但下游若驗證 result 或依 host DTO 分流，會出現契約缺口。
- 建議：分別建立 Core 與 Credit Card 的 request/response/result DTO，依各 host spec 回傳完整 `result`，並加入 path/sequence/operationType assertion。

### P2-04：Host 回應欄位 `status` 與平台 adapter 的 `code` 雙軌尚未以實際 adapter 驗證

- 現象：workflow 使用 `(.status // .code)`，需求 host response 是 `status` int，但既有平台文件也存在 `.code` 業務碼契約。
- 影響：若 adapter 將 host `status=0` 轉成另一種結構，可能造成成功/失敗判斷偏差。
- 建議：以 `MyOpenApiService::callOpenApi` 的實際回傳 fixture 驗證兩種 host response；必要時明確分離 `hostStatus`、`businessCode` 與 `_httpStatus`，不要只用 fallback 表達式掩蓋契約差異。

### P2-05：需求的 `reason` 尚未進入 API 與 Child audit mapping

- 現象：需求資料模型包含 `TELLER_MISTAKE`、`CARDHOLDER_REQUEST`，但入口 request schema 沒有 `reason`，Child 也沒有把原因傳入 audit。
- 影響：取消技術流程可執行，但無法完整滿足「取消原因僅用於 audit」的業務追蹤要求。
- 建議：由業務確認是否納入 v1.0；若納入，補 internal schema、validator、workflow payload、audit input 與測試案例。

### P2-06：序號長度規則仍是未決議需求矛盾

- 現象：需求描述提到 13 碼，但範例為 20 碼；Parent 規則另提衍生 `CA_`/`CC_` 序號。
- 影響：schema 現在採較寬鬆 13-32 碼，可能無法阻擋主機真正不接受的長度。
- 建議：由 Core、Credit Card host owner 確認原始序號與衍生序號的正式長度、前綴及最大長度後，再收緊 OpenAPI pattern/maxLength。

### P3-01：`validationError`、`coreError` 等部分 error 宣告未必有實際使用

- 現象：workflow 為了契約完整性宣告多個 error，但部分只由 code/name 宣告，沒有對應 onErrors 路徑。
- 影響：通常不會阻擋功能，但會增加維護者對 error routing 的理解成本。
- 建議：完成正式 preflight 後，移除未使用宣告或補上明確的 error handling；保持 errors 區塊與實際 onErrors 最小一致。

## 5. 風險矩陣

| ID | 風險 | 等級 | 目前狀態 | 建議 owner |
|---|---|---|---|---|
| P1-01 | path parameter 可能未進 state | 高 | 待整合驗證 | Workflow/Router |
| P1-02 | 正常交易也觸發 OpsAlert | 高 | 靜態已確認 | Workflow |
| P1-03 | B1 測試缺少原交易 fixture | 高 | 靜態已確認 | Test |
| P1-04 | 測試未驗證 path/body 對應 | 高 | 靜態已確認 | Test/Mock |
| P1-05 | Parent onErrors coverage 失敗 | 高 | 45/46 通過，待修正 | Workflow |
| P2-01 | 初次驗證未立即執行正式 preflight | 中 | 已補執行，但流程曾延遲 | Integration |
| P2-02 | 未做 codegen/Maven/E2E | 中高 | 未完成 | Integration |
| P2-03 | Mock result DTO 不完整 | 中 | 已知缺口 | Mock |
| P2-04 | host adapter response 未實測 | 中 | 待驗證 | Platform |
| P2-05 | reason 欄位未落地 | 中 | 待業務決策 | Business/API |
| P2-06 | sequence length 未決議 | 中 | 待 host owner 決策 | Host owner |
| P3-01 | 未使用 error 宣告 | 低 | 可整理 | Workflow |

## 6. 交接前阻塞條件

以下條件未完成前，不建議宣稱「可直接整併」或「E2E 全綠」：

1. 修正 P1-01 至 P1-05，或以正式 router/mock 測試證明它們不成立。
2. 重新執行 Agent Runner，確認 `failedChecks=0`。
3. 將 draft 掛載至正式 Maven module，完成 Kogito codegen 與 compile。
4. 完成 A1、B1、B2、rollback failure、cancel rollback failure 的實際 E2E。
5. 確認 `MyOpenApiService` 實際 response shape 與 status-rewrite 行為。
6. 取得 host owner 對序號長度及 `creditcardid`/`partyId` 關係的正式確認。

## 7. 建議執行順序

1. 先修 Parent `notifyOps` 無條件告警問題。
2. 確認並修正 `creditcardid` 的 path-to-state mapping。
3. 重寫 B1 測試，先建立 SUCCESS 原交易，再執行取消。
4. 擴充 Mock result DTO，讓 host response 與 OpenAPI schema 完整一致。
5. 啟動 Agent Runner，執行 16 項 preflight。
6. 交給 `sonataflow-integration` 整併至正式 module。
7. 執行 compile、workflow codegen、隔離測試與五個核心 E2E。
8. 依正式 host 回應結果調整 status/code mapping、序號 pattern 與 status-rewrite。

## 8. 驗收結論

目前結果應標示為：

> **Design draft complete / Static checks partially passed / Integration validation pending**

本報告不把編輯器的「non-project file」提示視為 Java 編譯錯誤，也不把 Python YAML parse 視為 Kogito codegen 通過。正式驗收必須在 `project/` Maven module 與 Agent Runner 環境完成。

## 9. 關聯文件

- [README.md](README.md)
- [spec.md](spec.md)
- [design-explanation.md](design-explanation.md)
- [feature.yaml](../feature.yaml)
- [Parent workflow](../workflows/omni-cash-transaction.sw.yaml)
- [正向 Child workflow](../workflows/repayment-cash-deposit.sw.yaml)
- [取消 Child workflow](../workflows/repayment-cash-cancellation.sw.yaml)
