package org.acme.transfer.api;

import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import org.acme.transfer.api.features.dto.CoreCashDepositRequest;
import org.acme.transfer.api.features.dto.CoreCashDepositResponse;

import java.util.UUID;

@Path("/CoreAccount/{creditcardid}/CashDeposit")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class CoreCashDepositResource {
    @POST
    @Path("/Execute")
    public Response execute(@PathParam("creditcardid") String creditcardid, CoreCashDepositRequest request) {
        if ("0".equals(request.amount) || "0000000000".equals(request.amount)) {
            return Response.ok(new CoreCashDepositResponse(UUID.randomUUID().toString(), 1, "E0024", "金額不符")).build();
        }
        return Response.ok(new CoreCashDepositResponse(UUID.randomUUID().toString(), 0, null, null)).build();
    }

    @POST
    @Path("/Rollback")
    public Response rollback(@PathParam("creditcardid") String creditcardid, CoreCashDepositRequest request) {
        if (request.rollbackSequenceNumber != null && request.rollbackSequenceNumber.startsWith("RBFAIL")) {
            return Response.ok(new CoreCashDepositResponse(UUID.randomUUID().toString(), 1, "E0050", "回沖失敗")).build();
        }
        return Response.ok(new CoreCashDepositResponse(UUID.randomUUID().toString(), 0, null, null)).build();
    }
}
