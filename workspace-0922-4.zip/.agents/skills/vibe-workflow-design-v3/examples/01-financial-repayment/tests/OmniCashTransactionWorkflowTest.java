package com.example.platform.distribution.transfer.features;

import io.quarkus.test.junit.QuarkusTest;
import io.restassured.http.ContentType;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

@QuarkusTest
class OmniCashTransactionWorkflowTest {
    private static final String URL = "/Omni/A123456789/Repayment/Execute";

    @Test
    void p1RejectsInvalidOperationType() {
        given().contentType(ContentType.JSON).body(request("C", uniqueSequence(), null))
            .when().post(URL).then().statusCode(400).body("finalStatus", equalTo("REJECTED_VALIDATION"));
    }

    @Test
    void a1CompletesRepayment() {
        given().contentType(ContentType.JSON).body(request("A", uniqueSequence(), null))
            .when().post(URL).then().statusCode(200).body("finalStatus", equalTo("SUCCESS"));
    }

    @Test
    void p4ReplaysSameSequence() {
        String body = request("A", uniqueSequence(), null);
        given().contentType(ContentType.JSON).body(body).when().post(URL).then().statusCode(200);
        given().contentType(ContentType.JSON).body(body).when().post(URL).then().statusCode(200).body("finalStatus", equalTo("IDEMPOTENT_REPLAY"));
    }

    @Test
    void b1CancelsSuccessfulOriginal() {
        String originalSequence = uniqueSequence();
        given().contentType(ContentType.JSON).body(request("A", originalSequence, null))
            .when().post(URL).then().statusCode(200).body("finalStatus", equalTo("SUCCESS"));
        given().contentType(ContentType.JSON).body(request("B", uniqueSequence(), originalSequence))
            .when().post(URL).then().statusCode(200).body("finalStatus", equalTo("CANCELLED"));
    }

    @Test
    void b2ReturnsLookupFailure() {
        given().contentType(ContentType.JSON).body(request("B", uniqueSequence(), uniqueSequence()))
            .when().post(URL).then().statusCode(500).body("finalStatus", equalTo("LOOKUP_FAILED"));
    }

    private String request(String operationType, String sequenceNumber, String originalSequenceNumber) {
        String original = originalSequenceNumber == null ? "" : ",\"originalSequenceNumber\":\"" + originalSequenceNumber + "\"";
        return "{\"partyId\":\"A123456789\",\"branchCode\":\"070\",\"transactionDate\":\"20260805\",\"transactionDateTime\":\"15061655\",\"postingDayType\":\"A\",\"postingDate\":\"20260805\",\"paymentSourceCode\":\"2500P\",\"operationType\":\"" + operationType + "\",\"amount\":\"0000011758\",\"sequenceNumber\":\"" + sequenceNumber + "\"" + original + "}";
    }

    private String uniqueSequence() {
        return "A123456789" + System.nanoTime();
    }
}
