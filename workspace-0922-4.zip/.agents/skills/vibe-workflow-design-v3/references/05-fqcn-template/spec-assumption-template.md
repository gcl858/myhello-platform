# Reference: docs/spec.md §0 H1-H18 假設清單完整模板（v2.4）

> 對應 SKILL.md Step 1a + 7.1-7.3/7.14
> H13 拆為 H13a(validator)/H13b(service)；H7 加檔名-id 行；H14 加參數化聲明

---

## 完整模板

```markdown
## §0 假設清單

> 撰寫日期: YYYY-MM-DD
> 對應業務書: BR-XXX (vN.M)
> 對應 draft 套件: draft-<name>/
> 設計模式: Mode A / B / C / D / E
> Convention: 舊 / 新 / 純 HTTP

### 業務與輸入假設

| # | 假設 | 為何這樣假設 | 待確認問題 | 落地策略 |
|---|---|---|---|---|
| H1 | 輸入欄位 N 個 (列舉) | 業務書 §X.Y | — | docs/spec.md §2.1 schema 對應 |
| H2 | 終態 finalStatus 有 M 個 (列舉) | 業務書 §X.Y | — | docs/spec.md §2.3 + status-rewrite config |
| H3 | 業務模式:Mode X (Saga/Parent+Child/...) | 業務書 §X.Y 流程圖 | — | docs/spec.md §3 workflow 結構 |
| H4 | 業務體系: <list> (e.g., Core + CC) | 業務書 §X.Y | — | docs/spec.md §3 子流程對應 |

### 平台與技術假設 ⭐

| # | 假設 | 為何這樣假設 | 待確認問題 | 落地策略 |
|---|---|---|---|---|
| H5 | 對外契約用 REST POST (或 GraphQL / gRPC) | 既有 transfer-workflow 用 REST | — | src/specs/internal/<entry>-api.yaml |
| H6 | **FQCN**: `<existing_service>::<new_method>` | 既有 service 未提供此方法 | 需擴充（展開/Map/JsonNode 三入口） | Java service (擴充) |
| H7 | **ID 命名**: snake_case (e.g., omni_cash_transaction) + 檔名-id Manifest（如 `omni-cash-transaction.sw.yaml:id omni_cash_transaction`，檔名≠id 合法） | ⭐ Kogito 10.2.0 codegen bug 規避 | — | 整個 draft 全用 snake_case；subFlowRef version 對齊 child version |
| H8 | **Convention**: 新 (status 0/1 int + finalStatus string，Parent 用；Child 僅 finalStatus) | 與 credit-card 體系對齊 | — | stateDataFilter.output 分流 |
| H9 | **Mock package**: org.acme.transfer.api.features (對齊特徵自治規範) | 避免下游 rename 與搬移 | — | src/mocks/* 全部，DTO 必為 `org.acme.transfer.api.features.dto` |
| H10 | **Mock sentinel**: 用 amount=0 觸發業務拒絕 (因 input regex 嚴格) | 不能用 FAIL_*,會被 input validation 攔截 | — | Mock resource 內 if (request.amount == "0" || ...) |
| H11 | **Path param 自動注入**: 從 OpenAPI spec 掃出 {creditcardid},在 workflow payload 顯式帶 .partyId | MyOpenApiService 不自動綁定 | — | workflow YAML 每個 callApiViaOpenAPI 都有 |

### 平台標準共用服務清冊 (Canonical Shared Services Catalog) ⭐

在宣告 `functions:` 或自定義服務時，平台已有以下共用 Bean，嚴禁發明新 package 或自行更動簽名：

| 服務名稱 | 標準 FQCN | 標準方法簽名契約 (Caller 必須嚴格對齊) | 用途說明 |
|---|---|---|---|
| `OpenApiSchemaValidator` | `com.example.transfer.workflow.OpenApiSchemaValidator` | `validate(Map arguments)` 或 `(JsonNode)` | Parent 入口 OpenAPI Schema 驗證 |
| `MyOpenApiService` | `com.example.transfer.workflow.MyOpenApiService` | `callOpenApi(Map arguments)` 或 `(JsonNode)` | OpenAPI spec 驅動之外部 HTTP 調用 |
| `IdempotencyService` | `com.example.reconciliation.IdempotencyService` | `findBySequenceNumber(String workflowId, Object businessKey)` | 冪等性查詢 (2 參契約，嚴禁額外帶 sequenceNumber) |
| `AuditLogService` | `com.example.reconciliation.AuditLogService` | `saveLog(String, Object, Object, Object, Object)` (5 參)<br>`findBySequenceNumber(String workflowId, Object businessKey)` (2 參)<br>`markCancelledBy(String, Object, Object, Object)` (4 參) | 稽核日誌儲存、原交易反查與標記已取消 |
| `OpsAlertService` | `com.example.reconciliation.OpsAlertService` | `raise(String workflowId, Object processInstanceId, Object businessKey, Object finalStatus, Object finalMessage, Map detail)` (6 參) | 補償失敗人工介入告警 (`notifyOps`) |

### 資料庫與稽核假設

| # | 假設 | 為何這樣假設 | 待確認問題 | 落地策略 |
|---|---|---|---|---|
| H12 | Flyway migration V 編號從既有最大 +1 且提供 teardown.sql | 從 project 找最大 V | — | db/migration/V<n+1>.__.sql 與 db/teardown.sql |
| H13a | **FQCN(validator)**: `<Xxx>BusinessRuleValidator::validate`（有條件必填/FAIL_ 哨兵時新建，否則複用通用） | 既有僅 Omni 一實作 | 需新建 + dispatch 註冊 + FAIL_ 剝離 | Java validator 新 class |
| H13b | **FQCN**: `<new_service>::<method>` (新 class) | 既有 service 無此類別 | 需新建（三入口） | Java service (新) + 對應 SQL migration (若需新欄位) |
| H14 | **FQCN**: `<existing_service>::<new_method>` (擴充，workflow_id 參數化不可寫死) | 既有 service 無此方法 | 需擴充 + 對應欄位 | Java service (擴充) + SQL migration |
| H15 | Audit log 保留 7 年 (保險法規) / 1 年 (一般) | 法規 §X.Y | — | AuditLogService retention policy |

### 整合前置產出物

| # | 假設 | 為何這樣假設 | 待確認問題 | 落地策略 |
|---|---|---|---|---|
| H16 | 平台支援 workflows=* 萬用字元，免手動合入 application.properties | 零侵入裝配架構 | — | config/application.properties.snippet 僅作備忘 |
| H17 | docs/spec.md §8 Project Mapping Manifest 指向 project/features/<name>/ | 自主特徵目錄模式 | — | docs/spec.md §8 表格 |

### 已知未解 / 待確認

| # | 待確認問題 | 影響 | 行動 |
|---|---|---|---|
| H18 | <待釐清的業務規則> | <影響哪些流程> | v1.1 修訂 |
```

---

## 真實案例 (omni-cash-transaction v1.0)

```markdown
## §0 假設清單

| # | 假設 | 為何這樣假設 | 待確認問題 | 落地策略 |
|---|---|---|---|---|
| H1 | 輸入欄位 6 個 | 業務書 §1.2 | — | docs/spec.md §2.1 schema |
| H2 | 終態 finalStatus 有 8 個 | 業務書 §3.1 | — | docs/spec.md §2.3 |
| H3 | 業務模式:Mode B (Parent + 2 Child) | 業務書 §2.1 | — | docs/spec.md §3 |
| H4 | 業務體系: CoreAccount + CreditCard | 業務書 §2.1 | — | docs/spec.md §3 |
| H5 | 對外契約用 REST POST | 既有 transfer-workflow 用 REST | — | src/specs/internal/omni-counter-repayment-api.yaml |
| H6 | **FQCN**: `com.example.reconciliation.AuditLogService::findBySequenceNumber` | 既有 service 支援 (workflowId, businessKey) 2 參數查詢 | — | 既有 service 直接複用 |
| H7 | **ID 命名**: snake_case | Kogito 10.2.0 bug 規避 | — | 整個 draft 全用 snake_case |
| H8 | **Convention**: 新 (status 0/1 int + finalStatus string) | 與 credit-card 對齊 | — | stateDataFilter.output |
| H9 | **Mock package**: org.acme.transfer.api.features | 對齊特徵自治架構 | — | src/mocks/* 全部 |
| H10 | **Mock sentinel**: amount=0 觸發業務拒絕 | regex 嚴格不允許 FAIL_* | — | Mock resource if (amount == "0") |
| H11 | **Path param 注入**: creditcardid 從 .partyId 推導 | MyOpenApiService 不自動綁定 | — | workflow YAML payload |
| H12 | Flyway V 編號接續最大版本 | 從 reconciliation-api/db/migration/ 與實體 DB 探測 | — | src/db/V1.2.9__*.sql 與 db/teardown.sql |
| H13 | **FQCN**: `com.example.reconciliation.IdempotencyService::findBySequenceNumber` | 既有 service 支援 (workflowId, businessKey) 2 參數查詢 | — | 既有 service 直接複用 |
| H14 | **FQCN**: `com.example.reconciliation.AuditLogService::markCancelledBy` | 既有 service 提供 4 參契約 (workflowId, businessKey, cancelledBy, processInstanceId) | — | 既有 service 直接複用 |
| H15 | Audit log 保留 1 年 (一般業務) | 非金融,無強制法規 | — | AuditLogService 預設 |
| H16 | 平台支援 workflows=* 萬用字元 | 零侵入裝配架構 | — | 備忘 snippet |
| H17 | Project Mapping Manifest 自治特徵模式 | 整合者直接照搬 | — | docs/spec.md §8 |
| H18 | 逆向 Child B 查原交易時 workflowId 綁定 | 原交易由 Child A (repayment_cash_deposit) 寫入 | — | LookupOriginal 傳 workflowId: repayment_cash_deposit |
```

---

## 為何 H6/H13/H14 必須明確標 FQCN 與參數契約?

這是下游 `sonataflow-integration` skill 識別「要新建/擴充哪些 service，或是已有既有 service 可直接綁定」的唯一依據。

整合者讀 spec.md §0,看到:
- `H6: com.example.reconciliation.AuditLogService::findBySequenceNumber` (2 參: `workflowId`, `businessKey`) → 知道直接對齊既有 2 參契約，不要在 workflow 多傳 sequenceNumber
- `H13: com.example.reconciliation.IdempotencyService::findBySequenceNumber` (2 參) → 知道直接對齊既有 2 參契約
- `H14: com.example.reconciliation.AuditLogService::markCancelledBy` → 知道直接對齊既有 4 參契約

若 §0 沒寫,整合者要從 workflow YAML 內 `functions: - operation:` 反推,容易因 FQCN 拼錯或參數不對齊導致 Kogito ProcessCodegenException。

---

## 撰寫順序建議

1. 先寫 H1-H4 (業務與輸入)
2. 再寫 H5 (對外契約類型)
3. 然後寫 H6-H11 (平台與技術)— 這幾條最重要,整合者必看
4. 接著 H12-H15 (資料庫)
5. H16-H17 (整合前置產出物)
6. 最後 H18+ (已知未解 / v1.1 修訂)

---

## 與 INTEGRATION-PRACTICE.md 對比

| 假設類型 | spec.md §0 | INTEGRATION-PRACTICE.md |
|---|---|---|
| 業務假設 (H1-H4) | 必有 | 隱含在「Step 1: 落規格檔」 |
| 平台與技術假設 (H5-H11) | 必有 ⭐ | 對應問題 1-7 |
| 資料庫假設 (H12-H15) | 必有 | 對應 Step 3 + 問題 5 |
| 整合前置產出物 (H16-H17) | 必有 | 對應 Step 5 |
| 已知未解 (H18+) | 必有 | 對應「已知限制」段 |

**核心差異**:`INTEGRATION-PRACTICE.md` 是**事後**記錄踩坑,`spec.md §0` 是**事前**標註假設。事前標註可以避免踩坑。
