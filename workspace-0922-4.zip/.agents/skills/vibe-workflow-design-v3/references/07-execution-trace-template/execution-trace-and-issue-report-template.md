# Reference 07: execution-trace-and-issue-report.md 寫作模板（執行軌跡紀錄與問題報告，v3.3 必產）

> 對應 SKILL.md Step 8c + 自查 7.35 + 交付檢查表
> 定位：`spec.md` 是技術規格，`design-explanation.md` 是業務設計理由；本檔是給**審查者、平台架構師與下游整合工程師**看的**詳細執行軌跡紀錄與問題報告**。
> 落位：`drafts/<feature-name>/docs/execution-trace-and-issue-report.md`（與 `docs/spec.md`、`docs/design-explanation.md` 同層；進 handoff zip）。

---

## 強制 9 節結構（不可刪節，可加附錄）

```markdown
# <特徵業務名稱> 執行軌跡與問題報告

- 報告日期：<YYYY-MM-DD>
- Draft：`drafts/<feature-name>/`
- Feature：<特徵業務名稱>
- 平台目標：SonataFlow / Kogito 10.2.0 / Quarkus 3.x
- 設計模式：<Mode A/B/C/D/E，架構簡述>
- 報告性質：設計期產出、靜態檢查與交接風險紀錄
- 目前結論：<客觀結論，例如：Draft 結構與多項靜態門禁通過，但尚未達到可宣稱 Maven/E2E 全綠的程度>

## 1. 執行摘要

簡述本次依需求文件建立自治 Feature Overlay draft 的概況，包含 Parent workflow、Child workflow、Internal/External OpenAPI、Mock、DTO、SQLite 對帳 View、組態、測試與設計文件。

### 已確認通過的部分
- [x] Draft 位於工作區根目錄 `drafts/<feature-name>/`，未直接侵入 `project/`。
- [x] 產出 17-22 個檔案，符合自治 Overlay 檔案數量範圍。
- [x] Workflow id 符合 snake_case 規範，Parent/Child subFlowRef version 精確對齊。
- [x] 冪等分支獨立（`CheckIdempotencyResult` 與業務 `Dispatcher` 分離）。
- [x] 直調 actionDataFilter 使用 `toStateData`，未出現 `.result.X`。
- [x] OpenAPI path parameter 與 host call payload 嚴格對應。
- [x] 經靜態或本機測試確認 SQLite View 欄位對齊實體 schema。
- [x] 嚴格杜絕殘留 `schemas/*.json`。

### 尚未完成 / 待整合驗證的部分
- [ ] 尚未呼叫 SonataFlow Agent Dynamic Script Runner 執行全量 `preflight-checks.js`（或已執行之結果摘要）。
- [ ] 尚未整併入 `project/` Maven 模組，未執行 Kogito codegen、Quarkus 測試與真正 E2E。
- [ ] 列出設計期靜態分析識別出的跨層契約風險或待決策項目。

## 2. 需求與設計追溯

### 2.1 輸入需求來源
| 來源文件 | 版本 | 用途 |
|---|---|---|
| `<業務需求書>.md` | vX.Y | 業務流程、狀態流轉、補償與資料約束規則 |
| `<對外入口API>.md` | vX.Y | 外部調用接口規範 |
| `<Host主機API-1>.md` | vX.Y | 核心主機調用接口規範 |
| `<Host主機API-2>.md` | vX.Y | 周邊主機調用接口規範 |

### 2.2 產出設計
| 層級 | Workflow ID | 主要職責 |
|---|---|---|
| Parent | `<feature_parent>` | 驗證、冪等、業務分流、統一回應與審計日誌 |
| Child A | `<feature_child_a>` | 正向業務調用、補償交易 (LIFO Rollback) |
| Child B | `<feature_child_b>` | 沖正/取消交易、查詢原交易、標記取消狀態 |

### 2.3 狀態設計
- 成功終態：`SUCCESS`, `CANCELLED` 等
- 業務失敗終態：`FAILED`, `ROLLED_BACK`, `CANCEL_REJECTED`, `CANCEL_FAILED` 等
- 驗證/系統失敗終態：`REJECTED_VALIDATION`, `LOOKUP_FAILED` 等
- 補償失敗終態：`ROLLBACK_FAILED`, `CANCEL_ROLLBACK_FAILED` 等（必發 ops alert）
- 冪等重送終態：`IDEMPOTENT_REPLAY`

## 3. 詳細執行軌跡

### 3.1 初始化與局部閱讀
1. 讀取業務需求與 Host API 文件，識別唯一對外入口與作業類型。
2. 識別架構模式（Mode A/B/C/D/E）與狀態回傳 Convention（舊/新/純 HTTP）。
3. 探測目標專案資料庫遷移紀錄，推導次一版 Flyway 版本號（`V<next>__...`）。
4. 檢視 `workflow_execution_log` 實體 schema，確認審計 View 欄位抽取方式。

### 3.2 Draft 建立過程
依序列出產出清單與實作要點：
1. `feature.yaml`：特徵元資料、owner、workflow 清單。
2. `docs/README.md`：draft 入口與交接指引。
3. `docs/spec.md`：H1-H18 假設、輸入輸出、狀態機與映射清單。
4. `docs/design-explanation.md`：創建者導向的 9 節設計理由書。
5. `docs/execution-trace-and-issue-report.md`：本執行軌跡與問題報告。
6. 工作流程定義（Parent / Child YAML）。
7. OpenAPI specs（`specs/internal/` 與 `specs/external/`）。
8. 組態備忘（`config/application.properties.snippet`）。
9. 資料庫 View DDL（CREATE VIEW 之前必加 `DROP VIEW IF EXISTS`）與抽離清理腳本 `db/teardown.sql`。
10. Mock 資源與 `features.dto` 套件定義。
11. 隔離測試套件（P1/A1/P4/B1/B2）。

### 3.3 已執行命令與結果
| 檢查項目 | 執行方式 / 指令 | 結果 |
|---|---|---|
| Agent Runner 健康檢查 | `curl -s http://127.0.0.1:8091/api/health` | 通過（回傳 online）/ 記錄實際狀態 |
| Draft 檔案計數 | `find drafts/<feature-name> -type f \| wc -l` | 通過，N 個檔案 |
| 禁止 JSON schema | 搜尋 `*/schemas/*.json` | 通過，0 個 |
| YAML 語法驗證 | YAML 解析腳本驗證工作流與 spec | 通過 |
| Workflow ID / version | 檢驗 snake_case 與 Parent/Child 版本對齊 | 通過 |
| errorRef 宣告對齊 | 掃描所有 `errorRef` 是否在 `errors:` 定義 | 通過 |
| toStateData 狀態防護 | 檢驗 operation results 之 toStateData 宣告 | 通過 |
| actionDataFilter 頂層欄位 | 檢驗無 `.result.X` 殘留 | 通過 |
| SQLite View 語法 | 套用至 SQLite 記憶體資料庫檢驗（含 DROP VIEW 前置） | 通過 |
| 文件章節完整度 | 檢驗 design-explanation 與 execution-trace 章節數 | 通過（各 ≥9 節） |
| Agent Runner 預檢 | `POST /api/run-file` 執行 `preflight-checks.js` | 記錄實際執行狀態 |
| Maven 編譯 / Quarkus 測試 | 執行狀態或未執行說明 | 記錄實際狀態 |

### 3.4 工具環境限制
說明執行檢測時的環境限制與採用的替代檢驗手段（例如：CLI 工具限制、沙盒網路隔離、Maven/Kogito codegen 需在正式整合期掛載後方可執行的邊界說明）。

## 4. 問題清單與發現

問題按嚴重性嚴格分級：
- `P0` (Blocker)：不可交接，阻斷基本運行（語法錯誤、死迴圈、Kogito bug 必發）。
- `P1` (Critical)：整併前應修正（path parameter 傳遞斷裂、告警範圍錯置、測試缺少 fixture 等）。
- `P2` (Major)：測試、規格或 Mock 補強（preflight 未跑、Maven 未編譯、Mock DTO 未完全對齊 host response、長度邊界不一致等）。
- `P3` (Minor)：文件、未使用的 error 宣告、可維護性整理。

### <PX-YY>：<問題簡述>
- 位置：`<檔案路徑> / <狀態或方法名>`
- 現象：<具體觀察到的行為或代碼寫法>
- 影響：<對執行期、整併期或業務流造成的後果>
- 根因：<技術或需求層面的真正原因>
- 建議：<具體可行的修改方案>
- 驗證方式：<後續如何驗證此問題已修正>

*(以此格式詳細記錄所有發現)*

## 5. 風險矩陣

| ID | 風險描述 | 等級 (高/中高/中/低) | 目前狀態 | 建議 Owner |
|---|---|---|---|---|
| P1-01 | ... | 高 | 靜態已確認 / 待驗證 | Workflow / Router |
| P1-02 | ... | 高 | 靜態已確認 | Workflow |
| P2-01 | ... | 中高 | 未執行 | Integration |
| P2-02 | ... | 中 | 已知缺口 | Mock |
| P3-01 | ... | 低 | 可整理 | Docs |

## 6. 交接前阻塞條件

條列不可略過之交接門檻（未滿足前禁止宣稱「可直接整併」或「E2E 全綠」）：
1. 所有 P0 阻斷性問題必須全數解決。
2. P1 等級關鍵缺陷已修正或已取得平台團隊解法共識。
3. 執行 Agent Runner `preflight-checks.js` 達到全綠無紅線。
4. 正式掛載後須完成 Kogito codegen 與 Quarkus compile。
5. 核心測試場景（正向、反向、補償失敗）在整合環境完成端對端驗證。

## 7. 建議執行順序

依優先級列出下一步工作建議：
1. 優先修訂 P1 級關鍵問題。
2. 補強 Mock DTO 與測試前置資料 (Fixture)。
3. 啟動 Agent Runner 執行 16 項平台預檢。
4. 移交 `sonataflow-integration` skill 進行正式目錄掛載。
5. 執行 Maven 編譯、Kogito 程式碼生成與整合測試。
6. 驗證實際 Host 回應與 `status-rewrite` 改寫行為。

## 8. 驗收結論

明確標記本階段客觀評級：
> **Design draft complete / Static checks partially passed / Integration validation pending**

嚴禁在尚未整併入專案執行 Maven/E2E 之前，虛構或宣稱「E2E 全部通過」！

## 9. 關聯文件

- [README.md](README.md)
- [spec.md](spec.md)
- [design-explanation.md](design-explanation.md)
- [feature.yaml](../feature.yaml)
- [Parent Workflow](../workflows/<parent-workflow>.sw.yaml)
- [Child Workflows](../workflows/)
- [Internal Specs](../specs/internal/)
- [External Specs](../specs/external/)
```

---

## 填寫鐵律與品質原則（7.35 檢查內容）

1. **實事求是，禁止虛報**：嚴禁在草稿階段聲稱「編譯通過」或「E2E 全綠」。未經 Maven 與 Kogito codegen 驗證前，結論一律標記為 `Integration validation pending`。
2. **命令軌跡真實記錄**：§3.3 必須列出實際執行的指令（如 `find`, `grep`, Python, SQLite 或 Agent Runner API）與真實產出數據。
3. **問題分級嚴格定義**：發現的每一項潛在風險必須依 P0/P1/P2/P3 正確分類，不可將高風險隱患降格為輕微問題。
4. **問題項目六要素齊全**：每條問題必須具備「位置、現象、影響、根因、建議、驗證方式」。
5. **章節數量強制要求**：二級章節 `## 1` 至 `## 9` 必須 9 節全數具備，不得任意刪減。由 `scripts/preflight-checks.js` 自動驗證。

---

## 反模式

- ❌ 未執行 Maven 測試卻在報告寫「所有測試通過」— 嚴格失真，下游整合必爆。
- ❌ 把問題清單留白或只寫「無問題」— 跨系統整合必有邊界或假設風險，不揭露即失職。
- ❌ 略過執行命令軌跡 — 審查者無法復現或確認驗證覆蓋面。
- ❌ 缺少關聯文件連結 — 下游工程師閱讀報告時無法快速跳轉原始代碼與規格。

