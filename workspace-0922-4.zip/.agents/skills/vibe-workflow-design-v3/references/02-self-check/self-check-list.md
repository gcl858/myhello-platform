# Reference: 28+1 項 Self-Check 清單（v3.0）
# Reference: 35 項 Self-Check 清單（v3.3）

> 對應 SKILL.md Step 7（7.1-7.29；7.27 為 design-explanation 必產檢查）
> 對應 SKILL.md Step 7（7.1-7.35；7.27 為 design-explanation 必產檢查；7.35 為 execution-trace-and-issue-report 必產檢查）
> 透過 SonataFlow Agent Dynamic Script Runner 進行即時全量自動預檢

---

## 完整清單

| # | 檢查項 | 通過條件 | 對應 SKILL 步驟 | 對應預檢 |
|---|---|---|---|---|
| 7.1 | `docs/spec.md §0 假設清單` 含 FQCN 假設（含 H13a validator） | ✅ 每個新 service/validator 都有 FQCN + 落地策略 | Step 1a | — |
| 7.2 | `docs/spec.md §0` 含 `id 命名決策` + 檔名-id Manifest | ✅ snake_case + 檔名≠id 登記，或註明 v1.0 hotfix | Step 1a | 01 |
| 7.3 | `docs/spec.md §0` 含 `convention 決策`（Parent/Child/Saga 分流） | ✅ Parent 舊/新/純 HTTP；Child 僅 finalStatus | Step 1c | 04 |
| 7.4 | OpenAPI spec 的 path param 與 workflow YAML 的 payload 對應 | ✅ 每個 `{xxx}` 都有對應 payload key | Step 6.3 | 03 |
| 7.5 | 直調 actionDataFilter 全部用頂層欄位（subFlowRef 豁免） | ✅ 直調 grep 不到 `.result.X` 配對 | Step 3c | 02 |
| 7.6 | stateDataFilter.output 對應 convention 與層級，且 output key 皆有賦值 | ✅ Parent 舊:`status`；Parent 新:`status: 0/1`+`finalStatus`；Child:僅 `finalStatus`；output 每個 key 至少在一個 inject/operation 被賦值 | Step 3d | 04 |
| 7.7 | Mock sentinel 字串能通過 input validation（A + FAIL_ 豁免為主） | ✅ 設計期實測；B 僅備選 | Step 5b | 06 |
| 7.8 | Mock package 命名（draft 佔位可，註明 rename 映射） | ✅ §8 有 rename 映射或已對齊；DTO 防 `.dto.dto` | Step 5a | — |
| 7.9 | SQL migration V 編號遞增 + db/teardown.sql 回滾腳本 | ✅ 從既有最大 +1；若包含 CREATE VIEW 則 Flyway 腳本內必須於 CREATE 之前加入 DROP VIEW IF EXISTS <view>; (確保可重複套用與更新定義)，且特徵目錄必備含 DROP VIEW IF EXISTS 之 `db/teardown.sql` | Step 4d | — |
| 7.10 | YAML 沒有 trailing comma | ✅ grep 不到 `,$\|,$` 結尾的 list item | Step 6.5 | 05 |
| 7.11 | `config/application.properties.snippet` 配置說明 | ✅ 平台已支援 `platform.status-rewrite.workflows=*` 萬用字元，免手動合入；snippet 僅作自訂參數備忘 | Step 8 | 04 |
| 7.12 | 測試套件包含 P1/A1/P4/B1/B2 五場且 package 命名空間隔離 | ✅ package 為 `com.example.platform.distribution.transfer.features;`；view 查詢加 `status='SUCCESS' ORDER BY id DESC LIMIT 1` | Step 8 | — |
| 7.13 | 測試資料字串能通過 input validation | ✅ 每個測試 payload 都驗過 | Step 6.6 | 06 |
| 7.14 | `docs/spec.md §8` Project Mapping Manifest 完整 | ✅ 映射目標直接為 `project/features/<name>/` 獨立目錄結構 | Step 7 | — |
| 7.15 | `docs/spec.md §9` 已知限制有列 | ✅ v1.0 留白 / 簡化項目都明確標出 | Step 7 | — |
| 7.16 | Input Validation Regex 與 API Sample 相容 | ✅ 通路代碼/欄位正則相容真實範例（如 `2500P`） | Step 1a | 06 |
| 7.17 | 測試案例採用動態唯一序號 | ✅ 正向/反向 `System.nanoTime()`；固定值僅 P1/B2 未入庫路徑 | Step 8 | — |
| 7.18 | jq 條件表達式 `tonumber` 防呆 + null guard | ✅ 用 `tonumber? //` 或 `startswith("FAIL_")` 守衛；所有讀 `.xxx.status` 的 condition 必須帶 `//` 預設值 | Step 3a | 06 |
| 7.19 | Workflow Root 顯式定義 `start`（四類值皆可） | ✅ `ValidateInput/ValidateChildInput/LookupOriginal/Call*`；避免 `getStart() is null` NPE | Step 3a | 01 |
| 7.20 | Service Function 參數鍵值對齊 Java 三入口簽名 | ✅ `workflowId`+`businessKey`；展開/Map/JsonNode，避免 ClassCastException | Step 3b | — |
| 7.21 | OpenAPI Spec `servers[0].url`（建議有，缺失走 fallback 不 FAIL） | ✅ 有則 `http://localhost:8080`；缺則 §0 註明 fallback 鏈 | Step 4 | 09 |
| 7.22 | OpenAPI Spec 欄位約束與 Example/測試 Payload 嚴格相容 | ✅ `maxLength`/`minLength` 覆蓋 example 與真實序號 | Step 2a | 07 |
| 7.23 | 直調 Operation State 若使用 results 必須顯式宣告 `toStateData`（subFlow/終端豁免） | ✅ 防 State Data 沖刷；子流無 filter 屬正常 | Step 3c | 08 |
| 7.24 | 金融工作流程輸入驗證避免原生 `dataInputSchema`（分流見 SKILL 1d） | ✅ Parent-Omni 完整三件套；其餘 Parent/Child 分流 | Step 1d | — |
| 7.25 | Parent 對外入口置於 `specs/internal/` 且含 `x-workflow-id`；host 置於 `specs/external/` 且必無標籤；root 禁放業務 yaml | ✅ Vert.x 動態路由解析；external 零標籤 | Step 2a | 09 |
| 7.26 | subFlowRef version 對齊 child version | ✅ 如 parent 1.0.1 則 subFlow 亦 1.0.1 | Step 6.10 | — |
| 7.27 | `docs/design-explanation.md` 已產出且與 draft 一致（創建者導向，必產） | ✅ 9 節齊全 + 決策/假設/檔案地圖與實際產出一致，無虛構欄位；範例值來自 specs/ example 或測試 payload | Step 8b | — |
| 7.28 | onErrors 覆蓋 + ROLLBACK_FAILED 必告警（見 6.11/10） | ✅ `onErrors` 數 ≥ `operation` 數 −1（terminal 豁免 1 個）；有 `ROLLBACK_FAILED` 終態則必調用 `notifyOps` | Step 6.11 | 10 |
| 7.29 | 業務欄位禁止 literal 硬編碼，衍生欄位須含運算式 | ✅ `currency/BIC/country/address/fee/rate` 一律 `${ .field }`（僅允許 OUR/BEN/A/B/C/R）；`amountInUSD` 類必須含 `fxRate` 運算或 §0 假設註明 | Step 3b | — |
| 7.30 | `feature.yaml` 特徵元資料宣告完整 | ✅ 根目錄含 `feature.yaml`，具備 id, name, version, workflows[], owner | Step 8 | — |
| 7.30 | Workflow `errors:` 區塊宣告與所有 `errorRef` 引用對齊（見 6.12） | ✅ grep 不到「`errorRef: X` 但 `errors:` 沒 X」配對 | Step 6.12 | 11 |
| 7.31 | Workflow 沒有 unreachable 狀態（見 6.13） | ✅ 每個 state 至少有一個 incoming transition（`start:` 或前驅的 `transition` / `dataConditions` / `defaultCondition` / `onErrors`） | Step 6.13 | 12 |
| 7.32 | `notifyOps` arguments 對齊 Java `OpsAlertService.raise` 6 參簽名（見 6.14） | ✅ 含 `workflowId` / `processInstanceId` / `businessKey` / `finalStatus` / `finalMessage` / `detail`；不可用 `inputData` / `outputData` | Step 6.14 | 13 |
| 7.33 | Mock DTO 套件命名對齊 `transfer-mock` 同步目錄 `features/dto/`（見 6.15） | ✅ `package org.acme.transfer.api.features.dto;`（**不可** `org.acme.transfer.api.dto`，會落入 Maven clean 後遺失） | Step 6.15 | 14 |
| 7.34 | View SQL 欄位對齊 `workflow_execution_log` 實體 schema（見 6.16） | ✅ 僅引用實體欄位（`business_key` / `status` / `message` / `input_data` / `output_data` / `cancelled_by` / `cancelled_at`）；業務欄位用 `json_extract(input_data, '$.field')` 拆出 | Step 6.16 | 15 |
| 7.35 | `docs/execution-trace-and-issue-report.md` 已產出且 9 節齊全（詳細執行軌跡與 P0-P3 問題報告，必產） | ✅ 9 節齊全 + 包含真實已執行命令與結果 + P0-P3 問題清單與風險矩陣完整，無虛構全綠 | Step 8c | — |

---

## 自動執行方式 (一鍵完成全量檢測)

在 v3 中，不再需要依賴本地安裝的 Bash、Python、grep 或 awk。直接透過 HTTP API 調用 **Agent Dynamic Script Runner** 執行內置的 `scripts/preflight-checks.js`：

### 方法 1: 調用 POST /api/run-file

```bash
# 0. 先行探測 Runner 健康狀態
curl -s http://127.0.0.1:8091/api/health

# 1. 執行全量預檢
curl -s -X POST http://127.0.0.1:8091/api/run-file \
  -H "Content-Type: application/json" \
  -d '{
    "filePath": ".agents/skills/vibe-workflow-design-v3/scripts/preflight-checks.js",
    "args": {
      "draftDir": "drafts/<feature-name>",
      "targetProject": "project"
    }
  }'
```

### 方法 2: VS Code 介面操作

1. 打開 VS Code 命令選擇區 (`Ctrl+Shift+P` 或 `Cmd+Shift+P`)。
2. 執行 `Sonata Mock: Start` 開啟伺服器。
3. 預檢失敗時，擴充套件會直接在 VS Code **問題（Problems）面板** 標記錯誤行號與紅線，點擊即可直接跳轉修改。
