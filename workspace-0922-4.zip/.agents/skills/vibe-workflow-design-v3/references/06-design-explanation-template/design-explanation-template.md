# Reference 06: design-explanation.md 寫作模板（創建者導向，v2.4 必產）

> 對應 SKILL.md Step 8b + 自查 7.27
> 定位：`docs/spec.md` 是給下游工程師的技術規格；本檔是給**創建者（業務／出資方）**的設計說明。
> 落位：`draft-<name>/docs/design-explanation.md`（v2.4 起改為 `docs/`；與 `docs/spec.md` 同層；進 handoff zip）。

---

## 強制 9 節結構（不可刪節，可加附錄）

```markdown
# <業務名> Workflow Draft — 設計說明書

> 給創建者看的文件：解釋「這份 draft 是怎麼被設計出來的」
> 日期：<YYYY-MM-DD>
> 對應業務書：<檔名> <版本>
> 對應產出：`draft-<name>/`（<N> 個檔案）+ `draft-<name>.zip`
> 目標平台：<SonataFlow 版本>，整合目標 <project>

## 0. 導讀（3 分鐘版）
- 5 點以內：業務要什麼 / 選了什麼模式 / 有幾個檔案 /
  最易誤會的決策 / 還沒確定的事

## 1. 背景與目標
- 痛點表（業務書章節對應）+ draft 目標 + 不做什麼（In/Out-Scope）

## 2. 輸入來源
- 業務書（檔名+版本）+ host API（檔名+版本）+ Step 0 特徵自治架構對齊矩陣

## 3. 從需求到設計
- 業務職責→state 對應表
- 模式選擇理由（為何是 A/B/C/D/E 其中之一，不選其他的原因）
- 回應 convention 決策（舊／新／純 HTTP）+ finalStatus×HTTP 對應表

## 4. 關鍵設計決策（至少 5 條）
每條固定五欄：
- 選了什麼 / 為什麼 / 沒選什麼 / 不這樣做的後果 / 在哪裡看到（檔名+行概念）
必覆蓋：id 命名、convention、驗證策略、sentinel、toStateData/version 任一

## 5. 產出物地圖
- 全部檔案一句話分工（樹狀）+ 檔名-id 對應表

## 6. 流程解說
- 正向走一遍 + 反向走一遍（ASCII 流程即可）
- 測試場景對應表（P1/A1/P4/B1/B2 或等價矩陣：怎麼觸發／預期）

## 7. 假設與待確認
- H1-Hn 精簡為業務語言，只列需人拍板的（含目前暫定值）

## 8. 驗證 + 限制 + 下一步
- 預檢／自查結果（幾項 PASS，有修過什麼 bug）
- 已知限制 + 移交下游對照表（draft 檔 → 正式路徑）
- 附錄：名詞解釋（Parent/Child、subFlowRef、冪等、補償、Audit Gap、FQCN、Sentinel、SSOT）
```

---

## 一致性鐵律（7.27 檢查內容）

1. 提到的每個 id／檔名／欄位／狀態／數字必須與實際產出一致，禁止虛構。
2. 範例值必須來自 `src/specs/ YAML` 的 `example` 或測試 payload。
3. 決策 ≥5 條，必覆蓋：id 命名、convention、驗證策略、sentinel、toStateData/version 任一。
4. 完稿檢查：透過 Agent Runner 驗證章節數 ≥ 9（或由 `scripts/preflight-checks.js` 自動檢查），再人工抽 3 個檔名／id／數字核對。

---

## 反模式

- ❌ 把 `docs/spec.md` 整份複製貼上改個標題 — 創建者要的是「為什麼」，不是第二份規格書。
- ❌ 寫「採用最佳實踐」卻不寫沒選什麼 — 沒有 trade-off 的決策不可信。
- ❌ 範例值憑空編（如 `partyId: P001`）— 必須用 `src/specs/` 的真實 example。
- ❌ 不寫待確認事項 — 假設不寫下來，驗收時就是返工。
