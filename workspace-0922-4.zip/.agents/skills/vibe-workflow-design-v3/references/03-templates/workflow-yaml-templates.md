# Reference: 5 種 Workflow YAML 範本（v2.1：A/B/C 生產可用；D/E 實驗性）

> 對應 SKILL.md Step 3b + 7.6/7.19
> ⚠️ D/E 在 project-0825-pd 20 workflow 零實例（零 event state），屬實驗性，生產前需先驗證。Child End 僅 finalStatus、Saga 用 status/message 分流已納入 A/B 模板註解。

---

## 範本 A:單層 Saga LIFO (Forward 3 階段 + 反向補償)

**適用**:電商訂單、保險出單、任何線性多階段業務

**完整範例**:見 `examples/02-ecommerce-order/src/order-fulfillment.sw.yaml`

**最小骨架**:

```yaml
id: <workflow_id>              # ⭐ snake_case
version: '1.0.0'
specVersion: '0.8'
metadata:
  pattern: saga-lifo-compensation
errors:
  - name: platformError
    code: 'PLATFORM_ERROR'
functions:
  - name: callApiViaOpenAPI
    operation: 'service:com.example.transfer.workflow.MyOpenApiService::callOpenApi'
    type: custom
  - name: recordAuditLog
    operation: 'service:com.example.reconciliation.AuditLogService::saveLog'
    type: custom
states:
  - name: ValidateInput
    type: switch
    dataConditions: [...]
    defaultCondition: { transition: Stage1Forward }
  
  - name: Stage1Forward
    type: operation
    actions:
      - functionRef: { refName: callApiViaOpenAPI, arguments: { ... } }
        actionDataFilter: { toStateData: '${ .stage1Result }', results: '{...}' }
    onErrors:
      - errorRef: platformError
        transition: TerminalNoRollback
    transition: CheckStage1
  
  - name: CheckStage1
    type: switch
    dataConditions:
      - condition: '${ .stage1Result.success == true }'
        transition: Stage2Forward
    defaultCondition: { transition: TerminalNoRollback }   # Stage 1 失敗,無需 rollback
  
  # ... Stage 2, Stage 3 類似
  
  # LIFO Rollback 順序:Stage3 fail → rollback Stage2 → Stage1
  - name: RollbackStage2AndStage1
    type: operation
    actions: [...]
    onErrors:
      - errorRef: platformError
        transition: TerminalRollbackCompleted
    transition: RollbackStage1
  
  - name: RollbackStage1
    type: operation
    actions: [...]
    onErrors:
      - errorRef: platformError
        transition: TerminalRollbackCompleted
    transition: TerminalRollbackCompleted
  
  - name: TerminalSuccess
    type: inject
    data: { finalStatus: SUCCESS }
    transition: End
  
  - name: TerminalNoRollback
    type: inject
    data: { finalStatus: FAILED }
    transition: End
  
  - name: TerminalRollbackCompleted
    type: inject
    data: { finalStatus: ROLLBACK_FAILED }
    transition: End
  
  - name: End
    type: operation
    actions: [{ functionRef: { refName: recordAuditLog, ... } }]
    stateDataFilter: { output: '...' }   # ⭐ convention 對齊
    end: true
```

---

## 範本 B:Parent + 2 Child Subflow

**適用**:多入口業務 (建立 / 取消 / 查詢),有獨立子流程

**完整範例**:見 `examples/01-financial-repayment/src/omni-cash-transaction.sw.yaml`

**最小骨架**:

```yaml
id: <parent_workflow_id>       # ⭐ snake_case
version: '1.0.0'
specVersion: '0.8'
metadata:
  pattern: parent-with-2-children
errors:
  - name: platformError
    code: 'PLATFORM_ERROR'
functions:
  - name: callApiViaOpenAPI
    operation: 'service:com.example.transfer.workflow.MyOpenApiService::callOpenApi'
    type: custom
  - name: checkIdempotency
    operation: 'service:com.example.reconciliation.IdempotencyService::findBySequenceNumber'
    type: custom
  - name: recordAuditLog
    operation: 'service:com.example.reconciliation.AuditLogService::saveLog'
    type: custom
states:
  - name: ValidateInput
    type: switch
    dataConditions: [...]
    defaultCondition: { transition: CheckIdempotency }
  
  - name: CheckIdempotency
    type: operation
    actions:
      - functionRef:
          refName: checkIdempotency
          arguments:
            workflowId: <parent_workflow_id>
            businessKey: '${ .sequenceNumber }'   # ⭐ 平台標準 2 參數契約
        actionDataFilter:
          toStateData: '${ .idempotencyResult }'
          results: '{idempotentReplay: .idempotentReplay, priorResult: .priorResult}'
    onErrors:
      - errorRef: platformError
        transition: InjectWorkflowFailedStatus
    transition: CheckIdempotencyResult
  
  - name: CheckIdempotencyResult
    type: switch
    dataConditions:
      - condition: '${ .idempotentReplay == true }'
        transition: OutputFinal
    defaultCondition: { transition: DispatchAction }

  - name: DispatchAction
    type: switch
    dataConditions:
      - condition: '${ .action == "NEW" }'
        transition: InvokeChildA
      - condition: '${ .action == "CANCEL" }'
        transition: InvokeChildB
    defaultCondition: { transition: TerminalValidationError }
  
  # ⭐ subFlowRef 亦必須宣告 onErrors，避免子流程或引擎異常拋出時造成 Audit Gap
  - name: InvokeChildA
    type: operation
    actions:
      - subFlowRef:
          workflowId: <child_a_workflow_id>   # ⭐ snake_case
          version: '1.0.0'
    onErrors:
      - errorRef: platformError
        transition: InjectWorkflowFailedStatus
    transition: OutputFinal
  
  - name: InvokeChildB
    type: operation
    actions:
      - subFlowRef:
          workflowId: <child_b_workflow_id>
          version: '1.0.0'
    onErrors:
      - errorRef: platformError
        transition: InjectWorkflowFailedStatus
    transition: OutputFinal
  
  - name: TerminalValidationError
    type: inject
    data:
      finalStatus: REJECTED_VALIDATION
      status: 1
    transition: OutputFinal

  - name: InjectWorkflowFailedStatus
    type: inject
    data:
      finalStatus: FAILED
      status: 1
    transition: OutputFinal

  - name: OutputFinal
    type: operation
    actions: [{ functionRef: { refName: recordAuditLog, ... } }]
    stateDataFilter: { output: '...' }   # ⭐ convention
    end: true
```

**子流程範本** (Child A — 獨立正向 workflow):

```yaml
id: <child_a_workflow_id>      # ⭐ snake_case
version: '1.0.0'
specVersion: '0.8'
metadata:
  pattern: child-saga-lifo
errors:
  - name: platformError
    code: 'PLATFORM_ERROR'
functions:
  - name: callApiViaOpenAPI
    operation: 'service:com.example.transfer.workflow.MyOpenApiService::callOpenApi'
    type: custom
  - name: recordAuditLog
    operation: 'service:com.example.reconciliation.AuditLogService::saveLog'
    type: custom
states:
  - name: CallStage1
    type: operation
    actions: [{ functionRef: { refName: callApiViaOpenAPI, ... } }]
    onErrors:
      - errorRef: platformError
        transition: FinalizeRollbackFailed
    transition: CheckStage1
  
  - name: CheckStage1
    type: switch
    dataConditions:
      - condition: '${ .stage1Result.success == true }'
        transition: CallStage2
    defaultCondition: { transition: RollbackNoOp }
  
  - name: CallStage2
    type: operation
    actions: [{ functionRef: { refName: callApiViaOpenAPI, ... } }]
    onErrors:
      - errorRef: platformError
        transition: RollbackStage1
    transition: CheckStage2
  
  - name: CheckStage2
    type: switch
    dataConditions:
      - condition: '${ .stage2Result.success == true }'
        transition: FinalizeSuccess
    defaultCondition: { transition: RollbackStage1 }
  
  - name: RollbackStage1
    type: operation
    actions: [{ functionRef: { refName: callApiViaOpenAPI, ... } }]
    onErrors:
      - errorRef: platformError
        transition: FinalizeRollbackFailed
    transition: FinalizeRollbackFailed
  
  - name: FinalizeSuccess
    type: inject
    data: { finalStatus: SUCCESS }
    transition: End
  
  # ... FinalizeFailed, FinalizeRollbackFailed, RollbackNoOp, End 等 state 同 A 範本
```

**子流程範本** (Child B — 獨立逆向/取消 workflow，階梯式 Switch 模式):

```yaml
id: <child_b_workflow_id>      # ⭐ snake_case
version: '1.0.0'
specVersion: '0.8'
metadata:
  pattern: child-cancellation
errors:
  - name: platformError
    code: 'PLATFORM_ERROR'
functions:
  - name: lookupOriginalTransaction
    operation: 'service:com.example.reconciliation.AuditLogService::findBySequenceNumber'
    type: custom
  - name: markOriginalCancelled
    operation: 'service:com.example.reconciliation.AuditLogService::markCancelledBy'
    type: custom
  - name: callApiViaOpenAPI
    operation: 'service:com.example.transfer.workflow.MyOpenApiService::callOpenApi'
    type: custom
  - name: recordAuditLog
    operation: 'service:com.example.reconciliation.AuditLogService::saveLog'
    type: custom
states:
  - name: LookupOriginal
    type: operation
    actions:
      - functionRef:
          refName: lookupOriginalTransaction
          arguments:
            workflowId: <child_a_workflow_id>   # ⭐ 鐵律：查原交易必須傳正向 child id！
            businessKey: '${ .originalSequenceNumber }'
        actionDataFilter:
          toStateData: '${ .originalResult }'
          results: '{found: .found, originalStatus: .status, originalFinalStatus: .originalFinalStatus, cancelledBy: .cancelledBy}'
    onErrors:
      - errorRef: platformError
        transition: FinalizeLookupFailed
    transition: CheckOriginalExists

  # ⭐ 階梯式 Switch 模式 Step 1: 僅判斷實體是否存在
  - name: CheckOriginalExists
    type: switch
    dataConditions:
      - name: notFound
        condition: '${ .originalResult.found != true }'
        transition: FinalizeLookupFailed
    defaultCondition:
      transition: CheckOriginalCancellable

  # ⭐ 階梯式 Switch 模式 Step 2: 僅判斷實體業務狀態是否允許操作（支援 0 / SUCCESS 雙軌相容）
  - name: CheckOriginalCancellable
    type: switch
    dataConditions:
      - name: notCancellable
        condition: >
          ${ ((.originalResult.originalStatus // "") | tostring) != "SUCCESS"
             and ((.originalResult.originalStatus // "") | tostring) != "0"
             or .originalResult.cancelledBy != null }
        transition: FinalizeCancelRejected
    defaultCondition:
      transition: CancelStage1

---

## 範本 C:多層 Parent (審批流)

**適用**:多層級審批、多階段業務流

**結構**:Parent 委派給另一個 Parent,而不是直接到 Child

```yaml
id: <level1_parent_id>
metadata:
  pattern: multi-level-parent
states:
  - name: ValidateInput
    type: switch
    dataConditions: [...]
    defaultCondition: { transition: SubmitToL2 }
  
  - name: SubmitToL2
    type: operation
    actions:
      - subFlowRef:
          workflowId: <level2_parent_id>     # ⭐ 委派給 L2 Parent
          version: '1.0.0'
    transition: OutputFinal
  
  # ... OutputFinal
```

```yaml
# L2 Parent
id: <level2_parent_id>
metadata:
  pattern: multi-level-parent
states:
  - name: ManagerReview
    type: operation
    actions: [{ functionRef: { refName: managerReview, ... } }]
    transition: CheckManagerResult
  
  - name: CheckManagerResult
    type: switch
    dataConditions:
      - condition: '${ .managerResult.approved == true }'
        transition: SubmitToL3
    defaultCondition: { transition: TerminalRejected }
  
  - name: SubmitToL3
    type: operation
    actions:
      - subFlowRef:
          workflowId: <level3_parent_id>     # 委派給 L3
          version: '1.0.0'
    transition: OutputFinal
```

---

## 範本 D:事件驅動 (Event Listener，實驗性 ⚠️)

**適用**:接收外部事件觸發 (e.g., Kafka topic, AMQP message)
**狀態**:實驗性 — project-0825-pd 零實例，照搬前先跑最小 PoC 驗證 Kogito event 註冊。

```yaml
id: <event_driven_id>
metadata:
  pattern: event-driven
events:
  - name: orderCreatedEvent
    source: 'kafka:orders.created'
    type: kafka
states:
  - name: WaitForEvent
    type: event
    onEvents:
      - eventRefs:
          - orderCreatedEvent
        eventConditions:
          - condition: '${ .event.type == "ORDER_CREATED" }'
        transition: ProcessEvent
    timeouts:
      eventTimeout: PT1H   # 1 小時內無事件就放棄
  
  - name: ProcessEvent
    type: operation
    actions:
      - functionRef: { refName: processOrder, ... }
    transition: OutputFinal
```

---

## 範本 E:計時 / 排程 (Timer Trigger，實驗性 ⚠️)

**適用**:排程觸發的批次處理、定時對帳
**狀態**:實驗性 — 同 D，需先驗證 `schedules/cron` 在 Kogito 10.2.0 行為。

```yaml
id: <timer_driven_id>
metadata:
  pattern: timer-scheduled
schedules:
  - name: dailyReconciliation
    cron: '0 2 * * *'    # 每天凌晨 2 點
states:
  - name: RunReconciliation
    type: operation
    actions:
      - functionRef: { refName: reconcile, ... }
    transition: OutputFinal
```

---

## 選用範本的決策樹

```
問:業務有多少「入口」(action type)?
├─ 1 個 (固定流程)
│   └─ 用範本 A (單層 Saga LIFO)
│
├─ 2 個 (e.g., NEW / CANCEL)
│   ├─ 取消是流程內 state 切換 → 範本 A
│   └─ 取消是獨立入口 → 範本 B (Parent + 2 Child)
│
├─ 3 個以上 (e.g., NEW / CANCEL / QUERY / UPDATE)
│   └─ 用範本 B + 在 DispatchAction 加更多 dataConditions
│
└─ 觸發方式是?
    ├─ 外部 HTTP/REST → 範本 A 或 B
    ├─ 外部事件 (Kafka/AMQP) → 範本 D
    └─ 排程 (Cron) → 範本 E

問:有幾個審批層級?
├─ 0 (無審批) → 範本 A 或 B
├─ 1 (單一層) → 範本 A (內含審批 state)
└─ 2+ (多層) → 範本 C
```
