# Reference 01: Workflow ID Naming (Kogito 10.2.0 Compatibility)

> 對應 SKILL.md Step 6.1 預檢
> 來源:`INTEGRATION-PRACTICE.md` 問題 1

---

## 規則

| 環境 | workflow id 命名 | 範例 |
|---|---|---|
| Kogito 10.2.0 + 含 `subFlowRef` | **必用 snake_case** | `omni_cash_transaction` ✅ |
| Kogito 10.2.0 + 無 `subFlowRef` | snake_case 或 kebab-case 都可 | `order_fulfillment` ✅ / `order-fulfillment` ✅ |
| Kogito 10.3+ (假設 bug 修好) | kebab-case 推薦 (符合 Serverless Workflow 慣例) | `omni-cash-transaction` ✅ |
| 其他 workflow engine (Camunda/Airflow) | 看該 engine 規範 | — |

---

## 自動檢查（透過 Agent Dynamic Script Runner）

直接調用 SonataFlow Mock 伺服器的動態腳本執行端點 (`http://127.0.0.1:8091/api/run`)，自動解析 YAML 並於 VS Code 問題面板標註紅線：

```bash
curl -s -X POST http://127.0.0.1:8091/api/run \
  -H "Content-Type: application/json" \
  -d '{
    "script": "const targetDir = path.join(workspaceRoot, args.draftDir || \"draft/src\"); const files = fs.readdirSync(targetDir).filter(f => f.endsWith(\".sw.yaml\")); let fail = false; for (const file of files) { const filePath = path.join(targetDir, file); const content = fs.readFileSync(filePath, \"utf8\"); if (content.includes(\"subFlowRef\")) { const wf = helpers.parseYaml(content); if (wf.id && wf.id.includes(\"-\")) { fail = true; console.log(`❌ FAIL: ${file} workflow id \"${wf.id}\" 含連字號，會觸發 Kogito 10.2.0 codegen bug！`); helpers.addDiagnostic(filePath, 1, 1, `Workflow id \"${wf.id}\" 含連字號，請改為 snake_case (e.g., ${wf.id.replace(/-/g, \"_\")})`, \"error\"); } else { console.log(`✅ PASS: ${file} (id=${wf.id})`); helpers.clearDiagnostics(filePath); } } else { console.log(`ℹ️ SKIP: ${file} (無 subFlowRef)`); } } return { success: !fail };",
    "args": { "draftDir": "draft/src" }
  }'
```

---

## 已知症狀 (若沒避開)

```
[ERROR] org.kie.memorycompiler.KieMemoryCompilerException:
[org/kie/kogito/serverless/Omni_cash_transactionProcess.java (16:109) : ';' expected

產出的 Java 程式碼:
@Inject @Named("repayment-cash-cancellation")
org.kie.kogito.process.Process<...> processrepayment-cash-cancellation;
//                                  ^^^^^^^^^^^^^^^^^^^^^^^^^^^
```

---

## spec.md 標註範本

若業務方強制要求 hyphen,須在 spec.md §0 加註:

```markdown
| H15 | **ID 命名**: 業務要求 kebab-case (omni-cash-transaction) | Kogito 10.2.0 codegen bug 規避 | 整合階段會改名為 snake_case | 須通知 API 消費者 breaking change |
```

並在 §7 已知限制列出:

```markdown
- 對外 API path 從 hyphen 改為 underscore (Kogito 10.2.0 bug 規避)
- 業務書命名為 `omni-cash-transaction`,整合後實際為 `omni_cash_transaction`
```

---

## 修復清單 (若發現 bug，9 處同步)

改名時,以下檔案要**同步**改:

1. workflow YAML 內的 `id:` 與 `subFlowRef.workflowId`（注意 `subFlowRef version` 須同步等於 child version，見 SKILL 6.10）
2. `subFlowRef version`（如 omni parent 1.0.1 則 subFlow 亦 1.0.1，不可殘留 1.0）
3. application.properties 內 `status-rewrite.workflows`
4. 測試類別的 `PARENT_URL` 與 `sequenceNumber` 前綴
5. SQL view 的 `WHERE workflow_id IN (...)`（需 drop & recreate，因 `IF NOT EXISTS` 不重建；下游見 sonataflow-integration 6d）
6. spec.md §0（含檔名-id Manifest 行）與 §8 Project Mapping Manifest
7. （v2.0 已廢除手動複製）UI 規格已由 WorkflowSpecResource 原位動態探索，無需複製到 `data/workflows/`
8. （v3.0 已自動化）透過 pom.xml Ant overlay 自動動態匯入，無需手動複製到 `transfer-app/src/main/resources`
9. README 與所有引用（含 `x-workflow-id` 值）

檔名≠id 視為合法（如 `omni-cash-transaction.sw.yaml:id omni_cash_transaction`），不強改檔名，以 Manifest 登記為準。

漏掉任一處 → E2E 0 筆資料、查詢回空、編譯過但 runtime 失敗。
