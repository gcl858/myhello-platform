# Reference 03: Path Parameter 自動注入

> 對應 SKILL.md Step 6.3 預檢
> 來源:`INTEGRATION-PRACTICE.md` 問題 3

---

## 規則

任何 `callApiViaOpenAPI` 動作呼叫的 spec,若 operation 內有 `parameters: [in: path]`,**必須**在 payload 內顯式提供對應 key。

---

## 自動檢查（透過 Agent Dynamic Script Runner）

透過 Runner 自動讀取工作流程中的 `schemaRef`，載入對應 OpenAPI YAML（`src/specs/external/` 或 `internal/`），分析其 path parameters 並比對 payload 欄位：

```bash
curl -s -X POST http://127.0.0.1:8091/api/run \
  -H "Content-Type: application/json" \
  -d '{
    "script": "const draftRoot = path.join(workspaceRoot, args.draftDir || \"draft\"); const swDir = path.join(draftRoot, \"src\"); const files = fs.readdirSync(swDir).filter(f => f.endsWith(\".sw.yaml\")); let fail = false; for (const file of files) { const filePath = path.join(swDir, file); const wf = helpers.parseYaml(fs.readFileSync(filePath, \"utf8\")); for (const state of (wf.states || [])) { for (const act of (state.actions || [])) { const fnRef = act.functionRef; if (fnRef && fnRef.arguments && fnRef.arguments.schemaRef) { const [relSpec, opId] = String(fnRef.arguments.schemaRef).split(\"#\"); const specPath = path.join(draftRoot, \"src\", relSpec); if (!fs.existsSync(specPath)) { console.log(`❌ FAIL: 找不到 spec 檔案: ${specPath}`); fail = true; continue; } const spec = helpers.parseYaml(fs.readFileSync(specPath, \"utf8\")); const pathParams = []; for (const pMethods of Object.values(spec.paths || {})) { for (const op of Object.values(pMethods || {})) { if (op && op.operationId === opId && Array.isArray(op.parameters)) { for (const p of op.parameters) if (p.in === \"path\") pathParams.push(p.name); } } } const payload = fnRef.arguments.payload || {}; for (const p of pathParams) { if (!(p in payload)) { fail = true; console.log(`❌ FAIL: ${file} 狀態 \"${state.name}\" 的操作 \"${opId}\" 缺少 path parameter: \"${p}\"`); helpers.addDiagnostic(filePath, 1, 1, `操作 \"${opId}\" 缺少 URL Path Parameter \"${p}\"，必須在 payload 顯式提供`, \"error\"); } else { console.log(`✅ PASS: ${file} -> ${opId} path param \"${p}\" 已注入`); } } } } } } return { success: !fail };",
    "args": { "draftDir": "draft" }
  }'
```

---

## 範例:對的寫法

OpenAPI spec:

```yaml
/CoreAccount/{creditcardid}/CashDeposit/Execute:
  post:
    operationId: executeCoreCashDeposit
    parameters:
      - name: creditcardid
        in: path                  # ⭐ path param
        required: true
        schema:
          type: string
```

對應 workflow YAML:

```yaml
- functionRef:
    refName: callApiViaOpenAPI
    arguments:
      functionName: "callApiViaOpenAPI"
      schemaRef: 'specs/external/core-account-cash-deposit-api.yaml#executeCoreCashDeposit'
      payload:
        creditcardid: '${ .partyId }'    # ⭐ 必顯式帶
        partyId: '${ .partyId }'
        branchCode: '${ .branchCode }'
        amount: '${ .amount }'
        sequenceNumber: '${ .sequenceNumber }'
        operationType: '${ .operationType }'
```

---

## 症狀:沒帶 path param 會怎樣?

```
ERROR ... 目標路徑有不合法的字元:
http://localhost:8080/CoreAccount/{creditcardid}/CashDeposit/Execute
```

`MyOpenApiService` 把 `{creditcardid}` 留作字面值,沒替換成實際值 → HTTP client 拒絕傳送。

---

## 為何 MyOpenApiService 不自動從 payload 抓 path param?

理論上可行 (從 spec 解析 path,看哪些是 `{xxx}`,然後從 payload 抓 `xxx` 對應值),但有兩個原因不做:

1. **效能**:每次都要解析 spec,影響 latency
2. **明確性**:workflow author 應該明確知道哪些欄位會被用於 URL,不該「魔法」自動綁定

所以這個責任放在 workflow author,必須在 payload 顯式帶。

---

## 對應值怎麼選?

從 input data 推導。常見對應:

| Path param | 通常對應 input 欄位 |
|---|---|
| `{creditcardid}` | `.partyId` 或 `.customerId` |
| `{orderId}` | `.orderId` |
| `{userId}` | `.userId` |
| `{accountId}` | `.accountId` |
| `{transactionId}` | `.sequenceNumber` 或 `.originalSequenceNumber` |

若有疑慮,看 input schema 哪個欄位語意最接近,或問業務方。
