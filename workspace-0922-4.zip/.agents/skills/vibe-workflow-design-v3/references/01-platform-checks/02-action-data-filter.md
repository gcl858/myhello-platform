# Reference 02: actionDataFilter 結構守則 (MyOpenApiService 相容性)

> 對應 SKILL.md Step 3c + Step 6.2 預檢
> 來源:`INTEGRATION-PRACTICE.md` 問題 4

---

## 核心規則

`MyOpenApiService::callOpenApi` 的回傳結構是**頂層欄位**,**不是 `.result` 底下**。

```json
// MyOpenApiService::callOpenApi 回傳
{
  "code": "100",                    // 業務碼 (頂層)
  "message": "SUCCESS",
  "trackId": "xxx",
  "errorType": null,
  "_httpStatus": 200,
  "errors": null,
  "sequenceNumber": "SEQ_xxx"
  // 注意:沒有 .result wrapper
}
```

---

## ✅ 對的寫法

```yaml
- functionRef:
    refName: callApiViaOpenAPI
    arguments:
      functionName: "callApiViaOpenAPI"
      schemaRef: 'specs/<host>.yaml#<operation>'
      payload:
        <path_param>: '${ .對應欄位 }'
        ...
  actionDataFilter:
    results: '{status: .code, message: .message, trackId: .trackId, errorType: .errorType, _httpStatus: ._httpStatus}'
```

---

## ❌ 錯的寫法

```yaml
- functionRef:
    refName: callApiViaOpenAPI
    arguments:
      ...
  actionDataFilter:
    results: '{status: .result.code, message: .result.message}'   # ❌ .result 不存在
```

症狀:mock 回 200 但 workflow 仍走 FAILED,因為 `.result.code` 是 null。

---

## 邊界情況:host API response 有 sub-object

若 host API response 是 `{"status": 0, "result": {"sequenceNumber": "xxx"}}`,對應 jpath:

```yaml
# ✅ 對:sub-object 內的欄位直接寫進 results,不要包 .result
results: '{status: .status, sequenceNumber: .result.sequenceNumber}'
```

**不要**這樣寫:

```yaml
# ❌ 錯:把 .result 當成 wrapper
results: '{status: .result.status, sequenceNumber: .result.sequenceNumber}'
```

---

## 自動檢查（透過 Agent Dynamic Script Runner）

透過 Runner 調用內置 YAML 解析與 AST 遍歷，檢查 `actionDataFilter.results` 是否存在非法 `.result.X` 存取：

```bash
curl -s -X POST http://127.0.0.1:8091/api/run \
  -H "Content-Type: application/json" \
  -d '{
    "script": "const targetDir = path.join(workspaceRoot, args.draftDir || \"draft/src\"); const files = fs.readdirSync(targetDir).filter(f => f.endsWith(\".sw.yaml\")); let fail = false; for (const file of files) { const filePath = path.join(targetDir, file); const content = fs.readFileSync(filePath, \"utf8\"); const wf = helpers.parseYaml(content); let fileHasBad = false; for (const state of (wf.states || [])) { if (state.type === \"operation\" && state.actions) { for (const act of state.actions) { if (act.actionDataFilter && act.actionDataFilter.results) { const match = String(act.actionDataFilter.results).match(/\\.result\\.[a-zA-Z_]+/g); if (match) { fileHasBad = true; fail = true; console.log(`❌ FAIL: ${file} 狀態 \"${state.name}\" actionDataFilter 誤用 .result: ${match.join(\", \")}`); helpers.addDiagnostic(filePath, 1, 1, `actionDataFilter 誤用了 .result: ${match.join(\", \")}，請改為頂層欄位存取`, \"error\"); } } } } } if (!fileHasBad) { console.log(`✅ PASS: ${file}`); helpers.clearDiagnostics(filePath); } } return { success: !fail };",
    "args": { "draftDir": "draft/src" }
  }'
```

---

## 為何 MyOpenApiService 是頂層結構?

`MyOpenApiService::callOpenApi` 的實作 (簡化版):

```java
public JsonNode callOpenApi(String schemaRef, JsonNode payload) {
    // 1. 解析 spec
    // 2. 呼叫 host API
    // 3. 把 host response 攤平到頂層 + 加 metadata
    ObjectNode result = mapper.createObjectNode();
    result.set("code", hostResponse.get("code"));      // 攤平
    result.set("message", hostResponse.get("message"));// 攤平
    result.set("_httpStatus", httpStatus);             // 加上 metadata
    result.set("errorType", errorType);
    return result;
}
```

**沒有 .result wrapper**,這是 design decision:讓 workflow author 直接用 jpath 讀欄位,不需要再剝一層。

但 OpenAPI spec 的 `result` sub-object 若有,workflow 仍可透過 `.result.<field>` 訪問 — 那是 host API 自己的結構。

---

## 常見錯誤模式

| 錯的 jpath | 原因 | 正確 |
|---|---|---|
| `.result.code` | 假設有 .result wrapper | `.code` |
| `.result.status` | 同上 | `.status` (若 host response 有) |
| `.result.message` | 同上 | `.message` |
| `.body.code` | 假設有 .body wrapper (HTTP client 風格) | `.code` |
| `.data.code` | 假設有 .data wrapper (GraphQL 風格) | `.code` |
