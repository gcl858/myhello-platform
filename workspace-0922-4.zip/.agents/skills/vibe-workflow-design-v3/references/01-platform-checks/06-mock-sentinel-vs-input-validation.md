# Reference 06: Mock Sentinel vs Input Validation 相容性（A 為主 + validator 豁免）

> 對應 SKILL.md Step 5b + Step 6.6 預檢 + 7.7
> 實況：project-0825-pd 全庫 Mode A，`__sentinel` 零使用；`OpenApiSchemaValidator` 已有 `FAIL_` 豁免

---

## 規則（實況主力為 A）

任何 mock 用來觸發「業務拒絕 / 失敗」的 sentinel 字串,**必須能通過 input schema 的 validation**。預設用模式 A + validator 豁免 + jq 守衛；模式 B 僅當 regex 絕對不可動時備選。

---

## 2 種 Sentinel 模式

### 模式 A:業務 payload 內字串前綴

```java
// Mock resource
if (request.amount.startsWith("FAIL_")) {
    return Response.status(403).entity(buildError("E0024", "金額不符", null)).build();
}
```

**前提**:input schema 的 `amount` 欄位 regex 須允許 `FAIL_*`:

```json
"amount": {
  "type": "string",
  "pattern": "^(FAIL_[A-Z0-9_]+|[0-9]+)$"   // ⭐ 允許 FAIL_* 或純數字
}
```

**優點**:測試 payload 簡潔
**缺點**:放寬 regex 可能讓真實攻擊面增加

---

### 模式 B:獨立 sentinel field

```java
// Mock resource
if ("FAIL_AMT".equals(request.__sentinel)) {
    return Response.status(403).entity(buildError("E0024", "金額不符", null)).build();
}
```

對應 input schema 加:

```json
"__sentinel": {
  "type": "string",
  "description": "測試專用哨兵,真實 API 不會傳入"
}
```

**優點**:不汙染業務 regex
**缺點**:每個測試 payload 都要多帶一個欄位

---

## 自動檢查（透過 Agent Dynamic Script Runner）

透過 Runner 掃描 Mock Java 檔案萃取所有 sentinel 字串，並比對 OpenAPI specs（`src/specs/internal/*.yaml` 與 `external/*.yaml`）內的 schema 正則：

```bash
curl -s -X POST http://127.0.0.1:8091/api/run \
  -H "Content-Type: application/json" \
  -d '{
    "script": "const draftRoot = path.join(workspaceRoot, args.draftDir || \"draft\"); const mockDir = path.join(draftRoot, \"src/mocks\"); const mockFiles = fs.existsSync(mockDir) ? fs.readdirSync(mockDir).filter(f => f.endsWith(\".java\")) : []; const sentinels = new Set(); for (const mf of mockFiles) { const txt = fs.readFileSync(path.join(mockDir, mf), \"utf8\"); const matches = txt.match(/\"(FAIL_[A-Za-z0-9_]+|RBFAIL|[0-9]{10})\"/g); if (matches) matches.forEach(m => sentinels.add(m.replace(/\"/g, \"\"))); } console.log(\"ℹ️ Mock 哨兵清單:\", Array.from(sentinels)); const specDirs = [path.join(draftRoot, \"src/specs/internal\"), path.join(draftRoot, \"src/specs/external\")]; const patterns = []; for (const d of specDirs) { if (!fs.existsSync(d)) continue; for (const sf of fs.readdirSync(d).filter(f => f.endsWith(\".yaml\"))) { const spec = helpers.parseYaml(fs.readFileSync(path.join(d, sf), \"utf8\")); function walk(props) { for (const [k, v] of Object.entries(props || {})) { if (v && v.pattern) patterns.push({ file: sf, field: k, pattern: v.pattern }); } } for (const s of Object.values(spec.components?.schemas || {})) walk(s.properties); } } console.log(\"📋 檢查到之驗證正則:\", patterns); return { sentinels: Array.from(sentinels), patterns };",
    "args": { "draftDir": "draft" }
  }'
```

---

## 真實案例:衝突的設計 (INTEGRATION-PRACTICE.md 問題 7)

```json
// input schema
"amount": {
  "type": "string",
  "pattern": "^[0-9]+$"   // 嚴格,只允許純數字
}
```

```java
// mock 原意:FAIL_000011758 觸發業務拒絕
if (request.amount.startsWith("FAIL_")) {
    return Response.status(403).entity(buildError("E0024", "金額不符", null)).build();
}
```

**衝突**:`FAIL_000011758` 不符合 `^[0-9]+$`,在 input validation 階段就被攔截,根本到不了 mock。

### 陷阱 2: jq `tonumber` 遇到 Sentinel 字串導致 Runtime Exception

**症狀**: 當使用 `amount: "FAIL_000011758"` 作為哨兵時，workflow switch 狀態條件 `($a | tonumber) <= 0` 拋出 jq 例外，導致整個 switch state 異常、`finalStatus` 變成 `null`。

**根因**: jq 的 `tonumber` 無法解析 `FAIL_...`，直接拋錯中斷執行。

**安全寫法**:
```yaml
# ❌ 錯誤寫法 (遇到 FAIL_ 拋錯)
condition: '${ ((.amount // "") as $a | ($a == "0" or ($a | tonumber) <= 0)) }'

# ✅ 安全寫法 1: 排除 FAIL_ 前綴後再轉數字
condition: '${ ((.amount // "") as $a | ($a == "0" or $a == "0000000000" or (($a | startswith("FAIL_") | not) and ($a | tonumber) <= 0))) }'

# ✅ 安全寫法 2: 使用 jq safe tonumber 運算子
condition: '${ ((.amount // "") as $a | ($a == "0" or (($a | tonumber? // 1) <= 0))) }'
```

---

## spec.md 標註範本

```markdown
| H17 | **Mock sentinel**: 用 amount=0000000000 觸發業務拒絕 | input regex 嚴格,不允許 FAIL_* | 業務方確認 0=拒絕 | Mock resource 內 if (request.amount == "0" || ...) |
```

---

## 為何不在 schema 層加寬鬆規則就好?

理論上可以,但實務上:

1. **資安風險**:regex 放寬,攻擊面增加 (例如 SQL injection)
2. **可讀性差**:其他人看 regex 會疑惑為何 `FAIL_*` 算合法
3. **耦合性高**:schema 規則跟 mock 行為耦合,改 regex 會影響 mock 行為

用**獨立 sentinel field** 是最乾淨的做法,例如 `__sentinel: "FAIL_AMT"` 明確標示「這是測試用」。
