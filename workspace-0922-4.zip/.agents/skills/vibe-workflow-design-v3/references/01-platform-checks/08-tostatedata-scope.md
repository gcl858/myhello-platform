# Reference 08: toStateData 作用域（直調才查，子流豁免）

> 對應 SKILL.md Step 3c 鐵律 2 + Step 6.8 + 7.23
> 來源：project-0825-pd 20 workflow 實況（12 subFlow 全無 actionDataFilter 屬正常）

---

## 規則

- 直調 `functionRef`（`callApiViaOpenAPI/checkIdempotency/lookup*/validate*`）若有 `results` 必有 `toStateData: '${ .xxxResult }'`。
- 豁免（不 FAIL）：
  1. `subFlowRef` invoke（`actions: [{ subFlowRef: ... }]`，實況 12 處全無 filter）
  2. terminal `recordAuditLog`（child End 8 處無 filter 屬正常）
  3. `MarkOriginalCancelled` 非關鍵路徑（5 處無 toStateData 可免，僅 repayment-cancellation 有 `${ .markResult }` 屬加分）

---

## 自動檢查（透過 Agent Dynamic Script Runner）

透過 Runner 解析 Workflow AST，精準識別直調與子流呼叫，檢查是否在需要處宣告了 `toStateData`，防止流程狀態遭意外覆寫：

```bash
curl -s -X POST http://127.0.0.1:8091/api/run \
  -H "Content-Type: application/json" \
  -d '{
    "script": "const targetDir = path.join(workspaceRoot, args.draftDir || \"draft/src\"); const files = fs.readdirSync(targetDir).filter(f => f.endsWith(\".sw.yaml\")); let fail = false; for (const file of files) { const filePath = path.join(targetDir, file); const wf = helpers.parseYaml(fs.readFileSync(filePath, \"utf8\")); let fileHasFail = false; for (const state of (wf.states || [])) { if (state.type === \"operation\" && state.actions) { for (const act of state.actions) { if (act.functionRef && act.actionDataFilter && act.actionDataFilter.results) { const isSubFlow = Boolean(act.subFlowRef); const isTerminalAudit = act.functionRef.refName === \"recordAuditLog\"; if (!isSubFlow && !isTerminalAudit && !act.actionDataFilter.toStateData) { fileHasFail = true; fail = true; console.log(`❌ FAIL: ${file} 狀態 \"${state.name}\" 直調缺少 toStateData`); helpers.addDiagnostic(filePath, 1, 1, `狀態 \"${state.name}\" 的直調 actionDataFilter 缺少 toStateData，會造成輸入 Payload 被覆寫！`, \"error\"); } } } } } if (!fileHasFail) { console.log(`✅ PASS: ${file} toStateData 宣告健全`); helpers.clearDiagnostics(filePath); } } return { success: !fail };",
    "args": { "draftDir": "draft/src" }
  }'
```

---

## 對錯範例

```yaml
# ✅ 對：直調隔離注入
actionDataFilter:
  results: '{isValid: .isValid, message: .message, errors: .errors}'
  toStateData: '${ .validationResult }'

# ✅ 對（豁免）：子流無需 filter
- subFlowRef:
    workflowId: repayment_cash_deposit
    version: '1.0.1'

# ❌ 錯：直調缺 toStateData（輸入會被沖掉）
actionDataFilter:
  results: '{isValid: .isValid, message: .message, errors: .errors}'
```

下游詳見 `sonataflow-integration Step 6e`（State Data 沖洗症狀與修法）。
