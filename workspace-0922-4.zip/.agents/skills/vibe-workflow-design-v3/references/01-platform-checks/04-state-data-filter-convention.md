# Reference 04: stateDataFilter Output Convention 對齊

> 對應 SKILL.md Step 3d + Step 6.4 預檢
> 來源:`INTEGRATION-PRACTICE.md` 問題 2

---

## 3 種 Convention

### 舊 Convention (saga2-transfer-workflow 風格)

```yaml
stateDataFilter:
  output: |
    {
      status: .finalStatus,
      message: .finalMessage
    }
```

- `status` 是 STRING
- 直接對應 finalStatus 值
- 適用於舊有 `WorkflowStatusFilter` 只讀 `status` 欄位

### 新 Convention (omni-cash-transaction 風格) ⭐ 推薦

```yaml
stateDataFilter:
  output: |
    {
      track_id: .<key_field>,
      workflow: (.operationType == "A" ? "REPAYMENT" : "CANCELLATION"),
      status: (if .finalStatus in ["SUCCESS", "CANCELLED", "IDEMPOTENT_REPLAY"] then 0 else 1 end),
      finalStatus: .finalStatus,
      message: .finalMessage,
      coreResult: (.coreResult // null),
      ccResult: (.ccResult // null)
    }
```

- `status` 是 INT 0/1
- `finalStatus` 是 STRING (獨立欄位)
- 適用於新版 `WorkflowStatusFilter` 同時讀兩個欄位

### 純 HTTP Status

```yaml
# 不在 stateDataFilter 設 status,完全靠 HTTP code 區分
stateDataFilter:
  output: |
    {
      message: .finalMessage
    }
```

- 適用於簡單的 GET/POST,對外契約不需 finalStatus

---

## 對應 platform-security 行為

| Convention | WorkflowStatusFilter 行為 | application.properties |
|---|---|---|
| 舊 | 讀 `status` (string) → 查 mapping → 改 HTTP code | `status-rewrite.workflows` + `mapping` |
| 新 | 讀 `finalStatus` (string) → 查 mapping → 改 HTTP code | `status-rewrite.workflows` + `mapping` |
| 純 HTTP | 不啟用 status-rewrite | 無 |

---

## 自動檢查（透過 Agent Dynamic Script Runner）

透過 Runner 自動掃描 `stateDataFilter.output`，比對是否符合選定的 convention（預設 new convention）：

```bash
curl -s -X POST http://127.0.0.1:8091/api/run \
  -H "Content-Type: application/json" \
  -d '{
    "script": "const targetDir = path.join(workspaceRoot, args.draftDir || \"draft/src\"); const convention = args.convention || \"new\"; const files = fs.readdirSync(targetDir).filter(f => f.endsWith(\".sw.yaml\")); let fail = false; for (const file of files) { const filePath = path.join(targetDir, file); const content = fs.readFileSync(filePath, \"utf8\"); if (!content.includes(\"stateDataFilter\")) continue; const wf = helpers.parseYaml(content); for (const state of (wf.states || [])) { if (state.stateDataFilter && state.stateDataFilter.output) { const outStr = String(state.stateDataFilter.output); if (convention === \"new\") { const hasStatusInt = /status:\\s*\\(?if/m.test(outStr); const hasFinalStatus = outStr.includes(\"finalStatus\"); if (!hasStatusInt || !hasFinalStatus) { fail = true; console.log(`❌ FAIL: ${file} 狀態 \"${state.name}\" 新 convention 必須含 status (int 0/1) 與 finalStatus 雙軌欄位`); helpers.addDiagnostic(filePath, 1, 1, `stateDataFilter.output 必須同時包含 status: 0/1 與 finalStatus: .finalStatus`, \"error\"); } else { console.log(`✅ PASS: ${file} 狀態 \"${state.name}\" 符合新 convention`); helpers.clearDiagnostics(filePath); } } } } } return { success: !fail };",
    "args": { "draftDir": "draft/src", "convention": "new" }
  }'
```

---

## spec.md 標註範本

在 `spec.md §0 假設清單` 加:

```markdown
| H16 | **Convention**: 新 (status 0/1 int + finalStatus string) | 與 credit-card 體系對齊 | — | stateDataFilter.output 強制含兩個欄位 |
```

---

## 對應 application.properties 設定

新 convention 範例 (見 `01-financial-repayment/src/config/application.properties.snippet`):

```properties
platform.status-rewrite.workflows=omni_cash_transaction,repayment_cash_deposit,repayment_cash_cancellation
platform.status-rewrite.mapping.REJECTED_VALIDATION=400
platform.status-rewrite.mapping.LOOKUP_FAILED=500
platform.status-rewrite.mapping.SYSTEM_UNAVAILABLE=503
platform.status-rewrite.mapping.ROLLBACK_FAILED=409
platform.status-rewrite.mapping.CANCEL_ROLLBACK_FAILED=409
```

**重要**:workflow id 必須用最終 snake_case 名稱,不能用 draft 時的 hyphen 名稱。
