# Reference 07: Spec Schema 與 Example/測試 Payload 一致性（YAML SSOT，無 JSON）

> 對應 SKILL.md Step 6.7 預檢 + 7.16/7.22
> SSOT 為 `src/specs/` YAML 內 `components.schemas/requestBody`；⛔ 禁止 `src/schemas/*.json`（見 SKILL Step 8）

---

## 規則

OpenAPI YAML（`draft/src/specs/internal/*.yaml` + `draft/src/specs/external/*.yaml`）內每個 `properties.<field>` 的 `maxLength/minLength/pattern` 必須同時相容三者：`example`、測試 payload、真實業務樣本（如通路代碼 `2500P`）。

禁止：
- 宣告 `maxLength: 4` 但 example 給 `2500P`（5 碼）
- 宣告 `maxLength: 22` 但 example 含 prefix 達 25 碼
- `pattern: ^[0-9]+$` 卻要求支援 `FAIL_*` 哨兵而不加 validator 豁免（見 06）

---

## 自動檢查（透過 Agent Dynamic Script Runner）

透過 Runner 自動解析 OpenAPI YAML 結構，遞迴掃描 properties，驗證 `example` 字串長度是否符合 `maxLength` 與 `minLength` 規範，並自動標註 VS Code 錯誤：

```bash
curl -s -X POST http://127.0.0.1:8091/api/run \
  -H "Content-Type: application/json" \
  -d '{
    "script": "const draftRoot = path.join(workspaceRoot, args.draftDir || \"draft\"); const specDirs = [path.join(draftRoot, \"src/specs/internal\"), path.join(draftRoot, \"src/specs/external\")]; let fail = false; for (const d of specDirs) { if (!fs.existsSync(d)) continue; for (const f of fs.readdirSync(d).filter(x => x.endsWith(\".yaml\"))) { const specPath = path.join(d, f); const spec = helpers.parseYaml(fs.readFileSync(specPath, \"utf8\")); let specHasFail = false; function checkProps(props, prefix) { if (!props) return; for (const [name, val] of Object.entries(props)) { if (val && typeof val === \"object\") { const ex = val.example; const maxL = val.maxLength; const minL = val.minLength; if (typeof ex === \"string\") { if (maxL !== undefined && ex.length > maxL) { specHasFail = true; fail = true; console.log(`❌ FAIL: ${f} ${prefix}${name} example \"${ex}\" (len=${ex.length}) > maxLength ${maxL}`); helpers.addDiagnostic(specPath, 1, 1, `欄位 ${prefix}${name} example 長度超出 maxLength: ${ex.length} > ${maxL}`, \"error\"); } if (minL !== undefined && ex.length < minL) { specHasFail = true; fail = true; console.log(`❌ FAIL: ${f} ${prefix}${name} example \"${ex}\" (len=${ex.length}) < minLength ${minL}`); helpers.addDiagnostic(specPath, 1, 1, `欄位 ${prefix}${name} example 長度小於 minLength: ${ex.length} < ${minL}`, \"error\"); } } } } } for (const s of Object.values(spec.components?.schemas || {})) checkProps(s.properties, \"#schema.\"); for (const pMethods of Object.values(spec.paths || {})) { for (const op of Object.values(pMethods || {})) { const schema = op.requestBody?.content?.[\"application/json\"]?.schema; if (schema) checkProps(schema.properties, \"#requestBody.\"); } } if (!specHasFail) { console.log(`✅ PASS: ${f} example 與長度限制相容`); helpers.clearDiagnostics(specPath); } } } return { success: !fail };",
    "args": { "draftDir": "draft" }
  }'
```

---

## pattern 與哨兵對照（人工）

| pattern | 允許哨兵 | 條件 |
|---|---|---|
| `^[0-9]+$` | `FAIL_*` 僅當 validator 有剝離豁免 | 見 06 + H13a validator 註冊 |
| `^[A-Za-z0-9]{1,10}$` | `FAIL_*`、`2500P` | 通路代碼推薦此寬度 |
| 嚴格業務碼 | 無哨兵，用 `amount=0` 觸發拒絕 | Mock 改用 `equals("0")` |

---

## spec.md 標註範本

```markdown
| H16 | **Example 相容**：`branchCode` pattern `^[A-Za-z0-9]{1,10}$` 覆蓋 `2500P` 與 `FAIL_*` | 真實樣本 + 哨兵需求 | — | src/specs/*-api.yaml 全欄已跑 check-spec-example |
```
