# Reference 10: onErrors 覆蓋 + notifyOps 告警 (Audit Gap 防線)

> 對應 SKILL.md Step 6.11 預檢 + 自查 7.28
> 來源：`draft-remittance/spec/remittance-swift.sw.yaml` 審查（宣告 platformError 卻零 onErrors；定義 notifyOps 卻零調用）

---

## 核心規則

1. 凡宣告 `errors:` 的 workflow，每個 `type: operation` 必須有 `onErrors`（terminal audit state 除外）。
2. 凡 `finalStatus` 含 `ROLLBACK_FAILED` 的 workflow，必須至少一處調用 `notifyOps`。

違反任一即 Audit Gap 或靜默失敗：host timeout / 拋 exception 會繞過 `FinalAuditAndEnd`，`ROLLBACK_FAILED` 無人知曉。

---

## ✅ 對的寫法

```yaml
- name: CallCoreDebit
  type: operation
  onErrors:
    - errorRef: platformError
      transition: FinalizeFailed
  actions:
    - functionRef:
        refName: callApiViaOpenAPI
        arguments:
          functionName: callApiViaOpenAPI
          schemaRef: 'specs/external/core-account-api.yaml#executeCoreDebit'
          payload:
            partyId: '${ .partyId }'
      actionDataFilter:
        results: '{status: .code, message: .message}'
        toStateData: '${ .coreResult }'
  transition: CheckCoreResult

- name: ChildFinalAuditAndEnd
  type: operation
  actions:
    - functionRef:
        refName: recordAuditLog
        arguments:
          workflowId: remittance_swift
          sequenceNumber: '${ .sequenceNumber }'
          finalStatus: '${ .finalStatus }'
    - name: alertOnRollbackFailed
      functionRef:
        refName: notifyOps
        arguments:
          workflowId: remittance_swift
          sequenceNumber: '${ .sequenceNumber }'
          finalStatus: '${ .finalStatus }'
          # 建議 Java 側僅當 finalStatus 含 ROLLBACK_FAILED 才發告警，避免成功路徑噪音
  end: true
```

---

## ❌ 錯的寫法

```yaml
errors:
  - name: platformError
    code: 'PLATFORM_ERROR'
# ...但 operation 全無 onErrors → host 拋錯直接炸，不進 audit
- name: CallCoreDebit
  type: operation
  actions: [...]
  transition: CheckCoreResult

functions:
  - name: notifyOps
    operation: 'service:com.example.reconciliation.OpsAlertService::raise'
    type: custom
# ...但全檔無 notifyOps 調用 → ROLLBACK_FAILED 靜默結束
```

---

## 自動檢查（透過 Agent Dynamic Script Runner）

透過 Runner 分析 operation 狀態數量與 `onErrors` 宣告比例，並檢查包含 `ROLLBACK_FAILED` 時是否調用 `notifyOps` 告警服務：

```bash
curl -s -X POST http://127.0.0.1:8091/api/run \
  -H "Content-Type: application/json" \
  -d '{
    "script": "const targetDir = path.join(workspaceRoot, args.draftDir || \"draft/src\"); const files = fs.readdirSync(targetDir).filter(f => f.endsWith(\".sw.yaml\")); let fail = false; for (const file of files) { const filePath = path.join(targetDir, file); const content = fs.readFileSync(filePath, \"utf8\"); const wf = helpers.parseYaml(content); const states = wf.states || []; const ops = states.filter(s => s.type === \"operation\"); const errs = states.filter(s => s.onErrors && s.onErrors.length > 0); if (ops.length > 1 && errs.length < (ops.length - 1)) { fail = true; console.log(`❌ FAIL: ${file} operation=${ops.length} 但 onErrors=${errs.length}（未達覆蓋標準）`); helpers.addDiagnostic(filePath, 1, 1, `onErrors 覆蓋不足 (${errs.length}/${ops.length})，除 terminal audit 外每個 operation 皆應防護`, \"error\"); } else { console.log(`✅ PASS: ${file} onErrors 覆蓋良好 (${errs.length}/${ops.length})`); helpers.clearDiagnostics(filePath); } if (content.includes(\"ROLLBACK_FAILED\")) { const hasNotify = content.includes(\"refName: notifyOps\") || content.includes(\"refName: \\\"notifyOps\\\"\"); if (!hasNotify) { fail = true; console.log(`❌ FAIL: ${file} 包含 ROLLBACK_FAILED 終態卻未調用 notifyOps 告警`); helpers.addDiagnostic(filePath, 1, 1, `存在 ROLLBACK_FAILED 終態，必須調用 notifyOps 進行維運告警`, \"error\"); } else { console.log(`✅ PASS: ${file} 已包含 notifyOps 告警防線`); } } } return { success: !fail };",
    "args": { "draftDir": "draft/src" }
  }'
```
