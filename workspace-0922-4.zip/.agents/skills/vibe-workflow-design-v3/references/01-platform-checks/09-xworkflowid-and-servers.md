# Reference 09: x-workflow-id 與 servers + internal/external 嚴格二分

> 對應 SKILL.md Step 6.9 + 7.21/7.25
> 實況：21 specs 僅 internal 1 有標籤；fx-exchange 缺 servers 仍運行；external/ 空待啟用；root omni 雙份漂移

---

## 規則（嚴格二分，root 禁放）

- `draft/src/specs/internal/*.yaml`：Parent 對外入口，每個 `post:` 必含 `x-workflow-id`（validator+router 唯一 SSOT）。
- `draft/src/specs/external/*.yaml`：被調 host 規格，禁止含 `x-workflow-id`/`x-kogito-workflow-id`。
- `draft/src/specs/*.yaml`（root）：禁止放業務 yaml（`openapi.yaml` 聚合除外），違者搬入 external。
- 整併後：`specs/internal/` + `specs/external/` 雙模組同步；root `specs/*.yaml` 僅相容舊案 20 檔，新案禁止再落 root；入口禁止落 root（root 舊 omni 無標籤嚴格版視為待刪，以 internal 放寬版為準）。
- `servers[0].url`：建議 `http://localhost:8080`，缺失走 `base_url>%dev.host>servers` fallback，不 FAIL。

---

## 自動檢查（透過 Agent Dynamic Script Runner）

透過 Runner 掃描 internal、external 與 root specs，驗證路由標籤與存放位置規範：

```bash
curl -s -X POST http://127.0.0.1:8091/api/run \
  -H "Content-Type: application/json" \
  -d '{
    "script": "const draftRoot = path.join(workspaceRoot, args.draftDir || \"draft\"); const internalDir = path.join(draftRoot, \"src/specs/internal\"); const externalDir = path.join(draftRoot, \"src/specs/external\"); const rootSpecDir = path.join(draftRoot, \"src/specs\"); let fail = false; if (fs.existsSync(internalDir)) { for (const f of fs.readdirSync(internalDir).filter(x => x.endsWith(\".yaml\"))) { const specPath = path.join(internalDir, f); const spec = helpers.parseYaml(fs.readFileSync(specPath, \"utf8\")); let hasTag = false; for (const ops of Object.values(spec.paths || {})) { if (ops.post && ops.post[\"x-workflow-id\"]) hasTag = true; } if (!hasTag) { fail = true; console.log(`❌ FAIL: ${f} internal 對外入口缺少 x-workflow-id 標籤`); helpers.addDiagnostic(specPath, 1, 1, `對外入口 spec 的 post 操作缺少 x-workflow-id 標籤供動態路由代理`, \"error\"); } else { console.log(`✅ PASS: ${f} internal x-workflow-id 齊全`); helpers.clearDiagnostics(specPath); } } } if (fs.existsSync(externalDir)) { for (const f of fs.readdirSync(externalDir).filter(x => x.endsWith(\".yaml\"))) { const specPath = path.join(externalDir, f); const txt = fs.readFileSync(specPath, \"utf8\"); if (txt.includes(\"x-workflow-id\")) { fail = true; console.log(`❌ FAIL: ${f} external 外部 host 禁止含有 x-workflow-id`); helpers.addDiagnostic(specPath, 1, 1, `External host spec 禁止含有 x-workflow-id 標籤`, \"error\"); } else { console.log(`✅ PASS: ${f} external 無多餘標籤`); helpers.clearDiagnostics(specPath); } } } if (fs.existsSync(rootSpecDir)) { const rootYamls = fs.readdirSync(rootSpecDir).filter(x => x.endsWith(\".yaml\") && x !== \"openapi.yaml\"); for (const rf of rootYamls) { fail = true; console.log(`❌ FAIL: 發現違規落放於 root 的 spec: ${rf}，請搬入 internal 或 external 目錄`); helpers.addDiagnostic(path.join(rootSpecDir, rf), 1, 1, `root src/specs/ 禁止落放業務 yaml，請搬入 internal/ 或 external/`, \"error\"); } } return { success: !fail };",
    "args": { "draftDir": "draft" }
  }'
```

---

## spec.md 標註範本

```markdown
| H5 | **入口路由**：`src/specs/internal/omni-*.yaml` post 含 `x-workflow-id: omni_cash_transaction`；host specs 不含 | 動態路由僅 Parent 需要 | — | Step 6.9 PASS |
| H21 | **BaseUrl**：specs 填 `http://localhost:8080`，缺失時靠 `%dev.callApiViaOpenAPI` fallback | fx-exchange 實況缺 servers 教訓 | — | §5 config snippet 註明 |
```
