"""DB diagnostic for reconciliation.db

Prints:
 - PRAGMA table_info(workflow_execution_log)
 - DDL of workflow_execution_log + related views/indexes
 - sample rows of created_at (typeof & value)
 - row count
"""
import sqlite3, sys, json

db = r'D:\2026\202608\card\sonataflow\myhello-platform-src\distribution\transfer-app\data\reconciliation.db'

con = sqlite3.connect(db)
cur = con.cursor()

def hr(s):
    print('\n===== ' + s + ' =====')

hr('PRAGMA table_info(workflow_execution_log)')
for r in cur.execute("PRAGMA table_info('workflow_execution_log')"):
    print(r)

hr('DDL of workflow_execution_log (and related views/indexes)')
cur2 = con.cursor()
rows = list(cur2.execute(
    "SELECT type, name, sql FROM sqlite_master "
    "WHERE (tbl_name='workflow_execution_log' OR name='workflow_execution_log') "
    "AND type IN ('table','view','index') ORDER BY type, name"))
for t,n,s in rows:
    print('--', t, n)
    print(s or '(no sql)')
    print()

hr('All DB objects')
for r in cur.execute("SELECT type, name, tbl_name FROM sqlite_master ORDER BY type, name"):
    print(r)

hr('Index on workflow_execution_log')
for r in cur.execute("SELECT name, sql FROM sqlite_master WHERE type='index' AND tbl_name='workflow_execution_log'"):
    print(r)

hr('Sample created_at rows (typeof, value)')
for r in cur.execute("SELECT rowid, typeof(created_at), created_at FROM workflow_execution_log ORDER BY rowid DESC LIMIT 10"):
    print(r)

hr('Row count')
print(cur.execute("SELECT COUNT(*) FROM workflow_execution_log").fetchone())

hr('Full row sample (first 3)')
for r in cur.execute("SELECT * FROM workflow_execution_log ORDER BY rowid DESC LIMIT 3"):
    print(r)

hr('Last 5 vw_saga_reconciliation rows (if view exists)')
try:
    for r in cur.execute("SELECT * FROM vw_saga_reconciliation ORDER BY id DESC LIMIT 5"):
        print(r)
except Exception as e:
    print('view not available:', e)
