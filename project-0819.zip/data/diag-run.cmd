@echo off
setlocal
set "PYEXE=D:\2024\202412\playwright\python-3.12.7\python.exe"
if not exist "%PYEXE%" (
    set "PYEXE=python"
)
"%PYEXE%" "D:\2026\202608\card\sonataflow\myhello-platform-src\distribution\transfer-app\data\diag.py"
endlocal
