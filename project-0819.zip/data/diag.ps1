$ErrorActionPreference = 'Stop'
$env:Path = "D:\2026\202607\Card\SonataFlow\jdk-21.0.12+8\bin;D:\2026\202607\Card\SonataFlow\apache-maven-3.9.16\bin;$env:Path"
chcp 65001 | Out-Null
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$OutputEncoding = [System.Text.Encoding]::UTF8

$db = 'D:\2026\202608\card\sonataflow\myhello-platform-src\distribution\transfer-app\data\reconciliation.db'

function Run-Cmd([string]$label, [string]$cmd) {
    Write-Host "===== $label =====" -ForegroundColor Cyan
    Write-Host $cmd
    Write-Host "----- output -----"
    Invoke-Expression $cmd
    Write-Host ""
}

# Try sqlite3.exe
$sqlite = $null
$candidates = @(
    "D:\2026\202607\Card\SonataFlow\sqlite-tools\sqlite3.exe",
    "D:\2026\202608\card\sqlite3\sqlite3.exe"
)
foreach ($p in $candidates) {
    if (Test-Path $p) { $sqlite = $p; break }
}
if (-not $sqlite) {
    $cmd = Get-Command sqlite3.exe -ErrorAction SilentlyContinue
    if ($cmd) { $sqlite = $cmd.Source }
}

if ($sqlite) {
    Write-Host "Using sqlite3: $sqlite"
    Run-Cmd "PRAGMA table_info(workflow_execution_log)" "& '$sqlite' '$db' 'PRAGMA table_info(\"workflow_execution_log\");'"
    Run-Cmd "DDL: workflow_execution_log" "& '$sqlite' '$db' 'SELECT sql FROM sqlite_master WHERE type IN (\"table\",\"view\") AND (tbl_name=\"workflow_execution_log\" OR name=\"workflow_execution_log\");'"
    Run-Cmd "All DB objects (sqlite_master)" "& '$sqlite' '$db' 'SELECT type, name, tbl_name FROM sqlite_master ORDER BY type, name;'"
    Run-Cmd "Sample created_at rows" "& '$sqlite' '-separator' '|' '$db' \"SELECT rowid, typeof(created_at), created_at FROM workflow_execution_log ORDER BY rowid DESC LIMIT 5;\""
    Run-Cmd "Row count" "& '$sqlite' '$db' 'SELECT COUNT(*) FROM workflow_execution_log;'"
    Run-Cmd "Indexes on the table" "& '$sqlite' '$db' \"SELECT name, sql FROM sqlite_master WHERE type='index' AND tbl_name='workflow_execution_log';\""
} else {
    Write-Host "sqlite3 not found; falling back to python."
    $py = (Get-Command python.exe -ErrorAction SilentlyContinue).Source
    if (-not $py) { Write-Error "Neither sqlite3 nor python available."; exit 1 }
    Run-Cmd "PRAGMA table_info(workflow_execution_log)" "& '$py' -c \"import sqlite3; c=sqlite3.connect(r'$db'); print(list(c.execute(\\\"PRAGMA table_info('workflow_execution_log')\\\").fetchall()))\""
}
