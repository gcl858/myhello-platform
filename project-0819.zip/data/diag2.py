"""Inspect Kogito data-index tables for the timestamp issue."""
import sqlite3

db = r'D:\2026\202608\card\sonataflow\myhello-platform-src\distribution\transfer-app\data\reconciliation.db'
con = sqlite3.connect(db)
cur = con.cursor()

def hr(s):
    print('\n===== ' + s + ' =====')

for tbl in ('processes', 'nodes', 'definitions', 'tasks', 'milestones', 'jobs'):
    hr(f'PRAGMA table_info({tbl})')
    rows = list(cur.execute(f"PRAGMA table_info('{tbl}')"))
    if not rows:
        print('(no such table)')
        continue
    for r in rows:
        print(r)

hr('processes row count')
print(cur.execute("SELECT COUNT(*) FROM processes").fetchone())

hr('processes CREATE DDL')
for r in cur.execute("SELECT sql FROM sqlite_master WHERE name='processes'"):
    print(r[0])

hr('Sample processes row (full *)')
rows = list(cur.execute("SELECT * FROM processes ORDER BY rowid DESC LIMIT 3"))
for r in rows:
    print(r)

hr('typeof(start) and value')
for r in cur.execute("SELECT id, typeof(start), start, typeof(end), end FROM processes ORDER BY rowid DESC LIMIT 3"):
    print(r)

hr('Sample nodes row')
for r in cur.execute("SELECT id, typeof(enter), enter, typeof(exit), exit, node_definition_id FROM nodes ORDER BY id DESC LIMIT 3"):
    print(r)
