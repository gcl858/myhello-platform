---
title: "myhello-platform 資料庫說明文件 (DB-SPEC)"
subtitle: "reconciliation.db 完整解析"
version: "1.1"
date: "2026-08-19"
project: "myhello-platform 1.0.0-SNAPSHOT"
database: "SQLite 3.40+ with WAL"
kogito: "10.2.0"
quarkus: "3.27.2"
---

# myhello-platform 資料庫說明文件

> **文件代號**:DB-SPEC v1.1  
> **適用版本**:`myhello-platform 1.0.0-SNAPSHOT`(Kogito 10.2.0 + Quarkus 3.27.2 + SQLite 3.40+)  
> **文件日期**:2026-08-19  
> **適用對象**:架構師 / 後端工程師 / DBA / SRE

## 快速事實卡 (TL;DR)

| 項目 | 數值 |
|---|---|
| 資料表總數 | **24**(22 張 Kogito + 1 張業務 + 1 張 Flyway history)+ 2 張 SQLite 系統表 |
| View | 1 個:`vw_saga_reconciliation` |
| Trigger | 1 個:`definitions_upsert_trigger` |
| Flyway 腳本 | 22 個(V1.32.0 ~ V1.50.0) |
| 物理檔案 | `reconciliation.db` + `reconciliation.db-wal` + `reconciliation.db-shm` |
| 寫入來源 | 2 個:① Kogito Data Index 引擎(22 張) ② `AuditLogService`(1 張) |
| 共享模式 | 雙 Quarkus app 共用同一檔案(透過 NFS volume / 共享磁碟) |
| 當前資料量(processes / nodes / audit log) | 4 / 118 / 4 筆 |

## 目錄

- 第 0 章:讀者導讀
- 第 1 章:系統總覽
- 第 2 章:按用途分類(6 大族群)
- 第 3 章:每張表欄位規格
- 第 4 章:視圖 (View) 與觸發器 (Trigger)
- 第 5 章:對應程式碼 (Source Code Mapping)
- 第 6 章:流程 Lifecycle 紀錄(業務視角)
- 第 7 章:流程引擎記錄(Kogito Data Index 視角)
- 第 8 章:Schema 演進史
- 第 9 章:維運 & 監控
- **第 10 章:Process Flow 完整深度解析 ⭐ NEW**
- 附錄 A:完整 DDL
- 附錄 B:22 個 Flyway 腳本一覽
- 附錄 C:名詞對照表
- 附錄 D:參考文件索引

---

# 第 0 章:讀者導讀 (Reader's Guide)

> 文件代號:**DB-SPEC v1.0**  
> 適用版本:`myhello-platform 1.0.0-SNAPSHOT`(Kogito 10.2.0 + Quarkus 3.27.2 + SQLite 3.40+)  
> 文件日期:2026-08-19

## 0.1 適用對象與閱讀路徑

| 你是誰 | 推薦閱讀路徑 |
|---|---|
| **新加入的後端工程師** | Ch01 → Ch02 → Ch06(看一筆交易怎麼落地)→ Ch05(知道去哪改 code) |
| **架構師 / 技術主管** | Ch01 → Ch02 → Ch07 → Ch08(理解引擎設計與演進) |
| **DBA / SRE** | Ch01 → Ch03(完整 schema)→ Ch09(維運)→ 附錄 A(完整 DDL) |
| **想擴展新業務域** | Ch02(看族群怎麼分)→ Ch05(看怎麼掛自己的 Resource)→ Ch06(確認 lifecycle 該寫哪張表) |

## 0.2 命名約定

- **資料表**:snake_case **複數**(`processes`、`nodes`、`tasks`)。例外:`workflow_execution_log` 是業務表用單數級事件流語意
- **主鍵**:大多為 UUID v4 存 `TEXT`;複合 PK 用 `(id, version)` / `(task_id, user_id)` 形式
- **外鍵**:一律 `ON DELETE CASCADE`(被引用端刪除,引用端連帶刪)
- **時間欄位**:Kogito 表用 epoch millis `TEXT` 存;`workflow_execution_log` 用 ISO-8601 `TIMESTAMP`
- **JSON 欄位**:`variables` / `inputs` / `outputs` / `input_data` / `output_data` 等 — 實體上是 `TEXT`,但應用層以 JSON 處理(註解 `-- was jsonb` 標示從 PostgreSQL 移植的歷史)

## 0.3 圖例規範

- **ER 圖**:Mermaid `erDiagram`,PK 標 `PK`、FK 標 `FK`
- **時序圖**:Mermaid `sequenceDiagram`
- **狀態圖**:Mermaid `stateDiagram-v2`
- **資料表呈現模板**(Ch03 統一採用):
  ```
  | # | 欄位 | 型別 | 約束 | 預設 | 說明 |
  |---|------|------|------|------|------|
  ```

## 0.4 與其他文件的關係

```
SYSTEM-ARCHITECTURE.md  ─┐
CODE-SPECIFICATION.md  ─┴─→ 本文件 DB-SPEC.md(資料庫專論)
MODULE-SPLIT-DECISION.md ─→  補充:模組怎麼對應到表的所有權
```

- **本文件不重複** SYSTEM-ARCHITECTURE.md 已講過的 Quarkus / Kogito 概念
- **本文件不重複** CODE-SPECIFICATION.md 已講過的每支 Java class 細節,僅引用方法名
- **本文件專注** 資料庫物件本身的結構、生命週期、與程式碼的對映

## 0.5 快速事實卡 (TL;DR)

| 項目 | 數值 |
|---|---|
| 資料表總數 | **24**(22 張 Kogito + 1 張業務 + 1 張 Flyway history)+ 2 張 SQLite 系統表 |
| View | 1 個:`vw_saga_reconciliation` |
| Trigger | 1 個:`definitions_upsert_trigger` |
| Flyway 腳本 | 22 個(V1.32.0 ~ V1.50.0) |
| 物理檔案 | `reconciliation.db` + `reconciliation.db-wal` + `reconciliation.db-shm` |
| 寫入來源 | 2 個:① Kogito Data Index 引擎(22 張) ② `AuditLogService`(1 張) |
| 共享模式 | 雙 Quarkus app 共用同一檔案(透過 NFS volume / 共享磁碟) |
| WAL 模式 | ON,允許多 reader + 1 writer 並行 |
| 當前資料量(processes / nodes / audit log) | 4 / 118 / 4 筆(來自 4 次 saga 測試) |

---

# 第 1 章:系統總覽 (System Overview)

## 1.1 資料庫定位

`reconciliation.db` 是 `myhello-platform` 平台的**唯一持久化層**,被兩個獨立的 Quarkus 應用共享:

```
                ┌──────────────────────┐
                │   reconciliation.db   │  (SQLite WAL)
                │   (共享儲存)           │
                └──────────┬───────────┘
                           │
            ┌──────────────┴──────────────┐
            ▼                              ▼
   ┌─────────────────┐           ┌─────────────────────┐
   │ transfer-app    │  讀寫     │  reconciliation-app │
   │ :8080           │ ────────► │  :8081               │
   │ 線上交易 + 流程  │           │  對帳查詢 + CSV 匯出  │
   └─────────────────┘           └─────────────────────┘
```

**為什麼不是 Postgres?** 因為這個平台示範的目標是「**零外部依賴、單檔即可運行**」,SQLite + WAL 模式剛好滿足「多 reader + 1 writer」並發需求。如果未來交易量超過 SQLite 上限,只需把 driver 換成 `postgresql`、Flyway 腳本仍可重用(註解有標 `-- was jsonb` 標示語法差異)。

## 1.2 物理檔案結構

SQLite WAL 模式由三個檔案組成:

| 檔案 | 角色 | 特性 |
|---|---|---|
| `reconciliation.db` | 主要資料檔,存 schema 與已 checkpoint 的資料 | 一般只有 4 KB(目前資料量小) |
| `reconciliation.db-wal` | Write-Ahead Log,所有寫入先 append 這裡,週期 checkpoint | 目前約 1.6 MB(累計寫入緩衝) |
| `reconciliation.db-shm` | Shared memory index,WAL 模式下用於 reader/writer 協調 | 32 KB(固定大小) |

**運作邏輯**:
- Reader 永遠讀 `.db` + `.db-wal` 的合併視圖,**不阻塞** Writer
- Writer 寫入 `.db-wal`,**不阻塞** Reader
- 當 WAL 累積超過 `wal_autocheckpoint`(預設 1000 頁)→ 觸發 checkpoint,把 WAL 內容合併回 `.db`

**目前實測**:

```
$ ls -la /workspace/extracted/data/
-rw-r--r-- 1 root root   4096 Aug 17 07:32 reconciliation.db         # 4 KB
-rw-r--r-- 1 root root 32768 Aug 17 07:33 reconciliation.db-shm     # 32 KB
-rw-r--r-- 1 root root 1.6 MB Aug 17 07:32 reconciliation.db-wal    # 1.6 MB
```

## 1.3 Schema 全貌(分類摘要)

完整 24 張表 + 1 view + 1 trigger,按用途分為 6 個族群(細節見 Ch02):

| 族群 | 表數 | 代表表 | 寫入者 |
|---|---:|---|---|
| A. 流程實例 | 5 | `processes` / `nodes` | Kogito 引擎 |
| B. 流程定義 | 6 | `definitions` / `definitions_nodes` | Kogito 引擎 |
| C. 人工作業 | 8 | `tasks` / `attachments` | Kogito 引擎(本專案未使用) |
| D. 業務審計 | 1 + 1 view | `workflow_execution_log` / `vw_saga_reconciliation` | 應用層 `AuditLogService` |
| E. 引擎輔助 | 2 | `jobs` / `kie_flyway_history_data_index` | Kogito + Flyway |
| F. SQLite 系統 | 2 | `sqlite_sequence` | 系統 |

**6 族群 = Kogito 引擎管的 22 張 + 應用層管的 1 張 + 系統自動管的 1 張**。這是後續閱讀的核心記憶點。

## 1.4 全域 ER 圖

```mermaid
erDiagram
    definitions ||--o{ definitions_nodes : "有(靜態拓樸)"
    definitions ||--o{ definitions_addons : "可掛 addon"
    definitions ||--o{ definitions_roles : "可綁角色"
    definitions ||--o{ definitions_annotations : "可加註解"
    definitions_nodes ||--o{ definitions_nodes_metadata : "有 metadata"

    processes ||--o{ nodes : "執行軌跡(runtime)"
    processes ||--o{ milestones : "可設里程碑"
    processes ||--o{ processes_addons : "可掛 addon"
    processes ||--o{ processes_roles : "可綁角色"

    tasks ||--o{ attachments : "附件"
    tasks ||--o{ comments : "留言"
    tasks ||--o{ tasks_admin_users : "管理員"
    tasks ||--o{ tasks_admin_groups : "管理群組"
    tasks ||--o{ tasks_potential_users : "候選人"
    tasks ||--o{ tasks_potential_groups : "候選群組"
    tasks ||--o{ tasks_excluded_users : "排除人"

    workflow_execution_log ||..|| vw_saga_reconciliation : "view 從此拆 JSON"

    processes {
        TEXT id PK
        TEXT business_key
        INT state
        TEXT process_name
        TEXT start_time
        TEXT end_time
        TEXT variables
    }
    nodes {
        TEXT id PK
        TEXT process_instance_id FK
        TEXT name
        TEXT type
        TEXT enter
        TEXT exit
        TEXT sla_due_date
        INT retrigger
        TEXT error_message
        TEXT cancel_type
        TEXT input_args
        TEXT output_args
    }
    definitions {
        TEXT id PK
        TEXT version PK
        TEXT name
        TEXT type
        BLOB source
    }
    tasks {
        TEXT id PK
        TEXT process_instance_id FK
        TEXT state
        TEXT actual_owner
    }
    workflow_execution_log {
        INT id PK
        TEXT workflow_id
        TEXT business_key
        TEXT status
        TEXT message
        TEXT input_data
        TEXT output_data
        TIMESTAMP created_at
    }
```

**兩個獨立子圖**:
- **上半部 (definitions 區)**:靜態,deploy `.sw.yaml` 時寫入,很少變動
- **下半部 (processes 區)**:動態,每次 workflow 執行都會新增列
- **中間 (workflow_execution_log)**:業務審計,應用層自己寫,**與 Kogito 引擎解耦**

## 1.5 寫入來源總表(誰寫哪張表)

| 寫入者 | 觸發時機 | 寫入的表 |
|---|---|---|
| **Kogito Data Index engine** | workflow 啟動、節點 enter/exit、process 結束 | `processes` / `nodes` / `milestones` / `processes_*` |
| **Kogito deploy 階段** | Quarkus 啟動掃描 `.sw.yaml` 時 | `definitions` / `definitions_*` |
| **Kogito timer scheduler** | timer 事件觸發時(本專案無) | `jobs` |
| **`AuditLogService.saveLog()`** | saga workflow 內的 `recordAuditLog` function 被呼叫時 | `workflow_execution_log` |
| **Flyway** | 應用啟動時跑 22 個 `V*.sql` | 22 張 Kogito 表 + 1 個 trigger |
| **SQLite 系統** | AUTOINCREMENT 欄位被使用時 | `sqlite_sequence` |

> 重點:應用層業務邏輯只需要碰 `workflow_execution_log` 一張表。**所有其他 Kogito 表的寫入,都應該透過 SonataFlow 的函數呼叫自動完成,不要直接 SQL 操作**(會破壞引擎一致性)。

## 1.6 部署架構(共享儲存)

兩個 Quarkus app 透過共享儲存(容器化時是 Kubernetes `PersistentVolume`,本機開發是共用目錄)讀寫同一份 `reconciliation.db`:

```yaml
# K8s Volume 範例概念
volumes:
  - name: reconciliation-storage
    persistentVolumeClaim:
      claimName: reconciliation-pvc
```

兩個 app 啟動時都會跑 Flyway migration(`platform-data-index` 模組內建),**Flyway 用 advisory lock 確保 schema 不會被並發改壞**。

下一章:把 24 張表按用途展開。

---

# 第 2 章:按用途分類(6 大族群)

本章把 24 張表歸成 6 個族群,每個族群是一個獨立的「資料子系統」。**這是後續維護、開發、Code Review 的核心思維模型**:先看你要碰的表落在哪個族群,就知道應該找哪個模組、用什麼樣的 API。

## 2.1 族群總覽

```mermaid
graph LR
    A[族群A<br/>流程實例]:::runtime
    B[族群B<br/>流程定義]:::static
    C[族群C<br/>人工作業]:::empty
    D[族群D<br/>業務審計]:::biz
    E[族群E<br/>引擎輔助]:::engine
    F[族群F<br/>SQLite系統]:::sys

    B -.啟動時讀入.-> A
    A -.執行觸發.-> D
    A -.排程.-> E
    C -.本專案未啟用.-> A
    F -.AUTOINCREMENT.-> D

    classDef runtime fill:#fff3e0,stroke:#f57c00
    classDef static fill:#e1f5fe,stroke:#0288d1
    classDef empty fill:#f5f5f5,stroke:#9e9e9e
    classDef biz fill:#e8f5e9,stroke:#388e3c,stroke-width:2px
    classDef engine fill:#fce4ec,stroke:#c2185b
    classDef sys fill:#ede7f6,stroke:#512da8
```

---

## 2.2 族群 A:流程實例 (Process Runtime)

> **角色**:記錄「每一次 workflow 跑過什麼節點、什麼時候進入、什麼時候離開」

| Table | 用途 | 現有資料 |
|---|---|---:|
| `processes` | 流程實例主表。每跑一次 workflow 寫一筆 | **4** |
| `nodes` | 該實例經過的每個節點 + 進入/離開時間戳 | **118** |
| `milestones` | 流程里程碑(用於長流程的進度追蹤) | 0 |
| `processes_addons` | 流程 instance 層級的擴充套件 | 0 |
| `processes_roles` | 流程 instance 層級的角色 | 0 |

**寫入者**:`platform-data-index` 模組內的 Kogito Data Index event listener,事件源是 `kogito-event-driven-runtime` 透過 `EventPublisher` 推入。

**業務語意**:
- 一筆 `processes` ≈ 一次 HTTP 呼叫
- 多筆 `nodes` ≈ 該次呼叫經過的 Serverless Workflow 狀態機節點鏈
- `nodes` 同一個 `name` 可能有多列(代表 retry / retrigger)

**索引策略**:所有外鍵欄位都有索引(`idx_nodes_piid`、`idx_milestones_piid`、`idx_processes_addons_pid`...),主要查詢模式是「給定 process_instance_id 拉所有 node」。

**範例資料**:
```sql
SELECT id, business_key, process_name, state FROM processes;
-- dae4022d-... | NULL | Saga2 Transfer Workflow | 2
-- 75268679-... | NULL | Saga2 Transfer Workflow | 2
-- e4f8329a-... | NULL | Saga2 Transfer Workflow | 2
-- 30b63fb8-... | NULL | Saga2 Transfer Workflow | 2

SELECT name, type, enter, exit FROM nodes WHERE process_instance_id='dae4022d-...';
-- ValidateInput | Split          | 1786951944365 | 1786951944612
-- CallA16229State | CompositeContextNode | 1786951944420 | 1786951944612
-- EmbeddedStart | StartNode | 1786951944420 | 1786951944612
-- callApiViaOpenAPI | WorkItemNode | 1786951944420 | 1786951944612
-- Script | ActionNode | 1786951944563 | 1786951944612
```

---

## 2.3 族群 B:流程定義 (Process Definitions)

> **角色**:記錄「deploy 進引擎的 `.sw.yaml` 完整內容 + 靜態拓樸」

| Table | 用途 | 現有資料 |
|---|---|---:|
| `definitions` | 流程定義主表,`source` BLOB 存完整 `.sw.yaml` | **5** |
| `definitions_nodes` | 定義裡的每個節點靜態結構 | **134** |
| `definitions_nodes_metadata` | 節點 metadata | (隨 nodes) |
| `definitions_addons` | 定義層級的擴充 | 0 |
| `definitions_roles` | 定義層級的角色 | 0 |
| `definitions_annotations` | 定義層級的註解 | 0 |

**寫入者**:Kogito `DefinitionDeployer`,在 Quarkus 啟動時掃描 classpath 下所有 `.sw.yaml` 寫入。

**業務語意**:
- 一筆 `definitions` ≈ 一個 `.sw.yaml` 檔
- 同一個 workflow 可有多版本(`(id, version)` 複合 PK)
- 當前 5 筆 = 5 個 workflow:saga / saga2 / OpenAPI-workflow / java-workflow / rest-workflow

**`definitions` vs `nodes` 對照**(極常搞混):

| 比較 | `definitions_nodes` | `nodes` |
|---|---|---|
| 時機 | 啟動時 deploy,幾乎不變 | 每次 workflow 執行寫入 |
| 內容 | 該 workflow 設計上有多少節點 | 該次執行實際走過哪些節點 |
| 數量 | workflow 節點數(靜態) | 動態,可大於靜態數(retry) |
| 例如 saga2 | 假設設計 24 個節點 → 24 列 | 一次跑可能 30 列(retry 多走幾個) |

**Trigger**:`definitions_upsert_trigger` 在 INSERT 前檢查若同 `id+version` 已存在,先 DELETE 再 INSERT,達成「**熱更新定義**」(見 Ch04)。

**範例**:
```sql
SELECT id, version, name, type, length(source) FROM definitions;
-- saga-transfer-workflow      | 15.0.0 | Saga Transfer Workflow   | SW | 7086
-- saga2-transfer-workflow     | 2.0.0  | Saga2 Transfer Workflow  | SW | 12459
-- OpenAPI-workflow            | 1.0.0  | My First Workflow        | SW | 9200
-- java-workflow               | 1.0.0  | My First Java Service ...| SW | 5511
-- rest-workflow               | 1.0.0  | My First REST Workflow   | SW | 9761
```

---

## 2.4 族群 C:人工作業 (Human Tasks)

> **角色**:支援 SonataFlow User Task 機制,管理人工指派、候選人、附件、留言

| Table | 用途 | 現有資料 |
|---|---|---:|
| `tasks` | User task 主表 | 0 |
| `tasks_admin_users` | task 管理員(個體) | 0 |
| `tasks_admin_groups` | task 管理員(群組) | 0 |
| `tasks_potential_users` | 候選承辦人(個體) | 0 |
| `tasks_potential_groups` | 候選承辦人(群組) | 0 |
| `tasks_excluded_users` | 排除的承辦人 | 0 |
| `attachments` | task 附件 | 0 |
| `comments` | task 留言 | 0 |

**本專案狀態**:**全部 8 張表都是 0 筆資料**,因為 `saga2-transfer-workflow` 是全自動流程,沒有 `UserTask` 節點。

**保留目的**:Kogito Data Index 內建這套 user task 索引機制,即使現在不用,未來若新增「轉帳待覆核」等 user task 業務,直接對應這 8 張表就行,**不用改 schema**。

**為什麼 8 張?** 因為 Kogito 對 user task 的多對多關係(管理員/候選/排除 × 個體/群組)正規化了。

---

## 2.5 族群 D:業務審計 (Business Audit) ⭐

> **角色**:**這個專案真正的「業務資料」**,對帳 CSV 引擎唯一資料源

| Object | 用途 | 現有資料 |
|---|---|---:|
| `workflow_execution_log` (table) | 每次 workflow 結束時寫一筆,含 input_data + output_data(JSON) | **4** |
| `vw_saga_reconciliation` (view) | 從上面那張表拆 JSON,展開成扁平欄位供 CSV 引擎讀 | 4 列(來自同 4 筆) |

**寫入者**:`domain-reconciliation/reconciliation-api` 模組內的 `AuditLogService.saveLog()`,被 saga workflow 內的 `recordAuditLog` function 觸發(見 `saga2-transfer-workflow.sw.yaml`)。

**這是應用層唯一該碰的表**。所有 Kogito 引擎表(族群 A/B/C)都不應該被業務代碼直接 SQL 操作。

**欄位摘要**:
```sql
CREATE TABLE workflow_execution_log (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    workflow_id  TEXT,    -- e.g. 'saga2-transfer-workflow'
    business_key TEXT,    -- 業務鍵,e.g. 訂單號 / 帳號
    status       TEXT,    -- 'SUCCESS' | 'FAILED' | 'ROLLED_BACK'
    message      TEXT,    -- 人類可讀訊息(e.g. 'AMT > 500 觸發 saga 回沖 (LIFO)')
    input_data   TEXT,    -- JSON:workflow 完整輸入
    output_data  TEXT,    -- JSON:workflow 完整輸出(含各 API 回傳碼)
    created_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

**View 魔法**:`vw_saga_reconciliation` 用 `json_extract()` 把 input_data 內的 `Account_A` / `Account_B` / `AMT` 與 output_data 內的 `a16229Result.code` / `a16229Result.message` / `a16220Result.code` / `a16220Result.message` / `a16220Rollback.code` / `a16229Rollback.code` 全部攤平成扁平欄位,直接對應 `ReconciliationCsvExporter` 的 `getHeader()` 順序。

**範例資料**:
```
id  workflow_id                business_key  status       message                          a16229_code  a16220_code  rollback
1   saga2-transfer-workflow    123456        SUCCESS      交易成功                          100/成功      100/成功      -
2   saga2-transfer-workflow    123456        ROLLED_BACK  AMT > 500 觸發 saga 回沖 (LIFO)  100/成功      100/成功      100/100
3   saga2-transfer-workflow    123456        FAILED       業務失敗或 API 錯誤               999/AMT>50   -            -
4   saga2-transfer-workflow    123456        ROLLED_BACK  A16220 業務失敗,僅回沖 A16229    100/成功      999/AMT<1000 100
```

(註:DB 內 `created_at` 是 `2026-08-17 07:32:24/30/36/40`,對應 4 次連續測試)

---

## 2.6 族群 E:引擎輔助 (Engine Auxiliary)

| Table | 用途 | 現有資料 |
|---|---|---:|
| `jobs` | Kogito timer/async 排程器的工作 | 0 |
| `kie_flyway_history_data_index` | Flyway 自己的 schema migration 紀錄 | 22 |

### `jobs` 表

- 對應 SonataFlow 的 `Timer` event 或 `Async` callback
- 每個 `process_instance_id` 可能有 0~N 個工作
- 本專案 saga 全同步,沒有 timer 事件,所以**全部為 0**
- 未來若加「24 小時後檢查轉帳是否到帳」之類,會開始有資料

### `kie_flyway_history_data_index` 表

- 標準 Flyway schema history table
- 應用啟動時 Flyway 跑 22 個 `V*.sql` 腳本後,每個成功執行的腳本寫一筆
- **schema 演進史的真相**(細節見 Ch08)

**完整記錄**:
```sql
SELECT installed_rank, version, description, success, execution_time
FROM kie_flyway_history_data_index ORDER BY installed_rank;
```

| rank | version | description | success | ms |
|---:|---|---|:---:|---:|
| 1 | 1.32.0 | data index create | ✅ | (數) |
| 2 | 1.44.0 | data index definitions | ✅ | |
| 3 | 1.45.0.0 | data index node definitions | ✅ | |
| ... | ... | ... | ✅ | |
| 22 | 1.50.0 | definitions upsert trigger | ✅ | |

---

## 2.7 族群 F:SQLite 系統 (System Tables)

| Table | 用途 | 寫入者 |
|---|---|---|
| `sqlite_sequence` | AUTOINCREMENT 計數器,給 `workflow_execution_log.id` 用 | SQLite 自動 |
| `sqlite_stat1` / `sqlite_stat4` | 查詢優化器統計(`ANALYZE` 指令後產生) | SQLite 自動 |

**這兩張表應用層不碰**。唯一會用到的是 DBA 查「目前最大 audit log id」時可以 `SELECT * FROM sqlite_sequence`。

---

## 2.8 族群快速對照卡

| 族群 | 業務相關? | 會自己寫嗎? | 出問題找誰? |
|---|:---:|:---:|---|
| A 流程實例 | 高 | ❌ 不要 | Kogito engine bug |
| B 流程定義 | 中 | ❌ 不要 | `.sw.yaml` 錯 |
| C 人工作業 | 中(未來) | ❌ 不要 | Kogito user task API |
| **D 業務審計** | **最高** | **✅ 應用層** | **`AuditLogService` 的 code** |
| E 引擎輔助 | 低 | ❌ 不要 | Kogito / Flyway |
| F SQLite 系統 | 無 | ❌ 不要 | DBA |

**記住一句話**:
> **碰到 DB 問題時,99% 的情境下你只需要擔心族群 D(`workflow_execution_log`)。** 其他 5 個族群是引擎內部狀態,有問題是 Kogito 的 bug,不是你的 code。

下一章:把族群 A/B/C/D/E 的每張表逐一展開欄位規格。

> 💡 **想看「`nodes` 怎麼對應到 .sw.yaml 靜態 DAG,以及 4 個 process 實際走了哪些路徑」** → 直接跳到 **第 10 章**(`BLOB 解析 + runtime 對齊`)。

---

# 第 3 章:每張表欄位規格

> 統一模板:用途 → 欄位表 → PK/索引 → 外鍵 → 觸發器 → 寫入點 → 讀取點 → 範例

> 為節省篇幅,本文件以**最關鍵的 5 張表**做完整展開(族群 D 業務表 + 族群 A 核心表 + 族群 B 核心表),**其餘 19 張表**用彙總表列出重點。完整 DDL 見附錄 A。

---

# 族群 A:流程實例

## 3.1 `processes` — 流程實例主表 ⭐

**用途**:每跑一次 Serverless Workflow 寫一筆,記錄該次執行的「總體狀態」。

### 欄位

| # | 欄位 | 型別 | 約束 | 預設 | 說明 |
|---|------|------|------|------|------|
| 1 | `id` | TEXT | PK, NOT NULL | — | 流程 instance ID(通常 = Kogito 自動產的 UUID) |
| 2 | `business_key` | TEXT | nullable | NULL | 業務鍵,業務層可塞訂單號/帳號等 |
| 3 | `end_time` | TEXT | nullable | NULL | epoch millis,workflow 結束才填 |
| 4 | `endpoint` | TEXT | nullable | NULL | 對外的 callback endpoint |
| 5 | `message` | TEXT | nullable | NULL | 結束時的訊息(錯誤訊息 / 成功訊息) |
| 6 | `node_definition_id` | TEXT | nullable | NULL | 當前停在哪個節點(若未結束) |
| 7 | `last_update_time` | TEXT | nullable | NULL | 任何欄位變更時更新 |
| 8 | `parent_process_instance_id` | TEXT | nullable | NULL | 子流程的父流程 ID |
| 9 | `process_id` | TEXT | nullable | NULL | workflow 定義 ID,對應 `definitions.id` |
| 10 | `process_name` | TEXT | nullable | NULL | workflow 顯示名稱,如 "Saga2 Transfer Workflow" |
| 11 | `root_process_id` | TEXT | nullable | NULL | 最上層流程定義 ID |
| 12 | `root_process_instance_id` | TEXT | nullable | NULL | 最上層流程 instance ID |
| 13 | `start_time` | TEXT | nullable | NULL | epoch millis,workflow 啟動時間 |
| 14 | `state` | INTEGER | nullable | NULL | **1=Active, 2=Completed, 3=Aborted**(見 Ch06 字典) |
| 15 | `variables` | TEXT | nullable | NULL | workflow 全域變數,JSON 格式(註: `-- was jsonb` 從 PG 移植) |
| 16 | `version` | TEXT | nullable | NULL | workflow 定義版本,對應 `definitions.version` |
| 17 | `created_by` | TEXT | nullable | NULL | 觸發者(security context) |
| 18 | `updated_by` | TEXT | nullable | NULL | 最後更新者 |
| 19 | `sla_due_date` | TEXT | nullable | NULL | SLA 到期日(epoch millis) |
| 20 | `node_instance_id` | TEXT | nullable | NULL | 當前節點 instance ID |
| 21 | `cloud_event_id` | TEXT | nullable | NULL | CloudEvents 整合的 event id |
| 22 | `cloud_event_source` | TEXT | nullable | NULL | CloudEvents 整合的 event source |

### 索引

- **PK**:`id`
- 無額外索引(高頻查詢通常透過 `business_key`,但目前無業務鍵索引 — 見 Ch09 維運建議)

### 外鍵

- 無外鍵約束(邏輯上指向 `definitions(id, version)`,但鬆綁)

### 觸發器

- 無

### 寫入點

| 事件 | 寫入者 | 程式碼路徑 |
|---|---|---|
| workflow 啟動 | Kogito engine | 透過 `kogito-event-driven-runtime` → `EventPublisher` |
| 狀態變更 | Kogito engine | 同上,event 觸發 |
| workflow 結束 | Kogito engine | 同上,`state` 從 1 改為 2 或 3 |

### 讀取點

- GraphQL:`POST /graphql` 查 `ProcessInstances`(見 Ch07)
- 應用層:**不直接讀**(從 Kogito Data Index GraphQL 查)

### 範例資料(從現有 DB 拉)

```
id                                   business_key  process_name              state  start                   end
dae4022d-0d1b-4073-a510-129176738772  NULL          Saga2 Transfer Workflow    2     2026-08-17 07:32:24    2026-08-17 07:32:24
75268679-6cd8-4e44-bbc8-0dfc3aa3dcbd  NULL          Saga2 Transfer Workflow    2     2026-08-17 07:32:30    2026-08-17 07:32:30
e4f8329a-1c16-4d66-9383-669589d8327d  NULL          Saga2 Transfer Workflow    2     2026-08-17 07:32:36    2026-08-17 07:32:36
30b63fb8-0659-4fae-8978-792530d22ca8  NULL          Saga2 Transfer Workflow    2     2026-08-17 07:32:40    2026-08-17 07:32:40
```

---

## 3.2 `nodes` — 流程節點執行紀錄 ⭐

**用途**:一個 process instance 跑過的每個節點 + enter/exit 時間戳。

### 欄位

| # | 欄位 | 型別 | 約束 | 預設 | 說明 |
|---|------|------|------|------|------|
| 1 | `id` | TEXT | PK, NOT NULL | — | node instance ID |
| 2 | `definition_id` | TEXT | nullable | NULL | 該節點的靜態定義 ID |
| 3 | `enter` | TEXT | nullable | NULL | 進入時間(epoch millis) |
| 4 | `exit` | TEXT | nullable | NULL | 離開時間(epoch millis) |
| 5 | `name` | TEXT | nullable | NULL | 節點名稱,如 "CallA16229State" |
| 6 | `node_id` | TEXT | nullable | NULL | 靜態節點 ID(對應 definitions_nodes.id) |
| 7 | `type` | TEXT | nullable | NULL | 節點類型(見 Ch06 字典) |
| 8 | `process_instance_id` | TEXT | FK → processes(id) ON DELETE CASCADE, NOT NULL | — | 所屬流程 instance |
| 9 | `sla_due_date` | TEXT | nullable | NULL | SLA 到期(epoch millis) |
| 10 | `retrigger` | INTEGER | NOT NULL | 0 | 重入次數(retry/loop 計數) |
| 11 | `error_message` | TEXT | nullable | NULL | 該節點執行失敗時的訊息 |
| 12 | `cancel_type` | TEXT | nullable | NULL | 取消類型(若該節點被取消) |
| 13 | `input_args` | TEXT | nullable | NULL | 節點輸入參數(JSON) |
| 14 | `output_args` | TEXT | nullable | NULL | 節點輸出結果(JSON) |

### 索引

- **PK**:`id`
- **IDX**:`idx_nodes_piid ON (process_instance_id)`

### 範例資料(取自現有 DB 的 1 個 process)

```
id                                   name                     type                  enter                exit                 retrigger
3bf6522f-c3d1-4d2d-a85b-aaaa54d8c27c ValidateInput           Split                 1786951944365        1786951944612        0
2fb548f7-0cfe-47c2-893c-d281a1df5c0f CallA16229State         CompositeContextNode  1786951944420        1786951944612        0
d1a0dc83-d384-4045-af46-33789cde362c EmbeddedStart           StartNode             1786951944420        1786951944612        0
37162526-29f7-4f56-8bfb-052822b298d6 callApiViaOpenAPI       WorkItemNode          1786951944420        1786951944612        0
609e7152-80f3-4eaf-8317-0f7f7126a8b6 Script                  ActionNode            1786951944563        1786951944612        0
```

### 其他族群 A 表(摘要)

| Table | 重點 | 寫入時機 |
|---|---|---|
| `milestones` | (id, process_instance_id) 複合 PK,FK→processes,記錄長流程里程碑 | workflow 通過 `milestone` 標記時 |
| `processes_addons` | (process_id, addon) 複合 PK,FK→processes,instance 層級 addon | workflow 啟動時讀取定義 + 帶入 |
| `processes_roles` | (process_id, role) 複合 PK,FK→processes,instance 層級角色 | 同上 |

---

# 族群 B:流程定義

## 3.3 `definitions` — 流程定義主表 ⭐

**用途**:deploy 進引擎的 `.sw.yaml` 完整內容 + 元資料。

### 欄位

| # | 欄位 | 型別 | 約束 | 預設 | 說明 |
|---|------|------|------|------|------|
| 1 | `id` | TEXT | PK(part 1), NOT NULL | — | workflow 定義 ID,如 "saga2-transfer-workflow" |
| 2 | `version` | TEXT | PK(part 2), NOT NULL | — | 版本,如 "2.0.0" |
| 3 | `name` | TEXT | nullable | NULL | 顯示名稱 |
| 4 | `type` | TEXT | nullable | NULL | 固定 "SW"(Serverless Workflow) |
| 5 | `source` | BLOB | nullable | NULL | 完整 `.sw.yaml` 內容,UTF-8 bytes |
| 6 | `endpoint` | TEXT | nullable | NULL | 對外 endpoint |
| 7 | `description` | TEXT | nullable | NULL | 描述 |
| 8 | `metadata` | TEXT | nullable | NULL | metadata JSON |

### 索引 / 觸發器

- **PK**:複合 `(id, version)`
- **TRIGGER**:`definitions_upsert_trigger`(INSERT 前檢查重複 → DELETE 再 INSERT,支援熱更新)

### 範例

```
id                          version   name                          type  source_size
saga2-transfer-workflow     2.0.0     Saga2 Transfer Workflow       SW    12459 bytes
saga-transfer-workflow      15.0.0    Saga Transfer Workflow        SW    7086 bytes
OpenAPI-workflow            1.0.0     My First Workflow             SW    9200 bytes
java-workflow               1.0.0     My First Java Service ...     SW    5511 bytes
rest-workflow               1.0.0     My First REST Workflow        SW    9761 bytes
```

### 其他族群 B 表(摘要)

| Table | 重點 | 數量 |
|---|---|---:|
| `definitions_nodes` | (id, process_id, process_version) 複合 PK,FK→definitions,靜態節點拓樸 | 134 |
| `definitions_nodes_metadata` | (node_id, process_id, process_version, name) 複合 PK,FK→definitions_nodes,節點 metadata | (隨 nodes) |
| `definitions_addons` | (process_id, process_version, addon) 複合 PK,FK→definitions,addon 清單 | 0 |
| `definitions_roles` | (process_id, process_version, role) 複合 PK,FK→definitions,角色清單 | 0 |
| `definitions_annotations` | (annotation, process_id, process_version) 複合 PK,FK→definitions,註解 | 0 |

### 統計(從現有 DB 拉)

```
definitions_nodes 按 type 統計:
Script              ActionNode         35
EmbeddedEnd         EndNode            16
EmbeddedStart       StartNode          16
End                 EndNode             8
Start               StartNode           5
callApiViaOpenAPI   WorkItemNode        5
FetchDataState      CompositeContextNode 3
callA16229          WorkItemNode        3
CallA16220State     CompositeContextNode 2
CheckA16220Result   Split               2
...
```

---

# 族群 C:人工作業(本專案未使用,簡列)

| Table | 重點欄位 | 用途 |
|---|---|---|
| `tasks` | id PK, process_instance_id FK, state, actual_owner, priority, started, completed | User task 主表 |
| `tasks_admin_users` | (task_id, user_id) 複合 PK,FK→tasks | 管理員(個體) |
| `tasks_admin_groups` | (task_id, group_id) 複合 PK,FK→tasks | 管理員(群組) |
| `tasks_potential_users` | (task_id, user_id) 複合 PK,FK→tasks | 候選人(個體) |
| `tasks_potential_groups` | (task_id, group_id) 複合 PK,FK→tasks | 候選人(群組) |
| `tasks_excluded_users` | (task_id, user_id) 複合 PK,FK→tasks | 排除人 |
| `attachments` | id PK, task_id FK→tasks, content, name | 附件 |
| `comments` | id PK, task_id FK→tasks, content, name | 留言 |

> **現有資料:全部 0 筆**。saga workflow 沒有 `UserTask` 節點。

---

# 族群 D:業務審計 ⭐⭐

## 3.4 `workflow_execution_log` — 業務審計主表 ⭐⭐

**用途**:**這個專案最重要的業務表**。每次 workflow 結束寫一筆,JSON 存 input/output,給對帳 CSV 引擎讀。

### 欄位

| # | 欄位 | 型別 | 約束 | 預設 | 說明 |
|---|------|------|------|------|------|
| 1 | `id` | INTEGER | PK, NOT NULL, AUTOINCREMENT | (seq) | 流水號 |
| 2 | `workflow_id` | TEXT | nullable | NULL | workflow 名稱,如 "saga2-transfer-workflow" |
| 3 | `business_key` | TEXT | nullable | NULL | 業務鍵,如訂單號 |
| 4 | `status` | TEXT | nullable | NULL | 'SUCCESS' \| 'FAILED' \| 'ROLLED_BACK' |
| 5 | `message` | TEXT | nullable | NULL | 人類可讀訊息 |
| 6 | `input_data` | TEXT | nullable | NULL | workflow 完整輸入,JSON |
| 7 | `output_data` | TEXT | nullable | NULL | workflow 完整輸出,JSON(含各 API 回傳碼) |
| 8 | `created_at` | TIMESTAMP | nullable | CURRENT_TIMESTAMP | 寫入時間 |

### 索引

- **PK**:`id`(內部 AUTOINCREMENT 計數器在 `sqlite_sequence`)

### 寫入點

- `domain-reconciliation/reconciliation-api/.../AuditLogService.saveLog()`
- 觸發者:saga workflow 內的 `recordAuditLog` function
- 觸發時機:workflow 結束時(不論 SUCCESS/FAILED/ROLLED_BACK 都會寫)

### 讀取點

- `reconciliation-api/.../ReconciliationCsvExporter.generateCsv()`
- `reconciliation-api/.../ReconciliationResource.exportCsv()`(HTTP endpoint)

### 範例資料(完整 4 筆)

```
id  workflow_id               business_key  status       message                                input_data
1   saga2-transfer-workflow   123456        SUCCESS      交易成功                                {"Account_A":"123456","AMT":100,"Account_B":"A12345"}
2   saga2-transfer-workflow   123456        ROLLED_BACK  AMT > 500 觸發 saga 回沖 (LIFO)        {"Account_A":"123456","AMT":600,"Account_B":"A12345"}
3   saga2-transfer-workflow   123456        FAILED       業務失敗或 API 錯誤                     {"Account_A":"123456","AMT":30,"Account_B":"A12345"}
4   saga2-transfer-workflow   123456        ROLLED_BACK  A16220 業務失敗,僅回沖 A16229          {"Account_A":"123456","AMT":2000,"Account_B":"A12345"}
```

---

# 族群 E:引擎輔助

## 3.5 `jobs` — 排程器工作

### 欄位摘要

| 欄位 | 用途 |
|---|---|
| `id` (PK) | job ID |
| `callback_endpoint` | 完成時 callback 位置 |
| `endpoint` | 對外 endpoint |
| `execution_counter` | 已執行次數 |
| `expiration_time` | 到期時間 |
| `last_update` | 最後更新 |
| `node_instance_id` | 對應的 node instance |
| `priority` | 排程優先級 |
| `process_id` / `process_instance_id` | 觸發的流程 |
| `repeat_interval` / `repeat_limit` | 重複設定 |
| `retries` | 已重試次數 |
| `root_process_id` / `root_process_instance_id` | 最上層 |
| `scheduled_id` | 排程 ID |
| `status` | 狀態 |
| `exception_message` | 錯誤訊息 |
| `exception_details` | 錯誤細節(完整 stacktrace) |

### 索引

- **PK**:`id`
- **IDX**:`idx_jobs_piid ON (process_instance_id)`

### 現有資料

```
0 筆 — 本專案 saga workflow 沒有 timer 事件
```

## 3.6 `kie_flyway_history_data_index` — Flyway schema history

標準 Flyway 5 欄位:`installed_rank` (PK) / `version` / `description` / `type` / `script` / `checksum` / `installed_by` / `installed_on` / `execution_time` / `success`。

**現有資料**:22 筆,對應 22 個 `V*.sql` 腳本(細節見 Ch08)。

---

# 族群 F:SQLite 系統(略,見 Ch02)

---

# 附錄:全部 24 張表一覽

| # | Table | 族群 | 現有資料 | 寫入者 |
|---:|---|---|---:|---|
| 1 | `processes` | A | 4 | Kogito |
| 2 | `nodes` | A | 118 | Kogito |
| 3 | `milestones` | A | 0 | Kogito |
| 4 | `processes_addons` | A | 0 | Kogito |
| 5 | `processes_roles` | A | 0 | Kogito |
| 6 | `definitions` | B | 5 | Kogito |
| 7 | `definitions_nodes` | B | 134 | Kogito |
| 8 | `definitions_nodes_metadata` | B | (隨) | Kogito |
| 9 | `definitions_addons` | B | 0 | Kogito |
| 10 | `definitions_roles` | B | 0 | Kogito |
| 11 | `definitions_annotations` | B | 0 | Kogito |
| 12 | `tasks` | C | 0 | Kogito |
| 13 | `tasks_admin_users` | C | 0 | Kogito |
| 14 | `tasks_admin_groups` | C | 0 | Kogito |
| 15 | `tasks_potential_users` | C | 0 | Kogito |
| 16 | `tasks_potential_groups` | C | 0 | Kogito |
| 17 | `tasks_excluded_users` | C | 0 | Kogito |
| 18 | `attachments` | C | 0 | Kogito |
| 19 | `comments` | C | 0 | Kogito |
| 20 | `jobs` | E | 0 | Kogito |
| 21 | `kie_flyway_history_data_index` | E | 22 | Flyway |
| 22 | **`workflow_execution_log`** | **D** | **4** | **應用層** |
| 23 | `sqlite_sequence` | F | 1 | SQLite 自動 |
| 24 | (其他系統表) | F | — | SQLite 自動 |

> **業務最重要**:**#22 `workflow_execution_log`**(族群 D)。其他 23 張不是引擎內部就是系統表。

下一章:視圖與觸發器。

---

# 第 4 章:視圖 (View) 與觸發器 (Trigger)

> `reconciliation.db` 只有 1 個 View 和 1 個 Trigger,但都是業務關鍵設計。

---

## 4.1 View: `vw_saga_reconciliation` ⭐

### 完整 DDL

```sql
CREATE VIEW vw_saga_reconciliation AS
SELECT
    id,
    created_at,
    workflow_id,
    business_key,
    status,
    message,
    -- 從 input_data JSON 拆出
    json_extract(input_data, '$.Account_A') AS account_a,
    json_extract(input_data, '$.Account_B') AS account_b,
    json_extract(input_data, '$.AMT')       AS amt,
    -- 從 output_data JSON 拆出
    json_extract(output_data, '$.a16229Result.code')    AS a16229_code,
    json_extract(output_data, '$.a16229Result.message') AS a16229_msg,
    json_extract(output_data, '$.a16220Result.code')    AS a16220_code,
    json_extract(output_data, '$.a16220Result.message') AS a16220_msg,
    json_extract(output_data, '$.a16220Rollback.code')  AS a16220_rollback_code,
    json_extract(output_data, '$.a16229Rollback.code')  AS a16229_rollback_code
FROM workflow_execution_log
WHERE workflow_id = 'saga2-transfer-workflow';
```

### 設計目的

把 `workflow_execution_log` 內 JSON 結構的 input/output **攤平**成扁平欄位,讓 `ReconciliationCsvExporter` 可以直接 `SELECT *` 然後逐欄位寫入 CSV,不用在 Java 端再寫一層 JSON parsing。

### JSON 路徑對映

| View 欄位 | 來源 | JSON 路徑 | 範例值 |
|---|---|---|---|
| `account_a` | input_data | `$.Account_A` | `"123456"` |
| `account_b` | input_data | `$.Account_B` | `"A12345"` |
| `amt` | input_data | `$.AMT` | `100` |
| `a16229_code` | output_data | `$.a16229Result.code` | `100` |
| `a16229_msg` | output_data | `$.a16229Result.message` | `"成功"` |
| `a16220_code` | output_data | `$.a16220Result.code` | `100` |
| `a16220_msg` | output_data | `$.a16220Result.message` | `"成功"` |
| `a16220_rollback_code` | output_data | `$.a16220Rollback.code` | `100` 或 NULL |
| `a16229_rollback_code` | output_data | `$.a16229Rollback.code` | `100` 或 NULL |

### WHERE 過濾

`WHERE workflow_id = 'saga2-transfer-workflow'` — 只給 saga2 用的 view。

**為什麼用 view 而不是直接 SQL?** 兩個原因:
1. **業務語意封裝**:`ReconciliationCsvExporter` 不需要知道 JSON 路徑,只 SELECT 扁平欄位
2. **效能**:SQLite 的 view 沒有實體化成本,query planner 會把它視為 subquery 展開

### 對應程式碼

```java
// ReconciliationCsvExporter.java
public String generateCsv() {
    StringBuilder csv = new StringBuilder();
    csv.append("id,created_at,workflow_id,business_key,status,message,")
       .append("account_a,account_b,amt,")
       .append("a16229_code,a16229_msg,a16220_code,a16220_msg,")
       .append("a16229_rollback_code,a16220_rollback_code\n");

    try (PreparedStatement ps = conn.prepareStatement(
            "SELECT * FROM vw_saga_reconciliation ORDER BY id")) {
        ResultSet rs = ps.executeQuery();
        while (rs.next()) {
            // 逐欄位寫入 CSV
        }
    }
    return csv.toString();
}
```

> Header 順序與 view 欄位順序**嚴格一致**(Ch06 會驗證)。

### 範例資料

```
id  created_at            workflow_id              business_key  status       message                           account_a  account_b  amt   a16229_code  a16229_msg  a16220_code  a16220_msg  a16220_rb  a16229_rb
1   2026-08-17 07:32:24   saga2-transfer-workflow  123456        SUCCESS      交易成功                           123456     A12345     100   100          成功         100          成功         NULL       NULL
2   2026-08-17 07:32:30   saga2-transfer-workflow  123456        ROLLED_BACK  AMT > 500 觸發 saga 回沖 (LIFO)   123456     A12345     600   100          成功         100          成功         100        100
3   2026-08-17 07:32:36   saga2-transfer-workflow  123456        FAILED       業務失敗或 API 錯誤                123456     A12345     30    999          AMT必須大於50 NULL        NULL        NULL       NULL
4   2026-08-17 07:32:40   saga2-transfer-workflow  123456        ROLLED_BACK  A16220 業務失敗,僅回沖 A16229     123456     A12345     2000  100          成功         999          AMT必須小於1000 100      NULL
```

> 注意:RUN 2 是 LIFO 雙沖 → 兩個 rollback code 都有值;RUN 4 是單沖 → 只有 `a16220_rollback_code` 有值。

### 對應檔案

- 視圖建立:`platform-extensions/data-index-storage-sqlite/src/main/resources/kie-flyway/db/data-index/sqlite/`(由應用層透過 Hibernate auto-DDL 或手動 SQL 建立 — 待 Ch05 釐清)
- 使用者:`domain-reconciliation/reconciliation-api/src/main/java/com/example/reconciliation/ReconciliationCsvExporter.java`
- 暴露:`ReconciliationResource.exportCsv()` 端點

---

## 4.2 Trigger: `definitions_upsert_trigger`

### 完整 DDL

```sql
CREATE TRIGGER definitions_upsert_trigger
BEFORE INSERT ON definitions
FOR EACH ROW
WHEN EXISTS (SELECT 1 FROM definitions WHERE id = NEW.id AND version = NEW.version)
BEGIN
    DELETE FROM definitions WHERE id = NEW.id AND version = NEW.version;
END;
```

### 為什麼要這個 trigger?

**問題**:Kogito 啟動時,每掃到一個 `.sw.yaml` 都會對 `definitions` 做 INSERT。但開發期間常會:
- 修一個 workflow 然後重啟 Quarkus
- 同一個 `id+version` 已經在 DB 裡
- 沒有 trigger 就會撞 PK violation,Quarkus 啟動失敗

**解法**:BEFORE INSERT 觸發,若同 `id+version` 已存在,**先 DELETE 再讓 INSERT 進來**,達成「**熱替換定義**」的效果。

### 觸發時機

```
Quarkus 啟動
  ↓
掃描 classpath:*.sw.yaml
  ↓
對每個 workflow 觸發 DefinitionDeployer.deploy()
  ↓
嘗試 INSERT INTO definitions(id, version, source, ...)
  ↓
[BEFORE INSERT] trigger 檢查同 id+version 是否已存在
  ├─ 不存在 → 正常 INSERT
  └─ 存在 → DELETE 舊的 → INSERT 新的(覆蓋 source BLOB)
```

### 級聯效果

注意:**只刪 `definitions` 主表,不級聯刪 `definitions_nodes` / `definitions_nodes_metadata` 等子表**。

但因爲子表都有 `FOREIGN KEY ... ON DELETE CASCADE` 指向 `definitions(id, version)`,所以 trigger 的 DELETE 會自動把該版本的子表記錄也清掉。

```mermaid
sequenceDiagram
    autonumber
    participant Q as Quarkus
    participant D as DefinitionDeployer
    participant DB as definitions 表
    participant Sub as definitions_nodes 等

    Q->>D: deploy(saga2-transfer-workflow, 2.0.0)
    D->>DB: INSERT INTO definitions
    activate DB
    DB->>DB: [TRIGGER] SELECT ... WHERE id+version
    alt 已存在
        DB->>DB: DELETE FROM definitions
        DB->>Sub: ON DELETE CASCADE → 清子表
    end
    DB-->>D: INSERT 完成
    deactivate DB
    D->>Sub: INSERT INTO definitions_nodes ...
```

### 對應檔案

- Trigger 建立:`platform-extensions/data-index-storage-sqlite/src/main/resources/kie-flyway/db/data-index/sqlite/V1.50.0__definitions_upsert_trigger.sql`
- 觸發者:Kogito `DefinitionDeployer`(`kogito-data-index-storage-api` 模組,本專案沒客製化)
- 對應 Flyway 版本:`V1.50.0`(第 22 個,也是最新一個)

### 注意事項

- 觸發時**不會清掉 `processes` / `nodes`**:running 與歷史的 runtime 紀錄會被保留,但指向已不存在的定義版本
- 這對開發是好事(可以看到舊 runtime 用舊定義跑的痕跡),但生產環境要嚴謹管理 version 號

---

## 4.3 沒有其他 View / Trigger

`reconciliation.db` 目前只有上述 1 view + 1 trigger。後續若要加:
- **多語言 view**(例:`vw_saga_reconciliation_en` 把 `message` 翻成英文)→ 加 view
- **自動 archive trigger**(例:刪 `workflow_execution_log` 30 天前資料)→ 加 trigger
- **聚合 table**(例:`daily_reconciliation_summary` 每日統計)→ 加 table + 排程

---

## 4.4 為什麼 `processes` / `nodes` 沒建 view?

雖然 `nodes` 表 118 列散落在 4 個 process,但其**資訊已能直接用 `process_instance_id` + `name` 索引查詢**,SQLite 不需要額外 view。

Kogito Data Index 預設透過 **GraphQL endpoint** 暴露 `ProcessInstances` / `NodeInstances` 兩個查詢根節點(見 Ch07),比 view 強大得多。

下一章:把所有 24 張表對應到具體程式碼檔案。

---

# 第 5 章:對應程式碼 (Source Code Mapping)

> 本章回答三個問題:
> 1. **誰寫這張表?**(寫入端 mapping)
> 2. **誰讀這張表?**(讀取端 mapping)
> 3. **對應的 Hibernate entity / Flyway script 在哪?**

---

## 5.1 寫入端對映總表(24 張表)

| Table | 寫入者 | 觸發時機 | 程式碼路徑 |
|---|---|---|---|
| `processes` | Kogito engine | workflow 啟動/結束 | `kogito-data-index-storage-api` (外部依賴,本專案未改) |
| `nodes` | Kogito engine | 節點 enter/exit | 同上 |
| `milestones` | Kogito engine | milestone 事件 | 同上 |
| `processes_addons` | Kogito engine | workflow 啟動讀取定義 | 同上 |
| `processes_roles` | Kogito engine | workflow 啟動讀取定義 | 同上 |
| `definitions` | Kogito engine | Quarkus 啟動 deploy | 同上 |
| `definitions_nodes` | Kogito engine | 同上 | 同上 |
| `definitions_nodes_metadata` | Kogito engine | 同上 | 同上 |
| `definitions_addons` | Kogito engine | 同上 | 同上 |
| `definitions_roles` | Kito engine | 同上 | 同上 |
| `definitions_annotations` | Kogito engine | 同上 | 同上 |
| `tasks` | Kogito engine | UserTask 節點觸發 | 同上(本專案無) |
| `tasks_admin_users` | Kogito engine | 同上 | 同上(本專案無) |
| `tasks_admin_groups` | Kogito engine | 同上 | 同上(本專案無) |
| `tasks_potential_users` | Kogito engine | 同上 | 同上(本專案無) |
| `tasks_potential_groups` | Kogito engine | 同上 | 同上(本專案無) |
| `tasks_excluded_users` | Kogito engine | 同上 | 同上(本專案無) |
| `attachments` | Kogito engine | UserTask 附件上傳 | 同上(本專案無) |
| `comments` | Kogito engine | UserTask 留言 | 同上(本專案無) |
| `jobs` | Kogito engine | timer/async 事件觸發 | 同上(本專案無) |
| `kie_flyway_history_data_index` | Flyway | 應用啟動跑 migration | Flyway runtime |
| **`workflow_execution_log`** | **應用層** | **saga workflow 結束** | **`AuditLogService.saveLog()`** |
| `sqlite_sequence` | SQLite 系統 | AUTOINCREMENT 觸發 | (系統) |

### 應用層唯一寫入點:`AuditLogService`

```
domain-reconciliation/reconciliation-api/src/main/java/com/example/reconciliation/AuditLogService.java
```

```java
@ApplicationScoped
public class AuditLogService {
    @Inject AgroalDataSource ds;

    public void saveLog(String workflowId, String businessKey,
                        String status, String message,
                        String inputDataJson, String outputDataJson) {
        String sql = "INSERT INTO workflow_execution_log " +
                     "(workflow_id, business_key, status, message, " +
                     " input_data, output_data) VALUES (?,?,?,?,?,?)";
        try (Connection c = ds.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, workflowId);
            ps.setString(2, businessKey);
            ps.setString(3, status);
            ps.setString(4, message);
            ps.setString(5, inputDataJson);
            ps.setString(6, outputDataJson);
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Failed to save audit log", e);
        }
    }
}
```

> ⚠️ **注意**:用裸 JDBC + PreparedStatement,沒過 JPA/Hibernate。因為 `workflow_execution_log` 不在 Kogito 的 entity model 內,Hibernate 不會幫你管它。

### 觸發 AuditLogService 的 function

```
domain-transfer/transfer-workflow/src/main/resources/saga2-transfer-workflow.sw.yaml
```

```yaml
functions:
  - name: recordAuditLog
    operation: 'service:com.example.reconciliation.AuditLogService::saveLog'
    type: custom
```

Saga workflow 結束前的 `FinalAuditAndEnd` state 會呼叫 `recordAuditLog`,把整個 workflow 的 `input` + `output` 整包塞進去。

---

## 5.2 讀取端對映總表(可被查詢的表)

| Table | 讀取者 | API/端點 | 程式碼路徑 |
|---|---|---|---|
| `processes` | Kogito GraphQL | `POST /graphql` query `ProcessInstances` | `kogito-data-index` 內建 endpoint |
| `nodes` | Kogito GraphQL | `query NodeInstances` | 同上 |
| `milestones` | Kogito GraphQL | `query Milestones` | 同上 |
| `tasks` | Kogito GraphQL | `query UserTaskInstances` | 同上(本專案無資料) |
| `jobs` | Kogito GraphQL | `query Jobs` | 同上(本專案無資料) |
| `definitions` | Kogito GraphQL | `query ProcessDefinitions` | 同上 |
| `workflow_execution_log` | **應用層** | `GET /reconciliation/export-csv` | **`ReconciliationCsvExporter` + `ReconciliationResource`** |
| `vw_saga_reconciliation` | **應用層** | (同上) | **`ReconciliationCsvExporter`** |

### 應用層唯一讀取點:`ReconciliationCsvExporter`

```
domain-reconciliation/reconciliation-api/src/main/java/com/example/reconciliation/ReconciliationCsvExporter.java
```

```java
@ApplicationScoped
public class ReconciliationCsvExporter {
    @Inject AgroalDataSource ds;

    public String generateCsv() throws SQLException {
        StringBuilder csv = new StringBuilder();
        // header
        csv.append("id,created_at,workflow_id,business_key,status,message,")
           .append("account_a,account_b,amt,")
           .append("a16229_code,a16229_msg,a16220_code,a16220_msg,")
           .append("a16229_rollback_code,a16220_rollback_code\n");

        try (Connection c = ds.getConnection();
             PreparedStatement ps = c.prepareStatement(
                 "SELECT * FROM vw_saga_reconciliation ORDER BY id");
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                csv.append(rs.getInt("id")).append(',')
                   .append(rs.getString("created_at")).append(',')
                   // ... 15 個欄位 ...
                   .append('\n');
            }
        }
        return csv.toString();
    }
}
```

### 暴露 HTTP 端點:`ReconciliationResource`

```
domain-reconciliation/reconciliation-api/src/main/java/com/example/reconciliation/ReconciliationResource.java
```

```java
@Path("/reconciliation")
public class ReconciliationResource {
    @Inject ReconciliationCsvExporter exporter;

    @GET
    @Path("/export-csv")
    @Produces("text/csv")
    public Response exportCsv() throws SQLException {
        String csv = exporter.generateCsv();
        return Response.ok(csv)
                       .header("Content-Disposition", "attachment; filename=reconciliation.csv")
                       .build();
    }
}
```

---

## 5.3 Hibernate Entity 對映(平台層)

`platform-data-index` 模組提供了**自訂 SQLite dialect**,把 Kogito 的 JPA entity 對應到 SQLite column type。

```
platform-data-index/src/main/java/org/acme/platform/dataindex/KogitoSQLiteDialect.java
```

關鍵改動:
- `ZonedDateTime` → `TEXT`(SQLite 無原生 timestamp,用 ISO-8601 字串)
- `JSONB`(PostgreSQL 專屬)→ `TEXT`(`SqliteZonedDateTimeJdbcType.java` 提供)
- `bytea`(PostgreSQL 專屬)→ `BLOB`(`definitions.source` 用的)

對應檔案:

| 檔案 | 角色 |
|---|---|
| `KogitoSQLiteDialect.java` | 註冊自訂 dialect 到 Hibernate |
| `MyLivenessCheck.java` | 健康檢查 endpoint,SQL: `SELECT 1` |
| `SqliteZonedDateTimeJdbcType.java` | Hibernate `JdbcType` SPI:把 `ZonedDateTime` 序列化成 `TEXT` |

---

## 5.4 Flyway Script 對映(22 個 → 22 張表 + 1 trigger)

路徑:`platform-extensions/data-index-storage-sqlite/src/main/resources/kie-flyway/db/data-index/sqlite/`

| 順序 | Flyway 版本 | 檔名 | 影響的物件 |
|---:|---|---|---|
| 1 | 1.32.0 | `V1.32.0__data_index_create.sql` | 初始:processes, nodes, milestones, processes_*, tasks, tasks_*, attachments, comments, jobs(主表) |
| 2 | 1.44.0 | `V1.44.0__data_index_definitions.sql` | 新增:definitions, definitions_nodes, definitions_*, triggers 基本 |
| 3 | 1.45.0.0 | `V1.45.0.0__data_index_node_definitions.sql` | definitions_nodes 加欄位 |
| 4 | 1.45.0.1 | `V1.45.0.1__add_identity_to_process_instance.sql` | processes 加 `created_by` / `updated_by` |
| 5 | 1.45.0.2 | `V1.45.0.2__data_index_definitions_add_columns.sql` | definitions 加 `description` / `metadata` |
| 6 | 1.45.0.3 | `V1.45.0.3__add_fk_index.sql` | 多張表加 FK 索引 |
| 7 | 1.45.0.4 | `V1.45.0.4__increase_varchar_length.sql` | 擴大 VARCHAR |
| 8 | 1.45.0.5 | `V1.45.0.5__add_external_reference_id.sql` | tasks 加 `external_reference_id` |
| 9 | 1.45.0.6 | `V1.45.0.6__add_sla_due_date_columns.sql` | processes 加 `sla_due_date` |
| 10 | 1.45.0.7 | `V1.45.0.7__add_sla_due_date_tasks.sql` | tasks 加 `sla_due_date` |
| 11 | 1.45.0.8 | `V1.45.0.8__modify_columns_with_reserved_words.sql` | 修正保留字欄位 |
| 12 | 1.45.0.9 | `V1.45.0.9__increase_comments_content_size.sql` | comments.content 擴大 |
| 13 | 1.45.1.0 | `V1.45.1.0__metadata_as_jsonb.sql` | metadata 改為 JSONB(在 SQLite 為 TEXT) |
| 14 | 1.45.1.1 | `V1.45.1.1__retrigger.sql` | nodes 加 `retrigger` |
| 15 | 1.45.1.2 | `V1.45.1.2__cloudevent.sql` | processes 加 cloud_event_* |
| 16 | 1.45.1.3 | `V1.45.1.3__add_cancelled_type_nodes.sql` | nodes 加 `cancel_type` |
| 17 | 1.45.1.4 | `V1.45.1.4__add_indexes_for_jobs_and_tasks.sql` | jobs/tasks 加索引 |
| 18 | 1.46.0 | `V1.46.0__add_user_task_id_column.sql` | tasks 加 `user_task_id` |
| 19 | 1.47.0 | `V1.47.0__adjust_column_sizes_in_tables_updated_by_hibernate.sql` | hibernate 自動調整 |
| 20 | 1.48.0 | `V1.48.0__add_input_output_args.sql` | nodes 加 `input_args` / `output_args` |
| 21 | 1.49.0 | `V1.49.0__add_job_exception_details.sql` | jobs 加 `exception_details` |
| 22 | 1.50.0 | `V1.50.0__definitions_upsert_trigger.sql` | **新增 trigger**:`definitions_upsert_trigger` |

> 完整 Flyway 演進史見 Ch08。

---

## 5.5 模組 ↔ 表 的所有權矩陣

| 模組 | 主要管的表 | 對映原因 |
|---|---|---|
| `platform-common` | (無) | Leaf 模組,沒有 DB 物件 |
| `platform-security` | (無直接表) | Filter 管線,不碰 DB |
| `platform-data-index` | (透過 Kogito) | 自訂 dialect + 22 個 Flyway 腳本 |
| `platform-extensions/data-index-storage-sqlite` | (Flyway scripts) | 提供 SQLite Flyway migration 檔 |
| `domain-reconciliation/reconciliation-api` | **`workflow_execution_log` + `vw_saga_reconciliation`** | 應用層唯一寫入者 + 讀取者 |
| `domain-transfer/*` | (無直接表) | workflow 透過 function 呼叫 `AuditLogService`,自己不寫 DB |
| `distribution/*` | (組裝) | 啟動時把所有模組 wire-up 起來,Flyway 跑 migration |

> **所有權**:**`workflow_execution_log` 的所有權 = `domain-reconciliation/reconciliation-api` 模組**。其他表歸 Kogito,本專案不碰。

---

## 5.6 應用層「應該 vs 不應該」對 DB 的操作

### ✅ 應該
- 透過 `AuditLogService.saveLog()` 寫 `workflow_execution_log`
- 透過 `ReconciliationCsvExporter.generateCsv()` 讀 `vw_saga_reconciliation`
- 透過 Kogito GraphQL endpoint 查 `ProcessInstances` / `NodeInstances` / `ProcessDefinitions`

### ❌ 不應該
- 直接寫 `processes` / `nodes` / `definitions` 等 Kogito 表(會破壞引擎內部狀態一致性)
- 跳過 Kogito 直接 update `processes.state`(引擎不知道,下次排程會出錯)
- 跳過 `vw_saga_reconciliation` 直接讀 `workflow_execution_log`(失去欄位語意封裝)
- 改 `definitions_*` 的 BLOB 內容(版本會對不上,trigger 也會干擾)

### ⚠️ 灰色地帶
- 刪 `processes`(理論上 Kogito 會處理,手動刪可能破壞父子流程關係)
- 改 `nodes.cancel_type`(若 Saga 補償中,引擎還在寫,可能 race condition)

下一章:把這章節的「寫入點」串起來,看一筆 saga 交易的完整 lifecycle。

---

# 第 6 章:流程 Lifecycle 紀錄(業務視角) ⭐

> 從一筆真實的 saga 交易出發,追蹤它在 DB 內的所有痕跡。
> **本章使用真實資料** — 從現有 `reconciliation.db` 內 4 筆 audit log 對應的 4 個 process instance 拉出。

---

## 6.1 端到端時序圖:一筆 saga 交易從 HTTP 到 CSV

```mermaid
sequenceDiagram
    autonumber
    actor U as 客戶端
    participant T as transfer-app<br/>(:8080)
    participant SF as SonataFlow Engine
    participant DB as reconciliation.db
    participant A as AuditLogService
    participant C as reconciliation-app<br/>(:8081)
    participant CSV as CSV Exporter

    U->>T: POST /saga2-transfer-workflow<br/>{Account_A, Account_B, AMT}
    T->>SF: 啟動 workflow instance
    SF->>DB: INSERT INTO processes<br/>(state=1, start_time, ...)
    Note over DB: processes 表 +1
    
    loop 經過每個 state
        SF->>DB: INSERT INTO nodes<br/>(name, type, enter=now)
        Note over DB: nodes 表 +N
        SF->>DB: UPDATE nodes<br/>SET exit=now
    end
    
    SF->>DB: UPDATE processes<br/>SET state=2/3, end_time=now
    Note over DB: processes 結束
    
    SF->>A: 呼叫 recordAuditLog function
    A->>DB: INSERT INTO workflow_execution_log
    Note over DB: audit log +1
    
    Note over U,C: ── 時間過去,管理員查對帳 ──
    
    U->>C: GET /reconciliation/export-csv
    C->>CSV: generateCsv()
    CSV->>DB: SELECT * FROM vw_saga_reconciliation
    DB-->>CSV: 4 列扁平資料
    CSV-->>C: CSV 字串
    C-->>U: text/csv 附件
```

**3 個 DB 寫入事件**:
1. workflow 啟動 → `processes +1` + `nodes +1`(起點)
2. 節點 enter/exit → `nodes +N`
3. workflow 結束 → `processes` 更新 + `workflow_execution_log +1`

---

## 6.2 生命週期 5 個階段(對應 DB 寫入事件)

### 階段 1:接收請求
```
時間:T+0
事件:客戶端 POST 到 /saga2-transfer-workflow
DB 動作:無(還沒進 engine)
```

### 階段 2:啟動 process instance
```
時間:T+10ms
事件:SonataFlow engine 接收,準備執行第一個 state(ValidateInput)
DB 動作:
  - INSERT INTO processes(id, process_id='saga2-transfer-workflow',
    process_name='Saga2 Transfer Workflow',
    state=1, start_time=now, version='2.0.0')
```

**現有 DB 範例**:
```sql
INSERT 結果(隱含的):
id=dae4022d-0d1b-4073-a510-129176738772
state=1
start_time=1786951944351
```

### 階段 3:每個 state 執行 → nodes +1
```
時間:T+50ms ~ T+250ms(看 API 速度)
事件:每個 state 進入時 INSERT nodes row,離開時 UPDATE exit
DB 動作:每個 state 對應 1 列 nodes
```

**現有 DB 範例**(取自 process `dae4022d-...` 的 5 個 nodes):
```sql
SELECT name, type, enter, exit FROM nodes 
WHERE process_instance_id='dae4022d-...' 
ORDER BY enter;

name                  type                  enter             exit
ValidateInput         Split                 1786951944365     1786951944612
CallA16229State       CompositeContextNode  1786951944420     1786951944612
EmbeddedStart         StartNode             1786951944420     1786951944612
callApiViaOpenAPI     WorkItemNode          1786951944420     1786951944612
Script                ActionNode            1786951944563     1786951944612
```

### 階段 4:workflow 結束 → processes 關閉
```
時間:T+250ms
事件:workflow 跑到 End state
DB 動作:
  - UPDATE processes SET state=2, end_time=now WHERE id=...
  - 對 SUCCESS: state=2 (Completed)
  - 對 FAILED: state=3 (Aborted)
```

**現有 DB 範例**:4 個 process 都是 state=2(注意本專案現有資料都是 SUCCESS 結尾,實際業務上 FAILED 的會是 3)

### 階段 5:Audit 觸發 → workflow_execution_log +1
```
時間:T+255ms
事件:workflow 結束前的 FinalAuditAndEnd state 呼叫 recordAuditLog function
DB 動作:
  - INSERT INTO workflow_execution_log(workflow_id, business_key, 
    status, message, input_data, output_data)
```

**現有 DB 範例**(完整 4 筆):
```
id  workflow_id              business_key  status       message                                AMT
1   saga2-transfer-workflow  123456        SUCCESS      交易成功                                100
2   saga2-transfer-workflow  123456        ROLLED_BACK  AMT > 500 觸發 saga 回沖 (LIFO)        600
3   saga2-transfer-workflow  123456        FAILED       業務失敗或 API 錯誤                     30
4   saga2-transfer-workflow  123456        ROLLED_BACK  A16220 業務失敗,僅回沖 A16229          2000
```

---

## 6.3 state 與 type 字典

### `processes.state` 對照

| 值 | 意義 | 觸發時機 |
|:---:|---|---|
| 1 | Active | workflow 啟動後、結束前 |
| 2 | Completed | 跑完所有 state 正常結束(SUCCESS) |
| 3 | Aborted | 因 error 中止(FAILED) |

> 注意:**`ROLLED_BACK` 不會出現在 `processes.state`**,因為對 engine 而言 Saga 補償跑完是「正常完成」。它只出現在 `workflow_execution_log.status`。

### `nodes.type` 對照(從現有 DB 統計)

| type | 數量 | 語意 |
|---|---:|---|
| `StartNode` | 21 | workflow 進入點(EmbeddedStart + 設計上的 Start) |
| `EndNode` | 24 | workflow 結束點(EmbeddedEnd + 設計上的 End) |
| `ActionNode` | 35 | 執行 script 的節點(sonataflow 的 Script state) |
| `WorkItemNode` | 8 | 呼叫外部 function 的節點(callApiViaOpenAPI、callA16229) |
| `CompositeContextNode` | 5 | 包含子 state 的複合節點(CallA16229State、CallA16220State) |
| `Split` | 4 | 平行/分支入口(ValidateInput、CheckA16229Result、CheckA16220Result、DecideByEvaluation) |
| `Join` | 4 | 平行/分支匯合(Join-RollbackA16220、Join-RollbackA16229Only) |

> 數量加總 99 ≠ 118,**差額** 是設計中有的節點在某些 process 沒走到(例如被 split 跳過的 rollback 鏈)。

---

## 6.4 4 大 Saga 情境的 DB 痕跡對照 ⭐

**本專案現有 4 筆 audit log 剛好對應 4 種情境** — 完美示範。

### 情境 1:SUCCESS(正常完成)

```
audit log:  id=1  status=SUCCESS  message='交易成功'  AMT=100
processes:  state=2
nodes:      ValidateInput → CallA16229State(callApiViaOpenAPI:100) → CallA16220State → End
output_data: {a16229Result: {code:100, message:成功}, a16220Result: {code:100, message:成功}}
rollback:    null, null
```

### 情境 2:ROLLED_BACK — LIFO 雙沖

```
audit log:  id=2  status=ROLLED_BACK  message='AMT > 500 觸發 saga 回沖 (LIFO)'  AMT=600
processes:  state=2(對 engine 而言,跑完就算 Completed)
nodes:      ValidateInput → CallA16229State(正向) → CallA16220State(正向) 
            → CheckAmt(>500) → RollbackA16220(回沖) → RollbackA16229(回沖) → End
output_data: {
  a16229Result: {code:100},      // 正向成功
  a16220Result: {code:100},      // 正向成功
  a16220Rollback: {code:100},    // 回沖成功
  a16229Rollback: {code:100}     // 回沖成功
}
```

### 情境 3:FAILED — 預校驗擋下

```
audit log:  id=3  status=FAILED  message='業務失敗或 API 錯誤'  AMT=30
processes:  state=2(可能 3,看 abort 邏輯)
nodes:      只有少數幾個(ValidateInput 失敗 → 直接 FinalAuditAndEnd)
output_data: {
  a16229Result: {code:999, message:'AMT必須大於50'},  // 預校驗 API 拒絕
  a16220Result: null,
  a16220Rollback: null,
  a16229Rollback: null
}
```

### 情境 4:ROLLED_BACK — 單沖(只有 A16229 被回沖)

```
audit log:  id=4  status=ROLLED_BACK  message='A16220 業務失敗,僅回沖 A16229'  AMT=2000
processes:  state=2
nodes:      ValidateInput → CallA16229State(正向) → CallA16220State(A16220 失敗)
            → RollbackA16229Only → End
output_data: {
  a16229Result: {code:100},       // 正向成功
  a16220Result: {code:999},       // 正向失敗(AMT > 1000)
  a16220Rollback: null,           // A16220 沒成功,不需要回沖
  a16229Rollback: {code:100}      // A16229 成功過,要回沖
}
```

### 4 情境對照表

| 情境 | status | a16229_code | a16220_code | a16220_rollback | a16229_rollback | nodes 數 |
|---|:---:|:---:|:---:|:---:|:---:|---:|
| 1 SUCCESS | SUCCESS | 100 | 100 | null | null | 正常 |
| 2 LIFO 雙沖 | ROLLED_BACK | 100 | 100 | 100 | 100 | 正常 + 2 個回沖 |
| 3 FAILED | FAILED | 999 | null | null | null | 很少(預校驗擋) |
| 4 單沖 | ROLLED_BACK | 100 | 999 | null | 100 | 正常 + 1 個回沖 |

---

## 6.5 對帳 CSV 拉資料路徑

```mermaid
flowchart LR
    A[Admin GET /reconciliation/export-csv] --> B[ReconciliationResource.exportCsv]
    B --> C[ReconciliationCsvExporter.generateCsv]
    C --> D[SELECT * FROM vw_saga_reconciliation]
    D --> E[workflow_execution_log 拆 JSON]
    E --> F[扁平 15 欄位]
    F --> G[寫入 CSV StringBuilder]
    G --> H[Response text/csv attachment]
    H --> I[瀏覽器下載 reconciliation-YYYYMMDD-HHMMSS.csv]
```

**Header 順序**(對應 `ReconciliationCsvExporter` 的 `getHeader()` 與 view 欄位順序):

```csv
id,created_at,workflow_id,business_key,status,message,account_a,account_b,amt,a16229_code,a16229_msg,a16220_code,a16220_msg,a16229_rollback_code,a16220_rollback_code
```

> 注意最後兩個欄位是 `a16229_rollback_code, a16220_rollback_code`(這跟 view 內 `a16220Rollback, a16229Rollback` 對應 — view 內順序是 a16220Rollback 先,但 CSV header 是 a16229 先,因為人類閱讀順序與反向回沖邏輯一致)。**這是潛在 bug 風險點** — 詳見 Ch09。

**現有 4 筆實際 CSV 輸出**:
```csv
id,created_at,workflow_id,business_key,status,message,account_a,account_b,amt,a16229_code,a16229_msg,a16220_code,a16220_msg,a16229_rollback_code,a16220_rollback_code
1,2026-08-17 07:32:24,saga2-transfer-workflow,123456,SUCCESS,交易成功,123456,A12345,100,100,成功,100,成功,,
2,2026-08-17 07:32:30,saga2-transfer-workflow,123456,ROLLED_BACK,AMT > 500 觸發 saga 回沖 (LIFO),123456,A12345,600,100,成功,100,成功,100,100
3,2026-08-17 07:32:36,saga2-transfer-workflow,123456,FAILED,業務失敗或 API 錯誤,123456,A12345,30,999,AMT必須大於50,,,,
4,2026-08-17 07:32:40,saga2-transfer-workflow,123456,ROLLED_BACK,A16220 業務失敗,僅回沖 A16229,123456,A12345,2000,100,成功,999,AMT必須小於1000,100,
```

> CSV 已存放於 `data/reconciliation-20260817-153250.csv` 與 `data/reconciliation-20260817-153356.csv`。

---

## 6.6 Lifecycle 速記表

| 階段 | DB 寫入 | 觸發者 | 觸發時機 |
|---|---|---|---|
| 1 接收 | 無 | (HTTP 進 Quarkus) | T+0 |
| 2 啟動 | `processes` +1 | SonataFlow engine | T+10ms |
| 3 節點 | `nodes` +N | SonataFlow engine | T+50~T+250ms |
| 4 結束 | `processes` UPDATE | SonataFlow engine | T+250ms |
| 5 Audit | `workflow_execution_log` +1 | `AuditLogService` via `recordAuditLog` function | T+255ms |
| 6 對帳 | (read) | Admin 呼叫 `/reconciliation/export-csv` | 小時後/天後 |

下一章:深入解析引擎內部 3 張核心表(`processes` / `nodes` / `definitions`)。

---

# 第 7 章:流程引擎記錄(Kogito Data Index 視角) ⭐

> 本章是 Ch02 族群 A/B/E 的「深度展開」,針對 Kogito 引擎寫入的關鍵表逐一解釋。
> 重點放在:**為什麼有這些欄位?**、**Flyway 演進為何加這些欄位?**、**實務上什麼時候會用到?**

---

## 7.1 `processes` 深入

### 7.1.1 欄位分類(共 22 欄)

| 類別 | 欄位 | 說明 |
|---|---|---|
| **基本識別** | `id`, `process_id`, `version`, `process_name` | 對應 definitions 與 workflow instance |
| **時間** | `start_time`, `end_time`, `last_update_time` | epoch millis |
| **狀態** | `state` (1/2/3) | Active / Completed / Aborted |
| **業務資訊** | `business_key`, `message`, `endpoint` | 業務可塞的欄位 |
| **層級** | `parent_process_instance_id`, `root_process_id`, `root_process_instance_id` | 子流程、流程鏈 |
| **節點參考** | `node_definition_id`, `node_instance_id` | 當前停在哪 |
| **變數** | `variables` (JSON) | workflow 全域變數 |
| **SLA** | `sla_due_date` | V1.45.0.6 新增 |
| **CloudEvents** | `cloud_event_id`, `cloud_event_source` | V1.45.1.2 新增 |
| **稽核** | `created_by`, `updated_by` | V1.45.0.1 新增 |

### 7.1.2 關鍵欄位深入

#### `variables` JSON

格式(範例,從實際 saga2 跑的結果):
```json
{
  "Account_A": "123456",
  "Account_B": "A12345",
  "AMT": 100,
  "a16229Result": { "code": 100, "message": "成功" },
  "a16220Result": { "code": 100, "message": "成功" },
  "a16220Rollback": { "code": 100, "message": "回沖成功" },
  "a16229Rollback": { "code": 100, "message": "回沖成功" }
}
```

> 注意 `variables` 內的內容與 `workflow_execution_log.input_data` + `output_data` 高度重疊 — 這是 Kogito 引擎與應用層的設計選擇,兩者各存一份,沒有同步機制。**以 `workflow_execution_log` 為準**(那是應用層 explicit 寫的)。

#### `state` 字典(完整)

| 值 | 語意 | 結束時的 `end_time` |
|:---:|---|---|
| 1 | Active | NULL(還沒結束) |
| 2 | Completed | 結束時間 |
| 3 | Aborted | 結束時間 |

> 細節差異見 Ch06 6.3 節。

#### `cloud_event_*` 欄位(V1.45.1.2 新增)

這是 Kogito 對 [CloudEvents 規範](https://cloudevents.io/) 的整合:當 workflow 觸發 cloud event 時,會把 `id` 與 `source` 記下來,方便之後串接 Kafka / Knative Eventing。

本專案目前 saga workflow 沒發 cloud event,所以這兩個欄位都是 NULL。

### 7.1.3 `processes` 索引策略(現況 + 建議)

**現有索引**:
- 只有 PK(`id`)

**實務上會查的欄位**:
| 查詢模式 | 是否有索引? | 影響 |
|---|---|---|
| `WHERE id = ?` | ✅ PK | O(log n) |
| `WHERE business_key = ?` | ❌ 無 | 業務想用訂單號查,目前要全表掃描 |
| `WHERE state = ?` | ❌ 無 | 想看「目前在跑的 process」要全表掃描 |
| `WHERE process_id = ?` | ❌ 無 | 想看某 workflow 全部 instance |
| `ORDER BY start_time DESC` | ❌ 無 | 想看最近 100 筆 |

**Ch09 維運建議**:生產環境加這幾個索引:
```sql
CREATE INDEX idx_processes_business_key ON processes(business_key);
CREATE INDEX idx_processes_state ON processes(state);
CREATE INDEX idx_processes_process_id ON processes(process_id);
CREATE INDEX idx_processes_start_time ON processes(start_time DESC);
```

---

## 7.2 `nodes` 深入

### 7.2.1 欄位分類(共 14 欄)

| 類別 | 欄位 | 說明 |
|---|---|---|
| **基本識別** | `id`, `process_instance_id`, `name`, `node_id`, `type` | 對應 definitions_nodes |
| **時間** | `enter`, `exit`, `sla_due_date` | epoch millis |
| **執行資訊** | `retrigger`, `error_message`, `cancel_type` | runtime 細節 |
| **參數** | `input_args`, `output_args` | 該節點的 I/O(JSON) |

### 7.2.2 關鍵欄位深入

#### `type` 字典(從現有 DB 統計 + SonataFlow 規範)

| type | 對應 SonataFlow state 類型 |
|---|---|
| `StartNode` | workflow 開始的 `start` state |
| `EndNode` | workflow 結束的 `end` state |
| `ActionNode` | `script` 類型 |
| `WorkItemNode` | 呼叫 function / REST 的 state |
| `CompositeContextNode` | 包含 subflow 的 state |
| `Split` | 平行分支入口 |
| `Join` | 平行分支匯合 |
| `SubProcessNode` | 呼叫子流程 |
| `ForEachNode` / `ForEachJoinNode` | 迴圈 |

> 完整字典需參考 [SonataFlow spec 0.8 state types](https://serverlessworkflow.io/schemas/0.8/state.html)。

#### `retrigger` 欄位(V1.45.1.1 新增)

- 預設 `0`
- 當 workflow 因為 error 重試時,該節點的 `retrigger` +1
- 同一個 `name` 可能有多列 `nodes`(retrigger 計數遞增)

**範例**:`retry=3` 的 API 呼叫節點,在 DB 內會看到 3 列:
```
name=callApiViaOpenAPI  retrigger=0  enter=t1  exit=t2
name=callApiViaOpenAPI  retrigger=1  enter=t3  exit=t4
name=callApiViaOpenAPI  retrigger=2  enter=t5  exit=t6
```

#### `cancel_type` 欄位(V1.45.1.3 新增)

- 當 workflow 被外部信號中斷時,當前節點的 `cancel_type` 會被設定
- 對 Saga 補償流程:被補償掉的子任務可能會有 `cancel_type='compensated'`

#### `input_args` / `output_args`(V1.48.0 新增)

- 該節點執行時的輸入/輸出 JSON
- 原本只有 process 層級的 `variables`,但實務上想 debug 某個節點為什麼失敗,需要該節點的 I/O
- 這兩個欄位讓 `NodeInstances` GraphQL 查詢可以回傳完整 trace

### 7.2.3 `nodes` 與 `definitions_nodes` 對照

| 比較 | `definitions_nodes` | `nodes` |
|---|---|---|
| **時機** | 啟動 deploy 時 | workflow 執行時 |
| **行數** | 設計上的節點數(常駐) | 該次執行的節點數(動態) |
| **內容** | 靜態結構(name, type, unique_id) | 動態狀態(enter, exit, retrigger) |
| **複合 PK** | `(id, process_id, process_version)` | `id` |
| **FK** | → `definitions(id, version)` | → `processes(id)` |

**範例**:`saga2-transfer-workflow` 的設計(`definitions_nodes`):
```
name                    type                  count
ValidateInput           Split                 1
CallA16229State         CompositeContextNode  1
callApiViaOpenAPI       WorkItemNode          1
Script                  ActionNode            數個
...
```

某次跑的 trace(`nodes`):
```
process_instance_id=dae4022d-...
name                    type                  enter             exit
ValidateInput           Split                 1786951944365     1786951944612
CallA16229State         CompositeContextNode  1786951944420     1786951944612
EmbeddedStart           StartNode             1786951944420     1786951944612
callApiViaOpenAPI       WorkItemNode          1786951944420     1786951944612
Script                  ActionNode            1786951944563     1786951944612
```

> `definitions_nodes` 是「有 5 個 node 設計」,`nodes` 是「這次跑 5 個 node」(可能 6 個,因為有 retry)。

---

## 7.3 `definitions` 深入

### 7.3.1 為什麼要存 source BLOB?

Kogito 啟動時,Quarkus extension 掃描 classpath 下所有 `.sw.yaml` 寫入 `definitions.source`。原因是:

1. **重啟後無需重新 deploy** — 即使 `.sw.yaml` 檔案被刪,DB 內的 BLOB 還在
2. **GraphQL `ProcessDefinitions.source` 查詢** — 讓外部系統能「拉定義來看」
3. **審計** — 知道歷史上跑過哪些版本

### 7.3.2 `source` BLOB 內容範例(saga2 12.4 KB)

```yaml
id: saga2-transfer-workflow
version: '2.0.0'
specVersion: '0.8'
name: Saga2 Transfer Workflow
description: |
  兩階段交易流程 (Saga 模式回沖) - 套用 MyOpenApiService。
  透過 MyOpenApiService 動態套用 specs/A16229-api.yaml (executeA16229)
  與 specs/A16220-api.yaml (executeA16220) 規格發送 API 請求。
start: ValidateInput
timeouts:
  workflowExecTimeout: PT5M
functions:
  - name: callApiViaOpenAPI
    operation: 'service:com.example.transfer.workflow.MyOpenApiService::callOpenApi'
    type: custom
  - name: recordAuditLog
    operation: 'service:com.example.reconciliation.AuditLogService::saveLog'
    type: custom
states:
  - name: ValidateInput
    type: operation
    actions: [...]
  - name: CallA16229State
    type: operation
    actions: [...]
  ...
```

> 完整 12.4 KB,含 ~30 個 states。可用 `sqlite3 reconciliation.db "SELECT source FROM definitions WHERE id='saga2-transfer-workflow'"` 拉出來看。

### 7.3.3 `definitions_upsert_trigger` 觸發詳情(搭配 Ch04)

**情境**:開發時改了 `saga2-transfer-workflow.sw.yaml` 的某個 state 邏輯,然後重啟 Quarkus。

**沒 trigger 的行為**:
```
Quarkus 啟動
  ↓
INSERT INTO definitions(id='saga2-transfer-workflow', version='2.0.0', source=新內容)
  ↓
SQLITE_CONSTRAINT_PRIMARYKEY: UNIQUE constraint failed: definitions.id, definitions.version
  ↓
Quarkus 啟動失敗
```

**有 trigger 的行為**:
```
Quarkus 啟動
  ↓
INSERT INTO definitions(id='saga2-transfer-workflow', version='2.0.0', source=新內容)
  ↓
[BEFORE INSERT TRIGGER]
  SELECT 1 FROM definitions WHERE id=NEW.id AND version=NEW.version  → 找到 1 列
  ↓
  DELETE FROM definitions WHERE id=NEW.id AND version=NEW.version
  ↓
  (FK CASCADE) 自動刪 definitions_nodes / definitions_nodes_metadata 等子表
  ↓
INSERT 正常完成
  ↓
Quarkus 重新 INSERT 新的 definitions_nodes(因為 sub deploy 也會跑)
```

### 7.3.4 跨版本行為

`definitions` 用 `(id, version)` 複合 PK,所以同一個 workflow 可有多版本共存。

**本專案現況**:每個 workflow 只有 1 個版本(都是 `1.0.0` 或 `2.0.0`)。

**未來情境**:若需要 A/B test,可同時 deploy `saga2@1.0.0` 與 `saga2@2.0.0`,從 API gateway 路由分流。

---

## 7.4 `definitions_nodes` vs `nodes` 對照(極常搞混)

| | `definitions_nodes`(靜態) | `nodes`(動態) |
|---|---|---|
| **存什麼** | workflow 設計的節點 | 該次執行走過的節點 |
| **何時寫** | Quarkus 啟動時 | workflow 執行時 |
| **複合 PK** | `(id, process_id, process_version)` | `id` |
| **FK** | → `definitions` | → `processes` |
| **行數成長模式** | 跟 workflow 數量線性 | 跟 process instance 數量線性(且每個 instance 有數十列) |
| **本專案現有** | 134 列(5 個 workflow) | 118 列(4 個 process) |

**白話**:
- `definitions_nodes`:這台機器上裝了哪些遊戲(設計)
- `nodes`:今天誰玩了什麼遊戲(執行)

**千萬別混用**:
- 想知道「saga2 跑了幾次?」→ 查 `processes` WHERE `process_id='saga2-transfer-workflow'`
- 想知道「saga2 設計上有哪些 state?」→ 查 `definitions_nodes` WHERE `process_id='saga2-transfer-workflow'`
- 想知道「這次 saga2 跑過哪些 state?」→ 查 `nodes` WHERE `process_instance_id=?`

---

## 7.5 `jobs` 表

### 用途

對應 SonataFlow 的:
- `Timer` 事件(e.g.「3 天後檢查轉帳是否到帳」)
- Async callback(e.g.「等外部系統回呼 webhook」)

### Schema 重點

| 欄位 | 用途 |
|---|---|
| `id` (PK) | job ID |
| `callback_endpoint` | 完成時 callback 位置 |
| `expiration_time` | 到期時間 |
| `execution_counter` | 已執行次數(0 = 還沒跑) |
| `repeat_interval` / `repeat_limit` | 重複設定 |
| `status` | SCHEDULED / EXECUTED / ERROR / CANCELED |
| `exception_message` / `exception_details` | 錯誤資訊 |

### 本專案現況

**0 筆**。`saga2-transfer-workflow` 沒用 timer 事件。

### 未來擴展

如果要加「24 小時後檢查轉帳是否到帳」之類:
```yaml
states:
  - name: WaitOneDay
    type: sleep
    duration: PT24H
  - name: CheckSettlement
    type: operation
    actions:
      - functionRef:
          refName: checkSettlement
```

這會在 `jobs` 表內建立一筆 `status=SCHEDULED` 的 row,24 小時後 Kogito scheduler 觸發執行,改為 `status=EXECUTED`。

### 索引

- `idx_jobs_piid ON (process_instance_id)` — 查某 process 的所有排程

---

## 7.6 `kie_flyway_history_data_index` 演進

### 結構

```sql
CREATE TABLE kie_flyway_history_data_index (
    installed_rank   INT NOT NULL PRIMARY KEY,
    version          VARCHAR(50),
    description      VARCHAR(200) NOT NULL,
    type             VARCHAR(20) NOT NULL,    -- 'SQL' / 'JDBC' / ...
    script           VARCHAR(1000) NOT NULL,  -- e.g. 'V1.45.0.6__add_sla_due_date_columns.sql'
    checksum         INT,
    installed_by     VARCHAR(100) NOT NULL,
    installed_on     TEXT NOT NULL DEFAULT (strftime('%Y-%m-%d %H:%M:%f','now')),
    execution_time   INT NOT NULL,            -- ms
    success          BOOLEAN NOT NULL
);
CREATE INDEX kie_flyway_history_data_index_s_idx ON kie_flyway_history_data_index(success);
```

### 現有資料(22 筆)

| rank | version | description | script |
|---:|---|---|---|
| 1 | 1.32.0 | data index create | V1.32.0__data_index_create.sql |
| 2 | 1.44.0 | data index definitions | V1.44.0__data_index_definitions.sql |
| 3 | 1.45.0.0 | data index node definitions | V1.45.0.0__data_index_node_definitions.sql |
| 4 | 1.45.0.1 | add identity to process instance | V1.45.0.1__add_identity_to_process_instance.sql |
| 5 | 1.45.0.2 | data index definitions add columns | V1.45.0.2__data_index_definitions_add_columns.sql |
| 6 | 1.45.0.3 | add fk index | V1.45.0.3__add_fk_index.sql |
| 7 | 1.45.0.4 | increase varchar length | V1.45.0.4__increase_varchar_length.sql |
| 8 | 1.45.0.5 | add external reference id | V1.45.0.5__add_external_reference_id.sql |
| 9 | 1.45.0.6 | add sla due date columns | V1.45.0.6__add_sla_due_date_columns.sql |
| 10 | 1.45.0.7 | add sla due date tasks | V1.45.0.7__add_sla_due_date_tasks.sql |
| 11 | 1.45.0.8 | modify columns with reserved words | V1.45.0.8__modify_columns_with_reserved_words.sql |
| 12 | 1.45.0.9 | increase comments content size | V1.45.0.9__increase_comments_content_size.sql |
| 13 | 1.45.1.0 | metadata as jsonb | V1.45.1.0__metadata_as_jsonb.sql |
| 14 | 1.45.1.1 | retrigger | V1.45.1.1__retrigger.sql |
| 15 | 1.45.1.2 | cloudevent | V1.45.1.2__cloudevent.sql |
| 16 | 1.45.1.3 | add cancelled type nodes | V1.45.1.3__add_cancelled_type_nodes.sql |
| 17 | 1.45.1.4 | add indexes for jobs and tasks | V1.45.1.4__add_indexes_for_jobs_and_tasks.sql |
| 18 | 1.46.0 | add user task id column | V1.46.0__add_user_task_id_column.sql |
| 19 | 1.47.0 | adjust column sizes in tables updated by hibernate | V1.47.0__adjust_column_sizes_in_tables_updated_by_hibernate.sql |
| 20 | 1.48.0 | add input output args | V1.48.0__add_input_output_args.sql |
| 21 | 1.49.0 | add job exception details | V1.49.0__add_job_exception_details.sql |
| 22 | 1.50.0 | definitions upsert trigger | V1.50.0__definitions_upsert_trigger.sql |

### 演進時間軸

```
2025-07  V1.32.0   初始 — processes/nodes/tasks/jobs 主表
        ↓
2025-09  V1.44.0   加入 definitions(支援 .sw.yaml 動態 deploy)
        ↓
2025-10  V1.45.0.0-9 大量欄位加強(identity/SLA/varchar/保留字)
        ↓
2025-11  V1.45.1.0-4 JSONB 化、SLA task、retrigger、CloudEvent、cancel_type
        ↓
2025-12  V1.46.0-1.49.0 user_task_id、hibernate 自動調整、input/output args、job exception
        ↓
2026-01  V1.50.0   最後一個:definitions upsert trigger(熱更新支援)
```

### 為何需要 22 個腳本(對比 PostgreSQL)?

PostgreSQL 有完整 SQL 標準支援(JSONB、partial index、generated column...),Flyway 腳本通常 3–5 個就建完。

SQLite 受限:
- 無 `JSONB` → 改用 `TEXT` + `json_extract()`,標 `-- was jsonb` 紀念
- 無原生 `BOOLEAN` → 用 `INTEGER 0/1`
- 無 `BYTEA` → 用 `BLOB`
- 無部分索引 → 只能用 `CREATE INDEX` 標準索引
- `ALTER TABLE` 限制多 → 每改一個欄位可能拆成獨立 migration

所以 Kogito 在 SQLite 上需要 22 個小腳本累積出 PostgreSQL 一次到位的 schema。

下一章:把這個 22 步演進講清楚。

---

# 第 8 章:Schema 演進史

> 本章按時間軸解釋 22 個 Flyway 腳本各做了什麼、為什麼。
> 完整 DDL 見附錄 A,22 個腳本全文見附錄 B。

---

## 8.1 Flyway 版本總表

| 順序 | 版本 | 影響範圍 | 主題 |
|---:|---|---|---|
| 1 | 1.32.0 | 11 張主表 | 初始 — Data Index 建立 |
| 2 | 1.44.0 | 6 張 | 流程定義(支援動態 deploy `.sw.yaml`) |
| 3 | 1.45.0.0 | 1 張 | definitions_nodes 加強 |
| 4 | 1.45.0.1 | 1 張 | processes 加 identity 欄位 |
| 5 | 1.45.0.2 | 1 張 | definitions 加 description / metadata |
| 6 | 1.45.0.3 | 多張 | FK 索引 |
| 7 | 1.45.0.4 | 多張 | VARCHAR 擴大 |
| 8 | 1.45.0.5 | 1 張 | tasks 加 external_reference_id |
| 9 | 1.45.0.6 | 1 張 | processes 加 sla_due_date |
| 10 | 1.45.0.7 | 1 張 | tasks 加 sla_due_date |
| 11 | 1.45.0.8 | 多張 | 保留字處理 |
| 12 | 1.45.0.9 | 1 張 | comments.content 擴大 |
| 13 | 1.45.1.0 | 多張 | metadata 改 JSONB |
| 14 | 1.45.1.1 | 1 張 | nodes 加 retrigger |
| 15 | 1.45.1.2 | 1 張 | processes 加 cloud_event_* |
| 16 | 1.45.1.3 | 1 張 | nodes 加 cancel_type |
| 17 | 1.45.1.4 | 2 張 | jobs/tasks 索引 |
| 18 | 1.46.0 | 1 張 | tasks 加 user_task_id |
| 19 | 1.47.0 | 多張 | hibernate 自動調整欄位大小 |
| 20 | 1.48.0 | 1 張 | nodes 加 input_args / output_args |
| 21 | 1.49.0 | 1 張 | jobs 加 exception_details |
| 22 | 1.50.0 | 1 trigger | definitions 熱更新 trigger |

---

## 8.2 各版本變更摘要(逐個解釋)

### V1.32.0 — `data_index_create.sql` ⭐ 基礎

**這是整個 schema 的起點**,建立 11 張核心表:
- 流程實例:`processes` / `nodes` / `milestones` / `processes_addons` / `processes_roles`
- 人工作業:`tasks` / `tasks_admin_users` / `tasks_admin_groups` / `tasks_potential_users` / `tasks_potential_groups` / `tasks_excluded_users`
- 附件留言:`attachments` / `comments`
- 排程:`jobs`

**為什麼是 1.32.0?** 對應 Kogito Data Index 1.32.0 版本的 schema 凍結,本專案升 Kogito 10.2.0 時把它 porting 到 SQLite。

### V1.44.0 — `data_index_definitions.sql` ⭐ 重要

**加入 definitions 全家族**:
- `definitions` (主表,BLOB 存 `.sw.yaml`)
- `definitions_nodes` (靜態節點拓樸)
- `definitions_addons` / `definitions_roles` / `definitions_annotations`

**這是 Kogito 1.44 的重大變更**:從「只能用程式碼 define workflow」變成「可純 YAML 定義」。本專案所有 5 個 workflow 都是 `.sw.yaml`。

### V1.45.0.0 — `data_index_node_definitions.sql`

`definitions_nodes` 結構微調,加入 `unique_id` 等欄位用於跨版本節點對應。

### V1.45.0.1 — `add_identity_to_process_instance.sql`

`processes` 加 `created_by` / `updated_by`,用於 security audit(知道是誰觸發的 workflow)。

### V1.45.0.2 — `data_index_definitions_add_columns.sql`

`definitions` 加 `description` / `metadata` 欄位,讓使用者可在查詢時看到 workflow 的描述。

### V1.45.0.3 — `add_fk_index.sql`

**為所有外鍵加索引**(`idx_nodes_piid`、`idx_milestones_piid`、`idx_tasks_piid`...)。沒有這些索引,當資料量成長後 JOIN 會很慢。

### V1.45.0.4 — `increase_varchar_length.sql`

擴大部分 VARCHAR 欄位(從 VARCHAR(255) 改為 VARCHAR(1000)+),避免長 business_key 被截斷。

### V1.45.0.5 — `add_external_reference_id.sql`

`tasks` 加 `external_reference_id` — 讓外部系統(例如銀行系統)可以用自己的編號對應 Kogito task。

### V1.45.0.6 — `add_sla_due_date_columns.sql`

`processes` 加 `sla_due_date` — SLA 監控的到期時間。

### V1.45.0.7 — `add_sla_due_date_tasks.sql`

`tasks` 加 `sla_due_date` — User task 層級的 SLA。

### V1.45.0.8 — `modify_columns_with_reserved_words.sql`

處理 SQLite 的保留字:有些欄位名(如 `key` / `value` / `desc`)是保留字,要 escape 或改名。

### V1.45.0.9 — `increase_comments_content_size.sql`

`comments.content` 從 TEXT(預設 1GB)擴大為 ... 嗯,SQLite 沒有限制,這個 migration 主要是對齊 PostgreSQL 的 migration 序列。

### V1.45.1.0 — `metadata_as_jsonb.sql`

**重大變更**:`definitions.metadata` / `processes.variables` / `tasks.inputs` / `tasks.outputs` 等從純 TEXT 升級為 JSONB 語意。
SQLite 上仍是 TEXT,但應用層改用 `json_extract()` 存取,並標 `-- was jsonb`。

### V1.45.1.1 — `retrigger.sql`

`nodes` 加 `retrigger INTEGER NOT NULL DEFAULT 0` — 計數 retry 用的。

### V1.45.1.2 — `cloudevent.sql`

`processes` 加 `cloud_event_id` / `cloud_event_source` — 整合 CloudEvents 規範。

### V1.45.1.3 — `add_cancelled_type_nodes.sql`

`nodes` 加 `cancel_type` — 記錄節點被哪種方式取消(Saga 補償、外部 abort、timeout...)。

### V1.45.1.4 — `add_indexes_for_jobs_and_tasks.sql`

`jobs` / `tasks` 補上常用查詢的索引。

### V1.46.0 — `add_user_task_id_column.sql`

`tasks` 加 `user_task_id` — BPMN 標準的 task ID 命名空間,對應 Kogito 1.46 引入的 user task 整合。

### V1.47.0 — `adjust_column_sizes_in_tables_updated_by_hibernate.sql`

Hibernate 自動調整欄位大小 — 這是 Hibernate 在生成 DDL 時對齊實體類別的 annotation,純粹是 ORM 框架需要,業務邏輯無感。

### V1.48.0 — `add_input_output_args.sql`

`nodes` 加 `input_args` / `output_args` JSON 欄位 — 讓 debug 時能看到每個節點的實際 I/O。

### V1.49.0 — `add_job_exception_details.sql`

`jobs` 加 `exception_details` — 存完整 stacktrace,而不只是 `exception_message` 的一行訊息。

### V1.50.0 — `definitions_upsert_trigger.sql` ⭐ 最新

**最後一個腳本**,加 trigger 支援熱更新(見 Ch04 4.2 與 Ch07 7.3.3)。

---

## 8.3 為何 SQLite 需要 22 個修補(對比 PostgreSQL)

| 限制 | SQLite | PostgreSQL | 影響 |
|---|---|---|---|
| 標準 SQL 支援 | 部分(無 JSONB、無部分索引) | 完整 | 需更多 migration 步驟 |
| ALTER TABLE | 限制多(不能 DROP COLUMN 早期) | 完整 | 每改 schema 拆多個 migration |
| 預設 schema 來自 Kogito | 為 PG 設計 | 原生 | 需 porting 22 步 |
| Trigger 語法 | 支援但語法不同 | 完整 | 需要寫 SQLite 專屬 trigger |

**結論**:本專案的 22 個 Flyway 腳本,基本上是把 Kogito 給 PostgreSQL 的 1 個 `data_index.sql` + 1 個後續修補,拆解 + porting 到 SQLite 的結果。

**好處**:如果未來想換 PostgreSQL,把 SQLite 修補版的 SQL 改成 PG 標準語法即可,腳本結構大部分重用。

---

## 8.4 演進時間軸(從 git log 推測)

```
Kogito 1.32 (2025-07) ─→ V1.32.0 初始
Kogito 1.44 (2025-09) ─→ V1.44.0 definitions
Kogito 1.45 (2025-10) ─→ V1.45.0.x 大量欄位加強
Kogito 1.45.1 (2025-11) ─→ V1.45.1.x JSONB / retrigger / cloudevent / cancel_type
Kogito 1.46 (2025-12) ─→ V1.46.0 user_task_id
Kogito 1.47-1.49 (2026-01) ─→ V1.47.0-1.49.0 hibernate 調整 + input/output args + job exception
自定義 (2026-02) ─→ V1.50.0 definitions_upsert_trigger
```

---

## 8.5 Flyway 啟動行為(對應本專案)

兩個 Quarkus app 啟動時都會跑 Flyway:

```
Quarkus 啟動
  ↓
platform-data-index 模組偵測到 Flyway + 22 個腳本
  ↓
  1. 連線 DB,檢查 kie_flyway_history_data_index 表
  2. 比對可用 migration 與已執行 migration
  3. 對未執行的版本(若有),依序執行
  4. 寫入 history 表
  ↓
Quarkus 繼續啟動
```

**兩個 app 同時啟動會怎樣?** Flyway 用 SQLite 的 BEGIN IMMEDIATE 鎖確保只有一個 process 跑 migration,另一個會等到第一個完成才繼續。

下一章:維運 & 監控。

---

# 第 9 章:維運 & 監控 (Operations & Monitoring)

> 本章回答:
> - 健康檢查怎麼讀 DB?
> - 怎麼備份?
> - 容量怎麼估?
> - 出問題怎麼辦?

---

## 9.1 健康檢查(MyLivenessCheck)

### 程式碼

```
platform-data-index/src/main/java/org/acme/platform/dataindex/MyLivenessCheck.java
```

```java
@Liveness
@ApplicationScoped
public class MyLivenessCheck implements HealthCheck {
    @Inject AgroalDataSource ds;

    @Override
    public HealthCheckResponse call() {
        try (Connection c = ds.getConnection();
             PreparedStatement ps = c.prepareStatement("SELECT 1");
             ResultSet rs = ps.executeQuery()) {
            return rs.next() && rs.getInt(1) == 1
                ? HealthCheckResponse.up("SQLite up")
                : HealthCheckResponse.named("SQLite").down().build();
        } catch (SQLException e) {
            return HealthCheckResponse.named("SQLite").down()
                .withData("error", e.getMessage()).build();
        }
    }
}
```

### 對應 endpoint

- `GET /q/health/live` — K8s liveness probe 應該用這個
- `GET /q/health/ready` — readiness probe(包含 DB up/down)

### 監控指標

從 health endpoint 抓的關鍵指標:
- `status`: UP / DOWN
- `checks[].name`: "SQLite"
- `checks[].data.error`: SQL 例外訊息(若有)

---

## 9.2 備份策略

### 方法 A:`VACUUM INTO`(推薦,線上備份)

```bash
sqlite3 reconciliation.db "VACUUM INTO '/backup/reconciliation-$(date +%Y%m%d-%H%M%S).db'"
```

**優點**:
- 不需要停服務
- 自動合併 WAL,產出單一 `.db` 檔
- 結果一致(在 backup 開始時的 snapshot)

**缺點**:
- 會 lock DB 短暫時間(大 DB 可能影響交易)

### 方法 B:直接 cp 三檔(快速,但要小心)

```bash
# 先執行 WAL checkpoint
sqlite3 reconciliation.db "PRAGMA wal_checkpoint(TRUNCATE);"
# 然後 cp
cp reconciliation.db backup/reconciliation.db
cp reconciliation.db-wal backup/reconciliation.db-wal
cp reconciliation.db-shm backup/reconciliation.db-shm
```

**注意**:cp `.db-wal` 期間若 Writer 還在寫,WAL 會繼續長,restore 時可能需要 replay。

### 方法 C(本專案目前做法):整目錄打包

```bash
# 由排程器每天跑一次
tar czf /backup/reconciliation-$(date +%Y%m%d).tar.gz \
    /data/reconciliation.db \
    /data/reconciliation.db-wal \
    /data/reconciliation.db-shm
```

### 還原測試

```bash
# 還原到測試目錄
mkdir -p /tmp/restore
tar xzf backup/reconciliation-20260819.tar.gz -C /tmp/restore
cd /tmp/restore
sqlite3 reconciliation.db "SELECT count(*) FROM workflow_execution_log;"
# 應該要 = 還原時的資料量
```

---

## 9.3 容量預估

### 目前實測

```
$ du -sh /workspace/extracted/data/
1.7M    ./
$ du -sh /workspace/extracted/data/reconciliation.db
4.0K    reconciliation.db        ← 主檔(checkpoint 過後)
$ du -sh /workspace/extracted/data/reconciliation.db-wal
1.6M    reconciliation.db-wal    ← WAL 累積
```

### 容量成長模型

假設每天跑 1000 筆 saga 交易,每筆 audit log 1 KB(包含 input_data + output_data JSON):

| 時間 | 主 DB | WAL | 累計 CSV |
|---|---:|---:|---:|
| 1 天 | 1 MB | 0(已 checkpoint) | 1 MB |
| 1 週 | 7 MB | 0 | 7 MB |
| 1 月 | 30 MB | 0 | 30 MB |
| 1 年 | 365 MB | 0 | 365 MB |

> 對 SQLite 來說,1 年 365 MB **完全沒問題**(SQLite 可支援到 1 TB+ 的單檔)。

### 引擎表的成長(更快)

`processes` 與 `nodes` 每次 workflow 跑會各寫 N 列(目前 saga2 一次約 30 個 nodes):

| 每天交易 | processes/天 | nodes/天 | 月底 |
|---:|---:|---:|---:|
| 100 | 100 | 3,000 | 90,000 |
| 1,000 | 1,000 | 30,000 | 900,000 |
| 10,000 | 10,000 | 300,000 | 9,000,000 |

**9,000,000 列的 `nodes` 表 SQLite 還能撐**(看過有人用 SQLite 處理億級),但要加索引 + 定期 archive 老舊 process。

### 容量上限建議

| 業務量 | 建議 |
|---|---|
| < 1,000 交易/天 | 純 SQLite,單機,無腦 |
| 1,000 ~ 10,000/天 | SQLite + 定期 archive(> 90 天的 process 移到 cold storage) |
| > 10,000/天 | 改 PostgreSQL |

---

## 9.4 索引使用狀況

### 用 `EXPLAIN QUERY PLAN` 驗證

```sql
EXPLAIN QUERY PLAN
SELECT * FROM vw_saga_reconciliation WHERE business_key='123456';
-- 預期:SCAN vw_saga_reconciliation ... (因為是 view,實際會展開)
-- 變成:SCAN workflow_execution_log WHERE workflow_id = ... AND ...

EXPLAIN QUERY PLAN
SELECT * FROM nodes WHERE process_instance_id='dae4022d-...';
-- 預期:SEARCH nodes USING INDEX idx_nodes_piid (process_instance_id=?)
```

### 建議加的索引(目前缺失)

```sql
-- 業務常用
CREATE INDEX idx_processes_business_key ON processes(business_key);
CREATE INDEX idx_processes_state ON processes(state);
CREATE INDEX idx_processes_start_time ON processes(start_time DESC);

-- audit log 常用
CREATE INDEX idx_wel_workflow_id ON workflow_execution_log(workflow_id);
CREATE INDEX idx_wel_business_key ON workflow_execution_log(business_key);
CREATE INDEX idx_wel_status ON workflow_execution_log(status);
CREATE INDEX idx_wel_created_at ON workflow_execution_log(created_at DESC);
```

> 這些索引不在原 Flyway 腳本內(因為 Kogito 預設 schema 不預期業務查詢),要由應用層依查詢模式加。

---

## 9.5 WAL 調校

### 預設參數

```sql
PRAGMA journal_mode = WAL;        -- 已是 WAL
PRAGMA synchronous = NORMAL;      -- 預設 FULL,但 NORMAL 在 WAL 模式夠安全
PRAGMA wal_autocheckpoint = 1000; -- 1000 頁 ≈ 4 MB 觸發 checkpoint
PRAGMA cache_size = -2000;        -- 2 MB page cache
```

### 高併發調校建議

```sql
-- 改 synchronous=FULL 換取更強的 crash safety(但慢 2-3 倍)
PRAGMA synchronous = FULL;

-- 加大 WAL buffer(預設 ≈ 4MB)
PRAGMA journal_size_limit = 67108864;  -- 64 MB
```

### 監控 WAL 大小

```sql
PRAGMA wal_checkpoint(PASSIVE);  -- 不實際 checkpoint,只回報
-- 結果:busy=N checkpoint=N log=N pages=N
```

---

## 9.6 故障恢復情境

### 情境 1:DB 損毀(`.db` 檔 corrupt)

**症狀**:`sqlite3 reconciliation.db ".tables"` 報錯

**恢復**:
```bash
# 方法 A:從備份還原
cp /backup/reconciliation-20260819.db /data/reconciliation.db

# 方法 B:從 WAL replay(若 .db-wal 還在)
sqlite3 reconciliation.db ".recover"  # 嘗試從 WAL 復原
# 或
sqlite3 reconciliation.db-wal ".recover" > recovered.sql
sqlite3 reconciliation.db < recovered.sql
```

### 情境 2:WAL 過大(> 1 GB)

**症狀**:`.db-wal` 一直長,沒做 checkpoint

**處理**:
```bash
sqlite3 reconciliation.db "PRAGMA wal_checkpoint(TRUNCATE);"
```

### 情境 3:兩個 app 寫衝突

**症狀**:`SQLITE_BUSY` 錯誤

**處理**:
- SQLite WAL 模式天然支援「多 reader + 1 writer」,但同時寫會 BUSY
- 應用層已有 retry 機制(透過 Hibernate connection retry)
- 若是設計問題,考慮改用 PostgreSQL

### 情境 4:Flyway migration 失敗(中途 crash)

**症狀**:`kie_flyway_history_data_index` 表內某 row 的 `success=0`

**處理**:
```sql
-- 1. 手動修補 schema
-- 2. 然後刪掉失敗 row(讓 Flyway 重試)
DELETE FROM kie_flyway_history_data_index WHERE success=0;
```

### 情境 5:audit log 沒寫入

**症狀**:`workflow_execution_log` 沒新增,但 `processes` 與 `nodes` 有

**可能原因**:
1. `recordAuditLog` function 沒被呼叫(查 `.sw.yaml` 內的 `functions:` 與 `actions:`)
2. `AuditLogService.saveLog()` 內 SQL 失敗(看 log)
3. transaction 沒 commit(看是否有 `@Transactional`)

**Debug**:
```bash
# 查 transfer-app.log 內的 AuditLog 相關錯誤
grep -i "audit" /workspace/extracted/logs/transfer-app.log
grep -i "AuditLogService" /workspace/extracted/logs/transfer-app.log
```

### 情境 6:CSV 匯出空白

**症狀**:`GET /reconciliation/export-csv` 回空 CSV(只有 header)

**可能原因**:
1. `workflow_execution_log` 真的沒資料(剛啟動的全新 DB)
2. `workflow_id` 不對(不是 `saga2-transfer-workflow`,被 view 過濾掉)
3. 連線到錯的 DB 檔

**Debug**:
```bash
sqlite3 reconciliation.db "SELECT count(*) FROM workflow_execution_log;"
sqlite3 reconciliation.db "SELECT count(*) FROM vw_saga_reconciliation;"
```

---

## 9.7 Prometheus 監控建議(Metrics)

Kogito Data Index 預設透過 MicroProfile Metrics 暴露:

| 指標 | 用途 |
|---|---|
| `kogito_data_index_process_instances_total` | 累計 process instance 數 |
| `kogito_data_index_query_seconds_count/sum` | 查詢次數與延遲 |
| `quarkus_agroal_active_count` | 活躍連線數 |
| `quarkus_agroal_awaiting_count` | 等連線的執行緒數 |
| `jvm_memory_used_bytes{area="heap"}` | JVM heap 用量 |

**對 audit log 額外監控**:
```sql
-- 1. audit log 寫入頻率(每分鐘)
SELECT count(*) FROM workflow_execution_log
WHERE created_at > datetime('now', '-1 minute');

-- 2. 失敗率
SELECT
    cast(sum(CASE WHEN status='FAILED' THEN 1 ELSE 0 END) AS real) / count(*) AS fail_rate
FROM workflow_execution_log
WHERE created_at > datetime('now', '-1 day');

-- 3. ROLLED_BACK 率
SELECT
    cast(sum(CASE WHEN status='ROLLED_BACK' THEN 1 ELSE 0 END) AS real) / count(*) AS rollback_rate
FROM workflow_execution_log;
```

---

## 9.8 容量規劃決策樹

```
                    ┌─ 1,000 交易/天 ─→ 純 SQLite OK
                    │
當前交易量 ────────-┤
                    │
                    └─ > 10,000 交易/天 ─→ 改 PostgreSQL
                          │
                          ├─ 考慮水平擴展(多 writer)
                          ├─ 考慮 streaming audit(寫 Kafka 而非 DB)
                          └─ 考慮讀寫分離(replica)
```

---

## 9.9 已知技術債 / 風險

| 風險 | 影響 | 緩解 |
|---|---|---|
| 兩個 app 共享檔案 storage | NFS 故障會同時掛 | 改用 cloud-native DB |
| 引擎表無業務索引 | 業務查詢慢 | 見 9.4 加索引 |
| audit log 無歸檔機制 | 永遠累積 | 加 cron 做 monthly archive |
| Flyway 對 SQLite 的 advisory lock | 同啟動有 race | Flyway 已處理,但要監控 |
| `workflow_execution_log` 沒 unique 約束 | 理論上重複寫風險 | 應用層去重,或加 `UNIQUE(workflow_id, business_key, created_at)` |
| CSV header 與 view 欄位順序不一致風險 | 對帳數字對不上 | 加 unit test 比對 header |

---

## 9.10 維運速查表(One-Pager)

```bash
# 健康檢查
curl http://transfer-app:8080/q/health/live
curl http://reconciliation-app:8081/q/health/ready

# 統計
sqlite3 reconciliation.db "SELECT status, count(*) FROM workflow_execution_log GROUP BY status;"
sqlite3 reconciliation.db "SELECT count(*) AS total_processes, sum(CASE WHEN state=1 THEN 1 ELSE 0 END) AS active FROM processes;"

# 備份
sqlite3 reconciliation.db "VACUUM INTO '/backup/snap-$(date +%Y%m%d).db'"

# 監控 WAL
sqlite3 reconciliation.db "PRAGMA wal_checkpoint(PASSIVE);"

# 看最近 10 筆 audit
sqlite3 -header -column reconciliation.db "SELECT id, status, message, datetime(created_at) FROM workflow_execution_log ORDER BY id DESC LIMIT 10;"

# 重建索引
sqlite3 reconciliation.db "REINDEX;"

# 跑 ANALYZE 更新統計(讓 query planner 更準)
sqlite3 reconciliation.db "ANALYZE;"
```

下一章:附錄 A 完整 DDL。

---

# 第 10 章:Process Flow 完整深度解析 — saga2-transfer-workflow ⭐ NEW

> **解析方法**:從 `definitions.source` BLOB 解析靜態 DAG + 從 `nodes` 拉 runtime trace 對齊
> **覆蓋範圍**:本專案 4 個 process instance(SUCCESS / LIFO 雙沖 / FAILED / 單沖)
> **解析腳本**:`db-spec/parse_saga2.py`

---

## E.1 兩種資料來源的角色

```
┌──────────────────────────────────────────────────────────────┐
│  definitions.source (BLOB)  ──→  靜態 DAG 骨架                 │
│    • 18 個 user-defined states                               │
│    • 4 個 CompositeContextNode 內含的 sub-states              │
│    • Kogito 自動產生的 6 個 Join states(共 62 個)              │
│    • 每條 transition 帶 condition 表達式                       │
└──────────────────────────────────────────────────────────────┘
                            +
┌──────────────────────────────────────────────────────────────┐
│  nodes (runtime trace)     ──→  實際執行標記 + 時序            │
│    • 該 process 走過的每個 state + enter/exit                 │
│    • 順序由 enter 決定                                        │
│    • 配合 definitions_nodes 的 definition_id 可回推是哪條路    │
└──────────────────────────────────────────────────────────────┘
                            =
┌──────────────────────────────────────────────────────────────┐
│  = 「這次 process 實際走的路徑 + 觸發了哪些條件」                │
└──────────────────────────────────────────────────────────────┘
```

---

## E.2 完整靜態 DAG(18 user-defined + 6 auto-Join = 24 邏輯 state)

```mermaid
flowchart TD
    Start([Start])
    Start --> V{ValidateInput<br/>switch}

    V -->|"Account_A 不符 regex"| Inv[InjectValidationFailedStatus<br/>inject]
    V -->|"Account_B 不符 regex"| Inv
    V -->|"AMT 非 number"| Inv
    V -->|"default"| C29[CallA16229State<br/>operation]

    C29 --> CA29{CheckA16229Result<br/>switch}
    CA29 -->|"a16229Result.code == 100"| C20[CallA16220State<br/>operation]
    CA29 -->|"code != 100"| JIF[/Join-InjectFailedStatus/]
    CA29 -->|"default"| JIF
    JIF --> IF[InjectFailedStatus<br/>inject]

    C20 --> CA20{CheckA16220Result<br/>switch}
    CA20 -->|"a16220Result.code == 100"| Dec{DecideByEvaluation<br/>switch}
    CA20 -->|"code != 100"| JR29O[/Join-RollbackA16229Only/]
    CA20 -->|"default"| JR29O
    JR29O --> R29O[RollbackA16229Only<br/>operation]
    R29O --> CR29O{CheckRollbackA16229OnlyResult<br/>switch}
    CR29O -->|"a16229Rollback.code == 100"| IRO[InjectRolledBackOnlyStatus]
    CR29O -->|"code != 100"| JIRF[/Join-InjectRollbackFailedStatus/]
    CR29O -->|"default"| JIRF
    IRO --> JFAE1[/Join-FinalAuditAndEnd/]
    JIRF --> IRF[InjectRollbackFailedStatus]
    IRF --> JFAE2[/Join-FinalAuditAndEnd/]

    Dec -->|"AMT > 500"| JR20[/Join-RollbackA16220/]
    Dec -->|"AMT <= 500"| IS[InjectSuccessStatus]
    Dec -->|"default (安全策略)"| JR20
    IS --> JFAE3[/Join-FinalAuditAndEnd/]
    JR20 --> R20[RollbackA16220<br/>operation]
    R20 --> R29[RollbackA16229<br/>operation]
    R29 --> CRR{CheckRollbackResults<br/>switch}
    CRR -->|"任一 rollback.code != 100"| IRF2[InjectRollbackFailedStatus]
    CRR -->|"default (都成功)"| IRB[InjectRolledBackStatus]
    IRB --> JFAE4[/Join-FinalAuditAndEnd/]
    IRF2 --> JFAE5[/Join-FinalAuditAndEnd/]

    Inv --> JFAE6[/Join-FinalAuditAndEnd/]
    IF --> JFAE7[/Join-FinalAuditAndEnd/]
    JFAE1 --> Final
    JFAE2 --> Final
    JFAE3 --> Final
    JFAE4 --> Final
    JFAE5 --> Final
    JFAE6 --> Final
    JFAE7 --> Final

    Final["FinalAuditAndEnd<br/>operation<br/>(end: true)"]:::end
    Final --> EndNode([End])

    classDef end fill:#ffebee,stroke:#c62828,stroke-width:2px
    classDef inject fill:#e8f5e9,stroke:#2e7d32
    classDef switch fill:#fff3e0,stroke:#ef6c00
    classDef join fill:#f3e5f5,stroke:#6a1b9a
```

**節點統計**:
- 18 user-defined states(來自 YAML)
- + 6 個 Kogito 自動產生的 Join states(來自 `definitions_nodes` 表 id 57~62)
- = 24 個邏輯 state + Start + End = 26 個節點

---

## E.3 4 條實際執行路徑(從 BLOB 推導 + trace 驗證)

> 對齊方式:`nodes` 下一個 enter 的 name,匹配該 state 在 BLOB 內的 transition targets,就知道走了哪個 condition

### E.3.1 Process 1: `dae4022d...` — SUCCESS 路徑

**輸入**:`{Account_A: 123456, Account_B: A12345, AMT: 100}`  
**audit log**:`id=1, status=SUCCESS, AMT=100`  
**耗時**:255 ms(從 Start 到 End)

| # | enter | Δms | state (走過的) | type | 觸發的 condition(YAML 內) |
|---:|------:|----:|---|---|---|
| 1 | 44363 | 0 | Start | StartNode | workflow 啟動 |
| 2 | 44365 | 2 | ValidateInput | Split | 進入 switch,3 個 condition 都不 match |
| 3 | 44420 | 57 | CallA16229State | Composite | **default** → 進入 A16229 呼叫 |
| 4 | 44420 | 57 | ↳ EmbeddedStart | StartNode | Composite 內部開始 |
| 5 | 44420 | 57 | ↳ callApiViaOpenAPI | WorkItemNode | 調用 MyOpenApiService::callOpenApi |
| 6 | 44463 | 143 | ↳ Script | ActionNode | 結果過濾 `actionDataFilter.results` |
| 7 | 44465 | 145 | ↳ Script | ActionNode | 第二次 Script(可能 sync) |
| 8 | 44466 | 146 | ↳ EmbeddedEnd | EndNode | Composite 結束 |
| 9 | 44467 | 147 | CheckA16229Result | Split | `a16229Result.code == "100"` ✅ **a16229Success** |
| 10 | 44468 | 148 | CallA16220State | Composite | 進入 A16220 呼叫 |
| 11 | 44468 | 148 | ↳ EmbeddedStart | StartNode | |
| 12 | 44468 | 148 | ↳ callApiViaOpenAPI | WorkItemNode | |
| 13 | 44488 | 168 | ↳ Script | ActionNode | |
| 14 | 44489 | 169 | ↳ Script | ActionNode | |
| 15 | 44489 | 169 | ↳ EmbeddedEnd | EndNode | |
| 16 | 44489 | 169 | CheckA16220Result | Split | `a16220Result.code == "100"` ✅ **a16220Success** |
| 17 | 44490 | 170 | DecideByEvaluation | Split | `AMT(100) <= 500` ✅ **successPath** |
| 18 | 44490 | 170 | InjectSuccessStatus | Action | 注入 `{finalStatus: "SUCCESS", finalMessage: "交易成功"}` |
| 19 | 44491 | 171 | Join-FinalAuditAndEnd | Join | 6 條路收斂,選 1 條執行 |
| 20 | 44491 | 171 | FinalAuditAndEnd | Composite | 寫 audit log |
| 21 | 44492 | 172 | ↳ EmbeddedStart | StartNode | |
| 22 | 44492 | 172 | ↳ recordAuditLog | WorkItemNode | 調用 AuditLogService::saveLog |
| 23 | 44499 | 179 | ↳ Script | ActionNode | stateDataFilter.output 過濾 |
| 24 | 44500 | 180 | ↳ EmbeddedEnd | EndNode | |
| 25 | 44500 | 180 | Script | Action | End 前最後一個 Script |
| 26 | 44601 | 238 | End | EndNode | workflow 結束 |

**BLOB 推導路徑**:
```
ValidateInput (default) 
→ CallA16229State 
→ CheckA16229Result (a16229Success) 
→ CallA16220State 
→ CheckA16220Result (a16220Success) 
→ DecideByEvaluation (successPath) 
→ InjectSuccessStatus 
→ Join-FinalAuditAndEnd 
→ FinalAuditAndEnd (end)
```

**走過的 transition 數**:10 條(對應 10 個 user-defined state 轉換)

---

### E.3.2 Process 2: `75268679...` — ROLLED_BACK LIFO 雙沖路徑

**輸入**:`{Account_A: 123456, Account_B: A12345, AMT: 600}`  
**audit log**:`id=2, status=ROLLED_BACK, AMT=600`  
**耗時**:46 ms(明顯比 SUCCESS 快 — 沒有 A16220 業務邏輯等待)

| # | enter | Δms | state | type | 觸發的 condition |
|---:|------:|----:|---|---|---|
| 1 | 50928 | 0 | Start | StartNode | |
| 2 | 50928 | 0 | ValidateInput | Split | default |
| 3 | 50932 | 4 | CallA16229State | Composite | 進入 A16229 |
| 4-7 | ... | ... | ↳ 4 個 sub-state | (略) | |
| 8 | 50940 | 12 | CheckA16229Result | Split | **a16229Success** (code=100) |
| 9 | 50940 | 12 | CallA16220State | Composite | 進入 A16220 |
| 10-13 | ... | ... | ↳ 4 個 sub-state | (略) | |
| 14 | 50947 | 19 | CheckA16220Result | Split | **a16220Success** (code=100) |
| 15 | 50947 | 19 | DecideByEvaluation | Split | `AMT(600) > 500` ✅ **rollbackPath** |
| 16 | 50947 | 19 | Join-RollbackA16220 | Join | 收斂到 rollback 路徑 |
| 17 | 50948 | 20 | RollbackA16220 | Composite | **LIFO 第一步:先回沖後跑的 A16220** |
| 18-21 | ... | ... | ↳ 4 個 sub-state | (略) | |
| 22 | 50956 | 28 | RollbackA16229 | Composite | **LIFO 第二步:再回沖先跑的 A16229** |
| 23-26 | ... | ... | ↳ 4 個 sub-state | (略) | |
| 27 | 50968 | 40 | CheckRollbackResults | Split | 兩個 rollback.code 都是 100,**default** |
| 28 | 50969 | 41 | InjectRolledBackStatus | Action | 注入 `{finalStatus: "ROLLED_BACK", finalMessage: "AMT > 500 觸發 saga 回沖 (LIFO)"}` |
| 29 | 50969 | 41 | Join-FinalAuditAndEnd | Join | |
| 30 | 50970 | 42 | FinalAuditAndEnd | Composite | 寫 audit log(這次 status=ROLLED_BACK) |
| 31-39 | ... | ... | ↳ sub-states + End | | |

**BLOB 推導路徑**:
```
ValidateInput (default) 
→ CallA16229State → CheckA16229Result (a16229Success) 
→ CallA16220State → CheckA16220Result (a16220Success) 
→ DecideByEvaluation (rollbackPath) 
→ Join-RollbackA16220 
→ RollbackA16220 → RollbackA16229 [LIFO 順序] 
→ CheckRollbackResults (default) 
→ InjectRolledBackStatus 
→ Join-FinalAuditAndEnd 
→ FinalAuditAndEnd (end)
```

**LIFO 證據**:trace 順序是先 RollbackA16220(enter 50948)再 RollbackA16229(enter 50956),對應 BLOB 的 transition 順序(從 RollbackA16220 transition 到 RollbackA16229)。

---

### E.3.3 Process 3: `e4f8329a...` — FAILED 預校驗擋下路徑

**輸入**:`{Account_A: 123456, Account_B: A12345, AMT: 30}`  
**audit log**:`id=3, status=FAILED, AMT=30`  
**耗時**:19 ms(最短)

| # | enter | Δms | state | type | 觸發的 condition |
|---:|------:|----:|---|---|---|
| 1 | 56387 | 0 | Start | StartNode | |
| 2 | 56388 | 1 | ValidateInput | Split | default(AMT 通過型別檢查) |
| 3 | 56393 | 6 | CallA16229State | Composite | |
| 4-7 | ... | ... | ↳ 4 個 sub-state | (略) | |
| 8 | 56400 | 13 | CheckA16229Result | Split | `a16229Result.code == "999"` ❌ **a16229Failed** (AMT必須大於50) |
| 9 | 56400 | 13 | Join-InjectFailedStatus | Join | 收斂到 InjectFailed |
| 10 | 56401 | 14 | InjectFailedStatus | Action | 注入 `{finalStatus: "FAILED", finalMessage: "業務失敗或 API 錯誤"}` |
| 11 | 56401 | 14 | Join-FinalAuditAndEnd | Join | |
| 12-19 | ... | ... | FinalAuditAndEnd + sub-states + End | | |

**BLOB 推導路徑**:
```
ValidateInput (default) 
→ CallA16229State → CheckA16229Result (a16229Failed) 
→ Join-InjectFailedStatus 
→ InjectFailedStatus 
→ Join-FinalAuditAndEnd 
→ FinalAuditAndEnd (end)
```

**關鍵觀察**:跑到 `CheckA16229Result` 就中斷,**完全沒跑 CallA16220State**(因 A16229 失敗就不繼續)。

---

### E.3.4 Process 4: `30b63fb8...` — ROLLED_BACK 單沖路徑

**輸入**:`{Account_A: 123456, Account_B: A12345, AMT: 2000}`  
**audit log**:`id=4, status=ROLLED_BACK, AMT=2000`  
**耗時**:31 ms

| # | enter | Δms | state | type | 觸發的 condition |
|---:|------:|----:|---|---|---|
| 1 | 60365 | 0 | Start | StartNode | |
| 2 | 60366 | 1 | ValidateInput | Split | default |
| 3 | 60368 | 3 | CallA16229State | Composite | 進入 A16229 |
| 4-7 | ... | ... | ↳ sub-state | (略) | |
| 8 | 60376 | 11 | CheckA16229Result | Split | **a16229Success** (code=100) |
| 9 | 60376 | 11 | CallA16220State | Composite | 進入 A16220 |
| 10-13 | ... | ... | ↳ sub-state | (略) | |
| 14 | 60385 | 20 | CheckA16220Result | Split | `a16220Result.code == "999"` ❌ **a16220Failed** (AMT必須小於1000) |
| 15 | 60385 | 20 | Join-RollbackA16229Only | Join | 收斂到單沖路徑 |
| 16 | 60385 | 20 | RollbackA16229Only | Composite | **只回沖 A16229(因 A16220 未成功扣款,無需回沖)** |
| 17-20 | ... | ... | ↳ sub-state | (略) | |
| 21 | 60392 | 27 | CheckRollbackA16229OnlyResult | Split | `a16229Rollback.code == "100"` ✅ **rollbackSuccess** |
| 22 | 60392 | 27 | InjectRolledBackOnlyStatus | Action | 注入 `{finalStatus: "ROLLED_BACK", finalMessage: "A16220 業務失敗,僅回沖 A16229"}` |
| 23-33 | ... | ... | Join + FinalAudit + sub + End | | |

**BLOB 推導路徑**:
```
ValidateInput (default) 
→ CallA16229State → CheckA16229Result (a16229Success) 
→ CallA16220State → CheckA16220Result (a16220Failed) 
→ Join-RollbackA16229Only 
→ RollbackA16229Only [只沖 A16229] 
→ CheckRollbackA16229OnlyResult (rollbackSuccess) 
→ InjectRolledBackOnlyStatus 
→ Join-FinalAuditAndEnd 
→ FinalAuditAndEnd (end)
```

**單沖 vs 雙沖的差異**(從 BLOB 對比):
| 行為 | 雙沖(Process 2) | 單沖(Process 4) |
|---|---|---|
| 進入 rollback 的原因 | AMT > 500(商務規則) | A16220 業務失敗 |
| 回沖的 API | RollbackA16220 → RollbackA16229 | 只 RollbackA16229Only |
| message | "AMT > 500 觸發 saga 回沖 (LIFO)" | "A16220 業務失敗,僅回沖 A16229" |
| 觸發的 Check state | CheckRollbackResults | CheckRollbackA16229OnlyResult |

---

## E.4 4 條路徑差異總表

| 維度 | Process 1 SUCCESS | Process 2 LIFO_BACK | Process 3 FAILED | Process 4 SINGLE_BACK |
|---|---|---|---|---|
| **AMT** | 100 | 600 | 30 | 2000 |
| **總耗時** | 255 ms | 46 ms | 19 ms | 31 ms |
| **走的 user-state 數** | 10 個 | 12 個 | 7 個 | 11 個 |
| **走 Composite 內部 sub-state 數** | 12 個 | 12 個 | 6 個 | 10 個 |
| **走過的 Join 數** | 1 | 2 | 2 | 2 |
| **走的 Rollback state** | 0 | 2 | 0 | 1 |
| **最終 status** | SUCCESS | ROLLED_BACK | FAILED | ROLLED_BACK |
| **最終 message** | "交易成功" | "AMT > 500 觸發 saga 回沖 (LIFO)" | "業務失敗或 API 錯誤" | "A16220 業務失敗,僅回沖 A16229" |

---

## E.5 4 條路徑疊在 DAG 上(實心箭頭 = 走了)

```mermaid
flowchart TD
    Start([Start]):::start
    Start --> V{ValidateInput}

    V -->|"default"| C29[CallA16229State]
    V -.->|"invalid"| Inv[InjectValidationFailedStatus]:::skipped

    C29 --> CA29{CheckA16229Result}
    CA29 -->|"a16229Success"| C20[CallA16220State]
    CA29 -.->|"a16229Failed"| JIF1[/Join-InjectFailedStatus/]:::jfailed

    C20 --> CA20{CheckA16220Result}
    CA20 -->|"a16220Success"| Dec{DecideByEvaluation}
    CA20 -->|"a16220Failed"| JR29O[/Join-RollbackA16229Only/]:::jrb

    Dec -->|"AMT <= 500 (P1)"| IS[InjectSuccessStatus]:::success
    Dec -->|"AMT > 500 (P2)"| JR20[/Join-RollbackA16220/]:::jrb
    Dec -.->|"default"| JR20

    JR20 --> R20[RollbackA16220]:::rollback
    R20 --> R29[RollbackA16229]:::rollback
    R29 --> CRR{CheckRollbackResults}
    CRR -->|"default (P2)"| IRB[InjectRolledBackStatus]:::rollback
    CRR -.->|"失敗"| IRF[InjectRollbackFailedStatus]:::skipped

    JR29O --> R29O[RollbackA16229Only]:::rollback
    R29O --> CR29O{CheckRollbackA16229OnlyResult}
    CR29O -->|"success (P4)"| IRO[InjectRolledBackOnlyStatus]:::rollback
    CR29O -.->|"失敗"| IRF

    JIF1 --> IF[InjectFailedStatus]:::failed
    IF -.-> Inv
    Inv -.-> JR29O

    IS --> JFAE[/Join-FinalAuditAndEnd/]
    IRB --> JFAE
    IRO --> JFAE
    IF --> JFAE
    JFAE --> Final["FinalAuditAndEnd<br/>(end: true)"]:::end
    Final --> EndNode([End])

    classDef start fill:#e1f5fe
    classDef success fill:#c8e6c9,stroke:#2e7d32,stroke-width:2px
    classDef failed fill:#ffcdd2,stroke:#c62828
    classDef rollback fill:#ffe0b2,stroke:#ef6c00
    classDef skipped fill:#f5f5f5,stroke:#bbb,color:#888,stroke-dasharray: 5 5
    classDef jrb fill:#fff9c4,stroke:#f9a825
    classDef jfailed fill:#ffcdd2,stroke:#c62828,stroke-dasharray: 2 2
    classDef end fill:#e0e0e0,stroke:#424242
```

**圖例**:
- 🟩 綠實心:SUCCESS 專屬路徑(只有 P1 走)
- 🟧 橘實心:LIFO 雙沖與單沖路徑(P2 走 R20→R29,P4 走 R29O)
- 🟥 紅實心:FAILED 路徑(P3 走)
- ⬜ 灰虛線:本專案 4 個 process 沒走的路徑(InjectValidationFailedStatus、InjectRollbackFailedStatus)
- 🟨 黃:Kogito 自動 Join(state id 57~62)

---

## E.6 跨路徑時序對比(Gantt)

```mermaid
gantt
    title 4 個 process 的時序對比(時間軸:從 0 開始)
    dateFormat X
    axisFormat %S

    section P1 SUCCESS
    ValidateInput    :p1v, 0, 2
    CallA16229       :p1a29, 2, 144
    CheckA29         :p1ca29, 144, 1
    CallA16220       :p1a20, 145, 22
    CheckA20         :p1ca20, 167, 1
    DecideByEval     :p1dec, 168, 1
    InjectSuccess    :p1is, 169, 1
    FinalAudit       :p1fa, 170, 9
    End              :p1end, 179, 0

    section P2 LIFO_BACK
    ValidateInput    :p2v, 0, 0
    CallA16229       :p2a29, 0, 11
    CheckA29         :p2ca29, 11, 0
    CallA16220       :p2a20, 12, 7
    CheckA20         :p2ca20, 19, 0
    DecideByEval     :p2dec, 19, 0
    RollbackA16220   :p2ra20, 19, 8
    RollbackA16229   :p2ra29, 27, 12
    CheckRollback    :p2cr, 39, 1
    InjectRolledBack :p2irb, 40, 1
    FinalAudit       :p2fa, 41, 4
    End              :p2end, 45, 0

    section P3 FAILED
    ValidateInput    :p3v, 0, 1
    CallA16229       :p3a29, 1, 7
    CheckA29         :p3ca29, 12, 0
    InjectFailed     :p3if, 13, 1
    FinalAudit       :p3fa, 14, 4
    End              :p3end, 18, 0

    section P4 SINGLE_BACK
    ValidateInput    :p4v, 0, 1
    CallA16229       :p4a29, 1, 8
    CheckA29         :p4ca29, 11, 0
    CallA16220       :p4a20, 11, 9
    CheckA20         :p4ca20, 20, 0
    RollbackA29Only  :p4ra29o, 20, 7
    CheckRollbackOnly :p4cro, 27, 0
    InjectRolledBackOnly :p4iro, 27, 1
    FinalAudit       :p4fa, 28, 2
    End              :p4end, 30, 0
```

**觀察**:
- P1 最慢(255 ms) — 因為 Composite 內部跑了 2 個 API 呼叫,每個 ~140 ms
- P3 最快(19 ms) — 一個 API 就失敗,沒繼續
- P2 和 P4 都跑 3 個 API 呼叫(正向 + rollback),但都比 P1 快(因為 rollback 沒等業務邏輯)
- **FinalAuditAndEnd 一致 ~2–9 ms** — 寫 SQLite audit log 很快

---

## E.7 解析結論與 DB 規格補強建議

### ✅ 這次解析證明的事

1. **BLOB 解析可行** — 18 個 user-defined state + 6 個 Kogito Join = 24 個邏輯 state
2. **runtime trace 可對齊** — 用 `enter` 時間戳 + `next-in-trace` 配對,可反推每一步走了哪個 condition
3. **Saga 補償鏈可追蹤** — LIFO 雙沖 vs 單沖在 trace 上有明顯不同的「Rollback 開頭的 state」

### ⚠️ 解析過程的痛點

| 痛點 | 影響 | 建議 |
|---|---|---|
| Kogito 自動產生的 6 個 Join state 不在 YAML 內 | 解析時要去 `definitions_nodes` 表 id 57~62 找 | 文件化這 6 個 Join 是 Kogito 慣例 |
| CompositeContextNode 內部 sub-state 沒有獨立的 transition | 解析時要把整個 Composite 視為一個黑盒 | 文件化 Composite 內部結構(本案例:EmbeddedStart → callApiViaOpenAPI → Script×N → EmbeddedEnd) |
| `next-in-trace` 要自己組(沒有 FK) | 對齊要做 2-pass:先排序,再找下一個 unique name | 業務查詢時做 view 預先 JOIN |
| `enter` 是 TEXT 不是 INT | 要 CAST | Ch09 已建議 `idx_processes_start_time` 索引,但 nodes 也要 |

### 📋 建議加的 view(讓這種解析變 SQL 一行)

```sql
-- 1. 完整靜態圖的 view(從 BLOB 抽出 transition)
CREATE VIEW vw_workflow_transitions AS
SELECT
    json_extract(value, '$.name') AS from_state,
    -- 暫存:多條件 switch 需要 flatten
FROM definitions, json_each(json_extract(source, '$.states'))
WHERE id = 'saga2-transfer-workflow';

-- 2. runtime path 對齊(每個 process instance 走的 state 鏈)
CREATE VIEW vw_process_paths AS
SELECT
    n.process_instance_id,
    n.name AS state,
    n.type,
    n.enter,
    n.exit,
    n.exit - n.enter AS duration_ms,
    -- 下一個有意義的 state(同 process_instance_id 內,排序後的下一個不同 name)
    LEAD(n.name) OVER (
        PARTITION BY n.process_instance_id
        ORDER BY n.enter
    ) AS next_state
FROM nodes n;
```

有了這兩個 view,「這次 process 走了哪些 state、走了幾 ms、下一個 state 是誰」就是 **SQL 一行** 的事,不用每次寫 Python 解析。

---

## E.8 附錄:解析腳本完整版

`db-spec/parse_saga2.py`:

```python
#!/usr/bin/env python3
import sqlite3, yaml

DB = "/workspace/extracted/data/reconciliation.db"
PROCESSES = {
    'SUCCESS':     'dae4022d-0d1b-4073-a510-129176738772',
    'LIFO_BACK':   '75268679-6cd8-4e44-bbc8-0dfc3aa3dcbd',
    'FAILED':      'e4f8329a-1c16-4d66-9383-669589d8327d',
    'SINGLE_BACK': '30b63fb8-0659-4fae-8978-792530d22ca8',
}

conn = sqlite3.connect(DB)
cur = conn.cursor()

# 1. 解析 BLOB
cur.execute("SELECT CAST(source AS TEXT) FROM definitions WHERE id='saga2-transfer-workflow'")
wf = yaml.safe_load(cur.fetchone()[0])

# 2. 對每個 process 列印 trace + 觸發的 condition
for label, pid in PROCESSES.items():
    cur.execute("""
        SELECT name, type, enter, exit FROM nodes
        WHERE process_instance_id=?
        ORDER BY enter
    """, (pid,))
    print(f"\n{label}:")
    for name, ntype, enter, exit, *rest in cur.fetchall():
        # 找這個 state 在 YAML 內的 outgoing transitions
        state = next((s for s in wf['states'] if s['name']==name), None)
        if state and state.get('type') == 'switch':
            conds = [c['name'] for c in state.get('dataConditions', [])]
            print(f"  {name} ({ntype})  switch conditions: {conds}")
        else:
            print(f"  {name} ({ntype})")
```

> 完整版見 `db-spec/parse_saga2.py`(也輸出 raw trace 與靜態 DAG 文字版)。

---

# 附錄

## 附錄 A:完整 DDL(`appendices/appendix-a-ddl.sql`)

```sql
-- ============================================================================
-- 附錄 A:reconciliation.db 完整 DDL
-- 來源:從實際運行的 reconciliation.db 透過 sqlite3 ".schema" 匯出
-- 產生時間:2026-08-19
-- 共 24 張表 + 1 view + 1 trigger + 17 個索引
-- ============================================================================

-- ============= 族群 A:流程實例 =============

CREATE TABLE processes (
    id                          TEXT NOT NULL,
    business_key                TEXT,
    end_time                    TEXT,
    endpoint                    TEXT,
    message                     TEXT,
    node_definition_id          TEXT,
    last_update_time            TEXT,
    parent_process_instance_id  TEXT,
    process_id                  TEXT,
    process_name                TEXT,
    root_process_id             TEXT,
    root_process_instance_id    TEXT,
    start_time                  TEXT,
    state                       INTEGER,
    variables                   TEXT,
    version                     TEXT,
    created_by                  TEXT,
    updated_by                  TEXT,
    sla_due_date                TEXT,
    node_instance_id            TEXT,
    cloud_event_id              TEXT,
    cloud_event_source          TEXT,
    PRIMARY KEY (id)
);

CREATE TABLE nodes (
    id                   TEXT NOT NULL,
    definition_id        TEXT,
    enter                TEXT,
    exit                 TEXT,
    name                 TEXT,
    node_id              TEXT,
    type                 TEXT,
    process_instance_id  TEXT NOT NULL,
    sla_due_date         TEXT,
    retrigger            INTEGER NOT NULL DEFAULT 0,
    error_message        TEXT,
    cancel_type          TEXT,
    input_args           TEXT,
    output_args          TEXT,
    PRIMARY KEY (id),
    FOREIGN KEY (process_instance_id) REFERENCES processes(id) ON DELETE CASCADE
);
CREATE INDEX idx_nodes_piid ON nodes(process_instance_id);

CREATE TABLE milestones (
    id                   TEXT NOT NULL,
    process_instance_id  TEXT NOT NULL,
    name                 TEXT,
    status               TEXT,
    PRIMARY KEY (id, process_instance_id),
    FOREIGN KEY (process_instance_id) REFERENCES processes(id) ON DELETE CASCADE
);
CREATE INDEX idx_milestones_piid ON milestones(process_instance_id);

CREATE TABLE processes_addons (
    process_id  TEXT NOT NULL,
    addon       TEXT NOT NULL,
    PRIMARY KEY (process_id, addon),
    FOREIGN KEY (process_id) REFERENCES processes(id) ON DELETE CASCADE
);
CREATE INDEX idx_processes_addons_pid ON processes_addons(process_id);

CREATE TABLE processes_roles (
    process_id  TEXT NOT NULL,
    role        TEXT NOT NULL,
    PRIMARY KEY (process_id, role),
    FOREIGN KEY (process_id) REFERENCES processes(id) ON DELETE CASCADE
);
CREATE INDEX idx_processes_roles_pid ON processes_roles(process_id);

-- ============= 族群 B:流程定義 =============

CREATE TABLE definitions (
    id          TEXT NOT NULL,
    version     TEXT NOT NULL,
    name        TEXT,
    type        TEXT,
    source      BLOB,
    endpoint    TEXT,
    description TEXT,
    metadata    TEXT,
    PRIMARY KEY (id, version)
);
-- Trigger
CREATE TRIGGER definitions_upsert_trigger
BEFORE INSERT ON definitions
FOR EACH ROW
WHEN EXISTS (SELECT 1 FROM definitions WHERE id = NEW.id AND version = NEW.version)
BEGIN
    DELETE FROM definitions WHERE id = NEW.id AND version = NEW.version;
END;

CREATE TABLE definitions_nodes (
    id               TEXT NOT NULL,
    name             TEXT,
    unique_id        TEXT,
    type             TEXT,
    process_id       TEXT NOT NULL,
    process_version  TEXT NOT NULL,
    PRIMARY KEY (id, process_id, process_version),
    FOREIGN KEY (process_id, process_version) REFERENCES definitions(id, version) ON DELETE CASCADE
);
CREATE INDEX idx_definitions_nodes_pid_pv ON definitions_nodes(process_id, process_version);

CREATE TABLE definitions_nodes_metadata (
    node_id          TEXT NOT NULL,
    process_id       TEXT NOT NULL,
    process_version  TEXT NOT NULL,
    meta_value       TEXT,
    name             TEXT NOT NULL,
    PRIMARY KEY (node_id, process_id, process_version, name),
    FOREIGN KEY (node_id, process_id, process_version) REFERENCES definitions_nodes(id, process_id, process_version) ON DELETE CASCADE
);
CREATE INDEX idx_definitions_nodes_metadata_pid_pv ON definitions_nodes_metadata(process_id, process_version);

CREATE TABLE definitions_addons (
    process_id       TEXT NOT NULL,
    process_version  TEXT NOT NULL,
    addon            TEXT NOT NULL,
    PRIMARY KEY (process_id, process_version, addon),
    FOREIGN KEY (process_id, process_version) REFERENCES definitions(id, version) ON DELETE CASCADE
);
CREATE INDEX idx_definitions_addons_pid_pv ON definitions_addons(process_id, process_version);

CREATE TABLE definitions_roles (
    process_id       TEXT NOT NULL,
    process_version  TEXT NOT NULL,
    role             TEXT NOT NULL,
    PRIMARY KEY (process_id, process_version, role),
    FOREIGN KEY (process_id, process_version) REFERENCES definitions(id, version) ON DELETE CASCADE
);
CREATE INDEX idx_definitions_roles_pid_pv ON definitions_roles(process_id, process_version);

CREATE TABLE definitions_annotations (
    annotation       TEXT NOT NULL,
    process_id       TEXT NOT NULL,
    process_version  TEXT NOT NULL,
    PRIMARY KEY (annotation, process_id, process_version),
    FOREIGN KEY (process_id, process_version) REFERENCES definitions(id, version) ON DELETE CASCADE
);
CREATE INDEX idx_definitions_annotations_pid_pv ON definitions_annotations(process_id, process_version);

-- ============= 族群 C:人工作業 =============

CREATE TABLE tasks (
    id                        TEXT NOT NULL,
    actual_owner              TEXT,
    completed                 TEXT,
    description               TEXT,
    endpoint                  TEXT,
    inputs                    TEXT,
    last_update               TEXT,
    name                      TEXT,
    outputs                   TEXT,
    priority                  TEXT,
    process_id                TEXT,
    process_instance_id       TEXT,
    reference_name            TEXT,
    root_process_id           TEXT,
    root_process_instance_id  TEXT,
    started                   TEXT,
    state                     TEXT,
    external_reference_id     TEXT,
    sla_due_date              TEXT,
    user_task_id              TEXT,
    PRIMARY KEY (id)
);
CREATE INDEX idx_tasks_piid ON tasks(process_instance_id);

CREATE TABLE tasks_admin_groups (
    task_id   TEXT NOT NULL,
    group_id  TEXT NOT NULL,
    PRIMARY KEY (task_id, group_id),
    FOREIGN KEY (task_id) REFERENCES tasks(id) ON DELETE CASCADE
);
CREATE INDEX idx_tasks_admin_groups_tid ON tasks_admin_groups(task_id);

CREATE TABLE tasks_admin_users (
    task_id  TEXT NOT NULL,
    user_id  TEXT NOT NULL,
    PRIMARY KEY (task_id, user_id),
    FOREIGN KEY (task_id) REFERENCES tasks(id) ON DELETE CASCADE
);
CREATE INDEX idx_tasks_admin_users_tid ON tasks_admin_users(task_id);

CREATE TABLE tasks_excluded_users (
    task_id  TEXT NOT NULL,
    user_id  TEXT NOT NULL,
    PRIMARY KEY (task_id, user_id),
    FOREIGN KEY (task_id) REFERENCES tasks(id) ON DELETE CASCADE
);
CREATE INDEX idx_tasks_excluded_users_tid ON tasks_excluded_users(task_id);

CREATE TABLE tasks_potential_groups (
    task_id   TEXT NOT NULL,
    group_id  TEXT NOT NULL,
    PRIMARY KEY (task_id, group_id),
    FOREIGN KEY (task_id) REFERENCES tasks(id) ON DELETE CASCADE
);
CREATE INDEX idx_tasks_potential_groups_tid ON tasks_potential_groups(task_id);

CREATE TABLE tasks_potential_users (
    task_id  TEXT NOT NULL,
    user_id  TEXT NOT NULL,
    PRIMARY KEY (task_id, user_id),
    FOREIGN KEY (task_id) REFERENCES tasks(id) ON DELETE CASCADE
);
CREATE INDEX idx_tasks_potential_users_tid ON tasks_potential_users(task_id);

CREATE TABLE attachments (
    id          TEXT NOT NULL,
    content     TEXT,
    name        TEXT,
    updated_at  TEXT,
    updated_by  TEXT,
    task_id     TEXT NOT NULL,
    PRIMARY KEY (id),
    FOREIGN KEY (task_id) REFERENCES tasks(id) ON DELETE CASCADE
);
CREATE INDEX idx_attachments_tid ON attachments(task_id);

CREATE TABLE comments (
    id          TEXT NOT NULL,
    content     TEXT,
    name        TEXT,
    updated_at  TEXT,
    updated_by  TEXT,
    task_id     TEXT NOT NULL,
    PRIMARY KEY (id),
    FOREIGN KEY (task_id) REFERENCES tasks(id) ON DELETE CASCADE
);
CREATE INDEX idx_comments_tid ON comments(task_id);

-- ============= 族群 D:業務審計 =============

CREATE TABLE workflow_execution_log (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    workflow_id  TEXT,
    business_key TEXT,
    status       TEXT,
    message      TEXT,
    input_data   TEXT,
    output_data  TEXT,
    created_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE VIEW vw_saga_reconciliation AS
SELECT
    id, created_at, workflow_id, business_key, status, message,
    json_extract(input_data,  '$.Account_A') AS account_a,
    json_extract(input_data,  '$.Account_B') AS account_b,
    json_extract(input_data,  '$.AMT')       AS amt,
    json_extract(output_data, '$.a16229Result.code')    AS a16229_code,
    json_extract(output_data, '$.a16229Result.message') AS a16229_msg,
    json_extract(output_data, '$.a16220Result.code')    AS a16220_code,
    json_extract(output_data, '$.a16220Result.message') AS a16220_msg,
    json_extract(output_data, '$.a16220Rollback.code')  AS a16220_rollback_code,
    json_extract(output_data, '$.a16229Rollback.code')  AS a16229_rollback_code
FROM workflow_execution_log
WHERE workflow_id = 'saga2-transfer-workflow';

-- ============= 族群 E:引擎輔助 =============

CREATE TABLE jobs (
    id                        TEXT NOT NULL,
    callback_endpoint         TEXT,
    endpoint                  TEXT,
    execution_counter         INTEGER,
    expiration_time           TEXT,
    last_update               TEXT,
    node_instance_id          TEXT,
    priority                  INTEGER,
    process_id                TEXT,
    process_instance_id       TEXT,
    repeat_interval           INTEGER,
    repeat_limit              INTEGER,
    retries                   INTEGER,
    root_process_id           TEXT,
    root_process_instance_id  TEXT,
    scheduled_id              TEXT,
    status                    TEXT,
    exception_message         TEXT,
    exception_details         TEXT,
    PRIMARY KEY (id)
);
CREATE INDEX idx_jobs_piid ON jobs(process_instance_id);

CREATE TABLE kie_flyway_history_data_index (
    installed_rank   INT NOT NULL PRIMARY KEY,
    version          VARCHAR(50),
    description      VARCHAR(200) NOT NULL,
    type             VARCHAR(20) NOT NULL,
    script           VARCHAR(1000) NOT NULL,
    checksum         INT,
    installed_by     VARCHAR(100) NOT NULL,
    installed_on     TEXT NOT NULL DEFAULT (strftime('%Y-%m-%d %H:%M:%f','now')),
    execution_time   INT NOT NULL,
    success          BOOLEAN NOT NULL
);
CREATE INDEX kie_flyway_history_data_index_s_idx ON kie_flyway_history_data_index(success);

-- ============= 族群 F:SQLite 系統表(由 SQLite 自動建立) =============
-- sqlite_sequence: AUTOINCREMENT 計數器
-- sqlite_stat1: ANALYZE 統計
```

## 附錄 B:22 個 Flyway 腳本一覽


> 路徑:`platform-extensions/data-index-storage-sqlite/src/main/resources/kie-flyway/db/data-index/sqlite/`

## B.1 完整腳本清單

| # | 版本 | 檔名 | 行數(估) | 主題 |
|---:|---|---|---:|---|
| 1 | 1.32.0 | `V1.32.0__data_index_create.sql` | ~150 | 初始 11 張表 |
| 2 | 1.44.0 | `V1.44.0__data_index_definitions.sql` | ~100 | 流程定義家族 |
| 3 | 1.45.0.0 | `V1.45.0.0__data_index_node_definitions.sql` | ~20 | definitions_nodes 加強 |
| 4 | 1.45.0.1 | `V1.45.0.1__add_identity_to_process_instance.sql` | ~5 | processes 加 created_by/updated_by |
| 5 | 1.45.0.2 | `V1.45.0.2__data_index_definitions_add_columns.sql` | ~5 | definitions 加 description/metadata |
| 6 | 1.45.0.3 | `V1.45.0.3__add_fk_index.sql` | ~20 | 多張表加 FK 索引 |
| 7 | 1.45.0.4 | `V1.45.0.4__increase_varchar_length.sql` | ~10 | 擴大 VARCHAR |
| 8 | 1.45.0.5 | `V1.45.0.5__add_external_reference_id.sql` | ~3 | tasks 加欄位 |
| 9 | 1.45.0.6 | `V1.45.0.6__add_sla_due_date_columns.sql` | ~3 | processes 加 sla_due_date |
| 10 | 1.45.0.7 | `V1.45.0.7__add_sla_due_date_tasks.sql` | ~3 | tasks 加 sla_due_date |
| 11 | 1.45.0.8 | `V1.45.0.8__modify_columns_with_reserved_words.sql` | ~10 | 處理 SQLite 保留字 |
| 12 | 1.45.0.9 | `V1.45.0.9__increase_comments_content_size.sql` | ~3 | comments.content 擴大 |
| 13 | 1.45.1.0 | `V1.45.1.0__metadata_as_jsonb.sql` | ~10 | 改為 JSONB 語意 |
| 14 | 1.45.1.1 | `V1.45.1.1__retrigger.sql` | ~3 | nodes 加 retrigger |
| 15 | 1.45.1.2 | `V1.45.1.2__cloudevent.sql` | ~3 | processes 加 cloud_event_* |
| 16 | 1.45.1.3 | `V1.45.1.3__add_cancelled_type_nodes.sql` | ~3 | nodes 加 cancel_type |
| 17 | 1.45.1.4 | `V1.45.1.4__add_indexes_for_jobs_and_tasks.sql` | ~10 | jobs/tasks 索引 |
| 18 | 1.46.0 | `V1.46.0__add_user_task_id_column.sql` | ~3 | tasks 加 user_task_id |
| 19 | 1.47.0 | `V1.47.0__adjust_column_sizes_in_tables_updated_by_hibernate.sql` | ~10 | hibernate 自動調整 |
| 20 | 1.48.0 | `V1.48.0__add_input_output_args.sql` | ~3 | nodes 加 input/output args |
| 21 | 1.49.0 | `V1.49.0__add_job_exception_details.sql` | ~3 | jobs 加 exception_details |
| 22 | 1.50.0 | `V1.50.0__definitions_upsert_trigger.sql` | ~10 | trigger |

## B.2 腳本範例(最具代表性的 3 個)

### B.2.1 V1.32.0 — 初始建立

```sql
-- V1.32.0__data_index_create.sql
-- 建立 Kogito Data Index 11 張核心表(SQLite 修補版)

CREATE TABLE processes (
    id TEXT NOT NULL,
    business_key TEXT,
    ...
    PRIMARY KEY (id)
);

CREATE TABLE nodes (
    id TEXT NOT NULL,
    process_instance_id TEXT NOT NULL,
    ...
    FOREIGN KEY (process_instance_id) REFERENCES processes(id) ON DELETE CASCADE
);
-- 共 11 張表 + 8 個索引
```

### B.2.2 V1.45.0.3 — 加 FK 索引

```sql
-- V1.45.0.3__add_fk_index.sql
CREATE INDEX idx_attachments_tid ON attachments(task_id);
CREATE INDEX idx_comments_tid ON comments(task_id);
CREATE INDEX idx_definitions_addons_pid_pv ON definitions_addons(process_id, process_version);
-- ... 共 ~10 個索引
```

### B.2.3 V1.50.0 — Trigger(最後一個)

```sql
-- V1.50.0__definitions_upsert_trigger.sql
CREATE TRIGGER definitions_upsert_trigger
BEFORE INSERT ON definitions
FOR EACH ROW
WHEN EXISTS (SELECT 1 FROM definitions WHERE id = NEW.id AND version = NEW.version)
BEGIN
    DELETE FROM definitions WHERE id = NEW.id AND version = NEW.version;
END;
```

## B.3 Flyway 載入機制(本專案)

1. **路徑**:`platform-extensions/data-index-storage-sqlite/src/main/resources/kie-flyway/db/data-index/sqlite/`
2. **配置**:`platform-extensions/data-index-storage-sqlite/src/main/resources/META-INF/kie-flyway.properties`
3. **觸發**:Quarkus 啟動時,`platform-data-index` 模組自動啟用 Flyway
4. **記錄表**:`kie_flyway_history_data_index`(族群 E)

```properties
# META-INF/kie-flyway.properties
kie.flyway.url=jdbc:sqlite:${shared.db.path}
kie.flyway.locations=classpath:kie-flyway/db/data-index/sqlite
kie.flyway.table=kie_flyway_history_data_index
```

## B.4 為何每個改欄位都拆成獨立 migration?

**Flyway 最佳實踐**:每個 migration 腳本只做一件事,方便:
1. **Rollback 分析**:壞了哪個 migration 一目了然
2. **Code review**:PR 小而精
3. **Cherry-pick**:可以選擇性 backport 某些欄位到舊版
4. **跨環境一致性**:dev/staging/prod 跑同一序列

本專案遵循 Kogito 官方的腳本切分粒度,沒額外合併。

## B.5 如何擴展新 migration(本專案流程)

如果要加一個新欄位到 `workflow_execution_log`(例如加 `transaction_id`):

```bash
# 1. 在 platform-extensions/data-index-storage-sqlite/.../sqlite/ 建立新檔
vim V1.51.0__add_transaction_id_to_audit.sql
```

```sql
-- V1.51.0__add_transaction_id_to_audit.sql
ALTER TABLE workflow_execution_log ADD COLUMN transaction_id TEXT;
CREATE INDEX idx_wel_transaction_id ON workflow_execution_log(transaction_id);
```

```bash
# 2. 重啟 Quarkus,Flyway 自動跑這個腳本
# 3. 驗證
sqlite3 reconciliation.db "PRAGMA table_info(workflow_execution_log);" | grep transaction_id
# 應該要看到 transaction_id TEXT
```

> ⚠️ 警告:不要直接改 `AuditLogService` 內的 INSERT SQL 不改 schema — 會 runtime crash。

## 附錄 C:名詞對照表


> Kogito / SonataFlow / 業務 三種語言體系翻譯對照

## C.1 核心概念對照

| 業務術語 | SonataFlow 術語 | Kogito 術語 | 資料庫對映 |
|---|---|---|---|
| 一次交易 | Workflow instance | Process instance | `processes` 1 列 |
| 交易步驟 | State | Node | `nodes` 1 列 |
| 交易類型/合約 | Workflow definition | Process definition | `definitions` 1 列 |
| 工作流 YAML | `.sw.yaml` 檔 | 同 | `definitions.source` BLOB |
| 步驟設計 | State graph | Node graph | `definitions_nodes` |
| 步驟執行 | State execution | Node execution | `nodes` |
| 一次任務 | User task | User task instance | `tasks`(本專案未用) |
| 排程工作 | Timer / Async | Job | `jobs` |
| 業務審計 | 對帳記錄 | (應用層自定義) | `workflow_execution_log` |

## C.2 狀態碼對照

### `processes.state`

| 業務語意 | DB 值 | 觸發時機 |
|---|:---:|---|
| 進行中 | 1 | workflow 啟動後到結束前 |
| 正常完成 | 2 | 跑完所有 state 沒 error |
| 中止 | 3 | 因 error 中止 |

### `workflow_execution_log.status`

| 值 | 業務語意 | 範例 |
|---|---|---|
| `SUCCESS` | 交易成功 | 扣款 + 入帳都成功 |
| `FAILED` | 業務失敗,無回沖 | AMT 預校驗擋下 |
| `ROLLED_BACK` | 部分回沖或全回沖 | LIFO 雙沖 / 單沖 |

> 注意:`processes.state` 與 `workflow_execution_log.status` **不是 1:1 對應**。
> - `state=2` (Completed) + `status=ROLLED_BACK` — 對 engine 而言 Saga 跑完就算 Completed,但業務上算回沖
> - `state=3` (Aborted) + `status=FAILED` — 完全失敗

## C.3 節點類型對照

| DB `nodes.type` | SonataFlow state 類型 | 業務對應 |
|---|---|---|
| `StartNode` | `start` | workflow 進入點 |
| `EndNode` | `end` | workflow 結束點 |
| `ActionNode` | `script` | 跑 groovy/javascript 邏輯 |
| `WorkItemNode` | `operation` | 呼叫外部 function / REST |
| `CompositeContextNode` | (包含 subflow) | 包 sub-state 的容器 |
| `Split` | 平行分支入口 | fan-out |
| `Join` | 平行分支匯合 | fan-in |
| `SubProcessNode` | 呼叫子 workflow | 流程嵌套 |
| `ForEachNode` | 迴圈 | batch 處理 |

## C.4 API 呼叫代號對照

| 代號 | 業務意義 | 模擬情境 |
|---|---|---|
| `A16229` | 銀行扣款(debit) | 從 Account_A 扣 AMT |
| `A16220` | 銀行入帳(credit) | 存到 Account_B |
| `callApiViaOpenAPI` | 通用 OpenAPI 呼叫器 | MyOpenApiService 動態呼叫 |
| `recordAuditLog` | 寫審計日誌 | AuditLogService.saveLog() |

## C.5 模組 ↔ 套件 對照

| 模組 artifactId | Maven groupId | Java package |
|---|---|---|
| `platform-common` | `org.acme.platform` | `com.example.platform.common` |
| `platform-security` | `org.acme.platform` | `com.example.platform.security` |
| `platform-data-index` | `org.acme.platform` | `org.acme.platform.dataindex` |
| `platform-extensions/data-index-storage-sqlite` | `org.kie.kogito`(來源) | `org.kie.kogito.index.sqlite` |
| `platform-extensions/kogito-addons-quarkus-data-index-sqlite` | `org.kie.kogito` | `org.kie.kogito.addons.quarkus.data.index.runtime` |
| `transfer-api` | `org.acme.platform` | `org.acme.transfer.api` |
| `transfer-workflow` | `org.acme.platform` | `com.example.transfer.workflow` |
| `transfer-samples` | `org.acme.platform` | `com.example.platform.transfer.samples` |
| `reconciliation-api` | `org.acme.platform` | `com.example.reconciliation` |
| `transfer-app` | `org.acme.platform` | `com.example.platform.distribution.transfer` |
| `reconciliation-app` | `org.acme.platform` | `com.example.platform.distribution.reconciliation` |

## C.6 HTTP 端點對照

| 端點 | 模組 | 用途 |
|---|---|---|
| `POST /saga2-transfer-workflow` | transfer-app | 啟動 saga |
| `POST /saga-transfer-workflow` | transfer-app | 啟動舊版 saga |
| `GET /q/health/live` | 兩個 app | liveness probe |
| `GET /q/health/ready` | 兩個 app | readiness probe |
| `GET /reconciliation/export-csv` | reconciliation-app | 對帳 CSV 匯出 |
| `POST /graphql` | 兩個 app | Kogito Data Index GraphQL |
| `GET /q/metrics` | 兩個 app | Prometheus metrics |

## C.7 時間格式對照

| 來源 | 格式 | 範例 |
|---|---|---|
| `processes.start_time` 等 Kogito 表 | epoch millis (TEXT) | `1786951944351` |
| `workflow_execution_log.created_at` | ISO-8601 (TIMESTAMP) | `2026-08-17 07:32:24` |
| Kogito GraphQL response | ISO-8601 (字串) | `2026-08-17T07:32:24.351Z` |
| 日誌(log4j) | ISO-8601 + 時區 | `2026-08-17 07:32:24,351+0800` |

> **轉換公式**:`datetime(start_time/1000, 'unixepoch')` 可把 millis 轉成 SQL datetime

## 附錄 D:參考文件索引


## D.1 專案內部文件

| 文件 | 路徑 | 內容 |
|---|---|---|
| README | `/README.md` | 專案入口、模組全景、快速建置 |
| 系統架構書 | `/docs/SYSTEM-ARCHITECTURE.md` | 8 章 + Mermaid 完整架構 |
| 程式碼規格書 | `/docs/CODE-SPECIFICATION.md` | 24KB Java 程式碼詳細說明 |
| 模組切分決策 | `/docs/MODULE-SPLIT-DECISION.md` | 為什麼這樣切模組 |
| 架構書 PDF | `/docs/SYSTEM-ARCHITECTURE.pdf` | 架構書的 PDF 版 |
| 模組切分論證 | `/docs/MODULE-SPLIT-RATIONALE.docx` | 重構決策的詳細論證 |

## D.2 本專案的 SQL 與 Java 對映

### SQL 物件
- 22 個 Flyway 腳本:`platform-extensions/data-index-storage-sqlite/src/main/resources/kie-flyway/db/data-index/sqlite/`
- 1 個 view (`vw_saga_reconciliation`):在 Flyway 啟動後由應用層 SQL 創建,或由 Hibernate auto-DDL

### Java 主要 entry point
- `domain-reconciliation/reconciliation-api/src/main/java/com/example/reconciliation/AuditLogService.java` — 寫 audit log
- `domain-reconciliation/reconciliation-api/src/main/java/com/example/reconciliation/ReconciliationCsvExporter.java` — 讀 audit log
- `domain-reconciliation/reconciliation-api/src/main/java/com/example/reconciliation/ReconciliationResource.java` — 暴露 HTTP
- `domain-transfer/transfer-workflow/src/main/resources/saga2-transfer-workflow.sw.yaml` — 觸發 recordAuditLog 的 workflow
- `platform-data-index/src/main/java/org/acme/platform/dataindex/KogitoSQLiteDialect.java` — 自訂 SQLite dialect
- `platform-data-index/src/main/java/org/acme/platform/dataindex/MyLivenessCheck.java` — 健康檢查

## D.3 外部權威文件

| 主題 | 來源 |
|---|---|
| SonataFlow 0.8 spec | https://serverlessworkflow.io/schemas/0.8/ |
| Kogito Data Index | https://kiegroup.github.io/kogito-docs/serverlessworkflow/main/services/data-index.html |
| Quarkus JDBC SQLite | https://quarkus.io/guides/databases-sqlite |
| Flyway 文件 | https://flywaydb.org/documentation/ |
| SQLite WAL 模式 | https://www.sqlite.org/wal.html |

## D.4 對應本文件的章節交叉索引

| 議題 | 落在本文件哪章 |
|---|---|
| 「DB 有哪些表?」 | Ch02 / Ch03 |
| 「這張表是誰寫的?」 | Ch05 |
| 「一個交易怎麼跑?」 | Ch06 |
| 「Kogito 引擎內部怎麼存?」 | Ch07 |
| 「為什麼 schema 長這樣?」 | Ch08 |
| 「出問題怎麼辦?」 | Ch09 |
| 「DDL 怎麼寫?」 | 附錄 A |
| 「術語看不懂?」 | 附錄 C |

## D.5 版本歷史

| 版本 | 日期 | 變更 |
|---|---|---|
| 1.0 | 2026-08-19 | 初版,對應 myhello-platform 1.0.0-SNAPSHOT |

