# 信用卡臨櫃現金繳款 Workflow Draft — 設計說明書

> 給創建者看的文件：解釋「這份 draft 是怎麼被設計出來的」
> 日期：2026-09-07
> 對應業務書：`requirement/credit-card-counter-cash-repayment-requirement.md` v2.2
> 對應產出：`draft-omni-counter-repayment-v2/`（20 個檔案）+ `draft-omni-counter-repayment-v2.zip`
> 目標平台：SonataFlow 10.2.0 on Kogito，整合目標 `project-0825-pd`

---

## 0. 導讀：先看這一段

如果你只有 3 分鐘，請看這一段：

1. **業務要什麼**：臨櫃現金繳款只有一個對外入口，櫃員傳 `operationType=A` 做正向繳款、`operationType=B` 做反向取消。錢必須同時進「核心總帳」和「信用卡主機」，兩邊都成功才算成功。
2. **設計選了什麼**：用 **Mode B（Parent + 2 個 Child）**。Parent 負責收單、驗證、查重複、路由、記帳、回應；Child A 做繳款兩階段；Child B 做取消反向兩階段。
3. **為什麼你會看到 20 個檔案**：3 份 OpenAPI（對外 1 + 主機 2）、3 份 workflow YAML（Parent + 2 Child）、2 個 mock 主機、3 個 Java 服務模板、1 份 DB view、1 份組態、1 份測試、1 份 spec 共 20 檔。每一檔都有明確分工，§6 有地圖。
4. **最容易誤會的 5 個決策**：全部用 `snake_case` 命名（避開平台 bug）、回應用 `status 0/1 + finalStatus` 雙欄位、輸入驗證放在流程內（避免審計斷層）、測試用 `FAIL_` 前綴不會被驗證擋掉、Parent 和 Child 版本號必須同為 `1.0.1`。
5. **還沒確定的事**：序號長度、取消時間窗、主機有沒有查詢端點等 7 件事在 §8，draft 先用最嚴格的假設，業務方確認後可改。

---

## 1. 背景與目標

### 1.1 現在的痛點（業務書 §1.2）

| 痛點 | 白話解釋 |
|---|---|
| 單一入帳 | 錢只進信用卡帳，沒同步進核心總帳，對帳對不起來 |
| 無統一入口 | 繳款和取消走不同端點，呼叫端要寫兩套邏輯 |
| 無統一取消機制 | 櫃員打錯卡，沒有標準反向流程 |
| 無對帳軌跡 | 失敗、重試、補償沒有系統化記錄 |

### 1.2 這份 draft 的目標

- **單一 API 入口**：`POST /omni_cash_transaction`，用 `operationType` 區分正向 / 反向。
- **最終一致**：核心和信用卡任一失敗，系統保證補償或告警，不會錢進一半。
- **標準化取消**：取消有固定流程（先查原交易 → 反向兩主機 → 標記已取消）。
- **可整併**：產出符合下游 `sonataflow-integration` 的 9 項預檢 + 26 項自查，移交後工時 < 1 小時。

### 1.3 不做什麼（業務書 §2.2）

跨日退款、外幣繳款、預授權、非臨櫃通路（網銀/ATM）都不在這版。

---

## 2. 輸入來源：設計是從哪幾份文件長出來的

| 文件 | 版本 | 用來決定什麼 |
|---|---|---|
| `requirement/credit-card-counter-cash-repayment-requirement.md` | v2.2 | Parent 職責、Dispatcher 規則、12 個對外狀態、BR-P / BR-001~BR-508 業務規則、驗收 P1/A1/P4/B1/B2 |
| `requirement/OmniRepaymentAPI.md` | v1.0 | 對外入口欄位範例（`2500P`、`0000011758`、`A1234567890000015061655` 這些真實字串直接拿來定 maxLength） |
| `requirement/CoreAccountCashDepositAPI.md` | v1.0 | 核心主機路徑 `/CoreAccount/{creditcardid}/CashDeposit/Execute`、path param `{creditcardid}`、回應含 `track_id/status/errors/result` |
| `requirement/ExecuteCreditCardRepaymentAPI.md` | v1.0 | 信用卡主機路徑 `/CreditCard/{creditcardid}/Repayment/Execute`，同上 |
| skill 範例 `examples/01-financial-repayment/` | v2.1 | YAML 寫法、mock 寫法、測試寫法的模板 |

設計前先問了 5 個前置問題（Step 0），你當時的回答全部採 Recommended：SonataFlow 10.2.0、整合進 project-0825-pd、SQLite + Flyway、Parent 對外 + 兩個 host mock（Mode A）。這 5 個答案決定了後面所有技術選型。

---

## 3. 從需求到設計：三步推導

### 3.1 第一步：把業務書拆成「誰做什麼」

業務書 §4.0 的 Parent 職責 P1~P8，直接對應到 workflow 的 state：

```
業務書語言                    →  workflow 語言
P1 輸入驗證                   →  ValidateInput（switch）
P3 冪等性檢查                 →  CheckIdempotency（查 IdempotencyService）
P2 Dispatcher                 →  DispatchOperation（switch：A→Child A，B→Child B）
P4 委派執行                   →  InvokeDepositSubflow / InvokeCancellationSubflow（subFlowRef）
P5 統一稽核                   →  FinalAuditAndEnd（調 recordAuditLog，保證一定寫到）
P6 統一回應                   →  End（stateDataFilter.output，固定格式）
P7 補償治理 + P8 告警         →  RollbackCore / RollbackCancelCore + NotifyAndAudit（調 notifyOps）
```

Child 不做的事（業務書 §4.0.2：不驗證、不查冪等、不定回應格式）→ 所以 Child YAML 裡沒有 ValidateInput，直接從 `CallCoreForward` / `CancelCore` 開始。

### 3.2 第二步：選模式

5 種模式裡只有一種符合「一個入口、兩種業務」：

- Mode A（單層 Saga）不行：A 和 B 的流程差太多（B 要先 lookup），硬塞一層會變成蜘蛛網。
- **Mode B（Parent + 2 Child）✅**：Parent 只管路由和善後，Child 各管一種業務。以後加 WF-C（比如跨日退款）只要再加一個 Child，Parent 加一條路由。
- Mode C/D/E（多層審批 / 事件 / 排程）跟本業務無關。

選 Mode B 的直接後果：Parent YAML 會出現 `subFlowRef`，於是觸發 Kogito 10.2.0 的 hyphen-id bug，必須全用 `snake_case`（見 §4.1）。

### 3.3 第三步：定回應長什麼樣

業務書 §6.3 的統一回應有 `status` + `finalStatus` 兩個欄位，這就是 skill 說的「新 convention」：

```json
{
  "track_id": "SEQ_xxx",
  "workflow": "REPAYMENT",
  "status": 0,
  "finalStatus": "SUCCESS",
  "result": { "partyId": "...", "coreResult": {...}, "ccResult": {...} }
}
```

- `status` 是給機器看的（0=成功，1=失敗），用來改寫 HTTP code。
- `finalStatus` 是給人看的（SUCCESS / CANCELLED / ROLLED_BACK 等 12 種，見下表）。
- Child 對外不直接回應，所以 Child 的 output 只有 `finalStatus`，沒有 `status`。這是故意的，不是漏寫。

12 個對外狀態與 HTTP 對應（業務書 §5.2 + §5.4）：

| finalStatus | HTTP | status | 意思 |
|---|---|---|---|
| SUCCESS | 200 | 0 | 兩階段都成功 |
| FAILED | 200 | 1 | 核心拒絕，錢沒進，不補償 |
| ROLLED_BACK | 200 | 0 | CC 失敗但核心補償成功，錢已退 |
| ROLLBACK_FAILED | 409 | 1 | 補償也失敗，告警找主管 |
| CANCELLED | 200 | 0 | 取消成功 |
| CANCEL_REJECTED | 200 | 1 | 原交易不是 SUCCESS 或已被取消，不給取消 |
| CANCEL_FAILED | 200 | 1 | 取消第一階段失敗，原帳還在，可重試 |
| CANCEL_ROLLED_BACK | 200 | 0 | 取消第二階段失敗但回滾成功 |
| CANCEL_ROLLBACK_FAILED | 409 | 1 | 取消補償失敗，告警 |
| REJECTED_VALIDATION | 400 | 1 | 輸入錯，連主機都沒打 |
| LOOKUP_FAILED | 500 | 1 | 要取消的交易找不到 |
| IDEMPOTENT_REPLAY | 200 | 0 | 重複送，直接回上次結果 |

---

## 4. 關鍵設計決策（5 條，每條都含「沒這樣做會怎樣」）

### 4.1 全部用 snake_case 命名（`omni_cash_transaction`）

- **選了什麼**：3 個 workflow id 全用底線：`omni_cash_transaction`、`repayment_cash_deposit`、`repayment_cash_cancellation`。版本全 `1.0.1`。
- **為什麼**：Kogito 10.2.0 有個 codegen bug——只要 Parent 有 `subFlowRef` 且 id 含 `-`，產生的 Java 會變成 `processrepayment-cash-cancellation` 這種不合法變數名，編譯直接炸掉。參考 `references/01-platform-checks/01-workflow-id-naming.md`。
- **沒選什麼**：業務書寫的 `CashTransaction` / hyphen 風格（`omni-cash-transaction`）。
- **不這樣做的後果**：`KieMemoryCompilerException: ';' expected`，整合階段才發現，改 9 處（YAML、config、SQL view、測試 URL、文件），至少半天。
- **在哪裡看到**：3 個 `.sw.yaml` 的 `id:`、`subFlowRef.workflowId`、`application.properties.snippet` 的 `status-rewrite.workflows`、SQL view 的 `WHERE workflow_id IN (...)`。

### 4.2 輸入驗證放在流程內，不用引擎原生 dataInputSchema

- **選了什麼**：Parent 第一個 state 是 `ValidateInput`（switch），失敗走 `InjectValidationFailed → FinalAuditAndEnd`（一定寫 audit log）。
- **為什麼**：金融審計要求「失敗也要留痕」。引擎原生的 `dataInputSchema` 會在 workflow 實例建立前就丟 400，根本到不了寫 audit 的 state，造成 Audit Gap（有請求、沒記錄，對帳永遠對不上）。
- **不這樣做的後果**：P1（operationType=C）這類錯誤請求在監控和對帳 view 裡完全消失。
- **在哪裡看到**：`parent-workflow.sw.yaml` 的 `ValidateInput`、`InjectValidationFailed`、`FinalAuditAndEnd`。

### 4.3 Mock 用 Mode A（`FAIL_` 前綴），validator 配合放行

- **選了什麼**：測試想觸發「主機拒絕」時，傳 `amount="FAIL_AMT..."`；想觸發「補償失敗」時，傳 `sequenceNumber="RBFAIL..."`。同時把 OpenAPI 的 amount regex 寫成 `^(FAIL_[A-Z0-9_]+|[0-9]{1,22})$`，validator 也放行 `FAIL_`，workflow 的 `tonumber` 改用安全寫法 `tonumber? // 1`。
- **為什麼**：測試需要一條「不改程式碼就能走失敗路徑」的開關。Mode B（獨立 `__sentinel` 欄位）雖然乾淨，但每個 payload 要多帶欄位，真實主機又沒有這個欄位，容易忘記拔掉。
- **沒選什麼**：Mode B（備選，僅當 regex 絕對不能動時用）。
- **不這樣做的後果**：三件套缺一就會斷鏈——regex 擋掉 `FAIL_`（到不了 mock）、或 `tonumber` 遇到 `FAIL_` 拋錯（finalStatus 變 null）。實況新 5 域就是 validator 沒同步，失敗路徑零覆蓋。
- **在哪裡看到**：`notebooks/**/pattern`、`spec/mocks/*.java` 的 `startsWith("FAIL_...")`、`spec/*.sw.yaml` 的 `tonumber?`。

### 4.4 回應雙軌：主機業務碼和對外 status 分開

- **選了什麼**：讀主機回應時用 `results: '{status: .code, ...}'`（讀頂層 `.code`）；對外輸出時用 `status: (if .finalStatus == "SUCCESS" ... then 0 else 1 end)` 重新算。
- **為什麼**：主機的 `code` 是 string（`"100"`），對外的 `status` 是 int（`0/1`），兩者意義不同，不能直接透傳。且 `MyOpenApiService::callOpenApi` 回的是頂層欄位，不是 `.result` 底下，寫 `.result.code` 會拿到 null。
- **不這樣做的後果**：`status` 永遠 null，status-rewrite 改寫 HTTP code 失效，全部回 200。
- **在哪裡看到**：`child-deposit.sw.yaml` 的 `actionDataFilter.results`、`parent-workflow.sw.yaml` 的 `output.status`。

### 4.5 直調一定要寫 toStateData，subFlow 不用

- **選了什麼**：每個直接調 function 的 action 都寫 `toStateData: '${ .coreResult }'`（或 `.ccResult`、`.lookupResult` 等），把結果隔離存進一個 key。
- **為什麼**：Kogito 有個反直覺行為——如果只寫 `results` 沒寫 `toStateData`，它會把 results 整份蓋掉 workflow 記憶體，之前輸入的 `partyId`、`amount`、`sequenceNumber` 全丟失，下游 subflow 和 audit 全變 null。
- **例外**：`subFlowRef`（12 處實況都沒有 actionDataFilter，正常）、terminal 的 `recordAuditLog` 可以豁免。
- **在哪裡看到**：`spec/*.sw.yaml` 所有 `actionDataFilter` 下都有 `toStateData`（預檢 6.8 全綠）。

---

## 5. 產出物地圖：20 個檔案各是幹嘛的

```
draft-omni-counter-repayment-v2/
├── notebooks/                              ← OpenAPI（SSOT：所有欄位規則的唯一來源）
│   ├── internal/
│   │   └── omni-cash-transaction-api.yaml  ← 對外入口。唯一含 x-workflow-id 的檔案，
│   │                                          給動態路由自動註冊用。11 個輸入欄位、
│   │                                          12 種 finalStatus 全在這定義。
│   └── external/
│       ├── core-account-cash-deposit-api.yaml ← 核心主機。含 {creditcardid} path param，
│       │                                        workflow 必須在 payload 補上它。
│       └── credit-card-repayment-api.yaml      ← 信用卡主機。同上。
└── spec/
    ├── parent-workflow.sw.yaml             ← Parent。驗證→查重複→路由→委派→記帳→回應。
    ├── child-deposit.sw.yaml               ← Child A。Core→CC，CC 失敗補償 Core。
    ├── child-cancellation.sw.yaml          ← Child B。反向 Core→反向 CC→標記原交易。
    ├── spec.md                             ← 規格書。H1-H18 假設 + 11 章節 + 預檢/自查結果表。
    ├── db/
    │   └── V1.2.0__*.sql                   ← 對帳 view。把 3 個 workflow 的記錄收斂成一張表給監控查。
    ├── config/
    │   └── application.properties.snippet  ← 組態。status→HTTP 對照 + bean 綁定 + mock/真機切換。
    ├── mocks/
    │   ├── CoreCashDepositResource.java    ← 假核心主機（dev 用）。看 amount/sequenceNumber 前綴決定回成功/拒絕/當機。
    │   ├── CreditCardRepaymentResource.java← 假信用卡主機。同上。
    │   └── dto/                            ← 5 個純欄位 DTO（無 getter/setter，跟既有 mock 一致）。
    ├── services/                           ← Java 模板（draft 側佔位，下游才真正落位）
    │   ├── IdempotencyService.java         ← 新建。Parent 查「這個序號是不是送過了」。
    │   ├── AuditLogServiceExtension.java   ← 擴充既有。查原交易 + 標記已取消（cancelled_by 必須參數化）。
    │   └── OmniCashBusinessRuleValidator.java ← 新建。A 不可帶原序號 / B 必帶原序號 + FAIL_ 剝離。
    └── tests/
        └── OmniCashTransactionWorkflowTest.java ← 5 場測試：P1(400)/A1(成功)/P4(重送)/B1(取消)/B2(找不到)。
```

檔名和 id 對應（允許檔名≠id，以 Manifest 登記為準）：

| 檔案 | id |
|---|---|
| parent-workflow.sw.yaml | omni_cash_transaction |
| child-deposit.sw.yaml | repayment_cash_deposit |
| child-cancellation.sw.yaml | repayment_cash_cancellation |

---

## 6. 流程解說：一個請求走一遍

### 6.1 正向繳款（operationType=A）

```
櫃員 POST /omni_cash_transaction（11 個欄位）
  → ValidateInput：operationType 是 A、有 sequenceNumber、amount 不是 0000000000 → 通過
  → CheckIdempotency：查 workflow_execution_log，這個序號沒出現過 → 繼續
  → DispatchOperation：operationType=A → InvokeDepositSubflow
  → Child A：
      CallCoreForward（調核心主機，payload 含 creditcardid=partyId）
      → 成功 → CallCCForward（調信用卡主機）
        → 成功 → finalStatus=SUCCESS
        → 失敗 → RollbackCore（調核心沖正）→ 成功=ROLLED_BACK / 失敗=ROLLBACK_FAILED(+告警P1)
      → 失敗 → finalStatus=FAILED（錢沒進，不補償）
  → FinalAuditAndEnd：寫 audit
  → End：回 {status:0/1, finalStatus, result:{coreResult, ccResult}}
```

### 6.2 反向取消（operationType=B）

```
櫃員 POST（多帶 originalSequenceNumber）
  → ValidateInput：B 且有原序號 → 通過（A 帶原序號反而擋掉，這是 BR-P03）
  → CheckIdempotency → DispatchOperation：B → LookupOriginalForCancel
  → CheckLookupResult：
      找不到 → LOOKUP_FAILED(500) + 告警P2
      原狀態不是 SUCCESS → CANCEL_REJECTED（只能取消成功的）
      已被取消過（cancelled_by 有值）→ CANCEL_REJECTED（防重複取消）
      通過 → InvokeCancellationSubflow
  → Child B：反向 Core → 反向 CC → MarkCancelled（把原交易的 cancelled_by 填上這次序號）
  → FinalAuditAndEnd → End：回 {workflow:"CANCELLATION", finalStatus:CANCELLED, ...}
```

### 6.3 測試怎麼覆蓋

| 場景 | 怎麼觸發 | 預期 |
|---|---|---|
| P1 | operationType=C | 400 REJECTED_VALIDATION（連主機都沒打，但 audit 有寫） |
| A1 | 正常 11 欄位，序號用 nanoTime 保證唯一 | 200 SUCCESS，coreResult/ccResult 都有 trackId |
| P4 | 同一 payload 送兩次 | 第一次 SUCCESS，第二次 IDEMPOTENT_REPLAY（主機只被打一次） |
| B1 | 先送一筆 A 成功，再送 B 指著它取消 | 200 CANCELLED，且原交易的 cancelled_by 有值（測試會查 DB） |
| B2 | B 指著不存在的序號 | 500 LOOKUP_FAILED |

---

## 7. 假設與待確認（H1-H18 精簡版）

完整版在 `spec/spec.md §0`。這裡只列「需要人來拍板」的：

| 假設 | 現在怎麼定 | 待確認 |
|---|---|---|
| 序號長度 | maxLength=30（實測 `A1234567890000015061655` 是 23 碼） | API owner 確認到底是 13 還是 22 還是 23 |
| 取消時間窗 | 以 transactionDate 當日為準 | 業務方確認是 24 小時還是當日 |
| 原交易查找鍵 | 只用 originalSequenceNumber，不做模糊查 | 業務方確認序號是否 partyId 內全域唯一 |
| 主機查詢端點 | 假設沒有，所以 timeout 流程先不做 | 主機 owner 確認有無「依 seq 查狀態」 |
| `2500P` | 當成合法 paymentSourceCode（maxLength 放寬到 5） | 業務方確認複合碼清單 |
| cancelled_by | 用參數傳，不寫死 | 下游合併程式碼時不要寫死 workflow_id（已知坑） |

---

## 8. 驗證：怎麼證明這份 draft 是對的

跑了兩輪機器檢查，全部綠燈（證據在 `spec/spec.md §10` `§11`）：

- **10 項平台預檢**：id 命名、actionDataFilter 頂層欄位、path param 注入、output convention、無 trailing comma、sentinel 過驗證、schema/example 一致、toStateData、internal/external 二分、version 對齊。
- **26 項自查**：FQCN 假設齊全、convention 分流正確、測試 5 場 + nanoTime 唯一序號、`tonumber?` 防呆、`start:` 顯式、servers 齊全、無 `schemas/*.json`。
- **修過的 1 個真 bug**：`description: ⭐ 新 convention: 0=成功...` 少了引號導致整份 YAML 解析失敗，已修（教訓：emoji 開頭 + 中段冒號要加引號）。

---

## 9. 已知限制與下一步

### 9.1 這版沒做的事

- 主機「依 seq 查狀態」端點未知，timeout 後的未知狀態查詢流程（業務書 §9.3）先留白。
- A4/A5/B5/B6/B7 的細粒度測試是空殼，sentinel 已在 mock 留好（FAIL_500、RBFAIL_CC），下游加測試即可。
- 對外路徑用 snake_case（`/omni_cash_transaction`），跟業務書的 hyphen 寫法不同，API 消費者要注意。

### 9.2 移交給下游（sonataflow-integration）

| draft 檔案 | 下游落點 |
|---|---|
| 3 個 .sw.yaml | `domain-transfer/transfer-workflow/.../resources/` + distribution 鏡像 |
| internal/external yaml | `.../resources/specs/internal/` + `specs/external/` 雙模組同步 |
| 3 個 service | 依 Manifest 落 `domain-transfer` / `domain-reconciliation` / `domain-security` |
| mocks | `dev/transfer-mock/.../org/acme/transfer/api/`（已對齊，免 rename） |
| V1.2.0 sql | `domain-reconciliation/.../db/migration/` |
| config snippet | 合併進 `distribution/transfer-app/.../application.properties` |
| 測試 | `distribution/transfer-app/.../transfer/` 跑 QuarkusTest |

預期整合工時 < 1 小時（上游預檢全綠的前提下）。

---

## 附錄：名词解釋（給第一次看的人）

| 詞 | 白話 |
|---|---|
| Parent / Child | 總機 / 分機。Parent 接電話、分線，Child 做實際的事。 |
| subFlowRef | Parent 說「這段交給 Child 做」的指令。 |
| Dispatcher | 總機的分線規則（看 operationType 是 A 還是 B）。 |
| 冪等（Idempotency） | 同一張單送兩次，只算一次錢，第二次直接回上次答案。 |
| LIFO 補償 | 第二步失敗，把第一步已做的事反向沖掉（後做先回滾）。 |
| Audit Gap | 有請求、沒記錄。對帳會永遠少一筆，所以驗證失敗也要寫 log。 |
| FQCN | Java 類別的全名（package + 類名 + 方法），下游靠它知道要新建還是擴充哪支程式。 |
| Sentinel | 測試開關。傳特定前綴（如 FAIL_AMT）讓假主機故意回失敗，藉此測失敗路徑。 |
| SSOT | 唯一真相來源。本 draft 裡輸入規則只看 notebooks 的 YAML，不另存 JSON。 |
