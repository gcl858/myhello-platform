# Omni Cash Transaction - Spec v2.0 (Draft)

> 對應 draft: `draft-omni-counter-repayment-v2/` (信用卡臨櫃現金繳款 v2.2 業務書)
> 撰寫日期: 2026-09-07
> 設計期採用模式: Mode B (Parent + 2 Child Subflow)
> Convention: 新 (status: 0/1 int + finalStatus: string)
> 目標平台: SonataFlow 10.2.0 on Kogito
> 整合目標: project-0825-pd (transfer-workflow + reconciliation-api)

---

## §0 假設清單 (Step 1a 強制結構 H1-H18)

| # | 假設 | 為何這樣假設 | 待確認問題 | 落地策略 |
|---|---|---|---|---|
| **H1** | 輸入欄位 11 個 (partyId, branchCode, transactionDate, transactionDateTime, postingDayType, postingDate, paymentSourceCode, operationType, amount, sequenceNumber, originalSequenceNumber?) | 業務書 §6.2 | — | spec §2.1 + `notebooks/internal/omni-cash-transaction-api.yaml` |
| **H2** | 終態 finalStatus 有 12 個 (含 ROLLED_BACK / CANCEL_ROLLED_BACK) | 業務書 §5.2 | — | spec §2.3 + status-rewrite config mapping |
| **H3** | 對外契約用 REST POST `/omni_cash_transaction` (snake_case 路徑) | 既有 transfer-workflow 用 REST；Step 6.1 snake_case 規避 Kogito bug | — | `notebooks/internal/omni-cash-transaction-api.yaml` (內含 `x-workflow-id: omni_cash_transaction`) |
| **H4** | CoreAccount + CreditCard 兩階段 (正向繳款) | 業務書 §4.1 | — | `child-deposit.sw.yaml` |
| **H5** | 取消需 lookup 原 SUCCESS transaction (BR-301, A5 假設) | 業務書 §4.2.2 | — | `LookupOriginalForCancel` state in parent-workflow |
| **H6** | **FQCN**: `com.example.platform.reconciliation.AuditLogService::findBySequenceNumber` (擴充既有) | 既有 service 無此方法 | 需擴充 | `spec/services/AuditLogServiceExtension.java` |
| **H7** | input validation 採用 OpenAPI SSOT 驅動 (拒絕 Kogito 原生 dataInputSchema，避免 Audit Gap) | 業務書 §7.5；Step 1d 金融審計原則 | — | parent-workflow ValidateInput (switch) → InjectValidationFailed → FinalAuditAndEnd 確保 100% 審計 |
| **H8** | Mock sentinel 採用 Mode A (FAIL_AMT / FAIL_CC / FAIL_500 + RBFAIL / RBFAIL_CC) + validator 豁免 | 業務 regex 不可放寬至 FAIL_*；Step 5b/6.6 | — | amount regex `^(FAIL_[A-Z0-9_]+|[0-9]{1,22})$`；mock 用 `startsWith("FAIL_AMT")` 等；spec §7 註明 |
| **H9** | DB 採用 SQLite + Flyway (對齊 project-0825-pd) | 既有 transfer-workflow 用 SQLite | — | `spec/db/V1.2.0__create_view_omni_cash_transaction_reconciliation.sql` |
| **H10** | V 編號從既有最大 +1 (假設既有最大 V1.1.0，本 draft 產 V1.2.0) | Step 4d 自動探測 | — | sql 檔名 |
| **H11** | 對帳 view 採 snake_case workflow id 過濾 | Step 6.1 snake_case 規避 | — | sql WHERE clause 用 `'omni_cash_transaction'` |
| **H12** | workflow id 採 snake_case 命名 (`omni_cash_transaction`) | Step 6.1 Kogito 10.2.0 codegen bug 規避 (subFlowRef 必用) | — | 全部 workflow YAML + sql view + config |
| **H13** | **FQCN**: `com.example.platform.distribution.transfer.IdempotencyService::findBySequenceNumber` (新 class) | 既有 service 無此類別 (BR-502 Parent 級冪等) | 需新建 | `spec/services/IdempotencyService.java` |
| **H13a** | **FQCN**: `com.example.platform.security.OmniCashBusinessRuleValidator::validate` (新 validator) | BR-P03 條件必填 (opType=B 必填 originalSequenceNumber) + FAIL_ 剝離邏輯 | 需新建 | `spec/services/OmniCashBusinessRuleValidator.java`；於 `OpenApiSchemaValidator` dispatch 註冊 |
| **H14** | **FQCN**: `com.example.platform.reconciliation.AuditLogService::markCancelledBy` (擴充既有) | 既有 service 無此方法 (BR-308) | 需擴充 | `spec/services/AuditLogServiceExtension.java`；`cancelled_by` 必須參數化不可寫死 workflow_id |
| **H15** | **subFlowRef version**: Parent `1.0.1` ↔ Child `1.0.1` (對齊) | Step 6.10 預檢 (實況 omni 1.0.1 vs 1.0 教訓) | — | 三個 workflow YAML 同步 |
| **H16** | **Convention**: Parent 新 convention (`status: 0/1` int + `finalStatus` string) | 與 credit-card 體系對齊 | — | stateDataFilter.output (Parent) |
| **H17** | **Mock package**: `org.acme.transfer.api` (對齊既有 transfer-mock) | 避免下游 rename 工時 | — | spec/mocks/* 全部 |
| **H18** | **檔名-id Manifest**: `parent-workflow.sw.yaml:id=omni_cash_transaction`, `child-deposit.sw.yaml:id=repayment_cash_deposit`, `child-cancellation.sw.yaml:id=repayment_cash_cancellation` | Step 7.14 + 允許檔名≠id | — | spec §8 Manifest 表格 |

---

## §1 概覽

Parent workflow (`omni_cash_transaction`) 接收信用卡臨櫃現金繳款 v2.2 業務書的統一入口，依 `operationType` dispatcher 鍵路由到對應 child subflow:

- `operationType=A` → 委派給 `repayment_cash_deposit` (WF-A: 正向繳款，Core + CC 兩階段，LIFO 補償)
- `operationType=B` → 委派給 `repayment_cash_cancellation` (WF-B: 反向取消，先 Lookup 再反向 Core + CC)

Parent 職責 (BR-P01~P06): 輸入驗證、冪等性檢查、Dispatcher 路由、統一 AuditLog 落地、統一回應格式、告警治理。

---

## §2 輸入輸出

### §2.1 Input schema

見 `notebooks/internal/omni-cash-transaction-api.yaml` 的 `OmniCashTransactionInput` schema (SSOT)。

關鍵欄位約束 (Step 7.16 + 7.22):
- `paymentSourceCode`: minLength=1, maxLength=5 (涵蓋真實範例 `2500P`)
- `amount`: pattern `^(FAIL_[A-Z0-9_]+|[0-9]{1,22})$` (放寬至 22 碼涵蓋實況 10 碼 + FAIL_* 前綴)
- `sequenceNumber`: maxLength=30 (涵蓋 `A123456789 (10) + 0000015061655 (13) = 23 碼` 實況)
- `originalSequenceNumber`: 條件必填 (僅 operationType=B)

### §2.2 Output schema

見 `OmniCashTransactionOutput` schema。包含 12 個對外狀態 (見 §2.3) + 完整 result sub-object (含 coreResult/ccResult/coreCancelResult/ccCancelResult)。

### §2.3 finalStatus 對映表 (Step 1c 新 convention)

| finalStatus | HTTP code | status (int) | 業務場景 | workflow 來源 |
|---|---|---|---|---|
| SUCCESS | 200 | 0 | 兩階段都成功 | WF-A |
| FAILED | 200 | 1 | 業務失敗短路 (Core 拒絕) | WF-A |
| ROLLED_BACK | 200 | 0 | CC 失敗但 Core 補償成功 | WF-A |
| ROLLBACK_FAILED | 409 | 1 | CC 失敗且 Core 補償也失敗 | WF-A |
| CANCELLED | 200 | 0 | 取消流程成功 | WF-B |
| CANCEL_REJECTED | 200 | 1 | 預檢不通過 (非 SUCCESS 或已取消) | WF-B |
| CANCEL_FAILED | 200 | 1 | 取消 Core 階段失敗 | WF-B |
| CANCEL_ROLLED_BACK | 200 | 0 | 取消 CC 失敗但自身 Core 補償成功 | WF-B |
| CANCEL_ROLLBACK_FAILED | 409 | 1 | 取消補償失敗 | WF-B |
| REJECTED_VALIDATION | 400 | 1 | 輸入驗證失敗 | Parent |
| LOOKUP_FAILED | 500 | 1 | 取消時找不到原 transaction | Parent |
| IDEMPOTENT_REPLAY | 200 | 0 | Parent 級冪等命中 | Parent |

---

## §3 Workflow 結構

- **Parent**: `omni_cash_transaction` (見 `spec/parent-workflow.sw.yaml`)
- **Child A**: `repayment_cash_deposit` (見 `spec/child-deposit.sw.yaml`)
- **Child B**: `repayment_cash_cancellation` (見 `spec/child-cancellation.sw.yaml`)

三個 workflow YAML 共用同一 `MyOpenApiService` / `AuditLogService` / `OpsAlertService`，Parent 額外引用 `IdempotencyService` (H13)。

---

## §4 資料庫 migration (Step 4d V 編號遞增)

`spec/db/V1.2.0__create_view_omni_cash_transaction_reconciliation.sql` — 從既有最大 V 編號 (假設 V1.1.0) 自動遞增為 V1.2.0。

View 涵蓋 3 個 workflow id (snake_case) 並建立 `idx_workflow_execution_log_workflow_id` + `idx_workflow_execution_log_sequence_number` 索引。

---

## §5 組態 (Step 8 整合前置產出物)

見 `spec/config/application.properties.snippet`，含:
1. **status-rewrite**: 7 個 finalStatus → HTTP code mapping (REJECTED_VALIDATION=400, LOOKUP_FAILED=500, ROLLBACK_FAILED=409, CANCEL_ROLLBACK_FAILED=409 等)
2. **function bean 綁定**: `%dev` + `%prod` 雙環境顯式綁定 `idempotencyService` / `auditLogService` / `opsAlertService`
3. **baseUrl fallback 鏈**: `%dev.callApiViaOpenAPI.base_url=http://localhost:8080` (mock 容器)；`%prod` 為真實主機
4. **動態路由**: `platform.openapi.router.auto-register=true` 自動掃描 `specs/internal/*.yaml` 的 `x-workflow-id` 標籤

---

## §6 測試 (Step 7.12 + 7.13 + 7.17)

`spec/tests/OmniCashTransactionWorkflowTest.java` 為 @QuarkusTest 範本，涵蓋 5 個核心場景:

| # | 場景 | 預期 finalStatus | HTTP | 關鍵斷言 |
|---|---|---|---|---|
| **P1** | operationType=C (無效) | REJECTED_VALIDATION | 400 | 入庫前攔截，audit 仍落地 (H7) |
| **A1** | 正常繳款 SUCCESS | SUCCESS | 200 | status=0, coreResult/ccResult.trackId 都有值 |
| **P4** | 同 seq 重送 | 第二次 IDEMPOTENT_REPLAY | 200 | 沒有重複呼叫主機 |
| **B1** | 原 SUCCESS 取消 | CANCELLED | 200 | status=0, cancelledBy 有值 (view 防污染查詢) |
| **B2** | 找不到原交易 | LOOKUP_FAILED | 500 | 未入庫 |

測試資料規範 (Step 7.17):
- 正向/反向用 `System.nanoTime()` 動態唯一序號
- 固定值僅 P1 (REJECTED_VALIDATION 未入庫) 與 B2 (LOOKUP_FAILED 未入庫) 允許

---

## §7 已知限制 / 簡化

- **B4 重複取消 idempotency**: markOriginalCancelled 用 `WHERE cancelled_by IS NULL` 保護，支援並發 (BR-302)
- **A4/A5/B5/B6/B7 細粒度測試空殼**:FAIL_AMT / FAIL_500 / RBFAIL 等 sentinel 已實作於 mock，可延伸
- **業務書命名為 hyphen 風格 (omni-cash-transaction)**,整合後實際為 snake_case (omni_cash_transaction) — Kogito 10.2.0 bug 規避
- **paymentSourceCode=2500P 為 5 碼**,與傳統 enum (J/K/P/I/A/E) 不衝突，已放寬 maxLength

---

## §8 Project Mapping Manifest (Step 7.14 — 檔名-id Manifest + 雙模組路徑)

| Draft 檔案 | id / 內容 | 正式專案路徑 (project-0825-pd 雙模組) |
|---|---|---|
| `spec/parent-workflow.sw.yaml` | `id: omni_cash_transaction` | `domain-transfer/transfer-workflow/src/main/resources/omni_cash_transaction.sw.yaml` + `distribution/transfer-app/src/main/resources/omni_cash_transaction.sw.yaml` (鏡像) |
| `spec/child-deposit.sw.yaml` | `id: repayment_cash_deposit` | `domain-transfer/transfer-workflow/src/main/resources/repayment_cash_deposit.sw.yaml` + 鏡像 |
| `spec/child-cancellation.sw.yaml` | `id: repayment_cash_cancellation` | `domain-transfer/transfer-workflow/src/main/resources/repayment_cash_cancellation.sw.yaml` + 鏡像 |
| `notebooks/internal/omni-cash-transaction-api.yaml` | 含 `x-workflow-id: omni_cash_transaction` | `domain-transfer/transfer-workflow/src/main/resources/specs/internal/omni-cash-transaction-api.yaml` + 鏡像 |
| `notebooks/external/core-account-cash-deposit-api.yaml` | 無 x-workflow-id (Step 6.9) | `domain-transfer/transfer-workflow/src/main/resources/specs/external/core-account-cash-deposit-api.yaml` + 鏡像 |
| `notebooks/external/credit-card-repayment-api.yaml` | 無 x-workflow-id (Step 6.9) | `domain-transfer/transfer-workflow/src/main/resources/specs/external/credit-card-repayment-api.yaml` + 鏡像 |
| `spec/services/IdempotencyService.java` | H13 新建 | `domain-transfer/transfer-workflow/src/main/java/com/example/platform/distribution/transfer/IdempotencyService.java` |
| `spec/services/AuditLogServiceExtension.java` | H6+H14 擴充 | 合併至 `domain-reconciliation/reconciliation-api/src/main/java/com/example/platform/reconciliation/AuditLogService.java` |
| `spec/services/OmniCashBusinessRuleValidator.java` | H13a 新建 | `domain-security/security-api/src/main/java/com/example/platform/security/OmniCashBusinessRuleValidator.java` |
| `spec/mocks/*.java` | Mode A sentinel | `dev/transfer-mock/src/main/java/org/acme/transfer/api/` |
| `spec/db/V1.2.0__*.sql` | View DDL | `domain-reconciliation/reconciliation-api/src/main/resources/db/migration/` |
| `spec/config/application.properties.snippet` | status-rewrite + bean + baseUrl | 合併到 `distribution/transfer-app/src/main/resources/application.properties` |
| `spec/tests/OmniCashTransactionWorkflowTest.java` | @QuarkusTest 5 場 | `distribution/transfer-app/src/test/java/com/example/platform/distribution/transfer/` |

---

## §9 已知限制 (Step 7.15)

詳見 §7。額外補充:

- **9.1**: 業務書 v2.2 §13 待開放問題 7 項 (sequenceNumber 長度、取消時間窗、originalSequenceNumber 唯一性 等) 需業務方 / API owner 確認，本 draft 採現行最嚴格假設 (22 字元 + 當日 + 全域唯一)
- **9.2**: 主機端是否提供「依 seq 查狀態」端點未知 (業務書 §11.2 T4)，影響未知狀態查詢流程 (業務書 §9.3)，本 draft 未實作
- **9.3**: paymentSourceCode 複合碼 (如 2500P) 與單碼 enum 共存，已放寬 maxLength=5，後續業務方可改為獨立 enum

---

## §10 9 項平台相容性預檢結果 (Step 6)

| # | 檢查項 | 結果 | 說明 |
|---|---|---|---|
| 6.1 | Workflow ID 命名 | ✅ PASS | 三個 workflow id 全為 snake_case (`omni_cash_transaction`, `repayment_cash_deposit`, `repayment_cash_cancellation`)，皆含 subFlowRef |
| 6.2 | actionDataFilter 結構 (頂層欄位) | ✅ PASS | grep `\.result\.X` 在 workflow YAML 中找不到配對 |
| 6.3 | Path Parameter 自動注入 | ✅ PASS | `creditcardid: '${ .partyId }'` 已在 CallCoreForward/CallCCForward/CancelCore/CancelCC 顯式提供 |
| 6.4 | stateDataFilter.output convention | ✅ PASS | Parent 用 `status (int 0/1) + finalStatus (string)`；Child 僅 `finalStatus` |
| 6.5 | YAML 語法嚴格性 | ✅ PASS | grep 不到 `^\s+\w+:\s+'.*',$` 形式的 trailing comma |
| 6.6 | Mock sentinel vs input validation | ✅ PASS | amount regex `^(FAIL_[A-Z0-9_]+|[0-9]{1,22})$` 已允許 FAIL_* 前綴；validator FAIL_ 豁免；workflow switch 用 `tonumber?` 守衛 |
| 6.7 | OpenAPI spec Schema/Example 一致性 | ✅ PASS | maxLength/minLength/pattern 與 example 與真實序號 (`A1234567890000015061655` 23 碼) 100% 相容 |
| 6.8 | toStateData 完整性 | ✅ PASS | 所有直調 `functionRef` 均含 `toStateData` (Step 6.8)；subFlowRef 與 terminal recordAuditLog 依規則豁免 |
| 6.9 | internal/external 嚴格二分 | ✅ PASS | `notebooks/internal/omni-cash-transaction-api.yaml` 含 `x-workflow-id: omni_cash_transaction`；external 2 個 host spec 零標籤；root `notebooks/*.yaml` 不存在業務檔 |
| 6.10 | subFlowRef version 對齊 | ✅ PASS | Parent 1.0.1 ↔ Child A 1.0.1 ↔ Child B 1.0.1 |

---

## §11 25+1 項自我檢查結果 (Step 7)

| # | 檢查項 | 結果 |
|---|---|---|
| 7.1 | spec.md §0 含 FQCN 假設 (含 H13a validator + H13b/H14 service) | ✅ H6/H13/H13a/H14 全標註 |
| 7.2 | spec.md §0 含 id 命名決策 (含檔名-id Manifest) | ✅ H12 + §8 Manifest |
| 7.3 | spec.md §0 含 convention 決策 | ✅ H16 (Parent 新 + Child finalStatus) |
| 7.4 | OpenAPI path param 與 workflow payload 對應 | ✅ `creditcardid` 在 4 處直調 payload 都有 |
| 7.5 | 直調 actionDataFilter 全部用頂層欄位 | ✅ grep `\.result\.X` 零配對 |
| 7.6 | stateDataFilter.output convention 對齊 | ✅ Parent 用 int+string；Child 僅 finalStatus |
| 7.7 | Mock sentinel 過 input validation | ✅ Mode A + validator FAIL_ 豁免；RBFAIL 用 sequenceNumber 前綴不影響 amount regex |
| 7.8 | Mock package 命名 | ✅ 直接對齊 `org.acme.transfer.api` (Step 5a) |
| 7.9 | SQL migration V 編號遞增 | ✅ V1.2.0 (從既有最大 +1) |
| 7.10 | YAML 無 trailing comma | ✅ grep 零命中 |
| 7.11 | application.properties.snippet 含 status-rewrite + %dev/%prod bean + baseUrl 註解 | ✅ §5 + config snippet 三者齊全 |
| 7.12 | 測試套件含 happy path + error path (P1/A1/P4/B1/B2) | ✅ 5 場全到位 |
| 7.13 | 測試資料字串過 input validation | ✅ amount 全為合法 (純數字或 FAIL_AMT) |
| 7.14 | spec.md §8 Project Mapping Manifest 完整 | ✅ 13 個檔案路徑 + 檔名-id Manifest |
| 7.15 | spec.md §9 已知限制有列 | ✅ §7 + §9 (含業務書 §13 待確認) |
| 7.16 | Input Validation Regex 與 API Sample 相容 | ✅ `2500P` 5 碼 (maxLength=5)；`0000011758` 10 碼 (maxLength=22) |
| 7.17 | 測試案例用動態 nanoTime 序號 | ✅ A1/P4/B1 用 nanoTime；P1/B2 固定值僅限未入庫路徑 |
| 7.18 | jq `tonumber` 防呆 | ✅ 所有 switch 用 `tonumber? // 1` + `startswith("FAIL_") | not` 守衛 |
| 7.19 | Workflow Root 顯式定義 `start:` | ✅ parent: ValidateInput; child-deposit: CallCoreForward; child-cancellation: CancelCore |
| 7.20 | Service Function 參數鍵值精準對齊 Java 簽名 | ✅ `sequenceNumber`/`workflowId`/`cancelledBy` 三入口覆蓋 |
| 7.21 | OpenAPI spec `servers[0].url` | ✅ 三份 spec 全填 |
| 7.22 | OpenAPI 欄位約束與 example 嚴格相容 | ✅ `sequenceNumber` 23 碼 ⊂ maxLength=30；`amount` 10 碼 ⊂ maxLength=22 |
| 7.23 | 直調 operation results 顯式宣告 toStateData | ✅ 所有直調 (含 checkIdempotency/lookupOriginal/CallCore/CallCC/RollbackCore) 都含 |
| 7.24 | 金融工作流程輸入驗證避免原生 dataInputSchema | ✅ 採 OpenApiSchemaValidator 三件套 (ValidateInput/CheckValidation/InjectValidationFailed/FinalAuditAndEnd) |
| 7.25 | Parent 對外入口置於 internal 且含 x-workflow-id | ✅ `omni-cash-transaction-api.yaml` post 含 `x-workflow-id: omni_cash_transaction` |
| 7.26 | subFlowRef version 對齊 child version | ✅ 全 1.0.1 |
