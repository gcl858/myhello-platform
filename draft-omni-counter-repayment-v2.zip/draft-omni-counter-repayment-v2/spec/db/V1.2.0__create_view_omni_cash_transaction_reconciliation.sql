-- V1.2.0:為 omni_cash_transaction workflow 新增對帳 view
-- 從既有最大 V 編號 +1 (假設既有最大 V1.1.0,新建立 V1.2.0)
-- Step 4d:版本號自動探測 + 遞增
-- ⭐ Step 6.1 + Step 6.6:WHERE clause 必須用最終 workflow id (snake_case,非 hyphen)

CREATE VIEW IF NOT EXISTS vw_omni_cash_transaction_reconciliation AS
SELECT
    workflow_id,
    sequence_number,
    final_status,
    json_extract(input_data, '$.partyId') AS party_id,
    json_extract(input_data, '$.branchCode') AS branch_code,
    json_extract(input_data, '$.operationType') AS operation_type,
    json_extract(input_data, '$.amount') AS amount,
    json_extract(input_data, '$.originalSequenceNumber') AS original_sequence,
    cancelled_by,
    cancelled_at,
    created_at,
    updated_at
FROM workflow_execution_log
WHERE workflow_id IN (
    'omni_cash_transaction',         -- ⭐ snake_case (對應 workflow id)
    'repayment_cash_deposit',
    'repayment_cash_cancellation'
);

CREATE INDEX IF NOT EXISTS idx_workflow_execution_log_workflow_id
    ON workflow_execution_log(workflow_id);
CREATE INDEX IF NOT EXISTS idx_workflow_execution_log_sequence_number
    ON workflow_execution_log(sequence_number);
