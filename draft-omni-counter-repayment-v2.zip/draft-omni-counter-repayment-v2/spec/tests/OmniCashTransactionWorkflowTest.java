// @QuarkusTest 範本
// 展示 Step 7.12 (5 場 P1/A1/P4/B1/B2) + Step 7.13 (payload 過 validation) +
//        Step 7.17 (動態 nanoTime 序號) + view 防污染查詢
//
// ⭐ Step 7.13 重要:測試 payload 的 amount 必須 ^[0-9]+$ 或 FAIL_AMT/FAIL_CC/RBFAIL (validator 已豁免 FAIL_*)
// ⭐ Step 7.17:正向/反向用 nanoTime,僅 P1 (400 不入庫) 與 B2 (LOOKUP_FAILED 未入庫) 可用固定值

package com.example.platform.distribution.transfer;

import io.quarkus.test.junit.QuarkusTest;
import io.restassured.http.ContentType;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;

import javax.sql.DataSource;
import jakarta.inject.Inject;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.UUID;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.*;

@QuarkusTest
@DisplayName("Omni Cash Transaction Parent Workflow E2E")
class OmniCashTransactionWorkflowTest {

    private static final String PARENT_URL = "/omni_cash_transaction";

    @Inject
    DataSource dataSource;

    // ─── P1:輸入驗證失敗 (REJECTED_VALIDATION,400) ───
    @Test
    @DisplayName("P1:operationType=C 無效值 → 400 REJECTED_VALIDATION")
    void test_invalidOperationType() {
        given()
            .contentType(ContentType.JSON)
            .body("""
                {
                  "operationType": "C",
                  "partyId": "A123456789",
                  "branchCode": "070",
                  "transactionDate": "20260805",
                  "transactionDateTime": "15061655",
                  "postingDayType": "A",
                  "postingDate": "20260805",
                  "paymentSourceCode": "2500P",
                  "amount": "0000011758",
                  "sequenceNumber": "SEQ_P1_STATIC"
                }
                """)
            .when().post(PARENT_URL)
            .then()
                .statusCode(400)
                .body("finalStatus", equalTo("REJECTED_VALIDATION"));
    }

    // ─── A1:正常 SUCCESS (新 convention:status=0 + finalStatus=SUCCESS) ───
    @Test
    @DisplayName("A1:正常繳款 SUCCESS (200)")
    void test_happyPath() {
        long seq = System.nanoTime();
        given()
            .contentType(ContentType.JSON)
            .body(String.format("""
                {
                  "operationType": "A",
                  "partyId": "A123456789",
                  "branchCode": "070",
                  "transactionDate": "20260805",
                  "transactionDateTime": "15061655",
                  "postingDayType": "A",
                  "postingDate": "20260805",
                  "paymentSourceCode": "2500P",
                  "amount": "0000011758",
                  "sequenceNumber": "SEQ_A1_%d"
                }
                """, seq))
            .when().post(PARENT_URL)
            .then()
                .statusCode(200)
                .body("status", equalTo(0))
                .body("finalStatus", equalTo("SUCCESS"))
                .body("workflow", equalTo("REPAYMENT"))
                .body("result.coreResult.trackId", notNullValue())
                .body("result.ccResult.trackId", notNullValue());
    }

    // ─── P4:Parent 級冪等 (重送同 sequenceNumber) ───
    @Test
    @DisplayName("P4:同 sequenceNumber 重送 → 第二次 IDEMPOTENT_REPLAY")
    void test_idempotency() {
        long seq = System.nanoTime();
        String body = String.format("""
            {
              "operationType": "A",
              "partyId": "A123456789",
              "branchCode": "070",
              "transactionDate": "20260805",
              "transactionDateTime": "15061655",
              "postingDayType": "A",
              "postingDate": "20260805",
              "paymentSourceCode": "2500P",
              "amount": "0000011758",
              "sequenceNumber": "SEQ_P4_%d"
            }
            """, seq);

        // 第一次:SUCCESS
        given().contentType(ContentType.JSON).body(body)
            .when().post(PARENT_URL)
            .then().statusCode(200).body("finalStatus", equalTo("SUCCESS"));

        // 第二次:IDEMPOTENT_REPLAY
        given().contentType(ContentType.JSON).body(body)
            .when().post(PARENT_URL)
            .then().statusCode(200).body("finalStatus", equalTo("IDEMPOTENT_REPLAY"));
    }

    // ─── B1:正常取消 (CANCELLED,200) ───
    @Test
    @DisplayName("B1:原 SUCCESS 交易取消 → CANCELLED")
    void test_normalCancellation() throws Exception {
        long now = System.nanoTime();
        long origSeq = now;
        long cancelSeq = now + 1;

        // 先建立一筆 SUCCESS 交易 (供後續取消)
        given().contentType(ContentType.JSON).body(String.format("""
            {
              "operationType": "A",
              "partyId": "A123456789",
              "branchCode": "070",
              "transactionDate": "20260805",
              "transactionDateTime": "15061655",
              "postingDayType": "A",
              "postingDate": "20260805",
              "paymentSourceCode": "2500P",
              "amount": "0000011758",
              "sequenceNumber": "SEQ_B1_ORIG_%d"
            }
            """, origSeq))
            .when().post(PARENT_URL)
            .then().statusCode(200).body("finalStatus", equalTo("SUCCESS"));

        // 執行取消
        given().contentType(ContentType.JSON).body(String.format("""
            {
              "operationType": "B",
              "partyId": "A123456789",
              "branchCode": "070",
              "transactionDate": "20260805",
              "transactionDateTime": "16000000",
              "postingDayType": "A",
              "postingDate": "20260805",
              "paymentSourceCode": "2500P",
              "amount": "0000011758",
              "sequenceNumber": "SEQ_B1_CANCEL_%d",
              "originalSequenceNumber": "SEQ_B1_ORIG_%d"
            }
            """, cancelSeq, origSeq))
            .when().post(PARENT_URL)
            .then()
                .statusCode(200)
                .body("status", equalTo(0))
                .body("finalStatus", equalTo("CANCELLED"))
                .body("workflow", equalTo("CANCELLATION"));

        // view 防污染查詢:確認 cancelledBy 有值
        try (Connection c = dataSource.getConnection();
             PreparedStatement ps = c.prepareStatement(
                 "SELECT cancelled_by FROM workflow_execution_log WHERE sequence_number = ?")) {
            ps.setString(1, "SEQ_B1_ORIG_" + origSeq);
            try (ResultSet rs = ps.executeQuery()) {
                assert rs.next() : "原交易未入庫";
                assert rs.getString("cancelled_by") != null : "cancelled_by 未設定";
            }
        }
    }

    // ─── B2:原交易找不到 (LOOKUP_FAILED,500) ───
    @Test
    @DisplayName("B2:originalSequenceNumber 不存在 → LOOKUP_FAILED (500)")
    void test_lookupFailed() {
        given()
            .contentType(ContentType.JSON)
            .body(String.format("""
                {
                  "operationType": "B",
                  "partyId": "A123456789",
                  "branchCode": "070",
                  "transactionDate": "20260805",
                  "transactionDateTime": "16000000",
                  "postingDayType": "A",
                  "postingDate": "20260805",
                  "paymentSourceCode": "2500P",
                  "amount": "0000011758",
                  "sequenceNumber": "SEQ_B2_%d",
                  "originalSequenceNumber": "SEQ_DOES_NOT_EXIST_STATIC"
                }
                """, System.nanoTime()))
            .when().post(PARENT_URL)
            .then()
                .statusCode(500)
                .body("finalStatus", equalTo("LOOKUP_FAILED"));
    }

    // ─── Helper:產唯一 seq (Step 7.17) ───
    private static String uniqueSeq() {
        return "SEQ_" + System.nanoTime() + "_" + UUID.randomUUID().toString().substring(0, 8);
    }
}
