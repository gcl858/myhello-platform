// OmniCashBusinessRuleValidator — 新業務專屬 validator (對應 spec.md H13a FQCN 假設)
// draft 側佔位 package com.example.platform.security (沿用既有業務 package)
// 下游 sonataflow-integration Step 4 會將本檔落於
// domain-security/security-api/src/main/java/com/example/platform/security/OmniCashBusinessRuleValidator.java
//
// ⭐ Step 4c 說明:
//   新業務有「條件必填」(operationType=A/B 與 originalSequenceNumber 連動) 與「FAIL_ 哨兵剝離」需求,
//   必須新建 XxxBusinessRuleValidator implements BusinessRuleValidator 並在 OpenApiSchemaValidator dispatch 註冊。
//   否則 FAIL_* 業務失敗路徑會被 input validation 攔截,業務規則零覆蓋 (實況新 5 域即如此)。

package com.example.platform.security;

import com.fasterxml.jackson.databind.JsonNode;
import jakarta.enterprise.context.ApplicationScoped;

/**
 * Omni Cash Transaction 業務規則驗證器。
 * 處理:
 *  1. operationType=A → 不允許 originalSequenceNumber (BR-P03)
 *  2. operationType=B → 必填 originalSequenceNumber (BR-P03)
 *  3. FAIL_* 哨兵字串剝離 — 將 amount 還原為純數字部分,避免下游 tonumber 拋錯 (Step 7.18)
 */
@ApplicationScoped
public class OmniCashBusinessRuleValidator implements BusinessRuleValidator {

    @Override
    public String workflowId() {
        return "omni_cash_transaction";
    }

    @Override
    public ValidationResult validate(JsonNode input) {
        if (input == null || input.isNull()) {
            return ValidationResult.fail("EMPTY_INPUT", "input 不可為空");
        }
        JsonNode opType = input.get("operationType");
        JsonNode origSeq = input.get("originalSequenceNumber");
        if (opType == null || opType.isNull()) {
            return ValidationResult.fail("MISSING_OPERATION_TYPE", "operationType 必填");
        }
        String op = opType.asText();
        switch (op) {
            case "A":
                if (origSeq != null && !origSeq.isNull() && !origSeq.asText().isEmpty()) {
                    return ValidationResult.fail("UNEXPECTED_ORIG_SEQ",
                        "operationType=A 不可帶 originalSequenceNumber");
                }
                break;
            case "B":
                if (origSeq == null || origSeq.isNull() || origSeq.asText().isEmpty()) {
                    return ValidationResult.fail("MISSING_ORIG_SEQ",
                        "operationType=B 必填 originalSequenceNumber");
                }
                break;
            default:
                return ValidationResult.fail("INVALID_OPERATION_TYPE",
                    "operationType 僅允許 A 或 B,收到: " + op);
        }
        return ValidationResult.ok();
    }

    /**
     * 剝離 FAIL_* 哨兵前綴,還原為純數字 (Step 7.18)。
     * 若非 FAIL_* 前綴則原樣回傳。
     */
    public static String stripFailPrefix(String raw) {
        if (raw == null) return null;
        if (raw.startsWith("FAIL_")) {
            return raw.substring("FAIL_".length());
        }
        return raw;
    }
}
