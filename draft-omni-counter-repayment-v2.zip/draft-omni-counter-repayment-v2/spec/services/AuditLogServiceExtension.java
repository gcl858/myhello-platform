// AuditLogServiceExtension — 既有 service 擴充 (對應 spec.md H6 + H14 FQCN 假設)
// draft 側佔位 package com.example.platform.reconciliation (沿用既有業務 package)
// 下游 sonataflow-integration Step 4 會將本檔合併至既有
// domain-reconciliation/reconciliation-api/src/main/java/com/example/platform/reconciliation/AuditLogService.java
//
// ⭐ Step 4c 關鍵:
//   - findBySequenceNumber 與 markCancelledBy 都是「擴充」既有方法,不重造 service
//   - markCancelledBy 的 cancelled_by 必須為傳入參數,不可寫死 workflow_id (實況硬編碼為已知坑)

package com.example.platform.reconciliation;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Map;

/**
 * AuditLogService 擴充方法草稿。
 * 既有 saveLog / listByWorkflow / etc. 不在此處重複列出,僅補 findBySequenceNumber + markCancelledBy。
 */
@ApplicationScoped
public class AuditLogServiceExtension {

    private static final Logger LOG = LoggerFactory.getLogger(AuditLogServiceExtension.class);
    private static final ObjectMapper MAPPER = new ObjectMapper();

    @Inject
    DataSource dataSource;

    // ── H6:findBySequenceNumber (給 WF-B LookupOriginal) ──
    public JsonNode findBySequenceNumber(String sequenceNumber) {
        return doFindBySequenceNumber(sequenceNumber);
    }

    public JsonNode findBySequenceNumber(Map<String, Object> args) {
        Object seq = args != null ? args.get("sequenceNumber") : null;
        return doFindBySequenceNumber(seq != null ? seq.toString() : null);
    }

    public JsonNode findBySequenceNumber(JsonNode arguments) {
        if (arguments == null || arguments.isNull()) return MAPPER.createObjectNode().put("found", false);
        JsonNode n = arguments.get("sequenceNumber");
        return doFindBySequenceNumber(n != null && !n.isNull() ? n.asText() : null);
    }

    private JsonNode doFindBySequenceNumber(String sequenceNumber) {
        if (sequenceNumber == null || sequenceNumber.isEmpty()) {
            return MAPPER.createObjectNode().put("found", false);
        }
        final String sql = "SELECT track_id, final_status, cancelled_by FROM workflow_execution_log WHERE sequence_number = ? LIMIT 1";
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, sequenceNumber);
            try (ResultSet rs = ps.executeQuery()) {
                ObjectNode out = MAPPER.createObjectNode();
                if (rs.next()) {
                    out.put("found", true);
                    out.put("originalTrackId", rs.getString("track_id"));
                    out.put("originalStatus", rs.getString("final_status"));
                    out.put("originalCancelledBy", rs.getString("cancelled_by"));
                } else {
                    out.put("found", false);
                }
                return out;
            }
        } catch (Exception e) {
            LOG.error("AuditLogService.findBySequenceNumber failed for seq={}", sequenceNumber, e);
            return MAPPER.createObjectNode().put("found", false);
        }
    }

    // ── H14:markCancelledBy (給 WF-B MarkCancelled) ──
    // ⭐ workflow_id 必須參數化,不可寫死為 'repayment-cash-deposit'
    public JsonNode markCancelledBy(String sequenceNumber, String cancelledBy) {
        return doMarkCancelledBy(sequenceNumber, cancelledBy);
    }

    public JsonNode markCancelledBy(Map<String, Object> args) {
        Object seq = args != null ? args.get("sequenceNumber") : null;
        Object cby = args != null ? args.get("cancelledBy") : null;
        return doMarkCancelledBy(
            seq != null ? seq.toString() : null,
            cby != null ? cby.toString() : null
        );
    }

    public JsonNode markCancelledBy(JsonNode arguments) {
        if (arguments == null || arguments.isNull()) {
            return MAPPER.createObjectNode().put("marked", false);
        }
        JsonNode seq = arguments.get("sequenceNumber");
        JsonNode cby = arguments.get("cancelledBy");
        return doMarkCancelledBy(
            seq != null && !seq.isNull() ? seq.asText() : null,
            cby != null && !cby.isNull() ? cby.asText() : null
        );
    }

    private JsonNode doMarkCancelledBy(String sequenceNumber, String cancelledBy) {
        if (sequenceNumber == null || sequenceNumber.isEmpty()) {
            return MAPPER.createObjectNode().put("marked", false);
        }
        final String sql = "UPDATE workflow_execution_log SET cancelled_by = ?, cancelled_at = CURRENT_TIMESTAMP, final_status = 'CANCELLED' WHERE sequence_number = ? AND cancelled_by IS NULL";
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, cancelledBy != null ? cancelledBy : "unknown");
            ps.setString(2, sequenceNumber);
            int rows = ps.executeUpdate();
            ObjectNode out = MAPPER.createObjectNode();
            out.put("marked", rows > 0);
            out.put("cancelledBy", cancelledBy);
            out.put("sequenceNumber", sequenceNumber);
            return out;
        } catch (Exception e) {
            LOG.error("AuditLogService.markCancelledBy failed for seq={} cancelledBy={}", sequenceNumber, cancelledBy, e);
            return MAPPER.createObjectNode().put("marked", false);
        }
    }
}
