// IdempotencyService — 新建 (對應 spec.md H13 FQCN 假設)
// draft 側佔位 package com.example.platform.distribution.transfer (沿用既有業務 package)
// 下游 sonataflow-integration Step 4 會將本檔落於
// domain-transfer/transfer-workflow/src/main/java/com/example/platform/distribution/transfer/IdempotencyService.java

package com.example.platform.distribution.transfer;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Map;

/**
 * Parent 級冪等服務 (BR-502)。
 *
 * 職責:用 sequenceNumber 查 workflow_execution_log,
 *       若已有同 sequenceNumber 且 finalStatus 已寫入 → 回傳 idempotentReplay=true 與 priorResult。
 *
 * Step 4b 三入口覆蓋 (Kogito reflection):
 *  1. 展開參數版 — 鍵名對齊 YAML arguments.sequenceNumber
 *  2. Map 版 — 防 codegen 傳 Map
 *  3. JsonNode 版 — Kogito 預設 codegen
 */
@ApplicationScoped
public class IdempotencyService {

    private static final Logger LOG = LoggerFactory.getLogger(IdempotencyService.class);
    private static final ObjectMapper MAPPER = new ObjectMapper();

    @Inject
    DataSource dataSource;

    // 1. 展開參數版入口 — 鍵名 sequenceNumber 對齊 YAML arguments
    public JsonNode findBySequenceNumber(String sequenceNumber) {
        return doFindBySequenceNumber(sequenceNumber);
    }

    // 1b. Map 版入口 — 防 codegen 傳 Map
    public JsonNode findBySequenceNumber(Map<String, Object> args) {
        if (args == null) {
            return buildEmpty();
        }
        Object seq = args.get("sequenceNumber");
        return doFindBySequenceNumber(seq != null ? seq.toString() : null);
    }

    // 2. JsonNode 單參數版入口 — Kogito codegen 預設生成
    public JsonNode findBySequenceNumber(JsonNode arguments) {
        if (arguments == null || arguments.isNull()) {
            return buildEmpty();
        }
        JsonNode seqNode = arguments.get("sequenceNumber");
        return doFindBySequenceNumber(seqNode != null && !seqNode.isNull() ? seqNode.asText() : null);
    }

    private JsonNode doFindBySequenceNumber(String sequenceNumber) {
        if (sequenceNumber == null || sequenceNumber.isEmpty()) {
            return buildEmpty();
        }
        // SELECT final_status, track_id, output_json FROM workflow_execution_log WHERE sequence_number = ? LIMIT 1
        final String sql = "SELECT final_status, track_id, output_json FROM workflow_execution_log WHERE sequence_number = ? LIMIT 1";
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, sequenceNumber);
            try (ResultSet rs = ps.executeQuery()) {
                ObjectNode out = MAPPER.createObjectNode();
                if (rs.next()) {
                    out.put("idempotentReplay", true);
                    out.put("priorResult", rs.getString("track_id"));
                    out.put("priorFinalStatus", rs.getString("final_status"));
                    String outputJson = rs.getString("output_json");
                    if (outputJson != null) {
                        out.set("priorOutput", MAPPER.readTree(outputJson));
                    }
                    LOG.info("idempotent hit: seq={} priorFinalStatus={}", sequenceNumber, rs.getString("final_status"));
                } else {
                    out.put("idempotentReplay", false);
                }
                return out;
            }
        } catch (Exception e) {
            LOG.error("IdempotencyService failed for seq={}", sequenceNumber, e);
            ObjectNode out = MAPPER.createObjectNode();
            out.put("idempotentReplay", false);
            return out;
        }
    }

    private JsonNode buildEmpty() {
        ObjectNode out = MAPPER.createObjectNode();
        out.put("idempotentReplay", false);
        return out;
    }
}
