package org.acme.transfer.api.dto;

public class CreditCardRepaymentRequest {
    public String partyId;
    public String branchCode;
    public String amount;
    public String sequenceNumber;
    public String operationType;

    public static class CancelRequest {
        public String originalSequenceNumber;
        public String cancelReason;
    }
}
