package org.acme.transfer.api.dto;

public class CreditCardRepaymentResponse {
    public String code;
    public String message;
    public String trackId;
    public String sequenceNumber;

    public CreditCardRepaymentResponse() {}

    public CreditCardRepaymentResponse(String code, String message, String trackId, String sequenceNumber) {
        this.code = code;
        this.message = message;
        this.trackId = trackId;
        this.sequenceNumber = sequenceNumber;
    }
}
