package org.acme.transfer.api.dto;

public class CoreCashDepositRequest {
    public String partyId;
    public String branchCode;
    public String amount;
    public String sequenceNumber;
    public String operationType;

    public static class RollbackRequest {
        public String originalSequenceNumber;
        public String rollbackReason;
    }
}
