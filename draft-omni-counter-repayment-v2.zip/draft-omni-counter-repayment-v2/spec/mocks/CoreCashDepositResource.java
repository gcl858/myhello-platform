// Package 對齊既有 project-0825-pd 模組:org.acme.transfer.api (Step 5a 直接對齊,省下游 rename 工時)
// 下游 sonataflow-integration Step 5 確認位置 (dev/transfer-mock/src/main/java/org/acme/transfer/api/)

package org.acme.transfer.api;

import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import org.acme.transfer.api.dto.CoreCashDepositRequest;
import org.acme.transfer.api.dto.CoreCashDepositResponse;
import org.acme.transfer.api.dto.ErrorDetail;

import java.util.UUID;

/**
 * Mock resource:Core Account Cash Deposit (主機正向 + 反向)
 *
 * 展示 Step 5b「Mock Sentinel 模式 A (業務 payload 內字串前綴)」。
 * 設計決策:
 *   - amount 正向業務拒絕 sentinel = FAIL_AMT / 0000000000 (validator 已允許 FAIL_* regex)
 *   - amount 反向補償失敗 sentinel = RBFAIL (僅 operationType=B 且 seq startswith("RBFAIL"))
 *   - 系統錯誤 sentinel = amount = "FAIL_500" → 回 500
 */
@Path("/CoreAccount/{creditcardid}/CashDeposit")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class CoreCashDepositResource {

    @POST
    @Path("/Execute")
    public Response execute(@PathParam("creditcardid") String creditcardid,
                            CoreCashDepositRequest request) {
        // ── 系統錯誤 sentinel:FAIL_500 → 5xx 觸發自動沖正 (BR-102) ──
        if (request.amount != null && request.amount.startsWith("FAIL_500")) {
            return Response.status(500)
                    .entity(new ErrorDetail("E0500", "模擬主機系統錯誤", null))
                    .build();
        }
        // ── 業務拒絕 sentinel:FAIL_AMT → 業務 403, 不觸發補償 (BR-101) ──
        if (request.amount != null && request.amount.startsWith("FAIL_AMT")) {
            return Response.status(403)
                    .entity(new ErrorDetail("E0024", "金額不符", null))
                    .build();
        }
        // ── 反向補償失敗 sentinel (僅 operationType=B) ──
        if ("B".equals(request.operationType)
                && request.sequenceNumber != null
                && request.sequenceNumber.startsWith("RBFAIL")) {
            return Response.status(403)
                    .entity(new ErrorDetail("E0050", "回沖失敗", null))
                    .build();
        }
        // ── 正常成功 ──
        return Response.ok(new CoreCashDepositResponse(
                "100", "SUCCESS", UUID.randomUUID().toString(), request.sequenceNumber
        )).build();
    }

    @POST
    @Path("/Rollback")
    public Response rollback(@PathParam("creditcardid") String creditcardid,
                             CoreCashDepositRequest.RollbackRequest request) {
        // 回沖失敗 sentinel:rollbackReason=RBFAIL
        if ("RBFAIL".equals(request.rollbackReason)) {
            return Response.status(403)
                    .entity(new ErrorDetail("E0050", "回沖失敗", null))
                    .build();
        }
        return Response.ok(new CoreCashDepositResponse(
                "100", "ROLLBACK_SUCCESS", UUID.randomUUID().toString(), null
        )).build();
    }
}
