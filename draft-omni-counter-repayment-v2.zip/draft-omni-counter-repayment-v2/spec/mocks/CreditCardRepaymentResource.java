// Package 對齊既有 project-0825-pd 模組:org.acme.transfer.api
// 展示 Step 5b「Mock Sentinel 模式 A (業務 payload 內字串前綴)」應用於信用卡主機。

package org.acme.transfer.api;

import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import org.acme.transfer.api.dto.CreditCardRepaymentRequest;
import org.acme.transfer.api.dto.CreditCardRepaymentResponse;
import org.acme.transfer.api.dto.ErrorDetail;

import java.util.UUID;

@Path("/CreditCard/{creditcardid}/Repayment")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class CreditCardRepaymentResource {

    @POST
    @Path("/Execute")
    public Response execute(@PathParam("creditcardid") String creditcardid,
                            CreditCardRepaymentRequest request) {
        // ── 系統錯誤 sentinel:FAIL_CC_500 → 5xx 觸發 RollbackCore ──
        if (request.amount != null && request.amount.startsWith("FAIL_CC_500")) {
            return Response.status(500)
                    .entity(new ErrorDetail("E0500", "模擬信用卡主機錯誤", null))
                    .build();
        }
        // ── 業務拒絕 sentinel:FAIL_CC → 403, 觸發 RollbackCore ──
        if (request.amount != null && request.amount.startsWith("FAIL_CC")) {
            return Response.status(403)
                    .entity(new ErrorDetail("E0031", "信用卡還款拒絕", null))
                    .build();
        }
        return Response.ok(new CreditCardRepaymentResponse(
                "100", "SUCCESS", UUID.randomUUID().toString(), request.sequenceNumber
        )).build();
    }

    @POST
    @Path("/Cancel")
    public Response cancel(@PathParam("creditcardid") String creditcardid,
                           CreditCardRepaymentRequest.CancelRequest request) {
        // ── 取消失敗 sentinel:RBFAIL_CC → 403, 觸發 RollbackCancelCore ──
        if ("RBFAIL_CC".equals(request.cancelReason)) {
            return Response.status(403)
                    .entity(new ErrorDetail("E0051", "信用卡沖銷失敗", null))
                    .build();
        }
        return Response.ok(new CreditCardRepaymentResponse(
                "100", "CANCEL_SUCCESS", UUID.randomUUID().toString(), null
        )).build();
    }
}
