-- =====================================================================
-- Migration V1.2.0: 建立 Card Auth + Capture 信用卡流程專屬對帳視圖
-- 目標路徑: distribution/transfer-app/src/main/resources/db/migration/
-- =====================================================================

CREATE VIEW IF NOT EXISTS vw_card_auth_capture_reconciliation AS 
SELECT 
  id, 
  created_at, 
  workflow_id, 
  business_key, 
  process_instance_id, 
  status, 
  message, 
  json_extract(input_data, '$.merchantId') AS merchant_id, 
  json_extract(input_data, '$.cardToken')  AS card_token, 
  json_extract(input_data, '$.amount')     AS amount, 
  json_extract(input_data, '$.currency')   AS currency, 
  json_extract(output_data, '$.authResult.code')        AS auth_code, 
  json_extract(output_data, '$.authResult.authId')      AS auth_id, 
  json_extract(output_data, '$.captureResult.code')     AS capture_code, 
  json_extract(output_data, '$.captureResult.captureId') AS capture_id, 
  json_extract(output_data, '$.voidAuthResult.code')    AS void_auth_code, 
  json_extract(output_data, '$.auditSaved')             AS audit_saved, 
  json_extract(output_data, '$.opsAlertRaised')         AS ops_alert_raised 
FROM workflow_execution_log 
WHERE workflow_id = 'card-auth-capture';

