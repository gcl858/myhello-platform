---
workflow_id: card-auth-capture
draft: draft-card-auth-capture
stage: testing
version: 0.3.0
created: 2026-08-24
updated: 2026-08-25
---

# Card Auth + Capture — 規格文件

> 來源: draft-card-auth-capture/
> 部署目標: SonataFlow 10.2.0 / Quarkus 3.27.2 / Serverless Workflow v0.8
> 模式: saga-lifo
> 狀態: testing (交付物已齊備，準備晉升至正式專案 project-0825-pd)

---

## 0. 假設清單 (quick reference)

| # | 假設內容 | 為何假設 | 待確認問題 | 狀態 |
|---|---------|---------|-----------|------|
| H1 | 無 manual capture 模式, 授權成功立刻請款 | 對齊 saga2 無人工介入風格, 降低設計複雜度 | — | **已確認** |
| H2 | 請款失敗 → void 授權 (LIFO 單層回沖) | 三階段失敗鏈的標準金融語意 | 是否需要 partial capture? | **已確認** (全額回沖) |
| H3 | 結算 (settlement) 屬後台批次, workflow 跑到 capture 成功即 `SUCCESS` | 結算為商家端對帳流程, 不屬於持卡人交易路徑 | 結算失敗是否要再延伸狀態? | **已確認** |
| H4 | 無 partial capture, 全成功或全失敗 | 簡化請款狀態, 符合大多數信用卡交易 | 是否需支援部分請款? | **已確認** |
| H5 | `currency` 限定 `TWD` / `USD` | 跨幣別屬另一 saga 場景 (可能用 FX lock state) | 是否需支援更多幣別? | **已確認** |
| H6 | `merchantId` 為英數字 `_` 組合 | 與 saga2 帳號驗證規則一致 | 是否需其他驗證 (如長度上限)? | **已確認** |
| H7 | OpenAPI 規格 (Auth / Capture) 為假設性 draft, 版本 `0.1.0-draft` | 需具體 API 規格才能調用 `callApiViaOpenAPI` | 用哪家 payment gateway?規格由誰提供? | **已確認** |
| H8 | Auth API 含 `executeAuth` + `voidAuth` 兩個 operation (同 spec); Capture API 為獨立 spec 一個 operation | 沿用 saga2 一個 spec 對應一組相關操作 | 是否要把 voidAuth 拆到獨立 spec? | **已確認** |
| H9 | void 測試哨兵: 當 authId 為 `"RBFAIL"` 時觸發 403 + code `401`, 驗證 `ROLLBACK_FAILED` 路徑 | 沿用 saga2 `RBFAIL` 哨兵慣例, 端到端測試 | 是否需要其他哨兵 (如「銀行超時」)? | **已確認** |
| H10 | capture 測試哨兵: 當 `amount = -1` 時觸發 403 + code `999`, 驗證 `ROLLED_BACK` 路徑 | 對稱設計, 讓兩條失敗鏈都有可重現的測試點 | — | **已確認** |
| H11 | `voidAuth` 的 `authId` 改放 request body (不走 path param) | 避免依賴未確認的 pathParams 支援, 改走保險做法 | MyOpenApiService 是否支援 pathParams? | **已確認** |

---

## 1. 概覽

- **一句話定位**: 信用卡交易的兩階段流程 (授權 + 請款)，請款失敗自動 void 授權回沖。
- **涉及 API**:
  - `card-auth-api.yaml#executeAuth` — 信用卡授權
  - `card-auth-api.yaml#voidAuth` — 授權 void (補償)
  - `card-capture-api.yaml#executeCapture` — 信用卡請款
- **業務觸發情境**: 用戶在電商/服務平台完成結帳，商家端觸發請款流程。

---

## 2. 輸入 / 輸出規格

### 2.1 輸入

| 欄位 | 型別 | 必填 | 驗證規則 | 說明 |
|---|---|---|---|---|
| `merchantId` | string | ✅ | `^[A-Za-z0-9_]+$` (非空) | 商家代號 |
| `cardToken` | string | ✅ | `^[A-Za-z0-9_-]{16,64}$` (非空) | 信用卡 token，避免儲存真實卡號 |
| `amount` | number | ✅ | `> 0` | 交易金額 (正數) |
| `currency` | string | ✅ | ∈ `{TWD, USD}` | ISO 4217 代碼，限定兩種 |

### 2.2 輸出

| 欄位 | 型別 | 必填 | 說明 |
|---|---|---|---|
| `status` | string | ✅ | `SUCCESS` / `FAILED` / `ROLLED_BACK` / `ROLLBACK_FAILED` / `VALIDATION_FAILED` |
| `message` | string | ✅ | 對應 finalStatus 的提示訊息 |
| `authResult` | object | ❌ | 授權 API 回應物件 (`code`, `message`, `authId`, `approvedAt`, `errorType`, `_httpStatus`) |
| `captureResult` | object | ❌ | 請款 API 回應物件 (`code`, `message`, `captureId`, `capturedAt`, `errorType`, `_httpStatus`) |
| `voidAuthResult` | object | ❌ | void API 回應物件 (同 `authResult` schema) |
| `auditSaved` | boolean | ✅ | 對帳紀錄寫入結果 (`saved: true/false`) |
| `opsAlertRaised` | boolean | ✅ | 運維告警觸發結果 (僅 `ROLLBACK_FAILED` 時為 `true`) |

### 2.3 status 與 HTTP 對應

| `finalStatus` | HTTP | 觸發情境 |
|---|---|---|
| `VALIDATION_FAILED` | 400 | 輸入欄位格式錯誤 |
| `FAILED` | 200 | 授權失敗 (無需補償) |
| `SUCCESS` | 200 | 兩階段皆成功 |
| `ROLLED_BACK` | 200 | 請款失敗, 授權 void 成功 |
| `ROLLBACK_FAILED` | 409 | void 授權失敗, 需人工介入 |

### 2.4 輸入契約檢核 (schemas/card-auth-capture-input-schema.json 雙向同步)

| Schema 定義 | ValidateInput jq 條件 | 說明 |
|---|---|---|
| `pattern: "^[A-Za-z0-9_]+$"` | `((.merchantId // "") \| match("^[A-Za-z0-9_]+$") // false) == false` | 商家代號格式驗證 |
| `pattern: "^[A-Za-z0-9_-]{16,64}$"` | `((.cardToken // "") \| match("^[A-Za-z0-9_-]{16,64}$") // false) == false` | 卡片 Token 長度與字元驗證 |
| `exclusiveMinimum: 0` | `.amount \| type != "number"` 或 `.amount <= 0` | 金額型別與正數驗證 |
| `enum: ["TWD", "USD"]` | `((.currency // "") as $c \| ($c == "TWD" or $c == "USD")) \| not` | 幣別列舉驗證 |

---

## 3. 狀態流程

### 3.1 流程圖 (Mermaid)

```mermaid
flowchart TD
    A[ValidateInput] -->|pass| B[CallAuth]
    A -->|fail| X1[InjectValidationFailedStatus]
    B --> C[CheckAuthResult]
    C -->|code=100| D[CallCapture]
    C -->|code!=100| Y1[InjectFailedStatus]
    D --> E[CheckCaptureResult]
    E -->|code=100| Z1[InjectSuccessStatus]
    E -->|code!=100| F[RollbackVoidAuth]
    F --> G[CheckVoidAuthResult]
    G -->|code=100| Y2[InjectRolledBackStatus]
    G -->|code!=100| Y3[InjectRollbackFailedStatus]
    X1 --> END[FinalAuditAndEnd]
    Y1 --> END
    Y2 --> END
    Y3 --> END
    Z1 --> END
```

### 3.2 state 表格

| name | type | 用途 | 失敗去向 |
|---|---|---|---|
| `ValidateInput` | switch | 輸入欄位驗證 (merchantId, cardToken, amount, currency) | `InjectValidationFailedStatus` |
| `CallAuth` | operation | 呼叫授權 API (透過 callApiViaOpenAPI) | onErrors → `InjectFailedStatus` |
| `CheckAuthResult` | switch | 檢查授權結果 code | `code!=100` → `InjectFailedStatus` |
| `CallCapture` | operation | 呼叫請款 API | onErrors → `RollbackVoidAuth` |
| `CheckCaptureResult` | switch | 檢查請款結果 code | `code!=100` → `RollbackVoidAuth` |
| `RollbackVoidAuth` | operation | void 授權 (補償呼叫) | onErrors → `InjectRollbackFailedStatus` |
| `CheckVoidAuthResult` | switch | 檢查 void 結果 | `code!=100` → `InjectRollbackFailedStatus` |
| `InjectValidationFailedStatus` | inject | 注入 `VALIDATION_FAILED` 終態資料 | `FinalAuditAndEnd` |
| `InjectFailedStatus` | inject | 注入 `FAILED` 終態資料 (授權失敗, 無補償) | `FinalAuditAndEnd` |
| `InjectSuccessStatus` | inject | 注入 `SUCCESS` 終態資料 | `FinalAuditAndEnd` |
| `InjectRolledBackStatus` | inject | 注入 `ROLLED_BACK` 終態資料 | `FinalAuditAndEnd` |
| `InjectRollbackFailedStatus` | inject | 注入 `ROLLBACK_FAILED` 終態資料 | `FinalAuditAndEnd` |
| `FinalAuditAndEnd` | operation | 統一終點: 寫 AuditLog + OpsAlert (若需) + 套用 output 模板 | end |

---

## 4. 錯誤處理、補償與對帳

- **錯誤分類與代碼**:
  - `platformError` (`PLATFORM_ERROR`): timeout / 引擎例外 / 服務未攔截例外 → 統一收斂至 `FinalAuditAndEnd`。
  - 業務 code: 由 `MyOpenApiService` 回傳，workflow 透過 switch 分流。
- **補償鏈 (LIFO)**:
  - `CallCapture` 失敗 / `code!=100` → `RollbackVoidAuth` (回沖授權)。
  - `RollbackVoidAuth` 失敗 → `InjectRollbackFailedStatus` (人工介入)。
- **AuditLog 觸發點**: 所有路徑收斂至 `FinalAuditAndEnd`，呼叫 `recordAuditLog` 寫入 `workflow_execution_log`。
- **OpsAlert 觸發點**: 僅 `status=ROLLBACK_FAILED` 時呼叫 `notifyOps`，輸出 `[OPS-ALERT]` 日誌通道。
- **對帳視圖 DDL**:
```sql
CREATE VIEW IF NOT EXISTS vw_card_auth_capture_reconciliation AS 
SELECT 
  id, created_at, workflow_id, business_key, process_instance_id, status, message,
  json_extract(input_data, '$.merchantId') AS merchant_id,
  json_extract(input_data, '$.cardToken')  AS card_token,
  json_extract(input_data, '$.amount')     AS amount,
  json_extract(input_data, '$.currency')   AS currency,
  json_extract(output_data, '$.authResult.code')        AS auth_code,
  json_extract(output_data, '$.authResult.authId')      AS auth_id,
  json_extract(output_data, '$.captureResult.code')     AS capture_code,
  json_extract(output_data, '$.captureResult.captureId') AS capture_id,
  json_extract(output_data, '$.voidAuthResult.code')    AS void_auth_code,
  json_extract(output_data, '$.auditSaved')             AS audit_saved,
  json_extract(output_data, '$.opsAlertRaised')         AS ops_alert_raised
FROM workflow_execution_log
WHERE workflow_id = 'card-auth-capture';
```

---

## 5. 平台整合

### 5.1 functions 引用 (真實平台 FQCN)

| function name | 對應 service | 用途 |
|---|---|---|
| `callApiViaOpenAPI` | `service:com.example.transfer.workflow.MyOpenApiService::callOpenApi` | 動態套用 OpenAPI spec 呼叫 API |
| `recordAuditLog` | `service:com.example.reconciliation.AuditLogService::saveLog` | 對帳紀錄寫入 |
| `notifyOps` | `service:com.example.reconciliation.OpsAlertService::raise` | 運維告警 (僅 ROLLBACK_FAILED 觸發) |

### 5.2 OpenAPI spec 引用

| spec | operationId | 用途 |
|---|---|---|
| `specs/card-auth-api.yaml#executeAuth` | 授權呼叫 (`EC=false`) | 取得授權 code 與 authId |
| `specs/card-auth-api.yaml#voidAuth` | 授權 void (補償, `EC=true`) | 請款失敗時回沖 |
| `specs/card-capture-api.yaml#executeCapture` | 請款呼叫 | 取得請款 code 與 captureId |

### 5.3 metadata 標籤

```yaml
metadata:
  domain: payment
  pattern: saga-lifo-compensation
  criticality: high
  owner: platform-team
```

### 5.4 平台組態片段 (application.properties.snippet)

```properties
platform.status-rewrite.workflows=saga2-transfer-workflow,card-auth-capture
platform.status-rewrite.mapping=VALIDATION_FAILED=400,ROLLBACK_FAILED=409
%dev.kogito.sw.functions.callApiViaOpenAPI.protocol=http
%dev.kogito.sw.functions.callApiViaOpenAPI.host=localhost
%dev.kogito.sw.functions.callApiViaOpenAPI.port=8080
```

---

## 6. 測試用例與斷言矩陣 (@QuarkusTest)

| # | 測試情境 | 測試輸入 (Payload) | 預期 HTTP | 預期 status | 關鍵欄位斷言 |
|---|---|---|---|---|---|
| 1 | 正常授權+請款成功 | `amount=100.0, currency="TWD"` | 200 | `SUCCESS` | `authResult.code="100"`, `captureResult.code="100"`, `opsAlertRaised=false` |
| 2 | 輸入驗證失敗 | `merchantId="", amount=-50` | **400** | `VALIDATION_FAILED` | `auditSaved=true`, `authResult=null` |
| 3 | 授權失敗短路 | `cardToken="FAIL_..."` | 200 | `FAILED` | `authResult.code="999"`, `captureResult=null` |
| 4 | 請款失敗回沖成功 | 哨兵 `amount=-1.0` | 200 | `ROLLED_BACK` | `captureResult.code="999"`, `voidAuthResult.code="100"` |
| 5 | 回沖失敗告警 | 哨兵 `authId="RBFAIL"` | **409** | `ROLLBACK_FAILED` | `voidAuthResult.code="401"`, `opsAlertRaised=true` |
| 6 | 對帳視圖驗證 | 查詢 SQLite View | - | - | `SELECT count(*) FROM vw_card_auth_capture_reconciliation` 命中 |

---

## 7. 參考文件清單

| 檔名 | mtime | size | 對應章節 | 變更狀態 |
|---|---|---|---|---|
| `notebooks/card-auth-api.yaml` | 2026-08-24 15:57:01 | 6162 | §5.2 | v0.1.0-draft |
| `notebooks/card-capture-api.yaml` | 2026-08-24 15:51:25 | 3400 | §5.2 | v0.1.0-draft |

---

## 8. 正式專案映射清單 (Project Mapping Manifest)

| Draft 產生物路徑 | 正式專案目標路徑 (project-0825-pd) | 說明 |
|---|---|---|
| `notebooks/card-auth-api.yaml` | `domain-transfer/transfer-workflow/src/main/resources/specs/` | OpenAPI 授權合約 |
| `notebooks/card-capture-api.yaml` | `domain-transfer/transfer-workflow/src/main/resources/specs/` | OpenAPI 請款合約 |
| `spec/card-auth-capture.sw.yaml` | `domain-transfer/transfer-workflow/src/main/resources/` | Canonical Workflow 定義 |
| `spec/schemas/card-auth-capture-input-schema.json` | `domain-transfer/transfer-workflow/src/main/resources/schemas/` | 輸入 Schema 契約 |
| `spec/config/application.properties.snippet` | `distribution/transfer-app/src/main/resources/application.properties` | 狀態碼改寫與路由註冊 |
| `spec/db/V1.2.0__create_view_card_auth_capture_reconciliation.sql` | `distribution/transfer-app/src/main/resources/db/migration/` | Flyway 對帳視圖 DDL |
| `spec/mocks/CardAuthResource.java.snippet` | `dev/transfer-mock/src/main/java/org/acme/transfer/api/` | 授權 JAX-RS Mock 端點 |
| `spec/mocks/CardCaptureResource.java.snippet` | `dev/transfer-mock/src/main/java/org/acme/transfer/api/` | 請款 JAX-RS Mock 端點 |
| `spec/mocks/dto/*.java.snippet` | `dev/transfer-mock/src/main/java/org/acme/transfer/api/dto/` | Mock Request / Response DTOs |
| `spec/tests/CardAuthCaptureWorkflowTest.java.snippet` | `distribution/transfer-app/src/test/java/com/example/platform/distribution/transfer/` | @QuarkusTest 整合測試 |

---

## 9. 版本與變更紀錄

| 版本 | 日期 | 變更 | 設計者 |
|---|---|---|---|
| 0.1.0 | 2026-08-24 | 初版，完成 design 階段，定義基本授權與請款流程 | Mavis(vibe) |
| 0.2.0 | 2026-08-24 | 拍板進 implementing；補齊 result object；產出初版 YAML 與 OpenAPI | Mavis(vibe) |
| 0.3.0 | 2026-08-25 | 升級為高適配交付目錄：校準真實 FQCN；補齊 JSON Schema、組態片段、對帳 View DDL、Mock Resource/DTO 與 @QuarkusTest 測試矩陣；建立正式專案映射清單 | Mavis(vibe) |
