# vibe-workflow-design Package

這個 zip 包含 **vibe-workflow-design skill** + 一個**完整走完的 draft 範例**(`draft-card-auth-capture`)。

---

## 內容結構

```
vibe-workflow-design-package/
├── README.md                                    # 本檔
├── .skills/
│   └── vibe-workflow-design/
│       └── SKILL.md                             # skill 本體(13KB)
└── draft-card-auth-capture/                     # draft 範例
    ├── notebooks/                               # 使用者/AI 共同輸入的原始資料
    │   ├── card-auth-api.yaml                   # 假設性 OpenAPI(Auth + Void)
    │   └── card-capture-api.yaml                # 假設性 OpenAPI(Capture)
    └── spec/                                    # AI 產出的設計文件
        ├── spec.md                              # 規格文件 v0.2.0(stage: implementing)
        └── card-auth-capture.sw.yaml            # 完整 workflow v0.1.0(13 states)
```

---

## Skill 怎麼用

`vibe-workflow-design` skill 是一個輔助設計 Serverless Workflow 的協作工具,使用方式:

### 1. 安裝

把 `.skills/vibe-workflow-design/SKILL.md` 放到你的 Mavis 專案的 `.skills/` 目錄下:

```
your-project/
└── .skills/
    └── vibe-workflow-design/
        └── SKILL.md
```

skill syncer 會在 session 結束時自動偵測並上傳。

### 2. 觸發

使用時必須在訊息中明確寫出 `vibe-workflow-design` 全名:

```
/vibe-workflow-design
```

或自然語句包含關鍵字:

```
幫我 vibe-workflow-design 一個新的轉帳流程
```

### 3. 設計對話節奏

每輪基本結構:

```
這輪規劃:[要做什麼]
預期改動:[哪些檔案/哪些段落]
→ 進行?
```

寫入前必須明確說「寫入」/「更新」/「同步到 spec」,預設 NO。

### 4. Guardrails(硬限制)

Skill 內建 3 類 guardrails,基於 saga2 v2.2.0 實作 + SOP + Ox_docs:

- **必用**:onErrors + errorRef、metadata、timeouts、jq null-safety、match() // false == false
- **不採用**:compensatedBy、dataInputSchema、end.terminate、events、retries、auth
- **技術限制**:jackson-jq 不支援 test(),需用 match() 迂迴

完整內容見 `SKILL.md`。

---

## Draft 範例怎麼用

`draft-card-auth-capture` 是用 skill 完整走過一遍的產出:

### 業務場景

信用卡交易兩階段流程(授權 + 請款),請款失敗自動 void 授權回沖。模式 `saga-lifo`。

### 生命週期

```
new → designing → spec-reviewing → implementing → testing → done → (promoted)
                                                  ↑ 你在這裡
```

### 已完成

- ✅ 第一輪 6 題釐清
- ✅ spec.md v0.2.0(7 章節 + 11 個 H# 假設)
- ✅ card-auth-capture.sw.yaml v0.1.0(13 states,對齊 saga2 風格)
- ✅ 假設性 OpenAPI 規格(含 RBFAIL / amount=-1 哨兵)

### 假設清單速覽(§0 完整版在 spec.md)

| #   | 假設                                   | 狀態    |
| --- | ------------------------------------ | ----- |
| H1  | 無 manual capture                     | ✅ 已確認 |
| H2  | 請款失敗 → void 授權(LIFO 單層)              | 待確認   |
| H3  | 結算屬後台批次                              | 待確認   |
| H4  | 無 partial capture                    | 待確認   |
| H5  | currency 限 TWD/USD                   | 待確認   |
| H6  | merchantId 為英數字底線                    | 待確認   |
| H7  | OpenAPI 為假設性 draft                   | 待確認   |
| H8  | Auth 含 executeAuth + voidAuth 同 spec | 待確認   |
| H9  | void 哨兵:authId="RBFAIL" → 401        | 待確認   |
| H10 | capture 哨兵:amount=-1 → 999           | 待確認   |
| H11 | voidAuth authId 放 body(不走 path)      | 待確認   |

---

## 配套討論結果(本次對話決定)

這些**只記在本次對話中,沒寫進 spec.md**。如果你要繼續做下去,以下是共識:

### 1. 配套 Java mock 模組(已設計,未實作)

```
mocks/
├── pom.xml
└── src/main/java/org/acme/mock/payment/
    ├── CardAuthResource.java
    ├── CardCaptureResource.java
    └── dto/
        ├── CardAuthRequest.java
        ├── CardVoidRequest.java
        ├── CardAuthResponse.java
        ├── CardCaptureRequest.java
        └── CardCaptureResponse.java

domain-payment/
├── pom.xml
└── payment-workflow/                  [merged: workflow + spec]
    ├── pom.xml
    └── src/main/resources/
        ├── card-auth-capture.sw.yaml  [從 draft 搬]
        └── specs/
            ├── card-auth-api.yaml     [從 draft/notebooks 搬]
            └── card-capture-api.yaml
```

**新架構核心**:

- spec + workflow 自含於 `payment-workflow/`(classpath 直接解析)
- Java mock 集中到 `mocks/<domain>/`(所有 domain 共享)
- mocks 不依賴 spec(只看 Java DTO)

# 
