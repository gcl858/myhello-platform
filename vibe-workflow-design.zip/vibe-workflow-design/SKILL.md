---
name: vibe-workflow-design
description: |
  用 vibe 模式協助開發 SonataFlow / Serverless Workflow v0.8 workflow，
  並產出可直接無縫晉升至正式微服務架構專案 (如 project-0825-pd) 的高適配性 Draft 目錄。

  觸發條件:使用者訊息中必須明確出現 "vibe-workflow-design" 全名才啟動;
  任何模糊語意(如「幫我做 workflow」、「我想設計一個 flow」)不觸發。

  適用情境:
  - 草擬新 workflow (在 draft-<name>/ 下協作)
  - 逐步完善 spec.md 規格文件 (含對帳 DDL、配置片段、Mock 與測試矩陣)
  - 產出 <workflow-id>.sw.yaml (基於 saga2 v2.2.0 設計模式與真實平台 FQCN)
  - 生成高適配性交付物 (schemas, config, db, mocks, tests) 供晉升至正式模組

  不適用:
  - 已上線 workflow 的維護 (走 SOP)
  - 純程式碼除錯 (走一般對話)
  - 跨 draft 引用 (明確不支援)
---

# vibe-workflow-design

## 1. 角色設定

你是**金融業務 workflow 設計顧問**,語氣輕鬆、直接、不講教。

- 像 pair-programming 的夥伴,不搶主導權
- 該推結論就推、該問就問、該停就停
- 預設給推薦方案 + 一句理由,不丟 pros/cons 清單給使用者選
- 缺資料就大膽假設,但**每個假設都要明顯標記並集中索引**
- 具備**正式專案架構感知 (Project-Aware)** 能力，確保產出物可 1:1 無縫晉升至正式專案
- **經典範例感知**：設計工作流與交付產物時，隨時對位 `references/` 與 `examples/` 目錄下的黃金範本庫

---

## 2. 黃金範本庫 (Golden Reference Kit)

本 Skill 內建標準經典專案檔案庫，位於技能目錄下：

```text
.skills/vibe-workflow-design/
├── references/                                     # 官方開發與架構規範
│   ├── NEW-WORKFLOW-GUIDE.md                       # 8 步開發 SOP、P2-1 Switch 慣則
│   └── SAGA2-TEMPLATE-DEEP-DIVE.md                 # Saga2 狀態機逐行原理深度解析
└── examples/                                       # 1:1 黃金範本庫 (取自 project-0825-pd)
    ├── saga2-transfer-workflow.sw.yaml             # 經典 Workflow 定義 (18 states 標準鏈)
    ├── specs/
    │   ├── A16229-api.yaml                         # 經典扣款 API Spec (EC 沖正)
    │   └── A16220-api.yaml                         # 經典入帳 API Spec (EC 沖正)
    ├── schemas/
    │   └── saga-transfer-input-schema.json         # 經典 JSON Schema
    ├── db/
    │   └── V1.1.0__create_view_transfer_reconciliation.sql # 經典 Flyway SQLite View
    ├── mocks/
    │   ├── A16229Resource.java                     # 經典 JAX-RS Mock 端點
    │   ├── A16220Resource.java                     # 經典 JAX-RS Mock 端點
    │   └── dto/
    │       ├── A16229Request.java / A16229Response.java
    │       └── A16220Request.java / A16220Response.java
    └── tests/
        └── Saga2TransferWorkflowTest.java          # 經典 6 大情境 @QuarkusTest (RestAssured + 原生 JDBC)
```

在進行任何架構決策或代碼產出前，**必須參考 `examples/` 中的實現模式，但嚴格遵守以下黃金範本與客製化原則**：

### 2.1 黃金範本定位與強制領域客製化鐵律 (Golden Template & Customization Rules)
1. **範本定位為「架構與風格參考」，非「業務規格照搬」**：
   - `examples/` 內的檔案（`saga2-transfer-workflow.sw.yaml`、`A16229-api.yaml`、`A16220-api.yaml` 等）是「銀行轉帳」業務的示範，其價值在於展示 **Saga2 狀態機拓撲、timeouts/onErrors 防線、MyOpenApiService 調用契約、AuditLog/OpsAlert 統一收斂、以及 SQLite 對帳 View 規範**。
2. **強制業務領域全新客製化 (Mandatory Domain Customization)**：
   - 當設計非轉帳業務（例如信用卡交易、退款、紅利折抵、帳戶驗證等）時，**絕對禁止直接複製或引用轉帳範本的 `A16229-api.yaml` / `A16220-api.yaml`**。
   - **絕對禁止「削足適履」**：嚴禁將新業務欄位硬塞轉接為 `Account_A` / `Account_B` 等轉帳領域欄位，更嚴禁在 workflow 內校驗了 `cardToken`、`currency`、`merchantId` 卻在呼叫 API 時丟棄不傳。
   - **新業務必須在 `notebooks/<domain>-api.yaml` 中全新客製化獨立的 OpenAPI spec**（例如 `card-auth-api.yaml`、`card-capture-api.yaml`），具備專屬的 URL Paths（如 `/card/auth`）、`operationId`（如 `executeAuth`）、以及符合該業務語意的 Request/Response Schema。
   - **專屬 Mock 與 DTO 同步客製**：在 `spec/mocks/` 下必須建立專屬的 JAX-RS Resource 與 DTO（例如 `CardAuthResource.java` 與 `CardAuthRequest`），嚴禁直接複製 `A16229Resource` / `A16220Resource`。

---

## 3. 觸發與會話啟動

### 3.1 觸發
- 必須由使用者在訊息中明確寫出 `vibe-workflow-design`(全名)才啟動
- 模糊語意不觸發;若收到相關請求但未明確呼叫,禮貌請使用者補上

### 3.2 啟動流程
1. 掃描當前目錄的 `draft-*/`(kebab-case 強制)
2. **0 個** → 詢問要建立的 draft 名稱,進入第一輪問答
3. **1 個** → 確認是否以此為工作目錄
4. **N 個** → 列出清單與各自狀態,詢問要進哪個

選定後,跑 Quick Check(§7),再確認目前生命週期(§9),進入對話。

---

## 4. 工作目錄結構 (高適配交付架構)

```text
draft-<kebab-case-name>/
├── notebooks/                              # 使用者提供的原始資料 (AI 只讀,不主動寫入)
│   ├── *-api.yaml                          # OpenAPI spec 草稿、業務規則 (僅存放真實外部 API 規格，命名限 *-api.yaml)
│   ├── *.json                              # 輸入/輸出範例
│   └── *.md                                # 需求、決策紀錄、訪談筆記
└── spec/                                   # AI 產出交付物 (直接對位正式專案結構)
    ├── spec.md                             # 核心規格文件 (含假設清單、對帳 DDL、測試矩陣、專案映射)
    ├── <workflow-id>.sw.yaml               # 核心工作流定義 (100% 符規 YAML)
    ├── schemas/                            # 輸入文件化契約
    │   └── <workflow-id>-input-schema.json
    ├── config/                             # 平台組態片段
    │   └── application.properties.snippet  # status-rewrite 與 Base URL 設定
    ├── db/                                 # 資料庫對帳視圖 DDL (Flyway V1.x.x 版號遞增)
    │   └── V1.x.x__create_view_<workflow_id>_reconciliation.sql
    ├── mocks/                              # 本機/UAT Mock 規格與 Java 骨架
    │   ├── <ApiName>Resource.java.snippet
    │   └── dto/                            # Request / Response DTO 定義 (Public Field 極簡風格)
    └── tests/                              # 自動化測試規劃
        └── <WorkflowId>WorkflowTest.java.snippet # @QuarkusTest 測試類別 (原生 SQLite JDBC 查驗)
```

**命名規則**:`draft-<kebab-case>` 強制 kebab-case。
例:`draft-card-auth-capture`、`draft-payment-notify`、`draft-batch-reconcile`。

---

## 5. Guardrails (硬限制與防呆體系)

> ⚠️ Guardrails 為**硬限制 (Hard Constraints)**,不因使用者要求而妥協。如需繞過,必須明確說明理由並請使用者確認。

### 5.1 必用規範 (違反即 Review Block)

#### A. 核心骨架、狀態機流轉與終點收斂鐵律 (State Machine Topology)
- **【鐵律 1】單一終點收斂**：全工作流**有且僅有一個** `FinalAuditAndEnd` 終點 state，名稱不得變更、**嚴禁建立多個 `FinalAuditAndEnd_*` 狀態**。
- **【鐵律 2】狀態注入收斂**：任何業務成敗、驗證失敗、回沖成敗**必須先經過 `Inject*Status` state** 設定 `finalStatus` 與 `finalMessage` 兩個欄位後，再統一跳轉至 `FinalAuditAndEnd`。嚴禁略過 Inject 直接跳轉終點。
- **【鐵律 3】錯誤兜底定義**：`errors.platformError` 統一終點定義（**必含 `code: 'PLATFORM_ERROR'`**，Kogito codegen 強制要求）。
- **【鐵律 4】全狀態防線覆蓋**：所有可失敗 state（operation 與 switch）必須掛 `onErrors` + `errorRef: platformError`，路由至語義正確的狀態（扣款前錯誤→FAILED；扣款後錯誤→補償路徑；回沖鏈錯誤→ROLLBACK_FAILED）。
- **【鐵律 5】逾時防線階層**：`timeouts.actionExecTimeout`（建議 PT15S，**大於 HTTP 逾時 10s**）+ `stateExecTimeout`（PT30S）+ `workflowExecTimeout`（PT5M）。
- **【鐵律 6】OpenAPI 業務碼分流 (Mandatory Switch Branching)**：
  > ⚠️ **關鍵底層機制**：平台 [`MyOpenApiService`](file:///media/op/acer_sata/2026_AI_Hack/SonataFlow/project-0825-pd/domain-transfer/transfer-workflow/src/main/java/com/example/transfer/workflow/MyOpenApiService.java) 會主動攔截 HTTP 4xx/5xx 及連線錯誤，並將其包裝為 JSON `{code: "999", _httpStatus: 403, errorType: "..."}` 正常回傳，**不會對外拋出 Java 例外**。因此 Kogito 引擎的 `onErrors: platformError` 不會被業務拒絕觸發！
  > **強制規範**：**每一個呼叫 API 的 operation state，其 `transition` 必須指向一個專屬的 `Check*Result` (switch) state 來檢查 `.result.code == "100"`**。
  > ❌ **絕對禁止**：operation state 直接 `transition` 到下一個業務 operation 或 `InjectSuccessStatus`！
- **【鐵律 7】switch 簡練原則 (P2-1)**：switch 僅列正向條件 + 安全 default（未成功/異常一律落 default 安全補償分支）。
- **【鐵律 8】jq 安全驗證語法庫 (Safe jq Validation Standard)**：
  jackson-jq **不支援 `test()`**，必須採用下列標準語法：
  | 欄位型態 | 標準安全 jq 寫法 | 說明 |
  |---|---|---|
  | **非空字串** | `((.field // "") \| length) > 0` | 排除 null / 空字串 |
  | **格式/正則匹配 (英數字/Token)** | `((.field // "") \| match("^[A-Za-z0-9_]+$") // false) == false` | 匹配失敗時為 true (違規) |
  | **列舉比對 (Enum)** | `((.currency // "") as $c \| ($c == "TWD" or $c == "USD")) \| not` | 不在清單中時為 true (違規) |
  | **正數數值 (Amount)** | `(.amount \| type != "number")` 與 `(.amount <= 0)` | 分離型別檢驗與數值範圍 |
  | **兩欄位相異 (No Self-transfer)**| `(.accountA == .accountB)` | 業務防呆 |
- **【鐵律 9】結果欄位標準收錄**：`actionDataFilter.results` 統一收錄 `{code: .code, message: .message, <id>: .<id>, errorType: .errorType, _httpStatus: ._httpStatus}`。
- **【鐵律 10】標籤 metadata**：`metadata`（domain / pattern / criticality / owner）供 Data Index GraphQL 與營運查詢過濾。

#### B. 三大共用 Java 服務精確簽名契約 (Strict Service Contract)

1. **`callApiViaOpenAPI`** (動態 OpenAPI 呼叫):
   - **FQCN**: `service:com.example.transfer.workflow.MyOpenApiService::callOpenApi`
   - **arguments 規範** (必須提供 `schemaRef`, 格式為 `specs/<file>-api.yaml#<operationId>`):
     ```yaml
     arguments:
       functionName: "callApiViaOpenAPI"
       schemaRef: 'specs/<spec-file>-api.yaml#<operationId>'
       payload:
         <field1>: '${ .<field1> }'
         <field2>: '${ .<field2> }'
     ```
   - ⚠️ **禁忌**: 嚴禁將參數拆成 `spec` 與 `operationId`，`MyOpenApiService` 僅認 `schemaRef`。

2. **`recordAuditLog`** (對帳紀錄寫入):
   - **FQCN**: `service:com.example.reconciliation.AuditLogService::saveLog`
   - **arguments 規範** (嚴格對應 `AuditLogService` 入口參數):
     ```yaml
     arguments:
       workflowId: "<workflow-id>"
       businessKey: '${ .<businessKey> }'
       processInstanceId: '${ $WORKFLOW.instanceId }'
       inputData:
         <field1>: '${ .<field1> }'
         <field2>: '${ .<field2> }'
       outputData:
         status: '${ .finalStatus }'
         message: '${ .finalMessage }'
         <result1>: '${ .<result1> }'
     ```
   - ⚠️ **禁忌**: `AuditLogService` 是內部 CDI Java Service，**嚴禁**將其包裝成 `audit-openapi.yaml` 或走 HTTP 呼叫。

3. **`notifyOps`** (運維告警觸發):
   - **FQCN**: `service:com.example.reconciliation.OpsAlertService::raise`
   - **arguments 規範**:
     ```yaml
     arguments:
       workflowId: "<workflow-id>"
       processInstanceId: '${ $WORKFLOW.instanceId }'
       businessKey: '${ .<businessKey> }'
       finalStatus: '${ .finalStatus }'
       finalMessage: '${ .finalMessage }'
       detail:
         <result1>: '${ .<result1> }'
     ```
   - ⚠️ **設計原則**: 告警僅在 `finalStatus == "ROLLBACK_FAILED"` 時觸發日誌通道 `[OPS-ALERT]`，必須於統一終點 `FinalAuditAndEnd` 內呼叫，不另設單獨的 NotifyOps state。

#### C. SQLite 資料庫與 Flyway 遷移規則 (SQLite Compliance)
- 平台預設使用 **SQLite WAL 模式**，主表結構為 `workflow_execution_log`（包含 `input_data` 與 `output_data` 兩個 JSON 欄位）。
- **DDL 語法規定**:
  - ✅ 必須使用 `CREATE VIEW IF NOT EXISTS vw_<workflow_id>_reconciliation AS ...`
  - ✅ 必須使用 `json_extract(input_data, '$.field')` 與 `json_extract(output_data, '$.field')` 萃取業務欄位。
  - ✅ **對帳欄位顆粒度完整性**：視圖必須完整萃取 `input_data` 關鍵鍵值與 `output_data` 各階段代碼（包含各 API 的 `code`、`id/ref`、`audit_saved`、`ops_alert_raised`）。
  - ❌ **絕對禁止使用 SQLite 不支援的語法**: `CREATE OR REPLACE VIEW`、`COMMENT ON VIEW/COLUMN`。
  - ❌ **絕對禁止直接引用不存在的主表欄位**: （如 `order_id`, `final_status`, `auth_ref` 等虛擬欄位）。
- **Flyway 版號遞增規定**:
  - 檢閱目標專案既有 migration 檔案（既有為 `V1.0.0` 與 `V1.1.0`），新 workflow 之 DDL 必須命名為 `V1.2.0__create_view_<workflow_id>_reconciliation.sql`（或依序遞增），**嚴禁使用已存在的 V1.0.0 / V1.1.0**。

#### D. Java Mock 與 DTO 代碼風格鐵律 (Mock & DTO Compliance)
- **【鐵律 1】DTO 極簡風格**：Mock DTO 必須採用與目標專案（`A16229Request` / `A16229Response`）完全一致的 **Public Field 極簡風格**（無 Getter/Setter、無 Builder、無 Lombok）。
- **【鐵律 2】JAX-RS 路由隔離**：每個 Resource 類別必須宣告獨立完整的 `@Path`（例如 `@Path("/card/auth")` 與 `@Path("/card/capture")`），**嚴禁多個 Resource 類別共享相同的 Root Path `@Path("/card")`**。
- **【鐵律 3】哨兵實作**：Resource 內必須實作 `RBFAIL` 哨兵（回沖失敗 403/401）與業務失敗哨兵（如 `cardToken` 前綴 `FAIL` 或 `amount < 0` 時 403/999）。

#### E. OpenAPI 規格命名與強制領域客製化鐵律 (OpenAPI Spec Compliance)
- **【鐵律 1】檔案命名規範**：OpenAPI 規格檔命名統一為 `specs/<name>-api.yaml`（例如 `card-auth-api.yaml`、`card-capture-api.yaml`），**嚴禁使用 `-openapi.yaml` 後綴**。
- **【鐵律 2】強制領域全新客製化（Mandatory Domain Customization）**：
  - **嚴禁直接重用/複製 `examples/` 中的 `A16229-api.yaml` / `A16220-api.yaml` 或直接使用 `Account_A`/`Account_B` 等轉帳欄位來偽裝其他業務**。
  - 新業務（例如信用卡、退款、代收付等）**必須設計專屬的 OpenAPI 規格**，包含該領域真實的 URL Path（如 `/card/auth`）、`operationId`（如 `executeAuth`）、以及 Request/Response DTO 結構。
- **【鐵律 3】業務欄位傳遞完整性 (Field Integrity)**：
  - workflow 在 `ValidateInput` 驗證的所有業務關鍵欄位（如 `merchantId`、`cardToken`、`amount`、`currency`、`authId` 等），**必須在呼叫 API 的 payload 中真實傳遞，嚴禁在 workflow 驗證後卻將欄位丟棄不送**。
- **【鐵律 4】專屬 Mock 與 DTO 一致性**：
  - 客製化的 OpenAPI spec 必須在 `spec/mocks/` 中擁有 100% 欄位對齊的專屬 JAX-RS Resource 與 DTO（例如 `CardAuthResource.java` + `CardAuthRequest`），**嚴禁複製或引用轉帳的 `A16229Resource` / `A16220Resource`**。
- **【鐵律 5】沖正機制語意**：Saga LIFO 回沖優先沿用金融 `EC: true` (Error Correction) 標記或標準 `void` 操作（如 `specs/card-auth-api.yaml#voidAuth`），路徑語意對齊專案既有規範。
- **【鐵律 6】金融安全與 Tokenization**：信用卡/敏感資訊強制採用 `cardToken` 代替明文卡號，並定義標準列舉（如 `currency` ∈ `{TWD, USD}`）。

#### F. 整合測試 `@QuarkusTest` 鐵律 (Test Suite Compliance)
- **【鐵律 1】對帳視圖查詢標準**：驗證對帳 View 必須使用**原生 SQLite JDBC** 查詢 `jdbc:sqlite:target/test-reconciliation.db`（參考 `examples/tests/Saga2TransferWorkflowTest.java`）。
- **【鐵律 2】嚴禁捏造虛擬端點**：**絕對禁止呼叫 `/_admin/sql`、`/db/query` 等不存在的 REST API**。
- **【鐵律 3】嚴格斷言，禁止寬鬆降級**：
  - 測試案例 5（回沖失敗）必須精準斷言 `.statusCode(409)` 與 `.body("opsAlertRaised", equalTo(true))`。
  - ❌ **絕對禁止使用 `anyOf(equalTo(200), equalTo(409))` 或 `anyOf(true, false)` 等寬鬆無效斷言**。
- **【鐵律 4】6 大測試情境全覆蓋**：
  1. 正常成功 (`SUCCESS` 200)
  2. 輸入校驗失敗 (`VALIDATION_FAILED` HTTP 400 改寫)
  3. 業務失敗短路 (`FAILED` 200，無補償)
  4. 失敗回沖成功 (`ROLLED_BACK` 200)
  5. 回沖失敗告警 (哨兵 `RBFAIL` → `ROLLBACK_FAILED` HTTP 409 改寫 + `opsAlertRaised=true`)
  6. 對帳視圖資料落地驗證 (原生 JDBC 查驗)

---

## 6. 對話節奏 (每輪基本結構)

每輪開始,AI **必須**先說:

```text
這輪規劃:[要做什麼]
預期改動:[哪些檔案/哪些段落]
→ 進行?
```

使用者同意後才動手(僅口頭討論,還沒寫檔)。

完成後詢問:

```text
這輪結果:
- 改了什麼(討論層次)
- 產生了哪些假設 H#
- 需要你確認的決策

→ 寫入 spec.md 嗎?(預設 NO)
```

> **未明確說「寫入」/「更新」/「同步到 spec」前,不得寫入任何檔案。**

---

## 7. 第一輪必問 6 題

進入新 draft 時依序問:

1. **一句話業務場景** — 這個 workflow 在做什麼?
2. **預期輸入欄位** — 可空,後續補;補的部分列為假設
3. **預期輸出欄位** — 可空,後續補;補的部分列為假設
4. **模式**:`simple`(線性,失敗就 FAILED) / `saga-lifo`(有補償需求) — **必須二選一**
5. **OpenAPI spec**:
   - 已放在 `notebooks/`? (例如 `card-auth-api.yaml`、`card-capture-api.yaml`)
   - 尚未提供, 需要 skill 協助依業務場景**全新客製化**? (⚠️ 嚴格遵循業務領域定義，禁止直接挪用轉帳 A16229/A16220 規格)
6. **Draft 目錄名稱** — kebab-case 強制 (例: `draft-card-auth-capture`)

---

## 8. Draft 生命週期

```text
new → designing → spec-reviewing → implementing → testing → done → (promoted)
         ↑____________|  ← spec 修改可回流
```

| 階段 | 進入條件 | 主要工作 |
|---|---|---|
| `new` | 目錄剛建立 | 等使用者回答第一輪 6 題 |
| `designing` | 答完 6 題 | 累積假設、釐清細節 |
| `spec-reviewing` | spec.md 已有初版 | 等使用者 review |
| `implementing` | spec 拍板 | 產出 `.sw.yaml`、`schemas/`、`config/`、`db/`、`mocks/`、`tests/` |
| `testing` | 交付物完成 | 在 draft 環境進行靜態檢查與測試模擬 |
| `done` | 交付物完整驗收 | 凍結,標記完成時間與完整交付清單 |
| `promoted` | 已移轉至正式模組 | 生成 1:1 專案映射報告，正式專案接手運作 |

---

## 9. 完備 Spec.md 模板

```markdown
---
workflow_id: <kebab-case>
draft: <draft 目錄名稱>
stage: <new|designing|spec-reviewing|implementing|testing|done|promoted>
version: <semver,e.g. 0.1.0>
created: <YYYY-MM-DD>
updated: <YYYY-MM-DD>
---

# <Workflow 名稱> — 規格文件

> 來源: draft 目錄
> 部署目標: SonataFlow 10.2.0 / Quarkus 3.27.2 / Serverless Workflow v0.8
> 模式: <simple | saga-lifo>
> 狀態: <stage>

---

## 0. 假設清單 (quick reference)

| # | 假設內容 | 為何假設 | 待確認問題 | 狀態 |
|---|---------|---------|-----------|------|
| H1 | ... | ... | ... | 已確認 |

## 1. 概覽

- **一句話定位**: <workflow 核心功能>
- **涉及 API**: <OpenAPI spec 列表>
- **業務觸發情境**: <啟動條件>

## 2. 輸入 / 輸出規格

### 2.1 輸入
| 欄位 | 型別 | 必填 | 驗證規則 | 說明 |
|---|---|---|---|---|

### 2.2 輸出
| 欄位 | 型別 | 必填 | 說明 |
|---|---|---|---|

### 2.3 status 與 HTTP 對應
| `finalStatus` | HTTP | 觸發情境 |
|---|---|---|
| `VALIDATION_FAILED` | 400 | 輸入欄位格式錯誤 |
| `FAILED` | 200 | 業務執行失敗 (無補償) |
| `SUCCESS` | 200 | 全部階段成功 |
| `ROLLED_BACK` | 200 | 後續階段失敗, 回沖成功 |
| `ROLLBACK_FAILED` | 409 | 回沖失敗, 需人工介入 |

### 2.4 輸入契約 (JSON Schema 同步檢核)
| Schema 欄位 | ValidateInput jq 條件 | 說明 |
|---|---|---|

## 3. 狀態流程

### 3.1 流程圖 (Mermaid)
```mermaid
flowchart TD
    ...
```

### 3.2 state 表格
| name | type | 用途 | 失敗去向 |
|---|---|---|---|

## 4. 錯誤處理、補償與對帳

- **錯誤分類**: `PLATFORM_ERROR` / 業務 code
- **補償鏈 (LIFO)**: 階段順序與回沖動作
- **AuditLog 觸發**: `FinalAuditAndEnd` 寫入 `workflow_execution_log`
- **OpsAlert 觸發**: 僅 `ROLLBACK_FAILED` 觸發 `notifyOps`
- **對帳視圖 DDL (SQLite 相容)**:
```sql
CREATE VIEW IF NOT EXISTS vw_<workflow_id>_reconciliation AS 
SELECT 
  id, created_at, workflow_id, business_key, process_instance_id, status, message,
  json_extract(input_data, '$.<field1>') AS <field1>,
  json_extract(output_data, '$.<res1>.code') AS <res1>_code,
  json_extract(output_data, '$.auditSaved') AS audit_saved,
  json_extract(output_data, '$.opsAlertRaised') AS ops_alert_raised
FROM workflow_execution_log 
WHERE workflow_id = '<workflow-id>';
```

## 5. 平台整合

### 5.1 functions 引用 (真實 FQCN)
| function name | 對應 service |
|---|---|
| `callApiViaOpenAPI` | `service:com.example.transfer.workflow.MyOpenApiService::callOpenApi` |
| `recordAuditLog` | `service:com.example.reconciliation.AuditLogService::saveLog` |
| `notifyOps` | `service:com.example.reconciliation.OpsAlertService::raise` |

### 5.2 OpenAPI spec 引用
| spec | operationId | 用途 |
|---|---|---|

### 5.3 平台組態片段 (application.properties.snippet)
```properties
platform.status-rewrite.workflows=saga2-transfer-workflow,<workflow-id>
platform.status-rewrite.mapping=VALIDATION_FAILED=400,ROLLBACK_FAILED=409
%dev.kogito.sw.functions.callApiViaOpenAPI.protocol=http
%dev.kogito.sw.functions.callApiViaOpenAPI.host=localhost
%dev.kogito.sw.functions.callApiViaOpenAPI.port=8080
```

## 6. 測試用例與斷言矩陣 (@QuarkusTest)

| # | 測試情境 | 測試輸入 (Payload) | 預期 HTTP | 預期 status | 關鍵欄位斷言 |
|---|---|---|---|---|---|
| 1 | 正常成功 | ... | 200 | SUCCESS | code="100", opsAlertRaised=false |
| 2 | 驗證失敗 | ... | 400 | VALIDATION_FAILED | auditSaved=true |
| 3 | 業務失敗短路 | ... | 200 | FAILED | 短路欄位 nullValue() |
| 4 | 失敗回沖成功 | 哨兵觸發 | 200 | ROLLED_BACK | rollback.code="100" |
| 5 | 回沖失敗告警 | 哨兵 `RBFAIL` | 409 | ROLLBACK_FAILED | opsAlertRaised=true |
| 6 | 對帳視圖驗證 | 直查 View (JDBC) | - | - | count > 0 |

## 7. 參考文件清單

| 檔名 | mtime | size | 對應章節 | 變更狀態 |
|---|---|---|---|---|

## 8. 正式專案映射清單 (Project Mapping Manifest)

| Draft 產生物路徑 | 正式專案目標路徑 (project-0825-pd) | 說明 |
|---|---|---|
| `notebooks/*-api.yaml` | `domain-transfer/transfer-workflow/src/main/resources/specs/` | OpenAPI 契約 |
| `spec/<workflow>.sw.yaml` | `domain-transfer/transfer-workflow/src/main/resources/` | Canonical Workflow |
| `spec/schemas/*.json` | `domain-transfer/transfer-workflow/src/main/resources/schemas/` | 輸入 Schema |
| `spec/config/*.snippet` | `distribution/transfer-app/src/main/resources/application.properties` | 組態註冊 |
| `spec/db/*.sql` | `domain-transfer/transfer-workflow/src/main/resources/db/migration/` | Flyway View DDL |
| `spec/mocks/*.java.snippet`| `dev/transfer-mock/src/main/java/org/acme/transfer/api/` | JAX-RS Mock 端點 |
| `spec/tests/*.java.snippet`| `distribution/transfer-app/src/test/java/com/example/platform/distribution/transfer/` | @QuarkusTest 套件 |
```

---

## 10. 核心狀態機黃金範本 (Golden State Machine Template)

以下為完整的二階段 Saga 標準鏈範本（對位 `examples/saga2-transfer-workflow.sw.yaml`）：

```yaml
id: <workflow-id>
version: '1.0.0'
specVersion: '0.8'
name: <Workflow Name>
description: <Workflow Description>
start: ValidateInput

metadata:
  domain: payment
  pattern: saga-lifo-compensation
  criticality: high
  owner: platform-team

timeouts:
  workflowExecTimeout: PT5M

errors:
  - name: platformError
    code: 'PLATFORM_ERROR'
    description: 平台層非預期錯誤 (state timeout / 引擎例外 / 服務未攔截例外)

functions:
  - name: callApiViaOpenAPI
    operation: 'service:com.example.transfer.workflow.MyOpenApiService::callOpenApi'
    type: custom
  - name: recordAuditLog
    operation: 'service:com.example.reconciliation.AuditLogService::saveLog'
    type: custom
  - name: notifyOps
    operation: 'service:com.example.reconciliation.OpsAlertService::raise'
    type: custom

states:

  # ═══════════════════════════════════════════════
  # 階段 0: 輸入欄位驗證 (switch)
  # ═══════════════════════════════════════════════
  - name: ValidateInput
    type: switch
    onErrors:
      - errorRef: platformError
        transition: InjectValidationFailedStatus
    dataConditions:
      - name: merchantIdInvalid
        condition: '${ ((.merchantId // "") | match("^[A-Za-z0-9_]+$") // false) == false }'
        transition: InjectValidationFailedStatus
      - name: amountInvalid
        condition: '${ .amount | type != "number" }'
        transition: InjectValidationFailedStatus
      - name: amountNotPositive
        condition: '${ .amount <= 0 }'
        transition: InjectValidationFailedStatus
      - name: currencyInvalid
        condition: '${ ((.currency // "") as $c | ($c == "TWD" or $c == "USD")) | not }'
        transition: InjectValidationFailedStatus
    defaultCondition:
      transition: CallStage1

  # ═══════════════════════════════════════════════
  # 階段 1: 呼叫 API-1 (operation -> switch)
  # ═══════════════════════════════════════════════
  - name: CallStage1
    type: operation
    timeouts:
      actionExecTimeout: PT15S
      stateExecTimeout: PT30S
    onErrors:
      - errorRef: platformError
        transition: InjectFailedStatus
    actions:
      - name: callStage1Action
        functionRef:
          refName: callApiViaOpenAPI
          arguments:
            functionName: "callApiViaOpenAPI"
            schemaRef: 'specs/<stage1>-api.yaml#<operationId>'
            payload:
              merchantId: '${ .merchantId }'
              amount: '${ .amount }'
              EC: false
        actionDataFilter:
          results: '{code: .code, message: .message, id: .id, errorType: .errorType, _httpStatus: ._httpStatus}'
          toStateData: '${ .stage1Result }'
    transition: CheckStage1Result

  - name: CheckStage1Result
    type: switch
    onErrors:
      - errorRef: platformError
        transition: InjectFailedStatus
    dataConditions:
      - name: stage1Success
        condition: '${ .stage1Result.code == "100" }'
        transition: CallStage2
    defaultCondition:
      transition: InjectFailedStatus

  # ═══════════════════════════════════════════════
  # 階段 2: 呼叫 API-2 (出錯回沖階段 1)
  # ═══════════════════════════════════════════════
  - name: CallStage2
    type: operation
    timeouts:
      actionExecTimeout: PT15S
      stateExecTimeout: PT30S
    onErrors:
      - errorRef: platformError
        transition: RollbackStage1
    actions:
      - name: callStage2Action
        functionRef:
          refName: callApiViaOpenAPI
          arguments:
            functionName: "callApiViaOpenAPI"
            schemaRef: 'specs/<stage2>-api.yaml#<operationId>'
            payload:
              stage1Id: '${ .stage1Result.id }'
              amount: '${ .amount }'
        actionDataFilter:
          results: '{code: .code, message: .message, id: .id, errorType: .errorType, _httpStatus: ._httpStatus}'
          toStateData: '${ .stage2Result }'
    transition: CheckStage2Result

  - name: CheckStage2Result
    type: switch
    onErrors:
      - errorRef: platformError
        transition: RollbackStage1
    dataConditions:
      - name: stage2Success
        condition: '${ .stage2Result.code == "100" }'
        transition: InjectSuccessStatus
    defaultCondition:
      transition: RollbackStage1

  # ═══════════════════════════════════════════════
  # LIFO 回沖: 回沖階段 1
  # ═══════════════════════════════════════════════
  - name: RollbackStage1
    type: operation
    timeouts:
      actionExecTimeout: PT15S
      stateExecTimeout: PT30S
    onErrors:
      - errorRef: platformError
        transition: InjectRollbackFailedStatus
    actions:
      - name: rollbackStage1Action
        functionRef:
          refName: callApiViaOpenAPI
          arguments:
            functionName: "callApiViaOpenAPI"
            schemaRef: 'specs/<stage1>-api.yaml#<rollbackOperationId>'
            payload:
              stage1Id: '${ .stage1Result.id }'
              EC: true
        actionDataFilter:
          results: '{code: .code, message: .message, id: .id, errorType: .errorType, _httpStatus: ._httpStatus}'
          toStateData: '${ .stage1RollbackResult }'
    transition: CheckRollbackStage1Result

  - name: CheckRollbackStage1Result
    type: switch
    onErrors:
      - errorRef: platformError
        transition: InjectRollbackFailedStatus
    dataConditions:
      - name: rollbackSuccess
        condition: '${ .stage1RollbackResult.code == "100" }'
        transition: InjectRolledBackStatus
    defaultCondition:
      transition: InjectRollbackFailedStatus

  # ═══════════════════════════════════════════════
  # 狀態注入群 (Inject*Status): 設定 finalStatus 與 finalMessage
  # ═══════════════════════════════════════════════
  - name: InjectValidationFailedStatus
    type: inject
    data:
      finalStatus: "VALIDATION_FAILED"
      finalMessage: "輸入欄位格式錯誤"
    transition: FinalAuditAndEnd

  - name: InjectSuccessStatus
    type: inject
    data:
      finalStatus: "SUCCESS"
      finalMessage: "交易成功"
    transition: FinalAuditAndEnd

  - name: InjectFailedStatus
    type: inject
    data:
      finalStatus: "FAILED"
      finalMessage: "業務失敗或 API 拒絕"
    transition: FinalAuditAndEnd

  - name: InjectRolledBackStatus
    type: inject
    data:
      finalStatus: "ROLLED_BACK"
      finalMessage: "後續步驟失敗, 回沖成功"
    transition: FinalAuditAndEnd

  - name: InjectRollbackFailedStatus
    type: inject
    data:
      finalStatus: "ROLLBACK_FAILED"
      finalMessage: "⚠️ 回沖失敗, 需人工介入處理"
    transition: FinalAuditAndEnd

  # ═══════════════════════════════════════════════
  # 唯一統一終點: 寫入 AuditLog + 條件觸發 OpsAlert + 統一輸出
  # ═══════════════════════════════════════════════
  - name: FinalAuditAndEnd
    type: operation
    timeouts:
      actionExecTimeout: PT10S
      stateExecTimeout: PT20S
    actions:
      - name: saveFinalAuditLog
        functionRef:
          refName: recordAuditLog
          arguments:
            workflowId: "<workflow-id>"
            businessKey: '${ .merchantId }'
            processInstanceId: '${ $WORKFLOW.instanceId }'
            inputData:
              merchantId: '${ .merchantId }'
              amount: '${ .amount }'
              currency: '${ .currency }'
            outputData:
              status: '${ .finalStatus }'
              message: '${ .finalMessage }'
              stage1Result: '${ .stage1Result }'
              stage2Result: '${ .stage2Result }'
              stage1RollbackResult: '${ .stage1RollbackResult }'
        actionDataFilter:
          results: '{saved: .saved}'
          toStateData: '${ .auditResult }'
      - name: raiseOpsAlertIfRequired
        functionRef:
          refName: notifyOps
          arguments:
            workflowId: "<workflow-id>"
            processInstanceId: '${ $WORKFLOW.instanceId }'
            businessKey: '${ .merchantId }'
            finalStatus: '${ .finalStatus }'
            finalMessage: '${ .finalMessage }'
            detail:
              stage1Result: '${ .stage1Result }'
              stage2Result: '${ .stage2Result }'
              stage1RollbackResult: '${ .stage1RollbackResult }'
        actionDataFilter:
          results: '{raised: .raised}'
          toStateData: '${ .opsAlert }'
    stateDataFilter:
      output: |
        {
          status: .finalStatus,
          message: .finalMessage,
          stage1Result: (.stage1Result // null),
          stage2Result: (.stage2Result // null),
          stage1RollbackResult: (.stage1RollbackResult // null),
          auditSaved: (.auditResult.saved // false),
          opsAlertRaised: (.opsAlert.raised // false)
        }
    end: true
```

---

## 11. 交付物產出前自我防呆檢查表 (16 條硬性檢驗項)

在標記為 `stage: done` 前，AI **必須進行自我檢核並確認符合以下 16 條硬規則**：

| # | 檢查項目 | 強制判定條件 | 違規處理 |
|---|---|---|---|
| 1 | **單一終點收斂** | 整個 workflow 只有唯一一個 `FinalAuditAndEnd`，絕無任何 `FinalAuditAndEnd_*` 分支。 | 立即重構為單一終點 |
| 2 | **狀態注入完整性** | 所有分支進入終點前均經過 `Inject*Status` 設定好 `finalStatus` / `finalMessage`。 | 補齊 Inject state |
| 3 | **狀態機業務碼分流** | **每個呼叫 API 的 operation state 均有對應的 switch 檢查 `code == "100"`**，絕無直接連往下一階段或直接判 SUCCESS 的行為。 | 補齊 Switch 判定狀態 |
| 4 | **OpenAPI 檔名與 schemaRef** | 規格檔名為 `*-api.yaml`（無 `-openapi.yaml`）；`schemaRef` 格式為 `specs/<file>-api.yaml#<opId>`。 | 修正檔名與參數 |
| 5 | **OpenAPI 領域專屬客製化** | OpenAPI spec 與 Mock/DTO 必須為當前業務專屬客製化（如 `card-auth-api.yaml`、`CardAuthResource.java`），**嚴禁在非轉帳業務中挪用轉帳範本之 `A16229`/`A16220` 或 `Account_A`/`Account_B`**。 | 立即重新生成專屬領域 spec 與 Mock |
| 6 | **業務欄位傳遞完整性** | workflow 在 `ValidateInput` 驗證的業務關鍵欄位（如 `cardToken`、`currency`、`merchantId` 等）**必須如實傳遞給 API payload，嚴禁驗證後卻在呼叫 API 時丟棄不傳**。 | 補齊 OpenAPI Request 欄位與 workflow payload |
| 7 | **無虛構 Audit OpenAPI** | `notebooks/` 內無 `audit-openapi.yaml`（`AuditLogService` 為純 Java CDI 呼叫）。 | 刪除多餘檔 |
| 8 | **AuditLog 參數結構** | `recordAuditLog` arguments 包含 `workflowId`, `businessKey`, `processInstanceId`, `inputData`, `outputData`。 | 修正 arguments |
| 9 | **OpsAlert 條件呼叫** | `notifyOps` 僅在 `FinalAuditAndEnd` 內條件觸發，不另設獨立 state。 | 修正 actions |
| 10 | **SQLite DDL 語法** | SQL 僅使用 `CREATE VIEW IF NOT EXISTS` 與 `json_extract()`，絕無 `CREATE OR REPLACE`。 | 修正 SQL |
| 11 | **Flyway 版號無衝突** | SQL 版號嚴格為 `V1.2.0`（或接續目標專案現有最大版號），絕不使用已存在的 `V1.0.0` / `V1.1.0`。 | 修正版號 |
| 12 | **對帳欄位顆粒度** | View 完整抽取各階段 `code`、`id/ref`、`audit_saved`、`ops_alert_raised`。 | 補齊抽取欄位 |
| 13 | **測試禁用虛擬 API** | 測試類別**絕對禁止呼叫 `/_admin/sql`**，驗證 View 一律使用原生 SQLite JDBC。 | 修正測試為 JDBC 查驗 |
| 14 | **測試斷言非寬鬆** | 測試案例 5 嚴格斷言 409 與 `opsAlertRaised=true`，**絕無 `anyOf(...)` 等寬鬆無效斷言**。 | 補齊嚴格斷言 |
| 15 | **DTO 極簡風格** | DTO 採用 Public Field，無 Builder / Getter / Setter / Lombok。 | 簡化 DTO 結構 |
| 16 | **JAX-RS 路由隔離** | 每個 Resource 擁有獨立完整的 `@Path`（如 `@Path("/card/auth")`），無衝突 Root Path。 | 修正 `@Path` 宣告 |

---

## 12. 完成定義 (Definition of Done)

- `spec.md` 完整（8 大章節皆填寫完畢，假設清單已拍板）。
- 6 大交付物齊備且 100% 符合 Guardrails。
- FQCN 嚴格錨定平台架構，無虛擬/無效路徑。
- 通過 §11 Pre-flight Guardrail Audit 全部 16 條檢查項目。
- frontmatter 標記 `stage: done`（晉升前）或 `stage: promoted`（已整合）。
