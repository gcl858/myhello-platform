# Core FX Account Debit/Credit API Specification

## Endpoint
`POST /CoreFX/{partyId}/DebitCredit/Execute`

## Description
銀行核心帳務主機 (Core Banking Host) 之台幣活存/外幣活存扣款與補款介面。
- `operationType = 'A'`: 扣款 (Debit)
- `operationType = 'B'`: 反向補款 / 退款 (Credit/Rollback)

### Request Schema
```json
{
  "partyId": "A123456789",
  "fromAccountId": "00701234567890",
  "operationType": "A",
  "amount": "0000030000",
  "sequenceNumber": "FX_20260830_001"
}
```

### Response Schema
```json
{
  "status": 0,
  "message": "核心帳務處理成功",
  "track_id": "core-fx-778899"
}
```
