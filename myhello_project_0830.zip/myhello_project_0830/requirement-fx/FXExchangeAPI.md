# Parent API Specification: FX Exchange Unified Entry

## Endpoint
`POST /FX/{partyId}/Exchange/Execute`

## Description
提供行動銀行、網路銀行統一發起即時外匯結匯與當日換匯沖正交易之對外標準 REST 端點。

### Request Body Schema (application/json)
```json
{
  "partyId": "A123456789",
  "fromAccountId": "00701234567890",
  "currencyCode": "USD",
  "toAccountId": "00709876543210",
  "transactionDate": "20260830",
  "transactionDateTime": "10300000",
  "channelCode": "APP01",
  "operationType": "A",
  "amount": "0000030000",
  "sequenceNumber": "FX_20260830_001",
  "originalSequenceNumber": null
}
```

### Response Schema (200 OK)
```json
{
  "track_id": "FX_20260830_001",
  "workflow": "FX_EXCHANGE",
  "status": 0,
  "finalStatus": "SUCCESS",
  "message": "換匯成功",
  "coreDebitResult": {
    "status": 0,
    "message": "扣款成功",
    "track_id": "core-fx-deb-101"
  },
  "fxSettleResult": {
    "status": 0,
    "message": "外匯清算成功",
    "track_id": "fx-set-202"
  },
  "coreRollbackResult": null,
  "auditSaved": true
}
```
