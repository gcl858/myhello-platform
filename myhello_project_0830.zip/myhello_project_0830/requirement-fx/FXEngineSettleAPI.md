# FX Engine Instant Settle API Specification

## Endpoint
`POST /FXEngine/{partyId}/Settle/Execute`

## Description
銀行外匯清算撮合引擎 (FX Engine) 即時部位鎖定、換匯牌價撮合與申報介面。
- `operationType = 'A'`: 正向部位撮合與外幣結算
- `operationType = 'B'`: 當日部位反向沖銷與取消

### Request Schema
```json
{
  "partyId": "A123456789",
  "currencyCode": "USD",
  "toAccountId": "00709876543210",
  "operationType": "A",
  "amount": "0000030000",
  "sequenceNumber": "FX_20260830_001"
}
```

### Response Schema
```json
{
  "status": 0,
  "message": "外匯撮合清算成功",
  "track_id": "fx-eng-556677"
}
```
