# 外匯即時結匯與沖正業務 (FX Instant Settlement & Reversal) 需求規格書

## 1. 業務背景與場景概述
本業務為商業銀行「外匯即時結匯與換匯申報」核心交易服務。客戶透過行動銀行 App 或網路銀行，辦理台幣換外幣 (如 TWD -> USD) 或外幣換台幣之即時結售/結購。系統需確保雙方扣帳與外匯部位清算之強一致性 (Saga Pattern)，並支援當日換匯沖正取消及重複交易冪等防護。

---

## 2. 核心架構設計 (Mode B: Parent + 2 Child Subflows)

```mermaid
flowchart TD
    Client[行動銀行 / 網銀客戶端] --> Parent[Parent: fx_exchange_settlement]
    Parent -->|11 欄位檢核失敗| VFail[REJECTED_VALIDATION -> HTTP 400]
    Parent -->|Parent 級冪等命中| IdemHit[IDEMPOTENT_REPLAY -> HTTP 200]
    Parent -->|operationType == 'A'| WFA[Child WF-A: fx_exchange_settle]
    Parent -->|operationType == 'B'| WFB[Child WF-B: fx_exchange_reversal]

    WFA -->|Step 1: 核心扣款 (TWD)| CoreDebit[Core FX: 扣款]
    CoreDebit -->|Step 2: 外匯清算鎖定部位| FXSettle[FX Engine: 結匯清算]
    FXSettle -->|成功| Success[SUCCESS -> HTTP 200]
    FXSettle -->|失敗| Rollback[Core FX: 反向補償退款 -> ROLLED_BACK / HTTP 200]

    WFB -->|Step 1: 查詢原交易| Lookup[Audit Log: 查原結匯交易]
    Lookup -->|查無原交易| LF[LOOKUP_FAILED -> HTTP 500]
    Lookup -->|原交易非 SUCCESS / 已沖正| CR[CANCEL_REJECTED -> HTTP 200]
    Lookup -->|Step 2: 外匯沖銷| FXRev[FX Engine: 沖銷部位]
    FXRev -->|Step 3: 核心退款補款| CoreCredit[Core FX: 補款入帳]
    CoreCredit -->|Step 4: 標記已取消| MarkCancel[CANCELLED -> HTTP 200]
```

---

## 3. 欄位規範 (11 個核心業務欄位)

| 欄位名稱 | 欄位代碼 | 型態 | 必填 | 格式 / 正則規則 | 說明與範例 |
|---|---|---|---|---|---|
| 身分證號 / 統編 | `partyId` | String | 是 | `^[A-Za-z0-9]+$` | 客戶身分代碼，如 `A123456789` |
| 扣款台幣帳號 | `fromAccountId` | String | 是 | `^[0-9]{10,16}$` | 扣款台幣活存帳號，如 `00701234567890` |
| 目的外幣幣別 | `currencyCode` | String | 是 | `^[A-Z]{3}$` | 目的幣別 (ISO-4217)，如 `USD`, `EUR`, `JPY` |
| 存入外幣帳號 | `toAccountId` | String | 是 | `^[0-9]{10,16}$` | 存入外幣帳號，如 `00709876543210` |
| 交易日期 | `transactionDate` | String | 是 | `^[0-9]{8}$` | YYYYMMDD，如 `20260830` |
| 交易時間 | `transactionDateTime` | String | 是 | `^[0-9]{8}$` | HHMMSSNN，如 `10300000` |
| 通路代碼 | `channelCode` | String | 是 | `^[A-Za-z0-9]{1,10}$` | 發起通路代碼，如 `APP01`, `WEB01` |
| 交易類別 | `operationType` | String | 是 | `^(A|B)$` | `A`: 即時換匯結購, `B`: 當日結匯沖正 |
| 交易金額 | `amount` | String | 是 | `^(FAIL_)?[0-9]{1,14}$` | 換匯台幣金額 (分/元)，如 `0000030000` (NT$ 30,000) |
| 本筆交易序號 | `sequenceNumber` | String | 是 | `^[A-Za-z0-9_]{1,32}$` | 全局唯一交易追蹤碼，如 `FX_20260830_001` |
| 原交易序號 | `originalSequenceNumber` | String | 條件 | `^[A-Za-z0-9_]{1,32}$` | `operationType=B` 必填；`A` 必須為空 |

---

## 4. 狀態代碼與 HTTP Mapping

| finalStatus | 業務說明 | status | HTTP Status |
|---|---|---|---|
| `SUCCESS` | 即時換匯全流程成功 | 0 | 200 |
| `FAILED` | 核心台幣扣款失敗 | 1 | 200 |
| `ROLLED_BACK` | 外匯清算失敗，台幣已自動回沖退款 | 0 | 200 |
| `ROLLBACK_FAILED`| 外匯清算失敗且台幣退款亦失敗 (需告警) | 1 | 409 |
| `CANCELLED` | 當日換匯沖正成功 | 0 | 200 |
| `CANCEL_REJECTED`| 沖正失敗 (原交易非 SUCCESS 或已被沖正) | 1 | 200 |
| `LOOKUP_FAILED` | 查無原換匯交易紀錄 | 1 | 500 |
| `REJECTED_VALIDATION`| 輸入參數檢核失敗 | 1 | 400 |
| `IDEMPOTENT_REPLAY` | Parent 級冪等防重複重播 | 0 | 200 |
