# 信用卡臨櫃現金繳款業務 — 業務需求文件 v2.2 (Parent Workflow 架構)

> 文件版本: v2.2
> 日期: 2026-08-26
> 對應原始文件: `credit-card-counter-cash-repayment-spec.md` (v1.0)
> 變更摘要: 引入 **Parent Workflow (`CashTransaction`)** 作為統一收納層,以 `operationType` 為 dispatcher 路由鍵;A → WF-A,B → WF-B;WF-C 不在本版

---

## 0. 文件目的

從業務方角度,描述信用卡臨櫃現金繳款的完整 workflow 架構:

- **Parent Workflow** (`CashTransaction`): 統一收單、驗證、分派、稽核
- **Child Workflow A** (WF-A, Repayment): 正常繳款
- **Child Workflow B** (WF-B, Cancellation): 主動取消

> 註: **退款流程(跨日、現金退費等)已另案處理**,本文件不涵蓋。

---

## 1. 業務背景與痛點

### 1.1 現況

目前信用卡臨櫃現金繳款流程由櫃員於端末機手動操作,流程如下:

```
客戶拿現金到櫃台
    ↓
櫃員輸入持卡人資料 + 金額
    ↓
端末機呼叫信用卡主機 → 信用卡主機更新持卡人未還款餘額
    ↓
櫃員開立收據給客戶
```

### 1.2 痛點

- **單一入帳** — 現金只入信用卡帳,未同步進核心總帳
- **無統一入口** — 繳款 / 取消走不同端點,呼叫端邏輯分散
- **無統一取消機制** — 櫃員打錯卡時沒有標準化反向流程
- **無對帳軌跡** — 失敗、重試、補償無系統化記錄

### 1.3 目標

- **單一 API 入口**,以 `operationType` 區分正向/反向業務
- 現金入帳必須**同步**至核心帳務(總帳)+ 信用卡主機(應收帳)
- 兩個主機任一失敗,系統必須**保證最終一致**(透過 Parent 統一補償)
- 取消流程必須**標準化**,所有狀態可追蹤

---

## 2. 業務範圍

### 2.1 包含 (In-Scope)

| Workflow 代號 | 名稱 | 觸發情境 |
|---|---|---|
| **Parent** | `CashTransaction` | 統一收單 + 分派 + 稽核 |
| **WF-A** | Repayment (child) | 櫃員於臨櫃收取現金後,執行入帳 |
| **WF-B** | Cancellation (child) | 櫃員當下發現打錯卡 OR 持卡人當場反悔,發動反向交易 |

### 2.2 不包含 (Out-of-Scope)

| 項目 | 原因 |
|---|---|
| 跨日退款 / 持卡人事後退費 | 涉及已對帳退費,需另案走會計流程 |
| 預授權 / 額度預留 | 屬於「刷卡授權」業務 |
| 外幣繳款 | 涉及匯率計算,本版本僅支援新台幣 |
| 非臨櫃通路(網銀/ATM 等) | 由各通路自有 spec,本文件僅鎖定臨櫃現金 |

---

## 3. 角色與觸發情境

| 角色 | 說明 | 可發動 |
|---|---|---|
| 櫃員 (Teller) | 臨櫃受理客戶繳款 / 取消 | Parent(WF-A)、Parent(WF-B) |
| 持卡人 (Cardholder) | 臨櫃繳款本人,當場可請求取消 | Parent(WF-B)(由櫃員代發動) |
| 分行主管 (Branch Supervisor) | 例外處理、人工核對 | WF-B 失敗後的 manual recovery |
| 監控系統 (Monitoring) | 接收告警 | 訂閱 `vw_..._alerts` |

---

## 4. Parent Workflow 架構 (核心) ⭐ v2.2 重點

### 4.0 整體架構圖

```
┌────────────────────────────────────────────────────────────────┐
│  API 端點: POST /Omni/{creditcardid}/Repayment/Execute         │
│  ──────────────────────────────────────────────────────────     │
│  輸入欄位 (11 個,見 §6.2),其中:                                │
│    operationType = A → 執行 WF-A (Repayment)                   │
│    operationType = B → 執行 WF-B (Cancellation)                │
│    其他值 → 400 驗證錯誤                                        │
└────────────────────────────────────────────────────────────────┘
                              ↓
┌────────────────────────────────────────────────────────────────┐
│  Parent: CashTransaction                                       │
│  ─────────────────────                                          │
│  1. 輸入驗證 (欄位、必填、operationType 範圍)                  │
│  2. 身份/櫃員授權檢查                                            │
│  3. 冪等性檢查 (workflow 級)                                     │
│  4. Dispatcher ─┬─ operationType=A → WF-A (Repayment)          │
│                 └─ operationType=B → WF-B (Cancellation)       │
│  5. 委派執行 (委派給 child workflow)                              │
│  6. 接收 child 回報的 finalStatus                                │
│  7. 統一寫 AuditLog (一個 parent row)                           │
│  8. 統一格式回應 (見 §6.3)                                      │
└────────────────────────────────────────────────────────────────┘
                              ↓
            ┌─────────────────┴─────────────────┐
            ↓                                   ↓
   ┌────────────────────┐             ┌────────────────────┐
   │ WF-A Repayment     │             │ WF-B Cancellation  │
   │ (child workflow)   │             │ (child workflow)   │
   │                    │             │                    │
   │ 階段1: Core opType=A (CA_xxx)    │ Lookup 原交易      │
   │ 階段2: CC   opType=A (CC_xxx)    │ 階段1: Core opType=B(CA_R_xxx)│
   │ 失敗 → 補償:                    │ 階段2: CC   opType=B(CC_R_xxx)│
   │        Core opType=B(CA_R_xxx)  │ 失敗 → 補償:                  │
   │                    │             │        Core opType=B(同CA_R_xxx)│
   └────────────────────┘             └────────────────────┘
```

### 4.0.1 Parent 職責清單

| # | 職責 | 說明 |
|---|---|---|
| P1 | 輸入驗證 | 11 個欄位格式、`operationType` 必須為 A 或 B、業務必填欄位(櫃員、櫃號、端末機) |
| P2 | operationType Dispatcher | 唯一路由決策點,A→WF-A, B→WF-B |
| P3 | 冪等性檢查 | 依 `workflowId` 檢查,若已存在則回傳同結果(workflow 級冪等,見 §7.4) |
| P4 | 委派執行 | 將控制權交給 child,接收 child 回報的 finalStatus |
| P5 | 統一稽核 | 一筆交易 = 一個 parent row,所有 child 階段結果寫入同一 row 的欄位 |
| P6 | 統一回應 | 不論 child 為何,API 回應結構一致(見 §6.3) |
| P7 | 補償治理 | 監控 child 回報,若進入 ROLLBACK_PENDING,驅動補償流程 |
| P8 | 告警 | 任何 child 進入 `*_FAILED` 終態,觸發對應告警 |

### 4.0.2 Child 不做的事(由 Parent 負責)

- ❌ 輸入驗證 → Parent 做
- ❌ 冪等性檢查 → Parent 做
- ❌ 統一回應格式 → Parent 做
- ❌ 跨 workflow 鎖 → Parent 做

### 4.0.3 Dispatcher 決策表

| `operationType` | 業務語意 | Child | 必填額外欄位 |
|---|---|---|---|
| `A` | 正向繳款 | WF-A (Repayment) | 無 |
| `B` | 反向取消 | WF-B (Cancellation) | `originalSequenceNumber` |
| 其他 | — | — | — (回 400) |

> **關鍵**: `operationType` 與 child 的 opType **必須一致**。WF-A 內部對主機呼叫一律 `opType=A`;WF-B 對主機呼叫一律 `opType=B`。

---

### 4.1 Workflow A: 正常繳款 (WF-A, child of Parent)

#### 4.1.1 流程圖

```
Parent 委派
    ↓
[WF-A: Repayment]
    ↓
階段 1: 核心帳務主機 ← 現金入帳(opType=A, seq=CA_xxx)
    ├─ 失敗(status=1 OR http=5xx) → FAILED(無補償,錢未入帳)
    └─ 成功(status=0)
         ↓
階段 2: 信用卡主機 ← 信用卡還款(opType=A, seq=CC_xxx)
    ├─ 成功 → SUCCESS ✅
    └─ 失敗 → 觸發 LIFO 補償
              ↓
          Rollback 核心帳務(opType=B, seq=CA_R_xxx)
              ├─ 成功 → ROLLED_BACK(已退還現金,結束)
              └─ 失敗 → ROLLBACK_FAILED(告警,人工處理)
    ↓
回報 Parent (finalStatus)
```

#### 4.1.2 為什麼兩階段都必須成功

- 核心未入 + 信用卡已扣 → **現金溢收**(銀行多收)
- 核心已入 + 信用卡未扣 → **虛增還款**(持卡人多得信用)

兩者都是監理申報異常,Parent 必須透過 child 流程保證一致性。

---

### 4.2 Workflow B: 主動取消 (WF-B, child of Parent)

#### 4.2.1 觸發條件

| 條件 | 規格 |
|---|---|
| 原交易狀態 | 必須為 `SUCCESS` (已兩階段都成功) |
| 原交易未取消 | 該交易必須尚未被任何 WF-B 處理過 |
| 取消時機 | 當日內(以 `transactionDate` 為準) |
| 發動者 | 同一分行的任一授權櫃員(不限定原櫃員) |
| 取消原因 | `TELLER_MISTAKE`(打錯卡)或 `CARDHOLDER_REQUEST`(持卡人反悔) |

#### 4.2.2 流程圖

```
Parent 委派
    ↓
[WF-B: Cancellation]
    ↓
[Lookup] 用 originalSequenceNumber 從 AuditLog 查原交易(parent row)
    ├─ 找不到 → LOOKUP_FAILED (500)
    ├─ 狀態 ≠ SUCCESS → CANCEL_REJECTED (200, 顯示原因)
    ├─ 已被取消 → CANCEL_REJECTED (idempotency 保護)
    └─ 通過預檢
         ↓
階段 1: 核心帳務主機 ← 沖正(opType=B, seq=CA_R_{origCA})
    ├─ 失敗 → CANCEL_FAILED (無補償,原核心入帳仍存)
    └─ 成功
         ↓
階段 2: 信用卡主機 ← 沖銷(opType=B, seq=CC_R_{origCC})
    ├─ 成功 → CANCELLED ✅ (原交易標記為已取消)
    └─ 失敗 → 部分取消狀態
              ├─ 觸發自動補償(反向回滾階段 1,同 seq CA_R_xxx)
              │   └─ 成功 → CANCEL_ROLLED_BACK
              └─ 補償失敗 → CANCEL_ROLLBACK_FAILED (告警,人工)
    ↓
回報 Parent (finalStatus)
```

#### 4.2.3 與「系統自動補償」的差異

| 維度 | 業務流取消 (WF-B) | 系統自動補償 (WF-A 內部) |
|---|---|---|
| 觸發者 | 櫃員手動 (Parent 委派) | Parent 偵測到 WF-A 階段 2 失敗 |
| 對象 | 兩階段都成功的原交易 | 只有核心入帳的當下交易 |
| 順序 | Core → CC | Core only (因為 CC 從未成功) |
| 失敗處理 | 觸發補償 → 失敗告警人工 | 同左 |
| AuditLog 標記 | `parent.transactionType=CANCELLATION` | `parent.transactionType=REPAYMENT_ROLLBACK` |

> **重要**: WF-B 階段 2 失敗時,Parent 仍會觸發對 WF-B 階段 1 的補償(用同一個 `CA_R_xxx` 冪等回滾);若補償也失敗,則走人工(不再觸發三階補償)。

---

## 5. 統一狀態機

### 5.1 Parent + Child 狀態總表

| 層級 | 狀態 | 涵義 |
|---|---|---|
| **Parent** | `RECEIVED` | API 收到請求 |
| **Parent** | `VALIDATED` | 輸入驗證通過 |
| **Parent** | `REJECTED_VALIDATION` | 驗證失敗 (HTTP 400) |
| **Parent** | `DISPATCHED` | 已委派給 child,等待回報 |
| **Parent** | `COMPLETED` | child 已回報,Parent 整理回應 |
| **Parent** | `IDEMPOTENT_REPLAY` | workflow 級冪等命中,回傳上次結果 |
| **Child WF-A** | `INIT` → `CORE_PENDING` → `CORE_SUCCESS` → `CC_PENDING` → `SUCCESS` |
| **Child WF-A** | `FAILED`(階段 1 失敗) |
| **Child WF-A** | `ROLLBACK_PENDING` → `ROLLED_BACK` |
| **Child WF-A** | `ROLLBACK_FAILED`(HTTP 409) |
| **Child WF-B** | `INIT` → `LOOKUP_PENDING` → `CORE_PENDING` → `CC_PENDING` → `SUCCESS (CANCELLED)` |
| **Child WF-B** | `LOOKUP_FAILED`(HTTP 500) |
| **Child WF-B** | `CANCEL_REJECTED` |
| **Child WF-B** | `CANCEL_FAILED`(階段 1 失敗) |
| **Child WF-B** | `CANCEL_ROLLED_BACK` |
| **Child WF-B** | `CANCEL_ROLLBACK_FAILED`(HTTP 409) |

### 5.2 對外回報狀態(Parent 統一)

> 不論內部 child 為何,Parent 對外只回報下列狀態:

| Parent 對外狀態 | 內部來源 | HTTP |
|---|---|---|
| `SUCCESS` | WF-A 兩階段成功 | 200 |
| `FAILED` | WF-A 階段 1 失敗 | 200 |
| `ROLLED_BACK` | WF-A 階段 2 失敗但補償成功 | 200 |
| `CANCELLED` | WF-B 兩階段成功(取消生效) | 200 |
| `CANCEL_REJECTED` | WF-B 預檢不通過 | 200 |
| `CANCEL_FAILED` | WF-B 階段 1 失敗 | 200 |
| `CANCEL_ROLLED_BACK` | WF-B 階段 2 失敗但補償成功 | 200 |
| `REJECTED_VALIDATION` | Parent 驗證失敗 | 400 |
| `LOOKUP_FAILED` | WF-B 查原交易失敗 | 500 |
| `ROLLBACK_FAILED` | WF-A 補償失敗 | 409 |
| `CANCEL_ROLLBACK_FAILED` | WF-B 補償失敗 | 409 |
| `IDEMPOTENT_REPLAY` | 命中 workflow 級冪等 | 200(回原結果) |

### 5.3 狀態轉換圖

```
                              [API POST]
                                  ↓
                              RECEIVED
                                  ↓
                            [Parent 驗證]
                              ├─(fail)─→ REJECTED_VALIDATION (400)
                              └─(ok)
                                  ↓
                            VALIDATED
                                  ↓
                          [冪等性檢查]
                              ├─(hit)─→ IDEMPOTENT_REPLAY (回原結果)
                              └─(miss)
                                  ↓
                            DISPATCHED
                                  ↓
                  ┌───────────────┴───────────────┐
                  ↓                               ↓
            [operationType=A]               [operationType=B]
                  ↓                               ↓
              [WF-A]                          [WF-B]
                  ↓                               ↓
   CORE_PENDING ─(fail)─→ FAILED    LOOKUP_PENDING ─(fail)─→ LOOKUP_FAILED
        │(ok)                 ↑            │(ok)              ↑
        ↓                     │       [預檢] ─(reject)─→ CANCEL_REJECTED
   CC_PENDING                 │            │(ok)
   ├─(ok)─→ SUCCESS          │            ↓
   └─(fail)─→ ROLLBACK_PENDING      CORE_PENDING
              ├─(ok)─→ ROLLED_BACK   ├─(fail)─→ CANCEL_FAILED
              └─(fail)─→ ROLLBACK_FAILED    │(ok)
                                          ↓
                                     CC_PENDING
                                     ├─(ok)─→ CANCELLED
                                     └─(fail)─→ ROLLBACK_PENDING
                                                  ├─(ok)─→ CANCEL_ROLLED_BACK
                                                  └─(fail)─→ CANCEL_ROLLBACK_FAILED
                  ↓                               ↓
                  └───────────────┬───────────────┘
                                  ↓
                              COMPLETED
                                  ↓
                              [統一回應]
```

### 5.4 HTTP 對應(Parent 對外)

| Parent 對外狀態 | HTTP | 客戶端動作 |
|---|---|---|
| `REJECTED_VALIDATION` | 400 | 修正輸入 |
| `SUCCESS` / `CANCELLED` | 200 | 開立收據 |
| `FAILED` | 200 | 顯示「現金未入帳」,不補償 |
| `ROLLED_BACK` | 200 | 顯示「已退還現金」,結束 |
| `CANCEL_REJECTED` | 200 | 顯示拒絕原因,結束 |
| `CANCEL_FAILED` | 200 | 顯示「取消失敗,原交易仍存」,由櫃員決定重試或人工 |
| `IDEMPOTENT_REPLAY` | 200 | 顯示原結果 |
| `LOOKUP_FAILED` | 500 | 系統異常,稍後重試 |
| `ROLLBACK_FAILED` | 409 | 通知分行主管 |
| `CANCEL_ROLLBACK_FAILED` | 409 | 通知分行主管 |

---

## 6. 介面契約

### 6.1 端點速查(清楚分層)

| 層級 | 端點 | 用途 |
|---|---|---|
| **API 入口 (唯一)** | `POST /Omni/{creditcardid}/Repayment/Execute` | Parent 收單,接收 operationType 分派 |
| 主機呼叫 (由 child 觸發) | `POST /CoreAccount/{id}/CashDeposit/Execute` | 呼叫核心帳務主機 |
| 主機呼叫 (由 child 觸發) | `POST /CreditCard/{id}/Repayment/Execute` | 呼叫信用卡主機 |

> **架構原則**: 對外**只有一個 API 入口**(`/Omni/...`),對內呼叫兩個**主機端點**。Parent 不直接呼叫主機,而是委派給 child 執行。

### 6.2 輸入欄位(API 入口,11 個)

> 詳細規格請參考原始 `omni-counter-repayment-api.md`,本文件補強因 Parent 架構新增的欄位。

| # | 參數 | 類型 | 必填 | 適用 | 說明 |
|---|---|---|---|---|---|
| 1 | `partyId` | string | ✓ | 全部 | 客戶統編 |
| 2 | `branchCode` | string | ✓ | 全部 | 交易分行代號 |
| 3 | `transactionDate` | string | ✓ | 全部 | 交易日期 (YYYYMMDD) |
| 4 | `transactionDateTime` | string | ✓ | 全部 | 交易時間 (HHMMSSxx) |
| 5 | `postingDayType` | string | ✓ | 全部 | A=本日 / B=次日 |
| 6 | `postingDate` | string | ✓ | 全部 | 入帳日 (YYYYMMDD) |
| 7 | `paymentSourceCode` | string | ✓ | 全部 | 見下方 |
| 8 | `operationType` | string | ✓ | **全部** | **A=正向(WF-A) / B=反向(WF-B)** ⭐ |
| 9 | `amount` | string | ✓ | 全部 | 金額(分,左補零) |
| 10 | `sequenceNumber` | string | ✓ | 全部 | 業務序號,Parent 生成 |
| 11 ⭐ | `originalSequenceNumber` | string | **條件必填** | **僅 operationType=B** | 欲取消的原繳款之 sequenceNumber |

**`paymentSourceCode`**: J=語音 / K=存款 / P=網銀 / I=ATM / A=現金 / E=轉帳

### 6.3 統一回應結構(Parent 對外)

```json
{
    "track_id": "<parent 統一 track_id>",
    "workflow": "REPAYMENT" | "CANCELLATION",
    "status": 0 | 1,
    "finalStatus": "SUCCESS" | "FAILED" | "ROLLED_BACK" | "CANCELLED" | "CANCEL_REJECTED" | "CANCEL_FAILED" | "CANCEL_ROLLED_BACK" | "REJECTED_VALIDATION" | "LOOKUP_FAILED" | "ROLLBACK_FAILED" | "CANCEL_ROLLBACK_FAILED" | "IDEMPOTENT_REPLAY",
    "errors": null | [{ "error_code": "...", "message": "..." }],
    "result": {
        "partyId": "...",
        "branchCode": "...",
        "operationType": "A" | "B",
        "amount": "...",
        "sequenceNumber": "...",
        "originalSequenceNumber": "..." // 僅 CANCELLATION 有
    }
}
```

### 6.4 Sequence Number 規則

| 前綴 | 用途 | 產生者 |
|---|---|---|
| `CA_` | 核心帳務正向 | WF-A 階段 1 |
| `CC_` | 信用卡正向 | WF-A 階段 2 |
| `CA_R_` | 核心帳務反向(取消/補償) | WF-B 階段 1、WF-A 系統補償、WF-B 階段 2 失敗時的補償 |
| `CC_R_` | 信用卡反向(取消) | WF-B 階段 2 |

> 規則: prefix 固定 3 碼,後接 19 碼業務序號,合計 22 字元。Parent 對外回報的 `sequenceNumber` 是 child 階段的最終 seq;Parent 自己的 `track_id` 是另一組(給稽核/監控用)。

### 6.5 Dispatcher 範例請求

**WF-A 範例 (operationType=A):**
```json
POST /Omni/A123456789/Repayment/Execute
{
    "partyId": "A123456789",
    "branchCode": "070",
    "transactionDate": "20260805",
    "transactionDateTime": "15061655",
    "postingDayType": "A",
    "postingDate": "20260805",
    "paymentSourceCode": "2500P",
    "operationType": "A",
    "amount": "0000011758",
    "sequenceNumber": "A1234567890000015061655"
    // originalSequenceNumber 不必填
}
```

**WF-B 範例 (operationType=B):**
```json
POST /Omni/A123456789/Repayment/Execute
{
    "partyId": "A123456789",
    "branchCode": "070",
    "transactionDate": "20260805",
    "transactionDateTime": "16000000",
    "postingDayType": "A",
    "postingDate": "20260805",
    "paymentSourceCode": "2500P",
    "operationType": "B",
    "amount": "0000011758",
    "sequenceNumber": "A1234567890000016000000",
    "originalSequenceNumber": "A1234567890000015061655"  // ⭐ 必填
}
```

---

## 7. 業務規則

### 7.1 Parent 通用規則 (BR-P) ⭐ 新章節

| 代號 | 規則 |
|---|---|
| **BR-P01** ⭐ | **API 入口唯一,所有請求走 `POST /Omni/{creditcardid}/Repayment/Execute`** |
| **BR-P02** ⭐ | **`operationType` 為唯一 dispatcher 鍵;A → WF-A,B → WF-B,其他值回 400** |
| **BR-P03** ⭐ | **`operationType=B` 時,`originalSequenceNumber` 為必填;為 A 時不可填** |
| BR-P04 | Parent 必須先做輸入驗證、冪等性檢查,再委派給 child |
| BR-P05 | Parent 對外只回報 §5.2 的對外狀態,內部 child 狀態不外洩 |
| BR-P06 | 任何 child 進入 `*_FAILED` 終態,Parent 必須觸發對應告警 |

### 7.2 通用規則 (跨 workflow,沿用)

| 代號 | 規則 | 適用 |
|---|---|---|
| BR-001 | 所有交易必須有 `tellerId`、`counterNo`、`terminalId` | 全部 |
| BR-002 | 交易金額必須 > 0(單位:分) | 全部 |
| BR-003 | `sequenceNumber` 不可重複(同前綴內唯一) | 全部 |
| BR-004 | `operationType` 只能為 `A` 或 `B` | 全部 |
| BR-005 | 欄位驗證錯誤必須在 5xx 之前攔截,轉成 400 | 全部 |
| BR-006 | **冪等性**: 同一 `sequenceNumber` 重送主機必須回傳相同結果,不得重複入帳 | 全部 |
| BR-007 | **並發保護**: 同一原交易不得同時被兩個 workflow 處理(以 row-level lock 保護) | WF-B |

### 7.3 繳款規則 (WF-A)

| 代號 | 規則 |
|---|---|
| BR-101 | 業務拒絕(status=1, http=200)→ **不**觸發自動沖正(因為本來就沒入帳) |
| BR-102 | 系統錯誤(http=5xx)→ **觸發**自動沖正 |
| BR-103 | 自動沖正本身失敗 → 告警 + 人工介入 |
| BR-104 | 兩段都成功才視為 `SUCCESS`,任一失敗整筆不視為成功 |

### 7.4 冪等性與並發規則

| 代號 | 規則 |
|---|---|
| BR-501 | 主機端必須支援 sequenceNumber 冪等(同 seq 重送回傳同結果) |
| **BR-502** ⭐ | **Parent 必須支援 workflow 級冪等:同 `sequenceNumber` 重送 Parent,回傳同 finalStatus(透過 `IDEMPOTENT_REPLAY` 狀態)** |
| BR-503 | WF-B 啟動時,Parent 必須對原交易 row 加 lock,防止並發取消 |
| BR-504 | 補償操作也必須是冪等的(同 CA_R_seq 重送回傳同結果) |
| BR-505 | 任何 workflow 在 30 秒無回應視為 timeout,進入「未知狀態」需主動查詢主機確認 |

### 7.5 主動取消規則 (WF-B)

| 代號 | 規則 |
|---|---|
| BR-301 | 取消對象的原狀態必須為 `SUCCESS` |
| BR-302 | 同一原交易只能被取消一次(以原交易 `cancelledBy` 欄位為據) |
| BR-303 | 取消必須在原交易當日內發動 |
| BR-304 | WF-B 階段 1 失敗 → `CANCEL_FAILED`,**不補償**(原核心入帳仍存,櫃員可重試取消) |
| BR-305 | WF-B 階段 2 失敗 → 觸發對**自身**階段 1 的補償(同 seq CA_R_xxx) |
| BR-306 | WF-B 補償失敗 → `CANCEL_ROLLBACK_FAILED`,告警,人工處理 |
| BR-307 | 取消原因 `TELLER_MISTAKE` 與 `CARDHOLDER_REQUEST` 走**相同**技術路徑,原因僅用於 audit |
| BR-308 | 取消成功後,原交易狀態改為 `CANCELLED`,並記錄 `cancelledBy` (Parent workflowId) 與 `cancelledAt` |

---

## 8. 資料模型 (Parent 統一)

### 8.1 `transactions` 表(單一主表,每筆 API 呼叫 = 一個 parent row)

| 欄位 | 類型 | 說明 |
|---|---|---|
| `id` | UUID | Primary Key |
| **`parent_workflow_id`** ⭐ | string | Parent 對外 track_id(給櫃員/監控用) |
| **`transaction_type`** ⭐ | enum | `REPAYMENT` / `CANCELLATION` / `REPAYMENT_ROLLBACK` |
| `operation_type` | char(1) | A / B(對應 API 輸入) |
| `parent_status` | enum | Parent 對外狀態(見 §5.2) |
| `child_status` | enum? | Child 內部狀態(給 Parent 內部用) |
| `parent_id` | UUID? | FK → 被取消的原交易(僅 CANCELLATION 有) |
| `original_sequence` | string? | ⭐ `originalSequenceNumber`(僅 CANCELLATION 有) |
| `party_id` | string | 客戶統編 |
| `creditcard_id` | string | 卡號 |
| `branch_code` | string | 分行代號 |
| `amount` | bigint | 金額(分) |
| `reason` | enum? | `TELLER_MISTAKE` / `CARDHOLDER_REQUEST` / null |
| `core_sequence` | string? | 對應主機 seq (CA_xxx / CA_R_xxx) |
| `core_track_id` | string? | 主機回傳追蹤 ID |
| `core_status` | enum? | 主機狀態 (PENDING/SUCCESS/FAILED/NOT_APPLICABLE) |
| `cc_sequence` | string? | 對應主機 seq (CC_xxx / CC_R_xxx) |
| `cc_track_id` | string? | 主機回傳追蹤 ID |
| `cc_status` | enum? | 主機狀態 |
| `rollback_sequence` | string? | 補償 seq (若有的話) |
| `rollback_track_id` | string? | 補償 track_id |
| `rollback_status` | enum? | 補償狀態 |
| `cancelled_by` | UUID? | 哪個 Parent workflowId 把它取消 |
| `cancelled_at` | timestamp? | 取消時間 |
| `teller_id` | string | 經辦櫃員 |
| `counter_no` | string | 櫃號 |
| `terminal_id` | string | 端末機 ID |
| `created_at` | timestamp | 建立時間 |
| `updated_at` | timestamp | 更新時間 |
| `retry_count` | int | 重試次數 |

### 8.2 Parent-Child 對映範例

**REPAYMENT 範例(transaction_type=REPAYMENT):**

| 欄位 | 值 |
|---|---|
| parent_workflow_id | `wf-uuid-001` |
| transaction_type | REPAYMENT |
| operation_type | A |
| parent_status | SUCCESS |
| core_sequence | `CA_xxx_001` |
| core_track_id | `core-track-001` |
| core_status | SUCCESS |
| cc_sequence | `CC_xxx_001` |
| cc_track_id | `cc-track-001` |
| cc_status | SUCCESS |
| (無 rollback_*) | — |

**CANCELLATION 範例(transaction_type=CANCELLATION):**

| 欄位 | 值 |
|---|---|
| parent_workflow_id | `wf-uuid-002` |
| transaction_type | CANCELLATION |
| operation_type | B |
| parent_status | CANCELLED |
| parent_id | `wf-uuid-001`(指向被取消的原 REPAYMENT row) |
| original_sequence | `A1234567890000015061655` |
| core_sequence | `CA_R_xxx_002`(反向前綴) |
| core_track_id | `core-track-002` |
| core_status | SUCCESS |
| cc_sequence | `CC_R_xxx_002` |
| cc_track_id | `cc-track-002` |
| cc_status | SUCCESS |

**被取消的原 REPAYMENT row 被更新:**

| 欄位 | 值 |
|---|---|
| (原 REPAYMENT row) | — |
| cancelled_by | `wf-uuid-002` |
| cancelled_at | `2026-08-05T15:00:00` |

### 8.3 索引建議

- UNIQUE(`core_sequence`)
- UNIQUE(`cc_sequence`)
- INDEX(`parent_id`)
- INDEX(`transaction_type`, `parent_status`)
- INDEX(`party_id`, `transaction_date`)
- INDEX(`original_sequence`) — 給 WF-B 快速查找原交易

---

## 9. 例外處理與補償

### 9.1 補償策略總表(由 Parent 統一治理)

| 觸發情境 | 補償動作 | 失敗處置 |
|---|---|---|
| WF-A 階段 1 失敗 | 無(錢未入帳) | 直接 FAILED |
| WF-A 階段 2 失敗 | Parent 呼叫 Core opType=B (seq=CA_R_xxx) | 告警 + 人工 |
| WF-B 階段 1 失敗 | 無(原核心入帳仍存) | CANCEL_FAILED,櫃員可重試 |
| WF-B 階段 2 失敗 | Parent 呼叫 Core opType=B (同 seq CA_R_xxx,冪等) | 告警 + 人工 |
| 任何階段 timeout | Parent 啟動「未知狀態查詢流程」(見 9.3) | 視查詢結果決定 |

### 9.2 告警規則(Parent 觸發)

| 觸發條件 | 告警等級 | 通知對象 |
|---|---|---|
| `ROLLBACK_FAILED` | P1 | 分行主管 + 監控中心 |
| `CANCEL_ROLLBACK_FAILED` | P1 | 分行主管 + 監控中心 |
| `LOOKUP_FAILED` (連續 3 次) | P2 | 監控中心 |
| 任何 Parent 30 分鐘卡在 DISPATCHED | P2 | 監控中心 |

### 9.3 未知狀態查詢流程

當 child 內某次主機呼叫 timeout:

1. Parent 不立即重試(避免重複入帳)
2. Parent 用相同 sequenceNumber 呼叫主機的「查詢端點」(若無,需請 API owner 補)
3. 依查詢結果決定:
   - 主機端 SUCCESS → 視為成功,繼續 child workflow
   - 主機端 FAILED → 視為失敗,進入補償
   - 主機端查無 → 視為「未送達」,人工聯絡主機 owner

---

## 10. 驗收標準

### 10.1 Parent 層級驗收(4 大情境) ⭐ 新增

| # | 情境 | 預期 finalStatus | HTTP | 關鍵斷言 |
|---|---|---|---|---|
| **P1** ⭐ | `operationType=C` 或其他無效值 | `REJECTED_VALIDATION` | 400 | 沒進 child,沒寫主機 |
| **P2** ⭐ | `operationType=B` 但缺 `originalSequenceNumber` | `REJECTED_VALIDATION` | 400 | 錯誤訊息明確指出缺漏欄位 |
| **P3** ⭐ | `operationType=A` 但帶了 `originalSequenceNumber` | `REJECTED_VALIDATION` | 400 | 不可同時存在 |
| **P4** ⭐ | 同 `sequenceNumber` 重送 Parent | 第二次回 `IDEMPOTENT_REPLAY`,結果與第一次相同 | 200 | 沒有重複呼叫主機(用 mock 計次驗證) |

### 10.2 WF-A 繳款 6 大情境

| # | 情境 | 預期 finalStatus | HTTP | 關鍵斷言 |
|---|---|---|---|---|
| A1 | 正常成功 | `SUCCESS` | 200 | 兩段 track_id 都有, auditSaved=true |
| A2 | 輸入校驗失敗(由 Parent 攔截) | `REJECTED_VALIDATION` | 400 | 失敗也寫 audit |
| A3 | 業務失敗(不補償) | `FAILED` | 200 | 兩段 track_id 都為 null |
| A4 | 失敗回沖成功 | `ROLLED_BACK` | 200 | 兩段 track_id 都有, opsAlert=false |
| A5 | 回沖失敗告警 | `ROLLBACK_FAILED` | 409 | opsAlertRaised=true |
| A6 | 對帳視圖落地 | — | — | JDBC 查 `vw_..._alerts` 正確 |

### 10.3 WF-B 取消 7 大情境

| # | 情境 | 預期 finalStatus | HTTP | 關鍵斷言 |
|---|---|---|---|---|
| B1 | 正常取消 | `CANCELLED` | 200 | 兩段 track_id 都有,原交易 cancelledBy 有值 |
| B2 | 原交易找不到 | `LOOKUP_FAILED` | 500 | 沒發任何主機呼叫 |
| B3 | 原狀態 ≠ SUCCESS | `CANCEL_REJECTED` | 200 | 顯示「原交易非 SUCCESS,無法取消」 |
| B4 | 重複取消 | `CANCEL_REJECTED` | 200 | idempotency 保護,顯示「已取消過」 |
| B5 | 取消階段 1 失敗 | `CANCEL_FAILED` | 200 | 原核心入帳仍存,CC track_id 為 null |
| B6 | 取消階段 2 失敗 + 補償成功 | `CANCEL_ROLLED_BACK` | 200 | 兩段 track_id 都有,opsAlert=false |
| B7 | 取消補償也失敗 | `CANCEL_ROLLBACK_FAILED` | 409 | opsAlertRaised=true |

### 10.4 跨 workflow 整合情境

| # | 情境 | 預期 |
|---|---|---|
| X1 | 對已 CANCELLED 的交易再嘗試取消 | 第二次必須 `CANCEL_REJECTED` |
| X2 | 並發兩個取消同一交易 | 一個 `CANCELLED`、一個 `CANCEL_REJECTED`(並發保護) |
| X3 | 重送同一 `sequenceNumber` | 回傳同 finalStatus(Parent 級冪等) |
| X4 | 取消一筆 ROLLED_BACK 的交易 | `CANCEL_REJECTED`(只能取消 SUCCESS) |
| **X5** ⭐ | REPAYMENT 失敗回沖後,嘗試取消該 ROLLED_BACK 交易 | `CANCEL_REJECTED`(已不在 SUCCESS 狀態) |

---

## 11. 假設與限制

### 11.1 業務假設

| # | 假設 | 待確認 |
|---|------|--------|
| A1 | sequenceNumber 採 22 字元(3 碼 prefix + 19 碼業務序號) | 需 API owner 確認 |
| A2 | 「當日內」以 `transactionDate` 為準,不看時間 | — |
| A3 | 同一卡的判斷基準為 `creditcard_id`,非 `party_id` | — |
| A4 | 櫃員在當日內可發動取消(覆蓋跨班次情境) | 需業務方確認 |
| **A5** ⭐ | `originalSequenceNumber` 是唯一可用於查找原交易的鍵(不走 partyId + amount 模糊查) | 需業務方確認 |

### 11.2 技術限制

| # | 限制 |
|---|---|
| T1 | 對帳資料儲存於 SQLite(本地),跨分行需 ETL 同步至中央資料庫 |
| T2 | Mock 端點僅供開發測試,正式環境由真實主機 API 取代 |
| T3 | Parent + WF-A + WF-B 共用同一套 AuditLog 服務,以 `parent_workflow_id` 區分 |
| T4 | 主機端是否提供「seq 查詢端點」未知(影響 9.3 設計) |

### 11.3 範圍外

| 項目 | 處理方式 |
|---|---|
| 跨日退款 / 持卡人事後退費 | 走會計流程,另案設計 |
| 外幣繳款 | 需另行設計匯率處理流程 |
| 預授權 | 屬於「刷卡授權」業務,非本文件範圍 |

---

## 12. 變更對照 (v2.1 → v2.2)

| 章節 | 變更內容 | 理由 |
|---|---|---|
| §4.0 Parent 架構 | **整段新增** | v2.1 沒有 Parent 概念,W1A/W1B 為平級 |
| §4.0.1 Parent 職責 | **新增** P1~P8 | 明確劃分 Parent vs Child 責任 |
| §4.0.3 Dispatcher 決策表 | **新增** | operationType 路由規則單一來源 |
| §4.1/4.2 | 改為「child of Parent」,委派流程加註 | 從平級改為父子 |
| §5 狀態機 | 新增 Parent 層級狀態(RECEIVED/VALIDATED/DISPATCHED/COMPLETED) | Parent 與 Child 分層 |
| §5.2 對外狀態 | 新增 Parent 對外狀態表 | 統一對外契約 |
| §6.1 端點速查 | 改為分層(API 入口 vs 主機呼叫) | 釐清架構層級 |
| §6.2 輸入欄位 | 11 個欄位,新增 `originalSequenceNumber` | WF-B 需要 |
| §6.3 回應結構 | 新增 `workflow` + `finalStatus` 欄位 | Parent 統一回應 |
| §6.5 Dispatcher 範例 | **新增** A、B 兩種請求範例 | 落實 operationType 路由 |
| §7.1 BR-P01~P06 | **新增** Parent 專屬規則 | operationType、入口唯一、冪等性 |
| §7.4 BR-502 | 改為 Parent 級冪等(原為 workflow 級) | Parent 統一收單 |
| §8 資料模型 | 改為 Parent 統一表,新增 `parent_workflow_id` / `original_sequence` | 一筆 API 呼叫 = 一個 parent row |
| §8.2 對映範例 | **新增** REPAYMENT + CANCELLATION 兩個範例 | 落地欄位 |
| §10.1 Parent 驗收 | **新增** P1~P4 四個情境 | 對應 Parent 職責 |
| §11.1 A5 | **新增** originalSequenceNumber 唯一性假設 | 需業務方確認 |

---

## 13. 待開放問題(需業務方 / API owner 確認)

1. **A1 sequenceNumber 長度** — 仍是 13 或 22? API owner 確認了嗎?
2. **A4 取消時間窗** — 24 小時? 還是當日(以 `transactionDate` 為準)?
3. **A5 originalSequenceNumber 唯一性** — 是否保證一個 partyId 內 sequenceNumber 全域唯一?若否,W1B Lookup 需多鍵查詢
4. **T4 主機查詢端點** — 核心/信用卡主機有沒有提供「依 seq 查狀態」的端點? 影響 9.3
5. **CC_R_ 前綴** — 信用卡主機接受嗎? 還是 opType=B 就夠識別?
6. **W1B 觸發者** — 是否限定原櫃員? 還是同分行任一授權櫃員都可?
7. **Parent 級冪等的 key** — 用 `sequenceNumber` 還是 `parent_workflow_id`?目前 v2.2 採前者
