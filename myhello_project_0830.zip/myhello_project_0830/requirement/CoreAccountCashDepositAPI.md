# 核心主機現金入帳 

**ver.** : `1.0`
**主機名稱** : 核心主機
**通訊方式** : API
**訊息格式** : JSON (UTF-8)
**對應  API** : `POST /CoreAccount/{creditcardid}/CashDeposit/Execute`

## Request 參數

| 參數名 | 類型 | 說明 |
| --- | --- | --- |
| partyId | `string` | 客戶統編 |
| branchCode | `string` | 交易分行代號 |
| transactionDate | `string` | 交易日期 |
| transactionDateTime | `string` | 交易時間 |
| postingDayType | `string` | 本/次日帳類型(A:本日 B:次日) |
| postingDate | `string` | 入帳日 |
| paymentSourceCode | `string` | 繳款來源碼 |
| operationType | `string` | 操作類型(A:正常 B:取消) |
| amount | `string` | 交易金額 |
| sequenceNumber | `string` | 交易序號(客戶統編 + 交易時間需再字串的左側補零，直到總長度達到 13 個字元) |

### 繳款來源碼 參數說明

| Code | Description |
| --- | --- |
| J | 語音 |
| K | 存款 |
| P | 網路銀行 |
| I | CD/ATM 轉帳 |
| A | 現金 |
| E | 轉帳 |

### Data example (主機請求訊息本文)

```json
{
    "partyId":"A123456789",
    "branchCode":"070",
    "transactionDate":"20260805",
    "transactionDateTime":"15061655",
    "postingDayType":"A",
    "postingDate":"20260805",
    "paymentSourceCode":"2500P",
    "operationType":"A",
    "amount":"0000011758",
    "sequenceNumber": "A1234567890000015061655"
}
```

## Success Response 結構

**主機回應訊息**

### 主體結構

| 參數名 | 類型 | 允許 null | 說明 |
| --- | --- | --- | --- |
| track_id | `string` | N | 追蹤 ID |
| status | `int` | N | 0：成功;1：失敗 |
| errors | `array<object>` | Y | 錯誤結構 |
| result | `object` | Y | 結果資料 |

### errors(`object`)結構

| 參數名 | 類型 | 允許 null | 說明 |
| --- | --- | --- | --- |
| error_code | `string` | N | 錯誤代碼 |
| message | `string` | N | 訊息 |

### result(`object`)結構

| 參數名 | 類型 | 允許 null | 說明 |
| --- | --- | --- | --- |
| partyId | `string` | N | 客戶統編 |
| branchCode | `string` | N | 交易分行代號 |
| operationType | `string` | N | 操作類型(A:正常 B:取消) |
| amount | `string` | N | 交易金額 |
| sequenceNumber | `string` | N | 交易序號 |

### Data example (主機回應訊息本文)

```json
{
    "track_id": "fec08b53dada432fac042dee8b1e3390",
    "status": 0,
    "errors": null,
    "result": {
        "partyId":"A123456789",
        "branchCode":"070",
        "operationType":"A",
        "amount":"0000011758",
        "sequenceNumber": "A1234567890000015061655"
    }
}
```

## Error Response

錯誤發生時結構皆相同，如需判斷請參考錯誤代碼表。

**結構** :

```json
{
    "track_id": "c269cd92a1984c2895175926930b871e",
    "status": 1,
    "errors": [
        {
            "error_code": "E0023",
            "message": "查無資料!!!"
        }
    ],
    "result": null
}
```
