# Parent API Specification: Loan Instant Disbursement Entry

## Endpoint
`POST /Loan/{partyId}/Disburse/Execute`

## Description
提供線上貸款核心系統、行動銀行統一發起個人信貸即時撥款與當日沖正作業之對外標準 REST 端點。

### Request Body Schema (application/json)
```json
{
  "partyId": "A123456789",
  "contractNo": "LN20260830001",
  "loanProductCode": "PL001",
  "toAccountId": "00701234567890",
  "transactionDate": "20260830",
  "transactionDateTime": "11000000",
  "channelCode": "APP01",
  "operationType": "A",
  "amount": "0000500000",
  "sequenceNumber": "LN_DISB_20260830_001",
  "originalSequenceNumber": null
}
```

### Response Schema (200 OK)
```json
{
  "track_id": "LN_DISB_20260830_001",
  "workflow": "LOAN_DISBURSEMENT",
  "status": 0,
  "finalStatus": "SUCCESS",
  "message": "放款撥款成功",
  "loanHostResult": {
    "status": 0,
    "message": "放款主機開戶成功",
    "track_id": "loan-host-tx-101"
  },
  "coreDepositResult": {
    "status": 0,
    "message": "撥款入帳成功",
    "track_id": "core-dep-tx-202"
  },
  "loanRollbackResult": null,
  "auditSaved": true
}
```
