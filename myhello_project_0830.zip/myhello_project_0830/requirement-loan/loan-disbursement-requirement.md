# 個人信貸即時撥款與沖正業務 (Loan Instant Disbursement & Reversal) 需求規格書

## 1. 業務背景與場景概述
本業務為商業銀行「個人線上信用貸款即時核貸與撥款」核心交易服務。客戶於行動銀行或線上申貸對保核准後，發起即時撥款作業。流程須依序完成「放款主機開戶建立額度」與「指定活存帳號撥款入帳」兩階段 Saga 交易。若撥款入帳失敗，需即時回沖放款主機額度；同時支援當日營業時間內之撥款錯誤沖正與 Parent 級冪等防護。

---

## 2. 核心架構設計 (Mode B: Parent + 2 Child Subflows)

```mermaid
flowchart TD
    Client[行動銀行 / 線上貸款系統] --> Parent[Parent: loan_instant_disbursement]
    Parent -->|11 欄位檢核失敗| VFail[REJECTED_VALIDATION -> HTTP 400]
    Parent -->|Parent 級冪等命中| IdemHit[IDEMPOTENT_REPLAY -> HTTP 200]
    Parent -->|operationType == 'A'| WFA[Child WF-A: loan_disburse_payout]
    Parent -->|operationType == 'B'| WFB[Child WF-B: loan_disburse_reversal]

    WFA -->|Step 1: 放款主機開戶入帳| LoanHost[Loan Host: 建立放款額度]
    LoanHost -->|Step 2: 活存帳戶撥款入帳| CoreCredit[Core Deposit: 撥款入帳]
    CoreCredit -->|成功| Success[SUCCESS -> HTTP 200]
    CoreCredit -->|失敗| Rollback[Loan Host: 反向銷帳沖正 -> ROLLED_BACK / HTTP 200]

    WFB -->|Step 1: 查詢原交易| Lookup[Audit Log: 查原撥款交易]
    Lookup -->|查無原交易| LF[LOOKUP_FAILED -> HTTP 500]
    Lookup -->|原交易非 SUCCESS / 已沖正| CR[CANCEL_REJECTED -> HTTP 200]
    Lookup -->|Step 2: 活存扣回撥款本金| CoreDebit[Core Deposit: 扣回撥款]
    CoreDebit -->|Step 3: 放款主機銷帳沖正| LoanRev[Loan Host: 銷帳結清]
    LoanRev -->|Step 4: 標記已取消| MarkCancel[CANCELLED -> HTTP 200]
```

---

## 3. 欄位規範 (11 個核心業務欄位)

| 欄位名稱 | 欄位代碼 | 型態 | 必填 | 格式 / 正則規則 | 說明與範例 |
|---|---|---|---|---|---|
| 身分證號 / 統編 | `partyId` | String | 是 | `^[A-Za-z0-9]+$` | 客戶身分代碼，如 `A123456789` |
| 貸款合約編號 | `contractNo` | String | 是 | `^[A-Za-z0-9]{10,20}$` | 貸款核准合約號，如 `LN20260830001` |
| 貸款產品別 | `loanProductCode` | String | 是 | `^[A-Za-z0-9]{3,6}$` | 貸款產品代碼，如 `PL001` |
| 撥款存入帳號 | `toAccountId` | String | 是 | `^[0-9]{10,16}$` | 撥款入帳活期帳號，如 `00701234567890` |
| 交易日期 | `transactionDate` | String | 是 | `^[0-9]{8}$` | YYYYMMDD，如 `20260830` |
| 交易時間 | `transactionDateTime` | String | 是 | `^[0-9]{8}$` | HHMMSSNN，如 `11000000` |
| 通路代碼 | `channelCode` | String | 是 | `^[A-Za-z0-9]{1,10}$` | 發起通路代碼，如 `APP01`, `WEB01` |
| 交易類別 | `operationType` | String | 是 | `^(A|B)$` | `A`: 即時放款撥入, `B`: 當日撥款沖正 |
| 撥款金額 | `amount` | String | 是 | `^(FAIL_)?[0-9]{1,14}$` | 放款撥款金額 (元)，如 `0000500000` (NT$ 500,000) |
| 本筆交易序號 | `sequenceNumber` | String | 是 | `^[A-Za-z0-9_]{1,32}$` | 全局唯一交易追蹤碼，如 `LN_DISB_20260830_001` |
| 原交易序號 | `originalSequenceNumber` | String | 條件 | `^[A-Za-z0-9_]{1,32}$` | `operationType=B` 必填；`A` 必須為空 |

---

## 4. 狀態代碼與 HTTP Mapping

| finalStatus | 業務說明 | status | HTTP Status |
|---|---|---|---|
| `SUCCESS` | 即時放款撥付全流程成功 | 0 | 200 |
| `FAILED` | 放款主機建檔開戶失敗 | 1 | 200 |
| `ROLLED_BACK` | 活存撥付失敗，放款主機已自動銷帳回沖 | 0 | 200 |
| `ROLLBACK_FAILED`| 撥付失敗且銷帳回沖亦失敗 (需告警) | 1 | 409 |
| `CANCELLED` | 當日撥款沖正成功 | 0 | 200 |
| `CANCEL_REJECTED`| 沖正失敗 (原交易非 SUCCESS 或已被沖正) | 1 | 200 |
| `LOOKUP_FAILED` | 查無原撥款交易紀錄 | 1 | 500 |
| `REJECTED_VALIDATION`| 輸入參數檢核失敗 | 1 | 400 |
| `IDEMPOTENT_REPLAY` | Parent 級冪等防重複重播 | 0 | 200 |
