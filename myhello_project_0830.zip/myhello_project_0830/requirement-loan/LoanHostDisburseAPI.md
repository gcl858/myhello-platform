# Loan Host Core Disbursement API Specification

## Endpoint
`POST /LoanHost/{partyId}/Disburse/Execute`

## Description
銀行放款帳務主機 (Loan Host Core) 貸款開戶、建立額度與銷帳介面。
- `operationType = 'A'`: 正向放款開戶 (Disburse)
- `operationType = 'B'`: 反向銷帳沖正 (Rollback/Cancel)

### Request Schema
```json
{
  "partyId": "A123456789",
  "contractNo": "LN20260830001",
  "loanProductCode": "PL001",
  "operationType": "A",
  "amount": "0000500000",
  "sequenceNumber": "LN_DISB_20260830_001"
}
```

### Response Schema
```json
{
  "status": 0,
  "message": "放款主機處理成功",
  "track_id": "loan-host-889900"
}
```
