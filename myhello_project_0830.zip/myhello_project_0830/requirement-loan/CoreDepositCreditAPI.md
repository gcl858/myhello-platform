# Core Deposit Payout/Credit API Specification

## Endpoint
`POST /CoreDeposit/{partyId}/Credit/Execute`

## Description
銀行活期儲蓄帳戶存款/撥款入帳及扣回介面。
- `operationType = 'A'`: 撥款存入 (Credit)
- `operationType = 'B'`: 反向扣回本金 (Debit/Rollback)

### Request Schema
```json
{
  "partyId": "A123456789",
  "toAccountId": "00701234567890",
  "operationType": "A",
  "amount": "0000500000",
  "sequenceNumber": "LN_DISB_20260830_001"
}
```

### Response Schema
```json
{
  "status": 0,
  "message": "活期帳戶撥款處理成功",
  "track_id": "core-dep-667788"
}
```
