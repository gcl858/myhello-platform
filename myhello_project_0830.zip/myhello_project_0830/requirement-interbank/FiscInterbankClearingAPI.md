# 財金中心跨行清算 API

**ver.** : `1.0`  
**URL** : `/FISC/{fromAccountId}/Clearing/Execute`  
**Method** : `POST`  
**說明** : 財金跨行即時清算交換

## Request 參數

| 參數名 | 類型 | 說明 |
| --- | --- | --- |
| fromAccountId | `string` | 轉出帳號 |
| toBankCode | `string` | 轉入行代碼 |
| toAccountId | `string` | 轉入帳號 |
| operationType | `string` | A:轉出清算 B:沖正取消 |
| amount | `string` | 金額 (分) |
| sequenceNumber | `string` | 財金序號 |

### Request Example
```json
{
  "fromAccountId": "00701234567890",
  "toBankCode": "822",
  "toAccountId": "98765432109876",
  "operationType": "A",
  "amount": "0000050000",
  "sequenceNumber": "FC_20260830100000001"
}
```

## Response Example
```json
{
  "track_id": "fisc-tx-99481723",
  "status": 0,
  "message": "跨行轉出成功",
  "errors": null,
  "result": {
    "toBankCode": "822",
    "toAccountId": "98765432109876",
    "amount": "0000050000",
    "fiscFee": "0000001500"
  }
}
```
