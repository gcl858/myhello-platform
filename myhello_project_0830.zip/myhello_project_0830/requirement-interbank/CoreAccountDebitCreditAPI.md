# 核心帳務借貸主機 API

**ver.** : `1.0`  
**URL** : `/CoreAccount/{fromAccountId}/Debit/Execute`  
**Method** : `POST`  
**說明** : 核心活期存款帳戶扣款或沖正退款

## Request 參數

| 參數名 | 類型 | 說明 |
| --- | --- | --- |
| partyId | `string` | 客戶身分證字號 |
| fromAccountId | `string` | 帳號 |
| operationType | `string` | A:扣款 B:沖正退款 |
| amount | `string` | 金額 (分) |
| sequenceNumber | `string` | 業務序號 |

### Request Example
```json
{
  "partyId": "A123456789",
  "fromAccountId": "00701234567890",
  "operationType": "A",
  "amount": "0000050000",
  "sequenceNumber": "IB_20260830100000001"
}
```

## Response Example
```json
{
  "track_id": "core-deb-83918239",
  "status": 0,
  "message": "扣款成功",
  "errors": null,
  "result": {
    "fromAccountId": "00701234567890",
    "amount": "0000050000",
    "balance": "0000950000"
  }
}
```
