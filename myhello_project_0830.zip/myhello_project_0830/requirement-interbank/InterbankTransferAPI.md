# 跨行轉帳 API

**ver.** : `1.0`  
**URL** : `/Interbank/{fromAccountId}/Transfer/Execute`  
**Method** : `POST`  
**說明** : 客戶發動跨行即時轉帳或當日沖正

## Request 參數

| 參數名 | 類型 | 說明 |
| --- | --- | --- |
| partyId | `string` | 客戶身分證字號 / 統編 |
| fromAccountId | `string` | 轉出帳號 |
| toBankCode | `string` | 轉入行代碼 |
| toAccountId | `string` | 轉入帳號 |
| transactionDate | `string` | 交易日期 (YYYYMMDD) |
| transactionDateTime | `string` | 交易時間 (HHMMSSxx) |
| channelCode | `string` | 通路代碼 |
| operationType | `string` | 操作類型 (A:正向 B:取消) |
| amount | `string` | 交易金額 (分) |
| sequenceNumber | `string` | 業務序號 |
| originalSequenceNumber | `string` | 原交易序號 (operationType=B 必填) |

### Request Example

```json
{
  "partyId": "A123456789",
  "fromAccountId": "00701234567890",
  "toBankCode": "822",
  "toAccountId": "98765432109876",
  "transactionDate": "20260830",
  "transactionDateTime": "10000000",
  "channelCode": "APP01",
  "operationType": "A",
  "amount": "0000050000",
  "sequenceNumber": "IB_20260830100000001"
}
```

## Response 結構

```json
{
  "track_id": "IB_20260830100000001",
  "workflow": "INTERBANK_TRANSFER",
  "status": 0,
  "finalStatus": "SUCCESS",
  "message": "轉帳成功",
  "coreDebitResult": { "status": 0, "message": "扣款成功", "track_id": "core-deb-001" },
  "fiscResult": { "status": 0, "message": "財金轉出成功", "track_id": "fisc-tx-001" }
}
```
