# 銀行跨行即時轉帳業務 — 業務需求文件 v1.0 (Parent Workflow 架構)

> 文件版本: v1.0  
> 日期: 2026-08-30  
> 業務代碼: BR-IBT (Interbank Fund Transfer)  
> 架構模式: **Mode B (Parent + 2 Child Subflow 分派模式)**  

---

## 0. 文件目的

本文件規範銀行客戶透過網銀/行動銀行或臨櫃發動「跨行即時轉帳」之端對端業務流與例外補償機制：
- **Parent Workflow (`interbank_fund_transfer`)**: 統一收單、輸入驗證、冪等檢查、路由分派、統一審計與狀態改寫。
- **Child WF-A (`interbank_transfer_out`)**: 正向轉帳（階段 1: 核心帳務活存扣款 ➔ 階段 2: 財金公司 FISC 跨行清算；若財金失敗則 LIFO 回沖核心活存退款）。
- **Child WF-B (`interbank_transfer_reversal`)**: 當日主動沖正/取消（Lookup 原交易 ➔ 階段 1: 財金跨行沖正 ➔ 階段 2: 核心帳務活存退款補償）。

---

## 1. 業務場景與流程

```
┌─────────────────────────────────────────────────────────────┐
│ 統一入口 API: POST /Interbank/{fromAccountId}/Transfer/Execute│
└─────────────────────────────────────────────────────────────┘
                               ↓
┌─────────────────────────────────────────────────────────────┐
│ Parent: interbank_fund_transfer                             │
│ 1. 輸入驗證 (11 欄位檢核、operationType A/B)                 │
│ 2. Parent 級冪等性檢查 (依 sequenceNumber)                   │
│ 3. Dispatcher 分派                                          │
└─────────────────────────────────────────────────────────────┘
                │ operationType=A           │ operationType=B
                ↓                           ↓
┌───────────────────────────────┐ ┌───────────────────────────┐
│ Child WF-A:                   │ │ Child WF-B:               │
│ interbank_transfer_out        │ │ interbank_transfer_reversal│
│ 階段 1: Core 活存扣款 (IB_xxx)  │ │ 1. Lookup 原轉帳 AuditLog  │
│ 階段 2: 財金 FISC 轉出 (FC_xxx)│ │ 階段 1: 財金沖正 (FC_R_xx) │
│ (失敗自動 LIFO 核心沖正退款)    │ │ 階段 2: Core 活存退款(IB_R) │
└───────────────────────────────┘ └───────────────────────────┘
```

---

## 2. 介面欄位契約 (11 個欄位)

| # | 欄位名稱 | 類型 | 必填 | 說明 |
|---|---|---|---|---|
| 1 | `partyId` | string | ✓ | 客戶身分證字號 / 統編 |
| 2 | `fromAccountId` | string | ✓ | 轉出帳號 (12~14 碼) |
| 3 | `toBankCode` | string | ✓ | 轉入行代碼 (3 碼，如 004, 012, 822) |
| 4 | `toAccountId` | string | ✓ | 轉入帳號 (10~16 碼) |
| 5 | `transactionDate` | string | ✓ | 交易日期 (YYYYMMDD) |
| 6 | `transactionDateTime`| string | ✓ | 交易時間 (HHMMSSxx) |
| 7 | `channelCode` | string | ✓ | 通路代碼 (如 NET01, APP02, BRANCH) |
| 8 | `operationType` | string | ✓ | **A=正向轉帳 / B=反向沖正** |
| 9 | `amount` | string | ✓ | 轉帳金額 (單位:分，純數字字串，>0) |
| 10| `sequenceNumber` | string | ✓ | 業務序號 (Parent 級冪等鍵，IB_ 或 IB_R_ 前綴) |
| 11| `originalSequenceNumber`| string | 條件必填 | **僅 operationType=B 必填** |

---

## 3. 狀態與 HTTP 映射

| finalStatus | HTTP Code | status (int) | 說明 |
|---|---|---|---|
| `SUCCESS` | 200 | 0 | 扣款與跨行轉出皆成功 |
| `FAILED` | 200 | 1 | 核心扣款失敗或業務拒絕 (短路不補償) |
| `ROLLED_BACK` | 200 | 0 | 跨行轉出失敗，核心已自動退款回沖 |
| `CANCELLED` | 200 | 0 | 跨行沖正與退款成功 |
| `CANCEL_REJECTED` | 200 | 0 | 原交易非 SUCCESS 或已被取消 |
| `REJECTED_VALIDATION` | 400 | 1 | 輸入欄位格式檢核失敗 |
| `LOOKUP_FAILED` | 500 | 1 | 沖正時查無原交易紀錄 |
| `ROLLBACK_FAILED` | 409 | 1 | 核心回沖退款失敗 (告警人工介入) |
| `CANCEL_ROLLBACK_FAILED` | 409 | 1 | 沖正補償失敗 (告警人工介入) |
| `IDEMPOTENT_REPLAY` | 200 | 0 | 命中 Parent 級冪等，回傳原結果 |
