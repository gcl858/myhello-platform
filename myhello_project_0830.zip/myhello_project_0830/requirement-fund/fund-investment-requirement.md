# 財富管理基金即時申購與取消業務 (Fund Investment Subscription & Cancellation) 需求規格書

## 1. 業務背景與場景概述
本業務為商業銀行「財富管理線上基金申購與當日沖銷」核心交易服務。客戶透過行動銀行或網路銀行進行境內外基金單筆/定期定額申購作業。流程依序完成「信託活存帳戶扣款」與「基金交易平台下單撮合」兩階段 Saga 交易。若下單撮合失敗，需即時回沖扣款；同時支援當日營業時間內之委託取消與 Parent 級冪等防護。

---

## 2. 核心架構設計 (Mode B: Parent + 2 Child Subflows)

```mermaid
flowchart TD
    Client[行動銀行 / 財管系統] --> Parent[Parent: fund_investment_order]
    Parent -->|11 欄位檢核失敗| VFail[REJECTED_VALIDATION -> HTTP 400]
    Parent -->|Parent 級冪等命中| IdemHit[IDEMPOTENT_REPLAY -> HTTP 200]
    Parent -->|operationType == 'A'| WFA[Child WF-A: fund_order_subscribe]
    Parent -->|operationType == 'B'| WFB[Child WF-B: fund_order_cancellation]

    WFA -->|Step 1: 活存信託扣款| CoreDebit[Core Trust: 扣款]
    CoreDebit -->|Step 2: 基金平台下單| FundOrder[Fund Platform: 下單撮合]
    FundOrder -->|成功| Success[SUCCESS -> HTTP 200]
    FundOrder -->|失敗| Rollback[Core Trust: 反向退款回沖 -> ROLLED_BACK / HTTP 200]

    WFB -->|Step 1: 查詢原申購交易| Lookup[Audit Log: 查原申購單]
    Lookup -->|查無原交易| LF[LOOKUP_FAILED -> HTTP 500]
    Lookup -->|原交易非 SUCCESS / 已取消| CR[CANCEL_REJECTED -> HTTP 200]
    Lookup -->|Step 2: 基金平台取消委託| FundCancel[Fund Platform: 取消委託]
    FundCancel -->|Step 3: 活存信託退回本金| CoreCredit[Core Trust: 補款退回]
    CoreCredit -->|Step 4: 標記已取消| MarkCancel[CANCELLED -> HTTP 200]
```

---

## 3. 欄位規範 (11 個核心業務欄位)

| 欄位名稱 | 欄位代碼 | 型態 | 必填 | 格式 / 正則規則 | 說明與範例 |
|---|---|---|---|---|---|
| 身分證號 / 統編 | `partyId` | String | 是 | `^[A-Za-z0-9]+$` | 客戶身分代碼，如 `A123456789` |
| 基金代號 | `fundCode` | String | 是 | `^[A-Za-z0-9]{4,10}$` | 基金標的代碼，如 `FD001` 或 `US99988` |
| 扣款活存帳號 | `fromAccountId` | String | 是 | `^[0-9]{10,16}$` | 投資人扣款活期帳號，如 `00701234567890` |
| 信託幣別 | `currencyCode` | String | 是 | `^[A-Z]{3}$` | ISO-4217 幣別代碼，如 `TWD`, `USD` |
| 交易日期 | `transactionDate` | String | 是 | `^[0-9]{8}$` | YYYYMMDD，如 `20260830` |
| 交易時間 | `transactionDateTime` | String | 是 | `^[0-9]{8}$` | HHMMSSNN，如 `11300000` |
| 通路代碼 | `channelCode` | String | 是 | `^[A-Za-z0-9]{1,10}$` | 發起通路代碼，如 `APP01`, `WEB01` |
| 交易類別 | `operationType` | String | 是 | `^(A|B)$` | `A`: 基金申購, `B`: 當日委託取消 |
| 申購金額 | `amount` | String | 是 | `^(FAIL_)?[0-9]{1,14}$` | 申購金額，如 `0000050000` (NT$ 50,000) |
| 本筆交易序號 | `sequenceNumber` | String | 是 | `^[A-Za-z0-9_]{1,32}$` | 全局唯一交易追蹤碼，如 `FD_ORD_20260830_001` |
| 原交易序號 | `originalSequenceNumber` | String | 條件 | `^[A-Za-z0-9_]{1,32}$` | `operationType=B` 必填；`A` 必須為空 |

---

## 4. 狀態代碼與 HTTP Mapping

| finalStatus | 業務說明 | status | HTTP Status |
|---|---|---|---|
| `SUCCESS` | 基金申購下單全流程成功 | 0 | 200 |
| `FAILED` | 活存信託扣款失敗 | 1 | 200 |
| `ROLLED_BACK` | 基金下單失敗，活存已自動退款回沖 | 0 | 200 |
| `ROLLBACK_FAILED`| 下單失敗且退款回沖亦失敗 (需告警) | 1 | 409 |
| `CANCELLED` | 當日基金委託取消成功 | 0 | 200 |
| `CANCEL_REJECTED`| 取消失敗 (原交易非 SUCCESS 或已被取消) | 1 | 200 |
| `LOOKUP_FAILED` | 查無原申購交易紀錄 | 1 | 500 |
| `REJECTED_VALIDATION`| 輸入參數檢核失敗 | 1 | 400 |
| `IDEMPOTENT_REPLAY` | Parent 級冪等防重複重播 | 0 | 200 |
