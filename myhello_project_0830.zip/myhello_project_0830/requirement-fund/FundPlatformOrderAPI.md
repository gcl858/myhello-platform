# Fund Platform Order API Specification

## Endpoint
`POST /FundPlatform/{partyId}/Order/Execute`

## Description
基金交易撮合平台下單與委託取消介面。
- `operationType = 'A'`: 申購下單撮合 (Subscribe)
- `operationType = 'B'`: 委託取消沖正 (Cancel)

### Request Schema
```json
{
  "partyId": "A123456789",
  "fundCode": "FD001",
  "currencyCode": "TWD",
  "operationType": "A",
  "amount": "0000050000",
  "sequenceNumber": "FD_ORD_20260830_001"
}
```

### Response Schema
```json
{
  "status": 0,
  "message": "基金平台處理成功",
  "track_id": "fund-plt-667788"
}
```
