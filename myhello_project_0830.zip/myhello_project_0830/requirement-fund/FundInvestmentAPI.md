# Parent API Specification: Fund Investment Order Entry

## Endpoint
`POST /Fund/{partyId}/Order/Execute`

## Description
提供行動銀行、網銀系統統一發起基金單筆申購與當日委託取消作業之對外標準 REST 端點。

### Request Body Schema (application/json)
```json
{
  "partyId": "A123456789",
  "fundCode": "FD001",
  "fromAccountId": "00701234567890",
  "currencyCode": "TWD",
  "transactionDate": "20260830",
  "transactionDateTime": "11300000",
  "channelCode": "APP01",
  "operationType": "A",
  "amount": "0000050000",
  "sequenceNumber": "FD_ORD_20260830_001",
  "originalSequenceNumber": null
}
```

### Response Schema (200 OK)
```json
{
  "track_id": "FD_ORD_20260830_001",
  "workflow": "FUND_INVESTMENT",
  "status": 0,
  "finalStatus": "SUCCESS",
  "message": "基金申購下單成功",
  "coreDebitResult": {
    "status": 0,
    "message": "信託扣款成功",
    "track_id": "trust-deb-101"
  },
  "fundOrderResult": {
    "status": 0,
    "message": "基金下單撮合成功",
    "track_id": "fund-plt-202"
  },
  "coreRollbackResult": null,
  "auditSaved": true
}
```
