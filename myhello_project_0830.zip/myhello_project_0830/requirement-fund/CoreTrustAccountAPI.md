# Core Trust Account Debit/Credit API Specification

## Endpoint
`POST /CoreTrust/{partyId}/DebitCredit/Execute`

## Description
銀行信託帳戶借記扣款與貸記補款介面。
- `operationType = 'A'`: 申購扣款 (Debit)
- `operationType = 'B'`: 退款/取消補款 (Credit/Rollback)

### Request Schema
```json
{
  "partyId": "A123456789",
  "fromAccountId": "00701234567890",
  "currencyCode": "TWD",
  "operationType": "A",
  "amount": "0000050000",
  "sequenceNumber": "FD_ORD_20260830_001"
}
```

### Response Schema
```json
{
  "status": 0,
  "message": "信託帳戶扣補款處理成功",
  "track_id": "trust-tx-889900"
}
```
