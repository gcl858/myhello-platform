# Draft Specification: FX Exchange Settlement & Reversal

## §0 核心決策
- 採用 Mode B 階層式架構 (Parent + 2 Child Subflows)
- 雙軌制狀態碼: status (0/1) + finalStatus (STRING)

## §1 業務與架構說明
- Parent: `fx_exchange_settlement`
- Child WF-A: `fx_exchange_settle`
- Child WF-B: `fx_exchange_reversal`

## §2 平台預檢與自檢
- 6 項預檢全數通過
- 20 項自檢全數通過
