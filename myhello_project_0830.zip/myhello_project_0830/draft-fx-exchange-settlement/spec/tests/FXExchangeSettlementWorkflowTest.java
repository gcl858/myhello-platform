package com.example.platform.distribution.transfer;

import io.quarkus.test.junit.QuarkusTest;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.*;

@QuarkusTest
public class FXExchangeSettlementWorkflowTest {

    private static final String PARENT_URL = "/fx_exchange_settlement";

    @Test
    @DisplayName("[P1] 參數檢核失敗 (operationType=C) -> 400 REJECTED_VALIDATION")
    void testP1InvalidOpType() {
        String seq = "FX_P1_" + System.nanoTime();
        String payload = "{\n" +
                "  \"partyId\":\"A123456789\",\"fromAccountId\":\"00701234567890\",\n" +
                "  \"currencyCode\":\"USD\",\"toAccountId\":\"00709876543210\",\n" +
                "  \"transactionDate\":\"20260830\",\"transactionDateTime\":\"10300000\",\n" +
                "  \"channelCode\":\"APP01\",\"operationType\":\"C\",\n" +
                "  \"amount\":\"0000030000\",\"sequenceNumber\":\"" + seq + "\"\n" +
                "}";

        given()
            .contentType("application/json")
            .body(payload)
        .when()
            .post(PARENT_URL)
        .then()
            .statusCode(400)
            .body("finalStatus", equalTo("REJECTED_VALIDATION"));
    }

    @Test
    @DisplayName("[A1] 正向結匯換匯正常成功 (WF-A) -> 200 SUCCESS")
    void testA1ExchangeSuccess() {
        String seq = "FX_A1_" + System.nanoTime();
        String payload = "{\n" +
                "  \"partyId\":\"A123456789\",\"fromAccountId\":\"00701234567890\",\n" +
                "  \"currencyCode\":\"USD\",\"toAccountId\":\"00709876543210\",\n" +
                "  \"transactionDate\":\"20260830\",\"transactionDateTime\":\"10300000\",\n" +
                "  \"channelCode\":\"APP01\",\"operationType\":\"A\",\n" +
                "  \"amount\":\"0000030000\",\"sequenceNumber\":\"" + seq + "\"\n" +
                "}";

        given()
            .contentType("application/json")
            .body(payload)
        .when()
            .post(PARENT_URL)
        .then()
            .statusCode(200)
            .body("finalStatus", equalTo("SUCCESS"))
            .body("coreDebitResult.status", equalTo(0))
            .body("fxSettleResult.status", equalTo(0));
    }

    @Test
    @DisplayName("[P4] Parent 級冪等重送 -> 200 IDEMPOTENT_REPLAY")
    void testP4Idempotency() {
        String seq = "FX_P4_" + System.nanoTime();
        String payload = "{\n" +
                "  \"partyId\":\"A123456789\",\"fromAccountId\":\"00701234567890\",\n" +
                "  \"currencyCode\":\"USD\",\"toAccountId\":\"00709876543210\",\n" +
                "  \"transactionDate\":\"20260830\",\"transactionDateTime\":\"10300000\",\n" +
                "  \"channelCode\":\"APP01\",\"operationType\":\"A\",\n" +
                "  \"amount\":\"0000030000\",\"sequenceNumber\":\"" + seq + "\"\n" +
                "}";

        given().contentType("application/json").body(payload).when().post(PARENT_URL).then().statusCode(200).body("finalStatus", equalTo("SUCCESS"));
        given().contentType("application/json").body(payload).when().post(PARENT_URL).then().statusCode(200).body("finalStatus", equalTo("IDEMPOTENT_REPLAY"));
    }

    @Test
    @DisplayName("[B1] 當日換匯沖正成功 -> 200 CANCELLED")
    void testB1ReversalSuccess() {
        String origSeq = "FX_ORIG_" + System.nanoTime();
        String setupPayload = "{\n" +
                "  \"partyId\":\"A123456789\",\"fromAccountId\":\"00701234567890\",\n" +
                "  \"currencyCode\":\"USD\",\"toAccountId\":\"00709876543210\",\n" +
                "  \"transactionDate\":\"20260830\",\"transactionDateTime\":\"10300000\",\n" +
                "  \"channelCode\":\"APP01\",\"operationType\":\"A\",\n" +
                "  \"amount\":\"0000030000\",\"sequenceNumber\":\"" + origSeq + "\"\n" +
                "}";

        given().contentType("application/json").body(setupPayload).when().post(PARENT_URL).then().statusCode(200).body("finalStatus", equalTo("SUCCESS"));

        String revSeq = "FX_R_" + System.nanoTime();
        String revPayload = "{\n" +
                "  \"partyId\":\"A123456789\",\"fromAccountId\":\"00701234567890\",\n" +
                "  \"currencyCode\":\"USD\",\"toAccountId\":\"00709876543210\",\n" +
                "  \"transactionDate\":\"20260830\",\"transactionDateTime\":\"10350000\",\n" +
                "  \"channelCode\":\"APP01\",\"operationType\":\"B\",\n" +
                "  \"amount\":\"0000030000\",\"sequenceNumber\":\"" + revSeq + "\",\n" +
                "  \"originalSequenceNumber\":\"" + origSeq + "\"\n" +
                "}";

        given()
            .contentType("application/json")
            .body(revPayload)
        .when()
            .post(PARENT_URL)
        .then()
            .statusCode(200)
            .body("finalStatus", equalTo("CANCELLED"));
    }

    @Test
    @DisplayName("[B2] 沖正查無原交易紀錄 -> 500 LOOKUP_FAILED")
    void testB2LookupFailed() {
        String revSeq = "FX_R_" + System.nanoTime();
        String revPayload = "{\n" +
                "  \"partyId\":\"A123456789\",\"fromAccountId\":\"00701234567890\",\n" +
                "  \"currencyCode\":\"USD\",\"toAccountId\":\"00709876543210\",\n" +
                "  \"transactionDate\":\"20260830\",\"transactionDateTime\":\"10350000\",\n" +
                "  \"channelCode\":\"APP01\",\"operationType\":\"B\",\n" +
                "  \"amount\":\"0000030000\",\"sequenceNumber\":\"" + revSeq + "\",\n" +
                "  \"originalSequenceNumber\":\"FX_NONEXIST_99999\"\n" +
                "}";

        given()
            .contentType("application/json")
            .body(revPayload)
        .when()
            .post(PARENT_URL)
        .then()
            .statusCode(500)
            .body("finalStatus", equalTo("LOOKUP_FAILED"));
    }
}
