package org.acme.transfer.api.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class CoreFXRequest {
    @JsonProperty("partyId")
    public String partyId;
    @JsonProperty("fromAccountId")
    public String fromAccountId;
    @JsonProperty("operationType")
    public String operationType;
    @JsonProperty("amount")
    public String amount;
    @JsonProperty("sequenceNumber")
    public String sequenceNumber;

    public CoreFXRequest() {}
}
