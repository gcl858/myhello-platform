package org.acme.transfer.api.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

public class CoreFXResponse {
    @JsonProperty("status")
    public int status;
    @JsonProperty("message")
    public String message;
    @JsonProperty("track_id")
    public String trackId;

    public CoreFXResponse() {}
    public CoreFXResponse(int status, String message, String trackId) {
        this.status = status;
        this.message = message;
        this.trackId = trackId;
    }
}
