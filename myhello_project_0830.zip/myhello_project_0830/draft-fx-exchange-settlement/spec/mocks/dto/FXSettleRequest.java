package org.acme.transfer.api.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class FXSettleRequest {
    @JsonProperty("partyId")
    public String partyId;
    @JsonProperty("currencyCode")
    public String currencyCode;
    @JsonProperty("toAccountId")
    public String toAccountId;
    @JsonProperty("operationType")
    public String operationType;
    @JsonProperty("amount")
    public String amount;
    @JsonProperty("sequenceNumber")
    public String sequenceNumber;

    public FXSettleRequest() {}
}
