package org.acme.transfer.api;

import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import org.acme.transfer.api.dto.FXSettleRequest;
import org.acme.transfer.api.dto.FXSettleResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.UUID;

@Path("/FXEngine/{partyId}/Settle/Execute")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class FXEngineSettleResource {
    private static final Logger LOG = LoggerFactory.getLogger(FXEngineSettleResource.class);

    @POST
    public Response execute(@PathParam("partyId") String partyId, FXSettleRequest request) {
        LOG.info("[Mock FXEngine] partyId={}, currency={}, opType={}, amount={}", partyId, request != null ? request.currencyCode : null, request != null ? request.operationType : null, request != null ? request.amount : null);
        if (request != null && request.amount != null && request.amount.startsWith("FAIL_FX")) {
            return Response.status(400).entity(new FXSettleResponse(1, "外匯撮合限額超限清算失敗", "fx-err-" + UUID.randomUUID().toString().substring(0, 8))).build();
        }
        return Response.ok(new FXSettleResponse(0, "外匯撮合清算成功", "fx-set-" + UUID.randomUUID().toString().substring(0, 8))).build();
    }
}
