package org.acme.transfer.api;

import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import org.acme.transfer.api.dto.CoreFXRequest;
import org.acme.transfer.api.dto.CoreFXResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.UUID;

@Path("/CoreFX/{partyId}/DebitCredit/Execute")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class CoreFXAccountResource {
    private static final Logger LOG = LoggerFactory.getLogger(CoreFXAccountResource.class);

    @POST
    public Response execute(@PathParam("partyId") String partyId, CoreFXRequest request) {
        LOG.info("[Mock CoreFX] partyId={}, opType={}, amount={}", partyId, request != null ? request.operationType : null, request != null ? request.amount : null);
        if (request != null && request.amount != null && request.amount.startsWith("FAIL_CORE")) {
            return Response.status(400).entity(new CoreFXResponse(1, "核心餘額不足扣款失敗", "core-err-" + UUID.randomUUID().toString().substring(0, 8))).build();
        }
        return Response.ok(new CoreFXResponse(0, "核心處理成功", "core-fx-" + UUID.randomUUID().toString().substring(0, 8))).build();
    }
}
