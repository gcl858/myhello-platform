CREATE VIEW IF NOT EXISTS vw_fund_investment_order_reconciliation AS
SELECT
    id,
    created_at,
    workflow_id,
    business_key,
    process_instance_id,
    status,
    message,
    json_extract(input_data, '$.partyId') AS party_id,
    json_extract(input_data, '$.fundCode') AS fund_code,
    json_extract(input_data, '$.fromAccountId') AS from_account_id,
    json_extract(input_data, '$.currencyCode') AS currency_code,
    json_extract(input_data, '$.operationType') AS operation_type,
    json_extract(input_data, '$.amount') AS amount,
    cancelled_by,
    cancelled_at
FROM workflow_execution_log
WHERE workflow_id IN ('fund_investment_order', 'fund_order_subscribe', 'fund_order_cancellation');
