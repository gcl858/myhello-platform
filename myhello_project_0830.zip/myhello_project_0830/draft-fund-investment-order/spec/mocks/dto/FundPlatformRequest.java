package org.acme.transfer.api.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class FundPlatformRequest {
    @JsonProperty("partyId")
    public String partyId;
    @JsonProperty("fundCode")
    public String fundCode;
    @JsonProperty("currencyCode")
    public String currencyCode;
    @JsonProperty("operationType")
    public String operationType;
    @JsonProperty("amount")
    public String amount;
    @JsonProperty("sequenceNumber")
    public String sequenceNumber;

    public FundPlatformRequest() {}
}
