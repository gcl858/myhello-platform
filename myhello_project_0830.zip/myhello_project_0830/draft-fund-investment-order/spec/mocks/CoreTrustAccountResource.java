package org.acme.transfer.api;

import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import org.acme.transfer.api.dto.CoreTrustRequest;
import org.acme.transfer.api.dto.CoreTrustResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.UUID;

@Path("/CoreTrust/{partyId}/DebitCredit/Execute")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class CoreTrustAccountResource {
    private static final Logger LOG = LoggerFactory.getLogger(CoreTrustAccountResource.class);

    @POST
    public Response execute(@PathParam("partyId") String partyId, CoreTrustRequest request) {
        LOG.info("[Mock CoreTrust] partyId={}, account={}, currency={}, opType={}, amount={}", partyId, request != null ? request.fromAccountId : null, request != null ? request.currencyCode : null, request != null ? request.operationType : null, request != null ? request.amount : null);
        if (request != null && request.amount != null && request.amount.startsWith("FAIL_TRUST")) {
            return Response.status(400).entity(new CoreTrustResponse(1, "信託活存餘額不足扣款失敗", "trust-err-" + UUID.randomUUID().toString().substring(0, 8))).build();
        }
        return Response.ok(new CoreTrustResponse(0, "信託帳戶處理成功", "trust-tx-" + UUID.randomUUID().toString().substring(0, 8))).build();
    }
}
