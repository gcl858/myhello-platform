package org.acme.transfer.api;

import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import org.acme.transfer.api.dto.FundPlatformRequest;
import org.acme.transfer.api.dto.FundPlatformResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.UUID;

@Path("/FundPlatform/{partyId}/Order/Execute")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class FundPlatformOrderResource {
    private static final Logger LOG = LoggerFactory.getLogger(FundPlatformOrderResource.class);

    @POST
    public Response execute(@PathParam("partyId") String partyId, FundPlatformRequest request) {
        LOG.info("[Mock FundPlatform] partyId={}, fundCode={}, currency={}, opType={}, amount={}", partyId, request != null ? request.fundCode : null, request != null ? request.currencyCode : null, request != null ? request.operationType : null, request != null ? request.amount : null);
        if (request != null && request.amount != null && request.amount.startsWith("FAIL_FUND")) {
            return Response.status(400).entity(new FundPlatformResponse(1, "基金下單撮合失敗(市場閉市或額度超限)", "fund-err-" + UUID.randomUUID().toString().substring(0, 8))).build();
        }
        return Response.ok(new FundPlatformResponse(0, "基金平台下單成功", "fund-plt-" + UUID.randomUUID().toString().substring(0, 8))).build();
    }
}
