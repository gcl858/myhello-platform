# Draft Specification: Fund Investment Order & Cancellation

## §0 核心決策
- 採用 Mode B 階層式架構 (Parent + 2 Child Subflows)
- 雙軌制狀態碼: status (0/1) + finalStatus (STRING)

## §1 業務與架構說明
- Parent: `fund_investment_order`
- Child WF-A: `fund_order_subscribe`
- Child WF-B: `fund_order_cancellation`

## §2 平台預檢與自檢
- 6 項預檢全數通過
- 21 項自檢全數通過
