package com.example.platform.distribution.transfer;

import io.quarkus.test.junit.QuarkusTest;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.notNullValue;
import static org.junit.jupiter.api.Assertions.assertTrue;

@QuarkusTest
@DisplayName("interbank_fund_transfer Parent + Child 測試")
public class InterbankFundTransferWorkflowTest {

    private static final String PARENT_URL = "/interbank_fund_transfer";

    @Test
    @DisplayName("[P1] operationType=C 無效值 -> 400 REJECTED_VALIDATION")
    void testP1InvalidOpType() {
        String seq = "IB_P1_" + System.nanoTime();
        String payload = "{\n" +
                "  \"partyId\":\"A123456789\",\"fromAccountId\":\"00701234567890\",\n" +
                "  \"toBankCode\":\"822\",\"toAccountId\":\"98765432109876\",\n" +
                "  \"transactionDate\":\"20260830\",\"transactionDateTime\":\"10000000\",\n" +
                "  \"channelCode\":\"APP01\",\"operationType\":\"C\",\n" +
                "  \"amount\":\"0000050000\",\"sequenceNumber\":\"" + seq + "\"\n" +
                "}";
        given()
            .contentType("application/json")
            .body(payload)
        .when()
            .post(PARENT_URL)
        .then()
            .statusCode(400)
            .body("finalStatus", equalTo("REJECTED_VALIDATION"));
    }

    @Test
    @DisplayName("[A1] 正常跨行轉帳 -> 200 SUCCESS (Core+FISC 皆成功)")
    void testA1TransferSuccess() {
        String seq = "IB_A1_" + System.nanoTime();
        String payload = "{\n" +
                "  \"partyId\":\"A123456789\",\"fromAccountId\":\"00701234567890\",\n" +
                "  \"toBankCode\":\"822\",\"toAccountId\":\"98765432109876\",\n" +
                "  \"transactionDate\":\"20260830\",\"transactionDateTime\":\"10000000\",\n" +
                "  \"channelCode\":\"APP01\",\"operationType\":\"A\",\n" +
                "  \"amount\":\"0000050000\",\"sequenceNumber\":\"" + seq + "\"\n" +
                "}";
        given()
            .contentType("application/json")
            .body(payload)
        .when()
            .post(PARENT_URL)
        .then()
            .statusCode(200)
            .body("finalStatus", equalTo("SUCCESS"))
            .body("workflow", equalTo("INTERBANK_TRANSFER"))
            .body("status", equalTo(0));
    }

    @Test
    @DisplayName("[P4] Parent 級冪等重送 -> 200 IDEMPOTENT_REPLAY")
    void testP4Idempotency() {
        String seq = "IB_P4_" + System.nanoTime();
        String payload = "{\n" +
                "  \"partyId\":\"A123456789\",\"fromAccountId\":\"00701234567890\",\n" +
                "  \"toBankCode\":\"822\",\"toAccountId\":\"98765432109876\",\n" +
                "  \"transactionDate\":\"20260830\",\"transactionDateTime\":\"10000000\",\n" +
                "  \"channelCode\":\"APP01\",\"operationType\":\"A\",\n" +
                "  \"amount\":\"0000050000\",\"sequenceNumber\":\"" + seq + "\"\n" +
                "}";

        given().contentType("application/json").body(payload).when().post(PARENT_URL).then().statusCode(200).body("finalStatus", equalTo("SUCCESS"));
        given().contentType("application/json").body(payload).when().post(PARENT_URL).then().statusCode(200).body("finalStatus", equalTo("IDEMPOTENT_REPLAY"));
    }

    @Test
    @DisplayName("[B1] 當日跨行沖正成功 -> 200 CANCELLED")
    void testB1ReversalSuccess() {
        String origSeq = "IB_ORIG_" + System.nanoTime();
        String setupPayload = "{\n" +
                "  \"partyId\":\"A123456789\",\"fromAccountId\":\"00701234567890\",\n" +
                "  \"toBankCode\":\"822\",\"toAccountId\":\"98765432109876\",\n" +
                "  \"transactionDate\":\"20260830\",\"transactionDateTime\":\"10000000\",\n" +
                "  \"channelCode\":\"APP01\",\"operationType\":\"A\",\n" +
                "  \"amount\":\"0000050000\",\"sequenceNumber\":\"" + origSeq + "\"\n" +
                "}";
        given().contentType("application/json").body(setupPayload).when().post(PARENT_URL).then().statusCode(200).body("finalStatus", equalTo("SUCCESS"));

        String revSeq = "IB_R_" + System.nanoTime();
        String revPayload = "{\n" +
                "  \"partyId\":\"A123456789\",\"fromAccountId\":\"00701234567890\",\n" +
                "  \"toBankCode\":\"822\",\"toAccountId\":\"98765432109876\",\n" +
                "  \"transactionDate\":\"20260830\",\"transactionDateTime\":\"10050000\",\n" +
                "  \"channelCode\":\"APP01\",\"operationType\":\"B\",\n" +
                "  \"amount\":\"0000050000\",\"sequenceNumber\":\"" + revSeq + "\",\n" +
                "  \"originalSequenceNumber\":\"" + origSeq + "\"\n" +
                "}";
        given().contentType("application/json").body(revPayload).when().post(PARENT_URL).then().statusCode(200).body("finalStatus", equalTo("CANCELLED"));
    }

    @Test
    @DisplayName("[B2] 查無原交易沖正 -> 500 LOOKUP_FAILED")
    void testB2LookupFailed() {
        String revSeq = "IB_R_" + System.nanoTime();
        String revPayload = "{\n" +
                "  \"partyId\":\"A123456789\",\"fromAccountId\":\"00701234567890\",\n" +
                "  \"toBankCode\":\"822\",\"toAccountId\":\"98765432109876\",\n" +
                "  \"transactionDate\":\"20260830\",\"transactionDateTime\":\"10050000\",\n" +
                "  \"channelCode\":\"APP01\",\"operationType\":\"B\",\n" +
                "  \"amount\":\"0000050000\",\"sequenceNumber\":\"" + revSeq + "\",\n" +
                "  \"originalSequenceNumber\":\"IB_NONEXIST_99999\"\n" +
                "}";
        given().contentType("application/json").body(revPayload).when().post(PARENT_URL).then().statusCode(500).body("finalStatus", equalTo("LOOKUP_FAILED"));
    }
}
