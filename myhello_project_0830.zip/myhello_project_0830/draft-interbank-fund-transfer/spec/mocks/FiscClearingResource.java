package org.acme.transfer.api;

import org.acme.transfer.api.dto.FiscClearingRequest;
import org.acme.transfer.api.dto.FiscClearingResponse;
import org.acme.transfer.api.dto.ErrorDetail;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.Collections;
import java.util.UUID;

@Path("/FISC/{fromAccountId}/Clearing/Execute")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public class FiscClearingResource {

    @POST
    public Response execute(@PathParam("fromAccountId") String fromAccountId, FiscClearingRequest request) {
        FiscClearingResponse resp = new FiscClearingResponse();
        resp.track_id = "fisc-tx-" + UUID.randomUUID().toString().substring(0, 8);

        if (request != null && request.amount != null && request.amount.startsWith("FISC_FAIL")) {
            resp.status = 1;
            resp.message = "財金跨行清算拒絕";
            resp.errors = Collections.singletonList(new ErrorDetail("F0002", "跨行清算失敗"));
            return Response.status(403).entity(resp).build();
        }

        resp.status = 0;
        resp.message = "跨行清算成功";
        return Response.ok(resp).build();
    }
}
