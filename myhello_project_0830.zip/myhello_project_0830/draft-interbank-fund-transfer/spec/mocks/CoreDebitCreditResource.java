package org.acme.transfer.api;

import org.acme.transfer.api.dto.CoreDebitRequest;
import org.acme.transfer.api.dto.CoreDebitResponse;
import org.acme.transfer.api.dto.ErrorDetail;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.Collections;
import java.util.UUID;

@Path("/CoreAccount/{fromAccountId}/Debit/Execute")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public class CoreDebitCreditResource {

    @POST
    public Response execute(@PathParam("fromAccountId") String fromAccountId, CoreDebitRequest request) {
        CoreDebitResponse resp = new CoreDebitResponse();
        resp.track_id = "core-deb-" + UUID.randomUUID().toString().substring(0, 8);

        if (request != null && request.amount != null && request.amount.startsWith("FAIL")) {
            resp.status = 1;
            resp.message = "餘額不足扣款失敗";
            resp.errors = Collections.singletonList(new ErrorDetail("E0011", "餘額不足"));
            return Response.status(403).entity(resp).build();
        }

        resp.status = 0;
        resp.message = "A".equals(request != null ? request.operationType : "") ? "扣款成功" : "沖正退款成功";
        return Response.ok(resp).build();
    }
}
