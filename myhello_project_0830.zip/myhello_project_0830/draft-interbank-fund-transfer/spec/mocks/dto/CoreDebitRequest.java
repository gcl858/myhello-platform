package org.acme.transfer.api.dto;
public class CoreDebitRequest {
    public String partyId;
    public String fromAccountId;
    public String operationType;
    public String amount;
    public String sequenceNumber;
}
