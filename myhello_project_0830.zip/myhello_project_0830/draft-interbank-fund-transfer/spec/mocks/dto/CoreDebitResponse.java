package org.acme.transfer.api.dto;
import java.util.List;
public class CoreDebitResponse {
    public String track_id;
    public int status;
    public String message;
    public List<ErrorDetail> errors;
}
