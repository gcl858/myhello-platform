package org.acme.transfer.api.dto;
public class FiscClearingRequest {
    public String fromAccountId;
    public String toBankCode;
    public String toAccountId;
    public String operationType;
    public String amount;
    public String sequenceNumber;
}
