CREATE VIEW IF NOT EXISTS vw_interbank_fund_transfer_reconciliation AS
SELECT
    id,
    created_at,
    workflow_id,
    business_key,
    process_instance_id,
    status,
    message,
    json_extract(input_data, '$.partyId') AS party_id,
    json_extract(input_data, '$.fromAccountId') AS from_account_id,
    json_extract(input_data, '$.toBankCode') AS to_bank_code,
    json_extract(input_data, '$.toAccountId') AS to_account_id,
    json_extract(input_data, '$.operationType') AS operation_type,
    json_extract(input_data, '$.amount') AS amount,
    cancelled_by,
    cancelled_at
FROM workflow_execution_log
WHERE workflow_id IN ('interbank_fund_transfer', 'interbank_transfer_out', 'interbank_transfer_reversal');
