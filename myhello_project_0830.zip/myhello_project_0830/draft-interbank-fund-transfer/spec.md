# Interbank Fund Transfer - Spec v1.0

> 設計模式: Mode B (Parent + 2 Child Subflows)
> Convention: status 0/1 (int) + finalStatus (string)

## §0 假設清單
| # | 假設 | 為何這樣假設 | 待確認問題 | 落地策略 |
|---|---|---|---|---|
| H1 | 輸入 11 欄位 | 業務書 §2 | — | spec/schemas/interbank-input-schema.json |
| H2 | finalStatus 10 種 | 業務書 §3 | — | status-rewrite config |
| H3 | ID 命名: snake_case (interbank_fund_transfer) | 規避 Kogito 10.2.0 codegen bug | — | 全 workflow YAML |
| H4 | FQCN: `IdempotencyService::findBySequenceNumber` | Parent 冪等服務 | — | Java Service |
| H5 | FQCN: `AuditLogService::saveLog` | 審計服務 | — | Java Service |
| H6 | FQCN: `AuditLogService::findBySequenceNumber` | 沖正 Lookup 服務 | — | Java Service |
| H7 | FQCN: `AuditLogService::markCancelledBy` | 沖正標記服務 | — | Java Service |

## §8 Project Mapping Manifest
- `spec/interbank_fund_transfer.sw.yaml` -> `domain-transfer/transfer-workflow/src/main/resources/interbank-fund-transfer.sw.yaml`
- `spec/interbank_transfer_out.sw.yaml` -> `domain-transfer/transfer-workflow/src/main/resources/interbank-transfer-out.sw.yaml`
- `spec/interbank_transfer_reversal.sw.yaml` -> `domain-transfer/transfer-workflow/src/main/resources/interbank-transfer-reversal.sw.yaml`
- `spec/mocks/*.java` -> `dev/transfer-mock/src/main/java/org/acme/transfer/api/`
- `spec/db/*.sql` -> `domain-transfer/transfer-workflow/src/main/resources/db/migration/`
- `spec/tests/*.java` -> `distribution/transfer-app/src/test/java/com/example/platform/distribution/transfer/`

## §9 已知限制
- 跨行外匯結匯流程由外匯模組另案處理。
