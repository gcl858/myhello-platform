# Reference 05: YAML 語法嚴格性

> 對應 SKILL.md Step 6.5 預檢
> 來源:`INTEGRATION-PRACTICE.md` 問題 3 (小陷阱)

---

## 規則

Kogito codegen 對 YAML 格式嚴格,**任何 list item 後的 trailing comma 必報錯**。

---

## 症狀

```
[ERROR] expected <block end>, but found ','
```

通常出現在:

```yaml
# ❌ 錯:list item 後有 trailing comma
functions:
  - name: callApiViaOpenAPI,
    operation: 'service:com.example.MyService::method',
    type: custom,

# ❌ 錯:在 arguments 內有 trailing comma
arguments:
  payload:
    partyId: '${ .partyId }',
    amount: '${ .amount }',
```

---

## 自動檢查腳本

```bash
#!/bin/bash
# 用途:Step 6.5 預檢 — 抓出所有 list item 結尾的 trailing comma

set -e
FAIL=0

# 規則:縮排空白 + key: value + 結尾的 `,` 是錯的
# 範例: "        partyId: '${ .partyId }',"

for f in draft/spec/*.sw.yaml; do
  bad=$(grep -E "^\s+\w+:\s+'[^']*',$" "$f")
  if [ -n "$bad" ]; then
    echo "❌ FAIL: $f"
    echo "$bad" | while read line; do
      echo "   → $line"
    done
    echo "   解法:移除行尾的 ,"
    FAIL=1
  fi
done

exit $FAIL
```

---

## 為何 Kogito codegen 對 trailing comma 嚴格?

Kogito 內部用 SnakeYAML 解析,但對應的 schema validator 用 JSON Schema,而 JSON Schema 不接受 trailing comma。

YAML 本身允許 trailing comma (因為 YAML 不是 JSON),但 Kogito 在 codegen 時會先把 YAML 轉成內部資料結構,然後再驗證,這中間某個步驟會把 YAML 視為 JSON-like 處理,所以報錯。

---

## 常見場景:複製貼上時出錯

從 OpenAPI spec 複製到 workflow YAML 的 payload 區段時,容易保留原 spec 的 trailing comma:

```yaml
# OpenAPI spec (YAML 允許,但 Kogito 不允許)
requestBody:
  content:
    application/json:
      schema:
        properties:
          partyId: { type: string },   # YAML 允許
          amount: { type: string }     # 最後一個 (無 comma)

# → 直接複製到 workflow arguments
arguments:
  payload:
    partyId: '${ .partyId }',         # ❌ Kogito 不允許
    amount: '${ .amount }'            # 對
```

**解法**:複製後跑上述自動檢查腳本,或手動移除所有行尾 comma。

---

## 其他 YAML 陷阱

| 陷阱 | 範例 | 解法 |
|---|---|---|
| Tab vs Space | 用 tab 縮排 | 統一用 2 或 4 個 space |
| 特殊字元未 escape | `'${ .amount }'` 中的 `$` | 用單引號包住整個字串 |
| 多行字串 | `|` 換 `>` 的差異 | `\|` 保留換行,`>` fold 換行成 space |
| 數字 vs 字串 | `amount: 1000` (int) | 業務上是字串就 `'1000'` |
| 布林陷阱 | `isActive: yes` | YAML 1.1 `yes/no` 是布林,1.2 改用 `true/false` |
