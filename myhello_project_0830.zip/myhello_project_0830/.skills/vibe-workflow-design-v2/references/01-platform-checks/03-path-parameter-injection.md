# Reference 03: Path Parameter 自動注入

> 對應 SKILL.md Step 6.3 預檢
> 來源:`INTEGRATION-PRACTICE.md` 問題 3

---

## 規則

任何 `callApiViaOpenAPI` 動作呼叫的 spec,若 operation 內有 `parameters: [in: path]`,**必須**在 payload 內顯式提供對應 key。

---

## 自動檢查腳本

```bash
#!/bin/bash
# 用途:Step 6.3 預檢 — 自動掃描所有 callApiViaOpenAPI,確認 path param 有對應 payload
# 邏輯:
#   1. 從 workflow YAML 抓出所有 schemaRef
#   2. 從對應 OpenAPI spec 抓出每個 operation 的 path params
#   3. 確認 workflow 的 payload 內有對應 key

set -e
FAIL=0
DRAFT_ROOT="$1"

if [ -z "$DRAFT_ROOT" ]; then
  echo "Usage: $0 <draft-root>"
  exit 2
fi

# 抓所有 callApiViaOpenAPI 的 schemaRef
for yaml in "$DRAFT_ROOT"/spec/*.sw.yaml; do
  # 抓 schemaRef
  schema_refs=$(grep "schemaRef:" "$yaml" | sed -E "s/.*schemaRef: '([^']+)'.*/\1/")
  for ref in $schema_refs; do
    # 解析 spec file 與 operationId
    spec_file=$(echo "$ref" | cut -d'#' -f1)
    op_id=$(echo "$ref" | cut -d'#' -f2)
    spec_path="$DRAFT_ROOT/$spec_file"

    if [ ! -f "$spec_path" ]; then
      echo "❌ FAIL: $yaml 引用了不存在的 spec: $spec_path"
      FAIL=1
      continue
    fi

    # 從 spec 抓 path params
    path_params=$(python3 -c "
import yaml, sys
with open('$spec_path') as f:
    s = yaml.safe_load(f)
for path, methods in s.get('paths', {}).items():
    for m, op in methods.items():
        if op.get('operationId') == '$op_id':
            for p in op.get('parameters', []):
                if p.get('in') == 'path':
                    print(p['name'])
")

    # 確認 payload 內有對應 key
    for param in $path_params; do
      # 抓這個 operation 對應的 payload 區段
      payload_block=$(awk "/schemaRef: '$ref'/,/^        [a-z]/ { if (/schemaRef: '$ref'/) flag=1; if (flag) print; if (flag && /^[a-z]/) exit }" "$yaml" | grep -A 30 "payload:" | head -30)
      if echo "$payload_block" | grep -qE "^\s+${param}:"; then
        echo "✅ $yaml → $op_id: path param '$param' 在 payload 內"
      else
        echo "❌ FAIL: $yaml → $op_id: 缺少 path param '$param' 在 payload"
        echo "   解法:在 payload 內加 ${param}: '\${ .對應欄位 }'"
        FAIL=1
      fi
    done
  done
done

exit $FAIL
```

---

## 範例:對的寫法

OpenAPI spec:

```yaml
/CoreAccount/{creditcardid}/CashDeposit/Execute:
  post:
    operationId: executeCoreCashDeposit
    parameters:
      - name: creditcardid
        in: path                  # ⭐ path param
        required: true
        schema:
          type: string
```

對應 workflow YAML:

```yaml
- functionRef:
    refName: callApiViaOpenAPI
    arguments:
      functionName: "callApiViaOpenAPI"
      schemaRef: 'specs/core-account-cash-deposit-api.yaml#executeCoreCashDeposit'
      payload:
        creditcardid: '${ .partyId }'    # ⭐ 必顯式帶
        partyId: '${ .partyId }'
        branchCode: '${ .branchCode }'
        amount: '${ .amount }'
        sequenceNumber: '${ .sequenceNumber }'
        operationType: '${ .operationType }'
```

---

## 症狀:沒帶 path param 會怎樣?

```
ERROR ... 目標路徑有不合法的字元:
http://localhost:8080/CoreAccount/{creditcardid}/CashDeposit/Execute
```

`MyOpenApiService` 把 `{creditcardid}` 留作字面值,沒替換成實際值 → HTTP client 拒絕傳送。

---

## 為何 MyOpenApiService 不自動從 payload 抓 path param?

理論上可行 (從 spec 解析 path,看哪些是 `{xxx}`,然後從 payload 抓 `xxx` 對應值),但有兩個原因不做:

1. **效能**:每次都要解析 spec,影響 latency
2. **明確性**:workflow author 應該明確知道哪些欄位會被用於 URL,不該「魔法」自動綁定

所以這個責任放在 workflow author,必須在 payload 顯式帶。

---

## 對應值怎麼選?

從 input data 推導。常見對應:

| Path param | 通常對應 input 欄位 |
|---|---|
| `{creditcardid}` | `.partyId` 或 `.customerId` |
| `{orderId}` | `.orderId` |
| `{userId}` | `.userId` |
| `{accountId}` | `.accountId` |
| `{transactionId}` | `.sequenceNumber` 或 `.originalSequenceNumber` |

若有疑慮,看 input schema 哪個欄位語意最接近,或問業務方。
