# Reference 04: stateDataFilter Output Convention 對齊

> 對應 SKILL.md Step 3d + Step 6.4 預檢
> 來源:`INTEGRATION-PRACTICE.md` 問題 2

---

## 3 種 Convention

### 舊 Convention (saga2-transfer-workflow 風格)

```yaml
stateDataFilter:
  output: |
    {
      status: .finalStatus,
      message: .finalMessage
    }
```

- `status` 是 STRING
- 直接對應 finalStatus 值
- 適用於舊有 `WorkflowStatusFilter` 只讀 `status` 欄位

### 新 Convention (omni-cash-transaction 風格) ⭐ 推薦

```yaml
stateDataFilter:
  output: |
    {
      track_id: .<key_field>,
      workflow: (.operationType == "A" ? "REPAYMENT" : "CANCELLATION"),
      status: (if .finalStatus in ["SUCCESS", "CANCELLED", "IDEMPOTENT_REPLAY"] then 0 else 1 end),
      finalStatus: .finalStatus,
      message: .finalMessage,
      coreResult: (.coreResult // null),
      ccResult: (.ccResult // null)
    }
```

- `status` 是 INT 0/1
- `finalStatus` 是 STRING (獨立欄位)
- 適用於新版 `WorkflowStatusFilter` 同時讀兩個欄位

### 純 HTTP Status

```yaml
# 不在 stateDataFilter 設 status,完全靠 HTTP code 區分
stateDataFilter:
  output: |
    {
      message: .finalMessage
    }
```

- 適用於簡單的 GET/POST,對外契約不需 finalStatus

---

## 對應 platform-security 行為

| Convention | WorkflowStatusFilter 行為 | application.properties |
|---|---|---|
| 舊 | 讀 `status` (string) → 查 mapping → 改 HTTP code | `status-rewrite.workflows` + `mapping` |
| 新 | 讀 `finalStatus` (string) → 查 mapping → 改 HTTP code | `status-rewrite.workflows` + `mapping` |
| 純 HTTP | 不啟用 status-rewrite | 無 |

**新舊 filter 程式碼差異** (見 `INTEGRATION-PRACTICE.md` 問題 2):

```java
// 舊 filter
Object status = map.get("status");

// 新 filter (向後相容)
Object status = map.get("finalStatus");
if (status == null) {
    status = map.get("status");   // 向下相容舊 transfer 體系
}
if (status != null && status instanceof String) {  // 只對 String 做映射
    Integer rewrite = statusRewriteMap.get(status.toString());
    if (rewrite != null) {
        responseContext.setStatus(rewrite);
    }
}
```

---

## 自動檢查腳本

```bash
#!/bin/bash
# 用途:Step 6.4 預檢 — stateDataFilter.output 是否含正確欄位
# 依選定 convention 檢查

CONVENTION="${1:-new}"  # 預設 new

set -e
FAIL=0

for f in draft/spec/*.sw.yaml; do
  if grep -q "stateDataFilter" "$f"; then
    case "$CONVENTION" in
      old)
        if ! grep -A 10 "stateDataFilter" "$f" | grep -q "status:"; then
          echo "❌ FAIL: $f (舊 convention 須含 status: .finalStatus)"
          FAIL=1
        fi
        if grep -A 10 "stateDataFilter" "$f" | grep -q "finalStatus:"; then
          echo "❌ FAIL: $f (舊 convention 不應含 finalStatus:)"
          FAIL=1
        fi
        ;;
      new)
        if ! grep -A 20 "stateDataFilter" "$f" | grep -E "status:.*0|status:.*1" > /dev/null; then
          echo "❌ FAIL: $f (新 convention 須含 status: (if ... then 0 else 1 end))"
          FAIL=1
        fi
        if ! grep -A 20 "stateDataFilter" "$f" | grep -q "finalStatus:"; then
          echo "❌ FAIL: $f (新 convention 須含 finalStatus: .finalStatus)"
          FAIL=1
        fi
        ;;
      http-only)
        if grep -A 20 "stateDataFilter" "$f" | grep -q "status:"; then
          echo "❌ FAIL: $f (純 HTTP convention 不應在 stateDataFilter 設 status)"
          FAIL=1
        fi
        ;;
    esac
  fi
done

exit $FAIL
```

---

## spec.md 標註範本

在 `spec.md §0 假設清單` 加:

```markdown
| H16 | **Convention**: 新 (status 0/1 int + finalStatus string) | 與 credit-card 體系對齊 | — | stateDataFilter.output 強制含兩個欄位 |
```

---

## 對應 application.properties 設定

新 convention 範例 (見 `01-financial-repayment/spec/config/application.properties.snippet`):

```properties
platform.status-rewrite.workflows=omni_cash_transaction,repayment_cash_deposit,repayment_cash_cancellation
platform.status-rewrite.mapping.REJECTED_VALIDATION=400
platform.status-rewrite.mapping.LOOKUP_FAILED=500
platform.status-rewrite.mapping.SYSTEM_UNAVAILABLE=503
platform.status-rewrite.mapping.ROLLBACK_FAILED=409
platform.status-rewrite.mapping.CANCEL_ROLLBACK_FAILED=409
```

**重要**:workflow id 必須用最終 snake_case 名稱,不能用 draft 時的 hyphen 名稱。
