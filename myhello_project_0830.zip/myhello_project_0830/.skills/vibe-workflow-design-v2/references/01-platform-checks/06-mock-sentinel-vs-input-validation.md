# Reference 06: Mock Sentinel vs Input Validation 相容性

> 對應 SKILL.md Step 6.6 預檢
> 來源:`INTEGRATION-PRACTICE.md` 問題 7

---

## 規則

任何 mock 用來觸發「業務拒絕 / 失敗」的 sentinel 字串,**必須能通過 input schema 的 validation**。

---

## 2 種 Sentinel 模式

### 模式 A:業務 payload 內字串前綴

```java
// Mock resource
if (request.amount.startsWith("FAIL_")) {
    return Response.status(403).entity(buildError("E0024", "金額不符", null)).build();
}
```

**前提**:input schema 的 `amount` 欄位 regex 須允許 `FAIL_*`:

```json
"amount": {
  "type": "string",
  "pattern": "^(FAIL_[A-Z0-9_]+|[0-9]+)$"   // ⭐ 允許 FAIL_* 或純數字
}
```

**優點**:測試 payload 簡潔
**缺點**:放寬 regex 可能讓真實攻擊面增加

---

### 模式 B:獨立 sentinel field

```java
// Mock resource
if ("FAIL_AMT".equals(request.__sentinel)) {
    return Response.status(403).entity(buildError("E0024", "金額不符", null)).build();
}
```

對應 input schema 加:

```json
"__sentinel": {
  "type": "string",
  "description": "測試專用哨兵,真實 API 不會傳入"
}
```

**優點**:不汙染業務 regex
**缺點**:每個測試 payload 都要多帶一個欄位

---

## 自動檢查腳本

```bash
#!/bin/bash
# 用途:Step 6.6 預檢 — mock sentinel 字串是否會被 input validation 攔截
# 邏輯:
#   1. 從 mock Java 抓出所有 sentinel 字串 (FAIL_*, RBFAIL, 0, 0000000000 等)
#   2. 對每個 sentinel 驗證它能通過 input schema 的 regex

set -e
FAIL=0
DRAFT_ROOT="$1"

if [ -z "$DRAFT_ROOT" ]; then
  echo "Usage: $0 <draft-root>"
  exit 2
fi

# 抓出 mock 內的所有 sentinel 字串
SENTINELS=$(grep -rh "startsWith\|\"0\"\|\"0000000000\"" "$DRAFT_ROOT"/spec/mocks/ | grep -oE "\"[A-Z_]+\"|\"0+\"" | sort -u)

for sentinel in $SENTINELS; do
  echo "ℹ️  Found mock sentinel: $sentinel"
  echo "   請確認 input schema 的 regex 允許此字串,或改用模式 B (獨立 sentinel field)"
done

# 抓出 input schema 的 regex
for schema in "$DRAFT_ROOT"/spec/schemas/*-input.json; do
  echo ""
  echo "📋 $schema 內的 regex:"
  python3 -c "
import json, sys
with open('$schema') as f:
    s = json.load(f)
for prop, defn in s.get('properties', {}).items():
    if 'pattern' in defn:
        print(f'  {prop}: {defn[\"pattern\"]}')
"
done

echo ""
echo "⚠️  請手動比對:每個 sentinel 是否在 input schema 的 regex 允許範圍內"
echo "    若不在,改用模式 B (獨立 __sentinel field)"

exit 0
```

---

## 真實案例:衝突的設計 (INTEGRATION-PRACTICE.md 問題 7)

```json
// input schema
"amount": {
  "type": "string",
  "pattern": "^[0-9]+$"   // 嚴格,只允許純數字
}
```

```java
// mock 原意:FAIL_000011758 觸發業務拒絕
if (request.amount.startsWith("FAIL_")) {
    return Response.status(403).entity(buildError("E0024", "金額不符", null)).build();
}
```

**衝突**:`FAIL_000011758` 不符合 `^[0-9]+$`,在 input validation 階段就被攔截,根本到不了 mock。

### 陷阱 2: jq `tonumber` 遇到 Sentinel 字串導致 Runtime Exception

**症狀**: 當使用 `amount: "FAIL_000011758"` 作為哨兵時，workflow switch 狀態條件 `($a | tonumber) <= 0` 拋出 jq 例外，導致整個 switch state 異常、`finalStatus` 變成 `null`。

**根因**: jq 的 `tonumber` 無法解析 `FAIL_...`，直接拋錯中斷執行。

**安全寫法**:
```yaml
# ❌ 錯誤寫法 (遇到 FAIL_ 拋錯)
condition: '${ ((.amount // "") as $a | ($a == "0" or ($a | tonumber) <= 0)) }'

# ✅ 安全寫法 1: 排除 FAIL_ 前綴後再轉數字
condition: '${ ((.amount // "") as $a | ($a == "0" or $a == "0000000000" or (($a | startswith("FAIL_") | not) and ($a | tonumber) <= 0))) }'

# ✅ 安全寫法 2: 使用 jq safe tonumber 運算子
condition: '${ ((.amount // "") as $a | ($a == "0" or (($a | tonumber? // 1) <= 0))) }'
```

---

## spec.md 標註範本

```markdown
| H17 | **Mock sentinel**: 用 amount=0000000000 觸發業務拒絕 | input regex 嚴格,不允許 FAIL_* | 業務方確認 0=拒絕 | Mock resource 內 if (request.amount == "0" || ...) |
```

---

## 為何不在 schema 層加寬鬆規則就好?

理論上可以,但實務上:

1. **資安風險**:regex 放寬,攻擊面增加 (例如 SQL injection)
2. **可讀性差**:其他人看 regex 會疑惑為何 `FAIL_*` 算合法
3. **耦合性高**:schema 規則跟 mock 行為耦合,改 regex 會影響 mock 行為

用**獨立 sentinel field** 是最乾淨的做法,例如 `__sentinel: "FAIL_AMT"` 明確標示「這是測試用」。
