# Reference: 15 項 Self-Check 清單

> 對應 SKILL.md Step 7
> 用於設計完成後逐項驗證

---

## 完整清單

| # | 檢查項 | 通過條件 | 對應 SKILL 步驟 | 對應預檢 |
|---|---|---|---|---|
| 7.1 | `spec.md §0 假設清單` 含 FQCN 假設 | ✅ 每個新 service 都有 FQCN + 落地策略 | Step 1a | — |
| 7.2 | `spec.md §0` 含 `id 命名決策` 標記 | ✅ 明確寫出 snake_case 或註明 v1.0 hotfix | Step 1a | 01 |
| 7.3 | `spec.md §0` 含 `convention 決策` (status / finalStatus) | ✅ 標明用舊 / 新 / 純 HTTP status | Step 1c | 04 |
| 7.4 | OpenAPI spec 的 path param 與 workflow YAML 的 payload 對應 | ✅ 每個 `{xxx}` 都有對應 payload key | Step 6.3 | 03 |
| 7.5 | actionDataFilter 全部用頂層欄位 (非 `.result.X`) | ✅ grep 不到 `.result.X` 配對 | Step 3c | 02 |
| 7.6 | stateDataFilter.output 對應選定的 convention | ✅ 舊:`status: STRING`;新:`status: 0/1` + `finalStatus: STRING` | Step 3d | 04 |
| 7.7 | Mock sentinel 字串能通過 input validation | ✅ 設計期實測或改用模式 B | Step 5b | 06 |
| 7.8 | Mock package 命名對齊既有 project | ✅ 不需 rename | Step 5a | — |
| 7.9 | SQL migration V 編號遞增 | ✅ 從既有最大 +1 | Step 4d | — |
| 7.10 | YAML 沒有 trailing comma | ✅ grep 不到 `,$\|,$` 結尾的 list item | Step 6.5 | 05 |
| 7.11 | spec/config/application.properties.snippet 含 status-rewrite 完整配置 | ✅ workflows + mapping 兩個都列出 | Step 8 | 04 |
| 7.12 | 測試套件包含 happy path + 主要 error path | ✅ 至少 5 個測試案例 | Step 8 | — |
| 7.13 | 測試資料字串能通過 input validation | ✅ 每個測試 payload 都驗過 | Step 6.6 | 06 |
| 7.14 | spec.md §8 Project Mapping Manifest 完整 | ✅ 每個 draft 檔案都有對應正式路徑 | Step 7 | — |
| 7.15 | spec.md §9 已知限制有列 | ✅ v1.0 留白 / 簡化項目都明確標出 | Step 7 | — |
| 7.16 | Input Validation Regex 與 API Sample 相容 | ✅ 通路代碼/欄位正則相容真實範例（如 `2500P`） | Step 1a | 06 |
| 7.17 | 測試案例採用動態唯一序號 | ✅ 獨立測試採動態序號，避免誤觸 Parent 冪等 | Step 8 | — |
| 7.18 | jq 條件表達式 `tonumber` 防呆 | ✅ 具備非純數字哨兵保護，避免 Runtime Exception | Step 3a | 06 |
| 7.19 | Workflow Root 顯式定義 `start: <StateName>` | ✅ 避免 Kogito 拋出 `Workflow.getStart() is null` NPE | Step 3a | 01 |
| 7.20 | Service Function 參數鍵值精準對齊 Java Overload 簽名 | ✅ `workflowId` 與 `businessKey` 齊全，避免 ClassCastException | Step 3b | — |
| 7.21 | OpenAPI Spec 顯式定義 `servers[0].url` | ✅ 避免 MyOpenApiService 拋出「無法確定 API Base URL」異常 | Step 4 | 02 |

---

## 自動執行腳本

把所有檢查串起來:

```bash
#!/bin/bash
# 用途:設計完成後一次跑完 15 項 self-check
# 用法:./run-self-check.sh draft-<name>/

set -e
DRAFT_ROOT="$1"

if [ -z "$DRAFT_ROOT" ]; then
  echo "Usage: $0 <draft-root>"
  exit 2
fi

TOTAL=0
PASS=0
FAIL_LIST=()

check() {
  local id="$1"
  local desc="$2"
  local cmd="$3"
  TOTAL=$((TOTAL+1))
  echo "─── [$id] $desc ───"
  if eval "$cmd" > /dev/null 2>&1; then
    echo "✅ PASS"
    PASS=$((PASS+1))
  else
    echo "❌ FAIL"
    FAIL_LIST+=("$id: $desc")
  fi
  echo ""
}

# 7.1
check "7.1" "spec.md §0 含 FQCN 假設" \
  "grep -E 'FQCN' $DRAFT_ROOT/spec/spec.md | grep -E 'service|method'"

# 7.2
check "7.2" "spec.md §0 含 id 命名決策" \
  "grep -E 'ID 命名|snake_case|kebab-case' $DRAFT_ROOT/spec/spec.md"

# 7.3
check "7.3" "spec.md §0 含 convention 決策" \
  "grep -E 'Convention' $DRAFT_ROOT/spec/spec.md"

# 7.4
# (需獨立跑 path-param-injection 預檢)

# 7.5
check "7.5" "actionDataFilter 無 .result.X" \
  "! grep -rE 'actionDataFilter' $DRAFT_ROOT/spec/*.yaml -A 3 | grep -E '\.result\.'"

# 7.6
check "7.6" "stateDataFilter.output 對應 convention" \
  "grep -E 'stateDataFilter' $DRAFT_ROOT/spec/*.yaml -A 20 | grep -E 'finalStatus:|status:.*0|status:.*1'"

# 7.7
# (需手動或獨立腳本驗證)

# 7.8
check "7.8" "mock package 對齊既有 project (e.g., org.acme.transfer.api)" \
  "grep -rE '^package org\.acme\.[a-z]+\.api' $DRAFT_ROOT/spec/mocks/"

# 7.9
# (需手動查既有 V 編號)

# 7.10
check "7.10" "YAML 無 trailing comma" \
  "! grep -rE '^\s+\w+:\s+.+,\$' $DRAFT_ROOT/spec/*.yaml"

# 7.11
check "7.11" "application.properties.snippet 含 status-rewrite" \
  "grep -E 'status-rewrite' $DRAFT_ROOT/spec/config/application.properties.snippet"

# 7.12
check "7.12" "測試套件含 happy path + error path (>=5 案例)" \
  "test \$(grep -c '@Test' $DRAFT_ROOT/spec/tests/*.java) -ge 5"

# 7.13
# (需手動驗證)

# 7.14
check "7.14" "spec.md §8 含 Project Mapping Manifest" \
  "grep -E 'Project Mapping|draft.*正式' $DRAFT_ROOT/spec/spec.md"

# 7.15
check "7.15" "spec.md §9 含已知限制" \
  "grep -E '已知限制|Known Limitation' $DRAFT_ROOT/spec/spec.md"

# 總結
echo "============================================"
echo "Self-Check 結果: $PASS/$TOTAL PASS"
echo "============================================"
if [ ${#FAIL_LIST[@]} -gt 0 ]; then
  echo "❌ FAIL 項目:"
  for item in "${FAIL_LIST[@]}"; do
    echo "  - $item"
  done
  exit 1
fi
```

---

## 為何不全部自動化?

有些檢查項目**需要語意理解**,無法純靠 grep:

- 7.4 (path param 對應): 需解析 YAML 結構,確認 payload 內有對應 key
- 7.7 / 7.13 (sentinel vs validation): 需比對 mock 內的字串與 schema regex
- 7.9 (V 編號遞增): 需查 project 既有最大 V 編號

這些項目提供自動檢查腳本 + 人工 review 雙軌並用。
