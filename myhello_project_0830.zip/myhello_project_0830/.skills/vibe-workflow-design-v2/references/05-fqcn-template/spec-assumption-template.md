# Reference: spec.md §0 假設清單完整模板

> 對應 SKILL.md Step 1a
> 用於設計期記錄所有假設,作為下游整合的單一真相源 (Single Source of Truth)

---

## 完整模板

```markdown
## §0 假設清單

> 撰寫日期: YYYY-MM-DD
> 對應業務書: BR-XXX (vN.M)
> 對應 draft 套件: draft-<name>/
> 設計模式: Mode A / B / C / D / E
> Convention: 舊 / 新 / 純 HTTP

### 業務與輸入假設

| # | 假設 | 為何這樣假設 | 待確認問題 | 落地策略 |
|---|---|---|---|---|
| H1 | 輸入欄位 N 個 (列舉) | 業務書 §X.Y | — | spec §2.1 schema 對應 |
| H2 | 終態 finalStatus 有 M 個 (列舉) | 業務書 §X.Y | — | spec §2.3 + status-rewrite config |
| H3 | 業務模式:Mode X (Saga/Parent+Child/...) | 業務書 §X.Y 流程圖 | — | spec §3 workflow 結構 |
| H4 | 業務體系: <list> (e.g., Core + CC) | 業務書 §X.Y | — | spec §3 子流程對應 |

### 平台與技術假設 ⭐

| # | 假設 | 為何這樣假設 | 待確認問題 | 落地策略 |
|---|---|---|---|---|
| H5 | 對外契約用 REST POST (或 GraphQL / gRPC) | 既有 transfer-workflow 用 REST | — | notebooks/<entry>-api.yaml |
| H6 | **FQCN**: `<existing_service>::<new_method>` | 既有 service 未提供此方法 | 需擴充 | Java service (擴充) |
| H7 | **ID 命名**: snake_case (e.g., omni_cash_transaction) | ⭐ Kogito 10.2.0 codegen bug 規避 | — | 整個 spec 全用 snake_case |
| H8 | **Convention**: 新 (status 0/1 int + finalStatus string) | 與 credit-card 體系對齊 | — | stateDataFilter.output |
| H9 | **Mock package**: org.acme.<project>.api (對齊既有) | 避免下游 rename | — | spec/mocks/* 全部 |
| H10 | **Mock sentinel**: 用 amount=0 觸發業務拒絕 (因 input regex 嚴格) | 不能用 FAIL_*,會被 input validation 攔截 | — | Mock resource 內 if (request.amount == "0" || ...) |
| H11 | **Path param 自動注入**: 從 OpenAPI spec 掃出 {creditcardid},在 workflow payload 顯式帶 .partyId | MyOpenApiService 不自動綁定 | — | workflow YAML 每個 callApiViaOpenAPI 都有 |

### 資料庫與稽核假設

| # | 假設 | 為何這樣假設 | 待確認問題 | 落地策略 |
|---|---|---|---|---|
| H12 | Flyway migration V 編號從既有最大 +1 | 從 project/db/migration/ 找最大 V | — | spec/db/V<n+1>.__.sql |
| H13 | **FQCN**: `<new_service>::<method>` (新 class) | 既有 service 無此類別 | 需新建 | Java service (新) + 對應 SQL migration (若需新欄位) |
| H14 | **FQCN**: `<existing_service>::<new_method>` (擴充) | 既有 service 無此方法 | 需擴充 + 對應欄位 | Java service (擴充) + SQL migration |
| H15 | Audit log 保留 7 年 (保險法規) / 1 年 (一般) | 法規 §X.Y | — | AuditLogService retention policy |

### 整合前置產出物

| # | 假設 | 為何這樣假設 | 待確認問題 | 落地策略 |
|---|---|---|---|---|
| H16 | spec/config/application.properties.snippet 含完整 status-rewrite | 避免下游摸索 | — | spec §5 列出 |
| H17 | spec.md §8 Project Mapping Manifest 完整 | 整合者直接照搬 | — | spec §8 表格 |

### 已知未解 / 待確認

| # | 待確認問題 | 影響 | 行動 |
|---|---|---|---|
| H18 | <待釐清的業務規則> | <影響哪些流程> | v1.1 修訂 |
```

---

## 真實案例 (omni-cash-transaction v1.0)

```markdown
## §0 假設清單

| # | 假設 | 為何這樣假設 | 待確認問題 | 落地策略 |
|---|---|---|---|---|
| H1 | 輸入欄位 6 個 | 業務書 §1.2 | — | spec §2.1 schema |
| H2 | 終態 finalStatus 有 8 個 | 業務書 §3.1 | — | spec §2.3 |
| H3 | 業務模式:Mode B (Parent + 2 Child) | 業務書 §2.1 | — | spec §3 |
| H4 | 業務體系: CoreAccount + CreditCard | 業務書 §2.1 | — | spec §3 |
| H5 | 對外契約用 REST POST | 既有 transfer-workflow 用 REST | — | notebooks/parent-api.yaml |
| H6 | **FQCN**: `AuditLogService::findBySequenceNumber` | 既有 service 無此方法 | 需擴充 | Java service (既有) |
| H7 | **ID 命名**: snake_case | Kogito 10.2.0 bug 規避 | — | 整個 spec 全用 snake_case |
| H8 | **Convention**: 新 (status 0/1 int + finalStatus string) | 與 credit-card 對齊 | — | stateDataFilter.output |
| H9 | **Mock package**: org.acme.transfer.api | 對齊既有 transfer-mock | — | spec/mocks/* 全部 |
| H10 | **Mock sentinel**: amount=0 觸發業務拒絕 | regex 嚴格不允許 FAIL_* | — | Mock resource if (amount == "0") |
| H11 | **Path param 注入**: creditcardid 從 .partyId 推導 | MyOpenApiService 不自動綁定 | — | workflow YAML payload |
| H12 | Flyway V 編號從 V1.1.0 +1 = V1.2.0 | 從 reconciliation-api/db/migration/ 找最大 | — | spec/db/V1.2.0__*.sql |
| H13 | **FQCN**: `IdempotencyService::findBySequenceNumber` (新 class) | 既有 service 無此類別 | 需新建 | Java service (新) |
| H14 | **FQCN**: `AuditLogService::markCancelledBy` | 既有 service 無此方法 | 需擴充 + cancelled_by 欄位 | Java service (擴充) + V1.0.1__add_cancelled_by.sql |
| H15 | Audit log 保留 1 年 (一般業務) | 非金融,無強制法規 | — | AuditLogService 預設 |
| H16 | spec/config/application.properties.snippet 含 status-rewrite 5 條 mapping | 避免下游摸索 | — | spec §5 |
| H17 | Project Mapping Manifest 10 個檔案 | 整合者直接照搬 | — | spec §8 |
| H18 | 業務書 §6.2 A3 場景 (FAIL_*) 與 input regex 衝突 | spec 設計衝突 | 業務方需修 regex 或改 sentinel | v1.1 修訂,本版接受改用 amount=0 觸發 |
```

---

## 為何 H6/H13/H14 必須明確標 FQCN?

這是下游 `sonataflow-integration` skill 識別「要新建/擴充哪些 service」的唯一依據。

整合者讀 spec.md §0,看到:
- `H6: AuditLogService::findBySequenceNumber` → 知道要擴充既有 service
- `H13: IdempotencyService::findBySequenceNumber` → 知道要新建 class
- `H14: AuditLogService::markCancelledBy` → 知道要擴充既有 + 新增欄位

若 §0 沒寫,整合者要從 workflow YAML 內 `functions: - operation:` 反推,容易漏。

---

## 撰寫順序建議

1. 先寫 H1-H4 (業務與輸入)
2. 再寫 H5 (對外契約類型)
3. 然後寫 H6-H11 (平台與技術)— 這幾條最重要,整合者必看
4. 接著 H12-H15 (資料庫)
5. H16-H17 (整合前置產出物)
6. 最後 H18+ (已知未解 / v1.1 修訂)

---

## 與 INTEGRATION-PRACTICE.md 對比

| 假設類型 | spec.md §0 | INTEGRATION-PRACTICE.md |
|---|---|---|
| 業務假設 (H1-H4) | 必有 | 隱含在「Step 1: 落規格檔」 |
| 平台與技術假設 (H5-H11) | 必有 ⭐ | 對應問題 1-7 |
| 資料庫假設 (H12-H15) | 必有 | 對應 Step 3 + 問題 5 |
| 整合前置產出物 (H16-H17) | 必有 | 對應 Step 5 |
| 已知未解 (H18+) | 必有 | 對應「已知限制」段 |

**核心差異**:`INTEGRATION-PRACTICE.md` 是**事後**記錄踩坑,`spec.md §0` 是**事前**標註假設。事前標註可以避免踩坑。
