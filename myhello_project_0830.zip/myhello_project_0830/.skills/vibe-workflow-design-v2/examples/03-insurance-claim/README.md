# Example 03: Insurance Claim Processing (Mode B with Audit Lookup)

> 展示「保險理賠」業務用 Mode B (Parent + 2 Child Subflow) + Lookup Original Pattern。
> 與 Example 01 結構相似但業務語意完全不同,證明 skill 可橫向遷移。

---

## 業務情境

```
申請理賠 (New Claim)
  → Child A: 審核 + 撥款
  → Child B: 取消理賠 (需 lookup 原申請)

子流程:
  Child A (claim_settlement): 保險系統 → 銀行撥款
  Child B (claim_cancellation): 撤銷撥款 + 通知保戶
```

---

## 與 Example 01 結構對比

| 維度 | Example 01 (金融繳款) | Example 03 (保險理賠) |
|---|---|---|
| 業務體系 | Core Account + Credit Card | **Insurance + Bank Payout** |
| 主鍵 | sequenceNumber | **claimId** |
| Child A 內容 | 兩階段 (Core + CC) | **單階段** (審核 + 撥款合併) |
| 取消 Lookup 對象 | 原 SUCCESS transaction | **原 claimId 的 settlement** |
| 對外契約 | /omni_cash_transaction | **/insurance_claim** |
| finalStatus 命名 | SUCCESS/FAILED/CANCELLED | **APPROVED/REJECTED/CANCELLED/PENDING** (略改 convention) |
| Idempotency | 必要 | **必要** (保險不允許重複撥款) |

---

## 為何仍用 Mode B (而非 Mode A)?

雖然保險理賠也是「線性多階段」,但有兩個理由拆成 Parent + Child:
1. **「撤銷撥款」是獨立業務入口** (理賠專員可手動觸發,而非從申請流程內走)
2. **稽核要求**: Parent 須獨立記錄「哪個 claim 觸發了哪個 settlement」

這兩個需求在電商訂單(Example 02)不存在,所以用 Mode A 即可。

---

## 套件結構

```
03-insurance-claim/
├── notebooks/
│   ├── claim-api.yaml                  # 對外契約
│   ├── insurance-system-api.yaml       # host #1
│   └── bank-payout-api.yaml            # host #2
├── spec/
│   ├── claim-processing.sw.yaml        # Parent
│   ├── claim-settlement.sw.yaml        # Child A
│   ├── claim-cancellation.sw.yaml      # Child B
│   ├── schemas/claim-input.json
│   ├── schemas/claim-output.json
│   ├── db/V1.5.0__create_view_claim_reconciliation.sql
│   ├── config/application.properties.snippet
│   ├── mocks/
│   │   ├── InsuranceResource.java
│   │   ├── BankPayoutResource.java
│   │   └── dto/
│   ├── tests/ClaimProcessingTest.java
│   └── spec.md
└── README.md
```

---

## 通用化要點 (與 Example 01 對齊)

1. **workflow id 命名**: 全部 snake_case (`claim_processing`, `claim_settlement`, `claim_cancellation`) — ⭐ Step 6.1
2. **Parent 委派 Child 用 subFlowRef** — 必走 Step 6.1 預檢
3. **Lookup Original Transaction 模式**: 與金融繳款相同 — `lookupOriginalClaim` 對應 H6
4. **actionDataFilter**: 全部讀頂層欄位 — ⭐ Step 3c
5. **path param 注入**: claimId 在所有 host API 都要顯式帶 — ⭐ Step 6.3
6. **stateDataFilter output**: 新 convention (status 0/1 int + finalStatus string) — ⭐ Step 3d
7. **Mock package**: 對齊既有 project 的 `org.acme.insurance.api` — ⭐ Step 5a

---

## 業務 domain-specific 客製點

雖然結構通用,但有幾個**保險業特有**的設計決策:

1. **finalStatus 命名採業務語意**:`APPROVED/REJECTED/PENDING` 而非 `SUCCESS/FAILED`
   - 但仍對應到 status 0/1 (int) — 因為 convention 一致
2. **Mock sentinel 加 `FRAUD_*` 前綴**: 模擬詐欺偵測拒絕
3. **audit log 強制 7 年保留** (法規): 對齊既有的 AuditLogService retention policy
4. **Idempotency 加強**: 不只 sequenceNumber replay,還有「同日重複申請偵測」

---

## 跨領域通用化檢查表

若你要把 v2 skill 套到新領域 (例如物流配送、醫療掛號),可參考:

- [ ] 識別業務模式 (Mode A/B/C/D/E 中的哪個)
- [ ] 套用對應的 workflow YAML 範本
- [ ] 確認 host API 數量與 path param
- [ ] 設計 mock sentinel (避開 input validation 衝突)
- [ ] 對齊既有 project 的 package 命名
- [ ] 產出 spec/config/application.properties.snippet
- [ ] 跑 6 項平台相容性預檢
- [ ] 跑 15 項 self-check
