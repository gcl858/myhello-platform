# Omni Cash Transaction - Spec v1.0

> 對應 draft: `draft-omni-counter-repayment/` (信用卡臨櫃現金繳款)
> 撰寫日期: 2026-08-26
> 設計期採用模式: Mode B (Parent + 2 Child Subflow)
> Convention: 新 (status: 0/1 int + finalStatus: string)

---

## §0 假設清單 (Step 1a 強制結構)

| # | 假設 | 為何這樣假設 | 待確認問題 | 落地策略 |
|---|---|---|---|---|
| H1 | 輸入欄位 6 個 (operationType, partyId, branchCode, amount, sequenceNumber, originalSequenceNumber?) | 業務書 §1.2 | — | spec §2.1 schema |
| H2 | 終態 finalStatus 有 8 個 | 業務書 §3.1 表格 | — | spec §2.3 + status-rewrite config |
| H3 | 對外契約用 REST POST | 既有 transfer-workflow 用 REST | — | notebooks/parent-api.yaml |
| H4 | CoreAccount + CreditCard 兩階段 | 業務書 §2.1 流程圖 | — | child-deposit workflow |
| H5 | 取消時需 lookup 原 SUCCESS transaction | 業務書 §4.1 取消流程 | — | lookupOriginalTransaction function |
| H6 | **FQCN**: `AuditLogService::findBySequenceNumber` | 既有 service 無此方法 | 需擴充 | Java service (既有) |
| H13 | **FQCN**: `IdempotencyService::findBySequenceNumber` (新 class) | 既有 service 無此類別 | 需新建 | Java service (新) |
| H14 | **FQCN**: `AuditLogService::markCancelledBy` | 既有 service 無此方法 | 需擴充 | Java service (既有) |
| H15 | **ID 命名**: snake_case (omni_cash_transaction) | ⭐ Kogito 10.2.0 codegen bug 規避 | — | 整個 spec 全用 snake_case |
| H16 | **Convention**: 新 (status 0/1 int + finalStatus string) | 與 credit-card 體系對齊 | — | stateDataFilter.output |
| H17 | **Mock package**: org.acme.transfer.api (對齊既有 transfer-mock) | 避免下游 rename | — | spec/mocks/* 全部 |

---

## §1 概覽

Parent workflow 接收信用卡臨櫃現金繳款請求,依 `operationType` 路由到對應的 child subflow:
- `operationType=A` → 委派給 `repayment_cash_deposit` (正向繳款,Core+CC 兩階段)
- `operationType=B` → 委派給 `repayment_cash_cancellation` (取消繳款,先 lookup 再反向)

---

## §2 輸入輸出

### §2.1 Input schema
見 `schemas/parent-input.json`

### §2.3 finalStatus 對映表 (Step 1c convention)

| finalStatus | HTTP code | status (int) | 說明 |
|---|---|---|---|
| SUCCESS | 200 | 0 | 兩階段都成功 |
| FAILED | 200 | 1 | 業務失敗短路 |
| CANCELLED | 200 | 0 | 取消流程成功 |
| REJECTED_VALIDATION | 400 | 1 | 輸入驗證失敗 |
| LOOKUP_FAILED | 500 | 1 | 取消時找不到原 transaction |
| ROLLBACK_FAILED | 409 | 1 | CC 失敗,Core rollback 也失敗 |
| CANCEL_ROLLBACK_FAILED | 409 | 1 | 取消時 Core 反向失敗 |
| IDEMPOTENT_REPLAY | 200 | 0 | 冪等重送 |

---

## §3 Workflow 結構

- **Parent**: `omni_cash_transaction` (見 `spec/parent-workflow.sw.yaml`)
- **Child A**: `repayment_cash_deposit` (見 `spec/child-deposit.sw.yaml`)
- **Child B**: `repayment_cash_cancellation` (見 `spec/child-cancellation.sw.yaml`)

---

## §4 資料庫 migration (Step 4d 編號遞增)

- `V1.0.1__add_cancelled_by_to_workflow_execution_log.sql` (H14 欄位需求)
- `V1.2.0__create_view_omni_cash_transaction_reconciliation.sql` (對帳 view)

---

## §5 組態 (Step 8 整合前置產出物)

見 `config/application.properties.snippet` (含 status-rewrite + function bean 綁定)

---

## §6 測試 (Step 7.12)

- 5 個 E2E 測試案例 (見 `tests/ParentWorkflowTest.java`):
  - P1: input validation 失敗
  - P2: 取消缺 originalSequenceNumber
  - A1: happy path SUCCESS
  - A2: zero amount (注意:因 input validation 嚴格,實際是 400 不是 200)
  - P4: idempotency

---

## §7 已知限制 / 簡化

- B4 重複取消 idempotency: markOriginalCancelled 邏輯待補 (不影響 v1.0 主流程)
- A4/A5/B5/B6/B7 細粒度測試空殼:需 mock 加新 sentinel
- 對外 API path 從 hyphen 改為 underscore (Kogito 10.2.0 bug 規避)

---

## §8 Project Mapping Manifest (Step 7.14)

| Draft 檔案 | 正式專案路徑 |
|---|---|
| `spec/parent-workflow.sw.yaml` | `domain-transfer/transfer-workflow/src/main/resources/omni-cash-transaction.sw.yaml` |
| `spec/child-deposit.sw.yaml` | `domain-transfer/transfer-workflow/src/main/resources/repayment-cash-deposit.sw.yaml` |
| `spec/child-cancellation.sw.yaml` | `domain-transfer/transfer-workflow/src/main/resources/repayment-cash-cancellation.sw.yaml` |
| `notebooks/parent-api.yaml` | `domain-transfer/transfer-workflow/src/main/resources/specs/omni-counter-repayment-api.yaml` |
| `notebooks/host-core-api.yaml` | `domain-transfer/transfer-workflow/src/main/resources/specs/core-account-cash-deposit-api.yaml` |
| `spec/mocks/*.java` | `dev/transfer-mock/src/main/java/org/acme/transfer/api/` |
| `spec/db/V1.0.1__*.sql` | `domain-reconciliation/reconciliation-api/src/main/resources/db/migration/` |
| `spec/db/V1.2.0__*.sql` | `domain-reconciliation/reconciliation-api/src/main/resources/db/migration/` |
| `config/application.properties.snippet` | 合併到 `distribution/transfer-app/src/main/resources/application.properties` |
| `tests/ParentWorkflowTest.java` | `distribution/transfer-app/src/test/java/com/example/platform/distribution/transfer/` |

---

## §9 已知限制 (Step 7.15)

詳見 §7。
