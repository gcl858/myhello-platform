// Package 命名對齊既有 project:org.acme.transfer.api (Step 5a)
// 不使用 draft-only 的 org.acme.cashrepayment.api (避免下游 rename 工時)
package org.acme.transfer.api;

import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import org.acme.transfer.api.dto.CoreCashDepositRequest;
import org.acme.transfer.api.dto.CoreCashDepositResponse;
import org.acme.transfer.api.dto.ErrorDetail;

import java.util.UUID;

/**
 * Mock resource:Core Account Cash Deposit
 *
 * 展示 Step 5b「Mock Sentinel 模式 A (業務 payload 內字串前綴)」
 * 與 Step 6.6「Mock sentinel vs input validation 相容性」處理。
 *
 * 設計決策:由於 input schema 的 amount regex 為 ^[0-9]+$,
 * 業務拒絕 sentinel 採用「amount=0」或「amount=0000000000」觸發。
 * (不能用 FAIL_* 前綴,會被 input validation 先攔截)
 */
@Path("/CoreAccount/{creditcardid}/CashDeposit")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class CoreCashDepositResource {

    @POST
    @Path("/Execute")
    public Response execute(@PathParam("creditcardid") String creditcardid,
                            CoreCashDepositRequest request) {
        // 業務拒絕 sentinel:amount 為 0 或全 0 字串
        if ("0".equals(request.amount) || "0000000000".equals(request.amount)) {
            return Response.status(403)
                    .entity(new ErrorDetail("E0024", "金額不符", null))
                    .build();
        }
        // 正常成功
        return Response.ok(new CoreCashDepositResponse(
                "100", "SUCCESS", UUID.randomUUID().toString(), request.sequenceNumber
        )).build();
    }

    @POST
    @Path("/Rollback")
    public Response rollback(@PathParam("creditcardid") String creditcardid,
                             CoreCashDepositRequest.RollbackRequest request) {
        // 回沖失敗 sentinel:rollbackReason 為 RBFAIL
        if ("RBFAIL".equals(request.rollbackReason)) {
            return Response.status(403)
                    .entity(new ErrorDetail("E0050", "回沖失敗", null))
                    .build();
        }
        return Response.ok(new CoreCashDepositResponse(
                "100", "ROLLBACK_SUCCESS", UUID.randomUUID().toString(), null
        )).build();
    }
}
