package org.acme.transfer.api.dto;

public class CoreCashDepositResponse {
    public String code;
    public String message;
    public String trackId;
    public String sequenceNumber;

    public CoreCashDepositResponse() {}

    public CoreCashDepositResponse(String code, String message, String trackId, String sequenceNumber) {
        this.code = code;
        this.message = message;
        this.trackId = trackId;
        this.sequenceNumber = sequenceNumber;
    }
}
