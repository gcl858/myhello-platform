package org.acme.transfer.api.dto;

public class ErrorDetail {
    public String code;
    public String message;
    public Object detail;

    public ErrorDetail() {}

    public ErrorDetail(String code, String message, Object detail) {
        this.code = code;
        this.message = message;
        this.detail = detail;
    }
}
