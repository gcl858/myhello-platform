-- Flyway migration:從 project-0825-pd 既有最大 V 編號 +1
-- 假設既有最大是 V1.1.0,新建立 V1.2.0
-- ⭐ Step 6.1 + Step 6.6:WHERE clause 必須用最終 workflow id (snake_case,非 hyphen)

CREATE VIEW IF NOT EXISTS vw_omni_cash_transaction_reconciliation AS
SELECT
    workflow_id,
    sequence_number,
    final_status,
    json_extract(workflow_data, '$.amount') AS amount,
    json_extract(workflow_data, '$.partyId') AS party_id,
    json_extract(workflow_data, '$.operationType') AS operation_type,
    created_at,
    updated_at
FROM workflow_execution_log
WHERE workflow_id IN (
    'omni_cash_transaction',         -- ⭐ snake_case (對應 workflow id)
    'repayment_cash_deposit',
    'repayment_cash_cancellation'
);

CREATE INDEX IF NOT EXISTS idx_workflow_execution_log_workflow_id
    ON workflow_execution_log(workflow_id);
