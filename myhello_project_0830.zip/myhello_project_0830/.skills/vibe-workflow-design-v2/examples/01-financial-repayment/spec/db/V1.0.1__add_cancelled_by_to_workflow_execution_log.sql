-- V1.0.1:加 cancelled_by 欄位 (H14 markCancelledBy 服務需要)
-- 從既有最大 V 編號 V1.0.0 +0.0.1 (minor change)

ALTER TABLE workflow_execution_log ADD COLUMN cancelled_by TEXT;
ALTER TABLE workflow_execution_log ADD COLUMN cancelled_at TIMESTAMP;
