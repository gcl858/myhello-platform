// @QuarkusTest 範本
// 展示 Step 7.12-7.13:測試套件含 happy path + error path,且測試資料能通過 input validation
//
// ⭐ Step 6.6 重要:測試 payload 的 amount 必須是 ^[0-9]+$ 格式,不能用 FAIL_*
// 「業務拒絕短路」場景改用 amount=0 或 amount=0000000000 觸發

package com.example.platform.distribution.transfer;

import io.quarkus.test.junit.QuarkusTest;
import io.restassured.http.ContentType;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.*;

@QuarkusTest
@DisplayName("Omni Cash Transaction Parent Workflow E2E")
class OmniCashTransactionWorkflowTest {

    private static final String PARENT_URL = "/omni_cash_transaction";

    // ─── P1:輸入驗證失敗 (REJECTED_VALIDATION) ───
    @Test
    @DisplayName("P1:operationType=C → 400 REJECTED_VALIDATION")
    void test_invalidOperationType() {
        given()
            .contentType(ContentType.JSON)
            .body("""
                {
                  "operationType": "C",
                  "partyId": "P001",
                  "branchCode": "B01",
                  "amount": "1000",
                  "sequenceNumber": "SEQ_P1"
                }
                """)
            .when().post(PARENT_URL)
            .then()
            .statusCode(400)
            .body("finalStatus", equalTo("REJECTED_VALIDATION"));
    }

    // ─── P2:operationType=B 缺 originalSequenceNumber → 400 ───
    @Test
    @DisplayName("P2:operationType=B 缺 originalSequenceNumber → 400")
    void test_cancelMissingOriginal() {
        given()
            .contentType(ContentType.JSON)
            .body("""
                {
                  "operationType": "B",
                  "partyId": "P001",
                  "branchCode": "B01",
                  "amount": "1000",
                  "sequenceNumber": "SEQ_P2"
                }
                """)
            .when().post(PARENT_URL)
            .then()
            .statusCode(400)
            .body("finalStatus", equalTo("REJECTED_VALIDATION"));
    }

    // ─── A1:正常 SUCCESS (新 convention:status=0 + finalStatus=SUCCESS) ───
    @Test
    @DisplayName("A1:正常繳款 SUCCESS")
    void test_happyPath() {
        given()
            .contentType(ContentType.JSON)
            .body("""
                {
                  "operationType": "A",
                  "partyId": "P001",
                  "branchCode": "B01",
                  "amount": "50000",
                  "sequenceNumber": "SEQ_A1"
                }
                """)
            .when().post(PARENT_URL)
            .then()
            .statusCode(200)
            .body("status", equalTo(0))
            .body("finalStatus", equalTo("SUCCESS"))
            .body("coreResult.trackId", notNullValue())
            .body("ccResult.trackId", notNullValue());
    }

    // ─── A2:amount=0000000000 → 業務拒絕 (但因 input validation 嚴格,實際是 400) ───
    @Test
    @DisplayName("A2:amount=0000000000 → 400 REJECTED_VALIDATION (input validation 攔截)")
    void test_zeroAmount() {
        given()
            .contentType(ContentType.JSON)
            .body("""
                {
                  "operationType": "A",
                  "partyId": "P001",
                  "branchCode": "B01",
                  "amount": "0000000000",
                  "sequenceNumber": "SEQ_A2"
                }
                """)
            .when().post(PARENT_URL)
            .then()
            .statusCode(400)
            .body("finalStatus", equalTo("REJECTED_VALIDATION"));
    }

    // ─── P4:Parent 級冪等 ───
    @Test
    @DisplayName("P4:同 sequenceNumber 重送 → 第二次 IDEMPOTENT_REPLAY")
    void test_idempotency() {
        String body = """
            {
              "operationType": "A",
              "partyId": "P001",
              "branchCode": "B01",
              "amount": "5000",
              "sequenceNumber": "SEQ_P4"
            }
            """;

        // 第一次:SUCCESS
        given().contentType(ContentType.JSON).body(body)
            .when().post(PARENT_URL)
            .then().statusCode(200).body("finalStatus", equalTo("SUCCESS"));

        // 第二次:IDEMPOTENT_REPLAY
        given().contentType(ContentType.JSON).body(body)
            .when().post(PARENT_URL)
            .then().statusCode(200).body("finalStatus", equalTo("IDEMPOTENT_REPLAY"));
    }
}
