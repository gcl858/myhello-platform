# Example 02: E-Commerce Order Fulfillment (Mode A — Single Saga LIFO)

> 此為**通用化範本**,展示 Mode A (單層 Saga LIFO) 如何套用於「下單 → 付款 → 出貨」流程。
> 不同於 Example 01 的「金融信用卡繳款」(Mode B Parent+Child),此例展示單一 workflow 內的多階段補償。

---

## 業務情境

```
建立訂單 → 扣款 (Payment) → 預約庫存 (Inventory) → 排程出貨 (Shipping)
              ↓ 失敗                ↓ 失敗                ↓ 失敗
            取消訂單              退款                  釋放庫存
```

- **3 階段 Forward**,任一階段失敗需反向 LIFO 補償
- **無 Parent-Child 委派**,全部狀態在同一 workflow 內
- **不需要 idempotency lookup**(每個 order 有獨立 ID,不存在「取消」流程)

---

## 結構差異對比 (vs Example 01)

| 維度 | Example 01 (金融繳款) | Example 02 (電商訂單) |
|---|---|---|
| Workflow 模式 | Mode B (Parent + 2 Child Subflow) | **Mode A (單 Saga LIFO)** |
| 輸入分流 | operationType dispatcher | 無 (固定 3 階段) |
| 取消流程 | 獨立 Child workflow | **內含 Cancel state** |
| Idempotency | 必要 (sequenceNumber replay) | **不必要** (orderId 唯一) |
| 業務體系 | Core + CC (2 個 host) | **Payment + Inventory + Shipping (3 個 host)** |
| 對外契約 | Parent 對外 | **Order 對外** |

---

## 套件結構

```
02-ecommerce-order/
├── notebooks/
│   ├── order-api.yaml            # 對外契約
│   ├── payment-api.yaml          # host #1
│   ├── inventory-api.yaml        # host #2
│   └── shipping-api.yaml         # host #3
├── spec/
│   ├── order-fulfillment.sw.yaml  # ⭐ 單 workflow 含 3 階段 forward + LIFO rollback
│   ├── schemas/order-input.json
│   ├── schemas/order-output.json
│   ├── db/V2.0.0__create_view_order_fulfillment.sql
│   ├── config/application.properties.snippet
│   ├── mocks/
│   │   ├── PaymentResource.java
│   │   ├── InventoryResource.java
│   │   ├── ShippingResource.java
│   │   └── dto/
│   ├── tests/OrderFulfillmentTest.java
│   └── spec.md
└── README.md                     # 本檔
```

---

## 通用化要點

1. **workflow id 命名**: `order_fulfillment` (snake_case, ⭐ Step 6.1)
2. **actionDataFilter 結構**: 全部讀頂層欄位 (⭐ Step 3c)
3. **path param 注入**: 3 個 host API 的 `orderId` 都要在 payload 內顯式提供 (⭐ Step 6.3)
4. **stateDataFilter output**: 用新 convention `status: 0/1` + `finalStatus` (⭐ Step 3d)
5. **LIFO 補償順序**: Shipping rollback → Inventory rollback → Payment rollback → 訂單取消
6. **Mock sentinel 設計**: 由於無 input validation 衝突,可用 `FAIL_<stage>` 字串前綴
   (若 input validation 嚴格則改用模式 B 獨立 sentinel field)
7. **無 subFlowRef**: 因此**不觸發 Kogito hyphen bug**,id 命名可彈性

---

## 何時用這個範本

- ✅ 業務流是「線性多階段」且每階段都需要補償
- ✅ 無「取消」獨立入口 (取消是流程內的一個 state)
- ✅ 各階段都是同一業務體系內的 host (例如電商自己的服務)
- ❌ 若有「取消」獨立入口,改用 Mode B (Parent+Child) 較清晰
- ❌ 若 host 跨業務體系(金融+物流),改用 Mode B 較好

---

## 重要差異:為何不需要 Parent-Child?

電商訂單的「取消」邏輯上**屬於訂單流程的一部分**,而非獨立業務。
把取消拆成 Child workflow 反而:
- 增加狀態追蹤複雜度 (parent 要等 child 結束)
- 取消失敗時難以回到原 Parent 繼續其他補償
- idempotency 設計更複雜 (parent 跟 child 都要查)

**直接用單一 workflow 內的 state 切換** (`mode: "place" | "cancel"`) 是最乾淨的做法。
