---
name: vibe-workflow-design-v2
description: 從業務需求與 host API 規格出發,設計可直接整併到 SonataFlow / Kogito 平台的 workflow draft。涵蓋 9 項設計期自我檢查守則、平台相容性預檢、整合前置產出物(OpenAPI specs / workflow YAMLs / DDL / Mock Java / Test / 規格書)。設計完成即可移交 `sonataflow-integration` skill。
---

# Vibe Workflow Design v2

> v2 重點:把 8 個真實整併踩坑(從 `draft-omni-counter-repayment` → `project-0825-pd` 案例)上移為**設計期自我檢查守則**,讓 draft 在交付前就符合目標平台規範,降低下游整合工時 60%。

## 📦 套件內容

```
vibe-workflow-design-v2/
├── SKILL.md                          # 本檔 (SOP 主文件)
├── examples/                         # 完整範例
│   ├── 01-financial-repayment/       # 金融信用卡繳款 (Mode B,真實案例)
│   ├── 02-ecommerce-order/           # 電商訂單履行 (Mode A 範本)
│   └── 03-insurance-claim/           # 保險理賠 (Mode B 跨領域)
└── references/                       # 可重用資源
    ├── 01-platform-checks/           # 6 項平台相容性預檢 (各含自動檢查腳本)
    ├── 02-self-check/                # 15 項 self-check 清單
    ├── 03-templates/                 # 5 種 workflow YAML 範本
    ├── 04-config-snippets/           # application.properties.snippet 完整模板
    └── 05-fqcn-template/             # spec.md §0 假設清單完整模板
```

**第一次使用**: 先讀 `examples/01-financial-repayment/` (最完整,真實案例)
**對應業務找範本**: 看 `examples/` 找最接近的模式
**遇到特定問題**: 翻 `references/01-platform-checks/` 找對應的預檢 + 自動檢查腳本

---

## 觸發條件

當使用者訊息包含以下任一:
- 「設計 / 起草 / 規劃 workflow」
- 「從業務需求做一份 draft」
- 「新業務要做 workflow 雛型」
- 「產生可直接整併的 workflow spec」
- 看到業務需求書 (BR-xxx) + host API 規格 + sample payloads

**不要**用於:
- ❌ 已存在的 draft 整併 (用 `sonataflow-integration` skill)
- ❌ 純文件撰寫 (用一般寫作工具)
- ❌ 既有 workflow 修改 (用 `vibe-workflow-design` v1 + 手動)

---

## Step 0: 前置調研 (5 個必問)

| # | 問題 | 影響 |
|---|---|---|
| 0a | 目標平台是哪個? (SonataFlow 10.2.0 / 其他 Kogito 版本 / Camunda / Airflow) | 決定 workflow YAML dialect、可用 function |
| 0b | 整合到哪個既有 project? 模組結構為何? (transfer-workflow / reconciliation-api 等) | 決定 package 命名、service 位置 |
| 0c | 有哪些 host API 規格? (OpenAPI / AsyncAPI / 純文件) | 決定 spec 檔案產出格式 |
| 0d | DB / 對帳目標是什麼? (SQLite + Flyway / Postgres / 無) | 決定 V 編號起點、View DDL 必要性 |
| 0e | 對外 API contract 與 mock 端點需求? (Parent 對外 / Child 內部 / mock for dev) | 決定 test 套件設計 |

**若任何問題用戶未回答,主動詢問;不可假設。**

---

## Step 1: 業務需求拆解 (與平台無關)

### 1a. 寫一份 `spec.md` 草稿 (§0 假設清單 + §1 概覽 + §2 輸入輸出)

**§0 假設清單強制結構** (H1-Hn):

| # | 假設 | 為何這樣假設 | 待確認問題 | 落地策略 |
|---|---|---|---|---|
| H1 | 輸入欄位 N 個 | 業務書 §X | — | spec §2.1 schema 對應 |
| H2 | 終態 finalStatus 有 M 個 | 業務書 §Y | — | spec §2.3 + status-rewrite config 對應 |
| H3 | ... | ... | ... | ... |
| H<sub>n</sub> | 新增 service FQCN: `xxx.Yyy::method` | 既有 service 未提供 | 需實作 service bean | 在 Step 4 補 Java service |

**⭐ 關鍵**: H<sub>n</sub> 必須明確標註「FQCN 假設」,這是下游 `sonataflow-integration` 識別要新建 / 擴充 service 的唯一依據。

### 1b. 識別 workflow 結構模式 (5 種常見)

| 模式 | 適用情境 | 典型架構 |
|---|---|---|
| **A. 單層 Saga LIFO** | 跨 1 個外部系統,2 階段提交 | workflow 內: ForwardState → CheckResult → (RollbackState if fail) → EndState |
| **B. Parent + 2 個 Child Subflow** | 業務多入口,依 dispatcher 路由 | Parent: Validate → Idempotency → Dispatcher → (subflow) → End<br>Child A: 對應業務 A<br>Child B: 對應業務 B |
| **C. 多層 Parent** | 多層級審批 / 多階段業務流 | 多個 Parent 互相 subflow 委派 |
| **D. 事件驅動** | 接收外部事件觸發 | EventListener → Validate → Process |
| **E. 計時 / 排程** | 排程觸發 | Timer → Validate → Process |

**⭐ 識別結果決定 YAML 結構**: B 模式 → 有 subflow,有 Step 6 「平台相容性預檢」必須過 hyphen ID 檢查。

### 1c. 識別「終態 vs 業務碼」分離需求

**重要設計決策**: 對外 API response 要用以下哪種 convention?

| Convention | 適用情境 | 對應 HTTP 改寫需求 |
|---|---|---|
| **舊 convention** (saga2-transfer-workflow) | `status: STRING` 一個欄位 | 需 status-rewrite 改寫 HTTP code |
| **新 convention** (omni-cash-transaction) | `status: 0/1` (int) + `finalStatus: STRING` 兩欄位 | 需 status-rewrite 改寫 HTTP code |
| **純 HTTP status** | 對外不需 finalStatus,直接靠 HTTP code 區分 | 不需 status-rewrite |

**對應 platform 對齊**:
- 若 target platform 有 `WorkflowStatusFilter` 改寫機制 → 須沿用其 convention
- 若無 → 可自由設計

---

## Step 2: 產出 OpenAPI specs (3 種角色)

### 2a. 對外契約 spec (e.g., `omni-counter-repayment-api.yaml`)

- 路徑: `notebooks/<entry-name>.yaml` (或 `openapi/<entry-name>.yaml`)
- 內容:
  - `info.title` 與 `description` 明確標記「此為 Parent / 對外 entry」
  - 請求/回應 schema 完整
  - `operationId` 唯一且具語意 (e.g., `executeOmniRepayment`)
  - 範例值提供 happy path + error path

### 2b. Host API 規格 (e.g., `core-account-cash-deposit-api.yaml`)

- 一個 host 一個 spec
- `parameters: [in: path]` 區段務必明確 (下游整合會自動掃描)
- `paths` 完整含所有 operation (正向 + 反向 + 取消 + 查詢)

### 2c. Mock 規格 (給 dev profile mock 用)

- 通常等同 host API 規格 (mock 實作 host API)
- 但**重要**: mock 的 `@Path` 與 spec 的 `paths` 必須一致 (e.g., `/CoreAccount/{creditcardid}/CashDeposit/Execute`)
- 若有 path param,設計時就要明確標出,否則下游整合時 workflow 會丟 `Illegal character in path`

---

## Step 3: 產出 workflow YAML (Serverless Workflow v0.8)

### 3a. 平台相容性預檢 (設計期必跑)

| 檢查 | 命令 | 不通過時 |
|---|---|---|
| Kogito 10.2.0 + 含 subFlowRef + workflow id 含 hyphen | 設計時主動詢問: 「workflow id 命名用 snake_case 或 hyphen-case?」 | 改 snake_case,或 spec.md 標註 v1.0 hotfix |
| actionDataFilter 是否用 `.result.X` | 自我檢查清單 (見 Step 7) | 改用頂層欄位 |
| path param 是否在 payload | 自我檢查清單 | 自動加 |
| output 是否含 `status: 0/1` + `finalStatus: STRING` 兩欄位 (若用新 convention) | 自我檢查清單 | 補上 |
| YAML 是否有 trailing comma | 自我檢查清單 | 移除 |

### 3b. YAML 結構樣板 (3 種模式對應)

**模式 A 範本 (單層 Saga LIFO)**:
```yaml
id: <workflow_id>
version: '1.0.0'
specVersion: '0.8.0'
name: <human readable name>
start: <first_state>
metadata:
  domain: <business-domain>
  pattern: saga-lifo-compensation
  criticality: <low|medium|high>
  owner: <team>
timeouts:
  workflowExecTimeout: PT5M
errors:
  - name: platformError
    code: 'PLATFORM_ERROR'
functions:
  - name: callApiViaOpenAPI
    operation: 'service:com.example.transfer.workflow.MyOpenApiService::callOpenApi'
    type: custom
  - name: recordAuditLog
    operation: 'service:com.example.reconciliation.AuditLogService::saveLog'
    type: custom
  - name: notifyOps
    operation: 'service:com.example.reconciliation.OpsAlertService::raise'
    type: custom
states:
  - name: ValidateInput
    type: switch
    dataConditions: [...]  # input validation rules
  - name: CallCoreForward
    type: operation
    actions:
      - functionRef:
          refName: callApiViaOpenAPI
          arguments:
            functionName: "callApiViaOpenAPI"
            schemaRef: 'specs/<host-api>.yaml#<operationId>'
            payload:
              <path_param_1>: '${ .<input_field> }'   # ⭐ 自動注入
              <field_1>: '${ .<input_field> }'
              ...
        actionDataFilter:
          results: '{status: .code, message: .message, ...}'  # ⭐ 頂層,非 .result
          toStateData: '${ .coreResult }'
  ...
```

**模式 B 範本 (Parent + 2 Child)**:
- Parent workflow YAML 含 `subFlowRef: { workflowId: <child_id>, version: ... }`
- ⭐ **重要**: child workflow id 必須是 snake_case (見 3a 預檢)
- Child workflow YAML 各自獨立,但 functions 與 services 沿用

**模式 D 範本 (事件驅動)**:
- 起點是 event trigger state
- 含 `eventConditions` 過濾事件

### 3c. ActionDataFilter 結構守則 (跨模式通用)

**核心**: `MyOpenApiService::callOpenApi` 回傳 response 是**頂層欄位**,不是 `.result` 底下。

```yaml
# ✅ 對
results: '{status: .code, message: .message, track_id: .track_id, errorType: .errorType, _httpStatus: ._httpStatus, errors: .errors}'

# ❌ 錯
results: '{status: .result.code, message: .result.message, ...}'
```

**若有 `result` sub-object** (例如 host 回 `{status: 0, result: {sequenceNumber: "xxx"}}`):
```yaml
# ✅ 對: sub-object 內的欄位直接寫進 results,不要包 .result
results: '{status: .status, sequenceNumber: .result.sequenceNumber}'
```

### 3d. StateDataFilter Output 結構守則 (跨模式通用)

依 convention 決定:

```yaml
# 舊 convention (saga2-transfer-workflow 風格)
stateDataFilter:
  output: |
    {
      status: .finalStatus,
      message: .finalMessage,
      ...
    }

# 新 convention (omni-cash-transaction 風格,推薦)
stateDataFilter:
  output: |
    {
      track_id: .<key_id_field>,
      workflow: (if .<dispatch_field> == "A" then "REPAYMENT" else "CANCELLATION" end),
      status: (if .finalStatus == "SUCCESS" or ... then 0 else 1 end),  # int 0/1
      finalStatus: .finalStatus,  # string
      message: .finalMessage,
      <host_api_result_1>: (.coreResult // null),
      ...
    }
```

---

## Step 4: 補 Java 服務 (當 spec 標註新 FQCN 時)

### 4a. 識別需要新建 / 修改的 service

讀 `spec.md §0 H<sub>n</sub>` 假設清單,找出所有 FQCN:

```yaml
H13: IdempotencyService::findBySequenceNumber  # 新建
H14: AuditLogService::markCancelledBy          # 擴充既有
```

### 4b. 通用 service 模板

放在 `<project>/<domain>/<api>/src/main/java/com/example/<domain>/<ClassName>.java`:

```java
package com.example.<domain>;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

@ApplicationScoped
public class <ClassName> {

    private static final Logger LOG = LoggerFactory.getLogger(<ClassName>.class);
    private static final ObjectMapper MAPPER = new ObjectMapper();

    @Inject
    DataSource dataSource;

    // 1. 展開參數版入口 (對應 Kogito reflection 雙重綁定)
    public JsonNode <methodName>(String arg1, Object arg2) {
        return do<MethodName>(arg1, arg2 != null ? arg2.toString() : null);
    }

    // 2. JsonNode 單參數版入口 (Kogito codegen 預設生成)
    public JsonNode <methodName>(JsonNode arguments) {
        if (arguments == null) {
            return MAPPER.createObjectNode().put("<key>", false);
        }
        // 從 arguments 解析 arg1, arg2
        return do<MethodName>(arg1, arg2);
    }

    private JsonNode do<MethodName>(String arg1, String arg2) {
        // 實際 SQL 邏輯
    }
}
```

### 4c. 既有 service 擴充原則

- 既有 `AuditLogService` / `OpsAlertService` / `MyOpenApiService` 必須優先複用,不重造
- 擴充方法須「展開參數版」+「JsonNode 版」雙進入點 (Kogito reflection 兩種都用)

### 4d. Flyway migration (若有新欄位需求)

放在 `<project>/<domain>/<api>/src/main/resources/db/migration/V<X>.<Y>.<Z>__<description>.sql`:

```sql
-- V 編號:從既有最大 V 編號 +1 (從 project/db/migration/ 找)
-- description:英文小寫,底線分隔
ALTER TABLE workflow_execution_log ADD COLUMN <new_col> TEXT;
CREATE INDEX IF NOT EXISTS idx_<table>_<col> ON <table>(<col>);
```

---

## Step 5: 產出 Mock Resources (dev profile)

### 5a. 命名對齊既有 project 模組 (設計期就做)

**設計期先問**:
- 既有 mock 模組的 package 是? (e.g., `org.acme.transfer.api`)
- 若無既有,新模組該叫? (e.g., `org.acme.cashrepayment.api`)

直接使用既有 package (或新命名),**不要設計成一個 draft-only package**,這會增加下游整合的 sed rename 工時。

### 5b. Mock Resource 樣板 (2 種 sentinel 模式)

**Sentinel 模式 A: 業務 payload 內字串前綴**
```java
@Path("/CoreAccount/{creditcardid}/CashDeposit/Execute")
public class CoreCashDepositResource {
    @POST
    public Response execute(@PathParam("creditcardid") String creditcardid,
                            CoreCashDepositRequest request) {
        // 業務拒絕 sentinel: amount = "0" 或 "0000000000" 或以 "FAIL" 開頭
        if (isBusinessReject(request.amount)) {
            return Response.status(403).entity(buildError("E0024", "金額不符", null)).build();
        }
        // RBFAIL sentinel: operationType=B 且 sequenceNumber 以 "RBFAIL" 開頭
        if ("B".equals(request.operationType) && request.sequenceNumber != null
                && request.sequenceNumber.startsWith("RBFAIL")) {
            return Response.status(403).entity(buildError("E0050", "回沖失敗", null)).build();
        }
        // 正常成功
        ...
    }
}
```

**Sentinel 模式 B: 獨立 sentinel field** (避免破壞 input validation)
```java
public class CoreCashDepositRequest {
    public String partyId;
    public String branchCode;
    public String amount;
    public String sequenceNumber;
    public String operationType;
    public String __sentinel;  // 設計期專用,真實 API 不會有
}
```

**設計期決策**:
- 若 input validation 對業務 payload 嚴格 → 採模式 B (獨立 sentinel field)
- 若 input validation 寬鬆 → 採模式 A (字串前綴)

### 5c. DTO 設計守則

- 一個 request + 一個 response + 一個 result sub-object (e.g., `CoreCashDepositRequest` / `CoreCashDepositResponse` / `CoreCashDepositResult`)
- 極簡風格: 純 public field,無 getter/setter (與既有 transfer-mock 一致)
- ErrorDetail 共用 DTO 放 `org.acme.<project>.api.dto.ErrorDetail`

---

## Step 6: 平台相容性預檢 (★ v2 新增)

設計期就跑這 6 項檢查,任何一項不通過就修正 draft,不交付:

### 6.1 Workflow ID 命名 (Kogito 10.2.0 相容性)

```bash
# 自動檢查
for f in draft/spec/*.sw.yaml; do
  if grep -q "subFlowRef" "$f"; then
    id=$(grep "^id:" "$f" | awk '{print $2}')
    if [[ "$id" == *-* ]]; then
      echo "❌ FAIL: $f workflow id '$id' 含 hyphen,會觸發 Kogito 10.2.0 codegen bug"
    fi
  fi
done
```

不通過: 改 snake_case + 在 spec.md 標註 v1.0 hotfix

### 6.2 actionDataFilter 結構 (MyOpenApiService 相容性)

```bash
# 自動檢查
grep -A 1 "actionDataFilter" draft/spec/*.sw.yaml | grep -E "\.result\."
# 任何 .result.X 配對都是錯的
```

不通過: 改為直接讀頂層 `.X`

### 6.3 Path Parameter 自動注入

```bash
# 自動檢查: 對每個 callApiViaOpenAPI 的 schemaRef,找出 spec 的 path param,
# 並確認 payload 內有對應 key
for spec in draft/notebooks/*-api.yaml; do
  for op in $(grep "operationId:" "$spec" | awk '{print $2}'); do
    path_params=$(python3 -c "
import yaml
with open('$spec') as f:
    s = yaml.safe_load(f)
for path, methods in s.get('paths', {}).items():
    for m, op in methods.items():
        if op.get('operationId') == '$op':
            for p in op.get('parameters', []):
                if p.get('in') == 'path':
                    print(p['name'])
")
    echo "Schema $spec operation $op needs path params: $path_params"
  done
done
```

不通過: 在每個對應的 workflow YAML 的 payload 加 `xxx: '${ .對應欄位 }'`

### 6.4 StateDataFilter.output 欄位 (Convention 對齊)

```bash
# 若用新 convention,確認 output 含 status (int) + finalStatus (string) 兩欄位
grep -A 20 "stateDataFilter:" draft/spec/*.sw.yaml | grep -E "status:|finalStatus:"
```

不通過: 補上 `status: 0/1` (jq expression) 與 `finalStatus: .finalStatus`

### 6.5 YAML 語法嚴格性

```bash
# 檢查 list item 後是否多餘 comma
grep -E "^\s+\w+:\s+'.*',$" draft/spec/*.sw.yaml
# 任何結尾有 `,` 的 list item 是錯的
```

不通過: 移除 trailing comma

### 6.6 Mock sentinel vs input validation 相容性

```bash
# 列出所有 mock sentinel 字串
grep -h "startsWith\|equals.*\"0\"" draft/spec/mocks/*.java | grep -oE "\"FAIL[a-zA-Z_]*\"|\"RBFAIL\"|\"0\"|\"0000000000\""
# 對每個 sentinel 驗證它能通過 input validation 的 regex
```

不通過: 改用模式 B (獨立 sentinel field) 或放寬 validation regex

---

## Step 7: 自我檢查清單 (★ v2 設計期 SOP 核心)

設計完成後,逐項檢查:

| # | 檢查項 | 通過條件 |
|---|---|---|
| 7.1 | `spec.md §0 假設清單` 含 FQCN 假設 | ✅ 每個新 service 都有 FQCN + 落地策略 |
| 7.2 | `spec.md §0` 含 `id 命名決策` 標記 | ✅ 明確寫出 snake_case 或註明 v1.0 hotfix |
| 7.3 | `spec.md §0` 含 `convention 決策` (status / finalStatus) | ✅ 標明用舊 / 新 / 純 HTTP status |
| 7.4 | OpenAPI spec 的 path param 與 workflow YAML 的 payload 對應 | ✅ 每個 `{xxx}` 都有對應 payload key |
| 7.5 | actionDataFilter 全部用頂層欄位 (非 .result.X) | ✅ grep 不到 `.result.X` 配對 |
| 7.6 | stateDataFilter.output 對應選定的 convention | ✅ 舊:`status: STRING`;新:`status: 0/1` + `finalStatus: STRING` |
| 7.7 | Mock sentinel 字串能通過 input validation | ✅ 設計期實測或改用模式 B |
| 7.8 | Mock package 命名對齊既有 project | ✅ 不需 rename |
| 7.9 | SQL migration V 編號遞增 | ✅ 從既有最大 +1 |
| 7.10 | YAML 沒有 trailing comma | ✅ grep 不到 `,$\|,$` 結尾的 list item |
| 7.11 | spec/config/application.properties.snippet 含 status-rewrite 完整配置 | ✅ workflows + mapping 兩個都列出 |
| 7.12 | 測試套件包含 happy path + 主要 error path | ✅ 至少 5 個測試案例 |
| 7.13 | 測試資料字串能通過 input validation | ✅ 每個測試 payload 都驗過 |
| 7.14 | spec.md §8 Project Mapping Manifest 完整 | ✅ 每個 draft 檔案都有對應正式路徑 |
| 7.15 | spec.md §9 已知限制有列 | ✅ v1.0 留白 / 簡化項目都明確標出 |
| 7.16 | Input Validation Regex 與 API Sample 相容 | ✅ 通路代碼/欄位正則相容真實範例（如 `2500P`） |
| 7.17 | 測試案例採用動態唯一序號 | ✅ 獨立測試採動態序號，避免誤觸 Parent 冪等 |
| 7.18 | jq 條件表達式 `tonumber` 防呆 | ✅ 具備非純數字哨兵保護，避免 Runtime Exception |
| 7.19 | Workflow Root 顯式定義 `start: <StateName>` | ✅ 避免 Kogito 拋出 `Workflow.getStart() is null` NPE |
| 7.20 | Service Function 參數鍵值精準對齊 Java Overload 簽名 | ✅ `workflowId` 與 `businessKey` 齊全，避免 ClassCastException |
| 7.21 | OpenAPI Spec 顯式定義 `servers[0].url` | ✅ 避免 MyOpenApiService 拋出「無法確定 API Base URL」異常 |

---

## Step 8: 交付前最後一次檢查

- [ ] 7 個目錄結構都產出 (notebooks / spec / spec/mocks / spec/mocks/dto / spec/db / spec/config / spec/schemas / spec/tests)
- [ ] 15-20 個檔案 (依業務複雜度)
- [ ] spec.md 14 條假設清單 + 11 個章節齊全
- [ ] 6 項平台相容性預檢全綠
- [ ] 21 項自我檢查全綠
- [ ] 包成 `draft-<name>.zip` 給下游 `sonataflow-integration` skill

---

## 通用化考量 (跨領域)

### 適用領域

此 skill 不只限於「信用卡臨櫃現金繳款」,可應用於:

| 業務領域 | 範例 |
|---|---|
| 金融交易 | 信用卡現金繳款 (本次案例)、轉帳、匯款 |
| 電商訂單 | 下單 → 付款 → 出貨 → 退貨 |
| 保險理賠 | 申請 → 審核 → 撥款 |
| 物流配送 | 接單 → 揀貨 → 出貨 → 簽收 |
| 醫療掛號 | 預約 → 報到 → 看診 → 繳費 |

**共通特性** (這些領域都適用):
- 多階段業務流 (saga)
- 跨多個外部系統 (Core + CC 等)
- 需要對帳 (audit log)
- 需要 idempotency
- 需要 failure rollback

### 不適用場景

- 純 CRUD 應用 (無業務流)
- 純批次處理 (用 Airflow 而非 workflow engine)
- 純 event streaming (用 Kafka Streams)

---

## 與其他 skill 的關係

```
vibe-workflow-design-v2 (本 skill, 上游/Draft 階段)
  │
  │  產出 draft-<name>/ 套件
  │  (含 15-20 個檔案,符合 6 項預檢 + 15 項 self-check)
  │
  ▼
sonataflow-integration (下游/Integration 階段)
  │
  │  把 draft 整併進 project-0825-pd
  │  (10 步 SOP + 失敗模式速查)
  │
  ▼
最終產出:quarkus-run.jar + 通過 E2E smoke test
```

**本 skill 完成後,移交給 `sonataflow-integration` 即可預期整合階段工時 < 1 小時**(若上游預檢全綠)。

---

## 反模式 (不要這樣做)

- ❌ **不要產出 hyphen id + subflow 的 workflow** — 必觸發 Kogito 10.2.0 bug
- ❌ **不要在 actionDataFilter 用 `.result.X`** — 與 MyOpenApiService response 結構不符
- ❌ **不要忘了 path param** — 必在 payload 內顯式提供
- ❌ **不要設計 input validation regex 攔截 mock sentinel** — 兩個意圖會衝突
- ❌ **不要用 draft-only 的 package 命名** — 必增加下游 rename 工時
- ❌ **不要用 trailing comma** — YAML 解析失敗
- ❌ **不要用未對齊 platform 的 convention** — 必觸發 status-rewrite 問題
- ❌ **不要省略 status-rewrite config snippet** — 下游必再摸索一次
- ❌ **不要省略 FQCN 假設清單** — 下游無法識別要新建/修改的 service
- ❌ **不要省略測試套件** — 整合後無法快速驗證

---

## 輸出物結構 (draft-<name>/)

```
draft-<name>/
├── notebooks/                              # OpenAPI specs (對外 + host)
│   ├── <entry-api>.yaml                   # 對外契約
│   ├── <host-api-1>-api.yaml              # host #1 規格
│   ├── <host-api-2>-api.yaml              # host #2 規格
│   └── ...
├── spec/                                   # workflow + 規格
│   ├── <workflow-parent>.sw.yaml          # Parent workflow (若有)
│   ├── <workflow-child-A>.sw.yaml         # Child A
│   ├── <workflow-child-B>.sw.yaml         # Child B
│   ├── schemas/<input-schema>.json        # input JSON Schema
│   ├── db/V<X>.<Y>.<Z>__<desc>.sql       # Flyway DDL (從既有最大 +1)
│   ├── config/application.properties.snippet  # 平台組態片段
│   ├── mocks/<Resource1>.java             # JAX-RS mock
│   ├── mocks/<Resource2>.java
│   ├── mocks/dto/                         # DTO 群
│   │   ├── <Resource1>Request.java
│   │   ├── <Resource1>Response.java
│   │   ├── <Resource1>Result.java
│   │   └── ErrorDetail.java
│   ├── tests/<WorkflowTest>.java          # @QuarkusTest
│   └── spec.md                            # 規格書 (14 條假設 + 11 章節)
└── (optional) README.md
```

---

## 版本演進

| 版本 | 重點 |
|---|---|
| v1.0 | 基礎 draft 產出 (notebooks/spec/mocks/tests) |
| v1.1 | 加入 H1-H14 假設清單 + spec.md 11 章節 |
| **v2.0** (本版) | **加入 6 項平台相容性預檢 + 15 項自我檢查 + 9 項可上移守則 + 3 個完整 examples + 5 個 reference 模組** |
| 未來 v3.0 | 預期:根據更多領域案例擴展 pattern (D 事件驅動 / E 計時) 的 SOP,加入 TypeScript/Go 多語言 mock 模板 |

---

## 對應 reference / example 速查

設計中遇到下列問題,直接翻對應 reference:

| 問題 | 翻哪個 reference | 對應 example |
|---|---|---|
| workflow id 怎麼命名才不會觸發 Kogito bug? | `references/01-platform-checks/01-workflow-id-naming.md` | 全部 examples |
| actionDataFilter 怎麼寫才對? | `references/01-platform-checks/02-action-data-filter.md` | 全部 workflow YAML |
| path param 怎麼注入? | `references/01-platform-checks/03-path-parameter-injection.md` | 全部 workflow YAML |
| stateDataFilter 該用哪種 convention? | `references/01-platform-checks/04-state-data-filter-convention.md` | 01-financial, 03-insurance |
| YAML 語法有什麼陷阱? | `references/01-platform-checks/05-yaml-strictness.md` | 全部 |
| mock sentinel 怎麼設計才不違反 input validation? | `references/01-platform-checks/06-mock-sentinel-vs-input-validation.md` | 01-financial |
| 設計完成後怎麼驗證? | `references/02-self-check/self-check-list.md` | 對所有 examples 套用 |
| workflow YAML 結構該長怎樣? | `references/03-templates/workflow-yaml-templates.md` | 全部 examples |
| application.properties 該加什麼? | `references/04-config-snippets/application-properties-snippet.md` | 01-financial, 03-insurance |
| spec.md §0 假設清單怎麼寫? | `references/05-fqcn-template/spec-assumption-template.md` | 01-financial/spec/spec.md |

---

## 對應 example 速查

| 業務情境 | 用哪個 example | 為何 |
|---|---|---|
| 金融交易 (繳款/轉帳/匯款) | `examples/01-financial-repayment/` | 真實案例,最完整 |
| 電商 (下單/出貨/退貨) | `examples/02-ecommerce-order/` | Mode A 範本,3 階段 LIFO |
| 保險/金融審批 (理賠/核保) | `examples/03-insurance-claim/` | Mode B 跨領域,結構相同但語意不同 |
| 物流配送 | 參考 `02-ecommerce-order` Mode A 改寫 | — |
| 醫療掛號 | 參考 `01-financial-repayment` Mode B 改寫 | — |
| 純 CRUD 應用 | ❌ 不適用 | 改用一般 API 設計 |
| 純批次處理 | ❌ 不適用 | 改用 Airflow skill |
