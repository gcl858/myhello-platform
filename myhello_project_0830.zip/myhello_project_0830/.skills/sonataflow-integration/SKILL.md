---
name: sonataflow-integration
description: 將 draft 階段的 SonataFlow workflow 套件(specs / workflow YAMLs / DDL / Mock Java / Test)整併到 project-0825-pd 多模組 Quarkus 平台。涵蓋 Kogito 10.2.0 的已知陷阱 (hyphenated subflow workflow id、status-rewrite 對齊、path param 注入、actionDataFilter 結構)。
---

# SonataFlow Integration Skill (v1.0)

> 從一次真實整併 (`draft-omni-counter-repayment` → `project-0825-pd`) 提煉的 6-step SOP + 5 個已知踩坑解法。
> 適用於任何「有一個 draft 目錄,含 workflow YAML + OpenAPI spec + Java mock + SQL migration + Test,要整併進 Quarkus 多模組專案」的場景。

---

## 觸發條件

當使用者訊息包含以下任一,主動載入:
- 「整併 draft / workflow 到 project-0825-pd」
- 「把 sonataflow 套件整合進專案」
- 「新 workflow 要上線,幫我合併」
- 看到 draft 目錄結構含 `notebooks/*.yaml` + `spec/*.sw.yaml` + `spec/mocks/*.java` + `spec/db/*.sql` + `spec/tests/*.java`

---

## Step 0: 環境檢查

- 確認 Java 17、Maven 3.8+ 可用 (`which java mvn`)
- 確認 Maven mirror 已設定 (Aliyun `https://maven.aliyun.com/repository/central`,mirrorOf=*)
- 確認 JVM truststore 含企業 proxy cert (`keytool -list -cacerts | grep mvn-proxy`)
- 確認 `/root/.m2/settings.xml` mirror 配置正確

---

## Step 1: 分析 draft 結構

預期 draft 內含下列結構 (基於 `vibe-workflow-design` skill 的標準產出):
```
draft-<name>/
├── notebooks/
│   ├── <api-1>.yaml          # 對外契約 spec
│   ├── <api-2>-api.yaml      # host call spec
│   └── <api-3>-api.yaml
├── spec/
│   ├── <workflow-1>.sw.yaml  # Parent / Child workflow
│   ├── <workflow-2>.sw.yaml
│   ├── <workflow-3>.sw.yaml
│   ├── schemas/<input>-schema.json
│   ├── db/V<X>.<Y>.<Z>__<desc>.sql
│   ├── config/application.properties.snippet
│   ├── mocks/<Resource>1.java
│   ├── mocks/<Resource>2.java
│   ├── mocks/dto/*.java
│   └── tests/<TestName>.java
└── spec.md                    # 規格書,內含 14 條假設清單
```

**關鍵讀取點**:
1. 讀 `spec.md` §0 假設清單 (H1-H14),找出需要新建 / 修改的 Java 服務
2. 讀 §8 Project Mapping Manifest,確認 draft 規劃的目標路徑
3. 檢查每個 `*.sw.yaml` 的 `functions:` section,識別需要新 service bean 的 FQCN

---

## Step 2: 落規格檔 (純複製,無變形)

| draft 路徑 | 目標路徑 |
|---|---|
| `notebooks/*.yaml` | `<project>/domain-transfer/transfer-workflow/src/main/resources/specs/` |
| `spec/schemas/*.json` | `<project>/domain-transfer/transfer-workflow/src/main/resources/schemas/` |
| `spec/db/V*.sql` | `<project>/domain-transfer/transfer-workflow/src/main/resources/db/migration/` |

**注意**:
- DatabaseMigrationRunner 自動掃描 `db/migration/`,V 編號必須遞增
- 同一個目標目錄不覆蓋既有檔案(先比對 hash)

---

## Step 3: 落 workflow YAML + 套用 Kogito bug 修正

### Step 3a: 複製 3 個 workflow

```bash
cp draft/spec/*.sw.yaml <project>/domain-transfer/transfer-workflow/src/main/resources/
```

### Step 3b: ⭐ Kogito 10.2.0 codegen bug 修正

**症狀預兆**: 任何 workflow 有 `subFlowRef:` 且 workflow id 含 hyphen (`-`)。

**檢測**:
```bash
grep -l "subFlowRef" <project>/domain-transfer/transfer-workflow/src/main/resources/*.sw.yaml
# 若結果的 yaml 內有 id: xxx-yyy → 必須改名
```

**解法** (Python):
```python
mappings = {
    "omni-cash-transaction": "omni_cash_transaction",
    "repayment-cash-deposit": "repayment_cash_deposit",
    "repayment-cash-cancellation": "repayment_cash_cancellation",
    # ... 視實際 draft 而定
}
for f in workflow_yaml_files:
    content = open(f).read()
    for old, new in mappings.items():
        content = content.replace(old, new)
    open(f, "w").write(content)
```

**影響**: 對外 API path 也會從 `/xxx-yyy` 變 `/xxx_yyy`,需在 spec 註明 v1.0 hotfix。

---

## Step 4: 補 Java 服務

### Step 4a: 識別需要新建 / 修改的 service

讀 draft 的 `spec.md §0` 假設清單,找出所有 `假設 FQCN` 的 service。例如:
- H6: `IdempotencyService::findBySequenceNumber` → 新建
- H13: `IdempotencyService` 假設 FQCN → 新建
- H14: `AuditLogService::markCancelledBy` → 擴充既有

### Step 4b: 新建 service 類別

放在 `domain-reconciliation/reconciliation-api/src/main/java/com/example/reconciliation/`

**模板** (以 `IdempotencyService` 為例):
```java
@ApplicationScoped
public class IdempotencyService {
    @Inject DataSource dataSource;
    private static final ObjectMapper MAPPER = new ObjectMapper();

    public JsonNode findBySequenceNumber(String workflowId, Object businessKey) {
        // ... v1.0 簡化實作: query workflow_execution_log
    }
    public JsonNode findBySequenceNumber(JsonNode arguments) { ... }  // for Kogito reflection
}
```

**重要**: 提供「展開參數版」+「JsonNode 單參數版」兩個進入點,Kogito 反射綁定 arguments 兩種都用。

### Step 4c: 擴充既有 AuditLogService

```java
// 既有 doSaveLog 維持不變,加 2 個新方法
public JsonNode findBySequenceNumber(String workflowId, Object businessKey) { ... }
public JsonNode findBySequenceNumber(JsonNode arguments) { ... }

public JsonNode markCancelledBy(Object originalSequenceNumber, Object cancelledBy, Object cancelledAt) { ... }
public JsonNode markCancelledBy(JsonNode arguments) { ... }
```

### Step 4d: 若需新欄位,加 Flyway migration

**版本規範**: `V<X>.<Y>.<Z>__<description>.sql`

```sql
-- 範例 V1.0.1
ALTER TABLE workflow_execution_log ADD COLUMN cancelled_by TEXT;
ALTER TABLE workflow_execution_log ADD COLUMN cancelled_at TIMESTAMP;
CREATE INDEX IF NOT EXISTS idx_wel_cancelled_by ON workflow_execution_log(cancelled_by);
```

放 `domain-reconciliation/reconciliation-api/src/main/resources/db/migration/`

---

## Step 5: 落 mock resources (小心 package 替換陷阱)

### Step 5a: 複製 Java 檔,package 從 draft 的命名空間改成既有 mock 模組的命名空間

```python
# 範例:draft 用 org.acme.cashrepayment.api,正式專案用 org.acme.transfer.api
for f in glob("draft/spec/mocks/*.java"):
    content = open(f).read()
    content = content.replace("org.acme.cashrepayment.api", "org.acme.transfer.api")
    open(f"dev/transfer-mock/src/main/java/org/acme/transfer/api/{basename(f)}", "w").write(content)
```

### Step 5b: ⭐ 避免 sed 二次替換陷阱

**坑**: 如果 draft 的 DTO 已經在 `org.acme.cashrepayment.api.dto` package,sed 兩次替換會變成 `org.acme.transfer.api.dto.dto` (錯誤)。

**預防**:
```python
# 用 Python 取代 sed,精準控制替換邏輯
# 或用兩階段 sed:
# 1. 先把 .cashrepayment.api.dto. 換成 .transfer.api.dto. (全詞匹配)
# 2. 再把 .cashrepayment.api. 換成 .transfer.api. (排除已換過的)
```

### Step 5c: DTO 放 `org.acme.transfer.api.dto/` 子目錄

---

## Step 6: ⭐ 4 個 workflow 內容修正(整併特有的坑)

### 6a. Path parameter 注入

**症狀**: workflow 調用 OpenAPI 時報 `Illegal character in path ... {xxx}`。

**根因**: mock 的 `@Path("/foo/{xxx}/bar")` 但 workflow 沒在 payload 帶 `xxx`。

**解法**: 在每個 callApiViaOpenAPI 的 payload 內顯式加:
```yaml
payload:
  creditcardid: '${ .partyId }'   # ← 補上
  partyId: '${ .partyId }'
  ...
```

**小心**: YAML list item 不要 trailing comma:
```yaml
# ✗ 錯
creditcardid: '${ .partyId }',
# ✗ 對 (無 comma)
creditcardid: '${ .partyId }'
```

### 6b. actionDataFilter 結構對齊 MyOpenApiService

**症狀**: workflow 走到 FAILED 分支但 host API 回 200,因為 `.result.status` 是 null。

**根因**: `MyOpenApiService` 把 host API response 直接放頂層(`.code` / `.message` / `.Account` 等),不是 `.result` 底下。

**解法**: 改 actionDataFilter 直接讀頂層:
```yaml
# ✗ 錯 (假設 response 在 .result 下)
results: '{status: .result.status, message: .result.message, track_id: .result.track_id}'

# ✓ 對 (直接讀頂層)
results: '{status: .status, message: .message, track_id: .track_id, errorType: .errorType, _httpStatus: ._httpStatus, errors: .errors}'
```

### 6c. ⭐ status-rewrite filter 加 finalStatus 支援

**症狀**: workflow 回 `finalStatus: REJECTED_VALIDATION` 但 HTTP code 是 200(應該 400)。

**根因**: 既有 `WorkflowStatusFilter` 只讀 `status` 欄位。新 omni convention 用 `status: 0/1` (int) + `finalStatus: STRING`。

**解法**: 修改 `platform-security/.../SonataFlowSecurityConfig.java` 的 filter:
```java
// 改前
Object status = map.get("status");

// 改後 (優先 finalStatus,退回 status;且只對 String 映射)
Object status = map.get("finalStatus");
if (status == null) {
    status = map.get("status");  // 向下相容 saga2
}
if (status != null && status instanceof String) {
    Integer rewrite = statusRewriteMap.get(status.toString());
    if (rewrite != null) {
        responseContext.setStatus(rewrite);
    }
}
```

### 6d. SQL view workflow_id 對齊

**症狀**: V<X> SQL view 套用後查詢回 0 筆。

**根因**: view 的 `WHERE workflow_id IN (...)` 用了 draft 的 hyphen id,實際是 underscore。

**解法**: 改 V<X> SQL 內的 id 清單,並手動 drop & recreate view (因為 `CREATE VIEW IF NOT EXISTS` 不會重新觸發)。

---

## Step 7: 合併 application.properties

修改 `<project>/distribution/transfer-app/src/main/resources/application.properties`:

```properties
# 1. 加 3 個 workflow 到 status-rewrite 名單
platform.status-rewrite.workflows=saga2-transfer-workflow,omni_cash_transaction,repayment_cash_deposit,repayment_cash_cancellation

# 2. 加 N 個 finalStatus 對映
platform.status-rewrite.mapping=\
VALIDATION_FAILED=400,\
ROLLBACK_FAILED=409,\
REJECTED_VALIDATION=400,\
LOOKUP_FAILED=500,\
CANCEL_ROLLBACK_FAILED=409

# 3. dev profile function bean 註冊 (H6/H13/H14 落地)
%dev.kogito.sw.functions.checkIdempotency.bean=idempotencyService
%dev.kogito.sw.functions.lookupOriginalTransaction.bean=auditLogService
%dev.kogito.sw.functions.markOriginalCancelled.bean=auditLogService
```

> 註:`kogito.sw.functions.X.bean=...` 這種設定 Quarkus 會噴 "Unrecognized configuration key" warning(因為 Kogito 內建 OpenAPI handler 才用這種設定),但對 `service:` 形式的 workflow 沒影響,可忽略。

---

## Step 8: 落測試

```bash
cp draft/spec/tests/*.java <project>/distribution/transfer-app/src/test/java/com/example/platform/distribution/transfer/
# package 替換: <draft-package> → com.example.platform.distribution.transfer
```

---

## Step 9: 編譯 → 測試 → package

### 9a: 編譯
```bash
mvn -B compile -DskipTests -fae -T 1 -Dmaven.wagon.http.retryHandler.count=10
```

### 9b: 測試
```bash
# 先清掉 .lastUpdated 失敗快取
find ~/.m2/repository -name "*.lastUpdated" -delete
find ~/.m2/repository -name "_remote.repositories" -delete
mvn -B test -fae -T 1 -Dmaven.wagon.http.retryHandler.count=10
```

### 9c: package
```bash
# 必須從根跑(子樹 -pl 會因 deployment extension descriptor 缺 jar 失敗)
mvn -B package -DskipTests -fae -T 1 -Dmaven.wagon.http.retryHandler.count=10
```

**預期時間**: 編譯 1-2min、測試 5-10min、package 3-5min(首次下載所有 deps 20-30min)。

---

## Step 10: 端對端 smoke test

```bash
# 啟動 (port 8080 是 mock 預期 port)
nohup java -Dquarkus.http.port=8080 -Dquarkus.profile=dev \
  -jar distribution/transfer-app/target/quarkus-app/quarkus-run.jar \
  > /tmp/transfer-app.log 2>&1 &

# 等 health
for i in {1..30}; do
  HC=$(curl -s -o /dev/null -w "%{http_code}" http://127.0.0.1:8080/q/health)
  [ "$HC" = "200" ] && break
  sleep 3
done

# 跑至少 5 個核心情境:
# 1. P1: operationType=C → 400 REJECTED_VALIDATION
# 2. A1: 正常 SUCCESS → 200,core+cc track_id 都有
# 3. B1: 正常 CANCELLED → 200,Core+CC 反向都成功
# 4. B2: 不存在的 originalSequenceNumber → 500 LOOKUP_FAILED
# 5. P4: Parent 級冪等 (同 seq 重送) → 第二次 IDEMPOTENT_REPLAY

# 查 DB 確認 audit log 落地
sqlite3 data/reconciliation.db \
  "SELECT workflow_id, COUNT(*) FROM workflow_execution_log
   WHERE workflow_id LIKE '%_cash%' OR workflow_id LIKE '%repayment_%' GROUP BY workflow_id;"
```

---

## 整合完成的驗收 checklist

- [ ] `mvn -B package -DskipTests` 全 22 modules BUILD SUCCESS
- [ ] `mvn -B test` 跑出至少 N+1 個測試(N=既有數,1=新測試類別)
- [ ] `transfer-app/target/quarkus-app/quarkus-run.jar` 存在 (~122MB)
- [ ] 啟動後 `/q/health` 回 200
- [ ] 至少 5 個 E2E 情境通過
- [ ] audit log 落地 (workflow_execution_log 有新 workflow_id 的 row)
- [ ] DB view 存在 (`vw_<workflow-name>_reconciliation`)
- [ ] 無 NEW critical build error(可有 Quarkus warning)

---

## 失敗模式速查

| 失敗訊息關鍵字 | 對應修正 |
|---|---|
| `KieMemoryCompilerException: ';' expected, <identifier> expected` | Kogito subflow hyphen bug → 改名 underscore |
| `Illegal character in path at index N: ...{xxx}` | path parameter 沒傳 → 6a |
| `expected <block end>, but found ','` | YAML trailing comma → 6a 注意 |
| `finalStatus: REJECTED_VALIDATION` 但 HTTP 200 | status-rewrite filter 沒認 finalStatus → 6c |
| `vw_xxx_reconciliation` 查詢回 0 筆 | view 的 WHERE 用舊 id → 6d |
| `result.status == 0` 永遠 false | actionDataFilter 結構錯誤 → 6b |
| `rowsUpdated=0` 在 markOriginalCancelled | transaction 隔離 / cancelled_by 已值 / 連線池問題,留 v1.1 排查 |
| `Expected status code <200> but was <400>` | 全域正則拒絕正常通路碼 (如 `2500P`) → 檢查 API 規格放寬正則 (如 `^[A-Za-z0-9]{1,10}$`) |
| `finalStatus: null` 在業務失敗分支 | jq condition `tonumber` 遇到非數字哨兵 (如 `FAIL_`) 拋錯 → 加上 startswith("FAIL_") 守衛 |
| `Expected: SUCCESS Actual: IDEMPOTENT_REPLAY` | 測試案例重複使用硬編碼 sequenceNumber 觸發冪等 → 測試改用 System.nanoTime() 動態序號 |
| `NullPointerException: ... getStart() is null` | `.sw.yaml` 根節點缺少 `start:` 宣告 → 於 workflow 頂層顯式定義 `start: <StateName>` |
| `ClassCastException: ... cannot be cast to JsonNode` | Java 重載方法參數綁定失配 → 於 functionRef arguments 明確傳遞 `workflowId` 與 `businessKey` |
| `API 呼叫錯誤: 無法確定 API Base URL` | OpenAPI Spec 缺少 `servers:` 宣告且無全域 host → 於 Spec 補上 `servers: - url: http://localhost:8080` |
| `sqlite3.OperationalError: no such column: updated_at` | 對帳 View 參照不存在欄位 → 修正 View 定義，移除 `updated_at`，僅保留 `created_at` |
| `maven.aliyun.com 503 Service Unavailable` | 重試 / 切換 mirror / 縮短單次 build |
| Java/Maven 突然 not found | sandbox 自動清掉,重裝 `apt-get install openjdk-17-jdk-headless maven` |

---

## 反模式 (不要這樣做)

- ❌ 不要把整個 draft 資料夾丟進 project,挑選對應的檔案落對應目錄
- ❌ 不要跳過 Kogito bug 修正,直接編譯會 fail
- ❌ 不要改既有 saga2-transfer-workflow 的 convention(向後相容用 fallback)
- ❌ 不要用 `mvn install:install-file` 手動裝 jar,會破壞 reactor 一致性
- ❌ 不要在 test 階段才建 workflow URL prefix(應該是 dev profile 啟動時 Kogito 自動註冊)
- ❌ 不要省略 `creditcardid` 補上動作(6a),否則 mock 收到 `IllegalArgumentException`
- ❌ 不要在沒有 dev profile 下做 E2E(mocks 是 dev-only 模組,prod 會被排除)
