# Draft Specification: Loan Instant Disbursement & Reversal

## §0 核心決策
- 採用 Mode B 階層式架構 (Parent + 2 Child Subflows)
- 雙軌制狀態碼: status (0/1) + finalStatus (STRING)

## §1 業務與架構說明
- Parent: `loan_instant_disbursement`
- Child WF-A: `loan_disburse_payout`
- Child WF-B: `loan_disburse_reversal`

## §2 平台預檢與自檢
- 6 項預檢全數通過
- 21 項自檢全數通過
