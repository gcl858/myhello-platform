package com.example.platform.distribution.transfer;

import io.quarkus.test.junit.QuarkusTest;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.*;

@QuarkusTest
public class LoanInstantDisbursementWorkflowTest {

    private static final String PARENT_URL = "/loan_instant_disbursement";

    @Test
    @DisplayName("[P1] 參數檢核失敗 (operationType=C) -> 400 REJECTED_VALIDATION")
    void testP1InvalidOpType() {
        String seq = "LN_P1_" + System.nanoTime();
        String payload = "{\n" +
                "  \"partyId\":\"A123456789\",\"contractNo\":\"LN20260830001\",\n" +
                "  \"loanProductCode\":\"PL001\",\"toAccountId\":\"00701234567890\",\n" +
                "  \"transactionDate\":\"20260830\",\"transactionDateTime\":\"11000000\",\n" +
                "  \"channelCode\":\"APP01\",\"operationType\":\"C\",\n" +
                "  \"amount\":\"0000500000\",\"sequenceNumber\":\"" + seq + "\"\n" +
                "}";

        given()
            .contentType("application/json")
            .body(payload)
        .when()
            .post(PARENT_URL)
        .then()
            .statusCode(400)
            .body("finalStatus", equalTo("REJECTED_VALIDATION"));
    }

    @Test
    @DisplayName("[A1] 正向信貸撥款正常成功 (WF-A) -> 200 SUCCESS")
    void testA1DisburseSuccess() {
        String seq = "LN_A1_" + System.nanoTime();
        String payload = "{\n" +
                "  \"partyId\":\"A123456789\",\"contractNo\":\"LN20260830001\",\n" +
                "  \"loanProductCode\":\"PL001\",\"toAccountId\":\"00701234567890\",\n" +
                "  \"transactionDate\":\"20260830\",\"transactionDateTime\":\"11000000\",\n" +
                "  \"channelCode\":\"APP01\",\"operationType\":\"A\",\n" +
                "  \"amount\":\"0000500000\",\"sequenceNumber\":\"" + seq + "\"\n" +
                "}";

        given()
            .contentType("application/json")
            .body(payload)
        .when()
            .post(PARENT_URL)
        .then()
            .statusCode(200)
            .body("finalStatus", equalTo("SUCCESS"))
            .body("loanHostResult.status", equalTo(0))
            .body("coreDepositResult.status", equalTo(0));
    }

    @Test
    @DisplayName("[P4] Parent 級冪等重送 -> 200 IDEMPOTENT_REPLAY")
    void testP4Idempotency() {
        String seq = "LN_P4_" + System.nanoTime();
        String payload = "{\n" +
                "  \"partyId\":\"A123456789\",\"contractNo\":\"LN20260830001\",\n" +
                "  \"loanProductCode\":\"PL001\",\"toAccountId\":\"00701234567890\",\n" +
                "  \"transactionDate\":\"20260830\",\"transactionDateTime\":\"11000000\",\n" +
                "  \"channelCode\":\"APP01\",\"operationType\":\"A\",\n" +
                "  \"amount\":\"0000500000\",\"sequenceNumber\":\"" + seq + "\"\n" +
                "}";

        given().contentType("application/json").body(payload).when().post(PARENT_URL).then().statusCode(200).body("finalStatus", equalTo("SUCCESS"));
        given().contentType("application/json").body(payload).when().post(PARENT_URL).then().statusCode(200).body("finalStatus", equalTo("IDEMPOTENT_REPLAY"));
    }

    @Test
    @DisplayName("[B1] 當日撥款沖正成功 -> 200 CANCELLED")
    void testB1ReversalSuccess() {
        String origSeq = "LN_ORIG_" + System.nanoTime();
        String setupPayload = "{\n" +
                "  \"partyId\":\"A123456789\",\"contractNo\":\"LN20260830001\",\n" +
                "  \"loanProductCode\":\"PL001\",\"toAccountId\":\"00701234567890\",\n" +
                "  \"transactionDate\":\"20260830\",\"transactionDateTime\":\"11000000\",\n" +
                "  \"channelCode\":\"APP01\",\"operationType\":\"A\",\n" +
                "  \"amount\":\"0000500000\",\"sequenceNumber\":\"" + origSeq + "\"\n" +
                "}";

        given().contentType("application/json").body(setupPayload).when().post(PARENT_URL).then().statusCode(200).body("finalStatus", equalTo("SUCCESS"));

        String revSeq = "LN_R_" + System.nanoTime();
        String revPayload = "{\n" +
                "  \"partyId\":\"A123456789\",\"contractNo\":\"LN20260830001\",\n" +
                "  \"loanProductCode\":\"PL001\",\"toAccountId\":\"00701234567890\",\n" +
                "  \"transactionDate\":\"20260830\",\"transactionDateTime\":\"11050000\",\n" +
                "  \"channelCode\":\"APP01\",\"operationType\":\"B\",\n" +
                "  \"amount\":\"0000500000\",\"sequenceNumber\":\"" + revSeq + "\",\n" +
                "  \"originalSequenceNumber\":\"" + origSeq + "\"\n" +
                "}";

        given()
            .contentType("application/json")
            .body(revPayload)
        .when()
            .post(PARENT_URL)
        .then()
            .statusCode(200)
            .body("finalStatus", equalTo("CANCELLED"));
    }

    @Test
    @DisplayName("[B2] 沖正查無原撥款紀錄 -> 500 LOOKUP_FAILED")
    void testB2LookupFailed() {
        String revSeq = "LN_R_" + System.nanoTime();
        String revPayload = "{\n" +
                "  \"partyId\":\"A123456789\",\"contractNo\":\"LN20260830001\",\n" +
                "  \"loanProductCode\":\"PL001\",\"toAccountId\":\"00701234567890\",\n" +
                "  \"transactionDate\":\"20260830\",\"transactionDateTime\":\"11050000\",\n" +
                "  \"channelCode\":\"APP01\",\"operationType\":\"B\",\n" +
                "  \"amount\":\"0000500000\",\"sequenceNumber\":\"" + revSeq + "\",\n" +
                "  \"originalSequenceNumber\":\"LN_NONEXIST_99999\"\n" +
                "}";

        given()
            .contentType("application/json")
            .body(revPayload)
        .when()
            .post(PARENT_URL)
        .then()
            .statusCode(500)
            .body("finalStatus", equalTo("LOOKUP_FAILED"));
    }
}
