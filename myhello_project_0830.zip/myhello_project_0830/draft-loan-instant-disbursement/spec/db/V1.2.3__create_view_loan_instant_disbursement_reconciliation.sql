CREATE VIEW IF NOT EXISTS vw_loan_instant_disbursement_reconciliation AS
SELECT
    id,
    created_at,
    workflow_id,
    business_key,
    process_instance_id,
    status,
    message,
    json_extract(input_data, '$.partyId') AS party_id,
    json_extract(input_data, '$.contractNo') AS contract_no,
    json_extract(input_data, '$.loanProductCode') AS loan_product_code,
    json_extract(input_data, '$.toAccountId') AS to_account_id,
    json_extract(input_data, '$.operationType') AS operation_type,
    json_extract(input_data, '$.amount') AS amount,
    cancelled_by,
    cancelled_at
FROM workflow_execution_log
WHERE workflow_id IN ('loan_instant_disbursement', 'loan_disburse_payout', 'loan_disburse_reversal');
