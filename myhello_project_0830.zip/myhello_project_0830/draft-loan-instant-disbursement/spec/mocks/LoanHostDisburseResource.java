package org.acme.transfer.api;

import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import org.acme.transfer.api.dto.LoanHostRequest;
import org.acme.transfer.api.dto.LoanHostResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.UUID;

@Path("/LoanHost/{partyId}/Disburse/Execute")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class LoanHostDisburseResource {
    private static final Logger LOG = LoggerFactory.getLogger(LoanHostDisburseResource.class);

    @POST
    public Response execute(@PathParam("partyId") String partyId, LoanHostRequest request) {
        LOG.info("[Mock LoanHost] partyId={}, contract={}, opType={}, amount={}", partyId, request != null ? request.contractNo : null, request != null ? request.operationType : null, request != null ? request.amount : null);
        if (request != null && request.amount != null && request.amount.startsWith("FAIL_LOAN")) {
            return Response.status(400).entity(new LoanHostResponse(1, "放款主機開戶建檔失敗", "loan-err-" + UUID.randomUUID().toString().substring(0, 8))).build();
        }
        return Response.ok(new LoanHostResponse(0, "放款主機處理成功", "loan-host-" + UUID.randomUUID().toString().substring(0, 8))).build();
    }
}
