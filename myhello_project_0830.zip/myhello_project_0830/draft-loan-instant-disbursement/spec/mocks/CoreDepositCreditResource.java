package org.acme.transfer.api;

import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import org.acme.transfer.api.dto.CoreDepositRequest;
import org.acme.transfer.api.dto.CoreDepositResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.UUID;

@Path("/CoreDeposit/{partyId}/Credit/Execute")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class CoreDepositCreditResource {
    private static final Logger LOG = LoggerFactory.getLogger(CoreDepositCreditResource.class);

    @POST
    public Response execute(@PathParam("partyId") String partyId, CoreDepositRequest request) {
        LOG.info("[Mock CoreDeposit] partyId={}, account={}, opType={}, amount={}", partyId, request != null ? request.toAccountId : null, request != null ? request.operationType : null, request != null ? request.amount : null);
        if (request != null && request.amount != null && request.amount.startsWith("FAIL_DEP")) {
            return Response.status(400).entity(new CoreDepositResponse(1, "活存帳戶狀態異常撥付失敗", "dep-err-" + UUID.randomUUID().toString().substring(0, 8))).build();
        }
        return Response.ok(new CoreDepositResponse(0, "活存撥款入帳成功", "core-dep-" + UUID.randomUUID().toString().substring(0, 8))).build();
    }
}
