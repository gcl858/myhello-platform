package org.acme.transfer.api.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class LoanHostRequest {
    @JsonProperty("partyId")
    public String partyId;
    @JsonProperty("contractNo")
    public String contractNo;
    @JsonProperty("loanProductCode")
    public String loanProductCode;
    @JsonProperty("operationType")
    public String operationType;
    @JsonProperty("amount")
    public String amount;
    @JsonProperty("sequenceNumber")
    public String sequenceNumber;

    public LoanHostRequest() {}
}
