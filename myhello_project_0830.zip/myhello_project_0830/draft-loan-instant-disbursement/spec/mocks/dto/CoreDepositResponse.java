package org.acme.transfer.api.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

public class CoreDepositResponse {
    @JsonProperty("status")
    public int status;
    @JsonProperty("message")
    public String message;
    @JsonProperty("track_id")
    public String trackId;

    public CoreDepositResponse() {}
    public CoreDepositResponse(int status, String message, String trackId) {
        this.status = status;
        this.message = message;
        this.trackId = trackId;
    }
}
