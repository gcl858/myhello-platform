package com.example.platform.common;

import java.io.File;
import java.nio.file.Path;
import java.nio.file.Paths;

/**
 * 平台無關 (Platform-agnostic) 的路徑工具。
 *
 * <p>提供整個 myhello-platform 共用的路徑解析邏輯,避免各模組各自處理
 * Windows / Linux 路徑分隔符差異、JVM 啟動目錄等隱性依賴。
 *
 * <h2>設計原則</h2>
 * <ul>
 *   <li><b>不寫死路徑分隔符</b>:永遠透過 {@link java.nio.file.Path} API;
 *       不使用 {@code "/"} 或 {@code "\\"} 拼接絕對路徑。
 *   <li><b>錨定 JVM 工作目錄</b>:預設以 {@code System.getProperty("user.dir")}
 *       為根,使用 {@link Paths#get(String, String...)} 拼接,
 *       Windows / Linux 都會自動使用對應平台的分隔符。
 *   <li><b>支援環境變數覆寫</b>:若環境變數 {@code MYHELLO_DATA_DIR}
 *       有設定,則使用該絕對路徑;方便容器化部署掛載外部 volume。
 *   <li><b>Classpath 路徑統一用 {@code /}</b>:這是 Java 規格要求,
 *       本工具對 {@link #normalizeClasspath(String)} 自動將 Windows 風格的
 *       {@code \\} 轉成 {@code /},並去除尾端分隔符。
 *   <li><b>無 framework 依賴</b>:屬於 platform-common 模組 (pure Java only)。
 * </ul>
 *
 * <h2>典型用法</h2>
 * <pre>{@code
 * // 取代原本 hardcoded "data" / "data/reconciliation.db"
 * Path dataDir  = PlatformPaths.dataDirectory();        // 解析 data/ 目錄的絕對路徑
 * Path csvFile  = PlatformPaths.dataFile("reconciliation-20260817.csv");
 * String jdbcUrl = PlatformPaths.sqliteUrl("reconciliation.db");
 *
 * // Classpath 規格檔路徑(內部統一用 /)
 * String specPath = PlatformPaths.normalizeClasspath("specs\\A16229-api.yaml");
 * // → "specs/A16229-api.yaml"
 * }</pre>
 *
 * @author myhello-platform
 * @since 1.0.0
 */
public final class PlatformPaths {

    /** 環境變數名:外部資料目錄覆寫 (絕對路徑)。 */
    public static final String DATA_DIR_ENV = "MYHELLO_DATA_DIR";

    /** 預設資料目錄名稱 (相對於專案根目錄)。 */
    public static final String DEFAULT_DATA_DIR_NAME = "data";

    /** 環境變數名:外部紀錄目錄覆寫 (絕對路徑)。 */
    public static final String LOGS_DIR_ENV = "MYHELLO_LOGS_DIR";

    /** 預設紀錄目錄名稱 (相對於專案根目錄)。 */
    public static final String DEFAULT_LOGS_DIR_NAME = "logs";

    static {
        // 若外部未顯式設定 MYHELLO_DATA_DIR，將其預設設為專案根目錄下的 data 資料夾
        if (System.getProperty(DATA_DIR_ENV) == null && System.getenv(DATA_DIR_ENV) == null) {
            try {
                Path defaultDir = findProjectRoot().resolve(DEFAULT_DATA_DIR_NAME).toAbsolutePath().normalize();
                System.setProperty(DATA_DIR_ENV, defaultDir.toString());
            } catch (Exception ignored) {
            }
        }
        // 若外部未顯式設定 MYHELLO_LOGS_DIR，將其預設設為專案根目錄下的 logs 資料夾
        if (System.getProperty(LOGS_DIR_ENV) == null && System.getenv(LOGS_DIR_ENV) == null) {
            try {
                Path defaultLogsDir = findProjectRoot().resolve(DEFAULT_LOGS_DIR_NAME).toAbsolutePath().normalize();
                System.setProperty(LOGS_DIR_ENV, defaultLogsDir.toString());
            } catch (Exception ignored) {
            }
        }
    }

    private PlatformPaths() {
        // utility class
    }

    /**
     * 尋找專案根目錄。
     *
     * <p>若在子模組目錄中執行 (例如 distribution/transfer-app)，會逐層往上尋找包含 .git 或 root pom.xml 的根目錄。
     *
     * @return 專案根目錄絕對路徑
     */
    public static Path findProjectRoot() {
        Path current = Paths.get(System.getProperty("user.dir")).toAbsolutePath().normalize();
        Path p = current;
        while (p != null) {
            if (java.nio.file.Files.exists(p.resolve(".git")) ||
                (java.nio.file.Files.exists(p.resolve("pom.xml")) && java.nio.file.Files.exists(p.resolve("distribution")))) {
                return p;
            }
            p = p.getParent();
        }
        return current;
    }

    /**
     * 回傳目前的 {@code data/} 目錄絕對路徑。
     *
     * <p>解析順序:
     * <ol>
     *   <li>環境變數 {@link #DATA_DIR_ENV} (若已設定且非空)</li>
     *   <li>System Property {@link #DATA_DIR_ENV} (若已設定且非空)</li>
     *   <li>專案根目錄 (透過 {@link #findProjectRoot()}) + {@link #DEFAULT_DATA_DIR_NAME}</li>
     * </ol>
     *
     * <p>此方法 <b>不會</b> 在磁碟上建立目錄 — 若需實體目錄請用
     * {@link #ensureDataDirectory()} 或 {@link java.nio.file.Files#createDirectories(Path, java.nio.file.attribute.FileAttribute[])}。
     *
     * @return 跨平台絕對路徑
     */
    public static Path dataDirectory() {
        String envOverride = System.getenv(DATA_DIR_ENV);
        if (envOverride != null && !envOverride.isBlank()) {
            return Paths.get(envOverride).toAbsolutePath().normalize();
        }
        String propOverride = System.getProperty(DATA_DIR_ENV);
        if (propOverride != null && !propOverride.isBlank()) {
            return Paths.get(propOverride).toAbsolutePath().normalize();
        }
        return findProjectRoot().resolve(DEFAULT_DATA_DIR_NAME)
                .toAbsolutePath()
                .normalize();
    }

    /**
     * 確保 {@code data/} 目錄存在於磁碟,並回傳絕對路徑。
     *
     * <p>若目錄不存在則遞迴建立 (等同 {@code mkdir -p} / {@code mkdir /p})。
     *
     * @return {@link #dataDirectory()} 對應的絕對路徑
     * @throws java.io.UncheckedIOException 若建立失敗
     */
    public static Path ensureDataDirectory() {
        Path dir = dataDirectory();
        File asFile = dir.toFile();
        if (!asFile.exists() && !asFile.mkdirs()) {
            // 第二次檢查 — 避免雙執行緒競爭下 mkdirs 與 exists 的併發誤判
            if (!asFile.exists()) {
                throw new java.io.UncheckedIOException(
                        "無法建立 data 目錄: " + dir,
                        new java.io.IOException("mkdirs() returned false"));
            }
        }
        return dir;
    }

    /**
     * 解析 {@code data/<fileName>} 的完整絕對路徑。
     *
     * <p>不會自動建立目錄 — 若呼叫端需要寫入磁碟,應先呼叫
     * {@link #ensureDataDirectory()}。
     *
     * @param fileName 檔名 (相對於 data 目錄)
     * @return 跨平台絕對路徑
     */
    public static Path dataFile(String fileName) {
        if (fileName == null || fileName.isBlank()) {
            throw new IllegalArgumentException("fileName 不可為空");
        }
        return dataDirectory().resolve(fileName).normalize();
    }

    /**
     * 回傳目前的 {@code logs/} 目錄絕對路徑。
     *
     * <p>解析順序:
     * <ol>
     *   <li>環境變數 {@link #LOGS_DIR_ENV} (若已設定且非空)</li>
     *   <li>System Property {@link #LOGS_DIR_ENV} (若已設定且非空)</li>
     *   <li>專案根目錄 (透過 {@link #findProjectRoot()}) + {@link #DEFAULT_LOGS_DIR_NAME}</li>
     * </ol>
     *
     * @return 跨平台絕對路徑
     */
    public static Path logsDirectory() {
        String envOverride = System.getenv(LOGS_DIR_ENV);
        if (envOverride != null && !envOverride.isBlank()) {
            return Paths.get(envOverride).toAbsolutePath().normalize();
        }
        String propOverride = System.getProperty(LOGS_DIR_ENV);
        if (propOverride != null && !propOverride.isBlank()) {
            return Paths.get(propOverride).toAbsolutePath().normalize();
        }
        return findProjectRoot().resolve(DEFAULT_LOGS_DIR_NAME)
                .toAbsolutePath()
                .normalize();
    }

    /**
     * 確保 {@code logs/} 目錄存在於磁碟,並回傳絕對路徑。
     *
     * <p>若目錄不存在則遞迴建立。
     *
     * @return {@link #logsDirectory()} 對應的絕對路徑
     * @throws java.io.UncheckedIOException 若建立失敗
     */
    public static Path ensureLogsDirectory() {
        Path dir = logsDirectory();
        File asFile = dir.toFile();
        if (!asFile.exists() && !asFile.mkdirs()) {
            if (!asFile.exists()) {
                throw new java.io.UncheckedIOException(
                        "無法建立 logs 目錄: " + dir,
                        new java.io.IOException("mkdirs() returned false"));
            }
        }
        return dir;
    }

    /**
     * 解析 {@code logs/<fileName>} 的完整絕對路徑。
     *
     * @param fileName 檔名 (相對於 logs 目錄)
     * @return 跨平台絕對路徑
     */
    public static Path logFile(String fileName) {
        if (fileName == null || fileName.isBlank()) {
            throw new IllegalArgumentException("fileName 不可為空");
        }
        return logsDirectory().resolve(fileName).normalize();
    }

    /**
     * 組合 SQLite JDBC 連線 URL。
     *
     * <p>SQLite JDBC driver 同時接受 forward slash {@code /} 與 OS 平台原生分隔符,
     * 但為了跨平台一致性,此方法統一使用 {@link java.io.File#separator}。
     *
     * <p>範例輸出:
     * <ul>
     *   <li>Linux: {@code jdbc:sqlite:/opt/app/data/reconciliation.db}</li>
     *   <li>Windows: {@code jdbc:sqlite:D:\app\data\reconciliation.db}</li>
     * </ul>
     *
     * @param fileName SQLite 資料庫檔名 (純檔名,不可含路徑)
     * @return JDBC URL 字串
     */
    public static String sqliteUrl(String fileName) {
        Path dbPath = dataFile(fileName);
        // SQLite JDBC URL 格式: jdbc:sqlite:<絕對路徑>
        // 用 File.separator 保證 Windows 路徑使用 \\,Linux 使用 /
        String absolute = dbPath.toFile().getAbsolutePath();
        return "jdbc:sqlite:" + absolute;
    }

    /**
     * 正規化 Classpath 路徑字串,統一使用 forward slash {@code /}。
     *
     * <p>Java ClassLoader (例如 {@link ClassLoader#getResourceAsStream(String)})
     * 規格要求路徑內部以 {@code /} 分隔,與平台無關。
     * 但若上游傳入 Windows 風格 {@code specs\\A16229-api.yaml},此方法會自動
     * 正規化為 {@code specs/A16229-api.yaml}。
     *
     * <p>同時去除重複的 {@code /}、結尾的 {@code /} 與 {@code \\}。
     *
     * @param input 可能含有 Windows 分隔符或不一致分隔符的路徑
     * @return 正規化後的 Classpath 路徑
     */
    public static String normalizeClasspath(String input) {
        if (input == null || input.isBlank()) {
            return "";
        }
        String s = input.replace('\\', '/');
        // 去除多餘斜線
        while (s.contains("//")) {
            s = s.replace("//", "/");
        }
        // 去除開頭的 "/" (classpath 資源不應以 / 開頭)
        while (s.startsWith("/")) {
            s = s.substring(1);
        }
        // 去除結尾的 "/"
        while (s.endsWith("/")) {
            s = s.substring(0, s.length() - 1);
        }
        return s;
    }

    /**
     * 將檔案路徑字串中的 Windows 分隔符 {@code \\} 與多餘的 {@code /}
     * 統一轉成 OS 原生分隔符,並回傳 {@link Path}。
     *
     * <p>適用於處理來自外部設定的 path 字串;若已是 Linux 風格也不會破壞。
     *
     * @param first 第一段路徑
     * @param more  其餘段
     * @return 跨平台 {@link Path}
     */
    public static Path resolveOsNative(String first, String... more) {
        // Paths.get 本身就處理跨平台,這裡只是顯式說明意圖
        return Paths.get(first, more).toAbsolutePath().normalize();
    }
}
