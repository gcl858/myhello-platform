-- =====================================================================
-- Migration V1.1.0: 建立 Saga2 轉帳流程專屬對帳視圖
-- 模組: domain-transfer / transfer-workflow
-- =====================================================================

CREATE VIEW IF NOT EXISTS vw_saga_reconciliation AS 
SELECT 
  id, 
  created_at, 
  workflow_id, 
  business_key, 
  process_instance_id, 
  status, 
  message, 
  json_extract(input_data, '$.Account_A') AS account_a, 
  json_extract(input_data, '$.Account_B') AS account_b, 
  json_extract(input_data, '$.AMT')       AS amt, 
  json_extract(output_data, '$.a16229Result.code')    AS a16229_code, 
  json_extract(output_data, '$.a16229Result.message') AS a16229_msg, 
  json_extract(output_data, '$.a16220Result.code')    AS a16220_code, 
  json_extract(output_data, '$.a16220Result.message') AS a16220_msg, 
  json_extract(output_data, '$.a16220Rollback.code') AS a16220_rollback_code, 
  json_extract(output_data, '$.a16229Rollback.code') AS a16229_rollback_code 
FROM workflow_execution_log 
WHERE workflow_id = 'saga2-transfer-workflow';

