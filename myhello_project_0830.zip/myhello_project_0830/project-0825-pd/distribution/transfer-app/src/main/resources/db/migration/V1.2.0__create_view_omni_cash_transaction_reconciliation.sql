-- =====================================================================
-- Migration V1.2.0: 建立 Omni Cash Transaction 對帳視圖
-- 模組: domain-transfer / transfer-workflow
-- 涵蓋 workflow: omni-cash-transaction + repayment-cash-deposit + repayment-cash-cancellation
-- 來源: draft-omni-counter-repayment/spec/spec.md §4.5
-- =====================================================================

CREATE VIEW IF NOT EXISTS vw_omni_cash_transaction_reconciliation AS
SELECT
  id,
  created_at,
  workflow_id,
  business_key,
  process_instance_id,
  status,
  message,
  -- 入口 11 欄 (Parent 層)
  json_extract(input_data, '$.partyId') AS party_id,
  json_extract(input_data, '$.branchCode') AS branch_code,
  json_extract(input_data, '$.operationType') AS operation_type,
  json_extract(input_data, '$.amount') AS amount,
  json_extract(input_data, '$.sequenceNumber') AS sequence_number,
  json_extract(input_data, '$.originalSequenceNumber') AS original_sequence_number,
  -- 各階段 API 結果
  json_extract(output_data, '$.coreResult.status') AS core_status,
  json_extract(output_data, '$.coreResult.message') AS core_message,
  json_extract(output_data, '$.coreResult.track_id') AS core_track_id,
  json_extract(output_data, '$.ccResult.status') AS cc_status,
  json_extract(output_data, '$.ccResult.message') AS cc_message,
  json_extract(output_data, '$.ccResult.track_id') AS cc_track_id,
  json_extract(output_data, '$.coreRollbackResult.status') AS core_rollback_status,
  json_extract(output_data, '$.coreRollbackResult.message') AS core_rollback_message,
  json_extract(output_data, '$.coreRollbackResult.track_id') AS core_rollback_track_id,
  -- WF-B 專屬
  json_extract(output_data, '$.lookupResult.found') AS lookup_found,
  json_extract(output_data, '$.lookupResult.originalFinalStatus') AS lookup_original_status,
  json_extract(output_data, '$.markResult.marked') AS mark_original_cancelled,
  -- 對帳與告警
  json_extract(output_data, '$.auditSaved') AS audit_saved,
  json_extract(output_data, '$.opsAlertRaised') AS ops_alert_raised
FROM workflow_execution_log
WHERE workflow_id IN (
  'omni_cash_transaction',
  'repayment_cash_deposit',
  'repayment_cash_cancellation'
);
