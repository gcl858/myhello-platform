package com.example.platform.distribution.transfer;

import io.quarkus.test.junit.QuarkusTest;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.*;

@QuarkusTest
@DisplayName("Data Index GraphQL API 測試")
class DataIndexGraphQLTest {

    @Test
    @DisplayName("驗證 ProcessDefinitions 查詢成功")
    void testProcessDefinitionsQuery() {
        String query = "{\"query\":\"{ ProcessDefinitions { id name version } }\"}";

        given()
            .contentType("application/json")
            .body(query)
        .when()
            .post("/graphql")
        .then()
            .statusCode(200)
            .body("errors", nullValue())
            .body("data.ProcessDefinitions", notNullValue());
    }

    @Test
    @DisplayName("驗證 ProcessInstances 查詢成功（無 Error parsing time stamp 錯誤）")
    void testProcessInstancesQuery() {
        // 先觸發一次 workflow 確保資料庫中有 process instance
        given()
            .contentType("application/json")
            .body("{\"Account_A\":\"A123\",\"Account_B\":\"B123\",\"AMT\":100}")
        .when()
            .post("/saga2-transfer-workflow")
        .then()
            .statusCode(200);

        String query = "{\"query\":\"{ ProcessInstances { id processId state start end } }\"}";

        given()
            .contentType("application/json")
            .body(query)
        .when()
            .post("/graphql")
        .then()
            .statusCode(200)
            .body("errors", nullValue())
            .body("data.ProcessInstances", notNullValue());
    }

    @Test
    @DisplayName("驗證所有節點均有記錄 input_args 與 output_args 至 SQLite nodes 資料表")
    void testNodeInstancesRecordedInDatabase() throws Exception {
        // 觸發一次 workflow 產生完整節點鏈
        given()
            .contentType("application/json")
            .body("{\"Account_A\":\"AccNodeTestA\",\"Account_B\":\"AccNodeTestB\",\"AMT\":100}")
        .when()
            .post("/saga2-transfer-workflow")
        .then()
            .statusCode(200);

        Class.forName("org.sqlite.JDBC");
        try (java.sql.Connection conn = java.sql.DriverManager.getConnection("jdbc:sqlite:target/test-reconciliation.db");
             java.sql.Statement stmt = conn.createStatement();
             java.sql.ResultSet rs = stmt.executeQuery(
                     "SELECT n.id, n.name, n.type, n.input_args, n.output_args, n.error_message " +
                     "FROM nodes n JOIN processes p ON n.process_instance_id = p.id " +
                     "WHERE p.variables LIKE '%AccNodeTestA%'")) {

            int totalNodes = 0;
            int nodesWithInputArgs = 0;
            int nodesWithOutputArgs = 0;

            while (rs.next()) {
                totalNodes++;
                String inputArgs = rs.getString("input_args");
                String outputArgs = rs.getString("output_args");
                if (inputArgs != null && !inputArgs.isBlank()) {
                    nodesWithInputArgs++;
                }
                if (outputArgs != null && !outputArgs.isBlank()) {
                    nodesWithOutputArgs++;
                }
            }

            org.junit.jupiter.api.Assertions.assertTrue(totalNodes > 0, "應記錄至少一個節點");
            org.junit.jupiter.api.Assertions.assertEquals(totalNodes, nodesWithInputArgs,
                    "所有執行的節點都應有 input_args");
            org.junit.jupiter.api.Assertions.assertEquals(totalNodes, nodesWithOutputArgs,
                    "所有執行的節點都應有 output_args");
        }
    }
}
