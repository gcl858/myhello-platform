package com.example.platform.distribution.transfer;

import com.example.transfer.workflow.MyOpenApiService;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.io.File;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * MyOpenApiService 傳輸層指數退避重試單元測試 (v2.2 / P2-2)
 *
 * <p>策略:動態寫入一支探測用 OpenAPI spec 至 test classpath
 * ({@code target/test-classes/specs/}),其 servers[0].url 指向保留埠
 * {@code http://127.0.0.1:9/}(discard,連線必遭拒絕),並使用未註冊於
 * application.properties 的 functionName,確保 Base URL 走 spec 內宣告值,
 * 從而<b>確定性地</b>製造 TRANSPORT 類失敗。
 *
 * <p>驗證:
 * <ul>
 *   <li>retryMaxAttempts=3 → 共嘗試 3 次、退避 sleep 2 次(80ms + 160ms),耗時 ≥ 180ms</li>
 *   <li>最終結果仍為標準化錯誤:code=999、errorType=TRANSPORT、_httpStatus=0(契約不變)</li>
 *   <li>maxAttempts=1(預設)→ 不重試,快速返回</li>
 * </ul>
 */
class MyOpenApiServiceRetryTest {

    private static final String PROBE_SPEC = "specs/__retry_probe__.yaml";
    private static final ObjectMapper JSON = new ObjectMapper();

    @TempDir
    static Path tempDir;

    @BeforeAll
    static void writeProbeSpec() throws Exception {
        // 找出 target/test-classes 目錄 (surefire 執行時位於 classpath 最前段)
        Path classes = Paths.get(MyOpenApiServiceRetryTest.class.getResource("/").toURI());
        Path specsDir = classes.resolve("specs");
        Files.createDirectories(specsDir);
        File probe = specsDir.resolve("__retry_probe__.yaml").toFile();
        try (PrintWriter w = new PrintWriter(probe, "UTF-8")) {
            w.println("openapi: 3.0.0");
            w.println("info:");
            w.println("  title: Retry Probe API");
            w.println("  version: 1.0.0");
            w.println("servers:");
            w.println("  - url: http://127.0.0.1:9/");
            w.println("paths:");
            w.println("  /probe:");
            w.println("    post:");
            w.println("      operationId: probeCall");
            w.println("      requestBody:");
            w.println("        content:");
            w.println("          application/json:");
            w.println("            schema:");
            w.println("              type: object");
            w.println("      responses:");
            w.println("        '200':");
            w.println("          description: ok");
        }
        probe.deleteOnExit();
    }

    private JsonNode call(int maxAttempts, long delayMs) {
        MyOpenApiService service = new MyOpenApiService();
        ObjectNode args = JSON.createObjectNode();
        args.put("schemaRef", PROBE_SPEC + "#probeCall");
        args.put("functionName", "retryProbeFn");
        args.set("payload", JSON.createObjectNode());
        args.put("timeoutSeconds", 2);
        args.put("retryMaxAttempts", maxAttempts);
        args.put("retryDelayMs", delayMs);
        return service.callOpenApi(args);
    }

    @Test
    @DisplayName("[retry-1] maxAttempts=3 → 退避重試 2 次,結果仍為標準化 TRANSPORT 錯誤")
    void transportFailureRetriesWithBackoff() {
        long start = System.nanoTime();
        JsonNode result = call(3, 80L);
        long elapsedMs = (System.nanoTime() - start) / 1_000_000;

        assertEquals("999", result.path("code").asText(), "契約不變:code=999");
        assertEquals("TRANSPORT", result.path("errorType").asText());
        assertEquals(0, result.path("_httpStatus").asInt());

        // 退避 sleep:80 + 160 = 240ms;留 60ms 容忍計時誤差
        assertTrue(elapsedMs >= 180,
                "應至少經歷 2 次指數退避 (≥180ms),實際 " + elapsedMs + "ms");

        System.out.printf("[RetryTest] attempts=3 elapsed=%dms result=%s%n",
                elapsedMs, result.toString().replaceAll("\\s+", " "));
    }

    @Test
    @DisplayName("[retry-2] maxAttempts=1 (預設語意) → 不重試,快速返回")
    void noRetryWhenMaxAttemptsIsOne() {
        long start = System.nanoTime();
        JsonNode result = call(1, 500L);
        long elapsedMs = (System.nanoTime() - start) / 1_000_000;

        assertEquals("999", result.path("code").asText());
        assertEquals("TRANSPORT", result.path("errorType").asText());
        assertEquals(0, result.path("_httpStatus").asInt());

        // 無重試:連線拒絕應在 timeout(2s)內快速失敗,不經任何退避 sleep
        assertTrue(elapsedMs < 2000,
                "不重試時應遠低於 timeout 上限,實際 " + elapsedMs + "ms");

        System.out.printf("[RetryTest] attempts=1 elapsed=%dms%n", elapsedMs);
    }
}
