package com.example.platform.distribution.transfer;

import io.quarkus.test.junit.QuarkusTest;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.greaterThan;
import static org.hamcrest.Matchers.matchesPattern;
import static org.hamcrest.Matchers.notNullValue;
import static org.hamcrest.Matchers.nullValue;

/**
 * saga2-transfer-workflow 完整測試
 * 對應 saga-transfer-workflow v14 測試集,驗證 4 種情境:
 *   - AMT=100 → SUCCESS
 *   - AMT=600 → ROLLED_BACK (LIFO 完整回沖)
 *   - AMT=30 → FAILED (A16229 業務失敗短路)
 *   - AMT=2000 → ROLLED_BACK (A16220 失敗僅回沖 A16229)
 *
 * 本測試透過 SonataFlow HTTP 端點 ({@code POST /saga2-transfer-workflow})
 * 啟動 workflow,並用 rest-assured 驗證輸出 JSON。
 */
@QuarkusTest
@DisplayName("saga2-transfer-workflow saga 測試")
class Saga2TransferWorkflowTest {

    private static final String WORKFLOW_URL = "/saga2-transfer-workflow";

    private static final String PAYLOAD_TEMPLATE =
            "{\"Account_A\":\"A123\",\"Account_B\":\"B123\",\"AMT\":%d}";

    @Test
    @DisplayName("[1] AMT=100 → SUCCESS (兩 API 都成功)")
    void testAmt100Success() {
        given()
            .contentType("application/json")
            .body(String.format(PAYLOAD_TEMPLATE, 100))
        .when()
            .post(WORKFLOW_URL)
        .then()
            .statusCode(200)
            .body("status", equalTo("SUCCESS"))
            .body("message", equalTo("交易成功"))
            .body("AMT", equalTo(100))
            .body("a16229Result.code", equalTo("100"))
            .body("a16229Result._httpStatus", equalTo(200))
            .body("a16220Result.code", equalTo("100"))
            .body("a16220Result._httpStatus", equalTo(200))
            .body("opsAlertRaised", equalTo(false));
    }

    @Test
    @DisplayName("[2] AMT=600 → ROLLED_BACK LIFO (兩 API + 兩 rollback)")
    void testAmt600RolledBackLifo() {
        given()
            .contentType("application/json")
            .body(String.format(PAYLOAD_TEMPLATE, 600))
        .when()
            .post(WORKFLOW_URL)
        .then()
            .statusCode(200)
            .body("status", equalTo("ROLLED_BACK"))
            .body("message", equalTo("AMT > 500 觸發 saga 回沖 (LIFO)"))
            .body("AMT", equalTo(600))
            .body("a16229Result.code", equalTo("100"))
            .body("a16220Result.code", equalTo("100"))
            // LIFO: 兩個 rollback 都用 EC=true
            .body("a16229Rollback.code", equalTo("100"))
            .body("a16229Rollback.message", equalTo("成功(EC)"))
            .body("a16220Rollback.code", equalTo("100"))
            .body("a16220Rollback.message", equalTo("成功(EC)"));
    }

    @Test
    @DisplayName("[3] AMT=30 → FAILED (A16229 業務失敗短路,不呼叫 A16220)")
    void testAmt30Failed() {
        given()
            .contentType("application/json")
            .body(String.format(PAYLOAD_TEMPLATE, 30))
        .when()
            .post(WORKFLOW_URL)
        .then()
            .statusCode(200)
            .body("status", equalTo("FAILED"))
            .body("AMT", equalTo(30))
            .body("a16229Result.code", equalTo("999"))
            .body("a16229Result._httpStatus", equalTo(403))
            // 短路:A16220 與 rollback 都不該被呼叫
            .body("a16220Result", nullValue())
            .body("a16229Rollback", nullValue())
            .body("a16220Rollback", nullValue());
    }

    @Test
    @DisplayName("[4] AMT=2000 → ROLLED_BACK (A16220 失敗,僅回沖 A16229)")
    void testAmt2000RolledBackA16229Only() {
        given()
            .contentType("application/json")
            .body(String.format(PAYLOAD_TEMPLATE, 2000))
        .when()
            .post(WORKFLOW_URL)
        .then()
            .statusCode(200)
            .body("status", equalTo("ROLLED_BACK"))
            .body("message", equalTo("A16220 業務失敗,僅回沖 A16229"))
            .body("AMT", equalTo(2000))
            .body("a16229Result.code", equalTo("100"))
            .body("a16220Result.code", equalTo("999"))
            .body("a16220Result._httpStatus", equalTo(403))
            // 只回沖 A16229 (A16220 本來就沒扣款)
            .body("a16229Rollback.code", equalTo("100"))
            .body("a16229Rollback.message", equalTo("成功(EC)"))
            .body("a16220Rollback", nullValue());
    }

    @Test
    @DisplayName("[5] AMT=500 邊界值 → SUCCESS (AMT <= 500 才算成功)")
    void testAmt500BoundarySuccess() {
        given()
            .contentType("application/json")
            .body(String.format(PAYLOAD_TEMPLATE, 500))
        .when()
            .post(WORKFLOW_URL)
        .then()
            .statusCode(200)
            .body("status", equalTo("SUCCESS"))
            .body("AMT", equalTo(500));
    }

    @Test
    @DisplayName("[6] AMT=501 邊界值 → ROLLED_BACK (AMT > 500 觸發 LIFO)")
    void testAmt501BoundaryRolledBack() {
        given()
            .contentType("application/json")
            .body(String.format(PAYLOAD_TEMPLATE, 501))
        .when()
            .post(WORKFLOW_URL)
        .then()
            .statusCode(200)
            .body("status", equalTo("ROLLED_BACK"))
            .body("AMT", equalTo(501));
    }

    @Test
    @DisplayName("[7] 驗證 SQLite 通用資料表與對帳 View (vw_saga_reconciliation) 紀錄內容")
    void testSqliteDatabaseRecords() throws Exception {
        Class.forName("org.sqlite.JDBC");
        // 跨平台 (Linux/Windows) 都使用相對路徑,SQLite JDBC 兩種分隔符皆接受
        try (java.sql.Connection conn = java.sql.DriverManager.getConnection("jdbc:sqlite:target/test-reconciliation.db");
             java.sql.Statement stmt = conn.createStatement();
             java.sql.ResultSet rs = stmt.executeQuery("SELECT id, workflow_id, business_key, status, account_a, account_b, amt, a16229_code, a16220_code FROM vw_saga_reconciliation")) {
            int count = 0;
            while (rs.next()) {
                count++;
                System.out.printf("[Reconciliation Test] Row %d -> ID: %d, WF: %s, BKey: %s, Status: %s, AccountA: %s, AccountB: %s, AMT: %d, A16229Code: %s, A16220Code: %s%n",
                        count, rs.getInt("id"), rs.getString("workflow_id"), rs.getString("business_key"),
                        rs.getString("status"), rs.getString("account_a"), rs.getString("account_b"),
                        rs.getInt("amt"), rs.getString("a16229_code"), rs.getString("a16220_code"));
            }
            org.junit.jupiter.api.Assertions.assertTrue(count > 0, "SQLite View 應包含寫入的對帳紀錄");
        }
    }

    @Test
    @DisplayName("[8] POST /reconciliation/export-csv (無過濾) — 匯出全部對帳紀錄到 data/ 目錄")
    void testExportCsvAllRecords() {
        // 跨平台相容的 regex:路徑分隔符可能是 / (Linux) 或 \\ (Windows)。
        // 使用 File.separator 配合 matchesPattern 動態構造,確保 Linux/Windows 都通過。
        // File.separator 在 Linux = "/",在 Windows = "\"
        // regex 內 \\ 為跳脫,需寫成 "\\" 才會被 regex 視為反斜線字面值。
        String sep = File.separator;
        String escapedSep = sep.equals("\\") ? "\\\\" : "/";
        // 比對 "<任意字元><sep>data<sep>reconciliation-<8碼日期>-<6碼時間>.csv"
        String pathRegex = ".*" + escapedSep + "data" + escapedSep
                + "reconciliation-\\d{8}-\\d{6}\\.csv$";

        String csvFilePath = given()
                .contentType("application/json")
                .body("{}")
            .when()
                .post("/reconciliation/export-csv")
            .then()
                .statusCode(200)
                .body("ok", equalTo(true))
                .body("fileName", notNullValue())
                .body("fileName", matchesPattern("^reconciliation-\\d{8}-\\d{6}\\.csv$"))
                .body("rowCount", greaterThan(0))
                .body("byteSize", greaterThan(0))
                .body("filePath", matchesPattern(pathRegex))
                .extract().path("filePath");

        // 驗證檔案實際存在於磁碟
        Path path = Paths.get(csvFilePath);
        org.junit.jupiter.api.Assertions.assertTrue(Files.exists(path),
                "CSV 檔案應實際寫入磁碟: " + csvFilePath);

        // 驗證內容:含 UTF-8 BOM + 表頭 + 至少 1 行資料
        try {
            String content = Files.readString(path, java.nio.charset.StandardCharsets.UTF_8);
            org.junit.jupiter.api.Assertions.assertTrue(content.startsWith("\uFEFF"),
                    "CSV 開頭應為 UTF-8 BOM (避免 Excel 中文亂碼)");
            org.junit.jupiter.api.Assertions.assertTrue(content.contains("id,created_at,workflow_id,business_key,process_instance_id,status"),
                    "CSV 應含標準表頭");
            org.junit.jupiter.api.Assertions.assertTrue(content.contains("saga2-transfer-workflow"),
                    "CSV 應含 workflow_id 欄位內容");
            org.junit.jupiter.api.Assertions.assertTrue(content.contains("SUCCESS"),
                    "CSV 應含至少一筆 SUCCESS 紀錄");
            System.out.printf("[CSV Export Test] File: %s, Lines: %d%n",
                    path.getFileName(), content.lines().count());
        } catch (Exception e) {
            org.junit.jupiter.api.Assertions.fail("讀取 CSV 失敗: " + e.getMessage());
        }
    }

    @Test
    @DisplayName("[9] POST /reconciliation/export-csv (status=ROLLED_BACK) — 過濾匯出")
    void testExportCsvFilteredByStatus() {
        given()
            .contentType("application/json")
            .body("{\"status\":\"ROLLED_BACK\"}")
        .when()
            .post("/reconciliation/export-csv")
        .then()
            .statusCode(200)
            .body("ok", equalTo(true))
            .body("rowCount", greaterThan(0))
            .body("filters.status", equalTo("ROLLED_BACK"));
    }

    @Test
    @DisplayName("[10] POST /reconciliation/export-csv (workflowId=non-existent) — 過濾無資料")
    void testExportCsvNoMatchingRecords() {
        given()
            .contentType("application/json")
            .body("{\"workflowId\":\"non-existent-workflow-xyz\"}")
        .when()
            .post("/reconciliation/export-csv")
        .then()
            .statusCode(200)
            .body("ok", equalTo(true))
            .body("rowCount", equalTo(0));
    }

    // ═══════════════════════════════════════════════
    // v2.1.0 驗證路徑 (VALIDATION_FAILED → HTTP 400,由 WorkflowStatusFilter 改寫)
    // ═══════════════════════════════════════════════

    private static final String INVALID_PAYLOAD_TEMPLATE =
            "{\"Account_A\":\"%s\",\"Account_B\":\"%s\",\"AMT\":%s}";

    @Test
    @DisplayName("[11] 缺失欄位 (null-safe) → 400 VALIDATION_FAILED,不拋 jq 例外")
    void testValidationFailedMissingField() {
        given()
            .contentType("application/json")
            .body("{\"Account_A\":\"123456\"}")
        .when()
            .post(WORKFLOW_URL)
        .then()
            .statusCode(400)
            .body("status", equalTo("VALIDATION_FAILED"))
            .body("message", equalTo("輸入欄位格式錯誤 (帳號僅限英數字與底線且兩者不得相同;AMT 須為大於 0 的數字)"))
            .body("a16229Result", nullValue())
            .body("a16220Result", nullValue())
            .body("auditSaved", equalTo(true))
            .body("opsAlertRaised", equalTo(false));
    }

    @Test
    @DisplayName("[12] Account_B 含非法字元 → 400 VALIDATION_FAILED")
    void testValidationFailedBadChars() {
        given()
            .contentType("application/json")
            .body(String.format(INVALID_PAYLOAD_TEMPLATE, "123456", "A@0001", "100"))
        .when()
            .post(WORKFLOW_URL)
        .then()
            .statusCode(400)
            .body("status", equalTo("VALIDATION_FAILED"));
    }

    @Test
    @DisplayName("[13] AMT=0 (非正數) → 400 VALIDATION_FAILED")
    void testValidationFailedAmtZero() {
        given()
            .contentType("application/json")
            .body(String.format(INVALID_PAYLOAD_TEMPLATE, "123456", "A00001", "0"))
        .when()
            .post(WORKFLOW_URL)
        .then()
            .statusCode(400)
            .body("status", equalTo("VALIDATION_FAILED"))
            .body("AMT", equalTo(0));
    }

    @Test
    @DisplayName("[14] 同帳號 → 400 VALIDATION_FAILED")
    void testValidationFailedSameAccount() {
        given()
            .contentType("application/json")
            .body(String.format(INVALID_PAYLOAD_TEMPLATE, "123456", "123456", "100"))
        .when()
            .post(WORKFLOW_URL)
        .then()
            .statusCode(400)
            .body("status", equalTo("VALIDATION_FAILED"));
    }

    // ═══════════════════════════════════════════════
    // errorType 契約 (成功不含欄位;業務失敗標記 BUSINESS)
    // ═══════════════════════════════════════════════

    @Test
    @DisplayName("[15] SUCCESS 時 errorType 不存在 (向後相容)")
    void testSuccessHasNoErrorType() {
        given()
            .contentType("application/json")
            .body(String.format(PAYLOAD_TEMPLATE, 100))
        .when()
            .post(WORKFLOW_URL)
        .then()
            .statusCode(200)
            .body("status", equalTo("SUCCESS"))
            .body("a16229Result.errorType", nullValue())
            .body("a16220Result.errorType", nullValue());
    }

    @Test
    @DisplayName("[16] A16229 業務失敗時 errorType=BUSINESS (HTTP 403 + body 自帶 code 999)")
    void testFailedPathErrorTypeBusiness() {
        given()
            .contentType("application/json")
            .body(String.format(PAYLOAD_TEMPLATE, 30))
        .when()
            .post(WORKFLOW_URL)
        .then()
            .statusCode(200)
            .body("status", equalTo("FAILED"))
            .body("a16229Result.code", equalTo("999"))
            .body("a16229Result._httpStatus", equalTo(403))
            .body("a16229Result.errorType", equalTo("BUSINESS"));
    }

    // ═══════════════════════════════════════════════
    // ROLLBACK_FAILED 路徑 (RBFAIL 測試哨兵 → HTTP 409,由 WorkflowStatusFilter 改寫)
    // ═══════════════════════════════════════════════

    @Test
    @DisplayName("[17] LIFO 全回沖但 A16220 回沖失敗 (Account_B=RBFAIL) → 409 ROLLBACK_FAILED,LIFO 不中斷")
    void testRollbackFailedLifo() {
        given()
            .contentType("application/json")
            .body("{\"Account_A\":\"123456\",\"Account_B\":\"RBFAIL\",\"AMT\":600}")
        .when()
            .post(WORKFLOW_URL)
        .then()
            .statusCode(409)
            .body("status", equalTo("ROLLBACK_FAILED"))
            .body("message", equalTo("⚠️ 回沖失敗,需人工介入處理"))
            // 兩階段原本皆業務成功
            .body("a16229Result.code", equalTo("100"))
            .body("a16220Result.code", equalTo("100"))
            // LIFO 不中斷:A16220 回沖失敗,A16229 仍繼續回沖並成功
            .body("a16220Rollback.code", equalTo("401"))
            .body("a16220Rollback.message", equalTo("回沖失敗(測試哨兵)"))
            .body("a16229Rollback.code", equalTo("100"))
            .body("auditSaved", equalTo(true))
            .body("opsAlertRaised", equalTo(true));
    }

    @Test
    @DisplayName("[18] A16220 業務失敗 + 僅回沖 A16229 也失敗 (Account_A=RBFAIL) → 409 ROLLBACK_FAILED")
    void testRollbackFailedA16229Only() {
        given()
            .contentType("application/json")
            .body("{\"Account_A\":\"RBFAIL\",\"Account_B\":\"A00001\",\"AMT\":2000}")
        .when()
            .post(WORKFLOW_URL)
        .then()
            .statusCode(409)
            .body("status", equalTo("ROLLBACK_FAILED"))
            // EC=false 正常交易不受 RBFAIL 影響,階段 1 成功、階段 2 因 AMT>=1000 失敗
            .body("a16229Result.code", equalTo("100"))
            .body("a16220Result.code", equalTo("999"))
            .body("a16220Rollback", nullValue())
            .body("a16229Rollback.code", equalTo("401"))
            .body("opsAlertRaised", equalTo(true));
    }
}