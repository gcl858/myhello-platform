package org.acme.transfer.api.dto;

import java.util.List;

/**
 * Core 主機回應 (對應 notebooks/core-account-cash-deposit-api.yaml)
 * 結構: { track_id, status, errors, result }
 * 極簡風格。
 */
public class CoreCashDepositResponse {
    public String track_id;
    public Integer status;            // 0=成功, 1=失敗
    public List<ErrorDetail> errors;  // status=1 時通常有值
    public CoreCashDepositResult result;
}
