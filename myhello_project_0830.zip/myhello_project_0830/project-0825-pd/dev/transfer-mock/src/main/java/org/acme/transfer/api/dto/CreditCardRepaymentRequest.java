package org.acme.transfer.api.dto;

/**
 * CC 主機還款請求 (對應 notebooks/credit-card-repayment-api.yaml)
 * 極簡風格:純 public field。
 */
public class CreditCardRepaymentRequest {
    public String partyId;
    public String branchCode;
    public String transactionDate;
    public String transactionDateTime;
    public String postingDayType;
    public String postingDate;
    public String paymentSourceCode;
    public String operationType;  // A=正向還款 / B=反向沖銷
    public String amount;
    public String sequenceNumber;  // CC_ 正向 / CC_R_ 反向
}
