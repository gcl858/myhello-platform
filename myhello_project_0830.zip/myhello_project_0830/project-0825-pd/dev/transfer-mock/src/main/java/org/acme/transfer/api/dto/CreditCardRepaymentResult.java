package org.acme.transfer.api.dto;

/**
 * CC 主機業務結果
 * 極簡風格。
 */
public class CreditCardRepaymentResult {
    public String partyId;
    public String branchCode;
    public String operationType;
    public String amount;
    public String sequenceNumber;
}
