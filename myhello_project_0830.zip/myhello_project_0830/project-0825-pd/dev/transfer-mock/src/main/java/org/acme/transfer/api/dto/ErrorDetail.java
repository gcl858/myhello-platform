package org.acme.transfer.api.dto;

/**
 * 共用錯誤細節 (Core 與 CC Response 共用)
 * 極簡風格。
 */
public class ErrorDetail {
    public String error_code;
    public String message;

    public ErrorDetail() {}

    public ErrorDetail(String error_code, String message) {
        this.error_code = error_code;
        this.message = message;
    }
}
