package org.acme.transfer.api.dto;

import java.util.List;

/**
 * CC 主機回應 (對應 notebooks/credit-card-repayment-api.yaml)
 * 結構: { track_id, status, errors, result }
 * 極簡風格。
 */
public class CreditCardRepaymentResponse {
    public String track_id;
    public Integer status;
    public List<ErrorDetail> errors;
    public CreditCardRepaymentResult result;
}
