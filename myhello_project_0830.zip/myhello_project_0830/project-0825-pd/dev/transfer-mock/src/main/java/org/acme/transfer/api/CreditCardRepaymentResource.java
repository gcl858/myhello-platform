package org.acme.transfer.api;

import org.acme.transfer.api.dto.CreditCardRepaymentRequest;
import org.acme.transfer.api.dto.CreditCardRepaymentResponse;
import org.acme.transfer.api.dto.CreditCardRepaymentResult;
import org.acme.transfer.api.dto.ErrorDetail;

import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

import java.util.Collections;
import java.util.UUID;

/**
 * CC 主機即時還款 Mock 端點 (對應 notebooks/credit-card-repayment-api.yaml)。
 * 完整獨立 @Path,絕不與其他 Resource 共享。
 *
 * 測試哨兵 (H10):
 *   - request null → 403 status=1
 *   - amount = "0" / "0000000000" / 以 "FAIL" 開頭 → 403 status=1 (業務拒絕)
 *   - operationType=B 且 sequenceNumber 以 "RBFAIL" 開頭 → 403 status=1 (回沖失敗)
 */
@Path("/CreditCard/{creditcardid}/Repayment/Execute")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public class CreditCardRepaymentResource {

    @POST
    public Response execute(@PathParam("creditcardid") String creditcardid,
                            CreditCardRepaymentRequest request) {

        // 哨兵 1: request 為空
        if (request == null) {
            return Response.status(Response.Status.FORBIDDEN)
                    .entity(buildErrorResponse("E0001", "Request不可為空", null))
                    .build();
        }

        // 哨兵 2: 業務拒絕
        if (isBusinessRejectAmount(request.amount)) {
            return Response.status(Response.Status.FORBIDDEN)
                    .entity(buildErrorResponse("E0024",
                            "金額必須大於 0 (received: " + request.amount + ")",
                            null))
                    .build();
        }

        // 哨兵 3: 回沖失敗
        if ("B".equals(request.operationType)
                && request.sequenceNumber != null
                && request.sequenceNumber.startsWith("RBFAIL")) {
            return Response.status(Response.Status.FORBIDDEN)
                    .entity(buildErrorResponse("E0050", "回沖失敗(測試哨兵)", null))
                    .build();
        }

        // 正常成功
        CreditCardRepaymentResult result = new CreditCardRepaymentResult();
        result.partyId = request.partyId;
        result.branchCode = request.branchCode;
        result.operationType = request.operationType;
        result.amount = request.amount;
        result.sequenceNumber = request.sequenceNumber;

        CreditCardRepaymentResponse resp = new CreditCardRepaymentResponse();
        resp.track_id = "cc-track-" + UUID.randomUUID().toString().replace("-", "").substring(0, 12);
        resp.status = 0;
        resp.errors = null;
        resp.result = result;

        return Response.ok(resp).build();
    }

    private boolean isBusinessRejectAmount(String amount) {
        if (amount == null) return true;
        if ("0".equals(amount) || "0000000000".equals(amount)) return true;
        return amount.startsWith("FAIL");
    }

    private CreditCardRepaymentResponse buildErrorResponse(String code, String message, CreditCardRepaymentResult result) {
        CreditCardRepaymentResponse resp = new CreditCardRepaymentResponse();
        resp.track_id = "cc-track-err-" + UUID.randomUUID().toString().replace("-", "").substring(0, 8);
        resp.status = 1;
        resp.errors = Collections.singletonList(new ErrorDetail(code, message));
        resp.result = result;
        return resp;
    }
}
