package org.acme.transfer.api.dto;

/**
 * Core 主機業務結果 (response.result 內的 sub-object)
 * 極簡風格。
 */
public class CoreCashDepositResult {
    public String partyId;
    public String branchCode;
    public String operationType;
    public String amount;
    public String sequenceNumber;
}
