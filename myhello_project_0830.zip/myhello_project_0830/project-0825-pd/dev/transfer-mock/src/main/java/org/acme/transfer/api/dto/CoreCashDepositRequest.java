package org.acme.transfer.api.dto;

/**
 * Core 主機現金入帳請求 (對應 notebooks/core-account-cash-deposit-api.yaml)
 * 極簡風格:純 public field,無 getter/setter,無 builder,無 Lombok。
 */
public class CoreCashDepositRequest {
    public String partyId;
    public String branchCode;
    public String transactionDate;
    public String transactionDateTime;
    public String postingDayType;
    public String postingDate;
    public String paymentSourceCode;
    public String operationType;  // A=正向入帳 / B=反向沖正
    public String amount;          // 單位:分,左補零字串
    public String sequenceNumber;  // CA_ 正向 / CA_R_ 反向
}
