package com.example.transfer.workflow;

import com.example.platform.common.PlatformPaths;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.fasterxml.jackson.dataformat.yaml.YAMLFactory;
import jakarta.enterprise.context.ApplicationScoped;
import org.eclipse.microprofile.config.Config;
import org.eclipse.microprofile.config.ConfigProvider;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.FileNotFoundException;
import java.io.InputStream;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * ===================================================================
 * MyOpenApiService - 通用 OpenAPI Workflow 執行服務 (增強版)
 * ===================================================================
 * 
 * 功能與優化特點:
 *  1. 完整 HTTP 方法支援: GET, POST, PUT, DELETE, PATCH, HEAD, OPTIONS。
 *  2. 動態路徑與查詢參數解析:
 *     - 自動將 URL 路徑模板中的 {param} 以 payload / arguments 欄位替換。
 *     - GET/DELETE 等無 body 請求或額外參數自動轉為 Query String (?key=value)。
 *  3. 自訂 Headers 與 Tracing 支援:
 *     - 支援從 arguments.headers 傳入自訂標頭。
 *     - 預設附帶 Content-Type 與關聯追蹤標頭支援。
 *  4. 彈性逾時配置 (Configurable Timeout):
 *     - 支援 application.properties 全域設定 (kogito.sw.openapi.timeout-seconds)。
 *     - 支援 arguments.timeoutSeconds 單次請求覆寫。
 *  4.1 傳輸層指數退避重試 (Transport Retry, v2.2):
 *     - 僅對未取得 HTTP 回應的傳輸失敗重試 (連線拒絕/逾時);已收到回應者不重試。
 *     - 全域:kogito.sw.openapi.transport-retry.max-attempts / .delay-ms
 *       (預設 1 次=不重試 / 500ms;上限 5 次,退避因子 2.0)。
 *     - 單次覆寫:arguments.retryMaxAttempts / arguments.retryDelayMs。
 *  5. 健壯的響應資料標準化 (Response Normalization):
 *     - 支援 JSON Object、JSON Array (包裝為 data)、204 No Content 與非 JSON 文字處理。
 *     - 確保非 2xx 或異常情況下必有 code 與 _httpStatus 欄位，方便 Workflow 判斷。
 *     - 失敗回應額外附帶 errorType 分類 (TRANSPORT / BUSINESS / HTTP_4XX / HTTP_5XX)，
 *       供 Workflow 區分「結果未知」與「業務確定失敗」(成功回應不含 errorType，向後相容)。
 *  6. 多層 ConcurrentHashMap 快取:
 *     - operationCache: specPath#operationId 端點對照快取。
 *     - baseUrlCache: Base URL 解析結果快取。
 *     - specAstCache: OpenAPI YAML 根 AST 快取。
 *     - requestFieldsCache: OpenAPI requestBody 欄位名稱快取 (可用於 Payload 過濾)。
 */
@ApplicationScoped
public class MyOpenApiService {

    private static final Logger LOG = LoggerFactory.getLogger(MyOpenApiService.class);
    private static final Duration DEFAULT_HTTP_TIMEOUT = Duration.ofSeconds(10);
    private static final Pattern PATH_PARAM_PATTERN = Pattern.compile("\\{([^}]+)\\}");

    // ── 傳輸層指數退避重試 (P2-2) ──────────────────────────────────────────
    // 僅對「呼叫未抵達目標系統」的傳輸失敗 (連線拒絕/逾時等 IOException) 重試;
    // HTTP 已收到回應者 (含 4xx/5xx) 屬確定結果,一律不重試。
    private static final String CFG_RETRY_MAX_ATTEMPTS = "kogito.sw.openapi.transport-retry.max-attempts";
    private static final String CFG_RETRY_DELAY_MS = "kogito.sw.openapi.transport-retry.delay-ms";
    /** 重試總次數上限 (含首次),防呆上限 */
    private static final int MAX_ATTEMPTS_CAP = 5;
    private static final long DEFAULT_RETRY_DELAY_MS = 500L;
    private static final double RETRY_BACKOFF_FACTOR = 2.0;

    /**
     * errorType 錯誤分類契約 (向後相容:成功回應不含此欄位)
     *
     * - TRANSPORT : 呼叫未抵達或未完成目標系統 (_httpStatus=0),含連線失敗、逾時、
     *               規格解析/組態錯誤。結果「未知」,補償判斷前應視為不確定狀態。
     * - BUSINESS  : 目標系統明確回覆的業務碼失敗 (回應 body 自帶 code != "100",
     *               如 HTTP 403 + {code:"999"})。結果「確定」。
     * - HTTP_4XX  : HTTP 層客戶端錯誤且 body 無業務碼 (如 404/405)。
     *               請求語法或路由問題,重試無效。
     * - HTTP_5XX  : HTTP 層伺服端錯誤且 body 無業務碼 (如 500/503)。
     *               結果「未知」,與 TRANSPORT 同屬需保守處理的分類。
     */
    public static final String ERROR_TYPE_TRANSPORT = "TRANSPORT";
    public static final String ERROR_TYPE_BUSINESS = "BUSINESS";
    public static final String ERROR_TYPE_HTTP_4XX = "HTTP_4XX";
    public static final String ERROR_TYPE_HTTP_5XX = "HTTP_5XX";

    private final HttpClient httpClient = HttpClient.newBuilder()
            .connectTimeout(DEFAULT_HTTP_TIMEOUT)
            .build();

    private final ObjectMapper jsonMapper = new ObjectMapper();
    private final ObjectMapper yamlMapper = new ObjectMapper(new YAMLFactory());

    // 1. 端點定位快取: key 為 "specPath#operationId"
    private final Map<String, ApiEndpoint> operationCache = new ConcurrentHashMap<>();

    // 2. Base URL 解析快取: key 為 "functionName#specPath"
    private final Map<String, String> baseUrlCache = new ConcurrentHashMap<>();

    // 3. YAML 根 AST 結構快取: key 為 "specPath"
    private final Map<String, JsonNode> specAstCache = new ConcurrentHashMap<>();

    // 4. Request Schema 欄位順序快取: key 為 "schemaRef"
    private final Map<String, List<String>> requestFieldsCache = new ConcurrentHashMap<>();

    /**
     * 通用 OpenAPI 呼叫進入點 (由 SonataFlow type: custom 呼叫)
     *
     * @param arguments Workflow functionRef.arguments 所有參數，必須包含 schemaRef
     * @return JsonNode 響應 (標準化 JSON 格式)
     */
    public JsonNode callOpenApi(JsonNode arguments) {
        String schemaRef = null;
        try {
            if (arguments == null || !arguments.has("schemaRef") || arguments.path("schemaRef").asText().isBlank()) {
                throw new IllegalArgumentException(
                    "未指定 OpenAPI 規格定位點 (schemaRef)！" +
                    "請於 Workflow functionRef.arguments 中提供 schemaRef" +
                    "(例如: 'specs/A16229-api.yaml#executeA16229')。");
            }

            schemaRef = arguments.path("schemaRef").asText().trim();

            if (!schemaRef.contains("#")) {
                throw new IllegalArgumentException(
                    "schemaRef 格式錯誤: [" + schemaRef + "]。" +
                    "正確格式應包含 '#' 符號，例如: 'specs/openapi.yaml#operationId'。");
            }

            String[] parts = schemaRef.split("#", 2);
            // 跨平台相容: 即使上游傳入 Windows 風格的 "\\", 自動正規化為 Classpath 標準 "/"
            String specPath = PlatformPaths.normalizeClasspath(
                    parts[0].replace("classpath:", "").trim());
            String operationId = parts[1].trim();

            if (specPath.isBlank() || operationId.isBlank()) {
                throw new IllegalArgumentException("schemaRef 無法解析規格路徑或 operationId: [" + schemaRef + "]。");
            }

            // 取得 Operation 定位資訊 (O(1) 查找)
            String cacheKey = specPath + "#" + operationId;
            ApiEndpoint endpoint = operationCache.computeIfAbsent(cacheKey, k -> resolveEndpoint(specPath, operationId));

            if (endpoint == null) {
                throw new IllegalArgumentException("在 OpenAPI 規格檔 [" + specPath + "] 中找不到 operationId = '" + operationId + "' 的定義。");
            }

            String functionName = arguments.has("functionName")
                    ? arguments.path("functionName").asText(operationId)
                    : operationId;

            // 快取解析 Base URL (O(1) 查找)
            String baseUrl = resolveBaseUrl(specPath, functionName, endpoint.specDeclaredBaseUrl);

            // 提取 Payload
            JsonNode payload = extractPayload(arguments);

            // 提取自訂 Headers
            JsonNode headersNode = arguments.has("headers") ? arguments.get("headers") : null;

            // 解析逾時時間
            Duration timeout = resolveTimeout(arguments);

            // 發送非同步 HTTP 請求並取得 JsonNode 結果 (傳輸失敗時依配置指數退避重試)
            int maxAttempts = resolveRetryMaxAttempts(arguments);
            long retryDelayMs = resolveRetryDelayMs(arguments);
            return executeHttpRequestAsync(baseUrl, endpoint.path, endpoint.method, payload, headersNode, timeout,
                    maxAttempts, retryDelayMs).join();

        } catch (Exception e) {
            LOG.error("MyOpenApiService 執行失敗: schemaRef={}, error={}", schemaRef, e.getMessage(), e);
            // 呼叫未抵達目標系統 (含規格解析/組態問題) → 分類為 TRANSPORT
            return transportError("API 呼叫錯誤: " + e.getMessage());
        }
    }

    /**
     * Kogito codegen 反射呼叫入口 — 巢狀 Map 參數版
     */
    public JsonNode callOpenApi(String schemaRef, Map<String, Object> payload) {
        ObjectNode args = jsonMapper.createObjectNode();
        args.put("schemaRef", schemaRef);
        if (payload != null) {
            payload.forEach((key, value) -> {
                if (!"schemaRef".equals(key) && !"functionName".equals(key)) {
                    args.set(key, jsonMapper.valueToTree(value));
                }
            });
        }
        return callOpenApi((JsonNode) args);
    }

    /**
     * Kogito codegen 反射呼叫入口 — 巢狀 JsonNode 參數版
     */
    public JsonNode callOpenApi(String schemaRef, JsonNode payload) {
        ObjectNode args = jsonMapper.createObjectNode();
        args.put("schemaRef", schemaRef);
        if (payload != null && payload.isObject()) {
            payload.fields().forEachRemaining(entry -> {
                String key = entry.getKey();
                if (!"schemaRef".equals(key) && !"functionName".equals(key)) {
                    args.set(key, entry.getValue());
                }
            });
        }
        return callOpenApi((JsonNode) args);
    }

    /**
     * Kogito codegen 反射呼叫入口 — 含 functionName, schemaRef, payload Map 參數版
     */
    public JsonNode callOpenApi(String functionName, String schemaRef, Map<String, Object> payload) {
        ObjectNode args = jsonMapper.createObjectNode();
        if (functionName != null) {
            args.put("functionName", functionName);
        }
        args.put("schemaRef", schemaRef);
        if (payload != null) {
            args.set("payload", jsonMapper.valueToTree(payload));
        }
        return callOpenApi((JsonNode) args);
    }

    /**
     * Kogito codegen 反射呼叫入口 — 含 functionName, schemaRef, payload JsonNode 參數版
     */
    public JsonNode callOpenApi(String functionName, String schemaRef, JsonNode payload) {
        ObjectNode args = jsonMapper.createObjectNode();
        if (functionName != null) {
            args.put("functionName", functionName);
        }
        args.put("schemaRef", schemaRef);
        if (payload != null) {
            args.set("payload", payload);
        }
        return callOpenApi((JsonNode) args);
    }

    /**
     * 從 Classpath 快取載入 OpenAPI YAML AST 結構
     */
    private JsonNode getSpecAst(String specPath) {
        return specAstCache.computeIfAbsent(specPath, path -> {
            try (InputStream is = Thread.currentThread().getContextClassLoader().getResourceAsStream(path)) {
                if (is == null) {
                    throw new FileNotFoundException("找不到指定的 OpenAPI 規格檔案: [classpath:" + path + "]，請確認檔案是否存在於 src/main/resources。");
                }
                return yamlMapper.readTree(is);
            } catch (Exception e) {
                throw new RuntimeException("解析 OpenAPI 規格檔 [" + path + "] 失敗: " + e.getMessage(), e);
            }
        });
    }

    /**
     * 從 OpenAPI spec 解析指定 operation 的 requestBody schema 欄位名稱 (帶 O(1) 快取)
     */
    public List<String> resolveRequestFieldNames(String schemaRef) {
        if (schemaRef == null || !schemaRef.contains("#")) {
            return Collections.emptyList();
        }
        return requestFieldsCache.computeIfAbsent(schemaRef, ref -> {
            String[] parts = ref.split("#", 2);
            String specPath = PlatformPaths.normalizeClasspath(
                    parts[0].replace("classpath:", "").trim());
            String operationId = parts[1].trim();

            try {
                JsonNode root = getSpecAst(specPath);
                JsonNode operationNode = findOperationNode(root, operationId);
                if (operationNode == null) {
                    return Collections.emptyList();
                }

                JsonNode schemaNode = operationNode
                        .path("requestBody")
                        .path("content")
                        .path("application/json")
                        .path("schema");

                JsonNode schema = resolveSchemaRef(root, schemaNode);
                JsonNode properties = schema.path("properties");
                if (properties.isObject()) {
                    List<String> names = new ArrayList<>();
                    properties.fieldNames().forEachRemaining(names::add);
                    return names;
                }
            } catch (Exception e) {
                LOG.warn("解析 spec requestBody 失敗: schemaRef={}, error={}", ref, e.getMessage());
            }
            return Collections.emptyList();
        });
    }

    /**
     * 在 spec 的 paths 內尋找指定 operationId 的 operation node
     */
    private JsonNode findOperationNode(JsonNode root, String operationId) {
        JsonNode paths = root.path("paths");
        if (!paths.isObject()) return null;
        Iterator<Map.Entry<String, JsonNode>> pathFields = paths.fields();
        while (pathFields.hasNext()) {
            Map.Entry<String, JsonNode> pathEntry = pathFields.next();
            Iterator<Map.Entry<String, JsonNode>> methodFields = pathEntry.getValue().fields();
            while (methodFields.hasNext()) {
                Map.Entry<String, JsonNode> methodEntry = methodFields.next();
                JsonNode opNode = methodEntry.getValue();
                if (opNode.has("operationId") && operationId.equals(opNode.get("operationId").asText())) {
                    return opNode;
                }
            }
        }
        return null;
    }

    /**
     * 解析 spec 內 {@code $ref: '#/components/schemas/<name>'} 指向的 schema node
     */
    private JsonNode resolveSchemaRef(JsonNode root, JsonNode schemaNode) {
        if (schemaNode == null || !schemaNode.isObject() || !schemaNode.has("$ref")) {
            return schemaNode;
        }
        String ref = schemaNode.get("$ref").asText();
        if (ref.startsWith("#/components/schemas/")) {
            String schemaName = ref.substring("#/components/schemas/".length());
            return root.path("components").path("schemas").path(schemaName);
        }
        return schemaNode;
    }

    /**
     * 從快取的 OpenAPI AST 解析指定 operationId
     */
    private ApiEndpoint resolveEndpoint(String specPath, String operationId) {
        JsonNode root = getSpecAst(specPath);

        String specDeclaredBaseUrl = null;
        if (root.has("servers") && root.get("servers").isArray() && !root.get("servers").isEmpty()) {
            specDeclaredBaseUrl = root.get("servers").get(0).path("url").asText(null);
        }

        JsonNode paths = root.path("paths");
        if (paths.isMissingNode() || !paths.isObject()) {
            throw new IllegalArgumentException("OpenAPI 規格檔 [" + specPath + "] 缺少有效的 'paths' 區塊。");
        }

        Iterator<Map.Entry<String, JsonNode>> pathFields = paths.fields();
        while (pathFields.hasNext()) {
            var pathEntry = pathFields.next();
            String path = pathEntry.getKey();
            Iterator<Map.Entry<String, JsonNode>> methodFields = pathEntry.getValue().fields();

            while (methodFields.hasNext()) {
                var methodEntry = methodFields.next();
                String httpMethod = methodEntry.getKey().toUpperCase();
                JsonNode opNode = methodEntry.getValue();

                if (opNode.has("operationId") && operationId.equals(opNode.get("operationId").asText())) {
                    return new ApiEndpoint(path, httpMethod, specDeclaredBaseUrl);
                }
            }
        }

        throw new IllegalArgumentException("OpenAPI 規格檔 [" + specPath + "] 內未找到 operationId 為 '" + operationId + "' 的 API 端點。");
    }

    /**
     * 依照 SonataFlow 慣例規則動態解析 Base URL (帶快取的被動檢索)
     */
    private String resolveBaseUrl(String specPath, String functionName, String specDeclaredBaseUrl) {
        String cacheKey = functionName + "#" + specPath;
        return baseUrlCache.computeIfAbsent(cacheKey, k -> doResolveBaseUrl(specPath, functionName, specDeclaredBaseUrl));
    }

    private String doResolveBaseUrl(String specPath, String functionName, String specDeclaredBaseUrl) {
        Config config = ConfigProvider.getConfig();

        // 規則 1: kogito.sw.functions.<functionName>.base_url / url
        Optional<String> fnBaseUrl = config.getOptionalValue("kogito.sw.functions." + functionName + ".base_url", String.class)
                .or(() -> config.getOptionalValue("kogito.sw.functions." + functionName + ".url", String.class));
        if (fnBaseUrl.isPresent() && !fnBaseUrl.get().isBlank()) {
            return fnBaseUrl.get();
        }

        // 規則 2: kogito.sw.functions.<functionName>.protocol + host + port
        Optional<String> protocol = config.getOptionalValue("kogito.sw.functions." + functionName + ".protocol", String.class)
                .or(() -> config.getOptionalValue("kogito.sw.functions." + functionName + ".scheme", String.class));
        Optional<String> host = config.getOptionalValue("kogito.sw.functions." + functionName + ".host", String.class);
        Optional<String> port = config.getOptionalValue("kogito.sw.functions." + functionName + ".port", String.class);

        if (host.isPresent() && !host.get().isBlank()) {
            String protoStr = protocol.orElse("http");
            String portStr = port.map(p -> ":" + p).orElse("");
            return protoStr + "://" + host.get() + portStr;
        }

        // 規則 3: kogito.sw.openapi.<specKey>.base_url
        String specKey = specPath.replace("/", "_").replace(".", "_");
        Optional<String> specBaseUrl = config.getOptionalValue("kogito.sw.openapi." + specKey + ".base_url", String.class)
                .or(() -> config.getOptionalValue("quarkus.rest-client." + specKey + ".url", String.class));
        if (specBaseUrl.isPresent() && !specBaseUrl.get().isBlank()) {
            return specBaseUrl.get();
        }

        // 規則 4: openapi.yaml 內定義的 servers[0].url
        if (specDeclaredBaseUrl != null && !specDeclaredBaseUrl.isBlank()) {
            return specDeclaredBaseUrl;
        }

        throw new IllegalStateException("無法確定 API Base URL！未在 application.properties 中設定 SonataFlow 慣例屬性："
                + "\n  - 函式屬性: kogito.sw.functions." + functionName + ".host (或 .protocol / .port)"
                + "\n  - 規格屬性: kogito.sw.openapi." + specKey + ".base_url"
                + "\n且 [" + specPath + "] 內亦未宣告 servers[0].url。請於設定檔補齊 Base URL。");
    }

    /**
     * 提取 Payload
     */
    private JsonNode extractPayload(JsonNode arguments) {
        if (arguments == null) {
            return jsonMapper.createObjectNode();
        }
        if (arguments.has("payload")) {
            return arguments.get("payload");
        }
        ObjectNode payload = jsonMapper.createObjectNode();
        if (arguments.isObject()) {
            arguments.fields().forEachRemaining(entry -> {
                String key = entry.getKey();
                if (!"schemaRef".equals(key) && !"functionName".equals(key) && !"headers".equals(key) && !"timeoutSeconds".equals(key)) {
                    payload.set(key, entry.getValue());
                }
            });
        }
        return payload;
    }

    /**
     * 動態解析請求逾時
     */
    private Duration resolveTimeout(JsonNode arguments) {
        if (arguments != null && arguments.has("timeoutSeconds")) {
            long seconds = arguments.path("timeoutSeconds").asLong(0);
            if (seconds > 0) {
                return Duration.ofSeconds(seconds);
            }
        }
        try {
            Optional<Long> configuredTimeout = ConfigProvider.getConfig()
                    .getOptionalValue("kogito.sw.openapi.timeout-seconds", Long.class);
            if (configuredTimeout.isPresent() && configuredTimeout.get() > 0) {
                return Duration.ofSeconds(configuredTimeout.get());
            }
        } catch (Exception ignored) {
        }
        return DEFAULT_HTTP_TIMEOUT;
    }

    /**
     * 構建完整請求 URL（包含路徑參數替換與 GET/DELETE 查詢參數組裝）
     */
    private String buildTargetUrl(String baseUrl, String pathTemplate, String httpMethod, JsonNode payload) {
        String cleanBase = baseUrl.endsWith("/") ? baseUrl.substring(0, baseUrl.length() - 1) : baseUrl;
        String resolvedPath = pathTemplate.startsWith("/") ? pathTemplate : "/" + pathTemplate;

        // 1. 替換 Path Parameters (例如 /accounts/{accountId})
        Matcher matcher = PATH_PARAM_PATTERN.matcher(resolvedPath);
        StringBuffer sb = new StringBuffer();
        List<String> usedAsPathParam = new ArrayList<>();

        while (matcher.find()) {
            String paramName = matcher.group(1);
            if (payload != null && payload.has(paramName)) {
                String value = payload.get(paramName).asText();
                matcher.appendReplacement(sb, URLEncoder.encode(value, StandardCharsets.UTF_8));
                usedAsPathParam.add(paramName);
            } else {
                LOG.warn("路徑參數 {{{}}} 未在 payload 中找到對應值", paramName);
                matcher.appendReplacement(sb, matcher.group(0));
            }
        }
        matcher.appendTail(sb);
        resolvedPath = sb.toString();

        // 2. 針對 GET, DELETE, HEAD, OPTIONS 等無 body 請求，將其餘 payload 轉為 Query String
        Set<String> noBodyMethods = Set.of("GET", "DELETE", "HEAD", "OPTIONS");
        if (noBodyMethods.contains(httpMethod.toUpperCase()) && payload != null && payload.isObject()) {
            StringBuilder queryBuilder = new StringBuilder();
            Iterator<Map.Entry<String, JsonNode>> fields = payload.fields();
            while (fields.hasNext()) {
                Map.Entry<String, JsonNode> field = fields.next();
                if (!usedAsPathParam.contains(field.getKey()) && !field.getValue().isNull()) {
                    if (queryBuilder.length() > 0) {
                        queryBuilder.append("&");
                    }
                    queryBuilder.append(URLEncoder.encode(field.getKey(), StandardCharsets.UTF_8))
                            .append("=")
                            .append(URLEncoder.encode(field.getValue().asText(), StandardCharsets.UTF_8));
                }
            }
            if (queryBuilder.length() > 0) {
                resolvedPath += (resolvedPath.contains("?") ? "&" : "?") + queryBuilder;
            }
        }

        return cleanBase + resolvedPath;
    }

    /**
     * 執行非同步 HTTP 請求;傳輸層失敗 (未收到 HTTP 回應) 時以指數退避重試
     *
     * @param maxAttempts 總嘗試次數 (含首次;1 = 不重試)
     * @param retryDelayMs 首次重試延遲,之後按 {@link #RETRY_BACKOFF_FACTOR} 指數成長
     */
    private CompletableFuture<JsonNode> executeHttpRequestAsync(
            String baseUrl,
            String pathTemplate,
            String httpMethod,
            JsonNode payload,
            JsonNode headersNode,
            Duration timeout,
            int maxAttempts,
            long retryDelayMs) {
        try {
            String fullUrl = buildTargetUrl(baseUrl, pathTemplate, httpMethod, payload);
            String methodUpper = httpMethod.toUpperCase();

            HttpRequest.Builder requestBuilder = HttpRequest.newBuilder()
                    .uri(URI.create(fullUrl))
                    .timeout(timeout)
                    .header("Content-Type", "application/json");

            // 套用自訂 Headers
            if (headersNode != null && headersNode.isObject()) {
                headersNode.fields().forEachRemaining(entry -> {
                    if (!entry.getValue().isNull()) {
                        requestBuilder.header(entry.getKey(), entry.getValue().asText());
                    }
                });
            }

            // 決定 Body Publisher
            String bodyJson = (payload != null && !payload.isNull() && !payload.isEmpty())
                    ? jsonMapper.writeValueAsString(payload)
                    : "";

            switch (methodUpper) {
                case "POST":
                    requestBuilder.POST(HttpRequest.BodyPublishers.ofString(bodyJson));
                    break;
                case "PUT":
                    requestBuilder.PUT(HttpRequest.BodyPublishers.ofString(bodyJson));
                    break;
                case "PATCH":
                    requestBuilder.method("PATCH", HttpRequest.BodyPublishers.ofString(bodyJson));
                    break;
                case "DELETE":
                    if (!bodyJson.isBlank()) {
                        requestBuilder.method("DELETE", HttpRequest.BodyPublishers.ofString(bodyJson));
                    } else {
                        requestBuilder.DELETE();
                    }
                    break;
                case "GET":
                    requestBuilder.GET();
                    break;
                case "HEAD":
                    requestBuilder.method("HEAD", HttpRequest.BodyPublishers.noBody());
                    break;
                default:
                    if (!bodyJson.isBlank()) {
                        requestBuilder.method(methodUpper, HttpRequest.BodyPublishers.ofString(bodyJson));
                    } else {
                        requestBuilder.method(methodUpper, HttpRequest.BodyPublishers.noBody());
                    }
                    break;
            }

            HttpRequest request = requestBuilder.build();
            return sendWithRetry(request, fullUrl, methodUpper, 1, maxAttempts, retryDelayMs);
        } catch (Exception e) {
            LOG.error("建立非同步 HTTP 請求失敗: error={}", e.getMessage(), e);
            return CompletableFuture.completedFuture(transportError("API 呼叫錯誤: " + e.getMessage()));
        }
    }

    /**
     * 單次發送 + 傳輸層指數退避重試。
     * 僅 exceptionally (未取得 HTTP 回應:連線拒絕/逾時/IO 錯誤) 才重試;
     * 已收到 HTTP 回應者交由 normalizeResponse 標準化,不重試。
     */
    private CompletableFuture<JsonNode> sendWithRetry(
            HttpRequest request, String url, String method,
            int attempt, int maxAttempts, long delayMs) {
        return httpClient.sendAsync(request, HttpResponse.BodyHandlers.ofString())
                .thenApply(this::normalizeResponse)
                .exceptionally(ex -> {
                    if (attempt < maxAttempts) {
                        long backoffMs = (long) (delayMs * Math.pow(RETRY_BACKOFF_FACTOR, attempt - 1));
                        LOG.warn("[MyOpenApiService] 傳輸失敗 ({}/{}),{} ms 後重試: {} | url={} method={}",
                                attempt, maxAttempts, backoffMs, ex.getMessage(), url, method);
                        try {
                            Thread.sleep(backoffMs);
                        } catch (InterruptedException ie) {
                            Thread.currentThread().interrupt();
                            return transportError("API 呼叫錯誤 (中斷): " + ie.getMessage());
                        }
                        return sendWithRetry(request, url, method, attempt + 1, maxAttempts, delayMs).join();
                    }
                    LOG.error("[MyOpenApiService] 傳輸失敗,已達重試上限 ({}/{}): url={} method={}",
                            attempt, maxAttempts, url, method, ex);
                    return transportError("API 呼叫錯誤: " + ex.getMessage());
                });
    }

    /** 建構標準化傳輸錯誤節點 (code=999, errorType=TRANSPORT, _httpStatus=0) */
    private ObjectNode transportError(String message) {
        ObjectNode error = jsonMapper.createObjectNode();
        error.put("code", "999");
        error.put("message", message);
        error.put("errorType", ERROR_TYPE_TRANSPORT);
        error.put("_httpStatus", 0);
        return error;
    }

    /**
     * 解析重試總次數 (含首次):arguments.retryMaxAttempts → 全域配置 → 預設 1 (不重試)
     */
    private int resolveRetryMaxAttempts(JsonNode arguments) {
        int attempts = readIntArgument(arguments, "retryMaxAttempts");
        if (attempts <= 0) {
            attempts = ConfigProvider.getConfig()
                    .getOptionalValue(CFG_RETRY_MAX_ATTEMPTS, Integer.class)
                    .orElse(1);
        }
        return Math.max(1, Math.min(attempts, MAX_ATTEMPTS_CAP));
    }

    /**
     * 解析首次重試延遲 (ms):arguments.retryDelayMs → 全域配置 → 預設 {@link #DEFAULT_RETRY_DELAY_MS}
     */
    private long resolveRetryDelayMs(JsonNode arguments) {
        long delay = readLongArgument(arguments, "retryDelayMs");
        if (delay <= 0) {
            delay = ConfigProvider.getConfig()
                    .getOptionalValue(CFG_RETRY_DELAY_MS, Long.class)
                    .orElse(DEFAULT_RETRY_DELAY_MS);
        }
        return Math.max(0, delay);
    }

    private int readIntArgument(JsonNode arguments, String field) {
        if (arguments != null && arguments.has(field)) {
            try {
                return Integer.parseInt(arguments.path(field).asText());
            } catch (NumberFormatException ignored) {
            }
        }
        return -1;
    }

    private long readLongArgument(JsonNode arguments, String field) {
        if (arguments != null && arguments.has(field)) {
            try {
                return Long.parseLong(arguments.path(field).asText());
            } catch (NumberFormatException ignored) {
            }
        }
        return -1;
    }

    /**
     * 標準化 HTTP 響應結構
     *
     * errorType 分類規則:
     * - 回應 body 自帶業務碼 code 且 != "100" → BUSINESS (伺服端明確的業務決策,結果確定)
     * - body 無業務碼且 HTTP >= 500          → HTTP_5XX (結果未知)
     * - body 無業務碼且 400 <= HTTP < 500    → HTTP_4XX (請求層問題)
     * - 成功 (code == "100") 不加 errorType 欄位 (向後相容)
     */
    private JsonNode normalizeResponse(HttpResponse<String> response) {
        String respBody = Optional.ofNullable(response.body()).orElse("").trim();
        int statusCode = response.statusCode();
        ObjectNode result;
        boolean businessCodeFromBody = false;

        try {
            if (statusCode == 204 || respBody.isEmpty()) {
                result = jsonMapper.createObjectNode();
                result.put("code", statusCode >= 400 ? "999" : "100");
                result.put("message", statusCode >= 400 ? "HTTP 錯誤: " + statusCode : "成功 (無回傳內容)");
            } else if (respBody.startsWith("{") && respBody.endsWith("}")) {
                result = (ObjectNode) jsonMapper.readTree(respBody);
                if (result.has("code")) {
                    // 業務碼來自目標系統回應本身 → 具備分類為 BUSINESS 的資格
                    businessCodeFromBody = true;
                } else {
                    result.put("code", statusCode >= 400 ? "999" : "100");
                }
                if (!result.has("message")) {
                    result.put("message", statusCode >= 400 ? "HTTP 狀態碼: " + statusCode : "成功");
                }
            } else if (respBody.startsWith("[") && respBody.endsWith("]")) {
                ArrayNode arrayNode = (ArrayNode) jsonMapper.readTree(respBody);
                result = jsonMapper.createObjectNode();
                result.set("data", arrayNode);
                result.put("code", statusCode >= 400 ? "999" : "100");
                result.put("message", statusCode >= 400 ? "HTTP 狀態碼: " + statusCode : "成功");
            } else {
                result = jsonMapper.createObjectNode();
                result.put("rawResponse", respBody);
                result.put("code", statusCode >= 400 ? "999" : "100");
                result.put("message", "HTTP 狀態碼: " + statusCode);
            }
        } catch (Exception parseEx) {
            result = jsonMapper.createObjectNode();
            result.put("rawResponse", respBody);
            result.put("code", "999");
            result.put("message", "JSON 解析錯誤: " + parseEx.getMessage());
        }

        // errorType 分類 (成功回應不標記,維持向後相容)
        if (!"100".equals(result.path("code").asText())) {
            if (businessCodeFromBody) {
                result.put("errorType", ERROR_TYPE_BUSINESS);
            } else {
                result.put("errorType", statusCode >= 500 ? ERROR_TYPE_HTTP_5XX : ERROR_TYPE_HTTP_4XX);
            }
        }

        result.put("_httpStatus", statusCode);
        return (JsonNode) result;
    }

    private record ApiEndpoint(String path, String method, String specDeclaredBaseUrl) {}
}
