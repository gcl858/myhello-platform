package com.example.reconciliation.migration;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.BufferedReader;
import java.io.File;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.JarURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.CRC32;

/**
 * 輕量級模組化資料庫遷移執行器 (Database Migration Runner)
 *
 * 遵循 Flyway 命名規範 (V{version}__{description}.sql)，
 * 自動掃描 Classpath 下 db/migration/ 目錄中的 SQL 腳本並按語意版本號依序執行。
 * 執行紀錄保存於 reconciliation_schema_history 資料表中。
 */
public class DatabaseMigrationRunner {

    private static final Logger LOG = LoggerFactory.getLogger(DatabaseMigrationRunner.class);
    private static final String MIGRATION_PATH = "db/migration";
    private static final Pattern MIGRATION_FILE_PATTERN = Pattern.compile("^V([0-9]+(?:\\.[0-9]+)*)__(.+)\\.sql$");

    public static class MigrationScript implements Comparable<MigrationScript> {
        private final String version;
        private final String description;
        private final String scriptName;
        private final String resourcePath;

        public MigrationScript(String version, String description, String scriptName, String resourcePath) {
            this.version = version;
            this.description = description;
            this.scriptName = scriptName;
            this.resourcePath = resourcePath;
        }

        public String getVersion() {
            return version;
        }

        public String getDescription() {
            return description;
        }

        public String getScriptName() {
            return scriptName;
        }

        public String getResourcePath() {
            return resourcePath;
        }

        @Override
        public int compareTo(MigrationScript other) {
            return compareVersions(this.version, other.version);
        }

        @Override
        public String toString() {
            return scriptName + " (" + version + ")";
        }
    }

    /**
     * 執行所有未套用之遷移腳本
     *
     * @param conn 資料庫連線 (不關閉連線，由呼叫端管理生命週期)
     */
    public static synchronized void runMigrations(Connection conn) {
        try {
            ensureHistoryTable(conn);
            Set<String> appliedVersions = getAppliedVersions(conn);
            List<MigrationScript> scripts = discoverMigrationScripts();

            if (scripts.isEmpty()) {
                LOG.debug("[DatabaseMigrationRunner] 未發現任何 migration 腳本 (classpath:{})", MIGRATION_PATH);
                return;
            }

            Collections.sort(scripts);
            int executedCount = 0;

            for (MigrationScript script : scripts) {
                if (appliedVersions.contains(script.getVersion())) {
                    LOG.debug("[DatabaseMigrationRunner] 腳本已套用，跳過: {}", script.getScriptName());
                    continue;
                }

                LOG.info("[DatabaseMigrationRunner] 開始執行遷移腳本: {}", script.getScriptName());
                long startTime = System.currentTimeMillis();

                String sqlContent = loadScriptContent(script.getResourcePath());
                int checksum = calculateChecksum(sqlContent);

                executeSqlScript(conn, sqlContent);

                long executionTime = System.currentTimeMillis() - startTime;
                recordMigrationSuccess(conn, script, checksum, executionTime);
                executedCount++;

                LOG.info("[DatabaseMigrationRunner] 成功套用遷移腳本: {} (版本: {}, 耗時: {}ms)",
                        script.getScriptName(), script.getVersion(), executionTime);
            }

            if (executedCount > 0) {
                LOG.info("[DatabaseMigrationRunner] 資料庫遷移完成，共成功套用 {} 個腳本。", executedCount);
            } else {
                LOG.info("[DatabaseMigrationRunner] 資料庫結構已是最新版本 (Up to date)。");
            }

        } catch (Exception e) {
            LOG.error("[DatabaseMigrationRunner] 資料庫遷移執行失敗: {}", e.getMessage(), e);
            throw new RuntimeException("Database migration failed: " + e.getMessage(), e);
        }
    }

    /**
     * 確保歷史紀錄表存在
     */
    private static void ensureHistoryTable(Connection conn) throws Exception {
        String createHistoryTableSql = "CREATE TABLE IF NOT EXISTS reconciliation_schema_history (" +
                "installed_rank INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "version TEXT NOT NULL UNIQUE, " +
                "description TEXT NOT NULL, " +
                "type TEXT NOT NULL DEFAULT 'SQL', " +
                "script TEXT NOT NULL, " +
                "checksum INTEGER, " +
                "installed_by TEXT, " +
                "installed_on TIMESTAMP DEFAULT CURRENT_TIMESTAMP, " +
                "execution_time INTEGER, " +
                "success BOOLEAN NOT NULL" +
                ");";
        try (Statement stmt = conn.createStatement()) {
            stmt.execute(createHistoryTableSql);
        }
    }

    /**
     * 查詢所有已成功套用的版本清單
     */
    private static Set<String> getAppliedVersions(Connection conn) throws Exception {
        Set<String> versions = new HashSet<>();
        String sql = "SELECT version FROM reconciliation_schema_history WHERE success = 1";
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                versions.add(rs.getString("version"));
            }
        }
        return versions;
    }

    /**
     * 記錄遷移成功
     */
    private static void recordMigrationSuccess(Connection conn, MigrationScript script, int checksum, long executionTime) throws Exception {
        String insertSql = "INSERT INTO reconciliation_schema_history " +
                "(version, description, type, script, checksum, installed_by, execution_time, success) " +
                "VALUES (?, ?, 'SQL', ?, ?, ?, ?, 1);";
        try (PreparedStatement pstmt = conn.prepareStatement(insertSql)) {
            pstmt.setString(1, script.getVersion());
            pstmt.setString(2, script.getDescription().replace('_', ' '));
            pstmt.setString(3, script.getScriptName());
            pstmt.setInt(4, checksum);
            pstmt.setString(5, System.getProperty("user.name", "system"));
            pstmt.setLong(6, executionTime);
            pstmt.executeUpdate();
        }
    }

    /**
     * 掃描 Classpath 獲取所有 db/migration/ 下的 SQL 檔案
     */
    private static List<MigrationScript> discoverMigrationScripts() {
        List<MigrationScript> scripts = new ArrayList<>();
        Set<String> discoveredScriptNames = new HashSet<>();

        try {
            ClassLoader cl = Thread.currentThread().getContextClassLoader();
            if (cl == null) {
                cl = DatabaseMigrationRunner.class.getClassLoader();
            }

            Enumeration<URL> resources = cl.getResources(MIGRATION_PATH);
            while (resources.hasMoreElements()) {
                URL url = resources.nextElement();
                String protocol = url.getProtocol();

                if ("file".equalsIgnoreCase(protocol)) {
                    File dir = new File(url.toURI());
                    if (dir.exists() && dir.isDirectory()) {
                        File[] files = dir.listFiles((d, name) -> name.endsWith(".sql"));
                        if (files != null) {
                            for (File f : files) {
                                parseAndAddScript(f.getName(), MIGRATION_PATH + "/" + f.getName(), scripts, discoveredScriptNames);
                            }
                        }
                    }
                } else if ("jar".equalsIgnoreCase(protocol)) {
                    URLConnection urlConn = url.openConnection();
                    if (urlConn instanceof JarURLConnection) {
                        JarURLConnection jarConn = (JarURLConnection) urlConn;
                        try (JarFile jarFile = jarConn.getJarFile()) {
                            Enumeration<JarEntry> entries = jarFile.entries();
                            while (entries.hasMoreElements()) {
                                JarEntry entry = entries.nextElement();
                                String entryName = entry.getName();
                                if (entryName.startsWith(MIGRATION_PATH + "/") && entryName.endsWith(".sql") && !entry.isDirectory()) {
                                    String fileName = entryName.substring(entryName.lastIndexOf('/') + 1);
                                    parseAndAddScript(fileName, entryName, scripts, discoveredScriptNames);
                                }
                            }
                        }
                    }
                }
            }

            // 備用防護：預設已知的核心遷移腳本列表（若 Classpath 目錄掃描因特殊容器環境未枚舉完整時）
            String[] fallbackScripts = {
                "V1.0.0__create_workflow_execution_log.sql",
                "V1.1.0__create_view_transfer_reconciliation.sql"
            };
            for (String fallbackName : fallbackScripts) {
                if (!discoveredScriptNames.contains(fallbackName)) {
                    String resPath = MIGRATION_PATH + "/" + fallbackName;
                    if (cl.getResource(resPath) != null) {
                        parseAndAddScript(fallbackName, resPath, scripts, discoveredScriptNames);
                    }
                }
            }

        } catch (Exception e) {
            LOG.warn("[DatabaseMigrationRunner] 掃描遷移腳本時發生警告: {}", e.getMessage());
        }

        return scripts;
    }

    private static void parseAndAddScript(String fileName, String resourcePath, List<MigrationScript> list, Set<String> discovered) {
        if (discovered.contains(fileName)) {
            return;
        }
        Matcher matcher = MIGRATION_FILE_PATTERN.matcher(fileName);
        if (matcher.matches()) {
            String version = matcher.group(1);
            String description = matcher.group(2);
            list.add(new MigrationScript(version, description, fileName, resourcePath));
            discovered.add(fileName);
        }
    }

    /**
     * 讀取 SQL 腳本內容
     */
    private static String loadScriptContent(String resourcePath) throws Exception {
        ClassLoader cl = Thread.currentThread().getContextClassLoader();
        if (cl == null) {
            cl = DatabaseMigrationRunner.class.getClassLoader();
        }
        try (InputStream in = cl.getResourceAsStream(resourcePath)) {
            if (in == null) {
                throw new IllegalStateException("找不到資源檔案: " + resourcePath);
            }
            StringBuilder sb = new StringBuilder();
            try (BufferedReader reader = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    sb.append(line).append("\n");
                }
            }
            return sb.toString();
        }
    }

    /**
     * 執行 SQL 腳本
     */
    private static void executeSqlScript(Connection conn, String sqlContent) throws Exception {
        List<String> statements = splitSqlStatements(sqlContent);
        try (Statement stmt = conn.createStatement()) {
            for (String sql : statements) {
                String trimmed = sql.trim();
                if (!trimmed.isEmpty()) {
                    stmt.execute(trimmed);
                }
            }
        }
    }

    /**
     * 分割 SQL 語句 (依分號分割，同時忽略註解與字串內的假分號)
     */
    private static List<String> splitSqlStatements(String sqlContent) {
        List<String> statements = new ArrayList<>();
        StringBuilder current = new StringBuilder();
        boolean inSingleQuote = false;
        boolean inLineComment = false;
        boolean inBlockComment = false;

        char[] chars = sqlContent.toCharArray();
        for (int i = 0; i < chars.length; i++) {
            char c = chars[i];
            char next = (i + 1 < chars.length) ? chars[i + 1] : '\0';

            if (inLineComment) {
                if (c == '\n' || c == '\r') {
                    inLineComment = false;
                }
                continue;
            }

            if (inBlockComment) {
                if (c == '*' && next == '/') {
                    inBlockComment = false;
                    i++;
                }
                continue;
            }

            if (!inSingleQuote) {
                if (c == '-' && next == '-') {
                    inLineComment = true;
                    i++;
                    continue;
                }
                if (c == '/' && next == '*') {
                    inBlockComment = true;
                    i++;
                    continue;
                }
            }

            if (c == '\'') {
                inSingleQuote = !inSingleQuote;
                current.append(c);
                continue;
            }

            if (c == ';' && !inSingleQuote) {
                String stmt = current.toString().trim();
                if (!stmt.isEmpty()) {
                    statements.add(stmt);
                }
                current.setLength(0);
                continue;
            }

            current.append(c);
        }

        String remaining = current.toString().trim();
        if (!remaining.isEmpty()) {
            statements.add(remaining);
        }

        return statements;
    }

    /**
     * 計算 Checksum
     */
    private static int calculateChecksum(String content) {
        CRC32 crc = new CRC32();
        byte[] bytes = content.replaceAll("\r\n", "\n").getBytes(StandardCharsets.UTF_8);
        crc.update(bytes);
        return (int) crc.getValue();
    }

    /**
     * 語意版本比對 (e.g. 1.0.0 vs 1.1.0)
     */
    public static int compareVersions(String v1, String v2) {
        String[] parts1 = v1.split("\\.");
        String[] parts2 = v2.split("\\.");
        int length = Math.max(parts1.length, parts2.length);

        for (int i = 0; i < length; i++) {
            int p1 = i < parts1.length ? Integer.parseInt(parts1[i]) : 0;
            int p2 = i < parts2.length ? Integer.parseInt(parts2[i]) : 0;
            if (p1 != p2) {
                return Integer.compare(p1, p2);
            }
        }
        return 0;
    }
}

