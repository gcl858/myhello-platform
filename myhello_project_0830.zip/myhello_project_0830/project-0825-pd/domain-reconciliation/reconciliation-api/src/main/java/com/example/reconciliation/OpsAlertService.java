package com.example.reconciliation;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import jakarta.enterprise.context.ApplicationScoped;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Map;

/**
 * 運維條件告警服務 (Ops Alert Service, v2.2 新增)
 *
 * <p>設計定位:workflow 統一終點 (FinalAuditAndEnd) 於每次收尾時呼叫本服務,
 * 僅當 {@code finalStatus == "ROLLBACK_FAILED"} (回沖失敗、需人工介入) 時實際觸發告警,
 * 其餘狀態靜默返回 {@code raised=false},不產生日誌噪音。
 *
 * <p>目前通道:<b>專屬 SLF4J logger {@code OPS-ALERT}</b>,輸出 ERROR 級日誌,
 * 供 ELK / Splunk 依關鍵字 {@code [OPS-ALERT]} 建立告警規則接單 (ticketing)。
 *
 * <p>擴充點:如需串接 Kafka / webhook / ITSM,實作對應通道後於 {@link #raise} 內追加即可,
 * workflow 端契約 ({@code raised} 布林回傳) 不變。
 */
@ApplicationScoped
public class OpsAlertService {

    /** 專屬告警通道 logger — 以名稱建立,便於 log 設定檔單獨調級/分流 */
    private static final Logger ALERT_LOG = LoggerFactory.getLogger("OPS-ALERT");
    private static final Logger LOG = LoggerFactory.getLogger(OpsAlertService.class);
    private static final ObjectMapper MAPPER = new ObjectMapper();

    /** 觸發告警的業務狀態 */
    static final String ALERT_ON_STATUS = "ROLLBACK_FAILED";

    /**
     * 條件告警進入點 (展開參數版 — 對應 SonataFlow arguments 反射綁定)
     *
     * <p>⚠️ 簽名須與 workflow functionRef arguments 完全對應:
     * Kogito codegen 以精確型別反射查找 {@code raise(String, Object, Object, Object, Object, Map)},
     * 參數一律用 Object/Map 接收(jq 運算式產出),內部再轉字串。
     *
     * @return {@code {raised: true|false}};raised=true 表示已發出 [OPS-ALERT]
     */
    public JsonNode raise(String workflowId, Object processInstanceId, Object businessKey,
                          Object finalStatus, Object finalMessage, Map<String, Object> detail) {
        ObjectNode result = MAPPER.createObjectNode();
        String status = finalStatus != null ? finalStatus.toString() : null;
        if (!ALERT_ON_STATUS.equals(status)) {
            result.put("raised", false);
            return result;
        }
        try {
            // TODO(擴充點): 串接 Kafka / webhook / ITSM 時於此追加通道
            ALERT_LOG.error("[OPS-ALERT] 回沖失敗,需人工介入 | workflowId={} | instanceId={} | businessKey={} | message={} | detail={}",
                    workflowId, processInstanceId, businessKey, finalMessage,
                    detail != null ? detail.toString() : "{}");
            result.put("raised", true);
        } catch (Exception e) {
            // 告警通道故障不得阻斷交易收尾 — 降級為一般日誌並標記未送出
            LOG.error("OpsAlertService 送出告警失敗 (workflowId={}, instanceId={}): {}",
                    workflowId, processInstanceId, e.getMessage(), e);
            result.put("raised", false);
        }
        return result;
    }

    /**
     * 單一 JsonNode 參數版 (相容 Kogito codegen 不同綁定形態)
     */
    public JsonNode raise(JsonNode arguments) {
        if (arguments == null || !arguments.hasNonNull("finalStatus")) {
            ObjectNode result = MAPPER.createObjectNode();
            result.put("raised", false);
            return result;
        }
        java.util.Map<String, Object> detailMap = null;
        if (arguments.hasNonNull("detail") && arguments.get("detail").isObject()) {
            detailMap = MAPPER.convertValue(arguments.get("detail"),
                    new com.fasterxml.jackson.core.type.TypeReference<java.util.Map<String, Object>>() {
                    });
        }
        return raise(
                arguments.path("workflowId").asText(null),
                arguments.path("processInstanceId").asText(null),
                arguments.path("businessKey").asText(null),
                arguments.path("finalStatus").asText(),
                arguments.path("finalMessage").asText(""),
                detailMap);
    }
}
