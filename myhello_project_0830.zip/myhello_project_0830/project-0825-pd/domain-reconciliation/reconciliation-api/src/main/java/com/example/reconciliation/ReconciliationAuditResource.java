package com.example.reconciliation;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.inject.Inject;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

@Path("/api/reconciliation")
@Produces(MediaType.APPLICATION_JSON)
public class ReconciliationAuditResource {

    private static final ObjectMapper MAPPER = new ObjectMapper();

    @Inject
    AuditQueryService auditService;

    /**
     * GET /api/reconciliation/records
     * 查詢對帳與審計交易流水，支援條件篩選
     */
    @GET
    @Path("/records")
    public Response getRecords(
            @QueryParam("accountA") String accountA,
            @QueryParam("accountB") String accountB,
            @QueryParam("status") String status,
            @QueryParam("minAmt") Double minAmt,
            @QueryParam("maxAmt") Double maxAmt) {
        JsonNode records = auditService.getReconciliationRecords(accountA, accountB, status, minAmt, maxAmt);
        return Response.ok(records.toString()).build();
    }

    /**
     * GET /api/reconciliation/files
     * 回傳歷史產出的 reconciliation-*.csv 檔案清單
     */
    @GET
    @Path("/files")
    public Response getFiles() {
        JsonNode files = auditService.getReconciliationFiles();
        return Response.ok(files.toString()).build();
    }

    /**
     * GET /api/reconciliation/files/{filename}
     * 下載或檢視特定 CSV 檔案內容
     */
    @GET
    @Path("/files/{filename}")
    @Produces(MediaType.TEXT_PLAIN)
    public Response getFileContent(@PathParam("filename") String filename) {
        String content = auditService.getCsvFileContent(filename);
        return Response.ok(content).header("Content-Disposition", "inline; filename=\"" + filename + "\"").build();
    }

    /**
     * POST /api/reconciliation/export-csv
     * 手動觸發產生新對帳 CSV 檔
     */
    @POST
    @Path("/export-csv")
    @Consumes(MediaType.APPLICATION_JSON)
    public Response exportCsv(JsonNode body) {
        String workflowId = body != null && body.has("workflowId") ? body.get("workflowId").asText() : null;
        String status = body != null && body.has("status") ? body.get("status").asText() : null;
        JsonNode res = auditService.exportCsv(workflowId, status);
        return Response.ok(res.toString()).build();
    }

    /**
     * POST /api/reconciliation/trigger-saga2
     * 觸發 Saga2 轉帳流程 (前端代理)
     */
    @POST
    @Path("/trigger-saga2")
    @Consumes(MediaType.APPLICATION_JSON)
    public Response triggerSaga2(JsonNode body) {
        String accountA = body != null && body.has("Account_A") ? body.get("Account_A").asText() : "Account_Standalone_A";
        String accountB = body != null && body.has("Account_B") ? body.get("Account_B").asText() : "Account_Standalone_B";
        int amt = body != null && body.has("AMT") ? body.get("AMT").asInt(500) : 500;
        JsonNode res = auditService.triggerSaga2Transfer(accountA, accountB, amt);
        return Response.ok(res.toString()).build();
    }

    /**
     * POST /api/reconciliation/proxy-test
     * 沙盒通用測試代理端點：可選取並發送測試至 5 大 Workflow
     */
    @POST
    @Path("/proxy-test")
    @Consumes(MediaType.APPLICATION_JSON)
    public Response proxyTest(JsonNode body) {
        String workflowPath = body != null && body.has("workflowPath") ? body.get("workflowPath").asText() : "saga2-transfer-workflow";
        JsonNode payload = body != null && body.has("payload") ? body.get("payload") : MAPPER.createObjectNode();
        JsonNode res = auditService.proxyTestWorkflow(workflowPath, payload);
        return Response.ok(res.toString()).build();
    }

    /**
     * POST /api/reconciliation/graphql
     * GraphQL 代理端點：轉發至 8080 /graphql，解決瀏覽器跨域 (CORS) 問題
     */
    @POST
    @Path("/graphql")
    @Consumes(MediaType.APPLICATION_JSON)
    public Response proxyGraphQL(JsonNode body) {
        JsonNode res = auditService.proxyGraphQL(body);
        return Response.ok(res.toString()).build();
    }

    /**
     * GET /api/reconciliation/jobs
     * 查詢 Kogito Jobs & Timers 延遲任務排程
     */
    @GET
    @Path("/jobs")
    public Response getJobs(@QueryParam("status") String status) {
        JsonNode jobs = auditService.getJobsRecords(status);
        return Response.ok(jobs.toString()).build();
    }

    /**
     * POST /api/reconciliation/jobs/{id}/retry
     * 手動發送 Job 重試
     */
    @POST
    @Path("/jobs/{id}/retry")
    public Response retryJob(@PathParam("id") String id) {
        JsonNode res = auditService.retryJob(id);
        return Response.ok(res.toString()).build();
    }

    /**
     * POST /api/reconciliation/jobs/{id}/cancel
     * 手動取消 Job 排程
     */
    @POST
    @Path("/jobs/{id}/cancel")
    public Response cancelJob(@PathParam("id") String id) {
        JsonNode res = auditService.cancelJob(id);
        return Response.ok(res.toString()).build();
    }

    /**
     * GET /api/reconciliation/specs
     * 讀取與解析 OpenAPI 規格檔案
     */
    @GET
    @Path("/specs")
    public Response getOpenApiSpecs() {
        JsonNode specs = auditService.getOpenApiSpecs();
        return Response.ok(specs.toString()).build();
    }

    /**
     * POST /api/reconciliation/specs/ping
     * 執行連線品質點檢 (Health Check Ping)
     */
    @POST
    @Path("/specs/ping")
    @Consumes(MediaType.APPLICATION_JSON)
    public Response pingEndpoint(JsonNode body) {
        String targetUrl = body != null && body.has("targetUrl") ? body.get("targetUrl").asText() : "http://localhost:8080/";
        JsonNode res = auditService.pingEndpoint(targetUrl);
        return Response.ok(res.toString()).build();
    }

    /**
     * GET /api/reconciliation/instances
     * 取得近期工作流實例 ID 清單
     */
    @GET
    @Path("/instances")
    public Response getRecentInstances() {
        JsonNode instances = auditService.getRecentInstances();
        return Response.ok(instances.toString()).build();
    }

    /**
     * GET /api/reconciliation/trace/{instanceId}
     * 取得特定工作流實例之圖形化節點軌跡與細節
     */
    @GET
    @Path("/trace/{instanceId}")
    public Response getInstanceTrace(@PathParam("instanceId") String instanceId) {
        JsonNode trace = auditService.getInstanceTrace(instanceId);
        return Response.ok(trace.toString()).build();
    }
}
