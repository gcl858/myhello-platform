-- =====================================================================
-- Migration V1.0.1: 為 workflow_execution_log 新增 cancelled_by / cancelled_at 欄位
-- 模組: domain-reconciliation / reconciliation-api
-- 用途: WF-B (repayment-cash-cancellation) 取消時,用 markOriginalCancelled state
--       更新對應原 REPAYMENT row 的取消記錄
-- 對齊 draft-omni-counter-repayment/spec/spec.md §3.2.3 (H14 細節)
-- 兼容性: 既有 row 的 cancelled_by / cancelled_at 為 NULL,完全不影響
-- =====================================================================

ALTER TABLE workflow_execution_log ADD COLUMN cancelled_by TEXT;
ALTER TABLE workflow_execution_log ADD COLUMN cancelled_at TIMESTAMP;

CREATE INDEX IF NOT EXISTS idx_wel_cancelled_by
    ON workflow_execution_log(cancelled_by);
