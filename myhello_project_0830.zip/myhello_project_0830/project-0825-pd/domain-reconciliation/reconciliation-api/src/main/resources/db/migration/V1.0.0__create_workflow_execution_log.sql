-- =====================================================================
-- Migration V1.0.0: 建立全系統通用流程執行紀錄表與索引
-- 模組: domain-reconciliation / reconciliation-api
-- =====================================================================

CREATE TABLE IF NOT EXISTS workflow_execution_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    workflow_id TEXT,
    business_key TEXT,
    process_instance_id TEXT,
    status TEXT,
    message TEXT,
    input_data TEXT,
    output_data TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_wel_process_instance_id 
    ON workflow_execution_log(process_instance_id);

CREATE INDEX IF NOT EXISTS idx_wel_workflow_business_key 
    ON workflow_execution_log(workflow_id, business_key);

