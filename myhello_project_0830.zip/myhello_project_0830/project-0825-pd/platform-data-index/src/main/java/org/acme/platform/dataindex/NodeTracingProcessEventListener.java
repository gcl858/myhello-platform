package org.acme.platform.dataindex;

import java.util.LinkedHashMap;
import java.util.Map;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.quarkus.arc.Unremovable;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import org.kie.api.event.process.ErrorEvent;
import org.kie.api.event.process.ProcessNodeLeftEvent;
import org.kie.api.event.process.ProcessNodeTriggeredEvent;
import org.kie.api.runtime.process.WorkflowProcessInstance;
import org.kie.kogito.internal.process.event.DefaultKogitoProcessEventListener;
import org.kie.kogito.internal.process.runtime.KogitoNodeInstance;
import org.kie.kogito.internal.process.runtime.KogitoWorkflowProcessInstance;
import org.kie.kogito.internal.process.runtime.KogitoWorkItemNodeInstance;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * ProcessEventListener 負責在所有節點執行時自動記錄:
 * 1) input_args: 進入節點時的輸入參數 / 流程狀態 snapshot
 * 2) output_args: 離開節點時的輸出結果 / 流程狀態 snapshot
 * 3) error_message: 節點或流程發生錯誤時的詳細錯誤訊息
 *
 * 確保 nodes 資料表 (reconciliation.db) 中所有節點 (Split, ActionNode, StartNode, EndNode,
 * WorkItemNode, CompositeContextNode, Join 等) 均有完整 I/O 與錯誤紀錄。
 */
@ApplicationScoped
@Unremovable
public class NodeTracingProcessEventListener extends DefaultKogitoProcessEventListener {

    private static final Logger LOG = LoggerFactory.getLogger(NodeTracingProcessEventListener.class);
    private static final String INPUT_ARGS_KEY = "inputArgs";
    private static final String OUTPUT_ARGS_KEY = "outputArgs";
    private static final String ERROR_MESSAGE_KEY = "errorMessage";
    private static final String WORKFLOW_DATA_KEY = "workflowdata";

    @Inject
    ObjectMapper objectMapper;

    private final ObjectMapper fallbackMapper = new ObjectMapper();

    @Override
    public void beforeNodeTriggered(ProcessNodeTriggeredEvent event) {
        try {
            if (event.getNodeInstance() instanceof KogitoNodeInstance nodeInstance) {
                Map<String, Object> metaData = nodeInstance.getMetaData();
                if (metaData != null && metaData.get(INPUT_ARGS_KEY) == null) {
                    Object inputArgs = extractInputArgs(event, nodeInstance);
                    if (inputArgs != null) {
                        metaData.put(INPUT_ARGS_KEY, inputArgs);
                    }
                }
            }
        } catch (Exception e) {
            LOG.warn("Failed to capture inputArgs for node {}: {}",
                    event.getNodeInstance() != null ? event.getNodeInstance().getNodeName() : "unknown",
                    e.getMessage());
        }
    }

    @Override
    public void beforeNodeLeft(ProcessNodeLeftEvent event) {
        try {
            if (event.getNodeInstance() instanceof KogitoNodeInstance nodeInstance) {
                Map<String, Object> metaData = nodeInstance.getMetaData();
                if (metaData != null && metaData.get(OUTPUT_ARGS_KEY) == null) {
                    Object outputArgs = extractOutputArgs(event, nodeInstance);
                    if (outputArgs != null) {
                        metaData.put(OUTPUT_ARGS_KEY, outputArgs);
                    }
                }
            }
        } catch (Exception e) {
            LOG.warn("Failed to capture outputArgs for node {}: {}",
                    event.getNodeInstance() != null ? event.getNodeInstance().getNodeName() : "unknown",
                    e.getMessage());
        }
    }

    @Override
    public void onError(ErrorEvent event) {
        try {
            if (event.getProcessInstance() instanceof KogitoWorkflowProcessInstance pi) {
                String errorMessage = pi.getErrorMessage();
                if (errorMessage == null && pi.getErrorCause().isPresent()) {
                    Throwable cause = pi.getErrorCause().get();
                    errorMessage = cause.getMessage() != null ? cause.getMessage() : cause.toString();
                }
                if (errorMessage == null) {
                    errorMessage = "Process execution error";
                }

                if (event.getNodeInstance() instanceof KogitoNodeInstance nodeInstance) {
                    Map<String, Object> metaData = nodeInstance.getMetaData();
                    if (metaData != null) {
                        metaData.put(ERROR_MESSAGE_KEY, errorMessage);
                        if (metaData.get(OUTPUT_ARGS_KEY) == null) {
                            Map<String, Object> errorOutput = new LinkedHashMap<>();
                            errorOutput.put("error", errorMessage);
                            metaData.put(OUTPUT_ARGS_KEY, errorOutput);
                        }
                    }
                }
            }
        } catch (Exception e) {
            LOG.warn("Failed to record error_message on error event: {}", e.getMessage());
        }
    }

    private Object extractInputArgs(ProcessNodeTriggeredEvent event, KogitoNodeInstance nodeInstance) {
        if (nodeInstance instanceof KogitoWorkItemNodeInstance workItemNode) {
            if (workItemNode.getWorkItem() != null && workItemNode.getWorkItem().getParameters() != null) {
                Map<String, Object> params = workItemNode.getWorkItem().getParameters();
                if (!params.isEmpty()) {
                    return snapshotValue(params);
                }
            }
        }
        return extractProcessStateSnapshot(event.getProcessInstance());
    }

    private Object extractOutputArgs(ProcessNodeLeftEvent event, KogitoNodeInstance nodeInstance) {
        if (nodeInstance instanceof KogitoWorkItemNodeInstance workItemNode) {
            if (workItemNode.getWorkItem() != null && workItemNode.getWorkItem().getResults() != null) {
                Map<String, Object> results = workItemNode.getWorkItem().getResults();
                if (!results.isEmpty()) {
                    return snapshotValue(results);
                }
            }
        }
        return extractProcessStateSnapshot(event.getProcessInstance());
    }

    private Object extractProcessStateSnapshot(org.kie.api.runtime.process.ProcessInstance pi) {
        if (pi instanceof org.kie.kogito.internal.process.runtime.KogitoProcessInstance kpi) {
            Map<String, Object> variables = kpi.getVariables();
            if (variables != null && !variables.isEmpty()) {
                if (variables.containsKey(WORKFLOW_DATA_KEY)) {
                    Object wfData = variables.get(WORKFLOW_DATA_KEY);
                    if (wfData != null) {
                        return snapshotValue(wfData);
                    }
                }
                return snapshotValue(variables);
            }
        }
        return null;
    }

    private Object snapshotValue(Object value) {
        if (value == null) {
            return null;
        }
        if (value instanceof JsonNode jsonNode) {
            return jsonNode.deepCopy();
        }
        ObjectMapper mapper = objectMapper != null ? objectMapper : fallbackMapper;
        try {
            return mapper.valueToTree(value);
        } catch (Exception e) {
            if (value instanceof Map<?, ?> map) {
                return new LinkedHashMap<>(map);
            }
            return value;
        }
    }
}
