package org.acme.platform.dataindex;

import com.example.platform.common.PlatformPaths;
import org.eclipse.microprofile.config.spi.ConfigSource;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

/**
 * 自動為 Quarkus 注入 MYHELLO_DATA_DIR 與 MYHELLO_LOGS_DIR。
 *
 * <p>藉由 MicroProfile ConfigSource 機制,在 Quarkus 載入配置與初始化 DataSource 前,
 * 自動透過 {@link PlatformPaths} 解析專案根目錄之 data 與 logs 路徑,並確保實體資料夾存在。
 *
 * <p>優先級 (Ordinal) 設為 250:
 * <ul>
 *   <li>高於 application.properties (100) 的預設 fallback</li>
 *   <li>低於作業系統環境變數 (300) 與 JVM 參數 -D (400),保留外部覆寫能力</li>
 * </ul>
 */
public class PlatformConfigSource implements ConfigSource {

    public static final String NAME = "PlatformConfigSource";
    private final Map<String, String> properties = new HashMap<>();

    public PlatformConfigSource() {
        try {
            String dataDir = PlatformPaths.ensureDataDirectory().toAbsolutePath().toString();
            String logsDir = PlatformPaths.ensureLogsDirectory().toAbsolutePath().toString();
            properties.put(PlatformPaths.DATA_DIR_ENV, dataDir);
            properties.put(PlatformPaths.LOGS_DIR_ENV, logsDir);
        } catch (Exception e) {
            // fallback gracefully if filesystem permissions prevent mkdir
        }
    }

    @Override
    public int getOrdinal() {
        return 250;
    }

    @Override
    public Map<String, String> getProperties() {
        return properties;
    }

    @Override
    public Set<String> getPropertyNames() {
        return properties.keySet();
    }

    @Override
    public String getValue(String propertyName) {
        return properties.get(propertyName);
    }

    @Override
    public String getName() {
        return NAME;
    }
}
