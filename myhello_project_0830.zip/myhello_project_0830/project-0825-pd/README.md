# myhello-platform

> 從單一 `myhello-sonataflow` 模組重構出來的企業級多模組 SonataFlow 平台。

## 模組全景

```
myhello-platform/                                    ← parent POM (packaging=pom)
│
├── platform-common/                                 ← 共用工具層 (無 framework 依賴) — `PlatformPaths` 路徑工具 + `package-info`
│
├── platform-security/                               ← 橫切:`SonataFlowSecurityConfig`(SwaggerFilter/RuntimeFilter/WorkflowStatusFilter)、`UnwrapResponseFilter`、`OpenApiFilter`
│
├── platform-extensions/                             ← Kogito / Quarkus 擴展與 SQLite 修補原始碼 (Data Index & Storage);每個子模組內含 runtime/ 與 deployment/ 兩層
│   ├── data-index-storage-sqlite/                   ← SQLite 儲存適配器 + 22 個 Flyway SQL 腳本 (`SQLiteStorage`、`ContainsSQLFunction`、`SQLiteJsonPredicateBuilder`...)
│   ├── kogito-addons-quarkus-data-index-sqlite/     ← Data Index Runtime (`SqliteZonedDateTimeJavaType`/`JdbcType`/`UserType`/`IntegrationListener`) 與 Deployment (`SQLiteDataIndexProcessor`、`SqliteZonedDateTimeIntegrationProcessor`、`KogitoAppsPersistenceConfig`)
│   └── kogito-addons-quarkus-data-index-persistence-sqlite/ ← 持久化 Runtime 與 Deployment (`SQLiteDataIndexPersistenceProcessor`) 擴展
│
├── platform-data-index/                             ← Kogito Data Index + SQLite 自訂 dialect (`KogitoSQLiteDialect`、`SqliteZonedDateTimeJdbcType`) + `MyLivenessCheck` 健康檢查 + `PlatformConfigSource` (ordinal=250)
│
├── domain-transfer/                                 ← Bounded context: 轉帳 (parent, prod-only)
│   └── transfer-workflow/                           ← saga-transfer-workflow (v15) + saga2-transfer-workflow (v2);Service: `SagaApiService`、`MyOpenApiService`;OpenAPI 合約 (`specs/A16229-api.yaml`、`A16220-api.yaml`) 自包含於本模組 resources
│
├── domain-reconciliation/                           ← Bounded context: 對帳 (parent)
│   └── reconciliation-api/                          ← `ReconciliationResource` (CSV 匯出) + `ReconciliationAuditResource` (查詢 API) + `ReconciliationCsvExporter` + `AuditLogService` (WAL 寫入) + `AuditQueryService` + `OpsAlertService` ([OPS-ALERT] 運維告警)
│
├── dev/                                             ← [v1.2] dev-only 模組 parent,僅 dev profile 納入 reactor
│   ├── transfer-samples/                            ← [v1.2] 從 domain-transfer 搬出。OpenAPI / java / rest-workflow 示範 (`ApiService` 範例)
│   └── transfer-mock/                               ← [v1.2] 從頂層 mocks/ 搬入。JAX-RS mock (`A16229Resource`、`A16220Resource`) + DTO
│
└── distribution/                                    ← Runnable Quarkus 應用 (parent)
    ├── transfer-app/                                ← 組裝平台層 + transfer domain + reconciliation-api → 1 個 quarkus-run.jar (Port 8080)
    └── reconciliation-app/                          ← 組裝平台層 + reconciliation domain → 1 個 quarkus-run.jar (Port 8090,僅讀模式)
```

## 模組依賴圖 (DAG)

```
                  ┌──────────────────┐
                  │ platform-common  │  ← leaf
                  └────────┬─────────┘
                           │
         ┌─────────────────┴────────────────┐
         ▼                                  ▼
 ┌──────────────┐   ┌────────────────┐   ┌────────────────┐
 │platform-     │   │platform-       │   │transfer-       │
 │security      │   │data-index      │   │workflow        │
 └──────────────┘   └────────────────┘   │(內含 OpenAPI   │
                                         │specs 合約)     │
                                         └────────┬───────┘
                                                  │ (跨域合約依賴,
                                                  │  僅用 AuditLogService)
                                                  ▼
                                         ┌────────────────┐
                                         │reconciliation- │
                                         │api             │
                                         └────────────────┘

 ┌────────────────┐        ┌────────────────┐
 │transfer-       │        │transfer-mock   │
 │samples         │        │(外部系統模擬器, │
 │(無內部依賴)     │        │ 僅測試用)       │
 └────────────────┘        └────────────────┘
   ↑ leaf                     ↑ leaf

 ┌──────────────────┐        ┌──────────────────┐
 │transfer-app      │        │reconciliation-   │
 │(Quarkus runner)  │        │app               │
 │  Port 8080       │        │  Port 8090       │
 │(組裝 workflow +  │        │(僅讀模式)        │
 │ mock + samples)  │        │                  │
 └──────────────────┘        └──────────────────┘
```

**核心不變式**:

1. 沒有任何 `domain-*` 反向依賴 `platform-*`(domain 只能往下)
2. 沒有 `transfer-*` 依賴 `reconciliation-*` 內部實作(只有 `transfer-workflow` 用 `AuditLogService` 介面,合約定義在 reconciliation-api)
3. `distribution/*` 是唯一允許組裝 platform + domain 的地方
4. 沒有任何循環依賴

## 部署模型

| Distribution       | Port | 寫入 reconciliation.db? | Pod 數量 | 用途         |
|--------------------|------|------------------------|---------|--------------|
| `transfer-app`     | 8080 | 是 (含 workflow + audit log) | ≥ 3  | 線上交易     |
| `reconciliation-app` | 8090 | 僅讀 (`quarkus.datasource.jdbc.read-only=true`) | 1~2 | 對帳查詢/匯出 |

> 註:`reconciliation-app` 設為 `read-only` 模式,所有寫入由 `transfer-app` 透過 `AuditLogService` 負責,避免兩個 app 同時寫造成 SQLite WAL lock contention。

兩個 distribution 透過共用 volume / 共享 storage 讀寫同一個 `reconciliation.db`。
SQLite WAL 模式可承受多 reader + 1 writer,但若改用 Postgres 就不必共享。

## 快速建置與執行

### A. 一般建置

> **[v1.2] 建置模式**:`mvn` 命令現在支援 `-P dev` / `-P prod` 切換。
> - **dev** (預設):含 `dev/transfer-samples` + `dev/transfer-mock` — 適合本機開發、UAT 整合測試
> - **prod**:排除整個 `dev/` 子樹,workflow 改打真實外部系統 — 適合 production deploy

```bash
# ── DEV 建置(預設,向後相容舊版指令 mvn clean package) ──
# 1. 完整編譯與打包(含 transfer-samples + transfer-mock)
mvn clean package -DskipTests        # 預設 dev profile
mvn clean package -DskipTests  -P prod # 明確指定 prod

# 2. 分別啟動服務(dev 模式,workflow 會打內嵌 mock @ localhost:8080)
java -jar distribution/transfer-app/target/quarkus-app/quarkus-run.jar        # Port 8080
java -jar distribution/reconciliation-app/target/quarkus-app/quarkus-run.jar  # Port 8090

# 3. Dev UI # Port 8080
mvn quarkus:dev -pl distribution/transfer-app -am -DskipTests
# 或
cd distribution/transfer-app
mvn quarkus:dev -am -DskipTests

# ── PROD 建置 ──
# 1. 編譯 prod 鏡像(物理排除 dev/ 子樹,自動 -DskipTests)
mvn clean package -P prod

# 2. 部署前必須設定 prod 環境變數(由 application.properties %prod.* 觸發):
#    PRODUCTION_API_BASE_URL=https://apimgw.tttkkkk.com.tw/tttkkkk/private/TWS/ESB/TWTXN
#    QUARKUS_TLS_TRUST_STORE=/path/to/truststore.p12
#    QUARKUS_TLS_TRUST_STORE_PASSWORD=...

# 3. 啟動 prod 鏡像
java -jar distribution/transfer-app/target/quarkus-app/quarkus-run.jar
```

# 打包成 .zip
tar -caf ..\project-0820-no-target.zip --exclude='target' *
```

 


> **跨平台提醒**:本專案 Java 程式碼全部以**相對路徑**撰寫,
> 透過 [`platform-common`](platform-common/src/main/java/com/example/platform/common/PlatformPaths.java)
> 的 `PlatformPaths` 工具統一解析 `data/` 等目錄,
> 因此 Linux、macOS、Windows 都能直接 `mvn clean package`。
> SQLite JDBC 路徑(`jdbc:sqlite:data/reconciliation.db`)、CSV 寫入、Classpath 資源
> (`MyOpenApiService` 動態讀取 OpenAPI YAML)皆已驗證跨平台相容。

### B. 斷網主機 100% 離線建置 (Air-Gapped / Offline)
專案內建完整的離線依賴庫，完全不需要外網連線。

**依作業系統選擇對應腳本**:
| OS | 腳本 | 說明 |
|---|---|---|
| **Linux / macOS** | `./offline-build.sh` | Bash 版本 |
| **Windows (PowerShell)** | `.\offline-build.ps1` | PowerShell 版本 (含中文編碼處理) |

```bash
# Linux / macOS
./offline-build.sh
```

```powershell
# Windows (PowerShell)
.\offline-build.ps1
```

```powershell
# Windows (PowerShell) — 額外參數範例
.\offline-build.ps1 -SkipTests                          # 跳過測試
.\offline-build.ps1 -OfflineRepo D:\repo                # 指定其他離線套件庫
```

## 相關架構與決策文件

### 系統設計與決策
- **完整系統架構說明文件 (Markdown + Mermaid)**：[docs/SYSTEM-ARCHITECTURE.md](docs/SYSTEM-ARCHITECTURE.md)
- **Java 程式碼詳細說明文件**：[docs/CODE-SPECIFICATION.md](docs/CODE-SPECIFICATION.md)
- **模組切分決策紀錄**：[docs/MODULE-SPLIT-DECISION.md](docs/MODULE-SPLIT-DECISION.md)

### 深入專論
- **新 Workflow 開發 SOP** (以 saga2 為範本:YAML 骨架慣例、三層防線、平台註冊清單、測試與已知地雷):[docs/NEW-WORKFLOW-SOP.md](docs/NEW-WORKFLOW-SOP.md)
- **通用 OpenAPI 服務完整手冊與架構指南** (`MyOpenApiService` 動態規格解析、4 層快取、Path/Query 參數、自訂標頭與響應正規化)：[docs/OPENAPI-SERVICE-GUIDE.md](docs/OPENAPI-SERVICE-GUIDE.md)
- **Saga2 Transfer 工作流規格書** (基於 OpenAPI 動態調用之兩階段 Saga 回沖)：[docs/saga2-transfer-workflow-spec.md](docs/saga2-transfer-workflow-spec.md)
- **資料庫完整說明文件** (`reconciliation.db` 結構、24 張表、Flyway 演進、4 條 Saga 範例路徑)：[docs/DB-SPEC.md](docs/DB-SPEC.md)
- **transfer-app 生命週期深度剖析** (從 mvn package 到 JVM 退出，含 Build-time/Bootstrap/Runtime/Shutdown 四大階段與 32 個細部章節)：[docs/TRANSFER-APP-LIFECYCLE-ANALYSIS.md](docs/TRANSFER-APP-LIFECYCLE-ANALYSIS.md)
- **Maven & Quarkus 知識庫** (Maven 3.9+ Reactor / BOM / Profile + Quarkus 3.27.2 Extension / CDI / Config / REST)：[docs/MAVEN-QUARKUS-REFERENCE.md](docs/MAVEN-QUARKUS-REFERENCE.md)
