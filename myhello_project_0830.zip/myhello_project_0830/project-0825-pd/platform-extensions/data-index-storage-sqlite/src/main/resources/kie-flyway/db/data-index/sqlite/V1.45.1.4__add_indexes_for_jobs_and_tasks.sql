/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

-- V1.45.1.4__add_indexes_for_jobs_and_tasks.sql (SQLite port)
-- SQLite has no USING btree clause; btree is the default.

CREATE INDEX IF NOT EXISTS idx_jobs_piid  ON jobs(process_instance_id);
CREATE INDEX IF NOT EXISTS idx_tasks_piid ON tasks(process_instance_id);
