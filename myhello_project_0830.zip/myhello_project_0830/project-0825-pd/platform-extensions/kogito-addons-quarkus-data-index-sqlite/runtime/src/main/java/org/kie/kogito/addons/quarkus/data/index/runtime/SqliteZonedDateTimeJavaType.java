/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
package org.kie.kogito.addons.quarkus.data.index.runtime;

import java.time.Instant;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

import org.hibernate.type.descriptor.java.ZonedDateTimeJavaType;

/**
 * Custom Hibernate 6 {@link org.hibernate.type.descriptor.java.JavaType} for
 * {@link ZonedDateTime} that tolerates Kogito Data Index's SQLite storage
 * format.
 *
 * <p>
 * Kogito's SQLite persistence layer writes {@code ZonedDateTime} values to
 * TEXT columns as a Unix epoch-millisecond decimal string (for example
 * {@code "1786185258763"}). The default Hibernate
 * {@link ZonedDateTimeJavaType} only understands ISO-8601 strings, so reading
 * such columns throws {@code DateTimeParseException: Error parsing time stamp}
 * (Kogito issue #9, GraphQL {@code ProcessInstances} query bug).
 *
 * <p>
 * This class extends the default descriptor and overrides the wrap/unwrap
 * logic so that, when Hibernate asks us to convert a raw string value coming
 * from JDBC into a {@link ZonedDateTime}, we first try parsing it as an epoch
 * milliseconds number and only fall back to {@link ZonedDateTime#parse} for
 * ISO-8601 strings.
 *
 * <p>
 * The companion {@code SqliteZonedDateTimeJdbcType} (in
 * {@code platform-data-index}) takes care of the JDBC-bound side (binding /
 * extraction from {@code ResultSet}); this class takes care of the Java-side
 * conversion that Hibernate performs once the JDBC layer hands back the raw
 * String.
 *
 * <p>
 * Registered by {@code KogitoSQLiteDialect#contributeTypes} alongside the
 * JDBC type.
 */
public class SqliteZonedDateTimeJavaType extends ZonedDateTimeJavaType {

    public static final SqliteZonedDateTimeJavaType INSTANCE = new SqliteZonedDateTimeJavaType();

    public SqliteZonedDateTimeJavaType() {
        super();
    }

    @Override
    public Class<ZonedDateTime> getJavaTypeClass() {
        return ZonedDateTime.class;
    }

    @Override
    public <X> X unwrap(ZonedDateTime value, Class<X> type, org.hibernate.type.descriptor.WrapperOptions options) {
        if (value == null) {
            return null;
        }
        if (type == ZonedDateTime.class) {
            return (X) value;
        }
        if (type == String.class) {
            // Kogito SQLite stores ZonedDateTime as epoch-ms decimal string
            return (X) Long.toString(value.toInstant().toEpochMilli());
        }
        if (type == java.time.Instant.class) {
            return (X) value.toInstant();
        }
        return super.unwrap(value, type, options);
    }

    @Override
    public <X> ZonedDateTime wrap(X value, org.hibernate.type.descriptor.WrapperOptions options) {
        if (value == null) {
            return null;
        }
        if (value instanceof ZonedDateTime) {
            return (ZonedDateTime) value;
        }
        if (value instanceof Instant) {
            return ((Instant) value).atZone(ZoneId.systemDefault());
        }
        if (value instanceof java.time.OffsetDateTime) {
            return ((java.time.OffsetDateTime) value).toZonedDateTime();
        }
        if (value instanceof java.time.LocalDateTime) {
            return ((java.time.LocalDateTime) value).atZone(ZoneId.systemDefault());
        }
        if (value instanceof String) {
            return parse((String) value);
        }
        if (value instanceof Number) {
            long epochMs = ((Number) value).longValue();
            return Instant.ofEpochMilli(epochMs).atZone(ZoneId.systemDefault());
        }
        // Last resort: ask the default JavaType.
        return super.wrap(value, options);
    }

    /**
     * Parse a Kogito SQLite-stored ZonedDateTime string.
     * <ol>
     * <li>First try Unix epoch milliseconds ({@code "1786185258763"}).</li>
     * <li>Otherwise fall back to ISO-8601 ({@link ZonedDateTime#parse}).</li>
     * <li>Otherwise try {@link DateTimeFormatter#ISO_ZONED_DATE_TIME} as a
     * final defensive fallback.</li>
     * </ol>
     * Returns {@code null} instead of throwing when nothing matches, so a
     * bad row won't take down the whole GraphQL ProcessInstances query.
     */
    static ZonedDateTime parse(String raw) {
        if (raw == null) {
            return null;
        }
        String s = raw.trim();
        if (s.isEmpty()) {
            return null;
        }
        // 1. Epoch milliseconds (Kogito SQLite format)
        try {
            long epochMs = Long.parseLong(s);
            return Instant.ofEpochMilli(epochMs).atZone(ZoneId.systemDefault());
        } catch (NumberFormatException ignore) {
            // not numeric, fall through
        }
        // 2. ISO-8601 (default Hibernate expectation)
        try {
            return ZonedDateTime.parse(s);
        } catch (RuntimeException ignore) {
            // not ISO-8601 either, fall through
        }
        // 3. Defensive: ISO_ZONED_DATE_TIME via formatter
        try {
            return ZonedDateTime.parse(s, DateTimeFormatter.ISO_ZONED_DATE_TIME);
        } catch (RuntimeException ignore) {
            // give up
        }
        return null;
    }

    // Quiet unused-import warning for Locale (kept for future locale-aware parsing).
    @SuppressWarnings("unused")
    private static final Locale ROOT = Locale.ROOT;
}
