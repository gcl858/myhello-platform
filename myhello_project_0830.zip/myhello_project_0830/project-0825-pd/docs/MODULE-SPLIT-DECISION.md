# myhello-sonataflow → myhello-platform 模組切分決策紀錄

> 版本: 1.1  
> 日期: 2026-08-17 (v1.0) / 2026-08-24 (v1.1 修訂)  
> 套用範圍: `myhello-sonataflow 1.0.0-SNAPSHOT` (單一模組) → `myhello-platform 1.0.0-SNAPSHOT` (13 模組)  
> 決策者: DevOps + 後端架構  
> 關聯文件: `myhello-sonataflow/docs/PROJECT_SETUP_GUIDE.md`、`myhello-sonataflow/SQLITE_DATA_INDEX_INSTALL.md`
>
> **v1.1 修訂 (2026-08-24)**:原 `transfer-api` 模組拆解 — OpenAPI 規格
> (`specs/A16220-api.yaml`、`A16229-api.yaml`) 移入 `transfer-workflow/src/main/resources/specs`
> (合約與其唯一執行期消費者 `MyOpenApiService` 同模組,自包含);JAX-RS mock
> (`A16229Resource`/`A16220Resource` + DTO) 獨立為頂層 `mocks/transfer-mock` 模組
> (外部系統模擬器不屬於業務域,生產部署可移除)。`transfer-api` 模組刪除。

---

## 1. 背景 (Context)

`myhello-sonataflow` 自 2025-07 啟動,目標是建立一個以 Quarkus 3.27.2 + SonataFlow 10.2.0
為基礎,展示 Saga 模式兩階段交易流程的示範專案。經過 ~12 週迭代,專案從最初 1 個 workflow
擴張到 5 個 workflow、3 個 JAX-RS Resource、4 個 Java Service、3 個 OpenAPI 規格,
所有程式碼集中在單一 Maven 模組內,於 `src/main/java/com/example/` 與
`src/main/java/org/acme/` 兩個 package。

### 1.1 觸發重構的具體痛點

| # | 痛點 | 影響 |
|---|------|------|
| 1 | 交易 (`saga2-transfer-workflow`) 與對帳 (`ReconciliationResource`) 寫同一個 `application.properties`,改對帳 log 設定會意外重啟交易 Pod | 變更風險 |
| 2 | `KogitoSQLiteDialect` 在 `org.acme` package,被所有模組隱式依賴,但實際只有 Data Index 用到 | 耦合洩漏 |
| 3 | `OpenApiFilter` / `SonataFlowSecurityConfig` 應該是平台級橫切關注,目前與業務 workflow 混在同一個 `target/quarkus-app/lib/` | 無法跨專案重用 |
| 4 | Saga 失敗補償邏輯要改時,`mvn package` 必須重新 build 整個依賴鏈 (含 200+ jar) | CI 5 分鐘變 12 分鐘 |
| 5 | 對帳批次 (預期未來) 想要用 `quarkus-scheduler` 跑背景任務,但目前沒有 slot | 架構阻礙 |
| 6 | 測試混雜: `ReconciliationCsvTest` 跟 `Saga2TransferWorkflowTest` 都用 `@QuarkusTest`,但前者其實是純 CSV 邏輯驗證,後者需完整 workflow runtime | 測試反饋慢 |
| 7 | KIE 10.2.0 升級時,業務 workflow 程式被迫跟著 rebuild 整條基礎設施依賴鏈 | 升級摩擦 |

### 1.2 期望產出

- 模組邊界與業務 bounded context 對齊
- 各模組可獨立 build / test / 部署
- 平台層程式碼可被未來新業務域直接複用,不必 copy-paste
- 對帳與交易可在不同 Pod 跑,SLA 分離
- 重構後的單元測試可在不啟動 Quarkus runtime 下執行

---

## 2. 決策框架 (Decision Framework)

採用 **「業務變動軸」優先** 原則,而非「技術分層」優先。

### 2.1 切分軸優先序

| 優先序 | 切分軸 | 理由 |
|--------|--------|------|
| 1 | **業務 bounded context** | 變更節奏、owner、SLA 不同的業務不該共用 release train |
| 2 | **變動頻率** | 基礎設施程式 (dialect, filter) 不該跟業務 workflow 同步 rebase |
| 3 | **技術橫切 vs 業務核心** | OpenAPI filter / health check / security 屬橫切,可抽 platform |
| 4 | **可獨立 deploy** | 若兩個元件要 deploy 在不同 Pod,必須分屬不同 distribution 模組 |

### 2.2 反模式 (刻意避免)

- ❌ 「全部 workflow 放一起、全部 service 放一起、全部 spec 放一起」 — 技術分層
- ❌ 「全部 Java 程式放 `common` lib」 — 過度抽象,造成循環依賴風險
- ❌ 「一個 Quarkus runner 跑全部業務」 — 故障爆炸半徑過大
- ❌ 「共用一個 `application.properties` 檔」 — 配置變更無法分業務交付

### 2.3 模組分類

```
┌─────────────────────────────────────────────────────────────┐
│  platform-*        純基礎設施,可橫向重用,framework 依賴隔離  │
├─────────────────────────────────────────────────────────────┤
│  domain-*         業務 bounded context,各自有合約與實作     │
├─────────────────────────────────────────────────────────────┤
│  distribution/*   可執行 Quarkus 應用,組裝 platform + domain│
└─────────────────────────────────────────────────────────────┘
```

---

## 3. 模組清單 (Module Roster)

| # | 模組 | GroupId | 打包 | 角色 |
|---|------|---------|------|------|
| 1 | `myhello-platform` | `org.acme.platform` | pom | parent,版本管理、reactor |
| 2 | `platform-common` | `org.acme.platform` | jar | 純 Java 共用工具 |
| 3 | `platform-security` | `org.acme.platform` | jar | OpenAPI filter、安全設定、Response 解包 |
| 4 | `platform-data-index` | `org.acme.platform` | jar | Kogito SQLite dialect、Flyway、health check |
| 5 | `domain-transfer` (parent) | `org.acme.platform` | pom | transfer 域父模組 |
| 6 | `transfer-workflow` | `org.acme.platform` | jar | saga-transfer-workflow + saga2-transfer-workflow + 專屬 service + OpenAPI 規格 (specs/) |
| 7 | `transfer-samples` | `org.acme.platform` | jar | 3 個示範 workflow (OpenAPI / java / rest) |
| 8 | `domain-reconciliation` (parent) | `org.acme.platform` | pom | reconciliation 域父模組 |
| 9 | `reconciliation-api` | `org.acme.platform` | jar | ReconciliationResource + CsvExporter + AuditLogService |
| 10 | `distribution` (parent) | `org.acme.platform` | pom | distribution 層父模組 |
| 11 | `transfer-app` | `org.acme.platform` | jar (quarkus) | 交易業務之 Quarkus runner |
| 12 | `reconciliation-app` | `org.acme.platform` | jar (quarkus) | 對帳業務之 Quarkus runner |
| 13 | `transfer-mock` (`mocks/`) | `org.acme.platform` | jar | A16229/A16220 外部系統模擬器 Resource + DTO (v1.1 自原 transfer-api 獨立;僅本機/UAT 測試) |

> v1.0 原有 13 模組含 `transfer-api`;v1.1 將其拆解為上述第 6 項 (specs 併入 workflow)
> 與第 13 項 (mock 獨立),總數維持 13。

---

## 4. 檔案 → 模組映射 (File-to-Module Map)

### 4.1 Java 程式

| 來源檔案 | 新模組 | 新套件 |
|----------|--------|--------|
| `com/example/SonataFlowSecurityConfig.java` | `platform-security` | `com.example.platform.security` |
| `com/example/OpenApiFilter.java` | `platform-security` | `com.example.platform.security` |
| `com/example/UnwrapResponseFilter.java` | `platform-security` | `com.example.platform.security` |
| `org/acme/KogitoSQLiteDialect.java` | `platform-data-index` | `org.acme.platform.dataindex` |
| `org/acme/MyLivenessCheck.java` | `platform-data-index` | `org.acme.platform.dataindex` |
| `org/acme/SqliteZonedDateTimeJdbcType.java` | `platform-data-index` | `org.acme.platform.dataindex` |
| `org/acme/api/A16220Resource.java` | `transfer-mock` (`mocks/`) | `org.acme.transfer.api` |
| `org/acme/api/A16229Resource.java` | `transfer-mock` (`mocks/`) | `org.acme.transfer.api` |
| `org/acme/dto/A16220Request.java` | `transfer-mock` (`mocks/`) | `org.acme.transfer.api.dto` |
| `org/acme/dto/A16220Response.java` | `transfer-mock` (`mocks/`) | `org.acme.transfer.api.dto` |
| `org/acme/dto/A16229Request.java` | `transfer-mock` (`mocks/`) | `org.acme.transfer.api.dto` |
| `org/acme/dto/A16229Response.java` | `transfer-mock` (`mocks/`) | `org.acme.transfer.api.dto` |
| `com/example/MyOpenApiService.java` | `transfer-workflow` | `com.example.transfer.workflow` |
| `com/example/SagaApiService.java` | `transfer-workflow` | `com.example.transfer.workflow` |
| `com/example/ApiService.java` | `transfer-samples` | `com.example.platform.transfer.samples` |
| `com/example/AuditLogService.java` | `reconciliation-api` | `com.example.reconciliation` |
| `com/example/ReconciliationCsvExporter.java` | `reconciliation-api` | `com.example.reconciliation` |
| `org/acme/api/ReconciliationResource.java` | `reconciliation-api` | `com.example.reconciliation` |

### 4.2 資源檔

| 來源檔案 | 新模組 |
|----------|--------|
| `src/main/resources/saga-transfer-workflow.sw.yaml` | `transfer-workflow` |
| `src/main/resources/saga2-transfer-workflow.sw.yaml` | `transfer-workflow` |
| `src/main/resources/schemas/*.json` | `transfer-workflow` |
| `src/main/resources/OpenAPI-workflow.sw.yaml` | `transfer-samples` |
| `src/main/resources/java-workflow.sw.yaml` | `transfer-samples` |
| `src/main/resources/rest-workflow.sw.yaml` | `transfer-samples` |
| `src/main/resources/specs/A16229-api.yaml` | `transfer-workflow` (v1.1 自 transfer-api 移入) |
| `src/main/resources/specs/A16220-api.yaml` | `transfer-workflow` (v1.1 自 transfer-api 移入) |
| `src/main/resources/specs/openapi.yaml` | `transfer-samples` |
| `src/main/resources/META-INF/resources/*.html` | `distribution/transfer-app` |
| `src/main/resources/application.properties` | **拆三份** (見 4.3) |

### 4.3 `application.properties` 拆分

| 拆分後檔案 | 內容重點 |
|-----------|---------|
| `platform-data-index/src/main/resources/application.properties` | Datasource、Hibernate dialect、Flyway、OIDC 全關、Data Index GraphQL 設定 — 任何 distribution 組裝 platform-data-index 後自動繼承 |
| `distribution/transfer-app/src/main/resources/application.properties` | HTTP port 8080、Kogito/SonataFlow function 設定、TLS/proxy、`%test.*` profile 設定 |
| `distribution/reconciliation-app/src/main/resources/application.properties` | HTTP port 8090(避免衝突)、共用 reconciliation.db 之外部路徑、`%test.*` profile 設定,且改為 `quarkus.datasource.jdbc.read-only=true` |

### 4.4 測試

| 來源檔案 | 新位置 | 理由 |
|----------|--------|------|
| `DataIndexGraphQLTest.java` | `distribution/transfer-app/src/test/java` | `@QuarkusTest` 需完整 transfer-app runtime |
| `Saga2TransferWorkflowTest.java` | `distribution/transfer-app/src/test/java` | `@QuarkusTest` 需完整 workflow runtime |
| `ReconciliationCsvTest.java` | `distribution/transfer-app/src/test/java` | `@QuarkusTest` 同時跑 saga2 + 對帳 export,需 transfer-app |

> 註: `reconciliation-app` 上線後若要新增 `@QuarkusTest` 級別測試 (例如對帳排程整合測試),再行新增。本期暫不產出。

---

## 5. 模組依賴圖 (Module Dependency Graph)

```
                 ┌─────────────────────┐
                 │  platform-common    │  ← 無 framework 依賴
                 └──────────┬──────────┘
                            │
        ┌───────────────────┴───────────────────┐
        ▼                                       ▼
┌────────────────┐                  ┌────────────────────┐
│ platform-      │                  │ transfer-workflow  │
│ security       │                  │ (內含 OpenAPI specs│
│                │                  │  合約,自包含)      │
└────────────────┘                  └─────────┬──────────┘
                                              │ (跨域合約依賴,
                                              │  僅用 AuditLogService)
                                              ▼
                                    ┌──────────────────────┐
                                    │ reconciliation-api   │
                                    └──────────────────────┘

┌────────────────┐   ┌────────────────────────┐
│ transfer-samples│  │ transfer-mock (mocks/) │
│ (無內部依賴)    │   │ 外部系統模擬器,leaf,  │
└────────────────┘   │ 僅本機/UAT 測試用      │
                     └────────────────────────┘
┌──────────────────┐  ┌──────────────────────┐
│  transfer-app   │  │ reconciliation-app   │
│ (組裝 workflow + │  └──────────────────────┘
│  mock + samples) │
└──────────────────┘
```

### 5.1 不變式 (Invariants)

1. **`domain-*` 永遠不依賴 `distribution-*`** (反向耦合會讓 distribution 設定散落各處)
2. **`domain-transfer` 與 `domain-reconciliation` 互不依賴** (避免 bounded context 耦合)
3. **業務模組僅透過合約互調** — transfer 域之 OpenAPI 合約 (`specs/*.yaml`) 位於
   `transfer-workflow` 自身 resources (v1.1),跨域僅依賴 `reconciliation-api` 的
   `AuditLogService` 介面,不直接 import 實作類別
4. **`platform-*` 不依賴任何 `domain-*`** (platform 必須可被任何未來 domain 重用)
5. **`mocks/*` 不被任何 `domain-*` / `platform-*` 依賴** (v1.1) — mock 是測試替身,
   只有 distribution 在組裝測試/本機環境時引入;生產部署可整組移除

### 5.2 例外處理

- `transfer-workflow` 例外依賴 `reconciliation-api` 中的 `AuditLogService`,因為
  `saga2-transfer-workflow` 每次交易完成時需要寫入 audit log。
  此為已知的「跨域服務依賴」,介面契約 (AuditLogService.saveLog) 定義在 reconciliation-api
  中,未來若 AuditLog 改為訊息匯流排,僅需替換實作,不影響 transfer-workflow。

---

## 6. 套件重新命名 (Package Renaming)

| 舊套件 | 新套件 | 理由 |
|--------|--------|------|
| `com.example` | (拆分) | 太過一般,沒標示所屬層 |
| `com.example.OpenApiFilter` 等 5 個 | `com.example.platform.security` | 標示為平台層 |
| `org.acme` (dialect / jdbc / health) | `org.acme.platform.dataindex` | 同上 |
| `org.acme.api` (Resource) | `org.acme.transfer.api` / `com.example.reconciliation` | 標示所屬業務域 |
| `org.acme.dto` | `org.acme.transfer.api.dto` | 標示所屬 API |
| `com.example.MyOpenApiService` 等 | `com.example.transfer.workflow` | 標示 workflow 內部 service |

所有 workflow YAML 中的 `service:` reference 同步更新,例如:

```yaml
# 舊
operation: 'service:com.example.SagaApiService::callA16229'
# 新
operation: 'service:com.example.transfer.workflow.SagaApiService::callA16229'
```

---

## 7. 部署策略

### 7.1 雙 distribution 模型

| Distribution | 預設 port | Pod 數量 | 寫 reconciliation.db? | 用途 |
|--------------|----------|---------|----------------------|------|
| `transfer-app` | 8080 | ≥ 3 | 是 (含 workflow) | 線上交易 |
| `reconciliation-app` | 8090 | 1~2 | 是 (audit log + 對帳查詢) | 對帳查詢/匯出 |

### 7.2 K8s namespace 配置

```
prod-transfer/                ← transfer-app Deployment
  ├── Deployment: transfer-app (replica: 3, PDB: minAvailable=2)
  ├── Service: transfer-app
  └── ConfigMap: transfer-app-config (jdbc.url → shared volume)

prod-reconciliation/          ← reconciliation-app Deployment
  ├── Deployment: reconciliation-app (replica: 1, PDB: minAvailable=1)
  ├── CronJob: reconciliation-daily-archive (未來, 從 reconciliation-app 觸發)
  ├── Service: reconciliation-app
  └── ConfigMap: reconciliation-app-config (同 jdbc.url)

prod-shared/                  ← Data Index / Jobs Service (共用)
  ├── Deployment: shared-data-index (未來, 目前 SQLite 不需要獨立進程)
  └── PVC: reconciliation-db (readwritemany 或 NFS)
```

### 7.3 SQLite 共享注意

兩個 distribution 必須指向同一個 `reconciliation.db` 檔案。WAL 模式下
可承受多 reader + 1 writer,適合交易 + 對帳分離部署。

**風險**: 若改用 PostgreSQL,則兩 distribution 應各自連線,不再共享檔案。

---

## 8. 風險與緩解 (Risks & Mitigations)

| 風險 | 機率 | 影響 | 緩解 |
|------|------|------|------|
| 重構後某個 workflow 啟動失敗 | 中 | 高 | 在 staging 完整跑 5 個 workflow smoke test;若失敗可一鍵 revert 單一模組 |
| 修補的 Kogito SQLite 模組本地安裝未完成導致 compile 卡住 | 高 | 中 | 在 README 明確標示 `INSTALL_SQLITE_MODULES.sh` 為必跑步驟;CI 將該步寫進 pre-build |
| `transfer-workflow` 跨域依賴 `reconciliation-api` 造成循環依賴疑慮 | 低 | 中 | 已驗證: `reconciliation-api` 不依賴 `transfer-workflow`,DAG 合法 |
| 兩個 distribution 共享 SQLite 檔案造成 lock contention | 中 | 中 | WAL 模式 + 1 writer 限制 (`quarkus.datasource.jdbc.max-size=1`);若未來上規模改用 Postgres |
| 重構後測試覆蓋率下降 | 中 | 中 | 原 3 個 `@QuarkusTest` 全部保留,僅移動位置 |
| 升級 KIE 10.2.0 → 10.3.0 時,`platform-data-index` 與 `transfer-workflow` 都要 rebase | 中 | 低 | 此即重構目的之一 — 把基礎設施程式集中在 `platform-data-index`,升級 diff 集中可審 |

---

## 9. 不在此次重構範圍 (Out of Scope)

- ❌ 將 `ApiService` (java-workflow 範例用) 移到獨立的 demo 模組 — 暫保留在 `transfer-samples`
- ❌ 重構 `ReconciliationCsvTest` 為純 JUnit 5 單元測試 (去掉 `@QuarkusTest`) — 下期再做
- ❌ 為 `reconciliation-app` 新增獨立的整合測試 — 待對帳排程開發時一併產出
- ❌ 將 SQLite 換為 PostgreSQL — 涉及資料遷移,屬獨立計畫
- ❌ 將 OpenAPI addon 換成 Springdoc / 其他 — 與 Kogito 整合度考量,延後
- ❌ K8s Helm chart / GitOps 設定 — 由平台 SRE 團隊另行負責

---

## 10. 替代方案與否決理由 (Alternatives Considered)

### 10.1 「維持單一模組,但用 package 區分」

❌ 否決。  
理由: package 邊界無法在 Maven 層級強制,`application.properties` 仍會混雜,共用
`target/quarkus-app/lib/` 無法分離故障爆炸半徑。`mvn package` 仍需編譯全部原始碼。

### 10.2 「三層分層: api / service / workflow」

❌ 否決。  
理由: 這是技術分層,違反本決策框架的核心原則(以業務變動軸為主)。
同一個 bounded context 內的 service 跟 workflow 變更節奏一致,放一起反而能降低協作成本。

### 10.3 「共用 `app-commons` 模組,所有業務依賴它」

❌ 否決。  
理由: 過早抽象。`platform-common` 應只放確實跨業務共用的工具,目前只放 `package-info`。
若未來真的有 2 個 domain 共用的工具再加入,不要憑想像建立。

### 10.4 「transfer-app 與 reconciliation-app 合併成單一 runner,用 profile 切換」

❌ 否決。  
理由: 故障爆炸半徑未縮減;profile 切換不適合用於部署邊界。
且對帳批次上線後,scheduled task 跟交易服務的生命週期管理邏輯完全不同。

### 10.5 「Kogito Data Index 拆成獨立 service」

⏸ 暫緩。  
理由: 目前用 SQLite 是嵌入式儲存,拆獨立 service 反而增加網路往返。
改用 PostgreSQL / MongoDB 時再評估。

---

## 11. 決策紀錄總結 (Decision Summary)

**核心決策**: 將原本單一 `myhello-sonataflow` 模組,重構為 13 個 Maven 模組,分為
3 層 (platform / domain / distribution),並產出 2 個可獨立部署的 Quarkus 應用
(`transfer-app` 與 `reconciliation-app`)。

**關鍵 trade-off**:

| 取捨 | 選擇 | 理由 |
|------|------|------|
| 模組數量:多 vs 少 | **多** | 業務獨立部署、故障隔離、CI 並行化 |
| 共用度:多 vs 少 | **少** | 避免過早抽象,僅 `platform-common` 目前實質為空殼 |
| 部署單元:單體 vs 微服務 | **微服務 (2 個 runner)** | 對帳與交易 SLA 不同 |
| 套件深度:淺 vs 深 | **中** | 4 層 (`com.example.{platform,transfer,reconciliation}.x.y`) |

**何時回滾此決策**: 若 6 個月內業務域無新增 (仍只有 transfer + reconciliation),
且未來 12 個月內未規劃第二個獨立 distribution,可考慮合併回 5 模組精簡版。
若觀察到第 3 個業務域出現 (例如「通知」或「AML」),則當前 13 模組結構已預留擴充空間。

---

## 12. 附錄 (Appendix)

### A. 完整目錄樹

```
myhello-platform/
├── pom.xml                                            (parent, packaging=pom)
├── README.md
├── docs/
│   ├── MODULE-SPLIT-DECISION.md                       (本檔)
│   └── MODULE-SPLIT-RATIONALE.docx                    (正式 DOCX 交付)
│
├── platform-common/
│   ├── pom.xml
│   └── src/main/java/com/example/platform/common/
│       ├── PlatformPaths.java                         (跨平台路徑工具,管理 MYHELLO_DATA_DIR / MYHELLO_LOGS_DIR)
│       └── package-info.java
│
├── platform-security/
│   ├── pom.xml
│   ├── src/main/java/com/example/platform/security/
│   │   ├── OpenApiFilter.java
│   │   ├── SonataFlowSecurityConfig.java              (含 SwaggerFilter / RuntimeFilter / WorkflowStatusFilter 三個 nested class)
│   │   └── UnwrapResponseFilter.java
│   └── src/main/resources/                            (空)
│
├── platform-data-index/
│   ├── pom.xml
│   ├── src/main/java/org/acme/platform/dataindex/
│   │   ├── KogitoSQLiteDialect.java
│   │   ├── MyLivenessCheck.java
│   │   ├── PlatformConfigSource.java                  (MP ConfigSource SPI, ordinal=250)
│   │   └── SqliteZonedDateTimeJdbcType.java
│   ├── src/main/resources/
│   │   ├── application.properties                     (基礎設定)
│   │   └── META-INF/services/
│   │       └── org.eclipse.microprofile.config.spi.ConfigSource  (註冊 PlatformConfigSource)
│
├── domain-transfer/
│   ├── pom.xml                                        (parent)
│   ├── transfer-workflow/
│   │   ├── pom.xml
│   │   ├── src/main/java/com/example/transfer/workflow/
│   │   │   ├── MyOpenApiService.java
│   │   │   └── SagaApiService.java
│   │   └── src/main/resources/
│   │       ├── saga-transfer-workflow.sw.yaml
│   │       ├── saga2-transfer-workflow.sw.yaml
│   │       ├── schemas/
│   │       │   ├── input-schema.json
│   │       │   └── saga-transfer-input-schema.json
│   │       ├── specs/                                 (v1.1: OpenAPI 合約自 transfer-api 移入,與消費者同模組)
│   │       │   ├── A16220-api.yaml
│   │       │   └── A16229-api.yaml
│   │       └── db/migration/
│   │           └── V1.1.0__create_view_transfer_reconciliation.sql (Saga2 對帳 View)
│   └── transfer-samples/
│       ├── pom.xml
│       ├── src/main/java/com/example/platform/transfer/samples/
│       │   └── ApiService.java
│       └── src/main/resources/
│           ├── OpenAPI-workflow.sw.yaml
│           ├── java-workflow.sw.yaml
│           ├── rest-workflow.sw.yaml
│           └── specs/
│               └── openapi.yaml
│
├── mocks/                                               (v1.1: 外部系統模擬器層)
│   └── transfer-mock/
│       ├── pom.xml
│       └── src/main/java/org/acme/transfer/api/         (package 保留原名,僅模組歸屬變更)
│           ├── A16220Resource.java
│           ├── A16229Resource.java
│           └── dto/
│               ├── A16220Request.java
│               ├── A16220Response.java
│               ├── A16229Request.java
│               └── A16229Response.java
│
├── domain-reconciliation/
│   ├── pom.xml                                        (parent)
│   └── reconciliation-api/
│       ├── pom.xml
│       ├── src/main/java/com/example/reconciliation/
│       │   ├── AuditLogService.java                   (SQLite WAL 寫入 + 委派 MigrationRunner)
│       │   ├── AuditQueryService.java                 (對帳條件查詢 + 檔案清單/內容)
│       │   ├── ReconciliationAuditResource.java       (@Path("/api/reconciliation"))
│       │   ├── ReconciliationCsvExporter.java
│       │   ├── ReconciliationResource.java             (@Path("/reconciliation"))
│       │   └── migration/
│       │       └── DatabaseMigrationRunner.java       (模組化 SQL 遷移執行器)
│       └── src/main/resources/
│           └── db/migration/
│               └── V1.0.0__create_workflow_execution_log.sql (通用稽核主表 + 索引)
│
└── distribution/
    ├── pom.xml                                        (parent)
    ├── transfer-app/
    │   ├── pom.xml
    │   ├── src/main/resources/
    │   │   ├── application.properties                 (transfer-app 專屬,Port 8080)
    │   │   ├── 5 個 .sw.yaml + schemas/ + specs/      (由 maven-resources-plugin 同步自 domain-transfer/*)
    │   │   └── META-INF/resources/
    │   │       ├── dashboard.html
    │   │       ├── index.html
    │   │       └── instances.html
    │   └── src/test/java/com/example/platform/distribution/transfer/
    │       ├── DataIndexGraphQLTest.java
    │       ├── ReconciliationCsvTest.java
    │       └── Saga2TransferWorkflowTest.java
    └── reconciliation-app/
        ├── pom.xml
        ├── src/main/resources/
        │   └── application.properties                 (reconciliation-app 專屬,Port 8090,read-only 模式)
        └── src/test/java/                             (空,本期末產出測試)
```

### B. 驗證結果

| 驗證 | 結果 |
|------|------|
| `mvn -N validate` (僅 parent) | ✅ BUILD SUCCESS |
| `mvn validate` (全 13 模組) | ✅ BUILD SUCCESS (14.5s) |
| `mvn -pl platform-security -am compile` | ✅ 6 .class 產出 |
| `mvn -pl transfer-mock -am compile` | ✅ 6 .class 產出 (v1.1 原 transfer-api) |
| `mvn -pl transfer-samples -am compile` | ✅ 2 .class 產出 |
| `mvn -pl platform-data-index compile` | ⏸ 等待修補 SQLite 模組安裝(預期) |
| `mvn package` (全模組) | ⏸ 等待修補 SQLite 模組安裝(預期) |

> 重構本身未引入語法錯誤;僅剩的紅燈為未安裝的外部修補依賴,這在原專案也是必要前置步驟。


---

# 附錄: v1.2 dev/prod 模組切分

> 版本: 1.2
> 日期: 2026-08-25
> 決策者: Mavis 助理 + 專案 owner
> 觸發動機: 將 dev-only 模組(示範 workflow + 外部系統模擬器)從 prod 鏡像物理隔離,
>          避免 `transfer-samples/ApiService.java` 硬編的 UAT 銀行端點 + client_id
>          隨 prod 鏡像外洩。

## 變更摘要

| 項目 | v1.1 | v1.2 |
|------|------|------|
| `transfer-samples` 位置 | `domain-transfer/transfer-samples/` | **`dev/transfer-samples/`** |
| `transfer-samples` parent | `domain-transfer` | **`dev`** |
| `transfer-mock` 位置 | `mocks/transfer-mock/` (頂層) | **`dev/transfer-mock/`** |
| `transfer-mock` parent | `myhello-platform` (root) | **`dev`** |
| `mocks/` 頂層目錄 | 存在 | **刪除** (空殼) |
| `domain-transfer` 子模組 | transfer-workflow + transfer-samples | **僅 transfer-workflow** |
| 模組總數 | 13 | **14** (新增 `dev` parent) |

## 結構對比

```
v1.1:                                    v1.2:
myhello-platform/                        myhello-platform/
├── platform-*                            ├── platform-*              (相同)
├── domain-transfer/                      ├── domain-transfer/
│   ├── transfer-workflow/                │   └── transfer-workflow/  (prod-only)
│   └── transfer-samples/    ← v1.2 搬走 ├── domain-reconciliation/  (相同)
├── domain-reconciliation/                ├── distribution/           (相同)
├── distribution/                         └── dev/                    ← v1.2 新增
├── mocks/                                │   ├── transfer-samples/   ← 從 domain 搬入
│   └── transfer-mock/       ← v1.2 搬走  │   └── transfer-mock/      ← 從 mocks 搬入
└── ...                                   └── ...
```

## 機制:Maven Profile 切換

```xml
<!-- 根 pom.xml -->
<profiles>
  <profile>
    <id>dev</id>
    <activation><activeByDefault>true</activeByDefault></activation>
    <modules>
      <module>dev</module>     <!-- 唯一控制點 -->
    </modules>
  </profile>
  <profile>
    <id>prod</id>
    <properties>
      <skipTests>true</skipTests>
    </properties>
    <!-- 故意不列 <module>dev</module> 即自動排除 -->
  </profile>
</profiles>
```

`distribution/transfer-app/pom.xml` 同步在 dev profile 內補上兩個依賴
(`transfer-samples` / `transfer-mock`) 與 `sync-samples-resources` execution;
prod profile 為空佔位,用於顯式壓制 child dev profile 的 activeByDefault。

## 對應設定檔:application.properties

dev-only 的 `kogito.sw.functions.callAaaService.*` 與
`kogito.sw.functions.callApiViaOpenAPI.host=localhost:8080`
以及 `quarkus.tls.trust-all=true` 全部加上 `%dev.` 前綴。
prod 模式由 `%prod.kogito.sw.functions.callApiViaOpenAPI.base_url` 觸發,
需於部署時透過環境變數注入真實銀行端點。

## 驗證結果

| 驗證項 | 結果 |
|--------|------|
| `mvn -N help:evaluate -Dexpression=project.modules` (dev 預設) | 8 個模組 + dev parent + transfer-samples + transfer-mock = 共 11 個 |
| `mvn -N help:evaluate -Dexpression=project.modules -P prod` | 7 個模組,**無 dev parent** |
| `mvn validate` (dev) | ✅ BUILD SUCCESS — 21 modules |
| `mvn validate -P prod` | ✅ BUILD SUCCESS — 18 modules |
| `mvn help:effective-pom -pl distribution/transfer-app` (dev) | effective deps 含 `transfer-samples` + `transfer-mock` |
| `mvn help:effective-pom -pl distribution/transfer-app -P prod` | effective deps **不含** `transfer-samples` / `transfer-mock`;`sync-samples-resources` execution 也消失 |
| `mvn package` (完整 build) | ⏸ 受限於沙箱網路 CDN 503,但 reactor 結構 + effective POM 已證明 profile 切換邏輯正確 |

## 替代方案與否決理由

### 12.1 用 Quarkus `%prod.*` runtime 切換排除 mock

❌ 否決。理由: mock 模組的 jar 仍會被打入 classpath,
即使 runtime 不啟動,`transfer-samples/ApiService.java` 內的 UAT 端點 + client_id
仍以 bytecode 形式存在於 prod 鏡像中,屬敏感資訊洩漏。

### 12.2 在 distribution 模組用 `<exclusion>` 排除 jar

❌ 否決。理由: `<exclusion>` 只能排除 transitive 依賴,無法排除自己直接宣告的依賴;
且模組仍會被 reactor 構建,只是不進入 final jar — 浪費 CI 時間。

### 12.3 用 Git branch (dev / main) 隔離

❌ 否決。理由: long-lived branch 分岔會造成合併衝突,
且無法從 commit hash 對應到環境(誰知道 prod 鏡像是從哪個 commit 包的?)。
本專案採「單一 main branch + Maven profile 切換」,由 CI 決定環境。

## 之後可加的硬化措施

- CI 加 `unzip -l` 驗證 prod 鏡像不含 `transfer-samples-*.jar` / `transfer-mock-*.jar`
- K8s image tag selector 只吃 `*-prod` 標籤
- 環境變數範本檔(`.env.prod.example`)集中管理 prod URL
