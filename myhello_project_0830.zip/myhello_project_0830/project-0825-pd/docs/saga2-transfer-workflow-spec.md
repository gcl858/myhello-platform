# Saga2 Transfer Workflow — 規格文件

> 來源:`saga2-transfer-workflow` v2.2.0 (Serverless Workflow spec v0.8)
> 部署目標:SonataFlow 10.2.0 / Quarkus 3.27.2
> 模式:兩階段交易 + Saga LIFO 回沖

---

## 1. 概覽

這是一個用 **Serverless Workflow v0.8** 撰寫的金流交易流程,採用 **Saga 模式**實作補償式回沖:

- **階段 1** 呼叫 `A16229` API(從 `Account_A` 扣款,`EC=false`)
- **階段 2** 呼叫 `A16220` API(對 `Account_B` 入帳,`EC=false`)
- 任一步驟失敗或滿足業務規則(`AMT > 500`)→ 觸發 **LIFO 回沖**(`EC=true` 補償呼叫)
- 最終統一寫入 **AuditLog** 後結束

API 呼叫不直接耦合,改透過通用服務 `MyOpenApiService::callOpenApi` 動態套用 OpenAPI 規格(`specs/A16229-api.yaml`、`specs/A16220-api.yaml`)。

---

## 2. 輸入 / 輸出規格

### 2.1 輸入 (Workflow Input)

| 欄位 | 型別 | 必填 | 驗證規則 | 說明 |
|------|------|------|----------|------|
| `Account_A` | string | ✅ | 符合 `^[A-Za-z0-9_]+$`(非空) | 扣款帳號 |
| `Account_B` | string | ✅ | 符合 `^[A-Za-z0-9_]+$`(非空) | 入帳帳號 |
| `AMT` | number | ✅ | `type == "number"` 且 `> 0` | 交易金額 |

> v2.1.0 起新增規則:`Account_A != Account_B`(同帳號拒絕)、`AMT > 0`(非正數拒絕)。
> 條件皆為 null-safe(欄位缺失/null 一律落入 `VALIDATION_FAILED`,不會拋 jq 例外)。
> 文件化契約見 `schemas/saga-transfer-input-schema.json`(v2.1.0 已與 runtime 規則同步)。

**範例輸入**

```json
{
  "Account_A": "123456",
  "Account_B": "A00001",
  "AMT": 300
}
```

### 2.2 輸出 (Workflow Output)

所有路徑最終都會收斂到 `FinalAuditAndEnd`,透過 `stateDataFilter.output` 統一輸出:

```json
{
  "status": "<finalStatus>",
  "message": "<finalMessage>",
  "AMT": <number>,
  "a16229Result":  { ... } | null,
  "a16220Result":  { ... } | null,
  "a16229Rollback":{ ... } | null,
  "a16220Rollback":{ ... } | null,
  "auditSaved": true | false,
  "opsAlertRaised": true | false
}
```

`a16229Result` / `a16220Result` / `a16229Rollback` / `a16220Rollback` 是 `MyOpenApiService` 回傳的精煉結果:

| 欄位 | 說明 |
|------|------|
| `code` | API 業務代碼(字串);`"100"` 代表成功 |
| `message` | API 業務訊息 |
| `Account` | 該次呼叫的目標帳號 |
| `errorType` | 錯誤分類(見 §3.3.1);服務層成功回應不含此欄位,**經 `actionDataFilter.results` 收錄後,workflow 輸出中成功時呈現為 `null`** |
| `_httpStatus` | HTTP 狀態碼 |

`auditSaved`:對帳紀錄(`workflow_execution_log`)寫入結果。`false` 代表寫入失敗
(細節見 AuditLogService LOG),交易本身仍依 `status` 呈現,不再靜默丟失。

`opsAlertRaised`(v2.2.0):運維告警觸發結果。僅 `status=ROLLBACK_FAILED` 時為 `true`
——由統一終點呼叫 `OpsAlertService` 輸出 **[OPS-ALERT]** ERROR 日誌通道
(含 instanceId/businessKey/回沖明細),供 ELK/Splunk 告警規則接單;其餘狀態一律 `false`。

### 2.3 `status` 與 HTTP 對應

| `finalStatus` | 觸發情境 | HTTP(由 `WorkflowStatusFilter` 改寫) |
|---------------|----------|-------------------------------------|
| `VALIDATION_FAILED` | 輸入欄位格式錯誤 | 400 |
| `FAILED` | 階段 1 失敗(無需回沖)或平台層錯誤兜底 | 200 |
| `SUCCESS` | 兩階段皆成功,`AMT ≤ 500` | 200 |
| `ROLLED_BACK` | Saga 完整 LIFO 回沖成功,或 A16220 失敗僅回沖 A16229 | 200 |
| `ROLLBACK_FAILED` | 回沖本身失敗,需人工介入 | 409 |

> HTTP 改寫由 `WorkflowStatusFilter`(JAX-RS `ContainerResponseFilter`)依 `finalStatus` 完成。
> v2.1.0 修復:該 filter 原本因「路徑含前導斜線 + entity 非 java Map」兩個因素從未生效,
> 現已正規化路徑(去 `/`)並相容 Map/JsonNode/字串三種 entity 型別,**400/409 實測生效**。
> v2.2 平台化:改寫規則已配置化,於 `application.properties` 註冊(新 workflow 免改 Java):
>
> ```properties
> platform.status-rewrite.workflows=saga2-transfer-workflow
> platform.status-rewrite.mapping=VALIDATION_FAILED=400,ROLLBACK_FAILED=409
> ```

---

## 3. 內部處理邏輯

### 3.1 流程圖(State Diagram)

```mermaid
stateDiagram-v2
    [*] --> ValidateInput

    ValidateInput --> InjectValidationFailedStatus: 欄位不符
    ValidateInput --> CallA16229State: 通過驗證

    CallA16229State --> CheckA16229Result
    CheckA16229Result --> CallA16220State: code == "100"
    CheckA16229Result --> InjectFailedStatus: code != "100"

    CallA16220State --> CheckA16220Result
    CheckA16220Result --> DecideByEvaluation: code == "100"
    CheckA16220Result --> RollbackA16229Only: code != "100"

    DecideByEvaluation --> InjectSuccessStatus: AMT <= 500
    DecideByEvaluation --> RollbackA16220: AMT > 500
    DecideByEvaluation --> RollbackA16220: default (安全策略)

    RollbackA16220  --> RollbackA16229: LIFO 第一步
    RollbackA16229  --> CheckRollbackResults

    CheckRollbackResults --> InjectRolledBackStatus: 兩者皆回沖成功
    CheckRollbackResults --> InjectRollbackFailedStatus: 任一回沖失敗

    RollbackA16229Only --> CheckRollbackA16229OnlyResult
    CheckRollbackA16229OnlyResult --> InjectRolledBackOnlyStatus: 成功
    CheckRollbackA16229OnlyResult --> InjectRollbackFailedStatus: 失敗

    InjectValidationFailedStatus --> FinalAuditAndEnd
    InjectSuccessStatus          --> FinalAuditAndEnd
    InjectFailedStatus           --> FinalAuditAndEnd
    InjectRolledBackStatus       --> FinalAuditAndEnd
    InjectRolledBackOnlyStatus   --> FinalAuditAndEnd
    InjectRollbackFailedStatus   --> FinalAuditAndEnd

    FinalAuditAndEnd --> [*]: 寫 AuditLog + 輸出
```

### 3.2 業務規則

| 規則 | 條件 | 結果 |
|------|------|------|
| 帳號格式 | `Account_A` / `Account_B` 須符合 `^[A-Za-z0-9_]+$` | 不符 → `VALIDATION_FAILED` |
| 金額型別 | `AMT` 須為 `number` | 不符 → `VALIDATION_FAILED` |
| 階段 1 成功 | `a16229Result.code == "100"` | 進入階段 2 |
| 階段 2 成功 | `a16220Result.code == "100"` | 進入業務規則判斷 |
| 大額回沖 | `AMT > 500` | 觸發 LIFO 全回沖 |
| 小額成功 | `AMT <= 500` | 直接 `SUCCESS` |
| 安全策略 | `DecideByEvaluation` default | 全回沖(避免雙邊扣款卻無補償) |
| LIFO 順序 | 階段 2 先 → 階段 1 後 | 補償呼叫 `EC=true` |
| 單邊回沖 | A16220 失敗時,僅回沖 A16229 | 階段 2 未扣款,無需補償 |

### 3.3 使用的 Function(自定義服務)

| 名稱 | 綁定 | 用途 |
|------|------|------|
| `callApiViaOpenAPI` | `service:com.example.transfer.workflow.MyOpenApiService::callOpenApi` | 依 OpenAPI spec 動態呼叫 `A16229` / `A16220` |
| `recordAuditLog` | `service:com.example.reconciliation.AuditLogService::saveLog` | 寫入對帳紀錄 |
| `notifyOps`(v2.2.0) | `service:com.example.reconciliation.OpsAlertService::raise` | 條件告警:`ROLLBACK_FAILED` → [OPS-ALERT] 日誌通道 |

呼叫透過 `schemaRef` 指定要套用的 OpenAPI operation:

- `specs/A16229-api.yaml#executeA16229`
- `specs/A16220-api.yaml#executeA16220`

#### 3.3.1 錯誤分類契約 — `errorType`(v2.1.0 新增)

`MyOpenApiService` 對「失敗」回應額外標記 `errorType`,區分**結果未知**與**業務確定失敗**
(成功回應不含此欄位,向後相容):

| `errorType` | 觸發條件 | `_httpStatus` | 語義 |
|-------------|----------|---------------|------|
| `TRANSPORT` | 連線失敗/逾時/規格解析或組態錯誤(呼叫未抵達目標系統) | `0` | 結果未知,補償判斷前應視為不確定 |
| `BUSINESS` | 目標系統明確回覆業務碼失敗(body 自帶 `code != "100"`,如 HTTP 403 + `{code:"999"}`) | 原狀態碼 | 結果確定 |
| `HTTP_4XX` | HTTP 層客戶端錯誤且 body 無業務碼(如 404/405) | 原狀態碼 | 請求語法/路由問題,重試無效 |
| `HTTP_5XX` | HTTP 層伺服端錯誤且 body 無業務碼(如 500/503) | 原狀態碼 | 結果未知 |

> workflow 各 `actionDataFilter.results` 已將 `errorType` 收進 state data(`a16229Result.errorType` 等),
> 供稽核查詢與後續分流;目前 switch 判斷仍以 `code == "100"` 為單一準則(Saga 語義:
> 不論錯誤類型,凡未確認成功即走補償)。v2.2.0 起對 `TRANSPORT` 類失敗已啟用服務層
> 指數退避重試(見 §3.5 傳輸重試列)。

### 3.4 統一終點 — `FinalAuditAndEnd`

所有路徑最終都會進到 `FinalAuditAndEnd`,此 state 會:

1. 呼叫 `recordAuditLog`,寫入結構化對帳紀錄:
   - `workflowId = "saga2-transfer-workflow"`
   - `businessKey = Account_A`
   - `processInstanceId = $WORKFLOW.instanceId`
   - `inputData` 與 `outputData`(含所有步驟結果)
2. 呼叫 `notifyOps`(`OpsAlertService::raise`,v2.2.0):**條件告警**——
   僅 `finalStatus = ROLLBACK_FAILED` 時輸出 `[OPS-ALERT]` ERROR 日誌通道
   (含 instanceId/businessKey/回沖明細)供接單;其餘狀態返回 `raised=false`
3. 透過 `stateDataFilter.output` 統一輸出最終 body(見 §2.2)

> 設計重點:**所有終點共用同一個 output 模板**,前端只需解析一份 schema 即可;
> 對帳落地 (`auditSaved`) 與告警觸發 (`opsAlertRaised`) 皆浮現於輸出,可觀測性完整。

### 3.5 Timeout 與錯誤兜底 (v2.1.0 強化)

**三層防線:**

| 層級 | 設定 | 行為 |
|------|------|------|
| HTTP 連線層 | `MyOpenApiService` 預設 10s(`kogito.sw.openapi.timeout-seconds` 可調) | 回標準化 `{code:"999", errorType:"TRANSPORT", _httpStatus:0}` |
| 傳輸重試 (v2.2.0) | `kogito.sw.openapi.transport-retry.max-attempts`(預設 1=不重試)/ `.delay-ms`(預設 500,因子 2.0);arguments.retryMaxAttempts/retryDelayMs 可單次覆寫(上限 5) | 僅對「未取得 HTTP 回應」的傳輸失敗指數退避重試;已收到回應者(含 4xx/5xx)不重試 |
| State 層 | operation states:`actionExecTimeout: PT15S` / `stateExecTimeout: PT30S`;`FinalAuditAndEnd`:`PT10S`/`PT20S` | 觸發 `platformError`,由該 state 的 `onErrors` 收斂至對應終點 |
| Workflow 層 | `workflowExecTimeout: PT5M` | 最後防線;正常情況下因前幾層存在而不應觸發 |

**onErrors 路由表**(error 定義:`errors.platformError`,Kogito 要求必須含 `code`):

| State | onErrors 轉移 | 理由 |
|-------|---------------|------|
| `ValidateInput` / `CallA16229State` / `CheckA16229Result` | `InjectFailedStatus` | 尚未扣款,無需補償 |
| `CallA16220State` / `CheckA16220Result` | `RollbackA16229Only` | **階段 1 已扣款**,必須補償,不可以 FAILED 收尾 |
| `DecideByEvaluation` | `RollbackA16220` | 安全策略與 default 同向(全回沖) |
| `Rollback*` / `CheckRollback*` | `InjectRollbackFailedStatus` | 補償未完成,標記人工介入 |
| `Inject*Status` / `FinalAuditAndEnd` | 不掛 | inject 不可能失敗;AuditLogService 自行吞例外回 `{saved:false}`(經 `auditSaved` 浮現) |

> v2.1.0 前:任何非預期錯誤會使 instance 直接 error,AuditLog 缺失造成對帳缺口。
> 現在所有平台層錯誤皆收斂至 `FinalAuditAndEnd`,對帳紀錄不遺漏。

---

## 4. 情境範例

> 以下範例以「輸入 → 流程動作 → 輸出」三段式呈現。

### 4.1 ✅ 成功交易(`AMT ≤ 500`)

**輸入**

```json
{ "Account_A": "123456", "Account_B": "A00001", "AMT": 300 }
```

**流程**

1. `ValidateInput` ✅
2. `CallA16229State` → `code: "100"`
3. `CallA16220State` → `code: "100"`
4. `DecideByEvaluation` → `AMT(300) <= 500` → `InjectSuccessStatus`
5. `FinalAuditAndEnd` 寫入 AuditLog

**輸出**

```json
{
  "status": "SUCCESS",
  "message": "交易成功",
  "AMT": 300,
  "a16229Result":  { "code": "100", "message": "扣款成功", "Account": "123456", "_httpStatus": 200 },
  "a16220Result":  { "code": "100", "message": "入帳成功", "Account": "A00001", "_httpStatus": 200 },
  "a16229Rollback": null,
  "a16220Rollback": null
}
```

---

### 4.2 ❌ 輸入驗證失敗

**輸入**(Account_B 含非法字元)

```json
{ "Account_A": "123456", "Account_B": "A@0001", "AMT": 300 }
```

**流程**

1. `ValidateInput` → `accountBInvalid` 條件成立(`match` 失敗)
2. → `InjectValidationFailedStatus`
3. → `FinalAuditAndEnd`

**輸出**(HTTP 400,由 `WorkflowStatusFilter` 改寫)

```json
{
  "status": "VALIDATION_FAILED",
  "message": "輸入欄位格式錯誤 (帳號僅限英數字與底線且兩者不得相同;AMT 須為大於 0 的數字)",
  "AMT": 300,
  "a16229Result":  null,
  "a16220Result":  null,
  "a16229Rollback": null,
  "a16220Rollback": null
}
```

---

### 4.3 ❌ 階段 1 失敗(A16229 扣款失敗,無需回沖)

**輸入**

```json
{ "Account_A": "123456", "Account_B": "A00001", "AMT": 300 }
```

**流程**

1. `ValidateInput` ✅
2. `CallA16229State` → `code: "201"`(餘額不足)
3. `CheckA16229Result` → `InjectFailedStatus`
4. → `FinalAuditAndEnd`

**輸出**

```json
{
  "status": "FAILED",
  "message": "業務失敗或 API 錯誤",
  "AMT": 300,
  "a16229Result":  { "code": "201", "message": "餘額不足", "Account": "123456", "_httpStatus": 200 },
  "a16220Result":  null,
  "a16229Rollback": null,
  "a16220Rollback": null
}
```

> 階段 1 失敗代表尚未動到 `Account_B`,**不觸發任何回沖**。

---

### 4.4 ↩️ 階段 2 失敗(僅回沖 A16229)

**輸入**

```json
{ "Account_A": "123456", "Account_B": "A00001", "AMT": 300 }
```

**流程**

1. `ValidateInput` ✅
2. `CallA16229State` ✅ → 扣款成功
3. `CallA16220State` → `code: "301"`(入帳失敗)
4. `CheckA16220Result` → `RollbackA16229Only`
5. `RollbackA16229Only` → `code: "100"`(回沖成功)
6. `CheckRollbackA16229OnlyResult` → `InjectRolledBackOnlyStatus`
7. → `FinalAuditAndEnd`

**輸出**

```json
{
  "status": "ROLLED_BACK",
  "message": "A16220 業務失敗,僅回沖 A16229",
  "AMT": 300,
  "a16229Result":  { "code": "100", "message": "扣款成功", "Account": "123456", "_httpStatus": 200 },
  "a16220Result":  { "code": "301", "message": "入帳失敗", "Account": "A00001", "_httpStatus": 200 },
  "a16229Rollback":{ "code": "100", "message": "回沖成功", "Account": "123456", "_httpStatus": 200 },
  "a16220Rollback": null
}
```

> 階段 2 失敗時 `Account_B` 未動到,**只需回沖階段 1**,因此走 `RollbackA16229Only` 路徑。

---

### 4.5 🔁 Saga LIFO 全回沖(`AMT > 500`)

**輸入**

```json
{ "Account_A": "123456", "Account_B": "A00001", "AMT": 800 }
```

**流程**

1. `ValidateInput` ✅
2. `CallA16229State` ✅ → 扣款 800
3. `CallA16220State` ✅ → 入帳 800(兩階段皆業務成功)
4. `DecideByEvaluation` → `AMT(800) > 500` → `RollbackA16220`
5. `RollbackA16220` → `code: "100"`(回沖 A00001)
6. `RollbackA16229` → `code: "100"`(回沖 123456)
7. `CheckRollbackResults` → `InjectRolledBackStatus`
8. → `FinalAuditAndEnd`

**輸出**

```json
{
  "status": "ROLLED_BACK",
  "message": "AMT > 500 觸發 saga 回沖 (LIFO)",
  "AMT": 800,
  "a16229Result":  { "code": "100", "message": "扣款成功", "Account": "123456", "_httpStatus": 200 },
  "a16220Result":  { "code": "100", "message": "入帳成功", "Account": "A00001", "_httpStatus": 200 },
  "a16229Rollback":{ "code": "100", "message": "回沖成功", "Account": "123456", "_httpStatus": 200 },
  "a16220Rollback":{ "code": "100", "message": "回沖成功", "Account": "A00001", "_httpStatus": 200 }
}
```

> LIFO 順序:後執行的 A16220 先回沖 → 先執行的 A16229 後回沖,與執行順序相反。

---

### 4.6 ⚠️ 回沖失敗(需人工介入)

**輸入**(延續 §4.5,但 A16220 回沖失敗)

```json
{ "Account_A": "123456", "Account_B": "A00001", "AMT": 800 }
```

**流程**

1–4 同 §4.5
5. `RollbackA16220` → `code: "401"`(回沖失敗)
6. `RollbackA16229` → `code: "100"`(A16229 仍試著回沖,因為 LIFO 不會中斷)
7. `CheckRollbackResults` → `a16220Rollback.code != "100"` → `InjectRollbackFailedStatus`
8. → `FinalAuditAndEnd`

**輸出**

```json
{
  "status": "ROLLBACK_FAILED",
  "message": "⚠️ 回沖失敗,需人工介入處理",
  "AMT": 800,
  "a16229Result":  { "code": "100", "message": "扣款成功", "Account": "123456", "_httpStatus": 200 },
  "a16220Result":  { "code": "100", "message": "入帳成功", "Account": "A00001", "_httpStatus": 200 },
  "a16229Rollback":{ "code": "100", "message": "回沖成功", "Account": "123456", "_httpStatus": 200 },
  "a16220Rollback":{ "code": "401", "message": "回沖失敗", "Account": "A00001", "_httpStatus": 500 }
}
```

> 設計細節:**即使前一步回沖失敗,LIFO 第二步仍會繼續執行**(`transition: RollbackA16229` 為直接轉移,未檢查 `a16220Rollback.code`)。最終狀態交由 `CheckRollbackResults` 統一判定。

---

### 4.7 ⏱️ Timeout / 平台層錯誤(v2.1.0 已補強)

**觸發**:外部 API 持續無回應(HTTP 10s 先超時 → `errorType: TRANSPORT`),或 state 層逾時。

**行為(v2.1.0 起)**:
- HTTP 逾時:`MyOpenApiService` 回 `{code:"999", errorType:"TRANSPORT", _httpStatus:0}`,流程照常走 switch 判斷(未確認成功 → 補償)
- State 層逾時/非預期例外:由 `onErrors` 收斂至對應終點,**仍會進入 `FinalAuditAndEnd` 寫入 AuditLog**
- 僅剩 `workflowExecTimeout PT5M` 為最後防線,正常情況不會觸發

> v2.1.0 前的「timeout 直接終止、AuditLog 缺失」風險已透過三層防線 + onErrors 兜底消除。

---

## 5. 端到端時序圖(以 §4.1 成功情境為例)

```mermaid
sequenceDiagram
    autonumber
    participant C as Client
    participant SW as SonataFlow Runtime
    participant V as ValidateInput
    participant A1 as CallA16229State
    participant API1 as A16229 API
    participant A2 as CallA16220State
    participant API2 as A16220 API
    participant AUD as AuditLogService

    C->>SW: 啟動 workflow (Account_A, Account_B, AMT)
    SW->>V: 進入驗證
    V-->>SW: 通過 → CallA16229State
    SW->>A1: 呼叫 A16229 (EC=false)
    A1->>API1: POST executeA16229
    API1-->>A1: { code: "100", ... }
    A1-->>SW: a16229Result
    SW->>A2: 呼叫 A16220 (EC=false)
    A2->>API2: POST executeA16220
    API2-->>A2: { code: "100", ... }
    A2-->>SW: a16220Result
    SW->>AUD: 寫入 AuditLog (status=SUCCESS, ...)
    AUD-->>SW: OK
    SW-->>C: { status: "SUCCESS", ... }
```

---

## 6. 設計重點與注意事項

| 項目 | 說明 |
|------|------|
| **共用終點** | 所有狀態收斂到 `FinalAuditAndEnd`,統一 output 模板,前端只需解析一份 schema |
| **OpenAPI 動態呼叫** | 不直接耦合 `A16229` / `A16220` SDK,改由 `MyOpenApiService` 套 spec;規格變更只需更新 YAML |
| **LIFO 回沖** | 補償順序與執行相反,避免鎖定時間過長;即使前一步失敗仍繼續,確保盡量回沖 |
| **業務規則觸發點** | `AMT > 500` 在**兩階段皆業務成功後**才檢查,失敗情境走更短路徑 |
| **AuditLog 必填** | 所有路徑都會寫(含 onErrors 兜底);寫入結果經 `auditSaved` 浮現於輸出 |
| **運維告警 (v2.2.0)** | 統一終點條件呼叫 `OpsAlertService`:`ROLLBACK_FAILED` → [OPS-ALERT] 日誌通道接單,結果經 `opsAlertRaised` 浮現 |
| **HTTP 改寫** | `WorkflowStatusFilter` 配置化(`platform.status-rewrite.*`)依 `finalStatus` 改寫 400/409 |
| **dataInputSchema 已停用** | runtime 改由 `ValidateInput` 統一驗證;schema JSON v2.1.0 起與 runtime 規則同步 |
| **錯誤分類** | `errorType` 區分 TRANSPORT/BUSINESS/HTTP_4XX/HTTP_5XX(§3.3.1),為重試策略預留分流點 |
| **傳輸重試 (v2.2.0)** | 僅 TRANSPORT 類失敗指數退避重試(config/arguments 可調),契約不變 |
| **switch 樣板慣例 (v2.2.0)** | 僅列正向條件 + 安全 default,消除冗餘全覆蓋條件 |
| **metadata 標籤 (v2.2.0)** | workflow 層 `domain/pattern/criticality/owner`,利於 Data Index 查詢過濾 |
| **冪等性註記 (v2.2.0)** | 未內建去重;建議呼叫端攜 Idempotency-Key 由入口層去重(見 description) |
| **三層防線** | HTTP 10s (+retry) → state 15s/30s → workflow PT5M;onErrors 兜底確保對帳紀錄不遺漏 |

> 註:§4 各情境範例的輸出 JSON 省略 `auditSaved` / `opsAlertRaised` 欄位
> (runtime 一律附帶:正常路徑為 `true` / `false`,告警僅 ROLLBACK_FAILED 為 `true`)。

---

## 7. 附錄 — State 總覽

| State | Type | 用途 |
|-------|------|------|
| `ValidateInput` | switch | jq 驗證三個輸入欄位 |
| `CallA16229State` | operation | 呼叫 A16229(`EC=false`) |
| `CheckA16229Result` | switch | 檢查階段 1 結果 |
| `CallA16220State` | operation | 呼叫 A16220(`EC=false`) |
| `CheckA16220Result` | switch | 檢查階段 2 結果 |
| `DecideByEvaluation` | switch | 業務規則判斷(`AMT > 500`) |
| `RollbackA16220` | operation | LIFO 第一步回沖 |
| `RollbackA16229` | operation | LIFO 第二步回沖 |
| `RollbackA16229Only` | operation | A16220 失敗時的單邊回沖 |
| `CheckRollbackResults` | switch | 檢查 LIFO 全回沖結果 |
| `CheckRollbackA16229OnlyResult` | switch | 檢查單邊回沖結果 |
| `Inject*Status` | inject | 設定 `finalStatus` / `finalMessage` |
| `FinalAuditAndEnd` | operation | 寫 AuditLog + 統一輸出 + end |
