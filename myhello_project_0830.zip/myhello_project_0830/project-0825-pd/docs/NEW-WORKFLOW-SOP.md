# 新 Workflow 開發 SOP(以 saga2-transfer-workflow 為範本)

> 適用版本:saga2-transfer-workflow v2.2.0 / SonataFlow 10.2.0 / Quarkus 3.27.2
> 範本檔案:`domain-transfer/transfer-workflow/src/main/resources/saga2-transfer-workflow.sw.yaml`
> 目標:任何新增 workflow 依本 SOP 走完,即可獲得與 saga2 相同的可靠性(三層防線、錯誤兜底、
> 對帳不遺漏、統一輸出)與平台整合(HTTP 改寫、審計日誌)。

---

## 0. 開發前確認(單一事實來源)

| 規則 | 說明 |
|------|------|
| **YAML 只寫在 domain 模組** | workflow `.sw.yaml` 一律放 `domain-transfer/<模組>/src/main/resources/`;`distribution/transfer-app/src/main/resources/` 內的同名檔案是**建置產物**(initialize 階段自動同步,已 gitignore)。直接編輯副本會被靜默覆蓋。 |
| **specs 歸 transfer-workflow** | OpenAPI spec 放 `domain-transfer/transfer-workflow/src/main/resources/specs/`,workflow 以 `classpath` 相對路徑引用(如 `specs/A16229-api.yaml#operationId`)。 |
| **schemas 歸 workflow 模組** | 輸入契約 JSON Schema 放對應 workflow 模組的 `schemas/`,且規則必須與 runtime `ValidateInput` 完全同步。 |

## 1. YAML 骨架 checklist

```yaml
id: <workflow-id>                    # kebab-case,同時是 REST 路徑 /saga2-transfer-workflow 的第一段
version: 'x.y.z'                     # semver;description 內附 changelog 區塊
specVersion: '0.8'
name: <顯示名稱>
description: |
  <一句話定位>
  vX.Y.Z 變更:<條列>

start: ValidateInput

# 工作流標籤 — Data Index GraphQL / 營運查詢過濾用 (v2.2 必填)
metadata:
  domain: <業務域>
  pattern: saga-lifo-compensation | simple
  criticality: high | medium | low
  owner: <團隊>

timeouts:
  workflowExecTimeout: PT5M          # 最後防線;正常情況由下層 timeout 先攔截

errors:
  - name: platformError              # ⚠️ Kogito 要求 error 定義必須含 code,否則整條被忽略!
    code: 'PLATFORM_ERROR'
    description: 平台層非預期錯誤 (state timeout / 引擎例外 / 服務未攔截例外)

functions:
  - name: callApiViaOpenAPI          # name 必須等於 arguments.functionName(base-url 快取 key 依賴它)
    operation: 'service:com.example.transfer.workflow.MyOpenApiService::callOpenApi'
    type: custom
  - name: recordAuditLog             # 對帳紀錄為必掛 function
    operation: 'service:com.example.reconciliation.AuditLogService::saveLog'
    type: custom

states:
  # ... 見 §2 state 慣例
```

### 1.1 必守慣例(違反即 review block)

| # | 慣例 | 原因 |
|---|------|------|
| 1 | 所有 operation state 掛 `timeouts.actionExecTimeout`(建議 PT15S,**大於 HTTP 逾時 10s**)+ `stateExecTimeout`(PT30S) | 讓服務層先回標準化錯誤,而非引擎中斷;避免拖到全域 PT5M 造成 AuditLog 缺失 |
| 2 | 所有可失敗 state 掛 `onErrors → errorRef: platformError`,路由到「語義正確」的終點 | 任何非預期錯誤仍收斂至統一終點寫 AuditLog |
| 3 | onErrors 路由語義:扣款前錯誤→FAILED;**扣款後錯誤→補償路徑(不可 FAILED 收尾)**;回沖鏈錯誤→ROLLBACK_FAILED | Saga 語義正確性 |
| 4 | jq 條件 null-safe:`((.Field // "") | match(...) // false) == false` | 缺欄位時不得拲例外繞過驗證(jackson-jq 對 null 做 match 會拋錯) |
| 5 | **jackson-jq 不支援 `test()`**,一律用 `match() // false == false` | 已知相容性限制 |
| 6 | switch 的 dataConditions 與 defaultCondition 二選一即可,勿兩者都寫全覆蓋條件 | 冗餘死碼 |
| 7 | `actionDataFilter.results` 固定收錄 `{code, message, Account(或業務鍵), errorType, _httpStatus}` | errorType 供稽核與未來重試分流 |
| 8 | switch 僅列正向條件 + 安全 default,勿寫全覆蓋條件 (v2.2 樣板慣例) | 冗餘死碼;default 即安全策略 |
| 9 | 統一終點須接 `OpsAlertService::raise` 條件告警,輸出含 `opsAlertRaised` | ROLLBACK_FAILED 自動進 [OPS-ALERT] 接單通道 |
| 8 | 統一終點 `Final*AndEnd`:所有路徑(含 onErrors 兜底)收斂於此;呼叫 recordAuditLog 後以共用 `stateDataFilter.output` 模板輸出,並含 `auditSaved` | 前端單一 schema;對帳不遺漏 |

> **冪等性 (Idempotency) 樣板註記**:workflow 不內建請求去重——重送即產生獨立實例。
> 金融場景:呼叫端 Header 攜帶 `Idempotency-Key`,由 API Gateway / 入口層去重,
> 或業務 API 層對業務鍵建唯一約束(saga2 的 description 已含此註記,新 workflow 請比照)。

### 1.2 統一終點模板(複製即用)

```yaml
  - name: FinalAuditAndEnd
    type: operation
    timeouts:
      actionExecTimeout: PT10S
      stateExecTimeout: PT20S
      # 刻意不掛 onErrors:AuditLogService 自吞例外回 {saved:false},結果經 auditSaved 浮現
    actions:
      - name: saveFinalAuditLog
        functionRef:
          refName: recordAuditLog
          arguments:
            workflowId: "<workflow-id>"
            businessKey: '${ .<業務鍵> }'        # 多筆難辨時考慮 composite key
            processInstanceId: '${ $WORKFLOW.instanceId }'
            inputData: { ... }
            outputData: { status: '${ .finalStatus }', message: '${ .finalMessage }', ... }
        actionDataFilter:
          results: '{saved: .saved}'
          toStateData: '${ .auditResult }'
    stateDataFilter:
      output: |
        {
          status: .finalStatus,
          message: .finalMessage,
          auditSaved: (.auditResult.saved // false),
          ...
        }
    end: true
```

## 2. State 命名規範

| 模式 | 用途 |
|------|------|
| `ValidateInput` | 入口驗證(switch),失敗 → `InjectValidationFailedStatus` |
| `Call<Xxx>State` | operation,呼叫外部 API |
| `Check<Xxx>Result` | switch,`code == "100"` 判斷成敗 |
| `Inject<Xxx>Status` | inject,只設 `finalStatus` + `finalMessage` 兩個欄位 |
| `Rollback<Xxx>` / `Rollback<Xxx>Only` | 補償呼叫(EC=true) |
| `FinalAuditAndEnd` | 統一終點 |

## 3. errorType 分流契約(MyOpenApiService)

| `errorType` | `_httpStatus` | 語義 | 未來重試策略 |
|-------------|---------------|------|--------------|
| (成功,無此欄位) | 200 | — | — |
| `TRANSPORT` | `0` | 呼叫未抵達,結果未知 | 可重試;重試耗盡仍未知 → 保守補償 |
| `BUSINESS` | 原碼 | 伺服端明確拒絕 | 不重試,直接走業務分支 |
| `HTTP_4XX` | 原碼 | 請求問題 | 不重試 |
| `HTTP_5XX` | 原碼 | 伺服端異常 | 謹慎重試 |

> 目前 switch 一律以 `code == "100"` 判斷(Saga 語義:未確認成功即補償);
> errorType 先收進 state data,待需要差異化策略時再啟用。
>
> **傳輸重試 (v2.2)**:MyOpenApiService 內建傳輸層指數退避重試——僅對未取得 HTTP 回應者生效
> (`kogito.sw.openapi.transport-retry.max-attempts/delay-ms` 全域,或 arguments.retryMaxAttempts/retryDelayMs 單次,
> 上限 5 次);已收到回應(含 4xx/5xx)一律不重試,workflow 契約不變。

## 4. 平台註冊清單(新 workflow 上線必做)

| # | 檔案 | 動作 |
|---|------|------|
| 1 | `distribution/transfer-app/src/main/resources/application.properties` | `platform.status-rewrite.workflows` 加入新 workflow id(若需 400/409 改寫);`platform.status-rewrite.mapping` 已是全域映射,通常免動 |
| 2 | 同上 | 外部 API 需 base-url 時加 `kogito.sw.functions.<functionName>.protocol/host/port`(解析順序:function props → spec props → spec servers[0].url) |
| 3 | `distribution/transfer-app/pom.xml` | `quarkus.index-dependency.*` 已含各模組,新 domain 模組需補一條 |
| 4 | 對帳 View | 若需專屬對帳視角,依 `docs/CODE-SPECIFICATION.md` §9.8 SOP 新增 migration SQL(V1.x.y 版號遞增) |
| 5 | mock(開發期) | 依 A16229/A16220Resource 慣例:EC=true 且帳號為哨兵值(如 RBFAIL)強制失敗,供 ROLLBACK_FAILED E2E 測試 |

## 5. 測試 checklist(`distribution/transfer-app/src/test/`)

| 案例 | 斷言 |
|------|------|
| 主成功路徑 + 邊界(如 AMT=500/501) | 200 + status + 各 result.code |
| 業務短路路徑(階段 1 失敗) | 200 FAILED + `errorType=BUSINESS` + 下游未呼叫(nullValue) |
| 補償路徑(LIFO) | 200 ROLLED_BACK + 回沖順序結果 |
| **回沖失敗路徑(哨兵)** | **409** ROLLBACK_FAILED + LIFO 不中斷 + auditSaved=true + opsAlertRaised=true |
| **缺欄位 / 非法字元 / 非正數 / 同鍵** | **400** VALIDATION_FAILED(驗證 WorkflowStatusFilter 生效)+ auditSaved=true + opsAlertRaised=false |
| SUCCESS 不帶 errorType、不觸發告警 | `errorType`/`opsAlertRaised` 為 nullValue 或 false(向後相容) |
| 傳輸重試 (v2.2) | 對不可路由埠探測:maxAttempts=3 應退避 2 次;=1 快速返回;結果仍 code=999/TRANSPORT |
| 對帳落地 | SQLite view / export-csv 含新 workflow_id 紀錄 |

執行:`mvn -pl distribution/transfer-app -am test`

## 6. 文件 checklist

- [ ] 新增/更新 `<workflow>-spec.md`(輸出入契約、狀態圖、情境範例、HTTP 映射)
- [ ] 更新 README 模組說明(若新增模組)
- [ ] 更新 SYSTEM-ARCHITECTURE.md(若新增平台元件)

## 7. 已知地雷速查

| 地雷 | 症狀 | 解法 |
|------|------|------|
| error 定義漏 `code` | codegen:`Cannot find any error definition for errorRef X` | errors 條目補 `code` 欄位 |
| custom function 簽名不符 | codegen:`could not find a method X with proper arguments` | 方法參數型別須與 arguments **精確對應**(jq 產出一律 Object/Map,勿用 String/JsonNode 接) |
| filter 改寫不生效 | VALIDATION_FAILED 回 200 | 確認 workflow id 已登記 `platform.status-rewrite.workflows`(比對的是路徑第一段) |
| jq 對缺失欄位拋例外 | instance 直接 error 而非驗證失敗 | 條件加 `// ""` 收斂 null |
| 改 app 副本沒生效 | 建置後改動消失 | 副本是同步產物,改 domain 模組來源 |
| actionExecTimeout ≤ HTTP 逾時 | 引擎中斷而非拿到標準化錯誤 body | 保持 action > HTTP(timeoutSeconds 可單次調降除外) |
| `quarkus.tls.trust-all=true` 帶上生產 | 中間人攻擊風險 | DEV/UAT-only;生產移除並配置正式 truststore |
| 重試對 4xx/5xx 也生效(誤用) | 對確定失敗做無謂重試 | 重試僅針對 TRANSPORT;業務/HTTP 錯誤由 switch 分流,勿開大 max-attempts 掩蓋問題 |
