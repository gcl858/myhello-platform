# myhello-platform 內建 Web UI 說明文件

> **專案名稱**：`myhello-platform`
> **範圍**：`distribution/reconciliation-app` 內建的 5 個靜態 HTML 頁面（無獨立前端專案；Quarkus 直接服務 `META-INF/resources/`）。
> **基於 API**：`reconciliation-app` 對外開放的 `/api/reconciliation/*` REST 端點。
> **頁面版本**：v1.0（2026-08-20 對應 `flow-trace.html` 大改版後）

---

## 目錄 (Table of Contents)

- [1. 總覽與設計原則](#1-總覽與設計原則)
- [2. 頁面索引](#2-頁面索引)
- [3. 流程節點執行軌跡圖形化頁面 (`flow-trace.html`)](#3-流程節點執行軌跡圖形化頁面-flow-tracehtml)
  - [3.1 頁面結構](#31-頁面結構)
  - [3.2 節點過濾邏輯](#32-節點過濾邏輯)
  - [3.3 狀態配色規則](#33-狀態配色規則)
  - [3.4 點擊展開 INPUTS / OUTPUTS](#34-點擊展開-inputs--outputs)
- [4. 與後端 API 對應關係](#4-與後端-api-對應關係)
- [5. 部署與路由](#5-部署與路由)

---

## 1. 總覽與設計原則

`reconciliation-app` 內建 5 個靜態 HTML 頁面，由 Quarkus 內建的 META-INF/resources 靜態檔案服務機制直接提供，無需另建前端專案、無打包工具、無 CORS 設定：

- 所有頁面皆採深色玻璃擬態風格（`Inter` 字體 + `Fira Code` 程式碼字體），響應式寬度自適應 1400px container。
- 前端與後端同源部署（皆在 `reconciliation-app:8090`），避免跨域請求限制。
- 靜態檔案位於 `domain-reconciliation/reconciliation-api/src/main/resources/META-INF/resources/`，經 Maven 模組依賴由 `reconciliation-app` 在 Quarkus classpath 中讀取。
- 頁面內容透過 `fetch()` 呼叫 REST API 即時刷新，無狀態保存。

## 2. 頁面索引

| 頁面 | 路徑 | 用途 | 主要互動 |
|---|---|---|---|
| `reconciliation.html` | `/reconciliation.html` | 對帳與審計日誌檢視器 | 條件篩選 + 對帳紀錄表格 + CSV 匯出 |
| `flow-trace.html` | `/flow-trace.html` | 流程節點執行軌跡圖形化頁面 | 下拉選單 + 流程圖 + 時間軸（點擊展開 I/O） |
| `specs.html` | `/specs.html` | OpenAPI 規格與服務端點監控頁 | 規格列表 + 端點健康度儀表板 |
| `tester.html` | `/tester.html` | 全工作流沙盒測試與除錯器 | 表單輸入 + 即時觸發工作流 |
| `jobs.html` | `/jobs.html` | Kogito Jobs & Timers 延遲任務管理控制台 | 排程任務清單 + 觸發 / 取消操作 |

所有頁面共用相同的 navbar（`Workflow Node Trace Visualizer` 品牌 + 6 個導航連結），互相可跳轉。

## 3. 流程節點執行軌跡圖形化頁面 (`flow-trace.html`)

頁面標題：**SonataFlow - 流程節點執行軌跡圖形化頁面**

### 3.1 頁面結構

由上至下分為四個區塊：

1. **控制列（Controls Bar）**：
   - `<select id="instSelect">` 下拉式選單（自動載入近期 50 筆實例）。
   - `<input id="manualIdInput">` 手動輸入 / 貼上 Instance ID。
   - 「🔍 讀取軌跡圖」按鈕 → 觸發 `loadTraceForSelected()`。
   - 「⚡ 測試發送 (AMT=888 觸發回沖)」按鈕 → �發 Saga2 流程（金額 888，AMT > 500 觸發 ROLLED_BACK）。
   - 「⚡ 測試發送 (AMT=300 成功)」按鈕 → 觸發 Saga2 流程（金額 300，SUCCESS 路徑）。
2. **實例摘要 Banner**：顯示 `Instance ID`、`Process ID | Start` 與狀態徽章（`🟢 SUCCESS (交易成功)` / `🔴 ROLLED_BACK (LIFO 回沖)`）。
3. **SVG/CSS 實例執行軌跡圖 (Flowchart Trace)**：以 flex-wrap 多行排列的節點 box（每個 box 顯示「節點名稱 + 綠/紅狀態燈」，hover 顯示 tooltip「type + #shortId + duration」）。
4. **節點時間軸明細 (Execution Sequence)**：每張卡片代表一個節點，標題顯示節點名稱、type、shortId、duration、Enter/Exit 時間；有 `inputArgs` / `outputArgs` 的節點可點擊展開 I/O JSON。

### 3.2 節點過濾�輯

為了讓流程圖與時間軸更聚焦於「業務關鍵節點」，前端對後端回傳的 `nodes` 陣列進行以下過濾：

- **過�清單**（位於 `renderFlowchart()` 與 `renderTimeline()` 內的 `SUB_NAMES`）：`EmbeddedStart`、`EmbeddedEnd`、`Script`。
- **理由**：
  - `EmbeddedStart` / `EmbeddedEnd` 是 `CompositeContextNode` 的內部子流程邊界節點（CallA16229State / CallA16220State / FinalAuditAndEnd 內含），與外層 flow 重複。
  - `Script` (ActionNode) 為內部運算節點（資料搬運、變數注入），對業務理解無直接幫助。
- **效果**：原始 26 個節點過濾為 14 個顯示節點，覆蓋完整 Saga2 業務鏈（`Start → ValidateInput → CallA16229State → callApiViaOpenAPI → CheckA16229Result → CallA16220State → callApiViaOpenAPI → CheckA16220Result → DecideByEvaluation → ... → End`）。

### 3.3 狀態配色規則

節點狀態配色由 `getNodeStyle(n)` 函式依據 `window.__traceStatus` 與節點名稱決定：

| 情境 | 節點條件 | boxClass | badge |
|---|---|---|---|
| 預設成功 | （任何節點） | `node-box completed`（綠框） | 🟢 正常執行 |
| ROLLED_BACK + 觸發點 | `trace.status === 'ROLLED_BACK'` 且 `name ∈ {DecideByEvaluation, InjectSuccessStatus}` | `node-box rolled-back`（紅框） | 🔴 觸發回沖 |
| 顯式補償節點 | `name` 含「Rollback」或「沖正」字串 | `node-box rolled-back`（紅框） | 🔴 補償沖正 |
| ROLLED_BACK forward 成功 | 其餘節點（在 ROLLED_BACK trace 中） | `node-box completed`（綠框） | � forward 成功 |

**設計重點**：原本 `CallA16229State` / `CallA16220State` 在 ROLLED_BACK 流程中曾被標紅，但實際上前兩階段 forward API 都回 `code: "100" / message: "成功"`，是 `DecideByEvaluation` 評估後才決定進入 LIFO 回沖。因此 CallA16229State / CallA16220State 應保持綠色（forward 成功），僅紅色標記實際�發回沖的決策節點。

### 3.4 點擊展開 INPUTS / OUTPUTS

節點時間軸卡片支援點擊互動：

- 卡片標頭加 `<span class="timeline-toggle">▸</span>` 箭頭指示。
- 點擊 `.timeline-card.has-io` 切換 `.open` class，CSS `max-height` 動畫展開 `.timeline-detail` 區塊。
- 展開內容包含兩個 `io-block`：
  - 📥 **輸入 INPUTS** — `inputArgs`（JSON，巢狀結構完整呈現）
  - 📤 **輸出 OUTPUTS** — `outputArgs`（JSON）
- 僅當節點具備 `inputArgs` 或 `outputArgs` 欄位時才標記 `has-io` class；無 IO 的節點不響應點擊（避免誤觸）。
- 資料來源：後端 `AuditQueryService.getRealNodesFromDb()` 從 `nodes.input_args` / `nodes.output_args` 反序列化為 Jackson `JsonNode`。
- 目前有 IO 資料的節點類型：`WorkItemNode`（`callApiViaOpenAPI`、`recordAuditLog`）；其他類型（`Split`、`ActionNode`、`CompositeContextNode` 等）的 IO 由 Kogito 引擎未持久化至 `nodes` 表。

**JSON 安全**：展開內容經 `escapeHtml()` helper 處理（`&` / `<` / `>`）避免 XSS。

## 4. 與後端 API 對應關係

`flow-trace.html` 與後端 API 的互動：

| 前端呼叫 | API 端點 | 用途 |
|---|---|---|
| `loadInstances()` | `GET /api/reconciliation/instances` | 載入下拉式選單的實例清單 |
| `loadTraceForSelected()` | `GET /api/reconciliation/trace/{instanceId}` | 載入指定實例完整軌跡 |
| `triggerSaga2(amt)` | `POST /api/reconciliation/trigger-saga2` | 觸發 Saga2 測試流程 |

API 回傳的關鍵欄位對應前端消費：

- `instances[].status`（業務層級）→ 下拉式選單 emoji + 中文標籤
- `trace.status`（業務層級）→ banner 狀態徽章 + 流程圖節點配色
- `trace.nodes[].inputArgs` / `outputArgs` → 時間軸卡片可點擊展開 I/O
- `trace.nodes[].enter` / `exit` → 計算 duration（`exit - exit`，毫秒）

## 5. 部署與路由

- **靜態檔案路徑**：`domain-reconciliation/reconciliation-api/src/main/resources/META-INF/resources/{reconciliation,flow-trace,tester,specs,jobs}.html`
- **Maven 模組依賴**：`distribution/reconciliation-app` 透過 `pom.xml` 宣告依賴 `reconciliation-api`，Quarkus build-time 自動將 `META-INF/resources/*.html` 註冊為靜態路由。
- **啟動服務**：
  ```bash
  cd distribution/reconciliation-app
  QUARKUS_LOG_FILE_ENABLED=false java -jar target/quarkus-app/quarkus-run.jar
  ```
  （`QUARKUS_LOG_FILE_ENABLED=false` 用於規避預設 log rotation suffix 為秒級時的 JBoss LogManager 限制）
- **存取入口**：
  - `http://localhost:8090/reconciliation.html`
  - `http://localhost:8090/flow-trace.html`
  - `http://localhost:8090/tester.html`
  - `http://localhost:8090/specs.html`
  - `http://localhost:8090/jobs.html`
- **Port 衝突排查**：啟動失敗若出現 `Port 8090 seems to be in use`，先用 `ss -tlnp | grep 8090` 找出佔用 PID 並 `kill`，再重啟服務。

---

## 變更紀錄

- **v1.0（2026-08-20）**：
  - `flow-trace.html` 全面改版：
    - 節點 schema 對齊後端（`{ id, name, type, enter, exit, inputArgs, outputArgs, errorMessage }`）。
    - `computeDurationMs()` helper 從 enter/exit 計算毫秒。
    - `stateLabel()` 與 `businessStatusLabel()` 將 SonataFlow state 數字（0-5）與業務 status 字串映射為可讀標籤。
    - 過濾 `EmbeddedStart` / `EmbeddedEnd` / `Script` 三類內部節點，顯示節點數 26 → 14。
    - Flowchart 卡片簡化為「節點名稱 + 狀態燈」，type/duration 改為 hover tooltip。
    - Timeline 卡片加入可點擊展開 INPUTS / OUTPUTS 區塊（含 `escapeHtml` XSS 防護）。
  - 後端 `AuditQueryService.getRecentInstances()` 擴充：從 `variables` JSON 解析 `finalStatus` / `finalMessage`，輸出業務 `status` / `message` 欄位供前端下拉式選單消費。
