# myhello-platform Java 程式碼詳細說明文件

> **專案名稱**：`myhello-platform`  
> **Java 版本**：Java 17 (release) / Java 21 (toolchain) — 詳見 [parent pom.xml](../pom.xml) `<maven.compiler.release>17</maven.compiler.release>`  
> **框架環境**：Quarkus 3.27.2 + Apache Kogito / SonataFlow 10.2.0  
> **文件範圍**：全專案所有正式 Java 原始程式碼（共 37 隻 main + 4 隻 test；包含 platform-extensions 擴充模組，排除測試程式與自動生成程式碼）  
> **相關文件**：[UI-WEBPAGES.md](./UI-WEBPAGES.md)（內建 5 個 HTML 頁面說明）、[SYSTEM-ARCHITECTURE.md](./SYSTEM-ARCHITECTURE.md)、[NEW-WORKFLOW-SOP.md](./NEW-WORKFLOW-SOP.md)（新 workflow 開發 SOP,以 saga2 為範本）

---

## 目錄 (Table of Contents)

- [myhello-platform Java 程式碼詳細說明文件](#myhello-platform-java-程式碼詳細說明文件)
  - [目錄 (Table of Contents)](#目錄-table-of-contents)
  - [1. 程式碼分佈與全景統計](#1-程式碼分佈與全景統計)
  - [2. 平台安全與過濾層 (platform-security)](#2-平台安全與過濾層-platform-security)
    - [2.1 `SonataFlowSecurityConfig.java`](#21-sonataflowsecurityconfigjava)
    - [2.2 `UnwrapResponseFilter.java`](#22-unwrapresponsefilterjava)
    - [2.3 `OpenApiFilter.java`](#23-openapifilterjava)
  - [3. 平台擴展與修補層 (platform-extensions)](#3-平台擴展與修補層-platform-extensions)
    - [3.1 `data-index-storage-sqlite` 模組](#31-data-index-storage-sqlite-模組)
    - [3.2 `kogito-addons-quarkus-data-index-sqlite` 模組](#32-kogito-addons-quarkus-data-index-sqlite-模組)
    - [3.3 `kogito-addons-quarkus-data-index-persistence-sqlite` 模組](#33-kogito-addons-quarkus-data-index-persistence-sqlite-模組)
  - [4. 平台資料索引與持久化層 (platform-data-index)](#4-平台資料索引與持久化層-platform-data-index)
    - [4.1 `KogitoSQLiteDialect.java`](#41-kogitosqlitedialectjava)
    - [4.2 `SqliteZonedDateTimeJdbcType.java`](#42-sqlitezoneddatetimejdbctypejava)
    - [4.3 `MyLivenessCheck.java`](#43-mylivenesscheckjava)
    - [4.4 `PlatformConfigSource.java`](#44-platformconfigsourcejava)
    - [4.5 `NodeTracingProcessEventListener.java`](#45-nodetracingprocesseventlistenerjava)
  - [5. 平台共用工具層 (platform-common)](#5-平台共用工具層-platform-common)
    - [5.1 `PlatformPaths.java`](#51-platformpathsjava)
    - [5.2 `package-info.java`](#52-package-infojava)
  - [6. 轉帳 API 合約與 Mock 服務 (mocks/transfer-mock)](#6-轉帳-api-合約與-mock-服務-mockstransfer-mock)
    - [6.1 `A16229Resource.java`](#61-a16229resourcejava)
    - [6.2 `A16220Resource.java`](#62-a16220resourcejava)
    - [6.3 `A16229Request.java` \& `A16229Response.java`](#63-a16229requestjava--a16229responsejava)
    - [6.4 `A16220Request.java` \& `A16220Response.java`](#64-a16220requestjava--a16220responsejava)
  - [7. 轉帳流程與服務調用層 (domain-transfer / transfer-workflow)](#7-轉帳流程與服務調用層-domain-transfer--transfer-workflow)
    - [7.1 `SagaApiService.java`](#71-sagaapiservicejava)
    - [7.2 `MyOpenApiService.java`](#72-myopenapiservicejava)
  - [8. 範例流程服務層 (domain-transfer / transfer-samples)](#8-範例流程服務層-domain-transfer--transfer-samples)
    - [8.1 `ApiService.java`](#81-apiservicejava)
  - [9. 對帳審計與報表匯出層 (domain-reconciliation / reconciliation-api)](#9-對帳審計與報表匯出層-domain-reconciliation--reconciliation-api)
    - [9.1 `AuditLogService.java`](#91-auditlogservicejava)
    - [9.2 `ReconciliationResource.java`](#92-reconciliationresourcejava)
    - [9.3 `ReconciliationCsvExporter.java`](#93-reconciliationcsvexporterjava)
    - [9.4 `ReconciliationAuditResource.java`](#94-reconciliationauditresourcejava)
    - [9.5 `AuditQueryService.java`](#95-auditqueryservicejava)
    - [9.6 `DatabaseMigrationRunner.java`](#96-databasemigrationrunnerjava)
    - [9.7 模組化資料庫遷移腳本 (`db/migration/*.sql`)](#97-模組化資料庫遷移腳本-dbmigrationsql)
    - [9.8 未來新增業務之對帳 View 擴充指南 (SOP)](#98-未來新增業務之對帳-view-擴充指南-sop)
    - [9.9 `OpsAlertService.java`（v2.2 新增）](#99-opsalertservicejava-v22-新增)
  - [10. 分發應用層代碼生成機制 (distribution/\*)](#10-分發應用層代碼生成機制-distribution)

---

## 1. 程式碼分佈與全景統計

| 模組名稱 | 檔案路徑 | 主要職責 / 類型 |
| :--- | :--- | :--- |
| **`platform-common`** | `.../common/PlatformPaths.java` | 平台無關路徑工具 (`MYHELLO_DATA_DIR` / `MYHELLO_LOGS_DIR` 解析) |
| **`platform-common`** | `.../common/package-info.java` | 套件宣告與 Javadoc |
| **`platform-security`** | `.../security/SonataFlowSecurityConfig.java` | HTTP 方法限制、審計日誌與狀態改寫過濾器 (含 `SwaggerFilter` / `RuntimeFilter` / `WorkflowStatusFilter` 3 個 nested class) |
| **`platform-security`** | `.../security/UnwrapResponseFilter.java` | SonataFlow 工作流輸出解包過濾器 |
| **`platform-security`** | `.../security/OpenApiFilter.java` | OpenAPI 規格動態過濾器 (排除非 POST) |
| **`platform-extensions`** | `.../data-index-storage-sqlite/...` | SQLite 儲存適配器 (`SQLiteStorage`/`SQLiteStorageServiceCapabilities`/`SQLiteJsonPredicateBuilder`/`ContainsSQLFunction`/`CustomFunctionsContributor`) 與 22 個 Flyway SQL 遷移腳本 |
| **`platform-extensions`** | `.../kogito-addons-quarkus-data-index-sqlite/...` | Data Index SQLite Runtime (`SqliteZonedDateTimeJavaType`/`JdbcType`/`UserType`/`IntegrationListener`) 與 Deployment (`SQLiteDataIndexProcessor`/`SqliteZonedDateTimeIntegrationProcessor`/`KogitoAppsPersistenceConfig`) 編譯處理器 |
| **`platform-extensions`** | `.../kogito-addons-quarkus-data-index-persistence-sqlite/...` | 持久化 Runtime 與 Deployment (`SQLiteDataIndexPersistenceProcessor`) 編譯處理器 |
| **`platform-data-index`** | `.../dataindex/KogitoSQLiteDialect.java` | 自訂 Hibernate 6 SQLite 方言 |
| **`platform-data-index`** | `.../dataindex/SqliteZonedDateTimeJdbcType.java` | SQLite ZonedDateTime JDBC 型別轉換處理器 |
| **`platform-data-index`** | `.../dataindex/MyLivenessCheck.java` | SmallRye Health 存活檢查探針 |
| **`platform-data-index`** | `.../dataindex/PlatformConfigSource.java` | MP ConfigSource SPI 實作 (ordinal=250,自動注入 `MYHELLO_DATA_DIR`/`MYHELLO_LOGS_DIR`) |
| **`platform-data-index`** | `.../dataindex/NodeTracingProcessEventListener.java` | 全節點 I/O 軌跡與錯誤訊息監聽器 (注入 `inputArgs`/`outputArgs`/`errorMessage` 至 Data Index) |
| **`transfer-mock`** | `.../transfer/api/A16229Resource.java` | A16229 (扣款/轉出) JAX-RS 服務端點 |
| **`transfer-mock`** | `.../transfer/api/A16220Resource.java` | A16220 (入帳/轉入) JAX-RS 服務端點 |
| **`transfer-mock`** | `.../transfer/api/dto/A16229Request.java` | A16229 請求 DTO |
| **`transfer-mock`** | `.../transfer/api/dto/A16229Response.java` | A16229 回應 DTO |
| **`transfer-mock`** | `.../transfer/api/dto/A16220Request.java` | A16220 請求 DTO |
| **`transfer-mock`** | `.../transfer/api/dto/A16220Response.java` | A16220 回應 DTO |
| **`transfer-workflow`** | `.../transfer/workflow/SagaApiService.java` | 非同步 HTTP Client 封裝 (提供 Saga 呼叫) |
| **`transfer-workflow`** | `.../transfer/workflow/MyOpenApiService.java` | 通用 OpenAPI 動態規格解析與呼叫引擎 (含 4 層快取) |
| **`transfer-samples`** | `.../transfer/samples/ApiService.java` | Java 工作流外部呼叫與健康檢查示範服務 |
| **`reconciliation-api`** | `.../reconciliation/AuditLogService.java` | SQLite WAL 審計日誌非阻塞儲存服務 |
| **`reconciliation-api`** | `.../reconciliation/OpsAlertService.java` | 運維條件告警 (`ROLLBACK_FAILED` → `[OPS-ALERT]` 日誌通道, v2.2) |
| **`reconciliation-api`** | `.../reconciliation/ReconciliationResource.java` | 對帳單 CSV 匯出 JAX-RS REST 端點 (`/reconciliation/export-csv`) |
| **`reconciliation-api`** | `.../reconciliation/ReconciliationAuditResource.java` | 對帳與軌跡查詢 JAX-RS REST 端點 (`/api/reconciliation/*` 含 records, trace, instances, files 等) |
| **`reconciliation-api`** | `.../reconciliation/AuditQueryService.java` | 對帳查詢與節點軌跡服務 (支援節點 inputArgs/outputArgs/errorMessage 解析) |
| **`reconciliation-api`** | `.../reconciliation/ReconciliationCsvExporter.java` | 高效能 UTF-8 BOM 對帳 CSV 串流匯出引擎 |

> **總計**: 37 隻 main 程式 + 4 隻 test 程式 (`distribution/transfer-app/src/test/.../{Saga2TransferWorkflowTest,MyOpenApiServiceRetryTest,ReconciliationCsvTest,DataIndexGraphQLTest}.java`)。

---

## 2. 平台安全與過濾層 (platform-security)

### 2.1 `SonataFlowSecurityConfig.java`
- **檔案路徑**：`platform-security/src/main/java/com/example/platform/security/SonataFlowSecurityConfig.java`
- **套件名稱**：`com.example.platform.security`
- **設計定位**：整合微服務安全策略、HTTP 請求約束、全鏈路審計日誌與業務狀態碼改寫。
- **內部元件結構**：
  1. **`SwaggerFilter`** (實作 `OASFilter`)：
     - **職責**：在產生 OpenAPI / Swagger UI 規格時，主動移除除 POST 以外的所有 HTTP Method（如 GET, PUT, DELETE, PATCH, HEAD），符合金融 API 單一 POST 進入點規範。
  2. **`RuntimeFilter`** (實作 `ContainerRequestFilter`)：
     - **標註**：`@Provider`, `@ApplicationScoped`, `@Priority(Priorities.USER)`
     - **核心邏輯**：
       - 自動放行系統監控路徑（`path.startsWith("q/")`，如 `/q/health`, `/q/swagger-ui`）。
       - 嚴格攔截非 `POST` 請求，直接以 `403 Forbidden`（`{"error": "Only POST method is allowed"}`）中斷請求。
       - 讀取 Request Entity Stream 轉換為字串緩存至 `requestContext.setProperty("rawInputPayload", ...)`，並使用 `ByteArrayInputStream` 重設 Stream 供後續反序列化使用。
       - 記錄請求進來之奈秒時間戳記 `startTimeNano` 供耗時計算。
  3. **`WorkflowStatusFilter`** (實作 `ContainerResponseFilter`)：
     - **標註**：`@Provider`, `@ApplicationScoped`, `@Priority(Priorities.USER - 10)`
     - **執行順序**：JAX-RS response filter 以 priority「降序」執行（數字大者先跑），故本 filter（USER - 10）刻意排在 `UnwrapResponseFilter`（USER）之後，取得解包後的最終 entity，並讓改寫的狀態碼覆蓋 Unwrap 強制設定的 200。
     - **配置化 (v2.2 平台化)**：啟用名單與映射皆由 MicroProfile Config 驅動，`@PostConstruct` 解析並輸出載入日誌：
       - `platform.status-rewrite.workflows`（預設 `saga2-transfer-workflow`）：逗號分隔的 workflow id 名單，比對目標為路徑第一段
       - `platform.status-rewrite.mapping`（預設 `VALIDATION_FAILED=400,ROLLBACK_FAILED=409`）：格式 `STATUS=CODE`,逗號分隔；未列出的 status 保持引擎原狀態碼
     - **路徑正規化**：RESTEasy Reactive 的 `getUriInfo().getPath()` 回傳含前導斜線（如 `/saga2-transfer-workflow`），與 RuntimeFilter 口徑一致去掉斜線後再做前綴比對（否則改寫永遠不會命中）。
     - **核心邏輯**：
       - 僅處理 POST 方法傳出的工作流回應。
       - **Entity 正規化**：回應 entity 可能為 `Map`、Jackson `JsonNode`（實測為 Kogito 的 `ObjectNodeListenerAware`）或 JSON 字串，統一經 `normalizeEntityToMap()` 轉為 Map 後判讀。
       - **狀態碼精準改寫**：若回應為 `saga2-transfer-workflow`，檢查 JSON 內容中的 `status` 欄位：
         - `VALIDATION_FAILED` $\rightarrow$ 改寫為 `HTTP 400 Bad Request`
         - `ROLLBACK_FAILED` $\rightarrow$ 改寫為 `HTTP 409 Conflict`
         - `SUCCESS` / `FAILED` / `ROLLED_BACK` $\rightarrow$ 保持 `HTTP 200 OK`
       - **統一 HTTP 審計輸出**：收集 URI、HTTP Code、耗時 (ms)、原始 Input 與 Output Payload，以標準格式輸出日誌：
         ```log
         [HTTP-AUDIT] URI: ... | HTTP: ... | Cost: ...ms | INPUT: ... | OUTPUT: ...
         ```

---

### 2.2 `UnwrapResponseFilter.java`
- **檔案路徑**：`platform-security/src/main/java/com/example/platform/security/UnwrapResponseFilter.java`
- **套件名稱**：`com.example.platform.security`
- **設計定位**：JAX-RS 回應解包過濾器，隱藏 Kogito 流程實例元數據。
- **標註**：`@Provider`, `@ApplicationScoped`, `@Priority(Priorities.USER)`
- **核心邏輯**：
  - Kogito 原生執行完畢時，產生的 JSON 為 `{"id": "uuid", "workflowdata": { ... }}`。
  - 本過濾器在 HTTP 回應寫入 Socket 前攔截 Response Entity：
    - 若 Entity 為 `Map` 且包含 `workflowdata`，直接將 Entity 替換為該子物件，並設定 HTTP 200。
    - 若 Entity 為 Jackson `JsonNode` 且包含 `workflowdata`，提取該節點並設定 HTTP 200。
    - 對其他 POJO 物件，透過 `@Inject ObjectMapper` 轉為樹狀結構進行判斷與解包。

---

### 2.3 `OpenApiFilter.java`
- **檔案路徑**：`platform-security/src/main/java/com/example/platform/security/OpenApiFilter.java`
- **套件名稱**：`com.example.platform.security`
- **設計定位**：標準 MicroProfile OpenAPI 攔截器。
- **核心方法**：
  - `filterPathItem(PathItem pathItem)`：將 `pathItem` 中的 `setGET(null)`, `setDELETE(null)`, `setPUT(null)`, `setPATCH(null)`, `setHEAD(null)` 清空，使 Swagger UI 僅呈現 POST 端點。

---

## 3. 平台擴展與修補層 (platform-extensions)

### 3.1 `data-index-storage-sqlite` 模組
- **檔案目錄**：`platform-extensions/data-index-storage-sqlite`
- **設計定位**：提供 Apache Kogito Data Index 的 SQLite 儲存適配器，包含底層 SQL 函數、JSON 查詢述詞解析器與全套 Flyway 資料庫結構定義。
- **核心元件**：
  1. `SQLiteStorageServiceCapabilities.java`：宣告 SQLite 儲存引擎能力（支援 JSON Query 等）。
  2. `SQLiteJsonPredicateBuilder.java`：利用 SQLite 內建之 `json_extract()` 函數解析 GraphQL 過濾述詞。
  3. `CustomFunctionsContributor.java` & `ContainsSQLFunction.java`：向 Hibernate 註冊 SQLite 自訂 JSON 包含函數。
  4. **Flyway 遷移腳本**（`V1.32.0` ~ `V1.50.0` 共 22 個 SQL 檔）：自動建立流程定義、節點實例、歷史記錄、CloudEvents 與觸發器結構。

### 3.2 `kogito-addons-quarkus-data-index-sqlite` 模組
- **檔案目錄**：`platform-extensions/kogito-addons-quarkus-data-index-sqlite`
- **設計定位**：Quarkus 擴展模組（包含 `runtime` 與 `deployment`），實現 Data Index 與 Quarkus / DevUI 深度整合。
- **核心元件**：
  1. `SqliteZonedDateTimeUserType.java` / `SqliteZonedDateTimeJavaType.java`：處理 SQLite 執行時期日期轉換。
  2. `SQLiteDataIndexProcessor.java`：Quarkus 編譯期處理器，註冊 Data Index 實體與 capabilities。
  3. `SqliteZonedDateTimeIntegrationProcessor.java`：編譯期 ORM 整合處理器。
  4. `dev-templates/*.html`：Quarkus DevUI 內嵌之流程與 Data Index 視覺化頁面。

### 3.3 `kogito-addons-quarkus-data-index-persistence-sqlite` 模組
- **檔案目錄**：`platform-extensions/kogito-addons-quarkus-data-index-persistence-sqlite`
- **設計定位**：Quarkus 擴展模組（包含 `runtime` 與 `deployment`），將 SQLite JDBC 連線池、Flyway 遷移與 Kogito 流程持久化串聯。
- **核心元件**：
  1. `SQLiteDataIndexPersistenceProcessor.java`：在 Quarkus 應用啟動前自動觸發 Flyway 執行 SQLite Data Index Schema 初始化與升級。

---

## 4. 平台資料索引與持久化層 (platform-data-index)

### 4.1 `KogitoSQLiteDialect.java`
- **檔案路徑**：`platform-data-index/src/main/java/org/acme/platform/dataindex/KogitoSQLiteDialect.java`
- **套件名稱**：`org.acme.platform.dataindex`
- **繼承**：`org.hibernate.community.dialect.SQLiteDialect`
- **設計定位**：解決 Hibernate ORM 6+ 搭配 SQLite 儲存 `ZonedDateTime` 欄位時的型別不相容問題。
- **核心方法**：
  - `contributeTypes(TypeContributions, ServiceRegistry)`：
    - 註冊 `SqliteZonedDateTimeJdbcType.INSTANCE` 與 `SqliteZonedDateTimeJavaType.INSTANCE`。
    - 註冊自訂 BasicType 映射，支援別名 `"zdt"`, `"ZonedDateTime"`, 解決 GraphQL `ProcessInstances` 查詢時間戳記解析失敗的缺陷。

---

### 4.2 `SqliteZonedDateTimeJdbcType.java`
- **檔案路徑**：`platform-data-index/src/main/java/org/acme/platform/dataindex/SqliteZonedDateTimeJdbcType.java`
- **套件名稱**：`org.acme.platform.dataindex`
- **實作介面**：`org.hibernate.type.descriptor.jdbc.JdbcType`
- **設計定位**：自訂 JDBC 型別描述器，處理 SQLite TEXT 欄位與 Java `ZonedDateTime` 之間的雙向轉換。
- **核心邏輯**：
  - **寫入 (Binder)**：將 `ZonedDateTime` 轉為 Unix Epoch 毫秒字串（如 `"1786185258763"`）存入 SQLite TEXT 欄位。
  - **讀取 (Extractor)**：支援雙模式相容解析：
    1. 優先嘗試將字串解析為 `Long`（毫秒），以系統預設時區組裝為 `ZonedDateTime`。
    2. 若失敗，則嘗試以標準 ISO-8601 格式（`ZonedDateTime.parse(str)`）進行解析，防止 `DateTimeParseException` 拋出。

---

### 4.3 `MyLivenessCheck.java`
- **檔案路徑**：`platform-data-index/src/main/java/org/acme/platform/dataindex/MyLivenessCheck.java`
- **套件名稱**：`org.acme.platform.dataindex`
- **實作介面**：`org.eclipse.microprofile.health.HealthCheck`
- **標註**：`@Liveness`
- **核心方法**：
  - `call()`：回傳 `HealthCheckResponse.up("alive")`，供 Kubernetes Liveness Probe 探測 Pod 存活狀態。

### 4.4 `PlatformConfigSource.java`
- **檔案路徑**：`platform-data-index/src/main/java/org/acme/platform/dataindex/PlatformConfigSource.java`
- **套件名稱**：`org.acme.platform.dataindex`
- **實作介面**：`org.eclipse.microprofile.config.spi.ConfigSource`
- **設計定位**：自動為 Quarkus 注入 `MYHELLO_DATA_DIR` 與 `MYHELLO_LOGS_DIR` 兩個關鍵環境變數,確保 DataSource 啟動前已解析完成。
- **優先級 (Ordinal) 設計**：
  - 高於 `application.properties` (100) 的預設 fallback
  - 低於作業系統環境變數 (300) 與 JVM 參數 `-D` (400),保留外部覆寫能力
  - **Ordinal = 250**
- **核心邏輯**：
  - 建構子內呼叫 `PlatformPaths.ensureDataDirectory()` 與 `PlatformPaths.ensureLogsDirectory()`,確保實體資料夾存在
  - 將解析後的絕對路徑寫入 `properties` map,key 分別為 `MYHELLO_DATA_DIR` 與 `MYHELLO_LOGS_DIR`
  - 透過 `META-INF/services/org.eclipse.microprofile.config.spi.ConfigSource` 註冊為 SPI 服務
- **為何需要**：`jdbc:sqlite:${MYHELLO_DATA_DIR:data}/reconciliation.db` 這種 `application.properties` 內的 placeholder 必須在 ConfigSource 解析時知道 `MYHELLO_DATA_DIR` 的值,否則會 fallback 到相對路徑 `data/`,在不同工作目錄下行為不一致。

### 4.5 `NodeTracingProcessEventListener.java`
- **檔案路徑**：`platform-data-index/src/main/java/org/acme/platform/dataindex/NodeTracingProcessEventListener.java`
- **套件名稱**：`org.acme.platform.dataindex`
- **實作/繼承**：`org.kie.kogito.internal.process.event.DefaultKogitoProcessEventListener`
- **標註**：`@ApplicationScoped`, `@io.quarkus.arc.Unremovable`
- **設計定位**：全節點 I/O 軌跡與錯誤訊息自動捕獲器。解決 Kogito 原生 Data Index 僅為 `WorkItemNode` 記錄參數，而遺漏 `StartNode`, `ActionNode`, `Split`, `Join`, `CompositeContextNode`, `EndNode` 等節點的 `input_args`、`output_args` 與 `error_message` 之問題。
- **核心機制與生命週期**：
  1. `beforeNodeTriggered(ProcessNodeTriggeredEvent event)`：
     - 在任何節點觸發執行前攔截，透過 `KogitoProcessInstance.getVariables()` 抓取當前工作流變數快照（優先抓取 `workflowdata` 欄位）。
     - 將深拷貝後的輸入變數以 JSON 格式注入至 `nodeInstance.getMetaData().put("inputArgs", snapshot)`。
  2. `beforeNodeLeft(ProcessNodeLeftEvent event)`：
     - 在節點執行完成即將離開前攔截，捕獲經過該節點計算/轉換後的最新變數快照。
     - 將最新輸出變數以 JSON 格式注入至 `nodeInstance.getMetaData().put("outputArgs", snapshot)`。
  3. `onError(ProcessErrorEvent event)`：
     - 流程或節點發生異常中斷時攔截，提取 `processInstance.getErrorMessage()` 與例外堆疊。
     - 注入至 `nodeInstance.getMetaData().put("errorMessage", errMsg)` 並寫入 `outputArgs` 供 Data Index 錯誤索引。
- **與持久化層協同**：
  - Kogito `UnitOfWork` 在批次提交節點事件時，`ProcessNodeEnteredEventDataEventAdapter` 與 `ProcessNodeLeftEventDataEventAdapter` 自動從 metadata 讀取 `inputArgs` / `outputArgs`，由 `kogito-addons-quarkus-data-index-persistence-sqlite` 寫入 SQLite `nodes.input_args` 與 `nodes.output_args` 欄位。

---

## 5. 平台共用工具層 (platform-common)

### 5.1 `PlatformPaths.java`
- **檔案路徑**：`platform-common/src/main/java/com/example/platform/common/PlatformPaths.java`
- **套件名稱**：`com.example.platform.common`
- **設計定位**：平台無關 (Platform-agnostic) 的路徑解析工具,避免各模組各自處理 Windows / Linux 路徑分隔符差異、JVM 啟動目錄等隱性依賴。
- **核心常數**：
  - `DATA_DIR_ENV = "MYHELLO_DATA_DIR"` — 環境變數:外部資料目錄覆寫
  - `DEFAULT_DATA_DIR_NAME = "data"` — 預設資料目錄名稱
  - `LOGS_DIR_ENV = "MYHELLO_LOGS_DIR"` — 環境變數:外部紀錄目錄覆寫
  - `DEFAULT_LOGS_DIR_NAME = "logs"` — 預設紀錄目錄名稱
- **核心方法**：
  - `ensureDataDirectory()`: 確保 `data/` 目錄存在,並回傳 `Path`;若有 `MYHELLO_DATA_DIR` 環境變數則使用,否則 fallback 至 `${user.dir}/data`
  - `ensureLogsDirectory()`: 同上,但用於 `logs/`
  - `dataDirectory() / dataFile(String)`: 解析 `data/` 內檔案之絕對路徑
  - `sqliteUrl(String filename)`: 產生 SQLite JDBC URL,跨平台處理
  - `normalizeClasspath(String)`: 將 Windows 風格的 `\\` 轉成 `/`,去除尾端分隔符

### 5.2 `package-info.java`
- **檔案路徑**：`platform-common/src/main/java/com/example/platform/common/package-info.java`
- **設計定位**：作為無框架依賴之 Leaf 模組宣告與共用規範指引。

---

## 6. 轉帳 API 合約與 Mock 服務 (mocks/transfer-mock)

> **模組位置說明**：本章 Mock 實作（JAX-RS Resource 與 DTO）已獨立為頂層模組 `mocks/transfer-mock`，對應的 OpenAPI 合約（`A16229-api.yaml` / `A16220-api.yaml`）則位於 `domain-transfer/transfer-workflow/src/main/resources/specs/`，由消費者模組 transfer-workflow 持有。Java package 名稱維持 `org.acme.transfer.api` 不變。

### 6.1 `A16229Resource.java`
- **檔案路徑**：`mocks/transfer-mock/src/main/java/org/acme/transfer/api/A16229Resource.java`
- **套件名稱**：`org.acme.transfer.api`
- **標註**：`@Path("/A16229")`, `@Consumes(MediaType.APPLICATION_JSON)`, `@Produces(MediaType.APPLICATION_JSON)`
- **設計定位**：銀行轉帳流程第一階段——**A 帳戶扣款/轉出服務**（Mock 實作）。
- **核心方法**：
  - `POST execute(A16229Request request)`：
    - **業務檢核**：
      - 若 `request == null` $\rightarrow$ 回傳 HTTP 403 (`code: "999"`, `message: "Request不可為空"`).
      - **測試哨兵 (v2.2 新增)**：若 `request.EC == true` 且 `request.Account_A == "RBFAIL"` $\rightarrow$ 強制回傳 HTTP 403 (`code: "401"`, `message: "回沖失敗(測試哨兵)"`)，供 workflow 端到端驗證 `ROLLBACK_FAILED` 路徑 (HTTP 409)；`EC == false` 的正常交易不受影響。
      - 若 `request.AMT > 50` $\rightarrow$ 扣款成功，回傳 HTTP 200 (`code: "100"`)。若 `request.EC == true`，則訊息顯示為 `"成功(EC)"`。
      - 若 `request.AMT <= 50` $\rightarrow$ 業務拒絕，回傳 HTTP 403 (`code: "999"`, `message: "AMT必須大於50"`).

---

### 6.2 `A16220Resource.java`
- **檔案路徑**：`mocks/transfer-mock/src/main/java/org/acme/transfer/api/A16220Resource.java`
- **套件名稱**：`org.acme.transfer.api`
- **標註**：`@Path("/A16220")`, `@Consumes(MediaType.APPLICATION_JSON)`, `@Produces(MediaType.APPLICATION_JSON)`
- **設計定位**：銀行轉帳流程第二階段——**B 帳戶入帳/轉入服務**（Mock 實作）。
- **核心方法**：
  - `POST execute(A16220Request request)`：
    - **業務檢核**：
      - 若 `request == null` $\rightarrow$ 回傳 HTTP 403 (`code: "999"`, `message: "Request不可為空"`).
      - **測試哨兵 (v2.2 新增)**：若 `request.EC == true` 且 `request.Account_B == "RBFAIL"` $\rightarrow$ 強制回傳 HTTP 403 (`code: "401"`, `message: "回沖失敗(測試哨兵)"`)，供 workflow 端到端驗證 `ROLLBACK_FAILED` 路徑 (HTTP 409)；`EC == false` 的正常交易不受影響。
      - 若 `request.AMT < 1000` $\rightarrow$ 入帳成功，回傳 HTTP 200 (`code: "100"`)。若 `request.EC == true`，則訊息顯示為 `"成功(EC)"`。
      - 若 `request.AMT >= 1000` $\rightarrow$ 業務拒絕，回傳 HTTP 403 (`code: "999"`, `message: "AMT必須小於1000"`).

---

### 6.3 `A16229Request.java` & `A16229Response.java`
- **檔案路徑**：
  - `mocks/transfer-mock/src/main/java/org/acme/transfer/api/dto/A16229Request.java`
  - `mocks/transfer-mock/src/main/java/org/acme/transfer/api/dto/A16229Response.java`
- **DTO 欄位定義**：
  - `A16229Request`：`String Account_A`, `Integer AMT`, `Boolean EC`
  - `A16229Response`：`String code`, `String message`, `String Account`

---

### 6.4 `A16220Request.java` & `A16220Response.java`
- **檔案路徑**：
  - `mocks/transfer-mock/src/main/java/org/acme/transfer/api/dto/A16220Request.java`
  - `mocks/transfer-mock/src/main/java/org/acme/transfer/api/dto/A16220Response.java`
- **DTO 欄位定義**：
  - `A16220Request`：`String Account_B`, `Integer AMT`, `Boolean EC`
  - `A16220Response`：`String code`, `String message`, `String Account`

---

## 7. 轉帳流程與服務調用層 (domain-transfer / transfer-workflow)

### 7.1 `SagaApiService.java`
- **檔案路徑**：`domain-transfer/transfer-workflow/src/main/java/com/example/transfer/workflow/SagaApiService.java`
- **套件名稱**：`com.example.transfer.workflow`
- **標註**：`@ApplicationScoped`
- **設計定位**：提供給 SonataFlow 工作流程（`type: custom`）調用銀行 API 的底層非同步 HTTP 客戶端封裝。
- **成員變數**：
  - `HttpClient httpClient`：JDK 11+ 原生連線池客戶端，逾時設定為 10 秒。
  - `ObjectMapper objectMapper`：JSON 序列化與節點操作。
- **核心方法**：
  1. `JsonNode callA16229(String Account_A, Integer AMT, Boolean EC)`：組裝 JSON Payload 並發送至 `/A16229`。
  2. `JsonNode callA16220(String Account_B, Integer AMT, Boolean EC)`：組裝 JSON Payload 並發送至 `/A16220`。
  3. `CompletableFuture<JsonNode> callApiAsync(String path, JsonNode body)`：
     - 使用 `httpClient.sendAsync()` 發送非同步 POST 請求。
     - 自動在回應 JSON 附帶 `_httpStatus` 欄位（例如 200, 403, 500），供工作流程 switch condition 判斷成功或失敗。
     - 透過 `.exceptionally()` 攔截網路連線逾時或斷線異常，回傳 `code: "999"` 與 `_httpStatus: 0`，避免流程因拋出未捕獲例外而死鎖。

---

### 7.2 `MyOpenApiService.java`
- **檔案路徑**：`domain-transfer/transfer-workflow/src/main/java/com/example/transfer/workflow/MyOpenApiService.java`
- **套件名稱**：`com.example.transfer.workflow`
- **標註**：`@ApplicationScoped`
- **設計定位**：通用型 OpenAPI 動態調用引擎。讓工作流能僅透過傳入 OpenAPI 規格路徑與 Operation ID（如 `specs/A16229-api.yaml#executeA16229`），動態解析端點、路徑、方法並發送非同步 HTTP 請求。
- **核心功能與強化特性**：
  1. **全 HTTP Method 支援**：完整支援 `GET`、`POST`、`PUT`、`DELETE`、`PATCH`、`HEAD`、`OPTIONS` 與自訂方法，依據 Method 自動判定是否攜帶 Request Body。
  2. **路徑與查詢參數自動處理**：
     - **Path Parameters**：自動偵測並替換 URL 模板中的 `{param}`（支援 UTF-8 編碼）。
     - **Query Parameters**：針對 `GET`、`DELETE` 等無 Body 請求，自動將未被 Path 使用的 Payload 欄位組裝為 Query String（`?key=value&...`）。
  3. **自訂 Headers 與鏈路追蹤**：支援從 `arguments.headers` 傳入自訂標頭（如 Authorization、Correlation ID、追蹤標頭等）。
  4. **彈性逾時配置 (Configurable Timeout)**：支援 `application.properties` 全域設定（`kogito.sw.openapi.timeout-seconds`），並允許透過 `arguments.timeoutSeconds` 單次覆寫。
  4.1 **傳輸層指數退避重試 (Transport Retry, v2.2 新增)**：
     - 僅對「未取得 HTTP 回應」的傳輸失敗 (連線拒絕/逾時) 重試；已收到回應者 (含 4xx/5xx) 不重試。
     - 全域:`kogito.sw.openapi.transport-retry.max-attempts`(預設 1=不重試,上限 5)/ `.delay-ms`(預設 500,因子 2.0)。
     - 單次覆寫:`arguments.retryMaxAttempts` / `arguments.retryDelayMs`。
     - 重試耗盡仍回標準化 `{code:"999", errorType:"TRANSPORT", _httpStatus:0}`,workflow 契約不變。
  5. **健壯的響應資料標準化 (Response Normalization)**：
     - JSON Object：自動保證具有 `code`、`message` 及 `_httpStatus`。
     - JSON Array：自動包裝為 `{ "data": [...], "code": "100", ... }`。
     - HTTP 204 / 空 Body：正規化為標準成功結構。
     - 非 JSON / 錯誤回傳：保留原始內容於 `rawResponse` 並標記 `code: "999"` 與對應 HTTP 狀態碼。
     - **errorType 錯誤分類 (v2.1.0 新增)**：失敗回應額外附帶 `errorType`，區分
       `TRANSPORT`（呼叫未抵達目標系統，`_httpStatus=0`，結果未知）、
       `BUSINESS`（目標系統明確回覆業務碼失敗，結果確定）、
       `HTTP_4XX` / `HTTP_5XX`（HTTP 層錯誤且 body 無業務碼）。
       成功回應（`code == "100"`）不含此欄位，向後相容。
- **高並發快取設計**：
  - `operationCache` (`ConcurrentHashMap<String, ApiEndpoint>`)：快取 `specPath#operationId` 之 URL 路徑與 HTTP Method。
  - `baseUrlCache` (`ConcurrentHashMap<String, String>`)：快取 Base URL 解析結果。
  - `specAstCache` (`ConcurrentHashMap<String, JsonNode>`)：快取 OpenAPI YAML 的語法樹（AST），避免重複磁碟 I/O。
  - `requestFieldsCache` (`ConcurrentHashMap<String, List<String>>`)：快取 Request Body 欄位順序與結構。
- **核心方法**：
  1. `callOpenApi(JsonNode arguments)`：主進入點，解析 `schemaRef`、提取 Payload、Headers、Timeout，建構 URL 並發送非同步 HTTP 請求。
  2. `callOpenApi(...)` 多載方法：提供 Map、JsonNode 與多參數簽章，相容 Kogito 編譯期反射生成的多種 WorkItemHandler 呼叫約定。
  3. `resolveBaseUrl(...)`：依序自 `application.properties` 配置中檢索 Base URL（依據 `kogito.sw.functions.<name>.base_url`、`.host`、`.port` 或 OpenAPI spec 中的 `servers[0].url`）。
  4. `resolveRequestFieldNames(String schemaRef)`：解析並快取指定 Operation 的 requestBody schema 欄位清單。

---

## 8. 範例流程服務層 (domain-transfer / transfer-samples)

### 8.1 `ApiService.java`
- **檔案路徑**：`domain-transfer/transfer-samples/src/main/java/com/example/platform/transfer/samples/ApiService.java`
- **套件名稱**：`com.example.platform.transfer.samples`
- **標註**：`@ApplicationScoped`
- **設計定位**：展示 Java CDI 服務與 SonataFlow 整合之示範程式碼。
- **核心方法**：
  1. `JsonNode callExternalApi(String idno, String spcd, String brno)`：
     - 展示如何在 Java 服務中建立支援 TrustAllCerts 的 SSLContext 呼叫外部 API Gateway。
  2. `JsonNode callHealthApi(JsonNode parameters)`：
     - 展示由 `java-workflow.sw.yaml` 呼叫本機健康檢查 API（`GET http://localhost:8080/q/health`）並傳回 JsonNode。

---

## 9. 對帳審計與報表匯出層 (domain-reconciliation / reconciliation-api)

### 9.1 `AuditLogService.java`
- **檔案路徑**：`domain-reconciliation/reconciliation-api/src/main/java/com/example/reconciliation/AuditLogService.java`
- **套件名稱**：`com.example.reconciliation`
- **標註**：`@ApplicationScoped`
- **設計定位**：通用工作流程審計日誌收集與 SQLite WAL 儲存服務。
- **成員變數與注入**：
  - `@Inject DataSource dataSource` (型別為 `javax.sql.DataSource`,實際實作為 Quarkus Agroal 連線池);若注入失敗會 fallback 至 `DriverManager.getConnection(PlatformPaths.sqliteUrl(...))`。
  - `AtomicBoolean initialized`：確保資料表結構與 PRAGMA 配置只執行一次 (double-checked locking)。
- **核心方法**：
  1. `onStart(@Observes StartupEvent ev)`：在應用程式啟動時呼叫 `initDatabase()`。
  2. `initDatabase()`：
     - 自動建立 `data/` 目錄 (透過 `PlatformPaths.ensureDataDirectory()`)。
     - 執行 `PRAGMA journal_mode=WAL;`、`PRAGMA synchronous=NORMAL;`、`PRAGMA busy_timeout=5000;` 啟用高並發寫入。
     - 委派 `DatabaseMigrationRunner.runMigrations(conn)` 自動掃描並執行各模組之 SQL 遷移腳本（不再硬編碼表與 View DDL，徹底實現模組解耦）。
  3. `saveLog(...)` 多載方法：接收工作流傳入之 `workflowId`, `businessKey`, `processInstanceId`, `inputData`, `outputData`，執行 SQL INSERT 並回傳 `{"saved": true}`。
- **跨域呼叫實作**：被 `transfer-workflow/saga2-transfer-workflow.sw.yaml` 的 `functions: - name: recordAuditLog, operation: 'service:com.example.reconciliation.AuditLogService::saveLog'` 呼叫,作為跨 bounded context 的介面契約。

---

### 9.2 `ReconciliationResource.java`
- **檔案路徑**：`domain-reconciliation/reconciliation-api/src/main/java/com/example/reconciliation/ReconciliationResource.java`
- **套件名稱**：`com.example.reconciliation`
- **標註**：`@Path("/reconciliation")`, `@Produces(MediaType.APPLICATION_JSON)`
- **設計定位**：提供對外觸發對帳單 CSV 匯出之 JAX-RS REST 端點。
- **核心方法**：
  1. `GET /reconciliation/export-csv`：支援 Query Parameters（`workflowId`, `businessKey`, `status`）進行過濾。
  2. `POST /reconciliation/export-csv`：支援 JSON Request Body 進行程式化篩選與匯出。

---

### 9.3 `ReconciliationCsvExporter.java`
- **檔案路徑**：`domain-reconciliation/reconciliation-api/src/main/java/com/example/reconciliation/ReconciliationCsvExporter.java`
- **套件名稱**：`com.example.reconciliation`
- **標註**：`@ApplicationScoped`
- **設計定位**：高效能對帳單 CSV 串流匯出引擎。
- **核心特性與方法**：
  1. `exportToCsv(String workflowId, String businessKey, String status)`：
     - 查詢視圖 `vw_saga_reconciliation`，動態拼接 SQL WHERE 條件。
     - 產出檔案名稱格式：`data/reconciliation-YYYYMMDD-HHmmss.csv`。
     - **UTF-8 BOM 支援**：開頭寫入 `\ufeff`，確保 Microsoft Excel 開啟時中文欄位不亂碼。
     - **記憶體保護**：使用 `BufferedWriter` 配合 JDBC `ResultSet` 逐列串流輸出，支援超大資料量匯出。
     - **CSV 跳脫 (`escapeCsv`)**：自動對包含逗號、換行或引號之字串加上雙引號並將內部引號轉義為 `""`。
  2. `exportReconciliationCsv(...)` 多載方法：提供 JsonNode 與 Map 進入點，供 SonataFlow 流程在終點透過工作流動作自動觸發匯出。

### 9.4 `ReconciliationAuditResource.java`
- **檔案路徑**：`domain-reconciliation/reconciliation-api/src/main/java/com/example/reconciliation/ReconciliationAuditResource.java`
- **套件名稱**：`com.example.reconciliation`
- **標註**：`@Path("/api/reconciliation")`, `@Produces(MediaType.APPLICATION_JSON)`
- **設計定位**：對帳與審計交易流水的查詢層 REST 端點 (與 `ReconciliationResource` 的 CSV 匯出互補)。提供 Web UI / 管理後台查詢對帳紀錄、節點鏈 I/O 軌跡、排程任務管理與規格診斷。
- **核心方法**：
  1. `GET /api/reconciliation/records`：查詢對帳紀錄，支援 `accountA` / `accountB` / `status` / `minAmt` / `maxAmt` 等 Query Parameter 條件篩選。
  2. `GET /api/reconciliation/instances`：取得近期工作流實例 ID 清單（支援業務狀態解析 `SUCCESS` / `ROLLED_BACK` / `FAILED`）。
  3. `GET /api/reconciliation/trace/{instanceId}`：取得指定工作流實例之圖形化節點軌跡，回傳各節點的 `inputArgs`、`outputArgs`、`enter`、`exit` 與 `errorMessage`。
  4. `GET /api/reconciliation/files`：列出 `data/` 目錄內歷史產出的 `reconciliation-*.csv` 檔案清單。
  5. `GET /api/reconciliation/files/{filename}`：讀取指定 CSV 檔案內容（`@Produces(MediaType.TEXT_PLAIN)`），供瀏覽器下載或前端預覽。
  6. `POST /api/reconciliation/export-csv`：手動觸發產生新對帳 CSV 檔。
  7. `POST /api/reconciliation/trigger-saga2`：觸發 Saga2 轉帳流程（前端代理）。
  8. `POST /api/reconciliation/proxy-test`：沙盒通用測試代理端點，轉發至 8080 引擎測試 5 大 Workflow。
  9. `POST /api/reconciliation/graphql`：GraphQL 跨域代理端點，轉發至 8080 `/graphql`。
  10. `GET /api/reconciliation/jobs`：查詢 Kogito Jobs & Timers 延遲任務排程紀錄。
  11. `POST /api/reconciliation/jobs/{id}/retry` & `/cancel`：手動重試或取消 Job 排程。
  12. `GET /api/reconciliation/specs` & `POST /api/reconciliation/specs/ping`：讀取 OpenAPI 規格並執行端點健康檢查。
- **依賴**：注入 `AuditQueryService` 處理實際查詢邏輯。

### 9.5 `AuditQueryService.java`
- **檔案路徑**：`domain-reconciliation/reconciliation-api/src/main/java/com/example/reconciliation/AuditQueryService.java`
- **套件名稱**：`com.example.reconciliation`
- **標註**：`@ApplicationScoped`
- **設計定位**：對帳查詢與節點軌跡助手服務，封裝 SQL 查詢與檔案 I/O，避免 Resource 層直接碰 JDBC。
- **成員變數**：
  - `@Inject DataSource dataSource`：優先使用 Agroal 連線池；若失敗 fallback 至 `DriverManager.getConnection(PlatformPaths.sqliteUrl("reconciliation.db"))`。
  - `@Inject ReconciliationCsvExporter csvExporter`：注入 CSV 匯出器。
- **核心方法**：
  1. `ArrayNode getReconciliationRecords(...)`：動態拼接 SQL WHERE 條件，從 `vw_saga_reconciliation` 查詢並回傳 `JsonNode` 陣列。
  2. `ArrayNode getRecentInstances()`：
     - 執行 SQL：`SELECT id, process_id, process_name, state, start_time, end_time, variables FROM processes ORDER BY start_time DESC LIMIT 50`。
     - 從 `variables` JSON 中解析業務層級的 `finalStatus` / `finalMessage`（或 `status` / `message` fallback），輸出為 JSON `status` 與 `message` 欄位，供前端 `flow-trace.html` 下拉式選單識別 `SUCCESS` / `ROLLED_BACK` / `FAILED` 等業務結果（與 SonataFlow 引擎層級 `state` 數字 `0..5` 解耦）。
  3. `ObjectNode getInstanceTrace(String instanceId)`：
     - 執行 SQL：`SELECT id, process_id, process_name, state, start_time, end_time, variables FROM processes WHERE id LIKE ? LIMIT 1`。
     - 從 `variables` 文字偵測 `ROLLED_BACK` 或「回沖」字串，輸出 JSON `status`（`SUCCESS` / `ROLLED_BACK`）。
     - 整合 `getRealNodesFromDb()` 結果組成完整 trace JSON。
  4. `ArrayNode getRealNodesFromDb(Connection conn, String processInstanceId)`：
     - 執行 SQL：`SELECT id, name, type, enter, exit, error_message, input_args, output_args FROM nodes WHERE process_instance_id = ? ORDER BY enter ASC, id ASC`。
     - 自動將 `input_args` 與 `output_args` 反序列化為 Jackson `JsonNode`（JSON 欄位名 `inputArgs` 與 `outputArgs`），支援巢狀物件結構；若反序列化失敗則 fallback 為原始字串。
     - 若有 `error_message` 則一併填入 JSON `errorMessage`。
  5. `JsonNode getReconciliationFiles()`：列出 `data/` 目錄內 `reconciliation-*.csv` 檔案（含檔名、大小、最後修改時間）。
  6. `String getCsvFileContent(String filename)`：讀取指定 CSV 檔案完整內容。

---

### 9.6 `DatabaseMigrationRunner.java`
- **檔案路徑**：`domain-reconciliation/reconciliation-api/src/main/java/com/example/reconciliation/migration/DatabaseMigrationRunner.java`
- **套件名稱**：`com.example.reconciliation.migration`
- **設計定位**：輕量級模組化資料庫遷移執行器。遵循 Flyway 規範自動掃描 Classpath 下 `db/migration/` 目錄中的 `V{version}__{description}.sql` 腳本，依語意版本號依序套用。
- **核心特性與方法**：
  1. `runMigrations(Connection conn)`：核心遷移進入點。建立 `reconciliation_schema_history` 表，比對已執行版本，依序執行未套用之遷移腳本並記錄執行結果、CRC32 Checksum 與耗時。
  2. `discoverMigrationScripts()`：自動掃描 Classpath 下的檔案系統與 JAR 套件內的 SQL 腳本。
  3. `splitSqlStatements(String sqlContent)`：智慧分割多語句 SQL，安全過濾單行註解 (`--`)、區塊註解 (`/* */`) 與字串常數內的假分號。
  4. `compareVersions(String v1, String v2)`：標準語意版本號比較演算法（如 `1.0.0` 比 `1.1.0` 優先）。

---

### 9.7 模組化資料庫遷移腳本 (`db/migration/*.sql`)
- **`V1.0.0__create_workflow_execution_log.sql`**：
  - **模組**：`domain-reconciliation / reconciliation-api`
  - **內容**：建立通用審計表 `workflow_execution_log` 及 `idx_wel_process_instance_id`、`idx_wel_workflow_business_key` 索引。
- **`V1.1.0__create_view_transfer_reconciliation.sql`**：
  - **模組**：`domain-transfer / transfer-workflow`
  - **內容**：建立 Saga2 流程專屬對帳視圖 `vw_saga_reconciliation`，抽取 `Account_A`、`Account_B`、`AMT`、API 結果與 Rollback 結果。

---

### 9.8 未來新增業務之對帳 View 擴充指南 (SOP)
當平台加入全新業務模組（例如 `domain-payment`、`domain-loan`）時，遵循以下 SOP 即可實現**零程式碼修改、隨插即用**的專屬對帳 View：

1. **建立 Migration 檔案**：
   - 在新業務模組目錄 `domain-<業務名>/<業務名>-workflow/src/main/resources/db/migration/` 建立 SQL 檔案。
   - 檔名遵守格式：`V{主版本}.{次版本}.{修訂版}__create_view_<業務名>_reconciliation.sql`（例如 `V1.2.0__create_view_payment_reconciliation.sql`）。
2. **編寫 View 抽取 DDL**：
   - 使用 SQLite `json_extract()` 函數抽取 `input_data` 與 `output_data` 中的業務關鍵欄位。
   - 明確設定 `WHERE workflow_id = '<your-workflow-id>'`。
3. **自動裝配與執行**：
   - 當該業務模組被 Maven 依賴並打包至 distribution 應用時，`DatabaseMigrationRunner` 於應用啟動時自動掃描該腳本，執行 DDL 並於 `reconciliation_schema_history` 表記錄版本。
   - **完全不需要修改 `AuditLogService` 或 `reconciliation-api` 核心程式碼**。

### 9.9 `OpsAlertService.java`（v2.2 新增）
- **檔案路徑**：`domain-reconciliation/reconciliation-api/src/main/java/com/example/reconciliation/OpsAlertService.java`
- **套件名稱**：`com.example.reconciliation`
- **標註**：`@ApplicationScoped`
- **設計定位**：運維條件告警服務。由 workflow 統一終點 (`FinalAuditAndEnd`) 收尾時條件呼叫——
  僅當 `finalStatus == "ROLLBACK_FAILED"` (回沖失敗、需人工介入) 時實際觸發,其餘狀態靜默返回 `{raised:false}`。
- **核心方法**：
  - `raise(String workflowId, Object processInstanceId, Object businessKey, Object finalStatus, Object finalMessage, Map<String,Object> detail)`：
    展開參數版。⚠️ 簽名須與 workflow functionRef arguments **精確型別對應**
    (Kogito codegen 以反射查找 `(String, Object×4, Map)`,參數一律用 Object/Map 接收),否則建置期即報
    `could not find a method ... with proper arguments`。
  - `raise(JsonNode arguments)`：單一節點版,相容不同綁定形態。
- **告警通道**：專屬 SLF4J logger `"OPS-ALERT"`,輸出 ERROR 級日誌
  `[OPS-ALERT] 回沖失敗,需人工介入 | workflowId=... | instanceId=... | businessKey=... | detail={回沖明細}`,
  供 ELK / Splunk 以關鍵字建告警規則接單;`TODO(擴充點)` 標註 Kafka/webhook/ITSM 串接位置。
- **容錯語義**：告警通道故障僅降級為一般日誌並返回 `raised=false`,**不阻斷交易收尾**。

---

## 10. 分發應用層代碼生成機制 (distribution/*)

在 `myhello-platform` 架構中，`distribution/transfer-app` 與 `distribution/reconciliation-app` 模組內部**完全不需要手寫任何 Java 原始程式碼**：

1. **資源自動同步 (`maven-resources-plugin`) — 單一事實來源 (v2.2)**：
   - 在 `initialize` 階段，Maven 外掛將 `domain-transfer` 與 `domain-reconciliation` 下的 `.sw.yaml` 流程圖及 OpenAPI YAML 同步至 `src/main/resources`。
   - **canonical source 一律在 domain 模組**；transfer-app 內的同名副本為「建置產物」(已列入 `.gitignore`、不追蹤)，直接編輯會在下一次建置被靜默覆蓋。
   - v2.2 起 pom 已移除將 domain 目錄直接納入 `<resources>` 的雙重打包路徑,打包僅經由同步後的 `src/main/resources` 單一路徑。
2. **Kogito 編譯期代碼生成 (`quarkus:generate-code`)**：
   - Kogito 自動為每個 `.sw.yaml` 產生對應的 JAX-RS REST Controller（如 `Saga2_transfer_workflowResource.java`）、流程定義類別（`Saga2_transfer_workflowProcess.java`）以及 WorkItemHandlers。
3. **Quarkus Arc CDI 依賴發現 (`jandex-maven-plugin`)**：
   - 透過跨模組的 Jandex 索引與 `application.properties` 中的 `quarkus.index-dependency.*` 配置，Quarkus 自動裝配平台層過濾器與領域層業務服務。
