# Maven & Quarkus 知識庫 ─ 基礎觀念 + 進階操作 / 命令 / 設定

> **適用對象**:`myhello-platform / distribution/transfer-app` 維運、開發、SRE
> **涵蓋範圍**:Maven 3.9+ (含 BOM、Reactor、Profile、離線建置);Quarkus 3.27.2 (含 build-time augmentation、CDI、Hibernate、OpenAPI、native、k8s)
> **結合專案**:所有概念都對應到 `transfer-app` 實際的 pom.xml 與 application.properties 設定
> **Java 版本**:Java 17 (release, `<maven.compiler.release>17</maven.compiler.release>`) / Java 21 (developer toolchain)
> **maven-compiler-plugin**:3.15.0 (parent 在 `pluginManagement` 統一管理)

---

## 目錄

### Part A ─ Maven 基礎觀念

| 章節 | 標題 |
| :--- | :--- |
| 1 | Maven 是什麼 |
| 2 | POM 結構 |
| 3 | 生命週期 (Lifecycle) |
| 4 | 常用命令速查 |
| 5 | Reactor 與多模組 |
| 6 | 屬性 (Properties) |
| 7 | 依賴範圍 (Scope) |
| 8 | 倉庫 (Repository) |
| 9 | .mvn/ 目錄與 wrapper |
| 10 | 設定檔 `~/.m2/settings.xml` |

### Part B ─ Maven 進階操作

| 章節 | 標題 |
| :--- | :--- |
| 11 | BOM 與 `dependencyManagement` |
| 12 | `<dependencyManagement>` vs `<dependencies>` |
| 13 | Plugin Management (`<pluginManagement>`) |
| 14 | 插件綁定與執行順序 |
| 15 | Profile (條件化設定) |
| 16 | 依賴衝突解決 |
| 17 | 跨模組資源同步 |
| 18 | Jandex Plugin |
| 19 | Enforcer Plugin |
| 20 | 離線建置 |
| 21 | Surefire vs Failsafe |
| 22 | 常用 Plugin 速查 |
| 23 | mvn 常用參數 |
| 24 | 常見錯誤排查 |

### Part C ─ Quarkus 基礎觀念

| 章節 | 標題 |
| :--- | :--- |
| 25 | Quarkus 是什麼 |
| 26 | Extension 機制 |
| 27 | Application 結構 |
| 28 | Configuration |
| 29 | CDI (Arc) |
| 30 | JAX-RS (REST) |
| 31 | Request / Response Filter |
| 32 | JSON 序列化 |
| 33 | Logging |
| 34 | Testing |
| 35 | Build-time Augmentation |
| 36 | 開發模式 (Dev Mode) |
| 37 | 健康檢查 (Health Check) |
| 38 | OpenAPI / Swagger |
| 39 | 常用 CLI 操作 |
| 40 | 常用 Annotation 速查 |

### Part D ─ Quarkus 進階操作

| 章節 | 標題 |
| :--- | :--- |
| 41 | 資料庫存取 (Hibernate ORM + Agroal) |
| 42 | 客製 Hibernate Dialect |
| 43 | REST Client |
| 44 | Reactive Programming (Mutiny) |
| 45 | 訊息佇列 (Kafka) |
| 46 | 快取 (Cache / Redis) |
| 47 | 排程任務 (Scheduler) |
| 48 | 訊息 / 通知 (Mailer) |
| 49 | WebSocket |
| 50 | GraphQL |
| 51 | Security (OIDC / JWT) |
| 52 | Fault Tolerance |
| 53 | OpenTelemetry / Micrometer |
| 54 | Native Build (GraalVM) |
| 55 | Container Image |
| 56 | Kubernetes 部署 |
| 57 | ConfigMapping |
| 58 | ConfigSource 自訂 |
| 59 | Lifecycle Event 完整列表 |
| 60 | Build Step 進階 |
| 61 | Kogito / SonataFlow 整合 |
| 62 | 多 Profile 設定慣例 |
| 63 | Static Files |
| 64 | HTTPS / TLS |
| 65 | CORS |
| 66 | 優化與調校 |
| 67 | 常見進階模式 |
| 68 | Quarkus 對 transfer-app 的影響 |
| 69 | 推薦資源 |
| 70 | Quarkus vs Spring Boot |
| 71 | 快速開始模板 |

### Part E ─ transfer-app 實例對照表

| 章節 | 標題 |
| :--- | :--- |
| 72 | 父 POM 解讀 |
| 73 | 子模組 POM 對照 |
| 74 | application.properties 對照 |
| 75 | 編譯指令流程 |
| 76 | 部署指令 |
| 77 | 常見 Quarkus 命令 |
| 78 | 故障排查對照表 |
| 79 | 完整依賴鏈視覺化 |
| 80 | 快速對照表 |

---

# Part A ─ Maven 基礎觀念

---

## 1. Maven 是什麼

Maven 是 Apache 維護的**專案管理與建構工具**,提供:

- **統一目錄佈局**:`src/main/java`、`src/test/java`、`target/`
- **生命週期管理**:`compile → test → package → install → deploy`
- **依賴管理**:從 Maven Repository (Maven Central、自架) 拉 JAR
- **多模組編譯 (Reactor)**:一次編譯整個 DAG
- **插件化 (Plugin)**:所有動作 (編譯、測試、打包) 都是 plugin

對 transfer-app 而言,所有事情都從 `mvn clean package` 開始。

---

## 2. POM 結構 (Project Object Model)

每個 Maven 專案都有一個 `pom.xml`,描述:

```xml
<project>
    <modelVersion>4.0.0</modelVersion>
    <groupId>org.acme.platform</groupId>          <!-- 組織 -->
    <artifactId>myhello-platform</artifactId>     <!-- 模組名 -->
    <version>1.0.0-SNAPSHOT</version>             <!-- 版本 -->
    <packaging>pom</packaging>                     <!-- 打包類型 -->

    <parent>...</parent>                          <!-- 父 POM 繼承 -->
    <modules>...</modules>                        <!-- 子模組 (僅 parent) -->
    <properties>...</properties>                  <!-- 變數 -->
    <dependencyManagement>...</dependencyManagement>  <!-- 版本管理 -->
    <dependencies>...</dependencies>              <!-- 實際依賴 -->
    <build>...</build>                            <!-- plugin 設定 -->
    <repositories>...</repositories>              <!-- 倉庫來源 -->
    <profiles>...</profiles>                      <!-- 條件分支 -->
</project>
```

### 2.1 packaging 常見值

| 值 | 產出 | 範例 |
| :--- | :--- | :--- |
| `pom` | 不打包,只描述 | parent、aggregator |
| `jar` | `target/*.jar` | 一般 library |
| `war` | `target/*.war` | web app (傳統 servlet 容器) |
| `maven-plugin` | `target/*.jar` | 自訂 plugin |
| (未宣告) | 預設 `jar`,但 Quarkus 會改為 `quarkus-app` | transfer-app |

---

## 3. 生命週期 (Lifecycle)

Maven 內建三個**獨立** lifecycle:**clean、default、site**。每個 lifecycle 包含多個**phase**,phase 嚴格按順序執行。

### 3.1 default lifecycle (最常用)

```
validate → initialize → generate-sources → process-sources
  → generate-resources → process-resources → compile
  → process-classes → generate-test-sources → process-test-sources
  → generate-test-resources → process-test-resources → test-compile
  → process-test-classes → test → prepare-package → package
  → pre-integration-test → integration-test → post-integration-test
  → verify → install → deploy
```

| Phase | 對 transfer-app 的觸發 |
| :--- | :--- |
| `validate` | 讀 POM,確認結構 |
| `initialize` | `maven-resources-plugin` 把 `domain-transfer/*/resources` 拷貝到 transfer-app |
| `generate-sources` | jandex 索引生成 |
| `process-classes` | `quarkus:generate-code` 觸發 Kogito codegen |
| `compile` | `maven-compiler-plugin` 編譯 Java |
| `test` | 跑 `*Test.java` |
| `package` | `quarkus:build` 組裝 fat-jar |
| `install` | 把自己裝到 `~/.m2/repository` |

### 3.2 對應指令

| 指令 | 跑到哪裡 |
| :--- | :--- |
| `mvn validate` | validate |
| `mvn compile` | compile |
| `mvn test` | test |
| `mvn package` | package (產 target/*.jar) |
| `mvn verify` | verify |
| `mvn install` | install (產 + 進本地 repo) |
| `mvn deploy` | install + 上傳遠端 |
| `mvn clean` | 跑 clean lifecycle,刪 `target/` |

### 3.3 plugin goal 與 phase 綁定

Plugin 的 goal 不會自動跑,必須綁到 phase。**常見的預設綁定** (內建 lifecycle binding):

| Phase | 預設觸發的 plugin goal |
| :--- | :--- |
| `compile` | `compiler:compile` |
| `test-compile` | `compiler:testCompile` |
| `test` | `surefire:test` |
| `package` | `jar:jar` 或 `war:war` |
| `install` | `install:install` |
| `deploy` | `deploy:deploy` |

> **注意**: Quarkus 的 `quarkus:build` 不是預設綁定,必須在 `pom.xml` 顯式掛到 `package` phase。

---

## 4. 常用命令速查

```bash
# 基本流程
mvn clean package -DskipTests          # 清掉 target, 編譯打包, 跳過測試
mvn clean install                       # 編譯 + 裝到本地 repo
mvn compile                             # 只編譯
mvn test                                # 只跑測試
mvn verify                              # 編譯 + 跑所有測試 + verify 階段

# 多模組
mvn clean package -pl transfer-app -am   # 只編 transfer-app + 其依賴
mvn clean package -pl :transfer-app -amd  # 只編 transfer-app + 依賴它的
mvn -pl distribution -am clean package   # 編 distribution 整個 chain

# 離線模式
mvn clean package -o                    # offline, 不連網
mvn clean package -Dmaven.repo.local=/path/to/repo

# 跳過某些 plugin
mvn package -DskipTests                 # 跳 surefire
mvn package -Dmaven.test.skip=true      # 跳 surefire + compiler:testCompile
mvn package -Dquarkus.package.type=fast-jar  # Quarkus 換打包方式

# 看 log / 診斷
mvn -X clean package                    # debug log
mvn -e clean package                    # 例外 stack
mvn clean package -U                    # 強制更新 snapshot
mvn dependency:tree                     # 看依賴樹
mvn dependency:resolve                  # 列出所有解析後的 JAR
mvn help:effective-pom                  # 合併後的 POM
mvn help:active-profiles                # 當前生效的 profile

# Quarkus 專用
mvn quarkus:dev                         # 開發模式 (熱重載)
mvn quarkus:build                       # 強制 build-time augmentation
mvn quarkus:add-extension               # 互動加 extension
mvn quarkus:list-extensions             # 列已安裝的 extension
mvn quarkus:test                        # 跑 @QuarkusTest
```

---

## 5. Reactor 與多模組

### 5.1 什麼是 Reactor

當 parent POM 宣告 `<modules>`,Maven 會把所有子模組的 POM 讀進來,**拓樸排序**成一個 DAG,然後依序 / 平行執行。

範例 (transfer-app):

```mermaid
flowchart TD
    P["myhello-platform (parent)"]
    C["platform-common"]
    S["platform-security"]
    E["platform-extensions"]
    DI["platform-data-index"]
    DT["domain-transfer"]
    DR["domain-reconciliation"]
    DIS["distribution"]

    P --> C
    P --> S
    P --> E
    P --> DI
    P --> DT
    P --> DR
    P --> DIS
    P --> MK["mocks/transfer-mock"]
    DT --> DT2["transfer-workflow"]
    DT --> DT3["transfer-samples"]
    DIS --> DIS1["transfer-app"]
    DIS --> DIS2["reconciliation-app"]
```

### 5.2 Reactor 計算的 DAG 編譯順序

Reactor 會展開所有 module,計算依賴,然後分 wave 執行:

```
Wave 1: platform-common
Wave 2: platform-security, platform-extensions
Wave 3: platform-data-index, transfer-mock, reconciliation-api
Wave 4: transfer-workflow, transfer-samples
Wave 5: transfer-app, reconciliation-app   ← transfer-app 最後
```

> transfer-app 在最後一個 wave,因為它依賴前面所有 platform 與 domain 模組。

### 5.3 部分編譯參數

| 參數 | 作用 |
| :--- | :--- |
| `-pl <module>` | 只編指定模組 (project list) |
| `-am` | also-make,連同 `<module>` 依賴的模組一起編 |
| `-amd` | also-make-dependents,連同依賴 `<module>` 的模組一起編 |
| `-N` | --non-recursive,只編當前模組,不進子模組 |
| `-rf <module>` | 從這個模組開始 resume |
| `-T 4` | 平行執行 (4 線程) |

範例:

```bash
# 只編 transfer-app 與其依賴
mvn clean package -pl transfer-app -am -DskipTests

# 編 transfer-app + 用它的 reconciliation-app
mvn clean package -pl transfer-app -amd -DskipTests

# 從 transfer-workflow 開始編
mvn clean package -rf :transfer-workflow -DskipTests
```

---

## 6. 屬性 (Properties)

```xml
<properties>
    <maven.compiler.release>17</maven.compiler.release>
    <quarkus.platform.version>3.27.2</quarkus.platform.version>
    <kie.version>10.2.0</kie.version>
</properties>

<dependencies>
    <dependency>
        <groupId>io.quarkus</groupId>
        <artifactId>quarkus-resteasy</artifactId>
        <version>${quarkus.platform.version}</version>
    </dependency>
</dependencies>
```

> **注意**: property 在整個 POM 樹**只繼承**,**不覆寫**。子 POM 設同名 property 不會覆蓋 parent。

---

## 7. 依賴範圍 (Scope)

| Scope | 編譯 | 測試 | 執行 | 範例 |
| :--- | :--- | :--- | :--- | :--- |
| `compile` (預設) | ✓ | ✓ | ✓ | quarkus-resteasy |
| `provided` | ✓ | ✓ | ✗ | quarkus-junit5 (期望執行環境有) |
| `runtime` | ✗ | ✓ | ✓ | JDBC driver |
| `test` | ✗ | ✓ | ✗ | rest-assured |
| `system` | ✓ | ✓ | ✗ | 自帶 JAR (極少用) |
| `import` | 僅用於 BOM | — | — | quarkus-bom |

---

## 8. 倉庫 (Repository)

```xml
<repositories>
    <repository>
        <id>central</id>
        <url>https://repo.maven.apache.org/maven2</url>
    </repository>
    <repository>
        <id>apache-public-repository-group</id>
        <url>https://repository.apache.org/content/groups/public/</url>
    </repository>
</repositories>
```

- Maven 預設有 `central` 倉庫 (但 transfer-app 顯式宣告)
- `pluginRepositories` 是 plugin 用的
- 離線模式用 `-o` 或 `-Dmaven.repo.local`

---

## 9. .mvn/ 目錄與 wrapper

```bash
# 用 Maven Wrapper 鎖定版本
mvn -N io.takari:maven:0.7.7:wrapper
# 會產生 mvnw / mvnw.cmd
```

> transfer-app 沒用 wrapper,直接假設環境裝好 `mvn`。

---

## 10. 設定檔 `~/.m2/settings.xml`

```xml
<settings>
    <mirrors>
        <mirror>
            <id>internal-nexus</id>
            <mirrorOf>*</mirrorOf>
            <url>http://nexus.internal/repository/maven-public/</url>
        </mirror>
    </mirrors>
    <servers>
        <server>
            <id>internal-nexus</id>
            <username>...</username>
            <password>...</password>
        </server>
    </servers>
    <profiles>
        <profile>
            <id>air-gapped</id>
            <repositories>
                <repository>
                    <id>offline-local</id>
                    <url>file:///opt/offline-repo</url>
                </repository>
            </repositories>
        </profile>
    </profiles>
</settings>
```

---

# Part B ─ Maven 進階操作

---

## 11. BOM 與 `dependencyManagement`

### 11.1 什麼是 BOM

**BOM (Bill of Materials)** 是一種特殊的 pom,**只有 `<dependencyManagement>` 不帶 `<dependencies>`**,用來**統一管理版本號**。

```xml
<!-- quarkus-bom 的核心內容 (節錄) -->
<dependencyManagement>
    <dependencies>
        <dependency>
            <groupId>io.quarkus</groupId>
            <artifactId>quarkus-resteasy</artifactId>
            <version>3.27.2</version>
        </dependency>
        <!-- ... 幾百條 quarkus-* -->
    </dependencies>
</dependencyManagement>
```

### 11.2 怎麼用

子模組**用 import scope** 把 BOM 拉進來:

```xml
<dependencyManagement>
    <dependencies>
        <dependency>
            <groupId>io.quarkus.platform</groupId>
            <artifactId>quarkus-bom</artifactId>
            <version>3.27.2</version>
            <type>pom</type>
            <scope>import</scope>
        </dependency>
    </dependencies>
</dependencyManagement>
```

之後子模組寫依賴時就**不需版本**:

```xml
<dependencies>
    <dependency>
        <groupId>io.quarkus</groupId>
        <artifactId>quarkus-resteasy</artifactId>  <!-- 版本由 BOM 提供 -->
    </dependency>
</dependencies>
```

### 11.3 為何用 BOM

- **版本對齊**:Quarkus 內部幾百個 extension 必須版本一致,BOM 保證
- **可升級**:改 BOM version 一行就升級整個 Quarkus
- **少衝突**:BOM 已挑過哪些版本互不相剋

### 11.4 transfer-app 用到的 BOM

| BOM | 對齊版本 | 內容 |
| :--- | :--- | :--- |
| `quarkus-bom` (io.quarkus.platform) | 3.27.2 | quarkus-* 幾百個 extension 統一版本 |
| `kogito-bom` (org.kie.kogito) | 10.2.0 | sonataflow-* / kogito-* / kie-* 統一版本 |
| **`myhello-platform-bom`(parent 自訂)** | 1.0.0-SNAPSHOT | 內部 7 條 `dependencyManagement` 條目:platform-common / platform-security / platform-data-index / transfer-workflow / transfer-samples / reconciliation-api / transfer-mock + xerial `sqlite-jdbc 3.45.1.0` |

---

## 12. `<dependencyManagement>` vs `<dependencies>`

| 區塊 | 用途 |
| :--- | :--- |
| `<dependencyManagement>` | 只宣告**版本**,**不實際引入**。子模組仍要寫 `<dependencies>` 才會拉 JAR |
| `<dependencies>` | **實際引入** JAR 到 classpath |

```xml
<!-- parent 的 dependencyManagement:只是「版本表」 -->
<dependencyManagement>
    <dependency>
        <groupId>io.quarkus</groupId>
        <artifactId>quarkus-resteasy</artifactId>
        <version>3.27.2</version>
    </dependency>
</dependencyManagement>

<!-- 子模組的 dependencies:實際拉 JAR -->
<dependencies>
    <dependency>
        <groupId>io.quarkus</groupId>
        <artifactId>quarkus-resteasy</artifactId>
        <!-- version 從 parent 找 -->
    </dependency>
</dependencies>
```

---

## 13. Plugin Management (`<pluginManagement>`)

類似 dependencyManagement,plugin 也能在 parent 集中管理版本與設定:

```xml
<!-- parent -->
<build>
    <pluginManagement>
        <plugins>
            <plugin>
                <groupId>io.quarkus.platform</groupId>
                <artifactId>quarkus-maven-plugin</artifactId>
                <version>3.27.2</version>
                <extensions>true</extensions>
                <executions>
                    <execution>
                        <goals>
                            <goal>build</goal>
                            <goal>generate-code</goal>
                        </goals>
                    </execution>
                </executions>
            </plugin>
        </plugins>
    </pluginManagement>
</build>
```

子模組**只宣告 plugin 不帶版本**:

```xml
<build>
    <plugins>
        <plugin>
            <groupId>io.quarkus.platform</groupId>
            <artifactId>quarkus-maven-plugin</artifactId>
            <!-- 版本從 parent 找 -->
        </plugin>
    </plugins>
</build>
```

---

## 14. 插件綁定與執行順序

`<executions>` 內可指定多個 execution,每個綁到不同 phase:

```xml
<plugin>
    <artifactId>maven-resources-plugin</artifactId>
    <executions>
        <execution>
            <id>sync-domain-resources</id>
            <phase>initialize</phase>          <!-- 最早 phase -->
            <goals><goal>copy-resources</goal></goals>
            <configuration>
                <outputDirectory>${project.basedir}/src/main/resources</outputDirectory>
                <overwrite>true</overwrite>
                <resources>
                    <resource>
                        <directory>../../domain-transfer/transfer-workflow/src/main/resources</directory>
                    </resource>
                </resources>
            </configuration>
        </execution>
    </executions>
</plugin>
```

| Phase 修飾 | 影響 |
| :--- | :--- |
| `<phase>initialize</phase>` | 最早執行,在所有 build 動作前 |
| 不寫 phase | 用 plugin 預設綁定 |
| 同一 plugin 多個 execution | 全部會跑,依 `<phase>` 順序 |

---

## 15. Profile (條件化設定)

Profile 讓 POM 在不同條件下用不同設定。常見場景:

- 開發 vs 生產 (`-P dev` vs `-P prod`)
- 連線到不同環境 (`-P test` 用 H2,正式用 Postgres)
- JDK 版本

```xml
<profiles>
    <profile>
        <id>prod</id>
        <activation>
            <activeByDefault>false</activeByDefault>
        </activation>
        <properties>
            <db.url>jdbc:postgresql://prod-db:5432/app</db.url>
        </properties>
    </profile>

    <profile>
        <id>test</id>
        <activation>
            <activeByDefault>false</activeByDefault>
        </activation>
        <properties>
            <db.url>jdbc:h2:mem:test</db.url>
        </properties>
    </profile>
</profiles>
```

呼叫:

```bash
mvn package -P prod
mvn package -P test
```

### 15.1 transfer-app 的 `%test.` 前綴

Quarkus 借用 properties 命名慣例:**`%<profile>.<key>=<value>`** 是 profile 限定設定:

```properties
# application.properties (依照 transfer-app 實際設定)
quarkus.http.port=8080
%test.quarkus.http.test-port=8080
%test.quarkus.datasource.jdbc.url=jdbc:sqlite:target/test-reconciliation.db
%test.quarkus.oidc.enabled=false
%test.quarkus.oidc.tenant-enabled=false
%test.quarkus.oidc.auth-server-url=none
%test.quarkus.keycloak.devservices.enabled=false
```

> 同樣的 `%test.*` 設定在 `reconciliation-app/src/main/resources/application.properties` 也存在,將 `test-port` 設為 8081(與正式 8090 區隔),並把 `quarkus.datasource.jdbc.read-only` 設回 `false`(測試環境需要寫入)。

- 沒有前綴:全 profile 共用
- `%test.` 前綴:只在 `quarkus:test` 或 `@QuarkusTest` 時生效
- `%prod.` 前綴:正式環境生效
- `%dev.` 前綴:`mvn quarkus:dev` 時生效

這是 **Quarkus 機制**,不是 Maven profile。Maven profile 用 `<profile>` 區塊。

---

## 16. 依賴衝突解決 (Dependency Mediation)

### 16.1 規則

Maven 採用**最近路徑優先** (nearest wins):

```
A → B → C 1.0
A → D → C 2.0
```
A 直接用 C 1.0 (透過 B 比較近)。

### 16.2 同深度時

- **第一宣告優先** (Maven 3.x)
- 或 `<dependencyManagement>` 強制鎖版

### 16.3 排除依賴

```xml
<dependency>
    <groupId>org.xerial</groupId>
    <artifactId>sqlite-jdbc</artifactId>
    <exclusions>
        <exclusion>
            <groupId>org.slf4j</groupId>
            <artifactId>slf4j-api</artifactId>
        </exclusion>
    </exclusions>
</dependency>
```

### 16.4 強制版本

```xml
<dependency>
    <groupId>com.fasterxml.jackson.core</groupId>
    <artifactId>jackson-databind</artifactId>
    <version>2.15.0</version>
</dependency>
```

> **注意**: Quarkus BOM 已經把整個生態版本對齊,**不要自己覆寫版本**,會破壞相容性。

### 16.5 診斷

```bash
mvn dependency:tree -Dincludes=com.fasterxml.jackson
mvn dependency:tree -Dverbose
mvn help:effective-pom
```

---

## 17. 跨模組資源同步 (Maven Resources Plugin)

`distribution/transfer-app` 的 workflow YAML 不在自身 `src/main/resources/`,而是其他模組。

**兩種做法**:

### 17.1 `<resources>` 宣告外部目錄

```xml
<build>
    <resources>
        <resource><directory>src/main/resources</directory></resource>
        <resource><directory>../../domain-transfer/transfer-workflow/src/main/resources</directory></resource>
    </resources>
</build>
```

`process-resources` phase 會把多個目錄的內容**合併**到 `target/classes/`。

### 17.2 `copy-resources` goal 實體複製

```xml
<build>
    <plugins>
        <plugin>
            <artifactId>maven-resources-plugin</artifactId>
            <executions>
                <execution>
                    <id>sync-domain-resources</id>
                    <phase>initialize</phase>
                    <goals><goal>copy-resources</goal></goals>
                    <configuration>
                        <outputDirectory>${project.basedir}/src/main/resources</outputDirectory>
                        <overwrite>true</overwrite>
                        <resources>
                            <resource>
                                <directory>../../domain-transfer/transfer-workflow/src/main/resources</directory>
                            </resource>
                        </resources>
                    </configuration>
                </execution>
            </executions>
        </plugin>
    </plugins>
</build>
```

### 17.3 兩種差異

| 方式 | 優點 | 缺點 |
| :--- | :--- | :--- |
| `<resources>` | 不動原始碼 tree | IDE 看不到 |
| `copy-resources` | 寫到 `src/main/resources/`,IDE 同步 | 改動原始碼 tree (git 看得到差異) |

> **本專案現況 (v2.2 單一事實來源)**:transfer-app 已移除 `<resources>` 外部目錄寫法,
> 僅保留 `copy-resources` execution(`initialize` 階段同步 domain 模組資源至 `src/main/resources/`,
> 同步產物已列入 `.gitignore` 不追蹤)。canonical source 一律在 domain 模組,直接編輯 app 副本會被下次建置靜默覆蓋。

---

## 18. Jandex Plugin

Jandex 是 SmallRye 的 class index 工具,在編譯期把 jar 內的 class + annotation 索引成 `META-INF/jandex.idx`。Quarkus runtime 用這索引快速找 bean。

```xml
<plugin>
    <groupId>io.smallrye</groupId>
    <artifactId>jandex-maven-plugin</artifactId>
    <version>3.2.7</version>
    <executions>
        <execution>
            <id>make-index</id>
            <goals><goal>jandex</goal></goals>
        </execution>
    </executions>
</plugin>
```

執行後每個模組的 `target/classes/META-INF/jandex.idx` 都會有索引。

> **為何需要**: Quarkus 不在 runtime 用 reflection 全掃 classpath(太慢),改用 jandex.idx 做 O(1) bean lookup。

---

## 19. Enforcer Plugin (規則檢查)

`maven-enforcer-plugin` 在 validate 階段執行規則 (JDK 版本、依賴限制、模組結構等)。

```xml
<plugin>
    <artifactId>maven-enforcer-plugin</artifactId>
    <executions>
        <execution>
            <id>enforce-java</id>
            <goals><goal>enforce</goal></goals>
            <configuration>
                <rules>
                    <requireJavaVersion><version>[17,)</version></requireJavaVersion>
                </rules>
            </configuration>
        </execution>
    </executions>
</plugin>
```

transfer-app 設 `<enforcer.skip>true</enforcer.skip>`,因為離線環境可能缺 rule 套件。

---

## 20. 離線建置 (Air-Gapped)

斷網環境的標準做法:

```bash
# 1. 先在有網環境把所有套件拉到本地
mvn dependency:go-offline -Dmaven.repo.local=/path/to/offline-repo

# 2. 把 /path/to/offline-repo 整包帶到斷網機

# 3. 斷網機執行
mvn -o -Dmaven.repo.local=/path/to/offline-repo clean package
```

transfer-app 內建 `offline-build.sh` 直接做這件事。

---

## 21. Surefire (單元測試) vs Failsafe (整合測試)

| Plugin | 跑的測試 | phase |
| :--- | :--- | :--- |
| `maven-surefire-plugin` | `*Test.java`, `*Tests.java` | `test` |
| `maven-failsafe-plugin` | `*IT.java`, `*ITCase.java` | `integration-test` |

transfer-app 兩個都用 Surefire(預設),但 Quarkus 的 `@QuarkusTest` 啟動整個容器,實務上是「準整合測試」。

---

## 22. 常用 Plugin 完整速查

| Plugin | 用途 | 預設綁定 phase |
| :--- | :--- | :--- |
| `maven-compiler-plugin` | 編譯 | `compile` / `test-compile` |
| `maven-resources-plugin` | 複製 resources | `process-resources` / `process-test-resources` |
| `maven-surefire-plugin` | 跑單元測試 | `test` |
| `maven-failsafe-plugin` | 跑整合測試 | `integration-test` |
| `maven-jar-plugin` | 打 jar | `package` |
| `maven-war-plugin` | 打 war | `package` |
| `maven-install-plugin` | 裝到 `~/.m2/repository` | `install` |
| `maven-deploy-plugin` | 上傳遠端 repo | `deploy` |
| `maven-clean-plugin` | 刪 `target/` | clean |
| `maven-site-plugin` | 產 site 文件 | site |
| `maven-enforcer-plugin` | 規則檢查 | `validate` |
| `jandex-maven-plugin` | 產 jandex.idx | `process-classes` |
| `quarkus-maven-plugin` | Quarkus build-time | `process-classes` / `package` |
| `maven-dependency-plugin` | 依賴分析 | (手動觸發) |

---

## 23. mvn 常用參數一覽

```bash
-X                  # debug log
-e                  # 例外 stack
-U                  # 強制更新 SNAPSHOT
-o                  # offline
-pl <modules>       # project list
-am / -amd          # also-make / also-make-dependents
-rf <module>        # resume from
-N                  # non-recursive
-T <n>              # 平行 (注意 module 間有依賴)
-DskipTests         # 跳 surefire
-Dmaven.test.skip   # 跳 surefire + test-compile
-Dquarkus.profile=  # 設定 quarkus profile
-Dproperties=value  # 設系統屬性
```

---

## 24. 常見錯誤與排查

| 錯誤 | 原因 | 解法 |
| :--- | :--- | :--- |
| `Could not find artifact` | 沒連網 / 沒設 repo | 加 mirror,離線環境用 `-Dmaven.repo.local=` |
| `Package does not exist` | 編譯期缺依賴 | 加 `<scope>compile</scope>` 或升級 |
| `ClassCastException at runtime` | 多版本衝突 | 用 `mvn dependency:tree` 找,`<exclusion>` |
| `Module X not found in reactor` | Reactor 計算時漏 | 檢查 `<modules>` 拼字與路徑 |
| `Plugin requires Maven X.Y` | Maven 太舊 | 升級 Maven |
| `OutOfMemoryError` (GC overhead) | fork 模式不夠記憶體 | `MAVEN_OPTS=-Xmx2g` |
| `BUILD FAILURE cyclic dependency` | 模組循環 | 重新設計依賴 |

---

# Part C ─ Quarkus 基礎觀念

---

## 25. Quarkus 是什麼

Quarkus 是 Red Hat 開發的**雲原生 Java 框架**,核心口號:

> **"Supersonic Subatomic Java"** — 為 GraalVM/容器/Kubernetes 優化

### 25.1 三大特性

| 特性 | 意義 |
| :--- | :--- |
| **Container-first** | 為 container 量身打造,記憶體小、啟動快 |
| **Reactive + Imperative** | 同時支援 imperative (RESTEasy) 與 reactive (Mutiny/Vert.x) |
| **Build-time augmentation** | reflection / proxy / config validation 都搬到 build-time |

### 25.2 為何選 Quarkus (vs Spring Boot)

| 維度 | Quarkus | Spring Boot |
| :--- | :--- | :--- |
| 啟動時間 (傳統 JVM) | 0.5-2s | 3-10s |
| 記憶體 (REST app) | 30-80MB | 150-300MB |
| Native binary | ✓ (GraalVM) | ✗ (僅 Spring Native 實驗) |
| 標準規範 | Jakarta EE / MicroProfile | 自家標準 |
| extension 機制 | 統一 `quarkus-*` 命名 | `spring-boot-starter-*` |

transfer-app 選 Quarkus 因為要跑 **Kogito Data Index 內嵌 + GraalVM-ready**。

---

## 26. Extension 機制

### 26.1 Extension 是什麼

Extension = 一組 Quarkus 套件,提供特定功能 (REST、DataSource、Hibernate 等)。
Extension 通常由兩個 Maven artifact 組成:

- **runtime**:執行期依賴,被打進應用 jar
- **deployment**:build-time 依賴,提供 `@BuildStep` processor

> 慣例: `quarkus-resteasy` 是 runtime,`quarkus-resteasy-deployment` 是 deployment。

### 26.2 怎麼用

```xml
<dependency>
    <groupId>io.quarkus</groupId>
    <artifactId>quarkus-resteasy</artifactId>
</dependency>
<!-- deployment 自動透過 BOM 帶入 -->
```

### 26.3 核心 extension 一覽

| Extension | 功能 | 對 transfer-app |
| :--- | :--- | :--- |
| `quarkus-arc` | CDI | ✓ |
| `quarkus-resteasy` | JAX-RS (REST) | ✓ |
| `quarkus-resteasy-jackson` | JSON | ✓ |
| `quarkus-smallrye-openapi` | OpenAPI/Swagger | ✓ |
| `quarkus-smallrye-health` | Health check | ✓ |
| `quarkus-hibernate-orm` | JPA | ✓ (transitive) |
| `quarkus-agroal` | JDBC pool | ✓ (transitive) |
| `quarkus-vertx` | HTTP server | ✓ (transitive) |
| `quarkus-flyway` | DB migration | ✓ (透過 kogito) |
| `quarkus-junit5` | 測試 | ✓ (test) |
| `quarkus-kubernetes` | K8s 部署 | ✓ |

### 26.4 探索可用 extension

```bash
mvn quarkus:list-extensions
mvn quarkus:add-extension                    # 互動加
mvn quarkus:add-extension -Dextension=quarkus-redis
```

---

## 27. Application 結構 (Quarkus 標準佈局)

```
my-app/
├── pom.xml
├── src/
│   ├── main/
│   │   ├── java/
│   │   │   └── com/example/MyResource.java
│   │   └── resources/
│   │       ├── application.properties
│   │       ├── META-INF/resources/        ← 靜態檔 (web root)
│   │       │   └── index.html
│   │       └── META-INF/microprofile-config.properties  ← 可選
│   └── test/
│       └── java/
│           └── com/example/MyResourceTest.java
└── target/
    └── quarkus-app/                       ← 編譯產物
        ├── quarkus-run.jar
        ├── app/, lib/, quarkus/
```

---

## 28. Configuration (application.properties)

### 28.1 載入順序 (由低到高)

| Ordinal | 來源 |
| :--- | :--- |
| 100 | `application.properties` (預設) |
| 200 | `application.yaml` |
| 250 | 自訂 `ConfigSource` (例如 PlatformConfigSource) |
| 300 | 環境變數 |
| 400 | JVM system properties (`-D`) |

> 高 ordinal 覆蓋低 ordinal。

### 28.2 命名慣例

`quarkus.<extension>.<key>=<value>`,例如:

```properties
# HTTP
quarkus.http.port=8080
quarkus.http.host=0.0.0.0
quarkus.http.cors.enabled=false

# Datasource
quarkus.datasource.db-kind=postgresql
quarkus.datasource.jdbc.url=jdbc:postgresql://localhost/app
quarkus.datasource.username=${DB_USER}
quarkus.datasource.password=${DB_PASSWORD}

# Hibernate
quarkus.hibernate-orm.database.generation=update
quarkus.hibernate-orm.log.sql=true

# Logging
quarkus.log.level=INFO
quarkus.log.category."com.example".level=DEBUG
```

### 28.3 Profile 限定設定

```properties
# 共用
quarkus.http.port=8080

# 測試限定
%test.quarkus.http.test-port=8080
%test.quarkus.datasource.jdbc.url=jdbc:h2:mem:test

# 開發限定
%dev.quarkus.hibernate-orm.log.sql=true

# 正式限定
%prod.quarkus.log.level=WARN
```

### 28.4 占位符與表達式

```properties
# 預設值
quarkus.datasource.jdbc.url=jdbc:sqlite:${MYHELLO_DATA_DIR:data}/reconciliation.db

# 引用其他屬性
quarkus.http.port=8080
kogito.data-index.url=http://localhost:${quarkus.http.port:8080}
```

### 28.5 從程式讀取

```java
@ApplicationScoped
public class MyService {
    @ConfigProperty(name = "my.greeting")
    String greeting;

    @ConfigProperty(name = "my.greeting", defaultValue = "hello")
    String greetingWithDefault;
}
```

或用 ConfigMapping (3.x 新):

```java
@ConfigMapping(prefix = "my")
public interface MyConfig {
    String greeting();
    int port();
}
```

---

## 29. CDI (Arc)

Quarkus 用 **ArC** (自己的 CDI 實作),不額外依賴 Weld。

### 29.1 核心註解

| 註解 | 用途 |
| :--- | :--- |
| `@ApplicationScoped` | 整個 app 一個實例 |
| `@Singleton` | 強型單例 |
| `@RequestScoped` | 一個 HTTP 請求一個 |
| `@Dependent` | 偽造 singleton (每個注入點新建) |
| `@Inject` | 注入依賴 |
| `@Produces` | 工廠方法 |
| `@Named` / `@Qualifier` | 命名 |

### 29.2 範例

```java
@ApplicationScoped
public class AuditLogService {
    @Inject DataSource dataSource;
    @ConfigProperty(name = "my.flag") boolean flag;
    @Inject @Named("mysql") DataSource mysqlDs;  // 多實例
}
```

### 29.3 事件

```java
// 廣播
@Inject Event<MyEvent> events;
events.fire(new MyEvent(...));

// 接收
void onStart(@Observes StartupEvent ev) { ... }
void onStop(@Observes ShutdownEvent ev) { ... }
```

Quarkus 提供:
- `StartupEvent` (應用就緒)
- `ShutdownEvent` (關機中)
- `PreShutdownEvent` (關機前)

### 29.4 攔截器

```java
@InterceptorBinding
@Target({TYPE, METHOD})
@Retention(RUNTIME)
public @interface Audited {}

@Interceptor
@Audited
@Priority(Interceptor.Priority.APPLICATION + 10)
public class AuditedInterceptor {
    @AroundInvoke
    Object audit(InvocationContext ctx) throws Exception {
        // 前置
        Object result = ctx.proceed();
        // 後置
        return result;
    }
}
```

---

## 30. JAX-RS (REST)

### 30.1 Resource 範例

```java
@Path("/users")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class UserResource {

    @GET
    public List<User> list() { ... }

    @GET
    @Path("/{id}")
    public Response get(@PathParam("id") Long id) { ... }

    @POST
    public Response create(User user) {
        URI location = URI.create("/users/" + user.id);
        return Response.created(location).entity(user).build();
    }

    @PUT @Path("/{id}")
    public User update(@PathParam("id") Long id, User user) { ... }

    @DELETE @Path("/{id}")
    public void delete(@PathParam("id") Long id) { ... }
}
```

### 30.2 常用 annotation

| Annotation | 用途 |
| :--- | :--- |
| `@Path("/x")` | 資源路徑 |
| `@GET / @POST / @PUT / @DELETE` | HTTP method |
| `@PathParam` | 路徑變數 |
| `@QueryParam` | query string |
| `@FormParam` | form data |
| `@HeaderParam` | header |
| `@CookieParam` | cookie |
| `@BeanParam` | 把多個 param 綁成 bean |
| `@DefaultValue` | 預設值 |
| `@Produces / @Consumes` | Content-Type |

### 30.3 Exception Mapping

```java
@Provider
public class MyExceptionMapper implements ExceptionMapper<MyException> {
    @Override
    public Response toResponse(MyException e) {
        return Response.status(500)
            .entity(Map.of("error", e.getMessage()))
            .build();
    }
}
```

---

## 31. Request / Response Filter

### 31.1 ContainerRequestFilter

```java
@Provider
@ApplicationScoped
@Priority(Priorities.AUTHENTICATION)
public class AuthFilter implements ContainerRequestFilter {
    @Override
    public void filter(ContainerRequestContext ctx) throws IOException {
        if (!isAuthorized(ctx)) {
            ctx.abortWith(Response.status(403).build());
        }
    }
}
```

### 31.2 ContainerResponseFilter

```java
@Provider
@ApplicationScoped
@Priority(Priorities.USER)
public class HeaderFilter implements ContainerResponseFilter {
    @Override
    public void filter(ContainerRequestContext req, ContainerResponseContext res) {
        res.getHeaders().add("X-Custom-Header", "value");
    }
}
```

### 31.3 Priority 順序

| Priority | 用途 |
| :--- | :--- |
| `AUTHENTICATION = 1000` | 認證 |
| `AUTHORIZATION = 2000` | 授權 |
| `HEADER_DECORATOR = 3000` | header 加工 |
| `ENTITY_CODER = 4000` | entity 編解碼 |
| `USER = 5000` | 使用者自訂 |

Request 鏈:小到大;Response 鏈:大到小。

---

## 32. JSON 序列化 (Jackson)

預設 `quarkus-resteasy-jackson` 用 Jackson。

```java
public class User {
    public String name;
    @JsonProperty("user_id")
    public Long id;
    @JsonIgnore
    public String password;
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    public LocalDateTime createdAt;
}
```

全域設定:

```properties
quarkus.jackson.write-dates-as-timestamps=false
quarkus.jackson.serialization-inclusion=non-null
quarkus.jackson.deserialization.fail-on-unknown-properties=false
```

---

## 33. Logging

### 33.1 設定

```properties
# 等級
quarkus.log.level=INFO
quarkus.log.category."com.example".level=DEBUG
quarkus.log.category."org.kie".level=WARN

# Console
quarkus.log.console.enabled=true
quarkus.log.console.format=%d{HH:mm:ss} %-5p [%c{1.}] %s%e%n

# File
quarkus.log.file.enabled=true
quarkus.log.file.path=logs/app.log
quarkus.log.file.rotation.max-file-size=10M
quarkus.log.file.rotation.max-backup-index=10
```

### 33.2 用法

```java
@ApplicationScoped
public class MyService {
    private static final Logger LOG = LoggerFactory.getLogger(MyService.class);
    public void do() {
        LOG.info("message {}", arg);
        LOG.error("error", ex);
    }
}
```

### 33.3 MDC (追蹤)

```java
MDC.put("traceId", "abc-123");
try {
    // ...
} finally {
    MDC.remove("traceId");
}
```

格式: `%X{traceId}`

---

## 34. Testing

### 34.1 `@QuarkusTest`

```java
@QuarkusTest
class MyResourceTest {
    @Test
    void test() {
        given()
            .contentType("application/json")
            .body("{\"key\":\"value\"}")
        .when()
            .post("/api/users")
        .then()
            .statusCode(201);
    }
}
```

- `@QuarkusTest` 啟動整個 Quarkus app 在測試時
- 預設用 `application.properties` 套上 `%test.` 設定
- 預設 port 由 Quarkus 動態指派;`%test.quarkus.http.test-port=8080` 強制指定

### 34.2 注入 bean

```java
@QuarkusTest
class MyServiceTest {
    @Inject MyService service;        // 真實 bean
    @InjectMock MyDependency mock;    // Mockito mock
}
```

### 34.3 Test Profile

```java
@QuarkusTest
@TestProfile(MyProfile.class)
class CustomProfileTest { ... }

public class MyProfile implements QuarkusTestProfile {
    public Map<String, String> getConfigOverrides() {
        return Map.of("quarkus.datasource.jdbc.url", "jdbc:h2:mem:test");
    }
}
```

### 34.4 跑測試

```bash
mvn test                              # Surefire 跑 *Test
mvn -Dtest=MyClassTest test           # 只跑特定 class
mvn -Dtest=MyClassTest#myMethod test  # 只跑特定 method
mvn quarkus:test                      # 跑 @QuarkusTest (含 dev services)
```

---

## 35. Build-time Augmentation (核心哲學)

### 35.1 概念

```
傳統框架 (Spring):
  compile → *.class → runtime 反射掃描 → 慢啟動

Quarkus:
  compile → *.class → quarkus:build 預先處理 (build-time) → 產出可直接執行的 bytecode
```

### 35.2 預先做的事

- Classpath 掃描 (透過 Jandex)
- Bean discovery
- CDI proxy 生成
- Config 驗證
- Reflection 替換
- OpenAPI 文件生成
- Kogito 程式碼生成

### 35.3 七大啟動階段 (有對應的 `@Record` 註解)

| 階段 | 說明 |
| :--- | :--- |
| Bootstrap | JVM 系統屬性 |
| Augment | (build-time) |
| Static Init | 框架級 static init |
| Runtime Config Init | 解析 properties |
| Runtime Init | CDI、Vert.x、Quarkus 各 service |
| Application Start | 廣播 StartupEvent |
| Running | 接受 HTTP |

### 35.4 `@Record(ExecutionTime.RUNTIME_INIT)` 範例

```java
@BuildStep
@Record(ExecutionTime.RUNTIME_INIT)
MyBuildItem register(RecorderContext ctx, MyRecorder recorder) {
    return new MyBuildItem(recorder.createSomething());
}
```

Recorder 是在 build-time 編譯的,**記錄一段 bytecode**,runtime 時被執行。

---

## 36. 開發模式 (Dev Mode)

```bash
mvn quarkus:dev
```

- 啟動 Quarkus,**熱重載** (改 .java 自動重編)
- `http://localhost:8080/q/dev-ui/` 是 Dev UI
- 自動重啟:改 .properties、.yaml、靜態檔
- 第一次 `mvn quarkus:dev` 會花較久,後續都很快

### 36.1 Dev Services

Quarkus 3.x 有 **Dev Services** 機制:dev mode 自動啟動 Testcontainers (Redis、Postgres、Kafka...),測試結束自動關閉。

```properties
# dev mode 自動啟動 Postgres 16 container
quarkus.datasource.devservices.enabled=true
quarkus.datasource.devservices.image-name=postgres:16
```

### 36.2 連線到本機 dev UI

- `http://localhost:8080/q/dev/` - Dev UI 主頁
- `http://localhost:8080/q/health` - Health check
- `http://localhost:8080/q/openapi` - OpenAPI
- `http://localhost:8080/q/graphql-ui` - GraphiQL (若有)

---

## 37. 健康檢查 (Health Check)

### 37.1 MicroProfile Health

```java
@Liveness      // 還活著?
public class MyLivenessCheck implements HealthCheck {
    public HealthCheckResponse call() {
        return HealthCheckResponse.up("alive");
    }
}

@Readiness     // 可接受流量?
public class MyReadinessCheck implements HealthCheck {
    public HealthCheckResponse call() {
        return HealthCheckResponse.named("ready").up().build();
    }
}
```

### 37.2 端點

| Path | 用途 |
| :--- | :--- |
| `/q/health` | 總覽 |
| `/q/health/live` | Liveness |
| `/q/health/ready` | Readiness |
| `/q/health/started` | Startup (K8s 啟動訊號) |
| `/q/health/groups/<group>` | 自訂群組 |

### 37.3 K8s 整合

`/q/health/live` 與 `/q/health/ready` 對應 K8s 的 `livenessProbe` / `readinessProbe`。

---

## 38. OpenAPI / Swagger

### 38.1 自動生成

加上 `quarkus-smallrye-openapi`,自動掃描所有 `@Path` resource:

- `GET /q/openapi` - 純 OpenAPI JSON/YAML
- `GET /q/openapi-ui` - Swagger UI

### 38.2 自訂

```properties
quarkus.smallrye-openapi.info-title=My API
quarkus.smallrye-openapi.info-version=1.0
quarkus.smallrye-openapi.info-description=My API description
quarkus.smallrye-openapi.info-contact-email=dev@example.com
quarkus.smallrye-openapi.info-license-name=MIT
quarkus.smallrye-openapi.servers=https://api.example.com
```

### 38.3 OpenAPI Filter

```java
public class MyOasFilter implements OASFilter {
    public PathItem filterPathItem(PathItem item) {
        item.setDELETE(null);  // 隱藏 DELETE
        return item;
    }
}
```

設定:

```properties
mp.openapi.filter=com.example.MyOasFilter
```

### 38.4 標註

```java
@Operation(summary = "查詢使用者")
@APIResponse(responseCode = "200", description = "成功")
@Tag(name = "user")
public List<User> list() { ... }
```

---

## 39. 常用 CLI 操作

```bash
# 查已裝 extension
mvn quarkus:list-extensions

# 加 extension (會自動更新 pom.xml)
mvn quarkus:add-extension
mvn quarkus:add-extension -Dextension=quarkus-redis-client

# 跑 dev mode
mvn quarkus:dev

# 跑測試
mvn quarkus:test

# 強制 build-time augmentation
mvn quarkus:build

# Image build
mvn package -Dquarkus.container-image.build=true

# Native build
mvn package -Dnative -Dquarkus.native.container-build=true

# 分析
mvn dependency:tree
mvn help:effective-pom
```

---

## 40. 常用 Annotation 速查

| Annotation | 套件 | 用途 |
| :--- | :--- | :--- |
| `@ApplicationScoped` | `jakarta.enterprise.context` | app 級 singleton |
| `@Inject` | `jakarta.inject` | DI 注入 |
| `@ConfigProperty` | `org.eclipse.microprofile.config.inject` | 注入設定 |
| `@Path` | `jakarta.ws.rs` | REST 資源 |
| `@GET / @POST` | `jakarta.ws.rs` | HTTP method |
| `@Produces / @Consumes` | `jakarta.ws.rs` | Content-Type |
| `@Provider` | `jakarta.ws.rs.ext` | JAX-RS 擴充 |
| `@Liveness / @Readiness` | `org.eclipse.microprofile.health` | Health check |
| `@Startup` | `io.quarkus.runtime` | 啟動事件 (Quarkus 3.7+) |
| `@BuildStep` | `quarkus.deployment.annotations` | build processor (deployment) |
| `@Record` | `quarkus.runtime.annotations` | Recorder 標註 |

---

# Part D ─ Quarkus 進階操作

---

## 41. 資料庫存取 (Hibernate ORM + Agroal)

### 41.1 加上 extension

```xml
<dependency>
    <groupId>io.quarkus</groupId>
    <artifactId>quarkus-hibernate-orm</artifactId>
</dependency>
<dependency>
    <groupId>io.quarkus</groupId>
    <artifactId>quarkus-agroal</artifactId>
</dependency>
<dependency>
    <groupId>io.quarkus</groupId>
    <artifactId>quarkus-jdbc-postgresql</artifactId>  <!-- 或 mysql / mariadb / oracle / mssql -->
</dependency>
```

### 41.2 設定 datasource

```properties
# 基本
quarkus.datasource.db-kind=postgresql
quarkus.datasource.username=${DB_USER:postgres}
quarkus.datasource.password=${DB_PASSWORD:postgres}
quarkus.datasource.jdbc.url=jdbc:postgresql://${DB_HOST:localhost}:${DB_PORT:5432}/${DB_NAME:app}
quarkus.datasource.jdbc.max-size=20

# 多 datasource
quarkus.datasource."primary".db-kind=postgresql
quarkus.datasource."primary".jdbc.url=...
quarkus.datasource."read-replica".db-kind=postgresql
quarkus.datasource."read-replica".jdbc.url=...
```

### 41.3 注入

```java
@Inject
DataSource dataSource;     // Agroal 池化的 javax.sql.DataSource

@Inject
@Named("read-replica")
DataSource replicaDs;
```

### 41.4 JPA 設定

```properties
# schema 管理
quarkus.hibernate-orm.database.generation=update  # none / drop-and-create / update / validate

# SQL log
quarkus.hibernate-orm.log.sql=true
quarkus.hibernate-orm.log.format-sql=true

# 效能
quarkus.hibernate-orm.jdbc.timezone=UTC
quarkus.hibernate-orm.order-by-default-nulls=last
```

### 41.5 Entity

```java
@Entity
@Table(name = "users")
public class User {
    @Id @GeneratedValue
    public Long id;
    public String name;
    @Column(unique = true)
    public String email;
    @Enumerated(EnumType.STRING)
    public Status status;
    @OneToMany(mappedBy = "user", cascade = CascadeType.ALL)
    public List<Order> orders;
}
```

### 41.6 Panache (Active Record 或 Repository)

```java
// Active Record
@Entity
public class User extends PanacheEntity {
    public String name;
    public static List<User> findActive() {
        return find("status", Status.ACTIVE).list();
    }
}

// Repository
@ApplicationScoped
public class UserRepository implements PanacheRepository<User> {
    public List<User> findActive() {
        return find("status", Status.ACTIVE).list();
    }
}
```

### 41.7 交易

```java
@Transactional
public void createUser(User u) {
    User.persist(u);
    // 自動 commit,拋例外自動 rollback
}
```

### 41.8 Native Query

```java
@EntityManager em;
List<User> users = em.createNativeQuery(
    "SELECT * FROM users WHERE created_at > :since", User.class)
    .setParameter("since", LocalDateTime.now().minusDays(7))
    .getResultList();
```

### 41.9 Flyway (Schema migration)

```xml
<dependency>
    <groupId>io.quarkus</groupId>
    <artifactId>quarkus-flyway</artifactId>
</dependency>
```

```properties
quarkus.flyway.migrate-at-start=true
quarkus.flyway.baseline-on-migrate=true
quarkus.flyway.locations=classpath:db/migration
```

`src/main/resources/db/migration/V1__init.sql`:

```sql
CREATE TABLE users (
  id BIGSERIAL PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(100) UNIQUE,
  created_at TIMESTAMP DEFAULT NOW()
);
```

### 41.10 Liquibase

```xml
<dependency>
    <groupId>io.quarkus</groupId>
    <artifactId>quarkus-liquibase</artifactId>
</dependency>
```

```properties
quarkus.liquibase.migrate-at-start=true
quarkus.liquibase.change-log=db/changelog/db.changelog-master.yaml
```

---

## 42. 客製 Hibernate Dialect

### 42.1 為何要

Quarkus 預設不支援 SQLite (Quarkus 3.27.x 沒有 `db-kind=sqlite`),要自訂 dialect。

### 42.2 流程

1. 引入 `hibernate-community-dialects`(提供 `SQLiteDialect`)
2. 寫自己的 dialect 繼承 `SQLiteDialect`
3. 在 `application.properties` 設定 `quarkus.hibernate-orm.dialect`

```java
public class MySQLiteDialect extends SQLiteDialect {
    public MySQLiteDialect() { super(); }

    @Override
    public void contributeTypes(TypeContributions tc, ServiceRegistry sr) {
        super.contributeTypes(tc, sr);
        // 註冊自訂 JdbcType / JavaType
        tc.contributeJdbcType(MyZonedDateTimeJdbcType.INSTANCE);
        tc.contributeJavaType(MyZonedDateTimeJavaType.INSTANCE);
    }
}
```

```properties
quarkus.hibernate-orm.dialect=com.example.MySQLiteDialect
```

### 42.3 進階:用 listener 改既有 entity

Hibernate 6.x 對現有 entity 的 Type 是 cached,單純註冊 JavaType 不夠。
要在 `onMetadataInitialized` 時**反射清 cache**:

```java
public class MyInitListener implements HibernateOrmIntegrationStaticInitListener {
    @Override
    public void onMetadataInitialized(Metadata md, BootstrapContext ctx, BiConsumer<String, Object> props) {
        TypeConfiguration tc = ctx.getTypeConfiguration();
        tc.getJavaTypeRegistry().addDescriptor(new MyJavaType());

        for (PersistentClass pc : md.getEntityBindings()) {
            for (Property prop : pc.getProperties()) {
                if (prop.getType().getReturnedClass() == ZonedDateTime.class) {
                    Field f = SimpleValue.class.getDeclaredField("type");
                    f.setAccessible(true);
                    f.set(prop.getValue(), null);  // 清 cache
                }
            }
        }
    }
}
```

然後註冊到 Quarkus:

```java
@BuildStep
@Record(ExecutionTime.STATIC_INIT)
HibernateOrmIntegrationStaticInitListenerBuildItem myListener() {
    return new HibernateOrmIntegrationStaticInitListenerBuildItem(new MyInitListener());
}
```

> 這就是 transfer-app `SqliteZonedDateTimeIntegrationListener` 做的事。

---

## 43. REST Client (呼叫外部 API)

### 43.1 介面宣告

```java
@RegisterRestClient(baseUri = "https://api.example.com")
public interface MyClient {
    @GET @Path("/users/{id}")
    User getUser(@PathParam("id") Long id);

    @POST @Path("/users")
    @Consumes(MediaType.APPLICATION_JSON)
    Response createUser(User user);
}
```

### 43.2 設定

```properties
quarkus.rest-client."com.example.MyClient".url=https://api.example.com
quarkus.rest-client."com.example.MyClient".scope=jakarta.inject.Singleton
```

### 43.3 注入

```java
@Inject @RestClient MyClient client;
User u = client.getUser(123L);
```

### 43.4 替代方案: MicroProfile Rest Client (reactive)

```java
@RegisterRestClient
@Path("/")
public interface ReactiveClient {
    @GET @Path("/data")
    CompletionStage<MyData> getData();
}
```

---

## 44. Reactive Programming (Mutiny)

Quarkus 預設用 **Mutiny** (`Uni<T>` 與 `Multi<T>`) 做 reactive。

```java
@GET @Path("/{id}")
@Produces(MediaType.APPLICATION_JSON)
public Uni<User> getUser(@PathParam("id") Long id) {
    return User.findById(id)
        .onItem().ifNull().failWith(() -> new NotFoundException())
        .onFailure().recoverWithItem(fallback);
}

@GET @Path("/stream")
@Produces(MediaType.SERVER_SENT_EVENTS)
public Multi<String> stream() {
    return Multi.createFrom().ticks().every(Duration.ofSeconds(1))
        .map(t -> "tick-" + t);
}
```

### 44.1 Uni 轉同步

```java
Uni<User> uni = ...;
User u = uni.await().indefinitely();
```

### 44.2 與 imperative 互轉

```java
// Uni → blocking
public User blockingFind(Long id) {
    return User.findById(id).await().indefinitely();
}

// CompletionStage → Uni
Uni<User> uni = Uni.createFrom().completionStage(() -> service.getUserAsync(id));
```

---

## 45. 訊息佇列 (Kafka / AMQP / MQTT)

### 45.1 Reactive Messaging

```xml
<dependency>
    <groupId>io.quarkus</groupId>
    <artifactId>quarkus-messaging-kafka</artifactId>
</dependency>
```

```java
@ApplicationScoped
public class MyProcessor {

    @Incoming("prices")
    @Outgoing("processed-prices")
    public double process(double price) {
        return price * 1.1;
    }

    @Incoming("prices")
    public CompletionStage<Void> consume(KafkaRecord<String, Double> rec) {
        LOG.info("got: {}", rec.getPayload());
        return rec.ack();
    }
}
```

```properties
mp.messaging.incoming.prices.connector=smallrye-kafka
mp.messaging.incoming.prices.topic=prices
mp.messaging.incoming.prices.value.deserializer=...
mp.messaging.incoming.prices.auto.offset.reset=earliest
```

### 45.2 Dev Services for Kafka

`mvn quarkus:dev` 自動啟動 Kafka container (透過 Testcontainers)。

---

## 46. 快取 (Cache)

```xml
<dependency>
    <groupId>io.quarkus</groupId>
    <artifactId>quarkus-cache</artifactId>
</dependency>
```

```java
@CacheResult(cacheName = "users")
public User getUser(Long id) { ... }

@CacheInvalidate(cacheName = "users")
public void updateUser(User u) { ... }
```

> 預設用 Caffeine,單機記憶體。

### 46.1 Redis 快取

```xml
<dependency>
    <groupId>io.quarkus</groupId>
    <artifactId>quarkus-redis-client</artifactId>
</dependency>
<dependency>
    <groupId>io.quarkus</groupId>
    <artifactId>quarkus-cache</artifactId>
</dependency>
```

```properties
quarkus.redis.hosts=redis://localhost:6379
quarkus.cache.users.type=redis
```

---

## 47. 排程任務 (Scheduler)

```xml
<dependency>
    <groupId>io.quarkus</groupId>
    <artifactId>quarkus-scheduler</artifactId>
</dependency>
```

```java
@ApplicationScoped
public class MyScheduler {

    @Scheduled(every = "30s", identity = "poll")
    void poll() { ... }

    @Scheduled(cron = "0 0 3 * * ?")  // 每天 3 點
    void daily() { ... }
}
```

```properties
quarkus.scheduler.enabled=true
```

---

## 48. 訊息 / 通知 (Mailer)

```xml
<dependency>
    <groupId>io.quarkus</groupId>
    <artifactId>quarkus-mailer</artifactId>
</dependency>
```

```properties
quarkus.mailer.from=noreply@example.com
quarkus.mailer.host=smtp.example.com
quarkus.mailer.port=587
quarkus.mailer.username=${MAIL_USER}
quarkus.mailer.password=${MAIL_PASS}
quarkus.mailer.start-tls=REQUIRED
```

```java
@Inject Mailer mailer;

public void send() {
    mailer.send(
        Mail.withText("to@example.com", "Subject", "Hello"));
}
```

---

## 49. WebSocket

```xml
<dependency>
    <groupId>io.quarkus</groupId>
    <artifactId>quarkus-websockets-next</artifactId>  <!-- Quarkus 3.x 新版 -->
</dependency>
```

```java
@WebSocket(path = "/chat/{room}")
public class ChatWebSocket {

    @OnOpen
    void onOpen(Session session, @PathParam("room") String room) { ... }

    @OnTextMessage
    void onMessage(String message) { ... }

    @OnClose
    void onClose(Session session) { ... }
}
```

---

## 50. GraphQL

```xml
<dependency>
    <groupId>io.quarkus</groupId>
    <artifactId>quarkus-smallrye-graphql</artifactId>
</dependency>
```

```java
@GraphQLApi
public class UserResource {

    @Query
    public List<User> users() { ... }

    @Query
    public User user(@Name("id") Long id) { ... }

    @Mutation
    public User createUser(User u) { ... }
}
```

端點: `POST /graphql`、`GET /q/graphql-ui`(GraphiQL)。

---

## 51. Security (OIDC / JWT)

### 51.1 OIDC

```xml
<dependency>
    <groupId>io.quarkus</groupId>
    <artifactId>quarkus-oidc</artifactId>
</dependency>
```

```properties
quarkus.oidc.auth-server-url=https://keycloak.example.com/realms/myrealm
quarkus.oidc.client-id=my-app
quarkus.oidc.credentials.secret=${OIDC_SECRET}
```

```java
@Path("/secure")
@Authenticated
public class SecureResource {
    @GET
    public String hello(@User SecurityIdentity identity) {
        return "Hello, " + identity.getPrincipal().getName();
    }
}
```

### 51.2 JWT (no OIDC server)

```xml
<dependency>
    <groupId>io.quarkus</groupId>
    <artifactId>quarkus-smallrye-jwt</artifactId>
</dependency>
<dependency>
    <groupId>io.quarkus</groupId>
    <artifactId>quarkus-smallrye-jwt-build</artifactId>
</dependency>
```

```properties
mp.jwt.verify.publickey.location=publicKey.pem
mp.jwt.verify.issuer=https://example.com
```

```java
@Inject
@ConfigProperty(name = "smallrye.jwt.new-token.signature-algorithm")
SignatureAlgorithm alg;

@POST @Path("/login")
public String login(UserCredential cred) {
    return Jwt.issuer("https://example.com")
        .upn(cred.username)
        .groups(Set.of("user"))
        .expiresIn(Duration.ofHours(1))
        .sign(alg);
}
```

### 51.3 RBAC

```java
@RolesAllowed("admin")
@Path("/admin")
public class AdminResource { ... }
```

---

## 52. Fault Tolerance (Retry / Fallback / Timeout)

```xml
<dependency>
    <groupId>io.quarkus</groupId>
    <artifactId>quarkus-smallrye-fault-tolerance</artifactId>
</dependency>
```

```java
@Retry(maxRetries = 3, delay = 200, delayUnit = ChronoUnit.MILLIS)
@Timeout(2000)
@Fallback(fallbackMethod = "defaultGreeting")
public String greet() { ... }

public String defaultGreeting() { return "Hi"; }
```

---

## 53. OpenTelemetry / Micrometer (Metrics & Tracing)

### 53.1 Micrometer

```xml
<dependency>
    <groupId>io.quarkus</groupId>
    <artifactId>quarkus-micrometer-registry-prometheus</artifactId>
</dependency>
```

```properties
quarkus.micrometer.export.prometheus.enabled=true
```

`GET /q/metrics` 取得 Prometheus 格式。

### 53.2 OpenTelemetry

```xml
<dependency>
    <groupId>io.quarkus</groupId>
    <artifactId>quarkus-opentelemetry</artifactId>
</dependency>
```

```properties
quarkus.otel.exporter.otlp.traces.endpoint=http://otel-collector:4317
```

自動追蹤所有 HTTP 與 JDBC 呼叫。

---

## 54. Native Build (GraalVM)

### 54.1 環境需求

- GraalVM 17+ (或透過 container)
- 4GB+ RAM
- C 編譯器 (gcc / clang)

### 54.2 指令

```bash
# 直接 native
mvn package -Dnative

# 透過 container build
mvn package -Dnative -Dquarkus.native.container-build=true
```

產出: `target/my-app-1.0.0-SNAPSHOT-runner` (原生執行檔)。

### 54.3 設定

```properties
quarkus.native.additional-build-args=--no-fallback,--report-unsupported-elements-at-runtime
quarkus.native.enable-http-url-handler=true
quarkus.native.enable-vm-inspection=false

# Image name
quarkus.native.container-image.name=myorg/myapp
```

### 54.4 限制

- Reflection 必須顯式宣告
- Dynamic class loading 有限制
- JDBC driver 須支援 (大多主流可)
- Hibernate 通常沒問題

---

## 55. Container Image (Docker / Podman / JIB)

```xml
<dependency>
    <groupId>io.quarkus</groupId>
    <artifactId>quarkus-container-image-docker</artifactId>  <!-- 或 container-image-podman / container-image-jib -->
</dependency>
```

```properties
quarkus.container-image.build=true
quarkus.container-image.push=true
quarkus.container-image.group=myorg
quarkus.container-image.name=transfer-app
quarkus.container-image.tag=1.0.0
quarkus.container-image.registry=registry.example.com
```

```bash
mvn package -Dquarkus.container-image.build=true
```

產出 `myorg/transfer-app:1.0.0` image。

### 55.1 Dockerfile 自動生成

Quarkus 預設會在 `target/Dockerfile` 產出:

```dockerfile
FROM registry.access.redhat.com/ubi8/openjdk-17:1.18
ENV LANGUAGE='en_US:en'
COPY --chown=185 target/quarkus-app/lib/main /deployments/lib/main
COPY --chown=185 target/quarkus-app/lib/boot /deployments/lib/boot
COPY --chown=185 target/quarkus-app/quarkus-run.jar /deployments/quarkus-run.jar
EXPOSE 8080
USER 185
ENTRYPOINT ["java", "-jar", "/deployments/quarkus-run.jar"]
```

---

## 56. Kubernetes 部署 (kubernetes extension)

```xml
<dependency>
    <groupId>io.quarkus</groupId>
    <artifactId>quarkus-kubernetes</artifactId>
</dependency>
```

```bash
mvn package -Dquarkus.kubernetes.deploy=true
```

產出 `target/kubernetes/` 含:

- `kubernetes.yml` - Deployment + Service
- 包含 liveness/readiness probe (`/q/health/live`, `/q/health/ready`)
- 自動從 `application.properties` 提取 image name、port

### 56.1 進階設定

```properties
quarkus.kubernetes.namespace=myapp
quarkus.kubernetes.replicas=3
quarkus.kubernetes.service-type=LoadBalancer
quarkus.kubernetes.image-pull-policy=Always
quarkus.kubernetes.env.vars.db-host=postgres
quarkus.kubernetes.env.secrets.db-password=my-secret
```

### 56.2 OpenShift

```xml
<dependency>
    <groupId>io.quarkus</groupId>
    <artifactId>quarkus-openshift</artifactId>
</dependency>
```

### 56.3 knative

```xml
<dependency>
    <groupId>io.quarkus</groupId>
    <artifactId>quarkus-knative</artifactId>
</dependency>
```

---

## 57. ConfigMapping (強型別設定,Quarkus 3.x 新)

```java
@ConfigMapping(prefix = "my.app")
public interface MyConfig {
    String name();
    int port();
    @WithName("max-threads")
    int maxThreads();
    Optional<String> description();
    Database database();

    interface Database {
        String host();
        int port();
    }
}
```

```properties
my.app.name=my-app
my.app.port=8080
my.app.max-threads=10
my.app.database.host=db
my.app.database.port=5432
```

```java
@Inject MyConfig config;
config.name();          // "my-app"
config.database().host();  // "db"
```

---

## 58. ConfigSource 自訂

實作 `org.eclipse.microprofile.config.spi.ConfigSource`:

```java
public class MyConfigSource implements ConfigSource {
    @Override
    public Set<String> getPropertyNames() { return Set.of("my.key"); }

    @Override
    public String getValue(String name) {
        if ("my.key".equals(name)) return "value";
        return null;
    }

    @Override
    public String getName() { return "MyConfigSource"; }

    @Override
    public int getOrdinal() { return 250; }
}
```

註冊到 `META-INF/services/org.eclipse.microprofile.config.spi.ConfigSource`:

```
com.example.MyConfigSource
```

> 這就是 transfer-app 的 `PlatformConfigSource`,ordinal 250,高於 `application.properties`。

---

## 59. Lifecycle Event 完整列表

```java
@Observes @Initialized(ApplicationScoped.class) void initAll(@Priority(100) Object event) { ... }
@Observes @BeforeDestroyed(ApplicationScoped.class) void beforeDestroy() { ... }
@Observes @Destroyed(ApplicationScoped.class) void destroyed() { ... }

@Observes StartupEvent  // Quarkus 應用就緒
@Observes ShutdownEvent  // 關機中
@Observes PreShutdownEvent  // 關機前 (Vert.x 還在)

@Observes ConfigurationEvent
@Observes KogitoProcessInstanceEvent  // 流程事件 (kogito)
@Observes @Initialized(RequestScoped.class)  // 每次 HTTP 請求開始
@Observes @Destroyed(RequestScoped.class)  // 每次 HTTP 請求結束
```

---

## 60. Build Step 進階

### 60.1 自訂 Quarkus Extension

transfer-app 的 `platform-extensions` 就是**自訂 extension**。三個 Maven 模組:

1. `xxx-deployment` 模組
2. `xxx` (runtime) 模組
3. `xxx-deployment/src/main/resources/META-INF/quarkus-extension.properties`

`quarkus-extension.properties`:

```
deployment-artifact=org.kie.kogito:my-extension-deployment:10.2.0
```

### 60.2 Build Item 互動

```java
@BuildStep
@Produce(MyDataBuildItem.class)
MyDataBuildItem produce() { return new MyDataBuildItem(...); }

@BuildStep
@Consume(MyDataBuildItem.class)
void consume(MyDataBuildItem item) { ... }
```

### 60.3 常見 BuildItem

| BuildItem | 用途 |
| :--- | :--- |
| `FeatureBuildItem` | 註冊 feature flag (用於 `/q/info`) |
| `GeneratedClassBuildItem` | 產 Java class |
| `GeneratedResourceBuildItem` | 產 resource |
| `SystemPropertyBuildItem` | 設系統屬性 |
| `BeanContainerBuildItem` | CDI container 引用 |
| `IndexDependencyBuildItem` | 加 index 依賴 |
| `RuntimeConfigBuildItem` | runtime config |
| `HibernateOrmIntegrationStaticInitListenerBuildItem` | Hibernate 修補 |

---

## 61. Kogito / SonataFlow 整合

### 61.1 加入

```xml
<dependency>
    <groupId>org.apache.kie.sonataflow</groupId>
    <artifactId>sonataflow-quarkus</artifactId>
</dependency>
<dependency>
    <groupId>org.kie</groupId>
    <artifactId>kie-addons-quarkus-process-management</artifactId>
</dependency>
<dependency>
    <groupId>org.kie</groupId>
    <artifactId>kie-addons-quarkus-source-files</artifactId>
</dependency>
```

### 61.2 寫 `.sw.yaml`

```yaml
id: my-workflow
version: '1.0'
specVersion: '0.8'
name: My Workflow
start: HelloState
states:
  - name: HelloState
    type: operation
    actions:
      - name: greet
        functionRef:
          refName: greetFunction
          arguments:
            name: '${ .name }'
    transition: EndState
  - name: EndState
    type: inject
    data:
      greeting: "hello, world"
    end: true

functions:
  - name: greetFunction
    operation: 'service:com.example.Greeter::greet'
    type: custom
```

### 61.3 CDI Service

```java
@ApplicationScoped
public class Greeter {
    public String greet(String name) {
        return "Hello, " + name;
    }
}
```

Kogito codegen 在 build-time 會自動:
- 產生 `MyWorkflowResource` (JAX-RS)
- 產生 `MyWorkflowProcess`
- 對應每個 state 的 Java class

### 61.4 啟動 workflow

```
POST /my-workflow
{ "name": "World" }
```

### 61.5 重要限制 (SonataFlow 10.2.0 + spec 0.8)

不完整實作:
- `Retries` policy
- `Sleep` state
- per-action `Timeouts`
- `resultEventRef`
- output schema validation
- `type: rest` OpenAPI addon 4xx 寫死拋例外 (要用 `type: custom`)

---

## 62. 多 Profile 設定慣例 (application.properties)

```properties
# 共用
quarkus.application.name=transfer-app
quarkus.http.port=8080

# dev
%dev.quarkus.hibernate-orm.log.sql=true
%dev.quarkus.log.console.format=%d{HH:mm:ss} %-5p [%c{1.}] (%t) %s%e%n

# test
%test.quarkus.http.test-port=8080
%test.quarkus.datasource.jdbc.url=jdbc:sqlite:target/test-reconciliation.db
%test.quarkus.oidc.enabled=false

# prod
%prod.quarkus.log.level=WARN
%prod.quarkus.log.file.path=/var/log/transfer-app/app.log
%prod.quarkus.hibernate-orm.database.generation=validate
```

啟用:

```bash
mvn quarkus:dev                              # 自動用 %dev.
mvn quarkus:test                              # 自動用 %test.
mvn package -Dquarkus.profile=prod            # 正式用 %prod.
```

---

## 63. Static Files 處理

`src/main/resources/META-INF/resources/` 為 web root:

```
META-INF/resources/
├── index.html        → http://localhost:8080/
├── dashboard.html    → http://localhost:8080/dashboard.html
├── css/style.css     → http://localhost:8080/css/style.css
└── js/app.js         → http://localhost:8080/js/app.js
```

> transfer-app 的 `index.html`、`dashboard.html`、`instances.html` 都走這個機制。

---

## 64. HTTPS / TLS

```properties
quarkus.http.port=8443
quarkus.http.ssl.port=8443
quarkus.http.ssl.certificate.files=server.crt
quarkus.http.ssl.certificate.key-files=server.key
quarkus.http.ssl.certificate.key-store-password=secret

# 信任所有 client (測試用)
quarkus.tls.trust-all=true
```

> transfer-app 用 `quarkus.tls.trust-all=true` 因為 workflow 透過 HTTPS 呼叫外部 API,但測試環境用自簽憑證。

---

## 65. CORS

```properties
# 全域開
quarkus.http.cors=true
quarkus.http.cors.origins=http://localhost:3000
quarkus.http.cors.methods=GET,POST,PUT,DELETE
quarkus.http.cors.headers=accept,authorization,content-type
quarkus.http.cors.exposed-headers=Content-Disposition

# 關閉 (transfer-app)
quarkus.http.cors.enabled=false
```

---

## 66. 優化與調校

### 66.1 啟動時間

```properties
# 關閉不必要的功能
quarkus.banner.enabled=false
quarkus.console.disable-input=true
```

### 66.2 記憶體

```properties
# JVM 參數
quarkus.jvm.args=-Xmx2g -XX:+UseG1GC

# Native
quarkus.native.memory-fraction=0.6
```

### 66.3 GC log

```properties
quarkus.jvm.args=-Xlog:gc*:file=logs/gc.log
```

### 66.4 連線池

```properties
quarkus.datasource.jdbc.max-size=20
quarkus.datasource.jdbc.min-size=2
quarkus.datasource.jdbc.acquisition-timeout=5
quarkus.datasource.jdbc.background-validation-interval=300
```

---

## 67. 常見進階模式

### 67.1 Repository Pattern

```java
@ApplicationScoped
public class UserRepository {
    @Inject EntityManager em;

    public User findById(Long id) {
        return em.find(User.class, id);
    }

    public List<User> findByStatus(Status s) {
        return em.createQuery("FROM User u WHERE u.status = :s", User.class)
            .setParameter("s", s)
            .getResultList();
    }
}
```

### 67.2 Strategy Pattern via CDI

```java
public interface PaymentProcessor {
    PaymentResult pay(Order order);
}

@ApplicationScoped @Named("stripe")
public class StripeProcessor implements PaymentProcessor { ... }

@ApplicationScoped @Named("paypal")
public class PaypalProcessor implements PaymentProcessor { ... }

@Inject @Named("stripe") PaymentProcessor processor;
```

### 67.3 Multi-tenancy

```properties
quarkus.hibernate-orm.multitenant=DATABASE
quarkus.hibernate-orm.tenant-identifier-resolver=...
```

### 67.4 gRPC

```xml
<dependency>
    <groupId>io.quarkus</groupId>
    <artifactId>quarkus-grpc</artifactId>
</dependency>
```

---

## 68. Quarkus 對 transfer-app 的影響

| Quarkus 機制 | 在 transfer-app 的角色 |
| :--- | :--- |
| quarkus-maven-plugin | 觸發 build-time augmentation |
| quarkus-resteasy | JAX-RS Resource (A16229Resource 等) |
| quarkus-resteasy-jackson | JSON 序列化 |
| quarkus-smallrye-openapi | OpenAPI + SwaggerFilter |
| quarkus-smallrye-health | /q/health |
| quarkus-arc | CDI 容器 (SagaApiService, AuditLogService 等) |
| quarkus-hibernate-orm (transitive) | Data Index ORM |
| quarkus-agroal (transitive) | DataSource 連線池 |
| quarkus-vertx (transitive) | HTTP server 8080 |
| quarkus-kubernetes | K8s 部署描述 |

---

## 69. 推薦資源

| 資源 | 用途 |
| :--- | :--- |
| [quarkus.io/guides](https://quarkus.io/guides) | 官方 guide,所有 extension 都有 |
| [quarkus.io/guides/cdi-reference](https://quarkus.io/guides/cdi-reference) | CDI 詳細 |
| [quarkus.io/guides/hibernate-orm](https://quarkus.io/guides/hibernate-orm-panache) | JPA 詳細 |
| [quarkus.io/guides/messaging](https://quarkus.io/guides/messaging) | Kafka 整合 |
| [quarkus.io/guides/kubernetes](https://quarkus.io/guides/kubernetes) | K8s 部署 |
| [kogito.kie.org](https://kogito.kie.org/) | Kogito / SonataFlow 官方 |
| [serverlessworkflow.io](https://serverlessworkflow.io/) | CNCF spec |

---

## 70. Quarkus vs Spring Boot 對照表

| 功能 | Quarkus | Spring Boot |
| :--- | :--- | :--- |
| 啟動 | 0.5-2s | 3-10s |
| Native | 支援 GraalVM | 透過 Spring Native (有限) |
| 標準 | Jakarta EE / MicroProfile | Spring 專屬 |
| Config | `application.properties` + `application.yaml` | `application.properties` / `.yaml` |
| Profile | `%dev.%test.%prod.` 前綴 | `spring.profiles.active` |
| DI | CDI (`@ApplicationScoped`) | Spring (`@Service`) |
| REST | JAX-RS (`@Path`) | Spring MVC (`@RestController`) |
| ORM | Hibernate + Panache | Hibernate + Spring Data JPA |
| Transaction | `@Transactional` | `@Transactional` |
| Test | `@QuarkusTest` | `@SpringBootTest` |
| Reactive | Mutiny (`Uni` / `Multi`) | Reactor (`Mono` / `Flux`) |
| Build | `quarkus-maven-plugin` | `spring-boot-maven-plugin` |
| 產出 | `quarkus-app/` 目錄 | fat jar |

---

## 71. 快速開始模板 (最小可運行 Quarkus)

```xml
<!-- pom.xml -->
<project>
    <modelVersion>4.0.0</modelVersion>
    <groupId>com.example</groupId>
    <artifactId>my-app</artifactId>
    <version>1.0.0</version>

    <properties>
        <maven.compiler.release>17</maven.compiler.release>
        <quarkus.platform.version>3.27.2</quarkus.platform.version>
    </properties>

    <dependencyManagement>
        <dependencies>
            <dependency>
                <groupId>io.quarkus.platform</groupId>
                <artifactId>quarkus-bom</artifactId>
                <version>${quarkus.platform.version}</version>
                <type>pom</type>
                <scope>import</scope>
            </dependency>
        </dependencies>
    </dependencyManagement>

    <dependencies>
        <dependency>
            <groupId>io.quarkus</groupId>
            <artifactId>quarkus-arc</artifactId>
        </dependency>
        <dependency>
            <groupId>io.quarkus</groupId>
            <artifactId>quarkus-resteasy</artifactId>
        </dependency>
        <dependency>
            <groupId>io.quarkus</groupId>
            <artifactId>quarkus-resteasy-jackson</artifactId>
        </dependency>
        <dependency>
            <groupId>io.quarkus</groupId>
            <artifactId>quarkus-junit5</artifactId>
            <scope>test</scope>
        </dependency>
        <dependency>
            <groupId>io.rest-assured</groupId>
            <artifactId>rest-assured</artifactId>
            <scope>test</scope>
        </dependency>
    </dependencies>

    <build>
        <plugins>
            <plugin>
                <groupId>io.quarkus.platform</groupId>
                <artifactId>quarkus-maven-plugin</artifactId>
                <version>${quarkus.platform.version}</version>
                <extensions>true</extensions>
                <executions>
                    <execution>
                        <goals>
                            <goal>build</goal>
                            <goal>generate-code</goal>
                        </goals>
                    </execution>
                </executions>
            </plugin>
        </plugins>
    </build>
</project>
```

```java
// src/main/java/com/example/HelloResource.java
package com.example;

import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;

@Path("/hello")
public class HelloResource {
    @GET
    @Produces(MediaType.TEXT_PLAIN)
    public String hello() {
        return "Hello, Quarkus!";
    }
}
```

```properties
# src/main/resources/application.properties
quarkus.http.port=8080
quarkus.application.name=my-app
```

```java
// src/test/java/com/example/HelloResourceTest.java
package com.example;

import io.quarkus.test.junit.QuarkusTest;
import org.junit.jupiter.api.Test;
import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

@QuarkusTest
class HelloResourceTest {
    @Test
    void testHello() {
        given()
            .when().get("/hello")
            .then()
                .statusCode(200)
                .body(equalTo("Hello, Quarkus!"));
    }
}
```

執行:

```bash
mvn quarkus:dev
# 開瀏覽器 http://localhost:8080/hello
```

---

# Part E ─ transfer-app 實例對照表

> 這一章把所有 Maven 與 Quarkus 的概念,對應到 `distribution/transfer-app` 的實際設定,作為活的速查表。

---

## 72. 父 POM (myhello-platform/pom.xml) 解讀

```xml
<groupId>org.acme.platform</groupId>
<artifactId>myhello-platform</artifactId>
<version>1.0.0-SNAPSHOT</version>
<packaging>pom</packaging>             ← packaging=pom 表示這是 aggregator
```

| 概念 | 對應位置 |
| :--- | :--- |
| packaging=pom | parent 是 aggregator,不打包 |
| `<modules>` 7 個 | 編譯 DAG 起點 |
| `<properties>` 全域變數 | `quarkus.platform.version=3.27.2` 等 |
| `<dependencyManagement>` | import quarkus-bom + kogito-bom + 內部 BOM |
| `<pluginManagement>` | 統一管理 maven-compiler、surefire、quarkus-maven-plugin 版本 |
| `<build><plugins>` | jandex-maven-plugin 預設綁定所有子模組 |
| `<repositories>` | Maven Central + Apache Public |

---

## 73. 子模組 POM 對照

### 73.1 platform-common/pom.xml

```xml
<parent>
    <groupId>org.acme.platform</groupId>
    <artifactId>myhello-platform</artifactId>
    <version>1.0.0-SNAPSHOT</version>
</parent>
<artifactId>platform-common</artifactId>
<!-- 沒 packaging 預設 jar -->
<dependencies>
    <!-- 純 Java,沒有 framework 依賴 -->
</dependencies>
```

### 73.2 platform-security/pom.xml

```xml
<dependencies>
    <dependency>
        <groupId>org.acme.platform</groupId>
        <artifactId>platform-common</artifactId>
        <!-- version 由 parent dependencyManagement 提供 -->
    </dependency>
    <dependency>
        <groupId>io.quarkus</groupId>
        <artifactId>quarkus-arc</artifactId>
        <!-- version 由 quarkus-bom 提供 -->
    </dependency>
    <dependency>
        <groupId>io.quarkus</groupId>
        <artifactId>quarkus-resteasy</artifactId>
    </dependency>
    <dependency>
        <groupId>io.quarkus</groupId>
        <artifactId>quarkus-resteasy-jackson</artifactId>
    </dependency>
    <dependency>
        <groupId>io.quarkus</groupId>
        <artifactId>quarkus-smallrye-openapi</artifactId>
    </dependency>
    <dependency>
        <groupId>org.eclipse.microprofile.openapi</groupId>
        <artifactId>microprofile-openapi-api</artifactId>
    </dependency>
</dependencies>
```

### 73.3 platform-data-index/pom.xml

```xml
<dependencies>
    <dependency>
        <groupId>io.quarkus</groupId>
        <artifactId>quarkus-arc</artifactId>
    </dependency>
    <dependency>
        <groupId>io.quarkus</groupId>
        <artifactId>quarkus-smallrye-health</artifactId>
    </dependency>
    <dependency>
        <groupId>org.xerial</groupId>
        <artifactId>sqlite-jdbc</artifactId>
        <!-- version 3.45.1.0 由 parent -->
    </dependency>
    <dependency>
        <groupId>org.hibernate.orm</groupId>
        <artifactId>hibernate-community-dialects</artifactId>
    </dependency>
    <dependency>
        <groupId>org.kie</groupId>
        <artifactId>kogito-addons-quarkus-data-index-sqlite</artifactId>
        <!-- version 由 kie.version -->
    </dependency>
    <dependency>
        <groupId>org.apache.kie.sonataflow</groupId>
        <artifactId>sonataflow-quarkus</artifactId>
    </dependency>
</dependencies>
```

### 73.4 transfer-app/pom.xml (重點)

```xml
<dependencies>
    <!-- platform 層 -->
    <dependency><groupId>org.acme.platform</groupId><artifactId>platform-security</artifactId></dependency>
    <dependency><groupId>org.acme.platform</groupId><artifactId>platform-data-index</artifactId></dependency>
    <!-- domain 層 -->
    <dependency><groupId>org.acme.platform</groupId><artifactId>transfer-workflow</artifactId></dependency>
    <dependency><groupId>org.acme.platform</groupId><artifactId>transfer-samples</artifactId></dependency>
    <dependency><groupId>org.acme.platform</groupId><artifactId>reconciliation-api</artifactId></dependency>
    <!-- mock 層 (頂層 mocks/transfer-mock,外部系統模擬器) -->
    <dependency><groupId>org.acme.platform</groupId><artifactId>transfer-mock</artifactId></dependency>
    <!-- Quarkus 選用 -->
    <dependency><groupId>io.quarkus</groupId><artifactId>quarkus-kubernetes</artifactId></dependency>
    <!-- test -->
    <dependency><groupId>io.quarkus</groupId><artifactId>quarkus-junit5</artifactId><scope>test</scope></dependency>
    <dependency><groupId>io.rest-assured</groupId><artifactId>rest-assured</artifactId><scope>test</scope></dependency>
</dependencies>

<build>
    <resources>
        <resource><directory>src/main/resources</directory></resource>
        <resource><directory>../../domain-transfer/transfer-workflow/src/main/resources</directory></resource>
        <resource><directory>../../domain-transfer/transfer-samples/src/main/resources</directory></resource>
    </resources>
    <plugins>
        <plugin>
            <artifactId>maven-resources-plugin</artifactId>
            <executions>
                <execution>
                    <id>sync-domain-resources</id>
                    <phase>initialize</phase>
                    <goals><goal>copy-resources</goal></goals>
                    <configuration>
                        <outputDirectory>${project.basedir}/src/main/resources</outputDirectory>
                        <overwrite>true</overwrite>
                        <resources>
                            <resource><directory>../../domain-transfer/transfer-workflow/src/main/resources</directory></resource>
                            <resource><directory>../../domain-transfer/transfer-samples/src/main/resources</directory></resource>
                        </resources>
                    </configuration>
                </execution>
            </executions>
        </plugin>
        <plugin>
            <groupId>io.quarkus.platform</groupId>
            <artifactId>quarkus-maven-plugin</artifactId>
            <!-- version 從 parent pluginManagement -->
        </plugin>
    </plugins>
</build>
```

> **沒有顯式 `<packaging>`**: Quarkus 預設會把它當成 `quarkus-app` 形式。

---

## 74. application.properties 設定對照

| 設定 | 作用 | 章節 |
| :--- | :--- | :--- |
| `quarkus.http.port=8080` | HTTP port | §28 |
| `quarkus.http.host=0.0.0.0` | 綁所有介面 | §28 |
| `quarkus.http.cors.enabled=false` | 關 CORS | §65 |
| `quarkus.log.file.enabled=true` | 開檔案 log | §33 |
| `quarkus.log.file.path=${MYHELLO_LOGS_DIR:logs}/transfer-app.log` | log 路徑 | §33 |
| `quarkus.log.file.rotation.max-file-size=10M` | log 輪替 | §33 |
| `mp.openapi.filter=com.example.platform.security.SonataFlowSecurityConfig$SwaggerFilter` | OpenAPI filter | §38 |
| `quarkus.hibernate-orm.database.generation=none` | 不自動建表 | §41 |
| `quarkus.hibernate-orm.schema-management.strategy=none` | 不驗 schema | §41 |
| `kogito.sw.functions.callAaaService.scheme=https` | SonataFlow function host | §61 |
| `kogito.sw.functions.callApiViaOpenAPI.protocol=http` | MyOpenApiService host | §61 |
| `quarkus.tls.trust-all=true` | 信任所有 TLS | §64 |
| `%test.quarkus.http.test-port=8080` | 測試時 port | §34 |
| `%test.quarkus.datasource.jdbc.url=jdbc:sqlite:target/test-reconciliation.db` | 測試用 SQLite | §15 |
| `%test.quarkus.oidc.enabled=false` | 測試關 OIDC | §15 |
| `quarkus.index-dependency.platform-common.group-id=...` | Jandex index 依賴 | §60 |

---

## 75. 編譯指令流程

### 75.1 一般環境

```bash
cd /path/to/myhello-platform
mvn clean package -DskipTests
```

執行流程:

```
mvn 解析 reactor
  → 依賴圖拓樸排序
  → wave 1~4 依序編譯 13 個模組
  → 每個模組跑:
      validate → initialize (maven-resources-plugin 同步) 
      → process-sources → compile → process-classes (jandex + quarkus:generate-code)
      → process-test-sources → test-compile
  → 最後 transfer-app 跑 package:
      quarkus:build (所有 @BuildStep 觸發)
      quarkus:build 組裝 target/quarkus-app/
```

### 75.2 離線環境

```bash
./offline-build.sh
# 等同於
mvn clean package -o -Dmaven.repo.local=./offline-packages/maven-repo "$@"
```

### 75.3 開發模式

```bash
cd distribution/transfer-app
mvn quarkus:dev
```

### 75.4 跑測試

```bash
# 跑 transfer-app 自己的測試
cd distribution/transfer-app
mvn test

# 跑全部模組的測試
cd myhello-platform
mvn verify
```

---

## 76. 部署指令

```bash
# 1. 編譯 (見 75)
mvn clean package -DskipTests

# 2. 跑起來
java -jar distribution/transfer-app/target/quarkus-app/quarkus-run.jar

# 3. 驗證
curl -X POST http://localhost:8080/saga2-transfer-workflow \
  -H "Content-Type: application/json" \
  -d '{"Account_A":"A123","Account_B":"B123","AMT":100}'

# 4. 看 OpenAPI
open http://localhost:8080/q/openapi

# 5. 看 Health
curl http://localhost:8080/q/health

# 6. 看 Data Index GraphQL
open http://localhost:8080/q/graphql-ui

# 7. 看對帳查詢
curl "http://localhost:8080/api/reconciliation/records?status=SUCCESS"

# 8. 匯出 CSV
curl "http://localhost:8080/reconciliation/export-csv?status=SUCCESS"
```

---

## 77. 常見 Quarkus 命令

```bash
# 列已裝 extension
cd distribution/transfer-app
mvn quarkus:list-extensions

# 加新 extension (互動)
mvn quarkus:add-extension

# 加 Redis (直接指定)
mvn quarkus:add-extension -Dextension=quarkus-redis-client

# 產 K8s 部署描述
mvn package -Dquarkus.kubernetes.deploy=false
ls target/kubernetes/

# 產 Docker image
mvn package -Dquarkus.container-image.build=true

# 跑 native build
mvn package -Dnative
```

---

## 78. 故障排查對照表

| 現象 | 工具 / 設定 | 章節 |
| :--- | :--- | :--- |
| 啟動失敗 | `mvn quarkus:dev` 開 `quarkus.log.level=DEBUG` | §36 |
| 依賴衝突 | `mvn dependency:tree -Dincludes=...` | §16 |
| OpenAPI 找不到 operation | 檢查 `mp.openapi.filter` 設定 | §38 |
| Data Index 時間解析錯誤 | 檢查 `SqliteZonedDateTimeIntegrationListener` log | §42 |
| Workflow 啟動失敗 | 檢查 `.sw.yaml` 是否在 classpath,看 `quarkus.log.category."org.kie".level=DEBUG` | §61 |
| 連線不到 DB | `quarkus.datasource.jdbc.url` 是否被 `${MYHELLO_DATA_DIR}` 正確展開 | §28 |
| 測試 port 衝突 | `%test.quarkus.http.test-port` | §15 |
| 編譯慢 | 用 `mvn -T 4` 平行,確認 `~/.m2/settings.xml` 有 mirror | §5 |
| 啟動慢 | `quarkus.banner.enabled=false`、移除多餘 extension | §66 |
| 找不 bean | 確認 `@ApplicationScoped`、確認 jandex 索引包含該模組 (`quarkus.index-dependency.*`) | §29 |
| Native build 失敗 | `--report-unsupported-elements-at-runtime` 看錯誤 | §54 |
| Container 啟動失敗 | 看 `docker logs <container>`,檢查 `target/Dockerfile` | §55 |

---

## 79. transfer-app 完整依賴鏈視覺化

```mermaid
graph LR
    subgraph "Parent BOM (myhello-platform)"
        PB["platform-* 內部 BOM"]
    end

    subgraph "Quarkus BOM 3.27.2"
        QB["quarkus-bom"]
    end

    subgraph "Kogito BOM 10.2.0"
        KB["kogito-bom"]
    end

    subgraph "transfer-app classpath"
        T1["platform-common"]
        T2["platform-security"]
        T3["platform-data-index"]
        T4["transfer-mock"]
        T5["transfer-workflow"]
        T6["transfer-samples"]
        T7["reconciliation-api"]
    end

    subgraph "Quarkus 執行期"
        Q1["quarkus-arc"]
        Q2["quarkus-resteasy"]
        Q3["quarkus-resteasy-jackson"]
        Q4["quarkus-smallrye-openapi"]
        Q5["quarkus-smallrye-health"]
        Q6["quarkus-hibernate-orm"]
        Q7["quarkus-agroal"]
        Q8["quarkus-vertx"]
        Q9["quarkus-kubernetes"]
    end

    subgraph "Kogito 執行期"
        K1["sonataflow-quarkus"]
        K2["kie-addons-quarkus-process-management"]
        K3["kie-addons-quarkus-source-files"]
        K4["kogito-addons-quarkus-data-index-sqlite (修補)"]
        K5["kogito-addons-quarkus-data-index-persistence-sqlite (修補)"]
    end

    subgraph "第三方"
        S1["sqlite-jdbc 3.45.1.0"]
        S2["hibernate-community-dialects"]
        S3["jackson-databind / jackson-dataformat-yaml"]
        S4["slf4j-api / jboss-logging"]
    end

    QB --> Q1
    QB --> Q2
    QB --> Q3
    QB --> Q4
    QB --> Q5
    QB --> Q6
    QB --> Q7
    QB --> Q8
    QB --> Q9
    KB --> K1
    KB --> K2
    KB --> K3
    KB --> K4
    KB --> K5
    PB --> T1
    PB --> T2
    PB --> T3
    PB --> T4
    PB --> T5
    PB --> T6
    PB --> T7

    T1 --> T2
    T1 --> T3
    T1 --> T4
    T1 --> T5
    T1 --> T6
    T1 --> T7
    T4 --> T5
    T4 --> T6
    T7 --> T5

    Q1 --> T3
    Q1 --> T2
    Q2 --> T2
    Q3 --> T2
    Q4 --> T2
    Q5 --> T3
    Q6 --> T3
    K1 --> T3
    K1 --> T5
    K1 --> T6
    K2 --> T5
    K2 --> T6
    K3 --> T5
    K3 --> T6
    K4 --> T3
    K5 --> T3
    S1 --> T3
    S2 --> T3
    S3 --> T2
    S4 --> T3
```

---

## 80. 快速對照表 (常用速查)

### 80.1 Maven 命令 vs 對應章節

| 命令 | 章節 |
| :--- | :--- |
| `mvn clean package -DskipTests` | §4 |
| `mvn clean install` | §4 |
| `mvn test` | §4, §21 |
| `mvn dependency:tree` | §16 |
| `mvn help:effective-pom` | §16 |
| `mvn -pl transfer-app -am` | §5 |
| `mvn -o clean package` | §20 |
| `mvn -DskipTests` | §4 |
| `mvn -T 4` | §5 |
| `mvn -X` (debug) | §4 |

### 80.2 Quarkus 命令 vs 對應章節

| 命令 | 章節 |
| :--- | :--- |
| `mvn quarkus:dev` | §36 |
| `mvn quarkus:test` | §34 |
| `mvn quarkus:list-extensions` | §26 |
| `mvn quarkus:add-extension` | §26 |
| `mvn quarkus:build` | §35 |
| `mvn package -Dnative` | §54 |
| `mvn package -Dquarkus.container-image.build=true` | §55 |
| `mvn package -Dquarkus.kubernetes.deploy=true` | §56 |

### 80.3 application.properties 設定 vs 章節

| 設定 | 章節 |
| :--- | :--- |
| `quarkus.http.port` | §28 |
| `quarkus.datasource.*` | §41 |
| `quarkus.hibernate-orm.*` | §41 |
| `quarkus.log.*` | §33 |
| `quarkus.http.cors.*` | §65 |
| `quarkus.smallrye-openapi.*` | §38 |
| `kogito.sw.functions.*` | §61 |
| `quarkus.index-dependency.*` | §60 |
| `mp.openapi.filter` | §38 |
| `%test.` 前綴 | §15 |
| `quarkus.jvm.args` | §66 |
| `quarkus.native.*` | §54 |
| `quarkus.kubernetes.*` | §56 |

### 80.4 Java Annotation vs 章節

| Annotation | 套件 | 章節 |
| :--- | :--- | :--- |
| `@ApplicationScoped` | jakarta.enterprise.context | §29 |
| `@Inject` | jakarta.inject | §29 |
| `@ConfigProperty` | microprofile.config.inject | §28 |
| `@Path` | jakarta.ws.rs | §30 |
| `@GET` / `@POST` | jakarta.ws.rs | §30 |
| `@Provider` | jakarta.ws.rs.ext | §31 |
| `@Priority` | jakarta.annotation | §31 |
| `@Liveness` | microprofile.health | §37 |
| `@Readiness` | microprofile.health | §37 |
| `@StartupEvent` / `@ShutdownEvent` | quarkus.runtime | §29, §59 |
| `@Transactional` | jakarta.transaction | §41 |
| `@BuildStep` | quarkus.deployment.annotations | §60 |
| `@Record` | quarkus.runtime.annotations | §35 |
| `@QuarkusTest` | quarkus.test.junit | §34 |

---

> **文件結束 — MAVEN-QUARKUS-REFERENCE.md**
> 80 章節,5 個 Part,完整覆蓋 Maven 基礎 + 進階 + Quarkus 基礎 + 進階 + transfer-app 實例對照
