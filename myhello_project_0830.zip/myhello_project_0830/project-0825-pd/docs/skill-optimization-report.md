# Workflow 整併與 Skill 自我優化報告 (v2.1)

> **專案**: `project-0825-pd` / `draft-omni-cash-transaction`  
> **日期**: 2026-08-30  
> **架構**: SonataFlow / Kogito 10.2.0 (Quarkus 3.8.6 / 3.27.2)  
> **目標**: 達成全自動端到端需求整合、測試除錯閉環，並將踩坑經驗左移回寫至 Skills 知識庫。

---

## 一、 端到端整併與驗收成果摘要

1. **需求與架構**:
   - 整合 `credit-card-counter-cash-repayment-requirement.md` (v2.2) 之 **Mode B (Parent + 2 Child Subflows)** 架構。
   - 產出標準套件 `draft-omni-cash-transaction/`（含 OpenAPI 規格、Workflow YAML、JSON Schema、Flyway DDL、JAX-RS Mock、@QuarkusTest）。
2. **多模組建置與測試**:
   - `mvn compile` / `mvn test` 全 22 模組 **BUILD SUCCESS**。
   - 總計 **53 個單元與整合測試案例**（含 Parent P1~P4、Child WF-A A1~A6、Child WF-B B1~B3、Saga2、RetryTest 等）全數通過（0 Failures, 0 Errors）。
3. **E2E Smoke Test 驗收**:
   - 啟動 Quarkus Dev Profile 於 Port 8080，於 4 秒內完成健康檢查（`/q/health` 回傳 200）。
   - 依序執行 5 大核心情境驗收：
     - **P1** (格式錯誤 operationType=C) ➔ HTTP 400 `REJECTED_VALIDATION`
     - **A1** (正常正向繳款) ➔ HTTP 200 `SUCCESS`（Core + CC 主機 track_id 正常綁定）
     - **P4** (Parent 級冪等重送相同 SequenceNumber) ➔ HTTP 200 `IDEMPOTENT_REPLAY`
     - **B1** (反向當日主動取消) ➔ HTTP 200 `CANCELLED`（Core + CC 反向沖銷成功）
     - **B2** (找不到原交易序號) ➔ HTTP 500 `LOOKUP_FAILED`
   - SQLite `workflow_execution_log` 與 `vw_omni_cash_transaction_reconciliation` 審計資料與對帳視圖成功落地。

---

## 二、 踩坑紀錄與根本原因分析 (RCA)

在自動化執行與測試閉環中，共診斷並修復了以下 4 大核心問題：

### 1. 通路代碼過度約束陷阱 (`paymentSourceCode`)
* **現象**: 執行 A1/B1/P4 等測試時，API 全數被攔截並回傳 HTTP 400 `REJECTED_VALIDATION`。
* **根因**: `ValidateInput` 正則表達式 `^[JKPIAE][A-Za-z0-9]{3}$` 要求字串長度固定為 4 且開頭必須為指定英文字母；但官方 API 規格 (`OmniRepaymentAPI.md`) 範例為 `"2500P"`（5 字元，前綴為通路代號 2500 + 來源碼 P）。
* **修復**: 將正則放寬為標準通路字串格式 `^[A-Za-z0-9]{1,10}$`。

### 2. jq `tonumber` 遇到非純數字哨兵引發 Runtime Exception
* **現象**: 測試 A3 (Core 業務拒絕) 與 B3 時，預期回傳 `finalStatus: FAILED`，實際卻為 `null`。
* **根因**: Workflow 為了測試業務拒絕，輸入 `amount: "FAIL_000011758"` 作為 Mock 哨兵；但在 Switch State 中，條件式直接執行 `($a | tonumber) <= 0`。由於 jq 無法將 `FAIL_...` 解析為數字，拋出未捕捉的 Runtime Exception，導致狀態機異常中斷。
* **修復**: 將條件改寫為防禦性表達式：
  `((.amount // "") as $a | ($a == "0" or $a == "0000000000" or (($a | startswith("FAIL_") | not) and ($a | tonumber) <= 0)))`。

### 3. 測試案例硬編碼序號觸發 Parent 冪等攔截
* **現象**: `testA6ReconciliationView` 呼叫 `testA1RepaymentSuccess` 時斷言失敗，預期 `SUCCESS` 卻得到 `IDEMPOTENT_REPLAY`。
* **根因**: 測試案例硬編碼了靜態序號 `"CA_1234567890000015061655"`，當第一個測試寫入 Audit Log 後，第二個測試再次使用相同序號即被 `IdempotencyService` 判定為重送交易。
* **修復**: 獨立測試案例全面改用動態序號（`"CA_123456789" + System.nanoTime()`），唯有明確驗證冪等性的測試 (`testP4`) 才重送同一序號。

### 4. 平台預檢腳本正則誤報 (False Positive)
* **現象**: 執行 `vibe-workflow-design-v2` 6.2 預檢時，`child-deposit.sw.yaml` 誤報包含 `.result.X`。
* **根因**: 檢查腳本之跨行正則匹配過寬，將後續 State 變數名稱（如 `.coreResult.status`）誤判為 `.result.`。
* **修復**: 修正預檢正規式為精準匹配 `actionDataFilter: results: '... .result.<field>'`。

---

## 三、 Skills 知識庫自我優化內容

依據「左移原則」，本次遭遇問題已全數回寫並升級至專案 `.skills/` 知識庫：

### 1. 對 `vibe-workflow-design-v2` 的升級
* **更新 `SKILL.md`**:
  - 自我檢查清單擴充至 **18 項 Self-Checks**（新增 7.16 API 範例正則相容、7.17 測試動態序號、7.18 jq tonumber 哨兵保護）。
* **更新 `references/01-platform-checks/06-mock-sentinel-vs-input-validation.md`**:
  - 增補「陷阱 2: jq `tonumber` 遇到 Sentinel 字串導致 Runtime Exception」章節與安全寫法範例。
* **更新 `references/02-self-check/self-check-list.md`**:
  - 增加 7.16~7.18 檢查項目與自動檢查指令。

### 2. 對 `sonataflow-integration` 的升級
* **更新 `SKILL.md`**:
  - 在「失敗模式速查表」新增 3 條常見錯誤與標準解法：
    1. `Expected status code <200> but was <400>`（通路代碼過窄）
    2. `finalStatus: null 在業務失敗分支`（jq tonumber 哨兵拋錯）
    3. `Expected: SUCCESS Actual: IDEMPOTENT_REPLAY`（測試序號碰撞）

---

---

## 四、 未來整併任意業務 Workflow 之最佳實踐 (Best Practices)

1. **設計期正則驗證「寬進嚴出」**:
   - 欄位驗證（如代碼、編號）切忌以單一業務假設定死長度與前綴，務必對照官方 API 文件中的 `Data example`。
2. **jq 運算子全面防禦化**:
   - 在 Serverless Workflow 條件式中使用 `tonumber`、`length` 等轉換函式時，一律加上預設值或前綴守衛（如 `tonumber? // 0`）。
3. **測試獨立性與冪等隔絕**:
   - 開發 @QuarkusTest 時，任何涉及真實或 Mock 冪等服務的測試，必須以 `System.nanoTime()` 或 `UUID` 隔離序號，確保測試之間零耦合。

---

## 五、 第二輪自動化演進：跨行即時轉帳業務 (`interbank_fund_transfer`)

### 1. 業務場景與架構設計
- **業務名稱**: 跨行即時轉帳與沖正業務 (Interbank Instant Fund Transfer & Reversal)
- **目錄結構**:
  - 需求端點: `requirement-interbank/` (含 11 欄位 Parent API、核心借貸 API、財金清算 API)
  - Draft 產物: `draft-interbank-fund-transfer/` (含 3 個 Serverless Workflow YAML、Schemas、Mocks、DB View 與測試)
- **架構模式**: 採用 Mode B 階層式架構
  - **Parent**: `interbank_fund_transfer` (負責 11 欄位檢核、Parent 級冪等檢查、分流調度、狀態收斂與 Audit Log 寫入)
  - **Child WF-A**: `interbank_transfer_out` (正向 Saga 兩階段調度：核心扣款 ➔ 財金清算；失敗執行反向退款回沖)
  - **Child WF-B**: `interbank_transfer_reversal` (反向沖正調度：查詢原交易狀態 ➔ 財金沖正 ➔ 核心補款 ➔ 標記原交易已取消)

### 2. 本輪踩坑與修復實錄 (Gotchas & Fixes)

| 序號 | 遇到的技術問題 / 異常現象 | 根本原因分析 | 解決方案與左移預防措施 |
|---|---|---|---|
| 1 | `NullPointerException: getStart() is null` | Kogito 10.2.0 SW 解析器要求 root 層級必須顯式定義 `start: <StateName>`，若省略會直接拋 NPE 導致編譯或啟動失敗 | 在 `vibe-workflow-design-v2` 新增 **Self-Check 7.19**，所有 SW YAML 頂層強制加入 `start: <StateName>` |
| 2 | `ClassCastException: class String cannot be cast to JsonNode` | Java 服務類別（如 `IdempotencyService`）定義了多載方法 `findBySequenceNumber(String, Object)` 與 `(JsonNode)`。若 workflow YAML 傳參缺少其中一個 key，Kogito 生成代碼會嘗試強制轉型為 JsonNode 失敗 | 在 `vibe-workflow-design-v2` 新增 **Self-Check 7.20**，呼叫 Service Function 時參數鍵值需完整對齊 Java 簽名 (`workflowId` 與 `businessKey`) |
| 3 | `sqlite3.OperationalError: no such column: updated_at` | 在產出 DB View Migration 時，自動參照了標準欄位 `updated_at`，但 SQLite 原生 `workflow_execution_log` 主表僅定義 `created_at` | 修正 View 定義，移除 `updated_at`，並在設計規範中統一審計日誌欄位標準 |

### 3. 本輪驗收結果統計
- **單元與整合測試**: **58 / 58 測試全數通過** (`transfer-app` + `reconciliation-app` + `saga2-transfer-workflow` + `omni_cash_transaction` + `interbank_fund_transfer`)
- **E2E 驗收測試**: 5 大核心情境驗收全綠（P1 參數檢核攔截 400、A1 正常跨行轉出 200、P4 冪等防重複 200、B1 反向沖正 200、B2 查無原交易 500）
- **DB 審計資料庫**: `workflow_execution_log` 正確落地，`vw_interbank_fund_transfer_reconciliation` 視圖正確彙整 16 筆交易紀錄。
- **Skills 知識庫版本**: `vibe-workflow-design-v2` 升級至 **20 項自我檢查清單 (20 Self-Checks)**，`sonataflow-integration` 失敗模式表同步擴充。

---

## 六、 第三輪自動化演進：外匯即時結匯與沖正業務 (`fx_exchange_settlement`)

### 1. 業務場景與架構設計
- **業務名稱**: 外匯即時結匯與換匯沖正業務 (FX Instant Settlement & Reversal)
- **目錄結構**:
  - 需求端點: `requirement-fx/` (含 11 欄位 Parent API、核心台幣/外幣扣補款 API、外匯清算引擎 API)
  - Draft 產物: `draft-fx-exchange-settlement/` (含 3 個 Serverless Workflow YAML、Schemas、Mocks、DB View 與測試)
- **架構模式**: 採用 Mode B 階層式架構
  - **Parent**: `fx_exchange_settlement` (負責 11 欄位檢核、Parent 級冪等檢查、分流調度、狀態收斂與 Audit Log 寫入)
  - **Child WF-A**: `fx_exchange_settle` (正向 Saga 兩階段調度：核心台幣扣款 ➔ 外匯清算撮合鎖定部位；失敗執行反向台幣回沖退款)
  - **Child WF-B**: `fx_exchange_reversal` (反向沖正調度：查詢原結匯交易 ➔ 外匯部位反向沖銷 ➔ 核心台幣補款 ➔ 標記原交易已取消)

### 2. 本輪踩坑與修復實錄 (Gotchas & Fixes)

| 序號 | 遇到的技術問題 / 異常現象 | 根本原因分析 | 解決方案與左移預防措施 |
|---|---|---|---|
| 1 | `API 呼叫錯誤: 無法確定 API Base URL` | `MyOpenApiService` 解析 Base URL 時，依序查找配置與 OpenAPI `servers[0].url`。若 Spec 省略 `servers:` 且無個別覆寫配置，會拋出找不到 Base URL 異常 | 在 `vibe-workflow-design-v2` 新增 **Self-Check 7.21**，OpenAPI Spec 一律顯式聲明 `servers: - url: http://localhost:8080`；在 `sonataflow-integration` 補充失敗排查指引 |

### 3. 本輪驗收結果統計
- **單元與整合測試**: **63 / 63 測試全數通過** (`transfer-app` + `reconciliation-app` + `saga2-transfer-workflow` + `omni_cash_transaction` + `interbank_fund_transfer` + `fx_exchange_settlement`)
- **E2E 驗收測試**: 5 大核心情境驗收全綠（P1 參數檢核攔截 400、A1 正常換匯 200、P4 冪等防重複 200、B1 反向結匯沖正 200、B2 查無原交易 500）
- **DB 審計資料庫**: `workflow_execution_log` 正確落地，`vw_fx_exchange_settlement_reconciliation` 視圖正確彙整 8 筆交易紀錄。
- **Skills 知識庫版本**: `vibe-workflow-design-v2` 升級至 **21 項自我檢查清單 (21 Self-Checks)**，`sonataflow-integration` 失敗模式表同步擴充。

---

## 七、 第四輪自動化演進：個人信貸即時撥款與沖正業務 (`loan_instant_disbursement`)

### 1. 業務場景與架構設計
- **業務名稱**: 個人信用貸款即時核貸撥款與當日沖正業務 (Personal Loan Instant Disbursement & Reversal)
- **目錄結構**:
  - 需求端點: `requirement-loan/` (含 11 欄位 Parent API、放款主機額度建檔 API、活期存款撥款入帳 API)
  - Draft 產物: `draft-loan-instant-disbursement/` (含 3 個 Serverless Workflow YAML、Schemas、Mocks、DB View 與測試)
- **架構模式**: 採用 Mode B 階層式架構
  - **Parent**: `loan_instant_disbursement` (負責 11 欄位檢核、Parent 級冪等檢查、分流調度、狀態收斂與 Audit Log 寫入)
  - **Child WF-A**: `loan_disburse_payout` (正向 Saga 兩階段調度：放款主機開戶建立額度 ➔ 活存帳戶撥款入帳；失敗執行反向銷帳回沖)
  - **Child WF-B**: `loan_disburse_reversal` (反向沖正調度：查詢原撥款交易 ➔ 活存帳戶扣回本金 ➔ 放款主機銷帳結清 ➔ 標記原交易已取消)

### 2. 成果與零故障驗收
本輪實施嚴格的 **21 項 Self-Checks** 與 **6 項平台相容性預檢**，實現了 **Draft 生成 ➔ 專案整併 ➔ 68 個測試全通過 ➔ E2E 5 大情境全綠「一次通過（Zero-defect on First Try）」** 的卓越成效！

### 3. 本輪驗收結果統計
- **單元與整合測試**: **68 / 68 測試全數通過** (`transfer-app` + `reconciliation-app` + `saga2-transfer-workflow` + `omni_cash_transaction` + `interbank_fund_transfer` + `fx_exchange_settlement` + `loan_instant_disbursement`)
- **E2E 驗收測試**: 5 大核心情境驗收全綠（P1 參數檢核攔截 400、A1 正常信貸撥付 200、P4 冪等防重複 200、B1 反向撥款沖正 200、B2 查無原交易 500）
- **DB 審計資料庫**: `workflow_execution_log` 正確落地，`vw_loan_instant_disbursement_reconciliation` 視圖正確彙整 8 筆交易紀錄。
- **整體整合現況**: `project-0825-pd` 現已成功整合 **4 個大型銀行業務工作流 (Mode B 模式 x 4 = 12 個 Serverless Workflows)**，保持 100% 綠燈與極致的穩定性。



