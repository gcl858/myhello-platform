# `transfer-app` 模組生命週期深度剖析說明書

> **專案名稱**:`myhello-platform` (parent)
> **目標模組**:`distribution/transfer-app`
> **Quarkus 版本**:`3.27.2`
> **SonataFlow / Kogito 版本**:`10.2.0`
> **Java 版本**:`17` (release) / `21` (toolchain)
> **Maven**:`3.9+`
> **文件目的**:從原始碼 → 編譯產物 → JVM 啟動 → Quarkus 啟動管線 → 請求執行 → 服務關機,完整拆解 transfer-app 在整個生命週期內所依賴 / 觸發的 Maven plugin、Quarkus 機制、SonataFlow 引擎、平台模組與第三方套件。

---

## 目錄

### Part 1 ─ 架構總覽 (Architecture Context)

| 章節 | 標題 |
| :--- | :--- |
| 1 | transfer-app 在 myhello-platform 中的位置 |
| 2 | 技術棧與版本矩陣 |

### Part 2 ─ 編譯期生命週期 (Build-time)

| 章節 | 標題 |
| :--- | :--- |
| 3 | Maven Reactor 編譯調度 |
| 4 | Jandex 索引建立 |
| 5 | Quarkus 編譯期增強 (Build-time Augmentation) |
| 6 | 平台擴展處理器鏈 (platform-extensions) |
| 7 | SonataFlow 程式碼生成 |
| 8 | 跨模組資源同步 |
| 9 | `quarkus-app` 產物結構 |

### Part 3 ─ 啟動期生命週期 (Bootstrap)

| 章節 | 標題 |
| :--- | :--- |
| 10 | JVM 啟動與 `quarkus-run.jar` 入口 |
| 11 | Quarkus Runtime 啟動管線 |
| 12 | ConfigSource 載入 |
| 13 | DataSource + Agroal 連線池 + SQLite JDBC |
| 14 | Hibernate ORM 初始化 + 自訂 Dialect |
| 15 | SonataFlow 引擎啟動 |
| 16 | Kogito Data Index 啟動 |
| 17 | RESTEasy + OpenAPI 過濾器載入 |
| 18 | `AuditLogService` 與 SQLite 資料表建立 |

### Part 4 ─ 執行期生命週期 (Runtime)

| 章節 | 標題 |
| :--- | :--- |
| 19 | HTTP 請求接收總流程 |
| 20 | 請求過濾器鏈 |
| 21 | SonataFlow Workflow 入口 |
| 22 | 自訂 Service 反射呼叫 |
| 23 | Saga 業務邏輯執行 |
| 24 | `MyOpenApiService` 動態呼叫 |
| 25 | Audit Log 寫入 |
| 26 | 回應過濾器鏈 |
| 27 | Data Index 雙寫 |

### Part 5 ─ 關機期生命週期 (Shutdown)

| 章節 | 標題 |
| :--- | :--- |
| 28 | 優雅關機訊號 |
| 29 | 資料持久化與 WAL Checkpoint |
| 30 | 資源釋放與 JVM 退出 |

### Part 6 ─ 附錄

| 章節 | 標題 |
| :--- | :--- |
| 31 | 核心模組 / 套件速查表 |
| 32 | 結論與排查指引 |

---

# Part 1 ─ 架構總覽 (Architecture Context)

---

## 第 1 章:transfer-app 在 myhello-platform 中的位置

### 1.1 模組分層與單向依賴

`myhello-platform` 是個**多模組 Maven Reactor**,以 `pom.xml` 為根,內含 7 個子模組,被分成三層:

```
myhello-platform/                                    ← parent POM (packaging=pom)
├── platform-common/                                 ← 共用工具層 (無 framework 依賴)
├── platform-security/                               ← 橫切:OpenAPI filter, SonataFlow security, Response unwrap
├── platform-extensions/                             ← Kogito / Quarkus 擴展與 SQLite 修補原始碼
│   ├── data-index-storage-sqlite/                   ← SQLite 儲存適配器 + 22 個 Flyway SQL
│   ├── kogito-addons-quarkus-data-index-sqlite/     ← Data Index Runtime + Deployment
│   └── kogito-addons-quarkus-data-index-persistence-sqlite/ ← 持久化 Runtime + Deployment
├── platform-data-index/                             ← Kogito Data Index + SQLite 自訂 dialect + 健康檢查
├── domain-transfer/                                 ← Bounded context: 轉帳 (parent)
│   ├── transfer-workflow/                           ← saga-transfer-workflow + saga2-transfer-workflow (+ OpenAPI specs 合約)
│   └── transfer-samples/                            ← OpenAPI/java/rest-workflow 示範
├── domain-reconciliation/                           ← Bounded context: 對帳 (parent)
│   └── reconciliation-api/                          ← ReconciliationResource + CsvExporter + AuditLog
├── mocks/
│   └── transfer-mock/                               ← JAX-RS mock (A16229/A16220 Resource + DTO),外部系統模擬器
└── distribution/                                    ← Runnable Quarkus 應用 (parent)
    ├── transfer-app/                                ← ⭐ 本文件主角
    └── reconciliation-app/
```

**核心不變式** (寫在 README.md 與各 pom.xml 的 description 中):

1. `domain-*` 不反向依賴 `platform-*` (業務只往下)
2. `transfer-*` 不依賴 `reconciliation-*` 內部實作,僅使用 `AuditLogService` 介面
3. `distribution/*` 是**唯一**允許組裝 platform + domain 的地方
4. 無循環依賴

### 1.2 transfer-app 的依賴組合

`distribution/transfer-app/pom.xml` 把以下模組的 classpath 全部收編:

| 依賴模組 | 角色 |
| :--- | :--- |
| `platform-security` | 橫切安全:Swagger filter、Runtime POST-only filter、Response unwrap |
| `platform-data-index` | Kogito Data Index + 自訂 SQLite dialect + `PlatformConfigSource` + `MyLivenessCheck` |
| `transfer-workflow` | saga-transfer-workflow + saga2-transfer-workflow + `SagaApiService` + `MyOpenApiService` + OpenAPI 規格 (specs/) |
| `transfer-samples` | OpenAPI / java / rest 三個示範 workflow |
| `transfer-mock` | A16229 / A16220 外部系統模擬器 JAX-RS Resource + DTO (本機/UAT 測試用) |
| `reconciliation-api` | `AuditLogService`(寫 SQLite) + `ReconciliationResource` + `ReconciliationCsvExporter` |

外加 Quarkus 套件:
- `quarkus-kubernetes` (部署描述,可選)
- `quarkus-junit5` + `rest-assured` (測試)

### 1.3 transfer-app 的「可執行 Quarkus 應用」特性

`distribution/transfer-app/pom.xml` 沒有 `<packaging>pom</packaging>`,也沒有 `<packaging>jar</packaging>`。
它**沒有顯式宣告 packaging**,但因為它**沒有引入 `quarkus-resteasy` 之類產生 main class 的依賴**,Quarkus 的 `quarkus-maven-plugin` 在 `quarkus:build` goal 時會自動把它標記為 `quarkus-app` 形式,並使用內建的 `QuarkusEntryPoint` 作為 `Main-Class`。

最終 `target/quarkus-app/quarkus-run.jar` 是一個**可執行的 fat-jar**,內含:

- `quarkus-run.jar` (主程式)
- `app/` (應用 jar)
- `lib/main/` (執行期依賴)
- `lib/boot/` (啟動器依賴)
- `quarkus/` (Quarkus 框架本身)
- `META-INF/microprofile-config.properties` ... (簡化後的設定)

### 1.4 模組依賴 DAG (Mermaid)

```mermaid
flowchart TD
    Common["platform-common<br/>(公用工具)"]
    Sec["platform-security<br/>(橫切安全)"]
    PExt1["data-index-storage-sqlite<br/>(Kogito Storage)"]
    PExt2["kogito-addons-quarkus-data-index-sqlite<br/>(Kogito Addon)"]
    PExt3["kogito-addons-quarkus-data-index-persistence-sqlite<br/>(Kogito Addon)"]
    PDI["platform-data-index<br/>(Data Index + 自訂 Dialect)"]
    TAPI["transfer-mock<br/>(JAX-RS mock + DTO)"]
    TWF["transfer-workflow<br/>(Saga + Service + OpenAPI specs)"]
    TSAM["transfer-samples<br/>(示範 workflow)"]
    RAPI["reconciliation-api<br/>(Audit + CSV)"]
    TAP["⭐ transfer-app<br/>(Quarkus 入口)"]

    Common --> Sec
    Common --> PDI
    Common --> TWF
    Common --> TSAM
    Common --> RAPI
    RAPI --> TWF
    PExt1 --> PDI
    PExt2 --> PDI
    PExt3 --> PDI

    Sec --> TAP
    PDI --> TAP
    TAPI --> TAP
    TWF --> TAP
    TSAM --> TAP
    RAPI --> TAP
```

---

## 第 2 章:技術棧與版本矩陣

| 類別 | 元件 | 版本 | 在 transfer-app 生命週期的角色 |
| :--- | :--- | :--- | :--- |
| JVM | Java | 17 release / 21 toolchain | compiler-plugin 與 Quarkus runtime |
| 編譯 | Maven | 3.9+ | Reactor + 各 plugin |
| 編譯 | maven-compiler-plugin | 3.15.0 | Java 17 bytecode 編譯 |
| 編譯 | maven-resources-plugin | (內建) | 跨模組資源同步 |
| 編譯 | jandex-maven-plugin | 3.2.7 | CDI bean 索引 |
| 框架 | Quarkus Platform BOM | 3.27.2 | 全家桶版本對齊 |
| 框架 | quarkus-maven-plugin | 3.27.2 | build-time augmentation |
| 框架 | quarkus-arc | (BOM) | CDI / DI |
| 框架 | quarkus-resteasy + jackson | (BOM) | JAX-RS |
| 框架 | quarkus-smallrye-openapi | (BOM) | OpenAPI 文件 |
| 框架 | quarkus-smallrye-health | (BOM) | `/q/health` |
| 框架 | quarkus-kubernetes | (BOM) | k8s 部署描述 |
| 引擎 | Kogito BOM | 10.2.0 | 流程引擎 |
| 引擎 | sonataflow-quarkus | 10.2.0 | CNCF Serverless Workflow 規範 |
| 引擎 | kie-addons-quarkus-process-management | 10.2.0 | Process 引擎管理 |
| 引擎 | kie-addons-quarkus-source-files | 10.2.0 | `.sw.yaml` 資源掃描 |
| 引擎 | kogito-addons-quarkus-data-index-sqlite | 10.2.0 (修補) | Data Index + SQLite |
| 引擎 | kogito-addons-quarkus-data-index-persistence-sqlite | 10.2.0 (修補) | Data Index 持久化 |
| 資料 | xerial sqlite-jdbc | 3.45.1.0 | SQLite JDBC driver |
| 資料 | hibernate-community-dialects | (BOM) | SQLite dialect 基底 |
| 資料 | Hibernate ORM | (BOM) | 6.x |
| 觀測 | JBoss Logging + SLF4J | (BOM) | 日誌 |
| 觀測 | quarkus-logging-file | (BOM) | 檔案日誌輪替 |
| 測試 | quarkus-junit5 | (BOM) | `@QuarkusTest` |
| 測試 | rest-assured | 5.5.0 | REST API 整合測試 |

> **版本來源**: 全部定義於 `pom.xml` (parent) 的 `<properties>` 與 `<dependencyManagement>`。
> `quarkus-bom` 與 `kogito-bom` 以 `import` scope 引入,讓子模組不需重複寫版本號。

### 2.1 一致性原則

- **`quarkus.platform.version = 3.27.2` ↔ `kie.version = 10.2.0`**: SonataFlow 10.2.0 是對應 Quarkus 3.x 的官方 LTS 對齊版本。
- **`maven.compiler.release = 17`**: 編譯期 target bytecode 為 Java 17。
- **`enforcer.skip = true`**: 因 air-gapped 環境內不一定有 enforcer rule 可達,刻意跳過。

### 2.2 跨模組資源座標

```mermaid
flowchart LR
    subgraph Parent["myhello-platform (parent)"]
        CP["compiler-plugin=3.15.0"]
        SP["surefire-plugin=3.5.6"]
        QD["quarkus.platform.version=3.27.2"]
        KV["kie.version=10.2.0"]
        SJ["sqlite-jdbc=3.45.1.0"]
        RA["rest-assured=5.5.0"]
    end

    subgraph Distribution["distribution (parent)"]
        INHERIT["繼承 parent 所有 properties"]
    end

    subgraph TransferApp["⭐ transfer-app"]
        INHERIT --> BOM["import quarkus-bom"]
        BOM --> QK["quarkus-* (BOM 管)"]
        BOM --> KOG["kogito / sonataflow / kie-* (kogito-bom 管)"]
        KOG --> SW["sonataflow-quarkus"]
        SW --> APP["@QuarkusTest + rest-assured"]
    end
```

---

# Part 2 ─ 編譯期生命週期 (Build-time)

> 本部分描述 `mvn clean package -DskipTests` 從觸發到 `target/quarkus-app/quarkus-run.jar` 產出之間,所有套件 / plugin / 引擎的協作。

---

## 第 3 章:Maven Reactor 編譯調度

### 3.1 parent pom 中的 `<modules>` 順序

`myhello-platform/pom.xml` 的模組宣告順序決定了 Reactor 的編譯 DAG:

```xml
<modules>
    <module>platform-common</module>
    <module>platform-security</module>
    <module>platform-extensions</module>
    <module>platform-data-index</module>
    <module>domain-transfer</module>
    <module>domain-reconciliation</module>
    <module>distribution</module>
</modules>
```

Maven Reactor 內部會用拓樸排序,把 7 個一級子模組與其下子模組全部攤平,得到約 13 個專案的有向無環圖 (DAG),然後**平行 / 序列** 執行。Maven 預設每個 module 線程 1 個,但因為模組間強依賴,實際上是「wave」式序列執行。

### 3.2 transfer-app 在編譯 DAG 的位置

`distribution/transfer-app` 是**最後一個被編譯的模組**,因為它需要:

- `platform-security` 已 `install` 到本機 repo
- `platform-data-index` 已 `install`
- `mocks/transfer-mock` 已 `install`
- `domain-transfer/transfer-workflow` 已 `install`
- `domain-transfer/transfer-samples` 已 `install`
- `domain-reconciliation/reconciliation-api` 已 `install`

由於 `pom.xml` 的 `<dependencyManagement>` 已宣告 `platform-*` 與 `transfer-*` 的版本為 `${project.version}`,`transfer-app` 可以直接以 `<artifactId>platform-security</artifactId>` 引用,不需指定版本。

### 3.3 編譯命令

```bash
# 一般編譯
mvn clean package -DskipTests

# 離線環境 (air-gapped)
./offline-build.sh   # 等同 mvn clean package -o -Dmaven.repo.local=./offline-packages/maven-repo
```

### 3.4 編譯流程概覽 (Mermaid)

```mermaid
flowchart TD
    A["mvn clean package 觸發"] --> B["Reactor 解析 modules"]
    B --> C["Wave 1: platform-common"]
    C --> D["Wave 2: platform-security + platform-extensions"]
    D --> E["Wave 3: platform-data-index + domain-transfer/* + domain-reconciliation/*"]
    E --> F["Wave 4: distribution (含 ⭐ transfer-app)"]
    F --> G["Package 階段: quarkus:build → target/quarkus-app/"]

    C --> C1["maven-compiler-plugin → *.class"]
    C --> C2["jandex-maven-plugin → jandex.idx"]

    F --> F1["maven-resources-plugin (initialize)"]
    F1 --> F1a["copy-resources 跨模組 YAML/JSON"]
    F --> F2["quarkus-maven-plugin (package)"]
    F2 --> F2a["generate-code 階段"]
    F2a --> F2a1["Kogito codegen: .sw.yaml → Java"]
    F2 --> F2b["augment 階段"]
    F2b --> F2b1["所有 @BuildStep 觸發"]
    F2 --> F2c["build 階段"]
    F2c --> F2c1["組裝 quarkus-app/ 目錄"]
```

### 3.5 transfer-app 自身的 plugin 觸發順序

讀 `distribution/transfer-app/pom.xml` 的 `<build>` 區塊,transfer-app 編譯會觸發:

| 階段 | Plugin | Goal | 動作 |
| :--- | :--- | :--- | :--- |
| `initialize` | `maven-resources-plugin` | `copy-resources` | 跨模組資源同步 (詳見 Ch8) |
| `generate-sources` | `jandex-maven-plugin` | `jandex` | 為 transfer-app 自身的 `target/classes` 產 jandex 索引 |
| `process-classes` | `quarkus-maven-plugin` | `generate-code` | 觸發 SonataFlow codegen (Ch7) |
| `process-classes` | `quarkus-maven-plugin` | `generate-code-tests` | 對測試類別做 codegen |
| `package` | `quarkus-maven-plugin` | `build` | 執行所有 `@BuildStep` 增強器 (Ch5) |
| `package` | `maven-jar-plugin` (隱含) | `jar` | 打包 `target/transfer-app-1.0.0-SNAPSHOT.jar` |
| `package` | `quarkus-maven-plugin` | `build` (續) | 組裝 `target/quarkus-app/` |

> **注意**: transfer-app 的 pom 內 `<plugins>` 只顯式宣告 `maven-resources-plugin` 與 `quarkus-maven-plugin`。`jandex-maven-plugin` 與 `maven-compiler-plugin` 是透過 parent `pluginManagement` 繼承。

---

## 第 4 章:Jandex 索引建立

### 4.1 為何要 Jandex?

Quarkus 啟動時 (runtime) 會掃描 classpath 內的 class 找 CDI bean、JAX-RS resource、HealthCheck 等。
為了**啟動速度** (不掃描整個 jar),Quarkus 採用 **Jandex 索引**:在編譯期先把每個 jar 內含哪些 annotation / class 索引成 `META-INF/jandex.idx`,執行期直接讀這個小檔。

### 4.2 plugin 設定

在 parent pom 中:

```xml
<plugin>
    <groupId>io.smallrye</groupId>
    <artifactId>jandex-maven-plugin</artifactId>
    <version>3.2.7</version>
    <executions>
        <execution>
            <id>make-index</id>
            <goals><goal>jandex</goal></goals>
        </execution>
    </executions>
</plugin>
```

### 4.3 哪些模組會跑 Jandex

由於 parent 在 `<build><plugins>` 區塊直接綁定 `jandex-maven-plugin`,**所有子模組**(包括 transfer-app)都會在 `process-classes` 階段產出索引檔。

對 transfer-app 而言,Jandex 索引會包含:

- 自身 `src/main/java`(沒 Java 源碼,但繼承自其他模組的 classes 仍會被索引)
- 透過 transitive 進來的 CDI bean:`AuditLogService` (reconciliation-api)、
  `SagaApiService` (transfer-workflow)、
  `MyOpenApiService` (transfer-workflow)、
  `MyLivenessCheck` (platform-data-index)、
  `PlatformConfigSource` (platform-data-index)、
  `SonataFlowSecurityConfig$RuntimeFilter` (platform-security)

### 4.4 跨模組索引合併

Quarkus 在 `quarkus:build` 階段會把所有依賴的 `jandex.idx` 合併成一個**應用級索引**,讓 runtime 用 `SingleIndexManager` O(1) 查找 bean。

```mermaid
flowchart LR
    A1["platform-common/jandex.idx"] --> APP["App Index"]
    A2["platform-security/jandex.idx"] --> APP
    A3["transfer-mock/jandex.idx"] --> APP
    A4["transfer-workflow/jandex.idx"] --> APP
    A5["transfer-samples/jandex.idx"] --> APP
    A6["reconciliation-api/jandex.idx"] --> APP
    A7["platform-data-index/jandex.idx"] --> APP
    APP --> Q["SingleIndexManager (runtime O(1) lookup)"]
```

---

## 第 5 章:Quarkus 編譯期增強 (Build-time Augmentation)

### 5.1 核心概念

Quarkus 的核心哲學是 **"build-time augmentation"**:
> 所有能在編譯期做的事 (reflection scan、proxies、config validation、bean discovery) 都在 `quarkus:build` 時做完,留下可直接執行的 bytecode,大幅縮短 startup time。

執行 `mvn quarkus:build` 會依序跑:

1. **Application classpath 掃描** (透過 Jandex)
2. **`@BuildStep` 拓樸排序**: 把所有 extension 的 processor 排成 DAG
3. **執行每個 `@BuildStep`**: 產出 `BuildItem` (例如 `FeatureBuildItem`、`SystemPropertyBuildItem`、`GeneratedClassBuildItem` ...)
4. **產出 `target/quarkus/generated-bytecode.jar`**: 包含所有 reflection / proxy / bean factory 的預先產生版本

### 5.2 觸發 transfer-app 的 `@BuildStep` 來源

對 transfer-app 而言,以 **dependency → deployment module** 配對來看,所有 `@BuildStep` 都來自 quarkus-* / kogito-* / kie-* / sonataflow-* 這些官方套件,以及本專案的 `platform-extensions` 修補模組。

| 來源 | Processor Class | 角色 |
| :--- | :--- | :--- |
| `quarkus-resteasy` | `ResteasyScanningProcessor` | 掃描 `@Path` 註冊 REST endpoint |
| `quarkus-arc` | `ArcProcessor` | CDI bean discovery、proxy 生成 |
| `quarkus-smallrye-openapi` | `OpenApiProcessor` | 收集 OpenAPI metadata |
| `quarkus-smallrye-health` | `HealthCheckProcessor` | 收集 `@Liveness` / `@Readiness` |
| `quarkus-kubernetes` | `KubernetesProcessor` | 產 k8s 部署描述 (可選) |
| `sonataflow-quarkus` (deployment) | `SonataFlowKogitoCodeGeneratorProcessor` | `.sw.yaml` codegen |
| `sonataflow-quarkus` (deployment) | `SonataFlowProcessor` | 註冊 workflow engine |
| `kie-addons-quarkus-process-management` | 多個 processor | Process 引擎整合 |
| `kogito-addons-quarkus-data-index-sqlite` (deployment) | `SQLiteDataIndexProcessor` | 註冊 Data Index 為 SQLite |
| `kogito-addons-quarkus-data-index-sqlite` (deployment) | `SqliteZonedDateTimeIntegrationProcessor` | 註冊 Hibernate 整合 listener |
| `kogito-addons-quarkus-data-index-persistence-sqlite` (deployment) | `SQLiteDataIndexPersistenceProcessor` | 註冊 SQLite persistence 為 Data Index |
| `data-index-storage-sqlite` | (含 Flyway scripts) | 22 個 Flyway SQL 遷移 |
| `quarkus-hibernate-orm` | `HibernateOrmProcessor` | 設定 dialect / datasource |

### 5.3 `@BuildStep` 範例

以 `platform-extensions` 內的 `SQLiteDataIndexProcessor` 為例:

```java
public class SQLiteDataIndexProcessor extends AbstractKogitoAddonsQuarkusDataIndexProcessor {
    private static final String FEATURE = "kogito-addons-quarkus-data-index-sqlite";

    @BuildStep
    public FeatureBuildItem feature() {
        return new FeatureBuildItem(FEATURE);
    }

    @BuildStep(onlyIf = { IsDevelopment.class })
    CardPageBuildItem createDevUILink(...) { ... }
}
```

`@BuildStep` 接受 `onlyIf` 條件 (例如 `IsDevelopment`)、可選 `onlyIfNot`、可宣告 `@Produces` / `@Consumes` 對應 `BuildItem` 依賴。

### 5.4 build-time 產物

執行 `quarkus:build` 後,`target/` 內會出現:

```
target/
├── classes/                       ← 編譯產出
├── generated-sources/
│   └── annotations/                ← Kogito codegen 產的 Java 源 (.java)
├── generated-test-sources/
│   └── annotations/                ← 測試 codegen
├── quarkus/
│   ├── generated-bytecode.jar      ← ⭐ 預先生成的 bytecode
│   ├── generated-config/
│   ├── generated-resources/
│   └── app/                        ← 預先組裝的應用 classpath metadata
├── transfer-app-1.0.0-SNAPSHOT.jar ← 應用 jar (thin)
└── quarkus-app/                    ← ⭐ 最終可執行 fat-jar 結構
    ├── quarkus-run.jar
    ├── app/
    ├── lib/
    │   ├── boot/
    │   └── main/
    └── quarkus/
```

---

## 第 6 章:平台擴展處理器鏈 (platform-extensions)

`platform-extensions/` 內含 3 個自訂模組,這是本專案**對 Kogito 官方 SQLite addon 的修補**:

### 6.1 模組結構

```
platform-extensions/
├── data-index-storage-sqlite/      ← 純 Runtime (Storage SPI 實作)
│   ├── runtime/                    ← SQLiteStorage 實作 + 22 個 Flyway SQL
│   └── deployment/                 ← (若有) deployment processor
├── kogito-addons-quarkus-data-index-sqlite/
│   ├── runtime/                    ← SqliteZonedDateTimeJavaType + Listener
│   └── deployment/                 ← @BuildStep processor
└── kogito-addons-quarkus-data-index-persistence-sqlite/
    ├── runtime/                    ← Persistence 實作
    └── deployment/                 ← @BuildStep processor
```

### 6.2 `data-index-storage-sqlite` 的內容

此模組是 Kogito Data Index Storage 的 SQLite 實作,內含:
- `SQLiteStorage` / `SQLiteStorageService` (Runtime 端)
- `ContainsSQLFunction` / `CustomFunctionsContributor` (註冊自訂 SQLite 函式)
- `SQLiteJsonPredicateBuilder` (JSON 查詢 SQL builder)
- `SQLiteStorageServiceCapabilities` (宣告 storage 能力)
- `META-INF/kie-flyway.properties` (Flyway 設定)
- 22 個 Flyway SQL 遷移腳本 (`db/migration/`)

### 6.3 `kogito-addons-quarkus-data-index-sqlite` 的關鍵修正

**`SqliteZonedDateTimeIntegrationListener`** 是這層最關鍵的修正:

```java
public class SqliteZonedDateTimeIntegrationListener implements HibernateOrmIntegrationStaticInitListener {
    // 在 Hibernate Metadata 初始化時:
    // 1. 註冊自訂 ZonedDateTime JavaType (能處理 Long epoch ms 與 numeric string)
    // 2. 反射清除 ProcessInstanceEntity / UserTaskEntity / JobEntity 上
    //    每個 ZonedDateTime 欄位的 cached Type,讓下次 getType() 重新解析 → 走自訂 JavaType
    @Override
    public void onMetadataInitialized(Metadata metadata, BootstrapContext bootstrapContext, ...) {
        TypeConfiguration typeConfig = bootstrapContext.getTypeConfiguration();
        JavaType<ZonedDateTime> customType = new SqliteZonedDateTimeJavaType();
        typeConfig.getJavaTypeRegistry().addDescriptor(customType);
        // ... reflection 清 cache ...
    }
}
```

解決了 Kogito Data Index 在 Hibernate 6.x + xerial SQLite JDBC 上,讀取 `ZonedDateTime` 欄位時的 **"Error parsing time stamp"** bug。

### 6.4 deployment 端的 processor

`SqliteZonedDateTimeIntegrationProcessor` 在 `@BuildStep` 階段把上面的 listener **註冊到 Hibernate 整合 SPI**:

```java
@BuildStep
@Record(ExecutionTime.STATIC_INIT)
HibernateOrmIntegrationStaticInitListenerBuildItem sqliteZdtListener() {
    return new HibernateOrmIntegrationStaticInitListenerBuildItem(
        new SqliteZonedDateTimeIntegrationListener()
    );
}
```

`@Record(ExecutionTime.STATIC_INIT)` 表示這個 listener 會在 Quarkus **靜態初始化階段** (見 Ch11) 被執行,而不是 runtime application 階段。

---

## 第 7 章:SonataFlow 程式碼生成 (Kogito codegen)

### 7.1 觸發點

`sonataflow-quarkus` 的 deployment processor 內含 `KogitoCodeGeneratorProcessor`,它在 `quarkus-maven-plugin:generate-code` goal 時掃描 classpath 上所有 `*.sw.yaml` 與 `*.sw.json` 檔案,為每個 workflow 產出一組 Java 類別。

### 7.2 為何 transfer-app 含 5 個 workflow 源檔

`transfer-app` 的 `src/main/resources/` 內有 5 個 `*.sw.yaml`(由 `maven-resources-plugin` 的 `copy-resources` execution 在 `initialize` 階段從 `domain-transfer/` 同步過來):

- `saga-transfer-workflow.sw.yaml` (v15.0.0, 218 行)
- `saga2-transfer-workflow.sw.yaml` (v2.2.0, 449 行)
- `OpenAPI-workflow.sw.yaml`、`java-workflow.sw.yaml`、`rest-workflow.sw.yaml` (示範)

所有 5 個檔案均為**唯讀副本**,實際 canonical source 為 `domain-transfer/transfer-workflow/` 與 `domain-transfer/transfer-samples/`,本身 `transfer-app` 不寫 Java 業務邏輯。

> **同步機制 (v2.2 單一事實來源)**:
> - `copy-resources` execution (`phase=initialize`) 實體複製到 `src/main/resources/`,確保 jandex / quarkus build 等 plugin 透過標準 classpath 找到
> - v2.2 起已移除 `<resources>` 區塊直接納入外部目錄的雙重打包路徑,打包僅經同步後的 `src/main/resources` 單一路徑
> - 同步產物已列入 `.gitignore` 不追蹤;**直接編輯副本會在下一次建置被靜默覆蓋**,一律修改 domain 模組來源

### 7.3 codegen 產出

`KogitoCodeGeneratorProcessor` 會對每個 workflow 在 `target/generated-sources/annotations/` 產出:

| 產出檔 | 用途 |
| :--- | :--- |
| `WorkflowApplication.java` | 應用程式入口 (此專案無) |
| `<WorkflowId>Resource.java` | JAX-RS 自動註冊 `POST /<workflowId>` endpoint |
| `<WorkflowId>Process.java` | 對應 Kogito `Process` 介面,封裝 state machine |
| `<WorkflowId>ProcessInstanceResource.java` | GET/DELETE `/<workflowId>/{id}` |
| `WorkflowInput` / `WorkflowOutput` (POJO) | 對應 schema |
| `*State` 類別 (每個 state 一個) | 對應 Serverless Workflow 的 `states` 區塊 |

例如 `saga2-transfer-workflow.sw.yaml` 會產生 `Saga2TransferWorkflowResource.java` 與 `Saga2TransferWorkflowProcess.java` 等。

### 7.4 specVersion 與 Kogito 引擎支援

`transfer-workflow` 內的 workflow 都宣告 `specVersion: '0.8'`,這是 CNCF Serverless Workflow 規範版本。
Kogito / SonataFlow 10.2.0 對 specVersion 0.8 的支援度見 `sonataflow-workflow-expert` skill 中的「10 項清單」,部分功能 (Retries、Sleep、per-action Timeouts、`resultEventRef`、output schema) 在該版本**未完整實作**。

`transfer-app` 的兩個 production workflow 都刻意避開這些未實作特性,改用:
- `type: custom` function (取代 OpenAPI addon 的 4xx 寫死拋例外問題)
- `type: switch` + `dataConditions` + `defaultCondition` (取代 Retries)
- `stateDataFilter.output` (取代 schema-based output)

### 7.5 codegen 與 quarkus 整合

```mermaid
flowchart LR
    A["transfer-workflow/<br/>saga-transfer-workflow.sw.yaml"] --> B["Quarkus: quarkus:generate-code"]
    C["transfer-workflow/<br/>saga2-transfer-workflow.sw.yaml"] --> B
    D["transfer-samples/<br/>*.sw.yaml (3 個)"] --> B
    B --> E["KogitoCodeGeneratorProcessor"]
    E --> F1["target/generated-sources/annotations/<br/>SagaTransferWorkflowResource.java"]
    E --> F2["target/generated-sources/annotations/<br/>Saga2TransferWorkflowResource.java"]
    E --> F3["Saga2TransferWorkflowProcess.java"]
    E --> F4["State classes (CallA16229State, ...)"]
    F1 --> G["javac 編譯成 .class"]
    F2 --> G
    F3 --> G
    F4 --> G
    G --> H["target/classes/<br/>(Quarkus 應用 classpath)"]
```

---

## 第 8 章:跨模組資源同步 (Maven Resources Plugin)

### 8.1 問題

transfer-app 的 workflow YAML 與 OpenAPI 規格**不在自身 `src/main/resources/`**,而是在:
- `domain-transfer/transfer-workflow/src/main/resources/*.sw.yaml`
- `domain-transfer/transfer-workflow/src/main/resources/specs/*.yaml`

但 Quarkus runtime 只能讀 transfer-app 自己 jar 內的 classpath。所以必須在編譯期把這些資源**拷貝到 transfer-app 的 `target/classes/`**。

### 8.2 設定

`distribution/transfer-app/pom.xml` (v2.2 起:`<resources>` 僅保留自身目錄,打包單一路徑;同步全權交由 `copy-resources` execution):

```xml
<build>
    <!-- 單一事實來源:canonical source 在 domain 模組,
         本模組副本為建置產物(已 gitignore),直接編輯會被靜默覆蓋 -->
    <resources>
        <resource><directory>src/main/resources</directory></resource>
    </resources>
    <plugins>
        <plugin>
            <artifactId>maven-resources-plugin</artifactId>
            <executions>
                <execution>
                    <id>sync-domain-resources</id>
                    <phase>initialize</phase>
                    <goals><goal>copy-resources</goal></goals>
                    <configuration>
                        <outputDirectory>${project.basedir}/src/main/resources</outputDirectory>
                        <overwrite>true</overwrite>
                        <resources>
                            <resource><directory>../../domain-transfer/transfer-workflow/src/main/resources</directory></resource>
                            <resource><directory>../../domain-transfer/transfer-samples/src/main/resources</directory></resource>
                        </resources>
                    </configuration>
                </execution>
            </executions>
        </plugin>
    </plugins>
</build>
```

### 8.3 同步動作

**`copy-resources` execution (`phase=initialize`)**: 在**最早階段**就把 domain 模組資源實體複製到 `src/main/resources/`,後續所有 plugin (jandex、quarkus build) 都能透過標準 classpath 找到;`process-resources` 再將其打包進 `target/classes/`。

> v2.2 前:另有 `<resources>` 區塊把外部目錄直接納入 `target/classes/`(雙保險但路徑冗餘),已移除。

### 8.4 同步內容

最終 `distribution/transfer-app/src/main/resources/` 內會有:

```
src/main/resources/
├── application.properties              ← transfer-app 自身
├── OpenAPI-workflow.sw.yaml            ← 同步自 transfer-samples
├── java-workflow.sw.yaml
├── rest-workflow.sw.yaml
├── saga-transfer-workflow.sw.yaml      ← 同步自 transfer-workflow
├── saga2-transfer-workflow.sw.yaml
├── schemas/
│   ├── input-schema.json
│   └── saga-transfer-input-schema.json
├── specs/
│   ├── A16220-api.yaml                 ← 同步自 transfer-workflow (specs 已併入 workflow 模組)
│   ├── A16229-api.yaml
│   └── openapi.yaml                    ← 同步自 transfer-samples
└── META-INF/
    └── resources/                       ← 靜態 HTML
        ├── index.html
        ├── dashboard.html
        └── instances.html
```

---

## 第 9 章:`quarkus-app` 產物結構

`quarkus-maven-plugin:build` 結束後,`distribution/transfer-app/target/` 內含:

```
target/
├── transfer-app-1.0.0-SNAPSHOT.jar   ← thin app jar (含 .class 與自身 resources)
├── quarkus-app/                       ← ⭐ 可執行 fat-jar 結構
│   ├── quarkus-run.jar               ← ⭐ 主程式 (含 Main-Class manifest)
│   ├── app/
│   │   └── transfer-app-1.0.0-SNAPSHOT.jar
│   ├── lib/
│   │   ├── boot/                      ← 啟動器依賴 (Quarkus + Arc + Vert.x 核心)
│   │   │   ├── quarkus-core-3.27.2.jar
│   │   │   ├── quarkus-vertx-3.27.2.jar
│   │   │   ├── quarkus-arc-3.27.2.jar
│   │   │   ├── io.quarkus.bootstrap.runner.QuarkusEntryPoint
│   │   │   └── ... (約 30 個 jar)
│   │   └── main/                      ← 應用依賴 (其餘全部)
│   │       ├── platform-common-1.0.0-SNAPSHOT.jar
│   │       ├── platform-security-1.0.0-SNAPSHOT.jar
│   │       ├── platform-data-index-1.0.0-SNAPSHOT.jar
│   │       ├── transfer-mock-1.0.0-SNAPSHOT.jar
│   │       ├── transfer-workflow-1.0.0-SNAPSHOT.jar
│   │       ├── transfer-samples-1.0.0-SNAPSHOT.jar
│   │       ├── reconciliation-api-1.0.0-SNAPSHOT.jar
│   │       ├── quarkus-resteasy-3.27.2.jar
│   │       ├── quarkus-resteasy-jackson-3.27.2.jar
│   │       ├── quarkus-smallrye-openapi-3.27.2.jar
│   │       ├── quarkus-smallrye-health-3.27.2.jar
│   │       ├── quarkus-hibernate-orm-3.27.2.jar
│   │       ├── quarkus-agroal-3.27.2.jar
│   │       ├── sqlite-jdbc-3.45.1.0.jar
│   │       ├── hibernate-community-dialects-*.jar
│   │       ├── sonataflow-quarkus-10.2.0.jar
│   │       ├── kie-addons-quarkus-process-management-10.2.0.jar
│   │       ├── kie-addons-quarkus-source-files-10.2.0.jar
│   │       ├── kogito-addons-quarkus-data-index-sqlite-10.2.0.jar
│   │       ├── kogito-addons-quarkus-data-index-persistence-sqlite-10.2.0.jar
│   │       ├── jackson-databind-*.jar
│   │       ├── jackson-dataformat-yaml-*.jar
│   │       ├── slf4j-api-*.jar
│   │       ├── jboss-logging-*.jar
│   │       └── ... (約 100+ jars)
│   └── quarkus/                       ← Quarkus 框架內部
└── classes/                           ← maven compile 產出
```

### 9.1 各目錄職責

| 目錄 | 內容 | 加載時機 |
| :--- | :--- | :--- |
| `quarkus-run.jar` | 啟動器 (含 `QuarkusEntryPoint` 與 manifest) | 第一個被 JVM 載入 |
| `app/` | 應用本身 (含 classpath 索引 `META-INF/jandex.idx`) | 啟動後 |
| `lib/boot/` | Quarkus 啟動核心 | 啟動期 (initial → static_init) |
| `lib/main/` | 其餘所有依賴 | 應用執行期 |
| `quarkus/` | 框架內部 (例如 generated config) | 整個生命週期 |

### 9.2 Manifest

`quarkus-run.jar` 的 `META-INF/MANIFEST.MF` 內關鍵欄位:

```manifest
Main-Class: io.quarkus.bootstrap.runner.QuarkusEntryPoint
Class-Path: app/transfer-app-1.0.0-SNAPSHOT.jar lib/boot/quarkus-core-3.27.2.jar ...
```

`QuarkusEntryPoint` 內部會:
1. 讀 `app/` jar
2. 載入 `lib/boot/*` (Quarkus 核心)
3. 呼叫 `io.quarkus.runtime.Quarkus.run(...)` 開始啟動管線

---

# Part 3 ─ 啟動期生命週期 (Bootstrap)

> 從 `java -jar quarkus-run.jar` 觸發到「應用 ready to accept HTTP」之間,所有 Quarkus 啟動階段、平台初始化、Hibernate 修補、SonataFlow 引擎註冊的完整協作。

---

## 第 10 章:JVM 啟動與 `quarkus-run.jar` 入口

### 10.1 啟動命令

```bash
java -jar distribution/transfer-app/target/quarkus-app/quarkus-run.jar
```

或開發模式:

```bash
cd distribution/transfer-app
mvn quarkus:dev -DskipTests
```

### 10.2 入口鏈

```
java -jar quarkus-run.jar
  ↓ Main-Class: io.quarkus.bootstrap.runner.QuarkusEntryPoint
QuarkusEntryPoint.main()
  ↓ 解析 quarkus-app/ 目錄結構
  ↓ 設定 ClassLoader 為 QuarkusClassLoader
  ↓ 呼叫 io.quarkus.runtime.Quarkus.run()
Quarkus.run(args, Quarkus.runClass)
  ↓ 載入 io.quarkus.runner.ApplicationImpl (編譯期產生的 entry point)
ApplicationImpl.run(args, ...)
  ↓ 呼叫 io.quarkus.runtime.Application.start(ArcContainer)
```

### 10.3 QuarkusClassLoader

`QuarkusClassLoader` 是一個自訂的 URLClassLoader 子類,負責:

- 從 `quarkus-run.jar` 的 manifest 讀 `Class-Path`
- 依序載入 `app/` → `lib/boot/` → `lib/main/` → `quarkus/`
- 支援**熱替換** (dev mode 才需要)
- 為 Quarkus 提供**隔離**的 classpath 視角

### 10.4 JVM 啟動期工具鏈

```mermaid
sequenceDiagram
    participant CLI as java CLI
    participant JRE as JVM
    participant QEP as QuarkusEntryPoint
    participant QCL as QuarkusClassLoader
    participant QR as Quarkus.run()

    CLI->>JRE: java -jar quarkus-run.jar
    JRE->>JRE: 解析 MANIFEST.MF → Main-Class
    JRE->>QEP: QuarkusEntryPoint.main(String[])
    QEP->>QCL: new QuarkusClassLoader(...)
    QCL->>QCL: 從 manifest 讀 Class-Path
    QCL->>QCL: 依序掃描 app/, lib/boot/, lib/main/, quarkus/
    QEP->>QR: Quarkus.run(args, Application)
    QR->>QR: 載入 io.quarkus.runtime.Application impl
```

---

## 第 11 章:Quarkus Runtime 啟動管線

### 11.1 七大階段

Quarkus 的啟動分為**七個**明確定義的階段,每階段的 `@Record` annotation 會被編譯成 bytecode 嵌入 framework 內:

| 階段 | 名稱 | 何時執行 | 在 transfer-app 的對應 |
| :--- | :--- | :--- | :--- |
| 1 | **Bootstrap** | Quarkus 啟動最初 | 載入 JVM system properties、bootstrap class loader |
| 2 | **Augment** | (build-time, 不在 runtime) | 已在 mvn 階段做完 |
| 3 | **Static Init** | runtime 啟動早期 | 註冊 `PlatformConfigSource` (ordinal 250)、Hibernate static init listener |
| 4 | **Runtime Config Init** | 解析所有 `application.properties` | 載入 `platform-data-index` 與 `transfer-app` 的 properties |
| 5 | **Runtime Init** | 啟動 CDI container | ARC 啟動、Jandex 索引載入、bean 註冊 |
| 6 | **Application Start** | 應用就緒 | `StartupEvent` 觸發 → `AuditLogService.onStart` 建表 |
| 7 | **Running** | 接受 HTTP 請求 | — |

### 11.2 ApplicationImpl 編譯產物

`quarkus-maven-plugin:build` 會根據所有 extension 的 `@Record(ExecutionTime.RUNTIME_INIT)` 等 annotation,動態組合出 `io.quarkus.runner.ApplicationImpl` 類別。這個類別含有:

```java
public class ApplicationImpl implements Application {
    @Override
    public int run(String... args) throws Exception {
        // 1. 載入 ConfigSource
        // 2. 初始化 Datasource
        // 3. 初始化 Hibernate ORM
        // 4. 初始化 ARC (CDI)
        // 5. 初始化 RESTEasy
        // 6. 初始化 SonataFlow 引擎
        // 7. 初始化 Kogito Data Index
        // 8. 啟動 Vert.x HTTP server
        // 9. 觸發 StartupEvent
    }
}
```

### 11.3 啟動流程 (Mermaid)

```mermaid
flowchart TD
    A["Quarkus.run()"] --> B["Static Init 階段"]
    B --> B1["註冊 PlatformConfigSource<br/>(ordinal=250)"]
    B --> B2["註冊 HibernateOrmIntegrationStaticInitListener<br/>(SqliteZonedDateTimeIntegrationListener)"]
    B --> C["Runtime Config Init"]
    C --> C1["讀 application.properties (application layer)"]
    C --> C2["讀 platform-data-index 內 base properties"]
    C --> C3["讀 transfer-app 內 override properties"]
    C --> C4["MP Config 系統整合所有來源"]
    C --> D["Runtime Init 階段"]
    D --> D1["啟動 Agroal DataSource<br/>(SQLite + WAL PRAGMA)"]
    D --> D2["啟動 Hibernate ORM<br/>(KogitoSQLiteDialect)"]
    D --> D3["觸發 SqliteZonedDateTimeIntegrationListener<br/>(清除 SimpleValue.type cache)"]
    D --> D4["啟動 ARC (CDI) — 從 jandex.idx 載入 beans"]
    D --> D5["啟動 RESTEasy (JAX-RS 掃描)"]
    D --> D6["啟動 SonataFlow Engine"]
    D --> D7["啟動 Kogito Data Index"]
    D --> D8["啟動 Vert.x HTTP server :8080"]
    D --> E["Application Start"]
    E --> E1["觸發 StartupEvent"]
    E --> E2["AuditLogService.onStart() → 建表 + 視圖 + WAL PRAGMA"]
    E --> E3["平台 / 業務 bean 開始接受請求"]
    E --> F["Running"]
```

### 11.4 啟動日誌樣本

實際 transfer-app 啟動時,典型日誌順序 (從 `transfer-app.log` 觀察):

```
[Quarkus] started in 2.345s
[INFO] PlatformConfigSource 設定 MYHELLO_DATA_DIR=.../data
[INFO] PlatformConfigSource 設定 MYHELLO_LOGS_DIR=.../logs
[INFO] [AuditLogService] 使用 data 目錄: .../data
[INFO] [AuditLogService] SQLite 通用資料表 (WAL 模式) workflow_execution_log 及對帳視圖 vw_saga_reconciliation 已就緒
[INFO] SqliteZonedDateTimeIntegrationListener: onMetadataInitialized called
[INFO] SqliteZonedDateTimeIntegrationListener: registered custom ZonedDateTime JavaType
[INFO] SqliteZonedDateTimeIntegrationListener: cleared cached Type on N SimpleValues
[INFO] listening on: http://0.0.0.0:8080
```

---

## 第 12 章:ConfigSource 載入

### 12.1 MP Config 載入順序

MicroProfile Config 規範定義的 `ConfigSource` ordinal:

| Ordinal | 來源 |
| :--- | :--- |
| 400 | JVM system properties (`-Dfoo=bar`) |
| 300 | 環境變數 (OS env) |
| **250** | **`PlatformConfigSource` (本專案自訂)** |
| 100 | `application.properties` (Quarkus 預設) |
| 其他 | 應用內自訂來源 |

### 12.2 PlatformConfigSource

`org.acme.platform.dataindex.PlatformConfigSource` 在 `META-INF/services/org.eclipse.microprofile.config.spi.ConfigSource` 內被宣告,ordinal 250,在 Quarkus 啟動的 **Static Init** 階段被讀取。

它的任務是**確保 `MYHELLO_DATA_DIR` 與 `MYHELLO_LOGS_DIR` 一定有值**:

```java
public PlatformConfigSource() {
    try {
        String dataDir = PlatformPaths.ensureDataDirectory().toAbsolutePath().toString();
        String logsDir = PlatformPaths.ensureLogsDirectory().toAbsolutePath().toString();
        properties.put(PlatformPaths.DATA_DIR_ENV, dataDir);  // MYHELLO_DATA_DIR
        properties.put(PlatformPaths.LOGS_DIR_ENV, logsDir);  // MYHELLO_LOGS_DIR
    } catch (Exception e) {
        // 降級處理:filesystem 權限不足時不讓應用 crash
    }
}
```

### 12.3 應用設定最終來源

`platform-data-index/src/main/resources/application.properties` 內含 base 設定,`distribution/transfer-app/src/main/resources/application.properties` 用同 key 覆寫。最終值由 MP Config 系統**最後寫入的 wins** (但有 ordinal 控制優先級)。

例如:

```
# platform-data-index/application.properties
quarkus.datasource.jdbc.url=jdbc:sqlite:${MYHELLO_DATA_DIR:data}/reconciliation.db

# distribution/transfer-app/application.properties
quarkus.http.port=8080
quarkus.log.file.path=${MYHELLO_LOGS_DIR:logs}/transfer-app.log
```

兩個檔案的內容會**合併**到同一個 ConfigSource 集合 (ordinal 100),`transfer-app` 的 `quarkus.http.port` 不會覆蓋 base (因為 base 沒設)。

### 12.4 ConfigSource 載入時序

```mermaid
sequenceDiagram
    participant QC as Quarkus Static Init
    participant MP as MP Config SPI
    participant PCS as PlatformConfigSource
    participant PROP as application.properties
    participant EN as Environment / -D
    participant DS as Datasource

    QC->>MP: getConfig()
    MP->>PCS: load(ordinal=250)
    PCS->>PCS: PlatformPaths.ensureDataDirectory()
    PCS-->>MP: { MYHELLO_DATA_DIR=..., MYHELLO_LOGS_DIR=... }
    MP->>PROP: load(ordinal=100)
    PROP-->>MP: { quarkus.http.port=8080, ... }
    MP->>EN: load(ordinal=300, 400)
    EN-->>MP: { ... }
    MP-->>DS: quarkus.datasource.jdbc.url = jdbc:sqlite:${MYHELLO_DATA_DIR}/reconciliation.db
    Note over DS: 已解析為絕對路徑
```

---

## 第 13 章:DataSource + Agroal 連線池 + SQLite JDBC

### 13.1 設定值

`platform-data-index/application.properties` 內:

```properties
quarkus.datasource.db-kind=other
quarkus.datasource.jdbc.driver=org.sqlite.JDBC
quarkus.datasource.jdbc.url=jdbc:sqlite:${MYHELLO_DATA_DIR:data}/reconciliation.db
quarkus.datasource.jdbc.max-size=1
quarkus.datasource.jdbc.additional-jdbc-properties.foreign_keys=true
quarkus.datasource.jdbc.additional-jdbc-properties.journal_mode=WAL
quarkus.datasource.jdbc.additional-jdbc-properties.synchronous=NORMAL
```

### 13.2 為何 `db-kind=other` + 手動 driver

- Quarkus 3.27.x **沒有內建 `db-kind=sqlite`** 選項
- `kogito-addons-quarkus-data-index-sqlite` 期待 JDBC driver 是 `org.sqlite.JDBC` (xerial)
- 因此顯式指定

### 13.3 Agroal 連線池

`quarkus-agroal` 是 Quarkus 內建的 JDBC 連線池 (取代 HikariCP)。設定 `max-size=1` 是因為:

- SQLite 單檔案,理論上不適合高並行
- 但 `journal_mode=WAL` 支援 **1 writer + 多 reader**,所以可以讓多個 transaction 同時 read

> **WAL 模式**:
> - 寫入者把資料先寫到 `reconciliation.db-wal`
> - 讀者直接讀 main db file
> - 兩者不會互鎖 → 提升 throughput

### 13.4 PRAGMA 設定

`additional-jdbc-properties` 會在每次取得連線時執行:

| PRAGMA | 意義 |
| :--- | :--- |
| `foreign_keys=true` | 啟用 FK 約束 (SQLite 預設 OFF) |
| `journal_mode=WAL` | 啟用 WAL 模式 |
| `synchronous=NORMAL` | 寫入 sync 模式:NORMAL 兼顧效能與安全 (非 OFF) |

> ⚠️ **注意**: 這三條 PRAGMA 雖然也會在 `AuditLogService.onStart` 中再次設定,但**連線層**的 PRAGMA 優先,確保**所有**透過 Agroal 取得的連線都有正確配置。

### 13.5 連線池啟動時序

```mermaid
sequenceDiagram
    participant Q as Quarkus Runtime Init
    participant A as AgroalDataSource
    participant SQ as xerial SQLite JDBC
    participant DB as data/reconciliation.db

    Q->>A: 讀 quarkus.datasource.*
    A->>SQ: 註冊 org.sqlite.JDBC driver
    A->>A: 設定 max-size=1
    A->>A: 設定 connection-init-sql (PRAGMA)
    A->>DB: 首次 lazy connection 建立
    SQ->>DB: PRAGMA foreign_keys=true
    SQ->>DB: PRAGMA journal_mode=WAL
    SQ->>DB: PRAGMA synchronous=NORMAL
    A-->>Q: DataSource ready
```

---

## 第 14 章:Hibernate ORM 初始化 + 自訂 Dialect

### 14.1 設定

```properties
quarkus.hibernate-orm.dialect=org.acme.platform.dataindex.KogitoSQLiteDialect
quarkus.hibernate-orm.jdbc.timezone=UTC
quarkus.hibernate-orm.physical-naming-strategy=org.hibernate.boot.model.naming.CamelCaseToUnderscoresNamingStrategy
quarkus.hibernate-orm.database.generation=none
quarkus.hibernate-orm.schema-management.strategy=none
quarkus.hibernate-orm.validate-in-dev-mode=false
```

> **為何 `database.generation=none`**: Kogito Data Index 用 Flyway 管理 schema (`kie.flyway.enabled=true`);若同時讓 Hibernate 自動建表會衝突。
> **為何 `validate-in-dev-mode=false`**: Kogito Data Index SQLite 擴充預設以 `database.generation=validate` 啟動,但 Hibernate 6.x 對 xerial SQLite JDBC driver 回傳的欄位 metadata (`IS_AUTOINCREMENT` / `COLUMN_DEF`) 解析會在 `AbstractInformationExtractorImpl.columnInformation:651` 拋出 `NoSuchElementException`。Flyway 已是 schema 唯一來源 (本檔前段 "Schema 'main' is up to date" 已驗證),關閉 validation 即可消除誤報。

### 14.2 KogitoSQLiteDialect 載入

`org.acme.platform.dataindex.KogitoSQLiteDialect` 繼承自 `org.hibernate.community.dialect.SQLiteDialect`,並在 `contributeTypes` 中:

```java
public class KogitoSQLiteDialect extends SQLiteDialect {
    @Override
    public void contributeTypes(TypeContributions typeContributions, ServiceRegistry serviceRegistry) {
        super.contributeTypes(typeContributions, serviceRegistry);
        typeContributions.contributeJdbcType(SqliteZonedDateTimeJdbcType.INSTANCE);
        typeContributions.contributeJavaType(SqliteZonedDateTimeJavaType.INSTANCE);

        // 註冊 named type 讓 Hibernate 知道 ZonedDateTime 欄位要走自訂實作
        BasicType<ZonedDateTime> customBasicType = new BasicTypeImpl<>(
                SqliteZonedDateTimeJavaType.INSTANCE,
                SqliteZonedDateTimeJdbcType.INSTANCE
        );
        typeContributions.contributeType(customBasicType, "zdt", "ZonedDateTime", ZonedDateTime.class.getName());
    }
}
```

### 14.3 SqliteZonedDateTimeIntegrationListener 介入

`SqliteZonedDateTimeIntegrationListener` 在 `onMetadataInitialized` 時:

1. 從 `BootstrapContext` 取得 `TypeConfiguration`
2. 把 `SqliteZonedDateTimeJavaType` 加入 `JavaTypeRegistry`
3. 走訪 `metadata.getEntityBindings()` 中屬於 `ProcessInstanceEntity` / `UserTaskEntity` / `JobEntity` 的 entity
4. 對每個 `ZonedDateTime` 屬性,**用反射把 `SimpleValue.type` 設為 `null`**
5. 下次 `getType()` 重新解析時,會走到 `contributeType` 註冊的 named type → 走自訂 JavaType

> 這是**修補 Kogito Data Index 在 SQLite + Hibernate 6.x 上讀 ZonedDateTime 失敗**的關鍵。

### 14.4 啟動時序

```mermaid
sequenceDiagram
    participant Q as Quarkus Runtime Init
    participant H as Hibernate ORM
    participant D as KogitoSQLiteDialect
    participant L as SqliteZonedDateTimeIntegrationListener
    participant M as Metadata
    participant TC as TypeConfiguration

    Q->>H: 初始化 ORM
    H->>D: 載入 dialect
    D->>TC: contributeTypes()
    Note over TC: 註冊 SqliteZonedDateTimeJavaType + JdbcType + BasicType
    H->>M: 建構 Metadata (掃描 Kogito entities)
    L->>M: onMetadataInitialized()
    L->>TC: 註冊自訂 JavaType descriptor
    L->>M: 反射清 SimpleValue.type cache
    H-->>Q: ORM ready
```

---

## 第 15 章:SonataFlow 引擎啟動

### 15.1 引擎元件

transfer-app 透過 `sonataflow-quarkus` 與 `kie-addons-quarkus-process-management` 帶入:

- `org.apache.kie.kogito.process.Process` 介面 (代表一個流程定義)
- `org.apache.kie.kogito.process.ProcessInstance` 介面 (代表一個運行實例)
- `org.apache.kie.kogito.process.impl.ProcessRuntimeImpl` (核心 state machine)
- jackson-jq 函式庫 (解析 workflow 的 `${ .x }` 表達式)
- `MVEL` (Serverless Workflow spec 表達式評估備援)
- `kogito-codegen` 產生的 `*Resource` 與 `*Process` 類別

### 15.2 Workflow 註冊流程

Kogito 在啟動時會掃描 `target/generated-sources/annotations/` 內每個 `*Process` 類別,把它註冊到 `ProcessRuntimeImpl` 的內部 map `processesById`。

對 transfer-app 而言,啟動後會有:

| Process ID | Version | Resource Endpoint |
| :--- | :--- | :--- |
| `saga-transfer-workflow` | 15.0.0 | `POST /saga-transfer-workflow` |
| `saga2-transfer-workflow` | 2.2.0 | `POST /saga2-transfer-workflow` |
| `OpenAPI-workflow` | (samples) | `POST /OpenAPI-workflow` |
| `java-workflow` | (samples) | `POST /java-workflow` |
| `rest-workflow` | (samples) | `POST /rest-workflow` |

### 15.3 引擎啟動細節

```mermaid
flowchart TD
    A["sonataflow-quarkus 啟動"] --> B["載入 KogitoProcessEngine"]
    B --> C["掃描 Jandex 找 *Process 類別"]
    C --> D["對每個 Process 建立 ProcessDescriptor"]
    D --> E["註冊到 ProcessRuntimeImpl.processesById"]
    E --> F["準備 jackson-jq evaluator"]
    F --> G["準備 MVEL evaluator"]
    G --> H["建立 ProcessEventListeners"]
    H --> I["Kogito Data Index Producer 註冊 Process 變更事件"]
    I --> J["引擎就緒"]
```

### 15.4 Custom Function 載入

Kogito 啟動時也會掃描所有 `*.sw.yaml` 內宣告的 `functions: [{ type: custom, operation: 'service:...::...' }]`,把 `service:` 標籤對應的 bean 透過反射找到:

- `com.example.transfer.workflow.SagaApiService` (供 `saga-transfer-workflow` 用)
- `com.example.transfer.workflow.MyOpenApiService` (供 `saga2-transfer-workflow` 用)
- `com.example.reconciliation.AuditLogService` (供 `saga2-transfer-workflow` 用)

這些 bean 由 ARC (CDI) 管理,已透過 Jandex 索引到,引擎透過 `Instance<>` lookup 取得。

---

## 第 16 章:Kogito Data Index 啟動

### 16.1 設定

`platform-data-index/application.properties`:

```properties
quarkus.kogito.data-index.graphql.ui.always-include=true
kogito.data-index.blocking=true
quarkus.smallrye-health.management.enabled=false
kie.flyway.enabled=true
kogito.data-index.url=http://localhost:${quarkus.http.port:8080}
sonataflow.devui.isLocalCluster=false
```

### 16.2 啟動步驟

1. **`data-index-storage-sqlite` 啟動**:
   - 建立 `SQLiteStorage` 物件
   - 註冊自訂 SQL 函式 (例如 `JSON_EXTRACT`)
   - 註冊自訂 predicate builder
2. **Flyway 啟動**:
   - 讀取 `META-INF/kie-flyway.properties`
   - 依序執行 22 個 `db/migration/V*.sql` (CREATE TABLE `processes`, `process_instances`, `jobs`, `user_tasks`...)
3. **GraphQL endpoint 註冊**:
   - `POST /graphql` 提供 Process / ProcessInstance / Job / UserTask 查詢
   - 內建 GraphiQL UI
4. **Producer 註冊**:
   - 註冊 `ProcessEventListener` 給 Kogito 引擎
   - 引擎執行 process 時,事件會被送往 Data Index
5. **Health check 註冊**:
   - `MyLivenessCheck` (`@Liveness`) 與 Quarkus 自動產生 DataSource health check

### 16.3 Data Index 啟動時序

```mermaid
sequenceDiagram
    participant Q as Quarkus Runtime Init
    participant DI as Kogito Data Index Addon
    participant ST as SQLiteStorage
    participant FW as Flyway
    participant SF as SonataFlow Engine
    participant EP as /graphql endpoint

    Q->>DI: 啟動 addon
    DI->>ST: new SQLiteStorage()
    ST->>ST: 註冊自訂 SQL functions
    DI->>FW: 啟動 Flyway
    FW->>FW: 執行 V1__init.sql ... V22__xxx.sql
    DI->>EP: 註冊 POST /graphql + GraphiQL
    Q->>SF: 啟動 SonataFlow engine
    SF->>DI: 註冊 ProcessEventListener (雙寫)
    Note over DI: 引擎事件 → Data Index 寫入 SQLite
```

---

## 第 17 章:RESTEasy + OpenAPI 過濾器載入

### 17.1 JAX-RS Resource 掃描

Quarkus 啟動時透過 Jandex 找到所有 `@Path` 註解的 class。對 transfer-app 而言,以下 Resource 會被註冊:

| Class | Path | 端點 | 來源 |
| :--- | :--- | :--- | :--- |
| `A16229Resource` | `/A16229` | `POST /A16229` | transfer-mock |
| `A16220Resource` | `/A16220` | `POST /A16220` | transfer-mock |
| `ReconciliationResource` | `/reconciliation` | `GET/POST /reconciliation/export-csv` | reconciliation-api |
| `ReconciliationAuditResource` | `/api/reconciliation` | `GET /api/reconciliation/records`<br/>`GET /api/reconciliation/files`<br/>`GET /api/reconciliation/files/{filename}` | reconciliation-api |
| `SagaTransferWorkflowResource` (codegen) | `/saga-transfer-workflow` | codegen | transfer-workflow |
| `Saga2TransferWorkflowResource` (codegen) | `/saga2-transfer-workflow` | codegen | transfer-workflow |
| `OpenAPI-workflowResource` (codegen) | `/OpenAPI-workflow` | codegen | transfer-samples |
| `java-workflowResource` (codegen) | `/java-workflow` | codegen | transfer-samples |
| `rest-workflowResource` (codegen) | `/rest-workflow` | codegen | transfer-samples |

加上 Quarkus 自動:
- `/q/health` (SmallRye Health)
- `/q/openapi` (OpenAPI 文件)
- `/q/dev-ui` (Dev mode UI)
- `/q/graphql-ui` (Kogito Data Index GraphiQL)

### 17.2 OpenAPI Filter

`distribution/transfer-app/application.properties`:

```properties
mp.openapi.filter=com.example.platform.security.SonataFlowSecurityConfig$SwaggerFilter
```

這個設定告訴 SmallRye OpenAPI 在生成 `/q/openapi` 文件時,套用 `SonataFlowSecurityConfig$SwaggerFilter` 的 `filterPathItem()`,把 `DELETE` / `PUT` / `PATCH` / `HEAD` 從 OpenAPI 文件中移除 (因為 `RuntimeFilter` 在 runtime 也會拒絕這些方法)。

### 17.3 JAX-RS Provider

Quarkus 啟動時也會掃描 `@Provider` 註解的 class。對 transfer-app 而言:

- `SonataFlowSecurityConfig$RuntimeFilter` (`ContainerRequestFilter`, 攔截所有非 POST)
- `UnwrapResponseFilter` (`ContainerResponseFilter`, 解包 workflow 輸出)
- `OpenApiFilter` (`OASFilter`, 過濾 OpenAPI path item)

這三個都來自 `platform-security` 模組。

---

## 第 18 章:AuditLogService 與 SQLite 資料表建立

### 18.1 StartupEvent 觸發

`org.acme.reconciliation.AuditLogService` 用 `void onStart(@Observes StartupEvent ev)` 註冊為 CDI observer:

```java
@ApplicationScoped
public class AuditLogService {
    void onStart(@Observes StartupEvent ev) {
        initDatabase();
    }
    // ...
}
```

`StartupEvent` 由 Quarkus 在 Application Start 階段 (見 Ch11) 廣播,所有 observer 同步執行。

### 18.2 initDatabase 邏輯

```java
public void initDatabase() {
    if (initialized.get()) return;          // AtomicBoolean 防止重複
    synchronized (this) {
        if (initialized.get()) return;
        try {
            Path dataDir = PlatformPaths.ensureDataDirectory();
            try (Connection conn = getConnection(); Statement stmt = conn.createStatement()) {
                stmt.execute("PRAGMA journal_mode=WAL;");
                stmt.execute("PRAGMA synchronous=NORMAL;");
                stmt.execute("PRAGMA busy_timeout=5000;");
                stmt.execute("CREATE TABLE IF NOT EXISTS workflow_execution_log ( ... )");
                stmt.execute("CREATE INDEX IF NOT EXISTS idx_wel_process_instance_id ON ...;");
                stmt.execute("CREATE VIEW IF NOT EXISTS vw_saga_reconciliation AS SELECT ... FROM workflow_execution_log WHERE workflow_id='saga2-transfer-workflow';");
                initialized.set(true);
            }
        } catch (Exception e) { LOG.error(...); }
    }
}
```

### 18.3 schema 細節

`workflow_execution_log` 表 (由 `AuditLogService.initDatabase()` 建立,共 9 個欄位):
- `id` (INTEGER PK, AUTOINCREMENT)
- `workflow_id` (TEXT)
- `business_key` (TEXT)
- `process_instance_id` (TEXT, indexed — `idx_wel_process_instance_id`)
- `status` (TEXT — `SUCCESS` / `FAILED` / `ROLLED_BACK` / `VALIDATION_FAILED` / `ROLLBACK_FAILED`)
- `message` (TEXT)
- `input_data` (TEXT, JSON)
- `output_data` (TEXT, JSON)
- `created_at` (TIMESTAMP DEFAULT CURRENT_TIMESTAMP)

`vw_saga_reconciliation` 視圖 (16 個欄位):
- 從 `workflow_execution_log` 過濾 `workflow_id = 'saga2-transfer-workflow'`
- 用 `json_extract` 把 `input_data` 與 `output_data` 的 JSON 欄位攤平為 column
- 加上 `process_instance_id` 直接欄位(共 16 欄:8 原始 + 1 process_instance_id + 7 json_extract 攤平)

### 18.4 應用就緒

`AuditLogService.onStart` 結束後,整個 transfer-app 進入 **Running** 階段,開始接受 HTTP 請求。

```mermaid
sequenceDiagram
    participant Q as Application Start
    participant SE as StartupEvent
    participant AL as AuditLogService
    participant DB as data/reconciliation.db

    Q->>SE: fire(StartupEvent)
    SE->>AL: onStart(StartupEvent)
    AL->>AL: PlatformPaths.ensureDataDirectory()
    AL->>DB: getConnection (透過 Agroal pool)
    AL->>DB: PRAGMA journal_mode=WAL
    AL->>DB: PRAGMA synchronous=NORMAL
    AL->>DB: PRAGMA busy_timeout=5000
    AL->>DB: CREATE TABLE IF NOT EXISTS workflow_execution_log
    AL->>DB: CREATE INDEX IF NOT EXISTS idx_wel_process_instance_id
    AL->>DB: CREATE VIEW IF NOT EXISTS vw_saga_reconciliation
    AL-->>Q: initialized.set(true)
    Q->>Q: 應用就緒
```

---

# Part 4 ─ 執行期生命週期 (Runtime)

> 從 HTTP 請求 `POST /saga2-transfer-workflow` 進入到回應離開 server 為止,所有 filter、SonataFlow 引擎、JDBC、SQLite、Data Index 雙寫的完整路徑。

---

## 第 19 章:HTTP 請求接收總流程

### 19.1 從 Port 8080 到 Vert.x Event Loop

transfer-app 啟動時,`quarkus-vertx-http` 會建立 Vert.x HTTP server,綁定 `0.0.0.0:8080`。Vert.x 內部使用少量 Event Loop threads (預設 = CPU 核數 * 2) 處理 I/O。

```
TCP 8080
  ↓
NettyServer (Quarkus / Vert.x)
  ↓ EventLoop thread
HttpServerCodec 解碼 HTTP/1.1
  ↓
HttpHandler (Quarkus routing)
  ↓
Route matching → JAX-RS Resource
  ↓ Worker thread (透過 executeBlocking)
Resource method 執行
  ↓
回應序列化 + Encoder
  ↓
NettyServer 寫回 socket
```

### 19.2 Request / Response Filter 鏈 (JAX-RS 標準)

進入 JAX-RS Resource method 之前,所有 `ContainerRequestFilter` 會依 `@Priority` 由小到大執行。
離開時,所有 `ContainerResponseFilter` 依相反順序 (高到低 `@Priority`) 執行。

對 transfer-app 而言:

**Request 鏈** (進):
1. `SonataFlowSecurityConfig$RuntimeFilter` (Priority=USER, 即 5000)
2. JAX-RS Body decoder
3. Resource method

**Response 鏈** (出):
1. JAX-RS Body encoder
2. `UnwrapResponseFilter` (或其他 platform-security 內宣告的 ContainerResponseFilter)
3. Quarkus 內部 logging / metrics

### 19.3 完整請求生命週期

```mermaid
sequenceDiagram
    participant C as Client
    participant N as Netty (EventLoop)
    participant R as RuntimeFilter
    participant JR as JAX-RS Router
    participant SW as Saga2TransferWorkflowResource
    participant EN as SonataFlow Engine
    participant SS as SagaApiService / MyOpenApiService
    participant AL as AuditLogService
    participant DI as Kogito Data Index
    participant U as UnwrapResponseFilter
    participant DB as SQLite

    C->>N: POST /saga2-transfer-workflow
    N->>R: 解碼 + 進 request chain
    R->>R: 檢查 method == POST?
    alt 非 POST
        R-->>C: 403 Forbidden
    else POST
        R->>JR: 放行
        JR->>SW: dispatch to *Resource.create()
        SW->>EN: 啟動 process instance
        EN->>EN: 載入 .sw.yaml → state machine
        EN->>SS: CallA16229State 觸發 MyOpenApiService.callOpenApi()
        SS->>SS: resolveBaseUrl + 快取
        SS->>N: JDK HttpClient POST http://localhost:8080/A16229
        N->>JR: self-call 觸發 A16229Resource
        JR->>SW: A16229 業務邏輯 (AMT > 50 → 100, else 999)
        SW-->>SS: JsonNode response
        SS-->>EN: a16229Result = {code: "100", ...}
        EN->>SS: 繼續 CallA16220State
        SS->>N: POST /A16220
        N-->>SS: a16220Result
        SS-->>EN: a16220Result
        EN->>EN: CheckA16220Result → DecideByEvaluation
        alt AMT > 500
            EN->>SS: RollbackA16220 + RollbackA16229
            SS->>N: EC=true 兩次回沖
        end
        EN->>AL: FinalAuditAndEnd → saveLog
        AL->>DB: INSERT workflow_execution_log
        AL-->>EN: {saved: true}
        EN-->>SW: process instance 結束 + 最終 output
        SW->>DI: process state change event
        DI->>DB: UPDATE / INSERT process_instances
        SW-->>JR: 返回 JSON
        JR->>U: 進 response chain
        U->>U: 解包 workflow output
        U-->>C: 200 OK + JSON
    end
```

---

## 第 20 章:請求過濾器鏈

### 20.1 RuntimeFilter (POST-only)

`platform-security` 內 `SonataFlowSecurityConfig$RuntimeFilter`:

```java
@Provider
@ApplicationScoped
@Priority(jakarta.ws.rs.Priorities.USER)
public static class RuntimeFilter implements ContainerRequestFilter {
    @Override
    public void filter(ContainerRequestContext requestContext) throws IOException {
        String rawPath = requestContext.getUriInfo().getPath();
        String path = rawPath != null && rawPath.startsWith("/") ? rawPath.substring(1) : rawPath;
        String method = requestContext.getMethod();

        // 白名單排除
        if (path.startsWith("q/") || path.endsWith(".html") || path.endsWith(".js")
            || path.endsWith(".css") || path.endsWith(".ico")
            || path.contains("reconciliation") || path.contains("specs")
            || path.contains("instances") || path.contains("jobs") || path.contains("trace")) {
            return;
        }

        if (!method.equalsIgnoreCase("POST")) {
            requestContext.abortWith(Response.status(Response.Status.FORBIDDEN)
                    .entity("{\"error\": \"Only POST method is allowed\"}").build());
        }
    }
}
```

**白名單**包含:
- Quarkus 系統端點 (`/q/`)
- 靜態資源 (`.html`, `.js`, `.css`, `.ico`)
- 對帳查詢 (`reconciliation`)
- OpenAPI specs 取得 (`specs`)
- Kogito Data Index GraphQL 查詢端點 (`instances`, `jobs`, `trace`)

**不在白名單的非 POST** → 403。

### 20.2 為何有此 filter

SonataFlow 10.2.0 對 specVersion 0.8 的 workflow endpoint,預設會**同時接受 GET 與 POST**,但:
- GET 觸發 process 沒有標準 body
- 容易造成意外觸發 (瀏覽器預載、爬蟲)

所以在 `platform-security` 用 `RuntimeFilter` 全域擋 GET,只允許 POST workflow 啟動。

---

## 第 21 章:SonataFlow Workflow 入口

### 21.1 命中 codegen 產生的 Resource

對 `POST /saga2-transfer-workflow` 而言,JAX-RS router 會找到 `Saga2TransferWorkflowResource` (Kogito codegen 在編譯期產出)。這個 class 通常結構為:

```java
@Path("/saga2-transfer-workflow")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class Saga2TransferWorkflowResource {

    @Inject
    Process<Saga2TransferWorkflowModel> process;

    @POST
    public Response create(Saga2TransferWorkflowModel input) {
        Saga2TransferWorkflowModel output = process.createInstance(input).start();
        return Response.ok(output.toMap()).build();
    }

    @GET
    @Path("/{id}")
    public Response get(@PathParam("id") String id) { ... }
}
```

`process` 是 Kogito `Process<Saga2TransferWorkflowModel>`,代表 `saga2-transfer-workflow` 流程定義。

### 21.2 啟動 Process Instance

`process.createInstance(input).start()`:
1. `createInstance` 從 `processesById` 找到 `saga2-transfer-workflow` 的 `ProcessDescriptor`
2. 建立新的 `ProcessInstance<Saga2TransferWorkflowModel>` (持有 input data + state)
3. `start()` 觸發 `ProcessRuntimeImpl` 跑 state machine,從 `start: ValidateInput` 開始

### 21.3 Workflow instance 生命週期

```mermaid
stateDiagram-v2
    [*] --> Pending: createInstance
    Pending --> Active: start()
    Active --> Active: state transition
    Active --> Completed: end: true
    Active --> Aborted: abort
    Completed --> [*]
    Aborted --> [*]
```

完成後 instance 可以:
- 留在記憶體 (預設)
- 持久化到 Data Index (Kogito 自動雙寫)
- 透過 `GET /saga2-transfer-workflow/{id}` 查詢狀態

---

## 第 22 章:自訂 Service 反射呼叫

### 22.1 function 宣告

workflow YAML 內:

```yaml
functions:
  - name: callApiViaOpenAPI
    operation: 'service:com.example.transfer.workflow.MyOpenApiService::callOpenApi'
    type: custom
  - name: recordAuditLog
    operation: 'service:com.example.reconciliation.AuditLogService::saveLog'
    type: custom
```

`type: custom` 告訴 Kogito 引擎:這是個 CDI bean 方法,反射呼叫。

### 22.2 反射呼叫流程

Kogito 引擎在 `CallA16229State` 觸發 `callApiViaOpenAPI` 時:

1. 從 `functions` 解析 `refName=callApiViaOpenAPI` → 取得 `operation` 字串
2. 解析 `service:com.example.transfer.workflow.MyOpenApiService::callOpenApi`
3. 從 CDI 容器 `Instance<>` 找到 `MyOpenApiService` bean
4. 用反射找到 `callOpenApi(JsonNode)` 方法
5. 把 `functionRef.arguments` 序列化為 JsonNode 傳入
6. 取得回傳 `JsonNode` 作為此 state 的 output

### 22.3 method 多載選擇

`MyOpenApiService` 提供了 5 個 `callOpenApi` 多載 (見原始碼):

```java
public JsonNode callOpenApi(JsonNode arguments)                                          // 主要入口
public JsonNode callOpenApi(String schemaRef, Map<String, Object> payload)
public JsonNode callOpenApi(String schemaRef, JsonNode payload)
public JsonNode callOpenApi(String functionName, String schemaRef, Map<String, Object> payload)
public JsonNode callOpenApi(String functionName, String schemaRef, JsonNode payload)
```

Kogito codegen 會依 `functionRef.arguments` 的欄位數,選擇最匹配的多載,例如 `saga2-transfer-workflow` 傳 `functionName` + `schemaRef` + `payload` 就會命中第 4 或第 5 個。

### 22.4 CDI Bean 注入鏈

```mermaid
flowchart TD
    A["Kogito Engine: 需 callApiViaOpenAPI"] --> B["CDI Instance<MyOpenApiService>"]
    B --> C["ARC 從 Jandex 索引找 bean"]
    C --> D["找到 @ApplicationScoped MyOpenApiService"]
    D --> E["反射取得 callOpenApi(JsonNode) Method"]
    E --> F["呼叫 method.invoke(bean, arguments)"]
    F --> G["回傳 JsonNode"]
    G --> A
```

---

## 第 23 章:Saga 業務邏輯執行

### 23.1 兩個 Saga 的差異

| 項目 | saga-transfer-workflow (v15) | saga2-transfer-workflow (v2) |
| :--- | :--- | :--- |
| 呼叫方式 | `type: custom` → `SagaApiService` (JDK HttpClient) | `type: custom` → `MyOpenApiService` (讀 OpenAPI YAML 動態組裝) |
| 輸入驗證 | `dataInputSchema` (編譯期驗證) | `ValidateInput` state 內 jq 驗證 |
| 終點 | 多個獨立 end state (`SuccessState`, `FailedState`, `RollbackA16229`, ...) | 統一 `FinalAuditAndEnd` (寫 audit log) |
| 對帳 | 無 | `recordAuditLog` (寫 `workflow_execution_log`) |
| 回應過濾 | 各自 output filter | `UnwrapResponseFilter` 在 JAX-RS 層處理 |
| HTTP status | workflow 直接定義 | `UnwrapResponseFilter` 改寫 (400 for validation fail) |

### 23.2 saga-transfer-workflow (v15) 狀態流轉

```mermaid
stateDiagram-v2
    [*] --> CallA16229State
    CallA16229State --> CheckA16229Result
    CheckA16229Result --> CallA16220State: code="100"
    CheckA16229Result --> FailedState: code != "100"
    CallA16220State --> CheckA16220Result
    CheckA16220Result --> DecideByEvaluation: code="100"
    CheckA16220Result --> RollbackA16229Only: code != "100"
    DecideByEvaluation --> SuccessState: AMT <= 500
    DecideByEvaluation --> RollbackA16220: AMT > 500
    RollbackA16220 --> RollbackA16229
    RollbackA16229 --> [*]
    SuccessState --> [*]
    FailedState --> [*]
    RollbackA16229Only --> [*]
```

四種業務情境:

| 情境 | AMT | 結果 | 路徑 |
| :--- | :--- | :--- | :--- |
| 1 | 100 | SUCCESS | CallA16229 → CallA16220 → SuccessState |
| 2 | 600 | ROLLED_BACK (LIFO) | CallA16229 → CallA16220 → Decide → RollbackA16220 → RollbackA16229 |
| 3 | 30 | FAILED (短路) | CallA16229 → CheckA16229Result code!=100 → FailedState |
| 4 | 2000 | ROLLED_BACK (僅 A16229) | CallA16229 → CallA16220 failed → RollbackA16229Only |

### 23.3 saga2-transfer-workflow (v2) 狀態流轉

> **v2.1.0/v2.2 增補**(本章狀態圖與情境仍正確,新增以下平台化能力,細節見
> [saga2-transfer-workflow-spec.md](./saga2-transfer-workflow-spec.md) 與 [NEW-WORKFLOW-SOP.md](./NEW-WORKFLOW-SOP.md)):
> - 各 state 掛 `onErrors → platformError` 兜底 + operation state 層 `actionExecTimeout/stateExecTimeout`(三層防線),非預期錯誤仍收斂至 `FinalAuditAndEnd` 寫對帳
> - `ValidateInput` 強化:null-safe、AMT>0、同帳號拒絕;驗證訊息與規則同步
> - API 結果新增 `errorType` 分類(TRANSPORT/BUSINESS/HTTP_4XX/HTTP_5XX);輸出新增 `auditSaved`
> - HTTP 改寫配置化:`platform.status-rewrite.workflows/mapping`(VALIDATION_FAILED→400、ROLLBACK_FAILED→409 實測生效)
> - 測試集由 10 案例擴充為 18 案例(含 400/409 路徑與 RBFAIL 測試哨兵)
> - v2.2.0 再增補:workflow `metadata` 標籤、switch 正向條件+安全 default 精簡、
>   傳輸層指數退避重試(`kogito.sw.openapi.transport-retry.*`)、統一終點條件告警
>   `OpsAlertService`(ROLLBACK_FAILED → `[OPS-ALERT]`,輸出新增 `opsAlertRaised`);
>   另新增 `MyOpenApiServiceRetryTest`(純 JUnit,確定性傳輸失敗探測),測試類共 4 支

```mermaid
stateDiagram-v2
    [*] --> ValidateInput
    ValidateInput --> InjectValidationFailedStatus: format invalid
    ValidateInput --> CallA16229State: ok
    CallA16229State --> CheckA16229Result
    CheckA16229Result --> CallA16220State: code="100"
    CheckA16229Result --> InjectFailedStatus: code != "100"
    CallA16220State --> CheckA16220Result
    CheckA16220Result --> DecideByEvaluation: code="100"
    CheckA16220Result --> RollbackA16229Only: code != "100"
    DecideByEvaluation --> InjectSuccessStatus: AMT <= 500
    DecideByEvaluation --> RollbackA16220: AMT > 500
    DecideByEvaluation --> RollbackA16220: default (安全)
    RollbackA16220 --> RollbackA16229
    RollbackA16229 --> CheckRollbackResults
    CheckRollbackResults --> InjectRolledBackStatus: 都成功
    CheckRollbackResults --> InjectRollbackFailedStatus: 任一失敗
    RollbackA16229Only --> CheckRollbackA16229OnlyResult
    CheckRollbackA16229OnlyResult --> InjectRolledBackOnlyStatus: 成功
    CheckRollbackA16229OnlyResult --> InjectRollbackFailedStatus: 失敗
    InjectValidationFailedStatus --> FinalAuditAndEnd
    InjectSuccessStatus --> FinalAuditAndEnd
    InjectFailedStatus --> FinalAuditAndEnd
    InjectRolledBackStatus --> FinalAuditAndEnd
    InjectRolledBackOnlyStatus --> FinalAuditAndEnd
    InjectRollbackFailedStatus --> FinalAuditAndEnd
    FinalAuditAndEnd --> [*]
```

**新增概念**:
- `InjectXxxStatus`: 純 `type: inject` state,只設定 `finalStatus` 與 `finalMessage` 兩個欄位
- `FinalAuditAndEnd`: 統一終點,呼叫 `recordAuditLog` + `stateDataFilter.output` 統一輸出格式
- LIFO 路徑加 `CheckRollbackResults` 偵測回沖是否成功

### 23.4 為何要 finalStatus + finalMessage

`InjectXxxStatus` 統一管理輸出格式,使 `FinalAuditAndEnd` 的 `stateDataFilter.output` 可共用,不會因為終點不同而 template 散落各處。

---

## 第 24 章:MyOpenApiService 動態呼叫

### 24.1 設計動機

`saga2-transfer-workflow` 不在 workflow YAML 內 hardcode `kogito.sw.openapi.<specKey>` 設定,而是讓 `MyOpenApiService` 在執行期從 classpath 讀 `specs/A16229-api.yaml` / `specs/A16220-api.yaml`,**動態解析 `operationId`、path、method、request schema**。

### 24.2 4 層 ConcurrentHashMap 快取

```java
// 1. 端點定位快取
private final Map<String, ApiEndpoint> operationCache;     // key: "specPath#operationId"

// 2. Base URL 解析快取
private final Map<String, String> baseUrlCache;            // key: "functionName#specPath"

// 3. YAML AST 快取 (避免重複 IO + YAML parse)
private final Map<String, JsonNode> specAstCache;          // key: "specPath"

// 4. request schema 欄位順序快取
private final Map<String, List<String>> requestFieldsCache; // key: "schemaRef"
```

四層快取在第一次呼叫時 lazy init,後續 O(1) 命中。

### 24.3 核心功能與強化特性

1. **完整 HTTP Method 支援**：支援 `GET`, `POST`, `PUT`, `DELETE`, `PATCH`, `HEAD`, `OPTIONS`，依 Method 自動判定 Body 發送模式。
2. **動態路徑與查詢參數**：
   - **Path Params**：自動將 `{param}` 模板比對 Payload 欄位並以 UTF-8 URL 編碼替換。
   - **Query Params**：針對 GET/DELETE 等請求，自動將剩餘 Payload 欄位組裝為 Query String。
3. **自訂 Headers 與追蹤標頭**：支援在 `arguments.headers` 傳入自訂標頭（如 Bearer Token, `X-Correlation-ID`）。
4. **可配置逾時**：支援 `application.properties` 設定 `kogito.sw.openapi.timeout-seconds`，或以 `arguments.timeoutSeconds` 單次覆寫。
5. **標準化響應結構**：保證 JSON Object、JSON Array (`data: [...]`)、204 No Content 與錯誤回傳均具備統一之 `code`、`message` 及 `_httpStatus`。

### 24.4 Base URL 解析規則

`doResolveBaseUrl(...)` 依序試 4 條規則,直到找到:

| 優先 | 規則 | 範例 |
| :--- | :--- | :--- |
| 1 | `kogito.sw.functions.<fn>.base_url` 或 `.url` | (未用) |
| 2 | `kogito.sw.functions.<fn>.protocol + host + port` | `kogito.sw.functions.callApiViaOpenAPI.protocol=http, host=localhost, port=8080` |
| 3 | `kogito.sw.openapi.<specKey>.base_url` | (未用) |
| 4 | `servers[0].url` (從 OpenAPI spec 內) | (未用) |

對 transfer-app 而言,`callApiViaOpenAPI` 走**規則 2**:

```properties
kogito.sw.functions.callApiViaOpenAPI.protocol=http
kogito.sw.functions.callApiViaOpenAPI.host=localhost
kogito.sw.functions.callApiViaOpenAPI.port=8080
```

合成 `http://localhost:8080`。

### 24.5 動態呼叫時序

```mermaid
sequenceDiagram
    participant EN as Engine
    participant MS as MyOpenApiService
    participant CC as ConcurrentHashMap 快取
    participant YM as YAMLMapper
    participant HC as JDK HttpClient
    participant API as A16229Resource

    EN->>MS: callOpenApi({functionName, schemaRef, payload, headers?, timeoutSeconds?})
    MS->>MS: parse schemaRef = "specs/A16229-api.yaml#executeA16229"
    MS->>CC: operationCache.get("specs/A16229-api.yaml#executeA16229")
    alt 快取 miss
        MS->>YM: getSpecAst("specs/A16229-api.yaml")
        YM->>YM: ClassLoader.getResourceAsStream → Jackson YAML parse
        YM-->>MS: JsonNode root
        MS->>CC: specAstCache.put(...)
        MS->>MS: findOperationNode(root, "executeA16229")
        MS->>CC: operationCache.put(...)
    end
    MS->>CC: baseUrlCache.get("callApiViaOpenAPI#specs/A16229-api.yaml")
    alt 快取 miss
        MS->>MS: 讀 MP Config → 規則 2 → http://localhost:8080
        MS->>CC: baseUrlCache.put(...)
    end
    MS->>MS: extractPayload + buildTargetUrl(Path/Query) + resolveTimeout
    MS->>HC: sendAsync(POST http://localhost:8080/A16229)
    HC->>API: POST /A16229
    API-->>HC: 200 {code:"100", message:"成功", Account:"A123"}
    HC-->>MS: thenApply → normalizeResponse
    MS-->>EN: JsonNode a16229Result
```

### 24.6 為何用 sendAsync + join

- 不用 blocking `httpClient.send()` (會卡 worker thread)
- `sendAsync` 回傳 `CompletableFuture<JsonNode>`,Kogito engine 用 `join()` 等待
- 整個 Quarkus worker thread pool 不會被 HTTP I/O 阻塞 → 支援高併發

---

## 第 25 章:Audit Log 寫入

### 25.1 觸發點

`saga2-transfer-workflow` 的 `FinalAuditAndEnd` state:

```yaml
- name: FinalAuditAndEnd
  type: operation
  actions:
    - name: saveFinalAuditLog
      functionRef:
        refName: recordAuditLog
        arguments:
          workflowId: "saga2-transfer-workflow"
          businessKey: '${ .Account_A }'
          processInstanceId: '${ $WORKFLOW.instanceId }'
          inputData: { ... }
          outputData: { ... }
```

### 25.2 反射呼叫 AuditLogService

Kogito engine 解析 `service:com.example.reconciliation.AuditLogService::saveLog`,找到 `saveLog` 多載。

`saveLog` 有 4 個多載:
- `saveLog(String, Object, Object, Object, Object)` (5 參數)
- `saveLog(String, Object, Object, Object)` (4 參數, 向下相容)
- `saveLog(JsonNode arguments)` (單一 JsonNode)
- `saveLog(Map<String, Object> arguments)` (單一 Map)

codegen 會依 `arguments` 結構選最匹配 → 通常是 `saveLog(JsonNode)`。

### 25.3 INSERT 邏輯

`AuditLogService.doSaveLog(...)` 透過 Agroal DataSource 取得 Connection,執行:

```sql
INSERT INTO workflow_execution_log
  (workflow_id, business_key, process_instance_id, status, message, input_data, output_data)
VALUES (?, ?, ?, ?, ?, ?, ?);
```

參數:
- `workflow_id` = "saga2-transfer-workflow"
- `business_key` = Account_A
- `process_instance_id` = Kogito 自動注入
- `status` = finalStatus (SUCCESS / FAILED / ROLLED_BACK / ROLLBACK_FAILED / VALIDATION_FAILED)
- `message` = finalMessage
- `input_data` = Account_A / Account_B / AMT (JSON)
- `output_data` = a16229Result / a16220Result / a16229Rollback / a16220Rollback (JSON)

### 25.4 寫入時序

```mermaid
sequenceDiagram
    participant EN as Engine
    participant AL as AuditLogService
    participant DS as Agroal DataSource
    participant SQ as xerial SQLite
    participant DB as data/reconciliation.db
    participant DI as Kogito Data Index

    EN->>AL: saveLog(arguments)
    AL->>AL: 解析 5 個欄位
    AL->>AL: initialized.get()?
    alt 未初始化
        AL->>AL: initDatabase() (內含建表)
    end
    AL->>DS: getConnection()
    DS->>SQ: 取得 JDBC 連線 (含 PRAGMA)
    SQ-->>DS: Connection
    AL->>SQ: INSERT INTO workflow_execution_log
    SQ->>DB: 寫入 (WAL 模式)
    SQ-->>AL: rows = 1
    AL-->>EN: {saved: true, workflowId, status}
    EN->>DI: process state change event (並行)
    DI->>DB: UPDATE process_instances
```

> **注意**: AuditLog 寫入與 Data Index 寫入是**並行**的,不互相依賴。即使 Data Index 寫失敗,audit log 仍會記錄。

---

## 第 26 章:回應過濾器鏈

### 26.1 UnwrapResponseFilter

`platform-security/UnwrapResponseFilter` 是一個 `ContainerResponseFilter`,在 JAX-RS 回應離開前介入。

用途:
1. **解包 workflow output**: Kogito 預設把 `stateDataFilter.output` 整個當 `workflowdata` 欄位回傳,filter 把它解到 root
2. **HTTP status 改寫**: 對 `VALIDATION_FAILED` (workflow 內 jq 驗證失敗),把 200 改為 400
3. **統一錯誤格式**: 把所有錯誤包成 `{error: "..."}` 格式

### 26.2 為何需要

- `saga2-transfer-workflow` 取消 `dataInputSchema`,改在 `ValidateInput` state 內做 jq 驗證
- 驗證失敗時 workflow 仍正常結束 (走 `FinalAuditAndEnd`)
- 但對 client 而言,失敗應該回 400 不是 200
- 所以由 `UnwrapResponseFilter` 在 JAX-RS 層改 status code

### 26.3 響應時序

```mermaid
sequenceDiagram
    participant SW as Saga2TransferWorkflowResource
    participant EN as SonataFlow Engine
    participant UF as UnwrapResponseFilter
    participant C as Client

    SW->>EN: start() 完成 → 取得 Saga2TransferWorkflowModel
    EN-->>SW: model.toMap() → {workflowdata: {...}}
    SW->>UF: 進入 response chain
    UF->>UF: 解析 status 欄位
    alt status == VALIDATION_FAILED
        UF->>UF: Response.status(400)
    else 其他
        UF->>UF: Response.status(200)
    end
    UF->>UF: 解包 workflowdata 到 root
    UF-->>C: 200 / 400 + JSON
```

---

## 第 27 章:Data Index 雙寫

### 27.1 Process 變更事件

Kogito 引擎在 process state 變化時,觸發事件給所有註冊的 `ProcessEventListener`。`kogito-addons-quarkus-data-index-sqlite` 註冊了一個 listener,會把事件序列化為 GraphQL mutation 寫到 Data Index 儲存。

### 27.2 寫入的實體

| Kogito Entity | Data Index Table | 內容 |
| :--- | :--- | :--- |
| `ProcessInstanceEntity` | `process_instances` | process id, state, start, end, variables(JSON), businessKey |
| `UserTaskEntity` | `user_tasks` | task id, processInstanceId, name, state |
| `JobEntity` | `jobs` | timer / async job, trigger time, state |
| `ProcessDefinitionEntity` | `processes` | 流程定義 metadata |

### 27.3 雙寫的時序

```mermaid
sequenceDiagram
    participant EN as Engine
    participant PE as ProcessEventListener
    participant ST as SQLiteStorage
    participant DB as data/reconciliation.db
    participant GQL as POST /graphql

    EN->>PE: processInstanceStateChanged(pid, state)
    PE->>ST: 序列化為 mutation
    ST->>DB: INSERT/UPDATE process_instances
    Note over ST,DB: 走的是另一組 Hibernate connection (Data Index 自己)
    GQL->>ST: query ProcessInstances { ... }
    ST->>DB: SELECT * FROM process_instances
    ST-->>GQL: GraphQL response
```

### 27.4 為何 ZonedDateTime 修補重要

Data Index 的 `process_instances.start` / `end` 是 `ZonedDateTime` 欄位,SQLite 把它存為 TEXT。

預設 Hibernate 6.x + xerial SQLite JDBC 期望 TEXT 是 ISO-8601 格式,但 Kogito 寫入的是 **Unix epoch ms 的 numeric string**(例如 `"1786185258763"`),預設 parser 會拋 `Error parsing time stamp`。

`SqliteZonedDateTimeIntegrationListener` 透過自訂 `JavaType.wrap()` 同時支援:
- `Long` (epoch ms)
- `String` (numeric string)
- 標準 ISO-8601 字串

修補後,GraphQL 查詢 `ProcessInstances { start }` 才能正確回傳 timestamp。

### 27.5 DataIndexGraphQLTest 驗證

`distribution/transfer-app/src/test/java/.../DataIndexGraphQLTest.java` 會在測試期對 `/graphql` 查詢:

```graphql
{ ProcessDefinitions { id name version } }
{ ProcessInstances { id processId state start end } }
```

驗證:
- `errors` 為 null
- `data.ProcessDefinitions` / `data.ProcessInstances` 有值
- 不會出現 `Error parsing time stamp`

---

# Part 5 ─ 關機期生命週期 (Shutdown)

> 從 `kill -TERM <pid>` 或 `Ctrl+C` 到 JVM 完全退出之間,Quarkus 的優雅關機管線、SQLite WAL flush、DataSource 釋放、SonataFlow 引擎卸載的完整協作。

---

## 第 28 章:優雅關機訊號

### 28.1 觸發方式

| 環境 | 訊號 | 行為 |
| :--- | :--- | :--- |
| Linux / macOS | `kill -TERM <pid>` (SIGTERM) | 觸發 Quarkus shutdown hook |
| Linux / macOS | `kill -INT <pid>` (SIGINT, Ctrl+C) | 同上 |
| Windows | Ctrl+C | JVM Shutdown hook |
| Kubernetes | Pod 終止時 kubelet 發 SIGTERM | 觸發 |

### 28.2 Quarkus 關機管線

Quarkus 內建 `ShutdownEvent` 與 `PreShutdownEvent` 兩個 CDI 事件。執行順序:

```
1. JVM 收到 SIGTERM / SIGINT
2. JVM 觸發 Shutdown Hook (Quarkus 註冊的)
3. Quarkus 廣播 PreShutdownEvent (尚未停止任何服務)
4. 停止接受新 HTTP 連線 (Vert.x HTTP server close)
5. 等待 in-flight request 結束 (有 timeout)
6. 廣播 ShutdownEvent
7. 各 bean 收到 ShutdownEvent 執行清理
8. 停止背景排程 (Quarkus Scheduler)
9. 關閉 DataSource (Agroal)
10. JVM 退出
```

### 28.3 關機時序

```mermaid
sequenceDiagram
    participant OS as OS Signal
    participant JVM as JVM Shutdown Hook
    participant Q as Quarkus Runtime
    participant V as Vert.x HTTP
    participant EN as SonataFlow Engine
    participant DS as Agroal DataSource
    participant SQ as xerial SQLite
    participant DB as data/reconciliation.db

    OS->>JVM: SIGTERM
    JVM->>Q: 觸發 Quarkus shutdown hook
    Q->>Q: 廣播 PreShutdownEvent
    Q->>V: httpServer.close()
    V->>V: 停止 listen, 拒絕新連線
    V->>V: 等待 in-flight request (預設 30s)
    V-->>Q: 連線全部結束
    Q->>Q: 廣播 ShutdownEvent
    Q->>EN: engine.close()
    EN->>EN: 等待 in-flight workflow 完成
    EN-->>Q: 所有 instance 結束
    Q->>DS: DataSource.close()
    DS->>SQ: 關閉所有連線
    SQ->>DB: WAL checkpoint (truncate)
    SQ-->>DS: 連線關閉
    DS-->>Q: pool 關閉
    Q-->>JVM: shutdown 完成
    JVM->>JVM: System.exit(0)
```

---

## 第 29 章:資料持久化與 WAL Checkpoint

### 29.1 SQLite WAL 模式特性

- 寫入者把資料寫到 `reconciliation.db-wal`,不直接寫 main file
- SQLite 定期做 **checkpoint**,把 WAL 內容合併回 main file
- **若直接拔電源** 沒做 checkpoint,可能遺失最後未 checkpoint 的交易
- WAL 模式下,`PRAGMA journal_mode=WAL` 設定後 checkpoint 是自動的
- **但** 應用正常關機時,可以手動觸發 `PRAGMA wal_checkpoint(TRUNCATE)` 強制合併

### 29.2 transfer-app 的關機清理

`AuditLogService` 沒有顯式註冊 `@Observes ShutdownEvent`,但**任何 ShutdownEvent observer** 都可以在關機期執行 SQL。

實際上 transfer-app 依賴:
1. Agroal 在 `DataSource.close()` 時把所有 connection 歸還 pool
2. xerial SQLite JDBC 在 connection close 時**不自動**做 checkpoint
3. WAL file (`reconciliation.db-wal`) 會保留,下次啟動時 SQLite 自動 replay

**建議改善** (非當前實作): 在 ShutdownEvent observer 中手動執行 `PRAGMA wal_checkpoint(TRUNCATE)`。

### 29.3 Kogito Data Index 持久化

Data Index 透過 Hibernate ORM 管理,所有 entity 變更都是 JPA transaction,close 時:

- 還在 transaction 中的 entity 會被 rollback
- 完成的 transaction 已經寫到 SQLite
- 不需額外 flush

### 29.4 共享 Volume 場景

README 提到:
> 兩個 distribution 透過共用 volume / 共享 storage 寫同一個 reconciliation.db
> SQLite WAL 模式可承受多 reader + 1 writer

**關機期**:
- transfer-app shutdown → WAL file 保留
- reconciliation-app (另一個 Pod) 仍可讀 main file + WAL
- 下次 transfer-app 啟動時自動 replay WAL

---

## 第 30 章:資源釋放與 JVM 退出

### 30.1 Vert.x 事件循環關閉

```java
// Quarkus 內部 (Recorder)
@Record(ExecutionTime.RUNTIME_INIT)
void shutdown(Vertx vertx, ShutdownContext shutdownContext) {
    shutdownContext.addShutdownTask(() -> vertx.close().await());
}
```

### 30.2 Netty 資源

- EventLoopGroup shutdownGracefully
- ChannelPool 關閉
- ByteBufAllocator 釋放

### 30.3 CDI Bean 釋放

所有 `@ApplicationScoped` bean 沒有 dispose method 的會被 Quarkus 直接釋放 reference。
有 `@PreDestroy` 或 `close()` 的會被呼叫。

對 transfer-app:
- `AuditLogService`: 無 `@PreDestroy`
- `ReconciliationCsvExporter`: 有 `void onStart(@Observes StartupEvent ev)`,但無 shutdown
- `MyOpenApiService` / `SagaApiService`: 無 close (HttpClient 為 lazy init, JVM exit 時自然釋放)

### 30.4 JVM 退出

```mermaid
flowchart TD
    A["ShutdownEvent 結束"] --> B["Quarkus 廣播 shutdown complete"]
    B --> C["JVM shutdown hook 結束"]
    C --> D["JVM 釋放所有 non-daemon thread"]
    D --> E["System.exit(0)"]
    E --> F["OS process 結束"]
```

> **Daemon thread 範例**: Hibernate connection pool keep-alive、Vert.x acceptor threads 都是 daemon,JVM 退出時自動結束。

### 30.5 完整生命週期對照

| 階段 | 開始 | 結束 | 主要動作 |
| :--- | :--- | :--- | :--- |
| Build | `mvn clean package` | `target/quarkus-app/` 產出 | 編譯、codegen、@BuildStep、組裝 |
| Bootstrap | `java -jar quarkus-run.jar` | `Quarkus started in Xs` | 7 大階段、CDI 啟動、Hibernate 修補 |
| Running | 第一個 HTTP 請求 | 最後一個 HTTP 請求 | filter、workflow、SQLite、Data Index 雙寫 |
| Shutdown | SIGTERM | `System.exit(0)` | 停止 accept、flush、close |

---

# Part 6 ─ 附錄:模組速查與結論

---

## 第 31 章:核心模組 / 套件速查表

### 31.1 模組速查 (依 transfer-app classpath 載入順序)

| # | 模組 | artifactId | 內含主要元件 | 在生命週期中的角色 |
| :--- | :--- | :--- | :--- | :--- |
| 1 | platform-common | `platform-common` | `PlatformPaths` | 路徑解析、跨平台 |
| 2 | platform-security | `platform-security` | `SonataFlowSecurityConfig$RuntimeFilter` / `SwaggerFilter`, `UnwrapResponseFilter` | 橫切安全 |
| 3 | platform-data-index | `platform-data-index` | `PlatformConfigSource`, `KogitoSQLiteDialect`, `MyLivenessCheck` | Data Index + 自訂 dialect |
| 4 | transfer-mock | `transfer-mock` | `A16220Resource`, `A16229Resource`, DTO | 外部系統模擬器 JAX-RS mock |
| 5 | transfer-workflow | `transfer-workflow` | 2 個 `*.sw.yaml`, `SagaApiService`, `MyOpenApiService`, OpenAPI specs | 業務 workflow + 合約 |
| 6 | transfer-samples | `transfer-samples` | 3 個 `*.sw.yaml` 示範, `ApiService` | 展示功能 |
| 7 | reconciliation-api | `reconciliation-api` | `ReconciliationResource`, `AuditLogService`, `AuditQueryService`, `ReconciliationCsvExporter` | 對帳與 audit |
| 8 | platform-extensions/* | `data-index-storage-sqlite` 等 3 個 | Storage, Deployment processor | Kogito SQLite 修補 |
| 9 | distribution/transfer-app | `transfer-app` | `application.properties`, 靜態 HTML, codegen 產物 | ⭐ 主程式入口 |

### 31.2 套件 (dependency) 速查

#### 31.2.1 Quarkus 核心 (BOM 對齊 3.27.2)

| artifactId | 角色 |
| :--- | :--- |
| `quarkus-arc` | CDI (相依注入) |
| `quarkus-resteasy` | JAX-RS (REST) |
| `quarkus-resteasy-jackson` | JSON 序列化 |
| `quarkus-smallrye-openapi` | OpenAPI 文件 |
| `quarkus-smallrye-health` | `/q/health` endpoint |
| `quarkus-hibernate-orm` (transitive) | ORM (透過 platform-data-index) |
| `quarkus-agroal` (transitive) | JDBC 連線池 |
| `quarkus-vertx` (transitive) | HTTP server + Event Loop |
| `quarkus-junit5` (test) | 測試框架 |
| `quarkus-kubernetes` | k8s 部署描述 |

#### 31.2.2 Kogito / SonataFlow (BOM 對齊 10.2.0)

| artifactId | 角色 |
| :--- | :--- |
| `sonataflow-quarkus` | CNCF Serverless Workflow 引擎 |
| `kie-addons-quarkus-process-management` | Process 引擎管理 |
| `kie-addons-quarkus-source-files` | `.sw.yaml` 資源掃描 |
| `kogito-addons-quarkus-data-index-sqlite` | Data Index + SQLite (修補) |
| `kogito-addons-quarkus-data-index-persistence-sqlite` | Data Index 持久化 (修補) |

#### 31.2.3 第三方

| artifactId | 版本 | 角色 |
| :--- | :--- | :--- |
| `sqlite-jdbc` (xerial) | 3.45.1.0 | SQLite JDBC driver |
| `hibernate-community-dialects` | (BOM) | SQLite dialect 基底 |
| `jackson-databind` | (BOM) | JSON 處理 |
| `jackson-dataformat-yaml` | (BOM) | OpenAPI YAML 解析 |
| `jackson-jq` (kogito transitive) | (BOM) | jq 表達式 (workflow 內 `${ .x }`) |
| `slf4j-api` | (BOM) | 日誌 facade |
| `jboss-logging` | (BOM) | Quarkus 日誌實作 |
| `rest-assured` | 5.5.0 | 整合測試 |

#### 31.2.4 Maven Plugin

| artifactId | 版本 | 角色 |
| :--- | :--- | :--- |
| `maven-compiler-plugin` | 3.15.0 | Java 編譯 |
| `maven-resources-plugin` | (Maven 內建) | 跨模組資源同步 |
| `maven-surefire-plugin` | 3.5.6 | 測試執行 |
| `jandex-maven-plugin` | 3.2.7 | CDI bean 索引 |
| `quarkus-maven-plugin` | 3.27.2 | build-time augmentation |

### 31.3 環境變數速查

| 變數 | 預設值 | 用途 |
| :--- | :--- | :--- |
| `MYHELLO_DATA_DIR` | `${project.basedir}/data` (自動推導) | SQLite 資料檔位置 |
| `MYHELLO_LOGS_DIR` | `${project.basedir}/logs` (自動推導) | 應用日誌位置 |
| `JAVA_OPTS` / `_JAVA_OPTIONS` | — | JVM 調校 (例如 `-Xmx2g`) |

### 31.4 REST 端點速查 (transfer-app, port 8080)

| Method | Path | 用途 |
| :--- | :--- | :--- |
| POST | `/A16229` | mock A16229 API (transfer-mock) |
| POST | `/A16220` | mock A16220 API (transfer-mock) |
| POST | `/saga-transfer-workflow` | 啟動 saga-transfer-workflow |
| POST | `/saga2-transfer-workflow` | 啟動 saga2-transfer-workflow |
| GET  | `/saga2-transfer-workflow/{id}` | 查詢 instance 狀態 |
| POST | `/OpenAPI-workflow` | 示範 workflow |
| POST | `/java-workflow` | 示範 workflow |
| POST | `/rest-workflow` | 示範 workflow |
| GET  | `/reconciliation/export-csv` | 對帳 CSV 匯出 |
| POST | `/reconciliation/export-csv` | 對帳 CSV 匯出 (with body) |
| GET  | `/api/reconciliation/records` | 查詢對帳紀錄 |
| GET  | `/api/reconciliation/files` | 列出匯出檔案 |
| GET  | `/q/health` | SmallRye Health |
| GET  | `/q/health/ready` | Readiness |
| GET  | `/q/health/live` | Liveness |
| GET  | `/q/openapi` | OpenAPI 文件 |
| GET  | `/q/openapi-ui` | Swagger UI |
| GET  | `/q/dev-ui` | Dev mode UI (僅 dev mode) |
| GET  | `/q/graphql-ui` | Kogito Data Index GraphiQL |
| POST | `/graphql` | Kogito Data Index GraphQL 查詢 |
| GET  | `/` | index.html |
| GET  | `/dashboard.html` | 自訂 dashboard |
| GET  | `/instances.html` | Instance 查詢頁 |

### 31.5 檔案產物速查

| 產物 | 路徑 | 用途 |
| :--- | :--- | :--- |
| `quarkus-run.jar` | `distribution/transfer-app/target/quarkus-app/` | 啟動入口 |
| `transfer-app-1.0.0-SNAPSHOT.jar` | 同上 `/app/` | 應用本體 |
| `lib/boot/*.jar` | 同上 | Quarkus 啟動器依賴 |
| `lib/main/*.jar` | 同上 | 應用依賴 |
| `data/reconciliation.db` | `${MYHELLO_DATA_DIR}` | SQLite 資料庫 |
| `data/reconciliation.db-wal` | 同上 | WAL 暫存 |
| `data/reconciliation-*.csv` | 同上 | 對帳匯出檔 |
| `logs/transfer-app.log` | `${MYHELLO_LOGS_DIR}` | 應用日誌 (rotation 10M x10) |

---

## 第 32 章:結論與排查指引

### 32.1 transfer-app 整體生命週期一覽

```mermaid
flowchart LR
    A["mvn clean package"] --> B["target/quarkus-app/"]
    B --> C["java -jar quarkus-run.jar"]
    C --> D["Quarkus 7 階段啟動"]
    D --> E["Running<br/>HTTP :8080<br/>+ 5 workflows<br/>+ 2 mock APIs<br/>+ 對帳查詢<br/>+ Data Index"]
    E --> F["SIGTERM"]
    F --> G["Quarkus 優雅關機"]
    G --> H["JVM 退出"]

    D --> D1["Static Init<br/>(PlatformConfigSource,<br/>Hibernate listener)"]
    D --> D2["Config Init<br/>(MP Config 合併)"]
    D --> D3["Runtime Init<br/>(DataSource, Hibernate,<br/>ARC, RESTEasy,<br/>SonataFlow, Data Index)"]
    D --> D4["App Start<br/>(AuditLog 建表)"]

    E --> E1["POST /saga2-transfer-workflow"]
    E1 --> E2["RuntimeFilter 放行"]
    E2 --> E3["SonataFlow Engine 執行"]
    E3 --> E4["MyOpenApiService 動態呼叫"]
    E4 --> E5["A16229/A16220 mock"]
    E3 --> E6["AuditLogService 寫入"]
    E3 --> E7["Data Index 雙寫"]
    E3 --> E8["UnwrapResponseFilter"]
    E8 --> E9["200 + JSON"]
```

### 32.2 套件 / 模組互動全景

```mermaid
graph TB
    subgraph "Build 階段"
        M1["Maven Reactor"] --> M2["jandex-maven-plugin"]
        M1 --> M3["quarkus-maven-plugin"]
        M3 --> M4["Kogito codegen"]
        M3 --> M5["@BuildStep processors"]
    end

    subgraph "Bootstrap 階段"
        B1["QuarkusEntryPoint"] --> B2["Quarkus.run()"]
        B2 --> B3["PlatformConfigSource"]
        B2 --> B4["Hibernate listener"]
        B2 --> B5["DataSource (Agroal + SQLite)"]
        B2 --> B6["ARC (CDI)"]
        B2 --> B7["RESTEasy"]
        B2 --> B8["SonataFlow Engine"]
        B2 --> B9["Data Index"]
    end

    subgraph "Runtime 階段"
        R1["POST /saga2-transfer-workflow"] --> R2["RuntimeFilter"]
        R2 --> R3["Saga2TransferWorkflowResource"]
        R3 --> R4["Engine"]
        R4 --> R5["MyOpenApiService"]
        R4 --> R6["AuditLogService"]
        R5 --> R7["A16229/A16220"]
        R6 --> R8["SQLite WAL"]
        R9["Data Index 雙寫"] --> R8
        R4 --> R10["UnwrapResponseFilter"]
    end

    subgraph "Shutdown 階段"
        S1["SIGTERM"] --> S2["PreShutdownEvent"]
        S2 --> S3["Vert.x close"]
        S3 --> S4["ShutdownEvent"]
        S4 --> S5["DataSource close"]
        S5 --> S6["WAL checkpoint"]
        S6 --> S7["JVM exit"]
    end

    M2 --> B6
    M4 --> B8
    M5 --> B5
    M5 --> B9
    B5 --> R8
    B8 --> R4
    B9 --> R9
    B3 --> B6
    B3 --> B7
```

### 32.3 關鍵設計決策

| 決策 | 理由 |
| :--- | :--- |
| 多模組 + 單向 DAG | 業務可獨立演進,平台可橫向重用 |
| distribution 層只組合 | 避免 domain 反向依賴 platform |
| `type: custom` 取代 OpenAPI addon | spec 0.8 OpenAPI addon 4xx 寫死拋例外,客製 service 才能控制錯誤流 |
| `SagaApiService` 用 JDK HttpClient | 高併發、非阻塞、支援 CompletionStage |
| `MyOpenApiService` 4 層快取 | 避免重複 Classpath IO + YAML parse + Config 讀取 |
| `AuditLogService` 在 StartupEvent 建表 | Flyway 為 Data Index,Kogito audit 表自管 |
| `db-kind=other` + 手動 driver | Quarkus 3.27 沒有內建 sqlite, 需明確指定 |
| `KogitoSQLiteDialect` 自訂 | 解決 ZonedDateTime 解析 bug |
| `PlatformConfigSource` ordinal=250 | 高於 application.properties,低於 env |
| `transfer-app` 不寫 Java 源碼 | 純組裝 + properties + 靜態 HTML |

### 32.4 常見問題排查

| 現象 | 可能原因 | 排查工具 |
| :--- | :--- | :--- |
| 啟動失敗 `No suitable driver` | `org.sqlite.JDBC` 不在 classpath | `jar tf quarkus-run.jar | grep sqlite` |
| 啟動失敗 `Unable to expand MYHELLO_DATA_DIR` | `PlatformConfigSource` 沒被載入 | 檢查 `META-INF/services/org.eclipse.microprofile.config.spi.ConfigSource` |
| Workflow 找不到 operation | OpenAPI YAML 沒被同步到 transfer-app | 檢查 `src/main/resources/specs/*.yaml` |
| GraphQL 回 `Error parsing time stamp` | `SqliteZonedDateTimeIntegrationListener` 沒生效 | 檢查 listener 註冊 log, `clared cached Type on N SimpleValues` |
| HTTP 403 on workflow | 用了 GET 而非 POST,或 path 在白名單外 | 查 `RuntimeFilter` 白名單 |
| HTTP 400 on validation fail (saga2) | `UnwrapResponseFilter` 改 status code | 屬正常行為 |
| 對帳紀錄查詢無資料 | `audit_workflow_id` 不是 `saga2-transfer-workflow` | 查 `vw_saga_reconciliation` WHERE 子句 |
| SQLite locked | 多 writer 同時寫入 | WAL 模式只允許 1 writer, 確認 max-size=1 |
| Workflow 4xx 拋例外 | 用了 OpenAPI addon 而非 custom service | 確認 `type: custom` + `service:` operation |

### 32.5 對 SonataFlow 10.2.0 的限制提醒

`transfer-app` 的 workflow 刻意避開 spec 0.8 這些未完整實作的功能:

- `Retries` policy
- `Sleep` state
- per-action `Timeouts`
- `resultEventRef`
- output schema validation

改用:
- `type: switch` + `dataConditions` 取代 Retries
- `type: inject` state 取代 Sleep
- 整個 workflow `timeouts.workflowExecTimeout: PT5M` 取代 per-action
  （v2.1.0 更新：已補上 operation state 層的 `actionExecTimeout`/`stateExecTimeout`
  與各 state `onErrors` 兜底，形成 HTTP 10s → state 15s/30s → workflow PT5M 三層防線）
- `stateDataFilter.output` 取代 output schema

### 32.6 結語

`transfer-app` 模組在整個生命週期中,展現了 Quarkus + SonataFlow 多模組專案的**典型協作模式**:

- **編譯期**:Maven Reactor 編譯 7 個子模組 → Jandex 索引 → Quarkus build-time augmentation → Kogito codegen → quarkus-app/ 組裝
- **啟動期**:Quarkus 7 階段管線,PlatformConfigSource 注入環境,Hibernate listener 修補,CDI 啟動,SonataFlow 引擎註冊,StartupEvent 建表
- **執行期**:RuntimeFilter 放行 POST → codegen 產生的 *Resource → Engine 跑 state machine → 自訂 service (SagaApiService / MyOpenApiService / AuditLogService) → Data Index 雙寫 → UnwrapResponseFilter 解包回應
- **關機期**:SIGTERM → Quarkus 優雅關機 → DataSource 關閉 → WAL 保留 → JVM 退出

每個階段都有對應的 Maven plugin、Quarkus extension、SonataFlow engine、平台模組或第三方套件在背後支撐,構成一個**完整且可獨立部署**的企業級金融交易編排應用。

---

> **文件結束 — TRANSFER-APP-LIFECYCLE-ANALYSIS.md**
