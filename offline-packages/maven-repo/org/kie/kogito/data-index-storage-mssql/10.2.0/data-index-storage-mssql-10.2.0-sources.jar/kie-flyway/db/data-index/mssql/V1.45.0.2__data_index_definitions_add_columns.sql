/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

-- V1.45.0.2__data_index_definitions_add_columns.sql (MSSQL port)
-- Adds annotations/metadata tables + description column on definitions.
-- Note: `key` is reserved in T-SQL, so it is bracketed as [key].

IF OBJECT_ID(N'definitions_annotations', N'U') IS NULL
CREATE TABLE definitions_annotations (
    value            NVARCHAR(255) NOT NULL,
    process_id       NVARCHAR(255) NOT NULL,
    process_version  NVARCHAR(255) NOT NULL,
    PRIMARY KEY (value, process_id, process_version)
);

IF OBJECT_ID(N'definitions_metadata', N'U') IS NULL
CREATE TABLE definitions_metadata (
    process_id       NVARCHAR(255) NOT NULL,
    process_version  NVARCHAR(255) NOT NULL,
    value            NVARCHAR(255),
    [key]            NVARCHAR(255) NOT NULL,
    PRIMARY KEY (process_id, process_version, [key])
);

IF EXISTS (SELECT 1 FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'fk_definitions_annotations') AND parent_object_id = OBJECT_ID(N'definitions_annotations'))
    ALTER TABLE definitions_annotations DROP CONSTRAINT fk_definitions_annotations;

IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'fk_definitions_annotations') AND parent_object_id = OBJECT_ID(N'definitions_annotations'))
    ALTER TABLE definitions_annotations
        ADD CONSTRAINT fk_definitions_annotations
        FOREIGN KEY (process_id, process_version) REFERENCES definitions
        ON DELETE CASCADE;

IF EXISTS (SELECT 1 FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'fk_definitions_metadata') AND parent_object_id = OBJECT_ID(N'definitions_metadata'))
    ALTER TABLE definitions_metadata DROP CONSTRAINT fk_definitions_metadata;

IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'fk_definitions_metadata') AND parent_object_id = OBJECT_ID(N'definitions_metadata'))
    ALTER TABLE definitions_metadata
        ADD CONSTRAINT fk_definitions_metadata
        FOREIGN KEY (process_id, process_version) REFERENCES definitions
        ON DELETE CASCADE;

IF NOT EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID(N'definitions') AND name = N'description')
    ALTER TABLE definitions ADD description NVARCHAR(255);
