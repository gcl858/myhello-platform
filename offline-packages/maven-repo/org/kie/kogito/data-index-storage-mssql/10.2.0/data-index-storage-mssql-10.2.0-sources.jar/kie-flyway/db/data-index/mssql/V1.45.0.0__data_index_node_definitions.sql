/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

-- V1.45.0.0__data_index_node_definitions.sql (MSSQL port)
-- Note: `key` is a reserved word in T-SQL, so the column is bracketed as [key].

IF OBJECT_ID(N'definitions_nodes', N'U') IS NULL
CREATE TABLE definitions_nodes (
    id               NVARCHAR(255) NOT NULL,
    name             NVARCHAR(255),
    unique_id        NVARCHAR(255),
    type             NVARCHAR(255),
    process_id       NVARCHAR(255) NOT NULL,
    process_version  NVARCHAR(255) NOT NULL,
    PRIMARY KEY (id, process_id, process_version)
);

IF OBJECT_ID(N'definitions_nodes_metadata', N'U') IS NULL
CREATE TABLE definitions_nodes_metadata (
    node_id          NVARCHAR(255) NOT NULL,
    process_id       NVARCHAR(255) NOT NULL,
    process_version  NVARCHAR(255) NOT NULL,
    value            NVARCHAR(255),
    [key]            NVARCHAR(255) NOT NULL,
    PRIMARY KEY (node_id, process_id, process_version, [key])
);

IF EXISTS (SELECT 1 FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'fk_definitions_nodes_definitions') AND parent_object_id = OBJECT_ID(N'definitions_nodes'))
    ALTER TABLE definitions_nodes DROP CONSTRAINT fk_definitions_nodes_definitions;

IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'fk_definitions_nodes_definitions') AND parent_object_id = OBJECT_ID(N'definitions_nodes'))
    ALTER TABLE definitions_nodes
        ADD CONSTRAINT fk_definitions_nodes_definitions
        FOREIGN KEY (process_id, process_version) REFERENCES definitions
        ON DELETE CASCADE;

IF EXISTS (SELECT 1 FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'fk_definitions_nodes_metadata_definitions_nodes') AND parent_object_id = OBJECT_ID(N'definitions_nodes_metadata'))
    ALTER TABLE definitions_nodes_metadata DROP CONSTRAINT fk_definitions_nodes_metadata_definitions_nodes;

IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'fk_definitions_nodes_metadata_definitions_nodes') AND parent_object_id = OBJECT_ID(N'definitions_nodes_metadata'))
    ALTER TABLE definitions_nodes_metadata
        ADD CONSTRAINT fk_definitions_nodes_metadata_definitions_nodes
        FOREIGN KEY (node_id, process_id, process_version) REFERENCES definitions_nodes
        ON DELETE CASCADE;
