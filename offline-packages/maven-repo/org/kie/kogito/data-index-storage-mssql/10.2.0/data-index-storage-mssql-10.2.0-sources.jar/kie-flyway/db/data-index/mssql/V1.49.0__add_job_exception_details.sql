/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

-- V1.49.0__add_job_exception_details.sql (MSSQL port)
-- Original PG: exception_message VARCHAR (unbounded), exception_details TEXT.
-- In MSSQL we use NVARCHAR(MAX) and NVARCHAR(MAX) respectively. NVARCHAR(MAX) is
-- functionally identical to PG's TEXT and the unbounded VARCHAR.

IF NOT EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID(N'jobs') AND name = N'exception_message')
    ALTER TABLE jobs ADD exception_message NVARCHAR(MAX);

IF NOT EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID(N'jobs') AND name = N'exception_details')
    ALTER TABLE jobs ADD exception_details NVARCHAR(MAX);
