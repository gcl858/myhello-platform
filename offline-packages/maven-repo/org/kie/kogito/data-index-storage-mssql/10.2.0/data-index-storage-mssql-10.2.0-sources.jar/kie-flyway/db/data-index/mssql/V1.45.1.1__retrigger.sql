/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

-- V1.45.1.1__retrigger.sql (MSSQL port)
-- PG types: boolean -> BIT, varchar(65535) -> NVARCHAR(MAX), varchar(255) -> NVARCHAR(255).

IF NOT EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID(N'nodes') AND name = N'retrigger')
    ALTER TABLE nodes ADD retrigger BIT NOT NULL CONSTRAINT DF_nodes_retrigger DEFAULT 0;

IF NOT EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID(N'nodes') AND name = N'error_message')
    ALTER TABLE nodes ADD error_message NVARCHAR(MAX);

IF NOT EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID(N'processes') AND name = N'node_instance_id')
    ALTER TABLE processes ADD node_instance_id NVARCHAR(255);
