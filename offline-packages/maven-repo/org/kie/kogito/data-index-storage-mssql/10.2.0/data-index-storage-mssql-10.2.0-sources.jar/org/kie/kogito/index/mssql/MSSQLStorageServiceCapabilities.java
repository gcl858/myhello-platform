/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
package org.kie.kogito.index.mssql;

import java.util.Set;

import org.kie.kogito.persistence.api.StorageServiceCapability;
import org.kie.kogito.persistence.api.StorageServiceCapabilityProvider;

/**
 * Capability provider for the MSSQL-backed Data Index storage.
 *
 * Microsoft SQL Server supports JSON path queries via {@code JSON_VALUE} / {@code JSON_QUERY}
 * since version 2016, so we declare {@link StorageServiceCapability#JSON_QUERY} the same
 * way the PostgreSQL provider does.
 */
public class MSSQLStorageServiceCapabilities implements StorageServiceCapabilityProvider {

    @Override
    public Set<StorageServiceCapability> capabilities() {
        return Set.of(StorageServiceCapability.JSON_QUERY);
    }
}
