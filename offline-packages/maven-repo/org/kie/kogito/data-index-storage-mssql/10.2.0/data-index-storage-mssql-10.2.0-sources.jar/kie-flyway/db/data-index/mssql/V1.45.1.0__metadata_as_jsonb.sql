/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

-- V1.45.1.0__metadata_as_jsonb.sql (MSSQL port)
--
-- Original PG: collapses a key/value table (definitions_metadata) into a single
--              `metadata jsonb` column on `definitions`. Aggregation uses
--              `json_object_agg(name, meta_value)`.
-- MSSQL port:  the `metadata` column becomes NVARCHAR(MAX) and is populated with a
--              JSON object string. We aggregate using FOR XML PATH (works on every
--              supported SQL Server version, unlike STRING_AGG which needs 2017+).
--              Result: `{"name1":"value1","name2":"value2",...}`.
--
-- WARNING: this script does basic JSON escaping (backslash and double-quote). It
--          does not handle other control characters or unicode escapes. If your
--          data contains those, you should sanitise on the application side.

IF NOT EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID(N'definitions') AND name = N'metadata')
    ALTER TABLE definitions ADD metadata NVARCHAR(MAX);

-- Aggregate definitions_metadata rows into a single JSON object per (process_id, process_version).
-- Strategy: use a CTE that groups rows and builds the JSON via FOR XML PATH + STUFF for the wrapping braces.
;WITH grouped AS (
    SELECT
        dm.process_id,
        dm.process_version,
        '{' + STUFF((
            SELECT ','
                 + '"' + REPLACE(REPLACE(ISNULL(dm2.[name], ''), '\', '\\'), '"', '\"') + '":'
                 + CASE
                       WHEN dm2.meta_value IS NULL THEN 'null'
                       ELSE '"' + REPLACE(REPLACE(dm2.meta_value, '\', '\\'), '"', '\"') + '"'
                   END
            FROM definitions_metadata dm2
            WHERE dm2.process_id = dm.process_id
              AND dm2.process_version = dm.process_version
            FOR XML PATH(''), TYPE
        ).value('.', 'NVARCHAR(MAX)'), 1, 1, '') + '}' AS v
    FROM definitions_metadata dm
    GROUP BY dm.process_id, dm.process_version
)
UPDATE d
SET d.metadata = g.v
FROM definitions d
INNER JOIN grouped g
    ON d.id = g.process_id
   AND d.version = g.process_version;

DROP TABLE definitions_metadata;
