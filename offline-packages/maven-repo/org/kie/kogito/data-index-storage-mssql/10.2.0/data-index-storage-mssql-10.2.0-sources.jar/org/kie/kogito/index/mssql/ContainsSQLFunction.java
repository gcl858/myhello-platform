/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
package org.kie.kogito.index.mssql;

import java.util.Iterator;
import java.util.List;

import org.hibernate.dialect.function.StandardSQLFunction;
import org.hibernate.metamodel.model.domain.ReturnableType;
import org.hibernate.sql.ast.SqlAstTranslator;
import org.hibernate.sql.ast.spi.SqlAppender;
import org.hibernate.sql.ast.tree.SqlAstNode;
import org.hibernate.type.BasicTypeReference;
import org.hibernate.type.SqlTypes;

/**
 * Hibernate custom function for JSON containment checks on Microsoft SQL Server.
 *
 * Renders T-SQL fragments equivalent to PostgreSQL's jsonb @> / ?& / ?| operators.
 * <ul>
 * <li>{@code contains(j, val)} → checks if {@code j} (NVARCHAR JSON column) contains
 * a top-level element whose value equals {@code val}.</li>
 * <li>{@code containsAll(j, v1, v2, ...)} → checks if {@code j} contains <b>all</b> of
 * the supplied values (AND of EXISTS checks).</li>
 * <li>{@code containsAny(j, v1, v2, ...)} → checks if {@code j} contains <b>any</b> of
 * the supplied values (EXISTS with IN clause).</li>
 * </ul>
 */
public class ContainsSQLFunction extends StandardSQLFunction {

    static final String CONTAINS_NAME = "contains";
    static final String CONTAINS_ALL_NAME = "containsAll";
    static final String CONTAINS_ANY_NAME = "containsAny";

    private static final BasicTypeReference<Boolean> RETURN_TYPE =
            new BasicTypeReference<>("boolean", Boolean.class, SqlTypes.BOOLEAN);

    /**
     * @param name function name to register
     * @param all true for {@code containsAll} (all values must be present), false for
     *        {@code contains} / {@code containsAny} (one value or any value present).
     */
    ContainsSQLFunction(String name, boolean all) {
        super(name, RETURN_TYPE);
        this.all = all;
    }

    private final boolean all;

    @Override
    public void render(
            SqlAppender sqlAppender,
            List<? extends SqlAstNode> args,
            ReturnableType<?> returnType,
            SqlAstTranslator<?> translator) {
        int size = args.size();
        if (size < 2) {
            throw new IllegalArgumentException("Function " + getName() + " requires at least two arguments");
        }
        // First argument is the JSON document (NVARCHAR(MAX)). It is re-emitted inline for
        // each EXISTS check, which Hibernate/SQL Server can safely re-execute.
        Iterator<? extends SqlAstNode> iter = args.iterator();
        SqlAstNode jsonDoc = iter.next();

        if (all && size > 2) {
            // containsAll: AND across individual EXISTS checks (one per value).
            sqlAppender.append('(');
            boolean first = true;
            while (iter.hasNext()) {
                if (!first) {
                    sqlAppender.append(" AND ");
                }
                sqlAppender.append("ISJSON(");
                jsonDoc.accept(translator);
                sqlAppender.append(") = 1 AND EXISTS (SELECT 1 FROM OPENJSON(");
                jsonDoc.accept(translator);
                sqlAppender.append(") AS doc WHERE CAST(doc.[value] AS NVARCHAR(MAX)) = CAST(");
                iter.next().accept(translator);
                sqlAppender.append(" AS NVARCHAR(MAX)))");
                first = false;
            }
            sqlAppender.append(')');
        } else {
            // contains (single value) or containsAny (multi value): single EXISTS with IN clause.
            sqlAppender.append("(ISJSON(");
            jsonDoc.accept(translator);
            sqlAppender.append(") = 1 AND EXISTS (SELECT 1 FROM OPENJSON(");
            jsonDoc.accept(translator);
            sqlAppender.append(") AS doc WHERE CAST(doc.[value] AS NVARCHAR(MAX)) IN (");
            boolean first = true;
            while (iter.hasNext()) {
                if (!first) {
                    sqlAppender.append(", ");
                }
                iter.next().accept(translator);
                first = false;
            }
            sqlAppender.append(")))");
        }
    }
}
