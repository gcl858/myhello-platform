Ensure migration scripts are developed to support several executions over the same database without any error.
This feature will make sure this migration execution would be compatible with other needed flyway migrations without broking the chain.

IMPORTANT: Due to the strong dependency between this module and persistence-commons-mssql please be sure that any new
Flyway migration added here uses a consistent version that doesn't collide with persistence-commons-mssql

This folder contains the Microsoft SQL Server (T-SQL) port of the Data Index Flyway
migrations. They are equivalent in semantics to the postgresql/ folder; only the SQL
dialect differs. See the top of each file for translation notes (jsonb -> NVARCHAR(MAX),
IF NOT EXISTS wrappers, reserved-word brackets, etc.).
