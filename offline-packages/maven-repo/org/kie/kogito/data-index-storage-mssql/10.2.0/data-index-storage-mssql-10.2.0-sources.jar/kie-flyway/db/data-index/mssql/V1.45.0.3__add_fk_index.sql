/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

-- V1.45.0.3__add_fk_index.sql (MSSQL port)
-- CREATE INDEX IF NOT EXISTS does not exist in T-SQL; use a sys.indexes guard instead.

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'attachments') AND name = N'idx_attachments_tid')
    CREATE INDEX idx_attachments_tid ON attachments(task_id);

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'comments') AND name = N'idx_comments_tid')
    CREATE INDEX idx_comments_tid ON comments(task_id);

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'definitions_addons') AND name = N'idx_definitions_addons_pid_pv')
    CREATE INDEX idx_definitions_addons_pid_pv ON definitions_addons(process_id, process_version);

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'definitions_annotations') AND name = N'idx_definitions_annotations_pid_pv')
    CREATE INDEX idx_definitions_annotations_pid_pv ON definitions_annotations(process_id, process_version);

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'definitions_metadata') AND name = N'idx_definitions_metadata_pid_pv')
    CREATE INDEX idx_definitions_metadata_pid_pv ON definitions_metadata(process_id, process_version);

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'definitions_nodes') AND name = N'idx_definitions_nodes_pid_pv')
    CREATE INDEX idx_definitions_nodes_pid_pv ON definitions_nodes(process_id, process_version);

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'definitions_nodes_metadata') AND name = N'idx_definitions_nodes_metadata_pid_pv')
    CREATE INDEX idx_definitions_nodes_metadata_pid_pv ON definitions_nodes_metadata(process_id, process_version);

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'definitions_roles') AND name = N'idx_definitions_roles_pid_pv')
    CREATE INDEX idx_definitions_roles_pid_pv ON definitions_roles(process_id, process_version);

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'milestones') AND name = N'idx_milestones_piid')
    CREATE INDEX idx_milestones_piid ON milestones(process_instance_id);

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'nodes') AND name = N'idx_nodes_piid')
    CREATE INDEX idx_nodes_piid ON nodes(process_instance_id);

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'processes_addons') AND name = N'idx_processes_addons_pid')
    CREATE INDEX idx_processes_addons_pid ON processes_addons(process_id);

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'processes_roles') AND name = N'idx_processes_roles_pid')
    CREATE INDEX idx_processes_roles_pid ON processes_roles(process_id);

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'tasks_admin_groups') AND name = N'idx_tasks_admin_groups_tid')
    CREATE INDEX idx_tasks_admin_groups_tid ON tasks_admin_groups(task_id);

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'tasks_admin_users') AND name = N'idx_tasks_admin_users_tid')
    CREATE INDEX idx_tasks_admin_users_tid ON tasks_admin_users(task_id);

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'tasks_excluded_users') AND name = N'idx_tasks_excluded_users_tid')
    CREATE INDEX idx_tasks_excluded_users_tid ON tasks_excluded_users(task_id);

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'tasks_potential_groups') AND name = N'idx_tasks_potential_groups_tid')
    CREATE INDEX idx_tasks_potential_groups_tid ON tasks_potential_groups(task_id);

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'tasks_potential_users') AND name = N'idx_tasks_potential_users_tid')
    CREATE INDEX idx_tasks_potential_users_tid ON tasks_potential_users(task_id);
