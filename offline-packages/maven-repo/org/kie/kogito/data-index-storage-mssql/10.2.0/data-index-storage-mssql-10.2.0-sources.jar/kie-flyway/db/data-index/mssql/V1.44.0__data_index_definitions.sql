/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

-- V1.44.0__data_index_definitions.sql (MSSQL port)
-- Original PostgreSQL: bytea -> VARBINARY(MAX), varchar -> NVARCHAR.

IF OBJECT_ID(N'definitions', N'U') IS NULL
CREATE TABLE definitions (
    id        NVARCHAR(255) NOT NULL,
    version   NVARCHAR(255) NOT NULL,
    name      NVARCHAR(255),
    type      NVARCHAR(255),
    source    VARBINARY(MAX), -- was bytea
    endpoint  NVARCHAR(255),
    PRIMARY KEY (id, version)
);

IF OBJECT_ID(N'definitions_addons', N'U') IS NULL
CREATE TABLE definitions_addons (
    process_id       NVARCHAR(255) NOT NULL,
    process_version  NVARCHAR(255) NOT NULL,
    addon            NVARCHAR(255) NOT NULL,
    PRIMARY KEY (process_id, process_version, addon)
);

IF OBJECT_ID(N'definitions_roles', N'U') IS NULL
CREATE TABLE definitions_roles (
    process_id       NVARCHAR(255) NOT NULL,
    process_version  NVARCHAR(255) NOT NULL,
    role             NVARCHAR(255) NOT NULL,
    PRIMARY KEY (process_id, process_version, role)
);

IF EXISTS (SELECT 1 FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'fk_definitions_addons_definitions') AND parent_object_id = OBJECT_ID(N'definitions_addons'))
    ALTER TABLE definitions_addons DROP CONSTRAINT fk_definitions_addons_definitions;

IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'fk_definitions_addons_definitions') AND parent_object_id = OBJECT_ID(N'definitions_addons'))
    ALTER TABLE definitions_addons
        ADD CONSTRAINT fk_definitions_addons_definitions
        FOREIGN KEY (process_id, process_version) REFERENCES definitions
        ON DELETE CASCADE;

IF EXISTS (SELECT 1 FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'fk_definitions_roles_definitions') AND parent_object_id = OBJECT_ID(N'definitions_roles'))
    ALTER TABLE definitions_roles DROP CONSTRAINT fk_definitions_roles_definitions;

IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'fk_definitions_roles_definitions') AND parent_object_id = OBJECT_ID(N'definitions_roles'))
    ALTER TABLE definitions_roles
        ADD CONSTRAINT fk_definitions_roles_definitions
        FOREIGN KEY (process_id, process_version) REFERENCES definitions
        ON DELETE CASCADE;

-- Add version column to processes
IF NOT EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID(N'processes') AND name = N'version')
    ALTER TABLE processes ADD version NVARCHAR(255);
