/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

-- V1.32.0__data_index_create.sql (MSSQL port)
-- Original: PostgreSQL. Ported to T-SQL.
-- Notes on the translation:
--   * PG types:    varchar -> NVARCHAR, int4 -> INT, int8 -> BIGINT,
--                  timestamp -> DATETIME2, jsonb -> NVARCHAR(MAX) (JSON text)
--   * IF NOT EXISTS wraps are required because SQL Server has no DDL IF NOT EXISTS.

IF OBJECT_ID(N'attachments', N'U') IS NULL
CREATE TABLE attachments (
    id          NVARCHAR(255) NOT NULL,
    content     NVARCHAR(255),
    name        NVARCHAR(255),
    updated_at  DATETIME2,
    updated_by  NVARCHAR(255),
    task_id     NVARCHAR(255) NOT NULL,
    PRIMARY KEY (id)
);

IF OBJECT_ID(N'comments', N'U') IS NULL
CREATE TABLE comments (
    id          NVARCHAR(255) NOT NULL,
    content     NVARCHAR(255),
    name        NVARCHAR(255),
    updated_at  DATETIME2,
    updated_by  NVARCHAR(255),
    task_id     NVARCHAR(255) NOT NULL,
    PRIMARY KEY (id)
);

IF OBJECT_ID(N'jobs', N'U') IS NULL
CREATE TABLE jobs (
    id                        NVARCHAR(255) NOT NULL,
    callback_endpoint         NVARCHAR(255),
    endpoint                  NVARCHAR(255),
    execution_counter         INT,
    expiration_time           DATETIME2,
    last_update               DATETIME2,
    node_instance_id          NVARCHAR(255),
    priority                  INT,
    process_id                NVARCHAR(255),
    process_instance_id       NVARCHAR(255),
    repeat_interval           BIGINT,
    repeat_limit              INT,
    retries                   INT,
    root_process_id           NVARCHAR(255),
    root_process_instance_id  NVARCHAR(255),
    scheduled_id              NVARCHAR(255),
    status                    NVARCHAR(255),
    PRIMARY KEY (id)
);

IF OBJECT_ID(N'milestones', N'U') IS NULL
CREATE TABLE milestones (
    id                   NVARCHAR(255) NOT NULL,
    process_instance_id  NVARCHAR(255) NOT NULL,
    name                 NVARCHAR(255),
    status               NVARCHAR(255),
    PRIMARY KEY (id, process_instance_id)
);

IF OBJECT_ID(N'nodes', N'U') IS NULL
CREATE TABLE nodes (
    id                   NVARCHAR(255) NOT NULL,
    definition_id        NVARCHAR(255),
    enter                DATETIME2,
    exit                 DATETIME2,
    name                 NVARCHAR(255),
    node_id              NVARCHAR(255),
    type                 NVARCHAR(255),
    process_instance_id  NVARCHAR(255) NOT NULL,
    PRIMARY KEY (id)
);

IF OBJECT_ID(N'processes', N'U') IS NULL
CREATE TABLE processes (
    id                          NVARCHAR(255) NOT NULL,
    business_key                NVARCHAR(255),
    end_time                    DATETIME2,
    endpoint                    NVARCHAR(255),
    message                     NVARCHAR(255),
    node_definition_id          NVARCHAR(255),
    last_update_time            DATETIME2,
    parent_process_instance_id  NVARCHAR(255),
    process_id                  NVARCHAR(255),
    process_name                NVARCHAR(255),
    root_process_id             NVARCHAR(255),
    root_process_instance_id    NVARCHAR(255),
    start_time                  DATETIME2,
    state                       INT,
    variables                   NVARCHAR(MAX), -- was jsonb
    PRIMARY KEY (id)
);

IF OBJECT_ID(N'processes_addons', N'U') IS NULL
CREATE TABLE processes_addons (
    process_id  NVARCHAR(255) NOT NULL,
    addon       NVARCHAR(255) NOT NULL,
    PRIMARY KEY (process_id, addon)
);

IF OBJECT_ID(N'processes_roles', N'U') IS NULL
CREATE TABLE processes_roles (
    process_id  NVARCHAR(255) NOT NULL,
    role        NVARCHAR(255) NOT NULL,
    PRIMARY KEY (process_id, role)
);

IF OBJECT_ID(N'tasks', N'U') IS NULL
CREATE TABLE tasks (
    id                        NVARCHAR(255) NOT NULL,
    actual_owner              NVARCHAR(255),
    completed                 DATETIME2,
    description               NVARCHAR(255),
    endpoint                  NVARCHAR(255),
    inputs                    NVARCHAR(MAX), -- was jsonb
    last_update               DATETIME2,
    name                      NVARCHAR(255),
    outputs                   NVARCHAR(MAX), -- was jsonb
    priority                  NVARCHAR(255),
    process_id                NVARCHAR(255),
    process_instance_id       NVARCHAR(255),
    reference_name            NVARCHAR(255),
    root_process_id           NVARCHAR(255),
    root_process_instance_id  NVARCHAR(255),
    started                   DATETIME2,
    state                     NVARCHAR(255),
    PRIMARY KEY (id)
);

IF OBJECT_ID(N'tasks_admin_groups', N'U') IS NULL
CREATE TABLE tasks_admin_groups (
    task_id   NVARCHAR(255) NOT NULL,
    group_id  NVARCHAR(255) NOT NULL,
    PRIMARY KEY (task_id, group_id)
);

IF OBJECT_ID(N'tasks_admin_users', N'U') IS NULL
CREATE TABLE tasks_admin_users (
    task_id  NVARCHAR(255) NOT NULL,
    user_id  NVARCHAR(255) NOT NULL,
    PRIMARY KEY (task_id, user_id)
);

IF OBJECT_ID(N'tasks_excluded_users', N'U') IS NULL
CREATE TABLE tasks_excluded_users (
    task_id  NVARCHAR(255) NOT NULL,
    user_id  NVARCHAR(255) NOT NULL,
    PRIMARY KEY (task_id, user_id)
);

IF OBJECT_ID(N'tasks_potential_groups', N'U') IS NULL
CREATE TABLE tasks_potential_groups (
    task_id   NVARCHAR(255) NOT NULL,
    group_id  NVARCHAR(255) NOT NULL,
    PRIMARY KEY (task_id, group_id)
);

IF OBJECT_ID(N'tasks_potential_users', N'U') IS NULL
CREATE TABLE tasks_potential_users (
    task_id  NVARCHAR(255) NOT NULL,
    user_id  NVARCHAR(255) NOT NULL,
    PRIMARY KEY (task_id, user_id)
);

-- Foreign keys (drop-if-exists + add)
IF EXISTS (SELECT 1 FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'fk_attachments_tasks') AND parent_object_id = OBJECT_ID(N'attachments'))
    ALTER TABLE attachments DROP CONSTRAINT fk_attachments_tasks;

IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'fk_attachments_tasks') AND parent_object_id = OBJECT_ID(N'attachments'))
    ALTER TABLE attachments
        ADD CONSTRAINT fk_attachments_tasks
        FOREIGN KEY (task_id) REFERENCES tasks
        ON DELETE CASCADE;

IF EXISTS (SELECT 1 FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'fk_comments_tasks') AND parent_object_id = OBJECT_ID(N'comments'))
    ALTER TABLE comments DROP CONSTRAINT fk_comments_tasks;

IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'fk_comments_tasks') AND parent_object_id = OBJECT_ID(N'comments'))
    ALTER TABLE comments
        ADD CONSTRAINT fk_comments_tasks
        FOREIGN KEY (task_id) REFERENCES tasks
        ON DELETE CASCADE;

IF EXISTS (SELECT 1 FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'fk_milestones_process') AND parent_object_id = OBJECT_ID(N'milestones'))
    ALTER TABLE milestones DROP CONSTRAINT fk_milestones_process;

IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'fk_milestones_process') AND parent_object_id = OBJECT_ID(N'milestones'))
    ALTER TABLE milestones
        ADD CONSTRAINT fk_milestones_process
        FOREIGN KEY (process_instance_id) REFERENCES processes
        ON DELETE CASCADE;

IF EXISTS (SELECT 1 FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'fk_nodes_process') AND parent_object_id = OBJECT_ID(N'nodes'))
    ALTER TABLE nodes DROP CONSTRAINT fk_nodes_process;

IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'fk_nodes_process') AND parent_object_id = OBJECT_ID(N'nodes'))
    ALTER TABLE nodes
        ADD CONSTRAINT fk_nodes_process
        FOREIGN KEY (process_instance_id) REFERENCES processes
        ON DELETE CASCADE;

IF EXISTS (SELECT 1 FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'fk_processes_addons_processes') AND parent_object_id = OBJECT_ID(N'processes_addons'))
    ALTER TABLE processes_addons DROP CONSTRAINT fk_processes_addons_processes;

IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'fk_processes_addons_processes') AND parent_object_id = OBJECT_ID(N'processes_addons'))
    ALTER TABLE processes_addons
        ADD CONSTRAINT fk_processes_addons_processes
        FOREIGN KEY (process_id) REFERENCES processes
        ON DELETE CASCADE;

IF EXISTS (SELECT 1 FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'fk_processes_roles_processes') AND parent_object_id = OBJECT_ID(N'processes_roles'))
    ALTER TABLE processes_roles DROP CONSTRAINT fk_processes_roles_processes;

IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'fk_processes_roles_processes') AND parent_object_id = OBJECT_ID(N'processes_roles'))
    ALTER TABLE processes_roles
        ADD CONSTRAINT fk_processes_roles_processes
        FOREIGN KEY (process_id) REFERENCES processes
        ON DELETE CASCADE;

IF EXISTS (SELECT 1 FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'fk_tasks_admin_groups_tasks') AND parent_object_id = OBJECT_ID(N'tasks_admin_groups'))
    ALTER TABLE tasks_admin_groups DROP CONSTRAINT fk_tasks_admin_groups_tasks;

IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'fk_tasks_admin_groups_tasks') AND parent_object_id = OBJECT_ID(N'tasks_admin_groups'))
    ALTER TABLE tasks_admin_groups
        ADD CONSTRAINT fk_tasks_admin_groups_tasks
        FOREIGN KEY (task_id) REFERENCES tasks
        ON DELETE CASCADE;

IF EXISTS (SELECT 1 FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'fk_tasks_admin_users_tasks') AND parent_object_id = OBJECT_ID(N'tasks_admin_users'))
    ALTER TABLE tasks_admin_users DROP CONSTRAINT fk_tasks_admin_users_tasks;

IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'fk_tasks_admin_users_tasks') AND parent_object_id = OBJECT_ID(N'tasks_admin_users'))
    ALTER TABLE tasks_admin_users
        ADD CONSTRAINT fk_tasks_admin_users_tasks
        FOREIGN KEY (task_id) REFERENCES tasks
        ON DELETE CASCADE;

IF EXISTS (SELECT 1 FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'fk_tasks_excluded_users_tasks') AND parent_object_id = OBJECT_ID(N'tasks_excluded_users'))
    ALTER TABLE tasks_excluded_users DROP CONSTRAINT fk_tasks_excluded_users_tasks;

IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'fk_tasks_excluded_users_tasks') AND parent_object_id = OBJECT_ID(N'tasks_excluded_users'))
    ALTER TABLE tasks_excluded_users
        ADD CONSTRAINT fk_tasks_excluded_users_tasks
        FOREIGN KEY (task_id) REFERENCES tasks
        ON DELETE CASCADE;

IF EXISTS (SELECT 1 FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'fk_tasks_potential_groups_tasks') AND parent_object_id = OBJECT_ID(N'tasks_potential_groups'))
    ALTER TABLE tasks_potential_groups DROP CONSTRAINT fk_tasks_potential_groups_tasks;

IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'fk_tasks_potential_groups_tasks') AND parent_object_id = OBJECT_ID(N'tasks_potential_groups'))
    ALTER TABLE tasks_potential_groups
        ADD CONSTRAINT fk_tasks_potential_groups_tasks
        FOREIGN KEY (task_id) REFERENCES tasks
        ON DELETE CASCADE;

IF EXISTS (SELECT 1 FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'fk_tasks_potential_users_tasks') AND parent_object_id = OBJECT_ID(N'tasks_potential_users'))
    ALTER TABLE tasks_potential_users DROP CONSTRAINT fk_tasks_potential_users_tasks;

IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'fk_tasks_potential_users_tasks') AND parent_object_id = OBJECT_ID(N'tasks_potential_users'))
    ALTER TABLE tasks_potential_users
        ADD CONSTRAINT fk_tasks_potential_users_tasks
        FOREIGN KEY (task_id) REFERENCES tasks
        ON DELETE CASCADE;
