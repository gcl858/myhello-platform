package io.restassured.internal.csrf;

import java.lang.*;
import java.io.*;
import java.net.*;
import java.util.*;
import groovy.lang.*;
import groovy.util.*;

public class CsrfTokenFinder
  extends java.lang.Object  implements
    groovy.lang.GroovyObject {
public  groovy.lang.MetaClass getMetaClass() { return (groovy.lang.MetaClass)null;}
public  void setMetaClass(groovy.lang.MetaClass mc) { }
public  java.lang.Object invokeMethod(java.lang.String method, java.lang.Object arguments) { return null;}
public  java.lang.Object getProperty(java.lang.String property) { return null;}
public  void setProperty(java.lang.String property, java.lang.Object value) { }
public static  io.restassured.internal.csrf.CsrfData findInHtml(io.restassured.config.CsrfConfig csrfConfig, io.restassured.response.Response pageThatContainsCsrfToken) { return (io.restassured.internal.csrf.CsrfData)null;}
}
