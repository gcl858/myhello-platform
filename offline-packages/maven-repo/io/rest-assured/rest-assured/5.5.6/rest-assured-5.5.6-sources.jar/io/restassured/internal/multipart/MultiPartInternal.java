package io.restassured.internal.multipart;

import java.lang.*;
import java.io.*;
import java.net.*;
import java.util.*;
import groovy.lang.*;
import groovy.util.*;

@groovy.transform.Canonical() public class MultiPartInternal
  extends java.lang.Object  implements
    groovy.lang.GroovyObject {
public static final java.lang.String OCTET_STREAM = "application/octet-stream";
public  groovy.lang.MetaClass getMetaClass() { return (groovy.lang.MetaClass)null;}
public  void setMetaClass(groovy.lang.MetaClass mc) { }
public  java.lang.Object invokeMethod(java.lang.String method, java.lang.Object arguments) { return null;}
public  java.lang.Object getProperty(java.lang.String property) { return null;}
public  void setProperty(java.lang.String property, java.lang.Object value) { }
public  java.lang.Object getContent() { return null;}
public  void setContent(java.lang.Object value) { }
public  java.lang.String getControlName() { return (java.lang.String)null;}
public  void setControlName(java.lang.String value) { }
public  java.lang.String getFileName() { return (java.lang.String)null;}
public  void setFileName(java.lang.String value) { }
public  void setMimeType(java.lang.String value) { }
public  java.lang.String getCharset() { return (java.lang.String)null;}
public  void setCharset(java.lang.String value) { }
public  java.util.Map<java.lang.String, java.lang.String> getHeaders() { return (java.util.Map)null;}
public  void setHeaders(java.util.Map<java.lang.String, java.lang.String> value) { }
public  java.lang.Object getContentBody() { return null;}
public  java.lang.String getMimeType() { return (java.lang.String)null;}
}
