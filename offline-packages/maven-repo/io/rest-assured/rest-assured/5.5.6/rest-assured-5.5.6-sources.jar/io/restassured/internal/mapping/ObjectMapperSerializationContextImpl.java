package io.restassured.internal.mapping;

import java.lang.*;
import java.io.*;
import java.net.*;
import java.util.*;
import groovy.lang.*;
import groovy.util.*;

public class ObjectMapperSerializationContextImpl
  extends java.lang.Object  implements
    io.restassured.mapper.ObjectMapperSerializationContext,    groovy.lang.GroovyObject {
public  groovy.lang.MetaClass getMetaClass() { return (groovy.lang.MetaClass)null;}
public  void setMetaClass(groovy.lang.MetaClass mc) { }
public  java.lang.Object invokeMethod(java.lang.String method, java.lang.Object arguments) { return null;}
public  java.lang.Object getProperty(java.lang.String property) { return null;}
public  void setProperty(java.lang.String property, java.lang.Object value) { }
public  java.lang.Object getObject() { return null;}
public  void setObject(java.lang.Object value) { }
public  void setContentType(java.lang.Object value) { }
public  void setCharset(java.lang.Object value) { }
@java.lang.Override() public  java.lang.Object getObjectToSerialize() { return null;}
@java.lang.Override() public  java.lang.Object getObjectToSerializeAs(java.lang.Class expectedType) { return null;}
@java.lang.Override() public  java.lang.String getContentType() { return (java.lang.String)null;}
@java.lang.Override() public  java.lang.String getCharset() { return (java.lang.String)null;}
}
