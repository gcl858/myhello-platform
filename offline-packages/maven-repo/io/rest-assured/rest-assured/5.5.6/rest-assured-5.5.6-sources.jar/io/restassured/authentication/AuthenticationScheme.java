package io.restassured.authentication;

import java.lang.*;
import java.io.*;
import java.net.*;
import java.util.*;
import groovy.lang.*;
import groovy.util.*;

public interface AuthenticationScheme
 {
 void authenticate(io.restassured.internal.http.HTTPBuilder httpBuilder);
}
