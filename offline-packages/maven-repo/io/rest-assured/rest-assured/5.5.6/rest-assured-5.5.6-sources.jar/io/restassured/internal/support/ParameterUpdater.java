package io.restassured.internal.support;

import java.lang.*;
import java.io.*;
import java.net.*;
import java.util.*;
import groovy.lang.*;
import groovy.util.*;

public class ParameterUpdater
  extends java.lang.Object  implements
    groovy.lang.GroovyObject {
public ParameterUpdater
(io.restassured.internal.support.ParameterUpdater.Serializer serializer) {}
public  groovy.lang.MetaClass getMetaClass() { return (groovy.lang.MetaClass)null;}
public  void setMetaClass(groovy.lang.MetaClass mc) { }
public  java.lang.Object invokeMethod(java.lang.String method, java.lang.Object arguments) { return null;}
public  java.lang.Object getProperty(java.lang.String property) { return null;}
public  void setProperty(java.lang.String property, java.lang.Object value) { }
public  void updateParameters(io.restassured.config.ParamConfig.UpdateStrategy strategy, java.util.Map<java.lang.String, java.lang.Object> from, java.util.Map<java.lang.String, java.lang.Object> to) { }
public  void updateCollectionParameter(io.restassured.config.ParamConfig.UpdateStrategy strategy, java.util.Map<java.lang.String, java.lang.Object> to, java.lang.String key, java.util.Collection<java.lang.Object> values) { }
public  void updateZeroToManyParameters(io.restassured.config.ParamConfig.UpdateStrategy strategy, java.util.Map<java.lang.String, java.lang.Object> to, java.lang.String parameterName, java.lang.Object... parameterValues) { }
public  void updateStandardParameter(io.restassured.config.ParamConfig.UpdateStrategy strategy, java.util.Map<java.lang.String, java.lang.Object> to, java.lang.String key) { }
public  void updateStandardParameter(io.restassured.config.ParamConfig.UpdateStrategy strategy, java.util.Map<java.lang.String, java.lang.Object> to, java.lang.String key, java.lang.Object value) { }
public static interface Serializer
 {
 java.lang.String serializeIfNeeded(java.lang.Object value);
}
}
