package io.restassured.internal.mapping;

import java.lang.*;
import java.io.*;
import java.net.*;
import java.util.*;
import groovy.lang.*;
import groovy.util.*;

public class JaxbMapper
  extends java.lang.Object  implements
    io.restassured.mapper.ObjectMapper,    groovy.lang.GroovyObject {
public JaxbMapper
(io.restassured.path.xml.mapper.factory.JAXBObjectMapperFactory factory) {}
public  groovy.lang.MetaClass getMetaClass() { return (groovy.lang.MetaClass)null;}
public  void setMetaClass(groovy.lang.MetaClass mc) { }
public  java.lang.Object invokeMethod(java.lang.String method, java.lang.Object arguments) { return null;}
public  java.lang.Object getProperty(java.lang.String property) { return null;}
public  void setProperty(java.lang.String property, java.lang.Object value) { }
public  java.lang.Object deserialize(io.restassured.mapper.ObjectMapperDeserializationContext context) { return null;}
@java.lang.SuppressWarnings(value="UnnecessaryQualifiedReference") public  java.lang.Object serialize(io.restassured.mapper.ObjectMapperSerializationContext context) { return null;}
}
