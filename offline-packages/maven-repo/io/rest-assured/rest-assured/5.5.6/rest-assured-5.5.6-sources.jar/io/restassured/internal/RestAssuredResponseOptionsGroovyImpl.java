package io.restassured.internal;

import java.lang.*;
import java.io.*;
import java.net.*;
import java.util.*;
import groovy.lang.*;
import groovy.util.*;

public class RestAssuredResponseOptionsGroovyImpl
  extends java.lang.Object  implements
    groovy.lang.GroovyObject {
public static final java.lang.String BINARY = "binary";
public  groovy.lang.MetaClass getMetaClass() { return (groovy.lang.MetaClass)null;}
public  void setMetaClass(groovy.lang.MetaClass mc) { }
public  java.lang.Object invokeMethod(java.lang.String method, java.lang.Object arguments) { return null;}
public  java.lang.Object getProperty(java.lang.String property) { return null;}
public  void setProperty(java.lang.String property, java.lang.Object value) { }
public  java.lang.Object getResponseHeaders() { return null;}
public  void setResponseHeaders(java.lang.Object value) { }
public  void setCookies(io.restassured.http.Cookies value) { }
public  java.lang.Object getContent() { return null;}
public  void setContent(java.lang.Object value) { }
public  void setContentType(java.lang.Object value) { }
public  void setStatusLine(java.lang.Object value) { }
public  void setStatusCode(java.lang.Object value) { }
public  java.lang.Object getSessionIdName() { return null;}
public  void setSessionIdName(java.lang.Object value) { }
public  java.util.Map getFilterContextProperties() { return (java.util.Map)null;}
public  void setFilterContextProperties(java.util.Map value) { }
public  java.lang.Object getConnectionManager() { return null;}
public  void setConnectionManager(java.lang.Object value) { }
public  org.apache.http.protocol.HttpContext getApacheHttpContext() { return (org.apache.http.protocol.HttpContext)null;}
public  void setApacheHttpContext(org.apache.http.protocol.HttpContext value) { }
public  java.lang.String getDefaultContentType() { return (java.lang.String)null;}
public  void setDefaultContentType(java.lang.String value) { }
public  void setRpr(io.restassured.internal.ResponseParserRegistrar value) { }
public  io.restassured.config.DecoderConfig getDecoderConfig() { return (io.restassured.config.DecoderConfig)null;}
public  void setDecoderConfig(io.restassured.config.DecoderConfig value) { }
public  boolean getHasExpectations() { return false;}
public  boolean isHasExpectations() { return false;}
public  void setHasExpectations(boolean value) { }
public  void setConfig(io.restassured.config.RestAssuredConfig value) { }
public  void parseResponse(io.restassured.internal.http.HttpResponseDecorator httpResponse, java.lang.Object content, java.lang.Object hasBodyAssertions, io.restassured.internal.ResponseParserRegistrar responseParserRegistrar) { }
public  java.lang.Object parseStatus(java.lang.Object httpResponse) { return null;}
public  java.lang.Object parseContentType(java.lang.Object httpResponse) { return null;}
public  java.lang.Object parseCookies() { return null;}
public  java.lang.Object parseHeaders(io.restassured.internal.http.HttpResponseDecorator httpResponse) { return null;}
public  java.lang.Object toString(groovy.lang.Writable node) { return null;}
public  java.lang.String print() { return (java.lang.String)null;}
public  java.lang.String prettyPrint(io.restassured.response.ResponseOptions responseOptions, io.restassured.response.ResponseBody responseBody) { return (java.lang.String)null;}
public  java.lang.Object peek(io.restassured.response.ResponseOptions responseOptions, io.restassured.response.ResponseBody responseBody) { return null;}
public  java.lang.Object prettyPeek(io.restassured.response.ResponseOptions responseOptions, io.restassured.response.ResponseBody responseBody) { return null;}
public  java.lang.String asString() { return (java.lang.String)null;}
public  java.lang.String asPrettyString(io.restassured.response.ResponseOptions responseOptions, io.restassured.response.ResponseBody responseBody) { return (java.lang.String)null;}
public  java.lang.String asString(boolean forcePlatformDefaultCharsetIfNoCharsetIsSpecifiedInResponse) { return (java.lang.String)null;}
public  boolean isInputStream() { return false;}
public  java.io.InputStream asInputStream() { return (java.io.InputStream)null;}
public  byte[] convertStringToByteArray(java.lang.Object string) { return (byte[])null;}
public  byte[] asByteArray() { return (byte[])null;}
public <T> T as(java.lang.reflect.Type cls, io.restassured.response.ResponseBodyData responseBodyData) { return null;}
public <T> T as(java.lang.reflect.Type cls, io.restassured.mapper.ObjectMapperType mapperType, io.restassured.response.ResponseBodyData responseBodyData) { return null;}
public <T> T as(java.lang.reflect.Type cls, io.restassured.mapper.ObjectMapper mapper) { return null;}
public <T> T as(io.restassured.common.mapper.TypeRef<T> typeRef, io.restassured.response.ResponseBodyData responseBodyData) { return null;}
public  java.lang.String findCharset() { return (java.lang.String)null;}
public  java.lang.String findCharset(boolean forcePlatformDefaultCharsetIfNoCharsetIsSpecifiedInResponse) { return (java.lang.String)null;}
public  io.restassured.http.Cookies detailedCookies() { return (io.restassured.http.Cookies)null;}
public  io.restassured.http.Cookies getDetailedCookies() { return (io.restassured.http.Cookies)null;}
public  io.restassured.http.Cookie detailedCookie(java.lang.String name) { return (io.restassured.http.Cookie)null;}
public  io.restassured.http.Cookie getDetailedCookie(java.lang.String name) { return (io.restassured.http.Cookie)null;}
public  io.restassured.http.Headers headers() { return (io.restassured.http.Headers)null;}
public  io.restassured.http.Headers getHeaders() { return (io.restassured.http.Headers)null;}
public  java.lang.String header(java.lang.String name) { return (java.lang.String)null;}
public  java.lang.String getHeader(java.lang.String name) { return (java.lang.String)null;}
public  java.util.Map<java.lang.String, java.lang.String> cookies() { return (java.util.Map)null;}
public  java.util.Map<java.lang.String, java.lang.String> getCookies() { return (java.util.Map)null;}
public  java.lang.String cookie(java.lang.String name) { return (java.lang.String)null;}
public  java.lang.String getCookie(java.lang.String name) { return (java.lang.String)null;}
public  java.lang.String contentType() { return (java.lang.String)null;}
public  io.restassured.internal.ResponseParserRegistrar getRpr() { return (io.restassured.internal.ResponseParserRegistrar)null;}
public  io.restassured.config.RestAssuredConfig getConfig() { return (io.restassured.config.RestAssuredConfig)null;}
public  java.lang.String getContentType() { return (java.lang.String)null;}
public  java.lang.String statusLine() { return (java.lang.String)null;}
public  int statusCode() { return (int)0;}
public  java.lang.String getStatusLine() { return (java.lang.String)null;}
public  java.lang.String sessionId() { return (java.lang.String)null;}
public  java.lang.String getSessionId() { return (java.lang.String)null;}
public  int getStatusCode() { return (int)0;}
public  io.restassured.path.json.JsonPath jsonPath() { return (io.restassured.path.json.JsonPath)null;}
public  io.restassured.path.json.JsonPath jsonPath(io.restassured.path.json.config.JsonPathConfig config) { return (io.restassured.path.json.JsonPath)null;}
public  io.restassured.path.xml.XmlPath xmlPath() { return (io.restassured.path.xml.XmlPath)null;}
public  io.restassured.path.xml.XmlPath xmlPath(io.restassured.path.xml.config.XmlPathConfig config) { return (io.restassured.path.xml.XmlPath)null;}
public  io.restassured.path.xml.XmlPath xmlPath(io.restassured.path.xml.XmlPath.CompatibilityMode compatibilityMode) { return (io.restassured.path.xml.XmlPath)null;}
public  io.restassured.path.xml.XmlPath htmlPath() { return (io.restassured.path.xml.XmlPath)null;}
public <T> T path(java.lang.String path, java.lang.String... arguments) { return null;}
public  long time() { return (long)0;}
public  long timeIn(java.util.concurrent.TimeUnit timeUnit) { return (long)0;}
public  java.lang.Object charsetToString(java.lang.Object charset) { return null;}
}
