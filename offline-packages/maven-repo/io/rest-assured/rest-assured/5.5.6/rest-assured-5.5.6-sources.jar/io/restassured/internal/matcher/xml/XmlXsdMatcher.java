package io.restassured.internal.matcher.xml;

import java.lang.*;
import java.io.*;
import java.net.*;
import java.util.*;
import groovy.lang.*;
import groovy.util.*;

public class XmlXsdMatcher
  extends org.hamcrest.BaseMatcher<java.lang.String>  implements
    groovy.lang.GroovyObject {
public XmlXsdMatcher
(java.lang.Object xsd) {}
public  groovy.lang.MetaClass getMetaClass() { return (groovy.lang.MetaClass)null;}
public  void setMetaClass(groovy.lang.MetaClass mc) { }
public  java.lang.Object invokeMethod(java.lang.String method, java.lang.Object arguments) { return null;}
public  java.lang.Object getProperty(java.lang.String property) { return null;}
public  void setProperty(java.lang.String property, java.lang.Object value) { }
public  java.lang.Object getXsd() { return null;}
public  void setXsd(java.lang.Object value) { }
public  java.lang.Object getResourceResolver() { return null;}
public  void setResourceResolver(java.lang.Object value) { }
public  io.restassured.internal.matcher.xml.XmlXsdMatcher using(org.w3c.dom.ls.LSResourceResolver resourceResolver) { return (io.restassured.internal.matcher.xml.XmlXsdMatcher)null;}
public  io.restassured.internal.matcher.xml.XmlXsdMatcher with(org.w3c.dom.ls.LSResourceResolver resourceResolver) { return (io.restassured.internal.matcher.xml.XmlXsdMatcher)null;}
public static  io.restassured.internal.matcher.xml.XmlXsdMatcher matchesXsd(java.lang.String xsd) { return (io.restassured.internal.matcher.xml.XmlXsdMatcher)null;}
public static  io.restassured.internal.matcher.xml.XmlXsdMatcher matchesXsd(java.io.InputStream xsd) { return (io.restassured.internal.matcher.xml.XmlXsdMatcher)null;}
public static  io.restassured.internal.matcher.xml.XmlXsdMatcher matchesXsd(java.io.Reader xsd) { return (io.restassured.internal.matcher.xml.XmlXsdMatcher)null;}
public static  io.restassured.internal.matcher.xml.XmlXsdMatcher matchesXsd(java.io.File xsd) { return (io.restassured.internal.matcher.xml.XmlXsdMatcher)null;}
public static  io.restassured.internal.matcher.xml.XmlXsdMatcher matchesXsd(java.net.URL url) { return (io.restassured.internal.matcher.xml.XmlXsdMatcher)null;}
@java.lang.Override() public  boolean matches(java.lang.Object item) { return false;}
@java.lang.Override() public  void describeTo(org.hamcrest.Description description) { }
public static  io.restassured.internal.matcher.xml.XmlXsdMatcher matchesXsdInClasspath(java.lang.String path) { return (io.restassured.internal.matcher.xml.XmlXsdMatcher)null;}
}
