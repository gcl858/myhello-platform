package io.restassured.internal.matcher.xml;

import java.lang.*;
import java.io.*;
import java.net.*;
import java.util.*;
import groovy.lang.*;
import groovy.util.*;

public class XmlDtdMatcher
  extends org.hamcrest.BaseMatcher<java.lang.String>  implements
    groovy.lang.GroovyObject {
public XmlDtdMatcher
(java.lang.Object dtd) {}
public  groovy.lang.MetaClass getMetaClass() { return (groovy.lang.MetaClass)null;}
public  void setMetaClass(groovy.lang.MetaClass mc) { }
public  java.lang.Object invokeMethod(java.lang.String method, java.lang.Object arguments) { return null;}
public  java.lang.Object getProperty(java.lang.String property) { return null;}
public  void setProperty(java.lang.String property, java.lang.Object value) { }
public  java.lang.Object getDtd() { return null;}
public  void setDtd(java.lang.Object value) { }
public static  org.hamcrest.Matcher<java.lang.String> matchesDtd(java.lang.String dtd) { return (org.hamcrest.Matcher)null;}
public static  org.hamcrest.Matcher<java.lang.String> matchesDtd(java.io.InputStream dtd) { return (org.hamcrest.Matcher)null;}
public static  org.hamcrest.Matcher<java.lang.String> matchesDtd(java.io.File dtd) { return (org.hamcrest.Matcher)null;}
public static  org.hamcrest.Matcher<java.lang.String> matchesDtd(java.net.URL url) { return (org.hamcrest.Matcher)null;}
@java.lang.Override() public  boolean matches(java.lang.Object item) { return false;}
@java.lang.Override() public  void describeTo(org.hamcrest.Description description) { }
public static  org.hamcrest.Matcher<java.lang.String> matchesDtdInClasspath(java.lang.String path) { return (org.hamcrest.Matcher)null;}
private static class ExceptionThrowingErrorHandler
  extends java.lang.Object  implements
    org.xml.sax.ErrorHandler,    groovy.lang.GroovyObject {
public  groovy.lang.MetaClass getMetaClass() { return (groovy.lang.MetaClass)null;}
public  void setMetaClass(groovy.lang.MetaClass mc) { }
public  java.lang.Object invokeMethod(java.lang.String method, java.lang.Object arguments) { return null;}
public  java.lang.Object getProperty(java.lang.String property) { return null;}
public  void setProperty(java.lang.String property, java.lang.Object value) { }
@java.lang.Override() public  void warning(org.xml.sax.SAXParseException exception) { }
@java.lang.Override() public  void error(org.xml.sax.SAXParseException exception) { }
@java.lang.Override() public  void fatalError(org.xml.sax.SAXParseException exception) { }
}
}
