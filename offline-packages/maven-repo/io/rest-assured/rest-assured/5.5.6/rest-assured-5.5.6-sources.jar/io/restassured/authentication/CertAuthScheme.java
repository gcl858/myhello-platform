package io.restassured.authentication;

import java.lang.*;
import java.io.*;
import java.net.*;
import java.util.*;
import groovy.lang.*;
import groovy.util.*;

public class CertAuthScheme
  extends java.lang.Object  implements
    io.restassured.authentication.AuthenticationScheme,    groovy.lang.GroovyObject {
public  groovy.lang.MetaClass getMetaClass() { return (groovy.lang.MetaClass)null;}
public  void setMetaClass(groovy.lang.MetaClass mc) { }
public  java.lang.Object invokeMethod(java.lang.String method, java.lang.Object arguments) { return null;}
public  java.lang.Object getProperty(java.lang.String property) { return null;}
public  void setProperty(java.lang.String property, java.lang.Object value) { }
public  java.lang.Object getPathToKeyStore() { return null;}
public  void setPathToKeyStore(java.lang.Object value) { }
public  java.lang.String getKeyStorePassword() { return (java.lang.String)null;}
public  void setKeyStorePassword(java.lang.String value) { }
public  java.lang.String getKeystoreType() { return (java.lang.String)null;}
public  void setKeystoreType(java.lang.String value) { }
public  java.lang.Object getPathToTrustStore() { return null;}
public  void setPathToTrustStore(java.lang.Object value) { }
public  java.lang.String getTrustStorePassword() { return (java.lang.String)null;}
public  void setTrustStorePassword(java.lang.String value) { }
public  java.lang.String getTrustStoreType() { return (java.lang.String)null;}
public  void setTrustStoreType(java.lang.String value) { }
public  int getPort() { return (int)0;}
public  void setPort(int value) { }
public  java.security.KeyStore getTrustStore() { return (java.security.KeyStore)null;}
public  void setTrustStore(java.security.KeyStore value) { }
public  java.security.KeyStore getKeyStore() { return (java.security.KeyStore)null;}
public  void setKeyStore(java.security.KeyStore value) { }
public  org.apache.http.conn.ssl.X509HostnameVerifier getX509HostnameVerifier() { return (org.apache.http.conn.ssl.X509HostnameVerifier)null;}
public  void setX509HostnameVerifier(org.apache.http.conn.ssl.X509HostnameVerifier value) { }
public  org.apache.http.conn.ssl.SSLSocketFactory getSslSocketFactory() { return (org.apache.http.conn.ssl.SSLSocketFactory)null;}
public  void setSslSocketFactory(org.apache.http.conn.ssl.SSLSocketFactory value) { }
@java.lang.Override() public  void authenticate(io.restassured.internal.http.HTTPBuilder httpBuilder) { }
}
