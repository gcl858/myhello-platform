package io.restassured.assertion;

import java.lang.*;
import java.io.*;
import java.net.*;
import java.util.*;
import groovy.lang.*;
import groovy.util.*;

public class StreamVerifier
  extends java.lang.Object  implements
    groovy.lang.GroovyObject {
public  groovy.lang.MetaClass getMetaClass() { return (groovy.lang.MetaClass)null;}
public  void setMetaClass(groovy.lang.MetaClass mc) { }
public  java.lang.Object invokeMethod(java.lang.String method, java.lang.Object arguments) { return null;}
public  java.lang.Object getProperty(java.lang.String property) { return null;}
public  void setProperty(java.lang.String property, java.lang.Object value) { }
public static  java.lang.Object newAssertion(io.restassured.response.Response response, java.lang.Object key, io.restassured.internal.ResponseParserRegistrar rpr) { return null;}
public static  java.lang.Object createAssertionForCustomParser(io.restassured.internal.ResponseParserRegistrar rpr, java.lang.String contentType, java.lang.Object key) { return null;}
}
