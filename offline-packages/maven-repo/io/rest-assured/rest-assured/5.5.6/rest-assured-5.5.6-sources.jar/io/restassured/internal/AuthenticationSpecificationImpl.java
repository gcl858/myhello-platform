package io.restassured.internal;

import io.restassured.authentication.*;
import java.lang.*;
import java.io.*;
import java.net.*;
import java.util.*;
import groovy.lang.*;
import groovy.util.*;

public class AuthenticationSpecificationImpl
  extends java.lang.Object  implements
    io.restassured.specification.AuthenticationSpecification,    groovy.lang.GroovyObject {
public AuthenticationSpecificationImpl
(io.restassured.specification.RequestSpecification requestSpecification) {}
public  groovy.lang.MetaClass getMetaClass() { return (groovy.lang.MetaClass)null;}
public  void setMetaClass(groovy.lang.MetaClass mc) { }
public  java.lang.Object invokeMethod(java.lang.String method, java.lang.Object arguments) { return null;}
public  java.lang.Object getProperty(java.lang.String property) { return null;}
public  void setProperty(java.lang.String property, java.lang.Object value) { }
public  io.restassured.specification.RequestSpecification basic(java.lang.String userName, java.lang.String password) { return (io.restassured.specification.RequestSpecification)null;}
public  io.restassured.specification.RequestSpecification ntlm(java.lang.String userName, java.lang.String password, java.lang.String workstation, java.lang.String domain) { return (io.restassured.specification.RequestSpecification)null;}
public  io.restassured.specification.RequestSpecification digest(java.lang.String userName, java.lang.String password) { return (io.restassured.specification.RequestSpecification)null;}
public  io.restassured.specification.RequestSpecification certificate(java.lang.String certURL, java.lang.String password) { return (io.restassured.specification.RequestSpecification)null;}
public  io.restassured.specification.RequestSpecification certificate(java.lang.String certURL, java.lang.String password, io.restassured.authentication.CertificateAuthSettings settings) { return (io.restassured.specification.RequestSpecification)null;}
public  io.restassured.specification.RequestSpecification oauth(java.lang.String consumerKey, java.lang.String consumerSecret, java.lang.String accessToken, java.lang.String secretToken) { return (io.restassured.specification.RequestSpecification)null;}
public  io.restassured.specification.RequestSpecification oauth(java.lang.String consumerKey, java.lang.String consumerSecret, java.lang.String accessToken, java.lang.String secretToken, io.restassured.authentication.OAuthSignature signature) { return (io.restassured.specification.RequestSpecification)null;}
public  io.restassured.specification.RequestSpecification oauth2(java.lang.String accessToken) { return (io.restassured.specification.RequestSpecification)null;}
public  io.restassured.specification.RequestSpecification oauth2(java.lang.String accessToken, io.restassured.authentication.OAuthSignature signature) { return (io.restassured.specification.RequestSpecification)null;}
public  io.restassured.specification.RequestSpecification none() { return (io.restassured.specification.RequestSpecification)null;}
public  io.restassured.specification.PreemptiveAuthSpec preemptive() { return (io.restassured.specification.PreemptiveAuthSpec)null;}
public  io.restassured.specification.RequestSpecification form(java.lang.String userName, java.lang.String password) { return (io.restassured.specification.RequestSpecification)null;}
public  io.restassured.specification.RequestSpecification form(java.lang.String userName, java.lang.String password, io.restassured.authentication.FormAuthConfig config) { return (io.restassured.specification.RequestSpecification)null;}
}
