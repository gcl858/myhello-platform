package io.restassured.internal.mapping;

import io.restassured.path.json.mapper.factory.*;
import java.lang.*;
import java.io.*;
import java.net.*;
import java.util.*;
import groovy.lang.*;
import groovy.util.*;

public class ObjectMapping
  extends java.lang.Object  implements
    groovy.lang.GroovyObject {
public  groovy.lang.MetaClass getMetaClass() { return (groovy.lang.MetaClass)null;}
public  void setMetaClass(groovy.lang.MetaClass mc) { }
public  java.lang.Object invokeMethod(java.lang.String method, java.lang.Object arguments) { return null;}
public  java.lang.Object getProperty(java.lang.String property) { return null;}
public  void setProperty(java.lang.String property, java.lang.Object value) { }
public static <T> T deserialize(io.restassured.response.ResponseBodyData response, java.lang.reflect.Type cls, java.lang.String contentType, java.lang.String defaultContentType, java.lang.String charset, io.restassured.mapper.ObjectMapperType mapperType, io.restassured.config.ObjectMapperConfig objectMapperConfig) { return null;}
public static  java.lang.String serialize(java.lang.Object object, java.lang.String contentType, java.lang.String charset, io.restassured.mapper.ObjectMapperType mapperType, io.restassured.config.ObjectMapperConfig config, io.restassured.config.EncoderConfig encoderConfig) { return (java.lang.String)null;}
public static  java.lang.Object parseWithJackson1(io.restassured.mapper.ObjectMapperDeserializationContext ctx, io.restassured.path.json.mapper.factory.Jackson1ObjectMapperFactory factory) { return null;}
public static  java.lang.Object parseWithJackson2(io.restassured.mapper.ObjectMapperDeserializationContext ctx, io.restassured.path.json.mapper.factory.Jackson2ObjectMapperFactory factory) { return null;}
public static  java.lang.Object parseWithJohnzon(io.restassured.mapper.ObjectMapperDeserializationContext ctx, io.restassured.path.json.mapper.factory.JohnzonObjectMapperFactory factory) { return null;}
public static  java.lang.Object parseWithJsonb(io.restassured.mapper.ObjectMapperDeserializationContext ctx, io.restassured.path.json.mapper.factory.JsonbObjectMapperFactory factory) { return null;}
}
