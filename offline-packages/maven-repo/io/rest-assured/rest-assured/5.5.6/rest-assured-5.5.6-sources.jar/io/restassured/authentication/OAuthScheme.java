package io.restassured.authentication;

import java.lang.*;
import java.io.*;
import java.net.*;
import java.util.*;
import groovy.lang.*;
import groovy.util.*;

public class OAuthScheme
  extends java.lang.Object  implements
    io.restassured.authentication.AuthenticationScheme,    groovy.lang.GroovyObject {
public  groovy.lang.MetaClass getMetaClass() { return (groovy.lang.MetaClass)null;}
public  void setMetaClass(groovy.lang.MetaClass mc) { }
public  java.lang.Object invokeMethod(java.lang.String method, java.lang.Object arguments) { return null;}
public  java.lang.Object getProperty(java.lang.String property) { return null;}
public  void setProperty(java.lang.String property, java.lang.Object value) { }
public  java.lang.String getConsumerKey() { return (java.lang.String)null;}
public  void setConsumerKey(java.lang.String value) { }
public  java.lang.String getConsumerSecret() { return (java.lang.String)null;}
public  void setConsumerSecret(java.lang.String value) { }
public  java.lang.String getAccessToken() { return (java.lang.String)null;}
public  void setAccessToken(java.lang.String value) { }
public  java.lang.String getSecretToken() { return (java.lang.String)null;}
public  void setSecretToken(java.lang.String value) { }
public  io.restassured.authentication.OAuthSignature getSignature() { return (io.restassured.authentication.OAuthSignature)null;}
public  void setSignature(io.restassured.authentication.OAuthSignature value) { }
@java.lang.Override() public  void authenticate(io.restassured.internal.http.HTTPBuilder httpBuilder) { }
}
