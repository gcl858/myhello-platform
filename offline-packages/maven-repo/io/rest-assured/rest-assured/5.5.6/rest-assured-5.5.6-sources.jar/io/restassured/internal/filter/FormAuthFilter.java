package io.restassured.internal.filter;

import java.lang.*;
import java.io.*;
import java.net.*;
import java.util.*;
import groovy.lang.*;
import groovy.util.*;

public class FormAuthFilter
  extends java.lang.Object  implements
    io.restassured.spi.AuthFilter,    groovy.lang.GroovyObject {
public  groovy.lang.MetaClass getMetaClass() { return (groovy.lang.MetaClass)null;}
public  void setMetaClass(groovy.lang.MetaClass mc) { }
public  java.lang.Object invokeMethod(java.lang.String method, java.lang.Object arguments) { return null;}
public  java.lang.Object getProperty(java.lang.String property) { return null;}
public  void setProperty(java.lang.String property, java.lang.Object value) { }
public  java.lang.Object getUserName() { return null;}
public  void setUserName(java.lang.Object value) { }
public  java.lang.Object getPassword() { return null;}
public  void setPassword(java.lang.Object value) { }
public  io.restassured.authentication.FormAuthConfig getFormAuthConfig() { return (io.restassured.authentication.FormAuthConfig)null;}
public  void setFormAuthConfig(io.restassured.authentication.FormAuthConfig value) { }
public  io.restassured.config.SessionConfig getSessionConfig() { return (io.restassured.config.SessionConfig)null;}
public  void setSessionConfig(io.restassured.config.SessionConfig value) { }
public  io.restassured.config.CsrfConfig getCsrfConfig() { return (io.restassured.config.CsrfConfig)null;}
public  void setCsrfConfig(io.restassured.config.CsrfConfig value) { }
@java.lang.Override() public  io.restassured.response.Response filter(io.restassured.specification.FilterableRequestSpecification requestSpec, io.restassured.specification.FilterableResponseSpecification responseSpec, io.restassured.filter.FilterContext ctx) { return (io.restassured.response.Response)null;}
public static  void applySessionFilterFromOriginalRequestIfDefined(io.restassured.specification.FilterableRequestSpecification requestSpec, io.restassured.specification.RequestSpecification loginRequestSpec) { }
public static  java.lang.Object throwIfException(groovy.lang.Closure closure) { return null;}
}
