package io.restassured.internal.multipart;

import java.lang.*;
import java.io.*;
import java.net.*;
import java.util.*;
import groovy.lang.*;
import groovy.util.*;

public class MultiPartSpecificationImpl
  extends java.lang.Object  implements
    io.restassured.specification.MultiPartSpecification,    groovy.lang.GroovyObject {
public  groovy.lang.MetaClass getMetaClass() { return (groovy.lang.MetaClass)null;}
public  void setMetaClass(groovy.lang.MetaClass mc) { }
public  java.lang.Object invokeMethod(java.lang.String method, java.lang.Object arguments) { return null;}
public  java.lang.Object getProperty(java.lang.String property) { return null;}
public  void setProperty(java.lang.String property, java.lang.Object value) { }
public  void setContent(java.lang.Object value) { }
public  void setControlName(java.lang.String value) { }
public  void setMimeType(java.lang.String value) { }
public  void setCharset(java.lang.String value) { }
public  boolean getControlNameSpecifiedExplicitly() { return false;}
public  boolean isControlNameSpecifiedExplicitly() { return false;}
public  void setControlNameSpecifiedExplicitly(boolean value) { }
public  boolean getFileNameSpecifiedExplicitly() { return false;}
public  boolean isFileNameSpecifiedExplicitly() { return false;}
public  void setFileNameSpecifiedExplicitly(boolean value) { }
public  void setHeaders(java.util.Map<java.lang.String, java.lang.String> value) { }
public  java.lang.Object getContent() { return null;}
public  java.lang.String getControlName() { return (java.lang.String)null;}
public  java.lang.String getMimeType() { return (java.lang.String)null;}
public  java.lang.String getCharset() { return (java.lang.String)null;}
public  java.lang.String getFileName() { return (java.lang.String)null;}
public  java.util.Map<java.lang.String, java.lang.String> getHeaders() { return (java.util.Map)null;}
public  boolean hasFileName() { return false;}
public  void setFileName(java.lang.String fileName) { }
public  java.lang.String toString() { return (java.lang.String)null;}
}
