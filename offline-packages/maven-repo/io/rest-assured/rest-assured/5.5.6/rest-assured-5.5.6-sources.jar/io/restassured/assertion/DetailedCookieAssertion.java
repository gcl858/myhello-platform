package io.restassured.assertion;

import java.lang.*;
import java.io.*;
import java.net.*;
import java.util.*;
import groovy.lang.*;
import groovy.util.*;

public class DetailedCookieAssertion
  extends java.lang.Object  implements
    groovy.lang.GroovyObject {
public  groovy.lang.MetaClass getMetaClass() { return (groovy.lang.MetaClass)null;}
public  void setMetaClass(groovy.lang.MetaClass mc) { }
public  java.lang.Object invokeMethod(java.lang.String method, java.lang.Object arguments) { return null;}
public  java.lang.Object getProperty(java.lang.String property) { return null;}
public  void setProperty(java.lang.String property, java.lang.Object value) { }
public  java.lang.String getCookieName() { return (java.lang.String)null;}
public  void setCookieName(java.lang.String value) { }
public  org.hamcrest.Matcher<? super io.restassured.http.Cookie> getMatcher() { return (org.hamcrest.Matcher)null;}
public  void setMatcher(org.hamcrest.Matcher<? super io.restassured.http.Cookie> value) { }
public  java.lang.Object validateCookies(java.util.List<java.lang.String> headerWithCookieList, io.restassured.http.Cookies responseCookies) { return null;}
}
