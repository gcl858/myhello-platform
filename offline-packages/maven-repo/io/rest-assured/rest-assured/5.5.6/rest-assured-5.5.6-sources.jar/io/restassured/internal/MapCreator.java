package io.restassured.internal;

import java.lang.*;
import java.io.*;
import java.net.*;
import java.util.*;
import groovy.lang.*;
import groovy.util.*;

public class MapCreator
  extends java.lang.Object  implements
    groovy.lang.GroovyObject {
public  groovy.lang.MetaClass getMetaClass() { return (groovy.lang.MetaClass)null;}
public  void setMetaClass(groovy.lang.MetaClass mc) { }
public  java.lang.Object invokeMethod(java.lang.String method, java.lang.Object arguments) { return null;}
public  java.lang.Object getProperty(java.lang.String property) { return null;}
public  void setProperty(java.lang.String property, java.lang.Object value) { }
public static  java.util.Map<java.lang.String, java.lang.Object> createMapFromParams(io.restassured.internal.MapCreator.CollisionStrategy collisionStrategy, java.lang.String firstParam, java.lang.Object firstValue, java.lang.Object... parameters) { return (java.util.Map)null;}
public static  java.util.Map<java.lang.String, java.lang.Object> createMapFromParams(io.restassured.internal.MapCreator.CollisionStrategy collisionStrategy, java.lang.String firstParam, java.lang.Object... parameters) { return (java.util.Map)null;}
public static  java.util.Map<java.lang.String, java.lang.Object> createMapFromObjects(io.restassured.internal.MapCreator.CollisionStrategy collisionStrategy, java.lang.Object... parameters) { return (java.util.Map)null;}
public static enum CollisionStrategy
  implements
    groovy.lang.GroovyObject {
MERGE, OVERWRITE;
public static final io.restassured.internal.MapCreator.CollisionStrategy MIN_VALUE = null;
public static final io.restassured.internal.MapCreator.CollisionStrategy MAX_VALUE = null;
public  groovy.lang.MetaClass getMetaClass() { return (groovy.lang.MetaClass)null;}
public  void setMetaClass(groovy.lang.MetaClass mc) { }
public  java.lang.Object invokeMethod(java.lang.String method, java.lang.Object arguments) { return null;}
public  java.lang.Object getProperty(java.lang.String property) { return null;}
public  void setProperty(java.lang.String property, java.lang.Object value) { }
public  io.restassured.internal.MapCreator.CollisionStrategy next() { return (io.restassured.internal.MapCreator.CollisionStrategy)null;}
public  io.restassured.internal.MapCreator.CollisionStrategy previous() { return (io.restassured.internal.MapCreator.CollisionStrategy)null;}
public static final  io.restassured.internal.MapCreator.CollisionStrategy $INIT(java.lang.Object... para) { return (io.restassured.internal.MapCreator.CollisionStrategy)null;}
}
@groovy.transform.Canonical() public static class ArgsAndValue
  extends java.lang.Object  implements
    groovy.lang.GroovyObject {
public  groovy.lang.MetaClass getMetaClass() { return (groovy.lang.MetaClass)null;}
public  void setMetaClass(groovy.lang.MetaClass mc) { }
public  java.lang.Object invokeMethod(java.lang.String method, java.lang.Object arguments) { return null;}
public  java.lang.Object getProperty(java.lang.String property) { return null;}
public  void setProperty(java.lang.String property, java.lang.Object value) { }
public  java.util.List<io.restassured.specification.Argument> getArgs() { return (java.util.List)null;}
public  void setArgs(java.util.List<io.restassured.specification.Argument> value) { }
public  java.lang.Object getValue() { return null;}
public  void setValue(java.lang.Object value) { }
}
}
