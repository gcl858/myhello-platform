package io.restassured.internal;

import io.restassured.config.*;
import io.restassured.http.*;
import io.restassured.internal.http.*;
import io.restassured.specification.*;
import java.lang.*;
import java.io.*;
import java.net.*;
import java.util.*;
import groovy.lang.*;
import groovy.util.*;

public class RequestSpecificationImpl
  extends java.lang.Object  implements
    io.restassured.specification.FilterableRequestSpecification,    groovy.lang.GroovyInterceptable {
public RequestSpecificationImpl
(java.lang.String baseURI, int requestPort, java.lang.String basePath, io.restassured.authentication.AuthenticationScheme defaultAuthScheme, java.util.List<io.restassured.filter.Filter> filters, io.restassured.specification.RequestSpecification defaultSpec, boolean urlEncode, io.restassured.config.RestAssuredConfig restAssuredConfig, io.restassured.internal.log.LogRepository logRepository, io.restassured.specification.ProxySpecification proxySpecification, boolean allowContentType, boolean addCsrfFilter) {}
public  groovy.lang.MetaClass getMetaClass() { return (groovy.lang.MetaClass)null;}
public  void setMetaClass(groovy.lang.MetaClass mc) { }
public  java.lang.Object invokeMethod(java.lang.String method, java.lang.Object arguments) { return null;}
public  java.lang.Object getProperty(java.lang.String property) { return null;}
public  void setProperty(java.lang.String property, java.lang.Object value) { }
public  io.restassured.authentication.AuthenticationScheme getAuthenticationScheme() { return (io.restassured.authentication.AuthenticationScheme)null;}
public  void setAuthenticationScheme(io.restassured.authentication.AuthenticationScheme value) { }
public  io.restassured.specification.RequestSpecification when() { return (io.restassured.specification.RequestSpecification)null;}
public  io.restassured.specification.RequestSpecification given() { return (io.restassured.specification.RequestSpecification)null;}
public  io.restassured.specification.RequestSpecification that() { return (io.restassured.specification.RequestSpecification)null;}
public  io.restassured.specification.ResponseSpecification response() { return (io.restassured.specification.ResponseSpecification)null;}
public  io.restassured.response.Response get(java.lang.String path, java.lang.Object... pathParams) { return (io.restassured.response.Response)null;}
public  io.restassured.response.Response post(java.lang.String path, java.lang.Object... pathParams) { return (io.restassured.response.Response)null;}
public  io.restassured.response.Response put(java.lang.String path, java.lang.Object... pathParams) { return (io.restassured.response.Response)null;}
public  io.restassured.response.Response delete(java.lang.String path, java.lang.Object... pathParams) { return (io.restassured.response.Response)null;}
public  io.restassured.response.Response head(java.lang.String path, java.lang.Object... pathParams) { return (io.restassured.response.Response)null;}
public  io.restassured.response.Response patch(java.lang.String path, java.lang.Object... pathParams) { return (io.restassured.response.Response)null;}
public  io.restassured.response.Response options(java.lang.String path, java.lang.Object... pathParams) { return (io.restassured.response.Response)null;}
public  io.restassured.response.Response get(java.net.URI uri) { return (io.restassured.response.Response)null;}
public  io.restassured.response.Response post(java.net.URI uri) { return (io.restassured.response.Response)null;}
public  io.restassured.response.Response put(java.net.URI uri) { return (io.restassured.response.Response)null;}
public  io.restassured.response.Response delete(java.net.URI uri) { return (io.restassured.response.Response)null;}
public  io.restassured.response.Response head(java.net.URI uri) { return (io.restassured.response.Response)null;}
public  io.restassured.response.Response patch(java.net.URI uri) { return (io.restassured.response.Response)null;}
public  io.restassured.response.Response options(java.net.URI uri) { return (io.restassured.response.Response)null;}
public  io.restassured.response.Response get(java.net.URL url) { return (io.restassured.response.Response)null;}
public  io.restassured.response.Response post(java.net.URL url) { return (io.restassured.response.Response)null;}
public  io.restassured.response.Response put(java.net.URL url) { return (io.restassured.response.Response)null;}
public  io.restassured.response.Response delete(java.net.URL url) { return (io.restassured.response.Response)null;}
public  io.restassured.response.Response head(java.net.URL url) { return (io.restassured.response.Response)null;}
public  io.restassured.response.Response patch(java.net.URL url) { return (io.restassured.response.Response)null;}
public  io.restassured.response.Response options(java.net.URL url) { return (io.restassured.response.Response)null;}
public  io.restassured.response.Response get() { return (io.restassured.response.Response)null;}
public  io.restassured.response.Response post() { return (io.restassured.response.Response)null;}
public  io.restassured.response.Response put() { return (io.restassured.response.Response)null;}
public  io.restassured.response.Response delete() { return (io.restassured.response.Response)null;}
public  io.restassured.response.Response head() { return (io.restassured.response.Response)null;}
public  io.restassured.response.Response patch() { return (io.restassured.response.Response)null;}
public  io.restassured.response.Response options() { return (io.restassured.response.Response)null;}
public  io.restassured.response.Response request(io.restassured.http.Method method) { return (io.restassured.response.Response)null;}
public  io.restassured.response.Response request(java.lang.String method) { return (io.restassured.response.Response)null;}
public  io.restassured.response.Response request(io.restassured.http.Method method, java.lang.String path, java.lang.Object... pathParams) { return (io.restassured.response.Response)null;}
public  io.restassured.response.Response request(java.lang.String method, java.lang.String path, java.lang.Object... pathParams) { return (io.restassured.response.Response)null;}
public  io.restassured.response.Response request(io.restassured.http.Method method, java.net.URI uri) { return (io.restassured.response.Response)null;}
public  io.restassured.response.Response request(io.restassured.http.Method method, java.net.URL url) { return (io.restassured.response.Response)null;}
public  io.restassured.response.Response request(java.lang.String method, java.net.URI uri) { return (io.restassured.response.Response)null;}
public  io.restassured.response.Response request(java.lang.String method, java.net.URL url) { return (io.restassured.response.Response)null;}
public  io.restassured.response.Response get(java.lang.String path, java.util.Map pathParamsMap) { return (io.restassured.response.Response)null;}
public  io.restassured.response.Response post(java.lang.String path, java.util.Map pathParamsMap) { return (io.restassured.response.Response)null;}
public  io.restassured.response.Response put(java.lang.String path, java.util.Map pathParamsMap) { return (io.restassured.response.Response)null;}
public  io.restassured.response.Response delete(java.lang.String path, java.util.Map pathParamsMap) { return (io.restassured.response.Response)null;}
public  io.restassured.response.Response head(java.lang.String path, java.util.Map pathParamsMap) { return (io.restassured.response.Response)null;}
public  io.restassured.response.Response patch(java.lang.String path, java.util.Map pathParamsMap) { return (io.restassured.response.Response)null;}
public  io.restassured.response.Response options(java.lang.String path, java.util.Map pathParamsMap) { return (io.restassured.response.Response)null;}
public  io.restassured.specification.RequestSpecification params(java.lang.String firstParameterName, java.lang.Object firstParameterValue, java.lang.Object... parameterNameValuePairs) { return (io.restassured.specification.RequestSpecification)null;}
public  io.restassured.specification.RequestSpecification params(java.util.Map parametersMap) { return (io.restassured.specification.RequestSpecification)null;}
public  io.restassured.specification.RequestSpecification param(java.lang.String parameterName, java.lang.Object... parameterValues) { return (io.restassured.specification.RequestSpecification)null;}
public  io.restassured.specification.FilterableRequestSpecification removeParam(java.lang.String parameterName) { return (io.restassured.specification.FilterableRequestSpecification)null;}
public  io.restassured.specification.RequestSpecification param(java.lang.String parameterName, java.util.Collection<?> parameterValues) { return (io.restassured.specification.RequestSpecification)null;}
public  io.restassured.specification.RequestSpecification queryParam(java.lang.String parameterName, java.util.Collection<?> parameterValues) { return (io.restassured.specification.RequestSpecification)null;}
public  io.restassured.specification.FilterableRequestSpecification removeQueryParam(java.lang.String parameterName) { return (io.restassured.specification.FilterableRequestSpecification)null;}
public  io.restassured.specification.FilterableRequestSpecification removeHeader(java.lang.String headerName) { return (io.restassured.specification.FilterableRequestSpecification)null;}
public  io.restassured.specification.FilterableRequestSpecification removeCookie(java.lang.String cookieName) { return (io.restassured.specification.FilterableRequestSpecification)null;}
public  io.restassured.specification.FilterableRequestSpecification removeCookie(io.restassured.http.Cookie cookie) { return (io.restassured.specification.FilterableRequestSpecification)null;}
public  io.restassured.specification.FilterableRequestSpecification replaceHeader(java.lang.String headerName, java.lang.String newValue) { return (io.restassured.specification.FilterableRequestSpecification)null;}
public  io.restassured.specification.FilterableRequestSpecification replaceCookie(java.lang.String cookieName, java.lang.String value) { return (io.restassured.specification.FilterableRequestSpecification)null;}
public  io.restassured.specification.FilterableRequestSpecification replaceCookie(io.restassured.http.Cookie cookie) { return (io.restassured.specification.FilterableRequestSpecification)null;}
public  io.restassured.specification.FilterableRequestSpecification replaceHeaders(io.restassured.http.Headers headers) { return (io.restassured.specification.FilterableRequestSpecification)null;}
public  io.restassured.specification.FilterableRequestSpecification replaceCookies(io.restassured.http.Cookies cookies) { return (io.restassured.specification.FilterableRequestSpecification)null;}
public  io.restassured.specification.FilterableRequestSpecification removeHeaders() { return (io.restassured.specification.FilterableRequestSpecification)null;}
public  io.restassured.specification.FilterableRequestSpecification removeCookies() { return (io.restassured.specification.FilterableRequestSpecification)null;}
public  io.restassured.specification.RequestSpecification queryParams(java.lang.String firstParameterName, java.lang.Object firstParameterValue, java.lang.Object... parameterNameValuePairs) { return (io.restassured.specification.RequestSpecification)null;}
public  io.restassured.specification.RequestSpecification queryParams(java.util.Map parametersMap) { return (io.restassured.specification.RequestSpecification)null;}
public  io.restassured.specification.RequestSpecification queryParam(java.lang.String parameterName, java.lang.Object... parameterValues) { return (io.restassured.specification.RequestSpecification)null;}
public  io.restassured.specification.RequestSpecification formParam(java.lang.String parameterName, java.util.Collection<?> parameterValues) { return (io.restassured.specification.RequestSpecification)null;}
public  io.restassured.specification.FilterableRequestSpecification removeFormParam(java.lang.String parameterName) { return (io.restassured.specification.FilterableRequestSpecification)null;}
public  io.restassured.specification.RequestSpecification formParams(java.lang.String firstParameterName, java.lang.Object firstParameterValue, java.lang.Object... parameterNameValuePairs) { return (io.restassured.specification.RequestSpecification)null;}
public  io.restassured.specification.RequestSpecification formParams(java.util.Map parametersMap) { return (io.restassured.specification.RequestSpecification)null;}
public  io.restassured.specification.RequestSpecification formParam(java.lang.String parameterName, java.lang.Object... additionalParameterValues) { return (io.restassured.specification.RequestSpecification)null;}
public  io.restassured.specification.RequestSpecification urlEncodingEnabled(boolean isEnabled) { return (io.restassured.specification.RequestSpecification)null;}
public  io.restassured.specification.RequestSpecification pathParam(java.lang.String parameterName, java.lang.Object parameterValue) { return (io.restassured.specification.RequestSpecification)null;}
public  io.restassured.specification.RequestSpecification pathParams(java.lang.String firstParameterName, java.lang.Object firstParameterValue, java.lang.Object... parameterNameValuePairs) { return (io.restassured.specification.RequestSpecification)null;}
public  io.restassured.specification.RequestSpecification pathParams(java.util.Map parameterNameValuePairs) { return (io.restassured.specification.RequestSpecification)null;}
public  io.restassured.specification.FilterableRequestSpecification removePathParam(java.lang.String parameterName) { return (io.restassured.specification.FilterableRequestSpecification)null;}
public  io.restassured.specification.FilterableRequestSpecification removeNamedPathParam(java.lang.String parameterName) { return (io.restassured.specification.FilterableRequestSpecification)null;}
public  io.restassured.specification.FilterableRequestSpecification removeUnnamedPathParam(java.lang.String parameterName) { return (io.restassured.specification.FilterableRequestSpecification)null;}
public  io.restassured.specification.FilterableRequestSpecification removeUnnamedPathParamByValue(java.lang.String parameterValue) { return (io.restassured.specification.FilterableRequestSpecification)null;}
public  io.restassured.specification.RequestSpecification config(io.restassured.config.RestAssuredConfig config) { return (io.restassured.specification.RequestSpecification)null;}
public  io.restassured.specification.RequestSpecification keyStore(java.lang.String pathToJks, java.lang.String password) { return (io.restassured.specification.RequestSpecification)null;}
public  io.restassured.specification.RequestSpecification keyStore(java.io.File pathToJks, java.lang.String password) { return (io.restassured.specification.RequestSpecification)null;}
public  io.restassured.specification.RequestSpecification trustStore(java.lang.String path, java.lang.String password) { return (io.restassured.specification.RequestSpecification)null;}
public  io.restassured.specification.RequestSpecification trustStore(java.io.File path, java.lang.String password) { return (io.restassured.specification.RequestSpecification)null;}
public  io.restassured.specification.RequestSpecification trustStore(java.security.KeyStore trustStore) { return (io.restassured.specification.RequestSpecification)null;}
public  io.restassured.specification.RequestSpecification keyStore(java.security.KeyStore keyStore) { return (io.restassured.specification.RequestSpecification)null;}
public  io.restassured.specification.RequestSpecification relaxedHTTPSValidation() { return (io.restassured.specification.RequestSpecification)null;}
public  io.restassured.specification.RequestSpecification relaxedHTTPSValidation(java.lang.String protocol) { return (io.restassured.specification.RequestSpecification)null;}
public  io.restassured.specification.RequestSpecification filter(io.restassured.filter.Filter filter) { return (io.restassured.specification.RequestSpecification)null;}
public  io.restassured.specification.RequestSpecification filters(java.util.List<io.restassured.filter.Filter> filters) { return (io.restassured.specification.RequestSpecification)null;}
public  io.restassured.specification.RequestSpecification filters(io.restassured.filter.Filter filter, io.restassured.filter.Filter... additionalFilter) { return (io.restassured.specification.RequestSpecification)null;}
public  io.restassured.specification.RequestLogSpecification log() { return (io.restassured.specification.RequestLogSpecification)null;}
public  io.restassured.specification.RequestSpecification and() { return (io.restassured.specification.RequestSpecification)null;}
public  io.restassured.specification.RequestSpecification request() { return (io.restassured.specification.RequestSpecification)null;}
public  io.restassured.specification.RequestSpecification with() { return (io.restassured.specification.RequestSpecification)null;}
public  io.restassured.specification.ResponseSpecification then() { return (io.restassured.specification.ResponseSpecification)null;}
public  io.restassured.specification.ResponseSpecification expect() { return (io.restassured.specification.ResponseSpecification)null;}
public  io.restassured.specification.AuthenticationSpecification auth() { return (io.restassured.specification.AuthenticationSpecification)null;}
@java.lang.Override() public  io.restassured.specification.RequestSpecification csrf(java.lang.String csrfTokenPath) { return (io.restassured.specification.RequestSpecification)null;}
@java.lang.Override() public  io.restassured.specification.RequestSpecification csrf(java.lang.String csrfTokenPath, java.lang.String csrfInputFieldName) { return (io.restassured.specification.RequestSpecification)null;}
@java.lang.Override() public  io.restassured.specification.RequestSpecification disableCsrf() { return (io.restassured.specification.RequestSpecification)null;}
public  io.restassured.specification.AuthenticationSpecification authentication() { return (io.restassured.specification.AuthenticationSpecification)null;}
public  io.restassured.specification.RequestSpecification port(int port) { return (io.restassured.specification.RequestSpecification)null;}
public  io.restassured.specification.RequestSpecification body(java.lang.String body) { return (io.restassured.specification.RequestSpecification)null;}
public  io.restassured.specification.RequestSpecification baseUri(java.lang.String baseUri) { return (io.restassured.specification.RequestSpecification)null;}
public  io.restassured.specification.RequestSpecification basePath(java.lang.String basePath) { return (io.restassured.specification.RequestSpecification)null;}
public  io.restassured.specification.RequestSpecification proxy(java.lang.String host, int port) { return (io.restassured.specification.RequestSpecification)null;}
public  io.restassured.specification.RequestSpecification proxy(java.lang.String host) { return (io.restassured.specification.RequestSpecification)null;}
public  io.restassured.specification.RequestSpecification proxy(int port) { return (io.restassured.specification.RequestSpecification)null;}
public  io.restassured.specification.RequestSpecification proxy(java.lang.String host, int port, java.lang.String scheme) { return (io.restassured.specification.RequestSpecification)null;}
public  io.restassured.specification.RequestSpecification proxy(java.net.URI uri) { return (io.restassured.specification.RequestSpecification)null;}
public  io.restassured.specification.RequestSpecification proxy(io.restassured.specification.ProxySpecification proxySpecification) { return (io.restassured.specification.RequestSpecification)null;}
public  io.restassured.specification.RequestSpecification body(byte... body) { return (io.restassured.specification.RequestSpecification)null;}
public  io.restassured.specification.RequestSpecification body(java.io.File body) { return (io.restassured.specification.RequestSpecification)null;}
public  io.restassured.specification.RequestSpecification body(java.io.InputStream body) { return (io.restassured.specification.RequestSpecification)null;}
public  io.restassured.specification.RequestSpecification body(java.lang.Object object) { return (io.restassured.specification.RequestSpecification)null;}
public  io.restassured.specification.RequestSpecification body(java.lang.Object object, io.restassured.mapper.ObjectMapper mapper) { return (io.restassured.specification.RequestSpecification)null;}
public  io.restassured.specification.RequestSpecification body(java.lang.Object object, io.restassured.mapper.ObjectMapperType mapperType) { return (io.restassured.specification.RequestSpecification)null;}
public  io.restassured.specification.RequestSpecification contentType(io.restassured.http.ContentType contentType) { return (io.restassured.specification.RequestSpecification)null;}
public  io.restassured.specification.RequestSpecification contentType(java.lang.String contentType) { return (io.restassured.specification.RequestSpecification)null;}
public  io.restassured.specification.RequestSpecification noContentType() { return (io.restassured.specification.RequestSpecification)null;}
public  io.restassured.specification.RequestSpecification accept(io.restassured.http.ContentType contentType) { return (io.restassured.specification.RequestSpecification)null;}
public  io.restassured.specification.RequestSpecification accept(java.lang.String mediaTypes) { return (io.restassured.specification.RequestSpecification)null;}
public  io.restassured.specification.RequestSpecification headers(java.util.Map headers) { return (io.restassured.specification.RequestSpecification)null;}
public  io.restassured.specification.RequestSpecification headers(io.restassured.http.Headers headers) { return (io.restassured.specification.RequestSpecification)null;}
public  io.restassured.specification.RequestSpecification header(java.lang.String headerName, java.lang.Object headerValue, java.lang.Object... additionalHeaderValues) { return (io.restassured.specification.RequestSpecification)null;}
public  io.restassured.specification.RequestSpecification header(io.restassured.http.Header header) { return (io.restassured.specification.RequestSpecification)null;}
public  io.restassured.specification.RequestSpecification headers(java.lang.String firstHeaderName, java.lang.Object firstHeaderValue, java.lang.Object... headerNameValuePairs) { return (io.restassured.specification.RequestSpecification)null;}
public  io.restassured.specification.RequestSpecification cookies(java.lang.String firstCookieName, java.lang.Object firstCookieValue, java.lang.Object... cookieNameValuePairs) { return (io.restassured.specification.RequestSpecification)null;}
public  io.restassured.specification.RequestSpecification cookies(java.util.Map cookies) { return (io.restassured.specification.RequestSpecification)null;}
public  io.restassured.specification.RequestSpecification cookies(io.restassured.http.Cookies cookies) { return (io.restassured.specification.RequestSpecification)null;}
public  io.restassured.specification.RequestSpecification cookie(java.lang.String cookieName, java.lang.Object value, java.lang.Object... additionalValues) { return (io.restassured.specification.RequestSpecification)null;}
public  io.restassured.specification.RequestSpecification cookie(io.restassured.http.Cookie cookie) { return (io.restassured.specification.RequestSpecification)null;}
public  io.restassured.specification.RequestSpecification cookie(java.lang.String cookieName) { return (io.restassured.specification.RequestSpecification)null;}
public  io.restassured.specification.RedirectSpecification redirects() { return (io.restassured.specification.RedirectSpecification)null;}
public  io.restassured.specification.RequestSpecification spec(io.restassured.specification.RequestSpecification requestSpecificationToMerge) { return (io.restassured.specification.RequestSpecification)null;}
public  io.restassured.specification.RequestSpecification specification(io.restassured.specification.RequestSpecification requestSpecificationToMerge) { return (io.restassured.specification.RequestSpecification)null;}
public  io.restassured.specification.RequestSpecification sessionId(java.lang.String sessionIdValue) { return (io.restassured.specification.RequestSpecification)null;}
public  io.restassured.specification.RequestSpecification sessionId(java.lang.String sessionIdName, java.lang.String sessionIdValue) { return (io.restassured.specification.RequestSpecification)null;}
public  io.restassured.specification.RequestSpecification multiPart(io.restassured.specification.MultiPartSpecification multiPartSpec) { return (io.restassured.specification.RequestSpecification)null;}
public  io.restassured.specification.RequestSpecification multiPart(java.lang.String controlName, java.io.File file) { return (io.restassured.specification.RequestSpecification)null;}
public  io.restassured.specification.RequestSpecification multiPart(java.io.File file) { return (io.restassured.specification.RequestSpecification)null;}
public  io.restassured.specification.RequestSpecification multiPart(java.lang.String controlName, java.io.File file, java.lang.String mimeType) { return (io.restassured.specification.RequestSpecification)null;}
public  io.restassured.specification.RequestSpecification multiPart(java.lang.String controlName, java.lang.Object object) { return (io.restassured.specification.RequestSpecification)null;}
public  io.restassured.specification.RequestSpecification multiPart(java.lang.String controlName, java.lang.Object object, java.lang.String mimeType) { return (io.restassured.specification.RequestSpecification)null;}
public  io.restassured.specification.RequestSpecification multiPart(java.lang.String controlName, java.lang.String filename, java.lang.Object object, java.lang.String mimeType) { return (io.restassured.specification.RequestSpecification)null;}
public  io.restassured.specification.RequestSpecification multiPart(java.lang.String name, java.lang.String fileName, byte... bytes) { return (io.restassured.specification.RequestSpecification)null;}
public  io.restassured.specification.RequestSpecification multiPart(java.lang.String name, java.lang.String fileName, byte[] bytes, java.lang.String mimeType) { return (io.restassured.specification.RequestSpecification)null;}
public  io.restassured.specification.RequestSpecification multiPart(java.lang.String name, java.lang.String fileName, java.io.InputStream stream) { return (io.restassured.specification.RequestSpecification)null;}
public  io.restassured.specification.RequestSpecification multiPart(java.lang.String name, java.lang.String fileName, java.io.InputStream stream, java.lang.String mimeType) { return (io.restassured.specification.RequestSpecification)null;}
public  io.restassured.specification.RequestSpecification multiPart(java.lang.String name, java.lang.String contentBody) { return (io.restassured.specification.RequestSpecification)null;}
public  io.restassured.specification.RequestSpecification multiPart(java.lang.String name, io.restassured.internal.NoParameterValue contentBody) { return (io.restassured.specification.RequestSpecification)null;}
public  io.restassured.specification.RequestSpecification multiPart(java.lang.String name, java.lang.String contentBody, java.lang.String mimeType) { return (io.restassured.specification.RequestSpecification)null;}
public  java.lang.Object newFilterContext(java.lang.Object assertionClosure, java.lang.Object filters, java.lang.Object properties) { return null;}
public  void assertCorrectNumberOfPathParams() { }
public  boolean shouldApplySSLConfig(java.lang.Object http, io.restassured.config.RestAssuredConfig cfg) { return false;}
public  java.lang.Object applyRestAssuredConfig(io.restassured.internal.http.HTTPBuilder http) { return null;}
public  java.lang.Object applySessionConfig(io.restassured.config.SessionConfig sessionConfig) { return null;}
public  java.lang.Object applyEncoderConfig(io.restassured.internal.http.HTTPBuilder httpBuilder, io.restassured.config.EncoderConfig encoderConfig) { return null;}
public  java.lang.Object applyHttpClientConfig(io.restassured.config.HttpClientConfig httpClientConfig) { return null;}
public  java.lang.Object applyRedirectConfig(io.restassured.config.RedirectConfig redirectConfig) { return null;}
public  java.lang.Object assembleBodyContent(java.lang.Object httpMethod) { return null;}
public  java.lang.Object mergeMapsAndRetainOrder(java.util.Map<java.lang.String, java.lang.Object> map1, java.util.Map<java.lang.String, java.lang.Object> map2) { return null;}
public  java.lang.Object setRequestHeadersToHttpBuilder(io.restassured.internal.http.HTTPBuilder http) { return null;}
public  void buildUnnamedPathParameterTuples(java.lang.Object... unnamedPathParameterValues) { }
public  java.lang.String partiallyApplyPathParams(java.lang.String path, boolean encodePath, java.util.List<java.lang.String> unnamedPathParams) { return (java.lang.String)null;}
public  void setResponseSpecification(io.restassured.specification.ResponseSpecification responseSpecification) { }
public  java.lang.String getBaseUri() { return (java.lang.String)null;}
public  java.lang.String getBasePath() { return (java.lang.String)null;}
public  java.lang.String getDerivedPath() { return (java.lang.String)null;}
public  java.lang.String getUserDefinedPath() { return (java.lang.String)null;}
public  java.lang.String getMethod() { return (java.lang.String)null;}
public  java.lang.String getURI() { return (java.lang.String)null;}
public  int getPort() { return (int)0;}
public  java.util.Map<java.lang.String, java.lang.String> getFormParams() { return (java.util.Map)null;}
public  java.util.Map<java.lang.String, java.lang.String> getPathParams() { return (java.util.Map)null;}
public  java.util.Map<java.lang.String, java.lang.String> getNamedPathParams() { return (java.util.Map)null;}
public  java.util.Map<java.lang.String, java.lang.String> getUnnamedPathParams() { return (java.util.Map)null;}
public  java.util.List<java.lang.String> getUnnamedPathParamValues() { return (java.util.List)null;}
public  java.util.Map<java.lang.String, java.lang.String> getRequestParams() { return (java.util.Map)null;}
public  java.util.Map<java.lang.String, java.lang.String> getQueryParams() { return (java.util.Map)null;}
public  java.util.List<io.restassured.specification.MultiPartSpecification> getMultiPartParams() { return (java.util.List)null;}
public  io.restassured.http.Headers getHeaders() { return (io.restassured.http.Headers)null;}
public  io.restassured.http.Cookies getCookies() { return (io.restassured.http.Cookies)null;}
public  java.lang.Object getBody() { return null;}
public  java.util.List<io.restassured.filter.Filter> getDefinedFilters() { return (java.util.List)null;}
public  io.restassured.config.RestAssuredConfig getConfig() { return (io.restassured.config.RestAssuredConfig)null;}
public  org.apache.http.client.HttpClient getHttpClient() { return (org.apache.http.client.HttpClient)null;}
public  io.restassured.specification.ProxySpecification getProxySpecification() { return (io.restassured.specification.ProxySpecification)null;}
public  io.restassured.specification.FilterableRequestSpecification path(java.lang.String path) { return (io.restassured.specification.FilterableRequestSpecification)null;}
public  java.util.List<java.lang.String> getUndefinedPathParamPlaceholders() { return (java.util.List)null;}
public  java.util.List<java.lang.String> getPathParamPlaceholders() { return (java.util.List)null;}
public  java.lang.String getRequestContentType() { return (java.lang.String)null;}
@java.lang.Override() public  java.lang.String getContentType() { return (java.lang.String)null;}
@java.lang.Override() public  io.restassured.specification.RequestSpecification noFilters() { return (io.restassured.specification.RequestSpecification)null;}
@java.lang.Override() public  io.restassured.specification.RequestSpecification noFiltersOfType(java.lang.Class filterType) { return (io.restassured.specification.RequestSpecification)null;}
public  io.restassured.config.RestAssuredConfig restAssuredConfig() { return (io.restassured.config.RestAssuredConfig)null;}
public static  java.util.List getPlaceholders(java.lang.String uri) { return (java.util.List)null;}
public static  java.lang.String getDerivedPath(java.lang.String uri) { return (java.lang.String)null;}
public  java.lang.String getURI(java.lang.String uri) { return (java.lang.String)null;}
public  java.util.Map<java.lang.String, java.lang.String> getRedundantNamedPathParams() { return (java.util.Map)null;}
public  java.util.List<java.lang.String> getRedundantUnnamedPathParamValues() { return (java.util.List)null;}
public  void removeUnnamedPathParamAtIndex(int indexOfParamName) { }
public  void setMethod(java.lang.String method) { }
private enum EncodingTarget
  implements
    groovy.lang.GroovyObject {
BODY, QUERY;
public static final io.restassured.internal.RequestSpecificationImpl.EncodingTarget MIN_VALUE = null;
public static final io.restassured.internal.RequestSpecificationImpl.EncodingTarget MAX_VALUE = null;
public  groovy.lang.MetaClass getMetaClass() { return (groovy.lang.MetaClass)null;}
public  void setMetaClass(groovy.lang.MetaClass mc) { }
public  java.lang.Object invokeMethod(java.lang.String method, java.lang.Object arguments) { return null;}
public  java.lang.Object getProperty(java.lang.String property) { return null;}
public  void setProperty(java.lang.String property, java.lang.Object value) { }
public  io.restassured.internal.RequestSpecificationImpl.EncodingTarget next() { return (io.restassured.internal.RequestSpecificationImpl.EncodingTarget)null;}
public  io.restassured.internal.RequestSpecificationImpl.EncodingTarget previous() { return (io.restassured.internal.RequestSpecificationImpl.EncodingTarget)null;}
public static final  io.restassured.internal.RequestSpecificationImpl.EncodingTarget $INIT(java.lang.Object... para) { return (io.restassured.internal.RequestSpecificationImpl.EncodingTarget)null;}
}
}
