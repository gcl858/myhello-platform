package io.restassured.internal;

import java.lang.*;
import java.io.*;
import java.net.*;
import java.util.*;
import groovy.lang.*;
import groovy.util.*;

public class PreemptiveAuthSpecImpl
  extends java.lang.Object  implements
    io.restassured.specification.PreemptiveAuthSpec,    groovy.lang.GroovyObject {
public PreemptiveAuthSpecImpl
(io.restassured.specification.RequestSpecification requestBuilder) {}
public  groovy.lang.MetaClass getMetaClass() { return (groovy.lang.MetaClass)null;}
public  void setMetaClass(groovy.lang.MetaClass mc) { }
public  java.lang.Object invokeMethod(java.lang.String method, java.lang.Object arguments) { return null;}
public  java.lang.Object getProperty(java.lang.String property) { return null;}
public  void setProperty(java.lang.String property, java.lang.Object value) { }
public  io.restassured.specification.RequestSpecification basic(java.lang.String username, java.lang.String password) { return (io.restassured.specification.RequestSpecification)null;}
public  io.restassured.specification.RequestSpecification oauth2(java.lang.String accessToken) { return (io.restassured.specification.RequestSpecification)null;}
}
