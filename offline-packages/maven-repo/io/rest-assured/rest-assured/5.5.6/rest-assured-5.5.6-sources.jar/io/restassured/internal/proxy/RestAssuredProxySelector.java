package io.restassured.internal.proxy;

import java.lang.*;
import java.io.*;
import java.net.*;
import java.util.*;
import groovy.lang.*;
import groovy.util.*;

public class RestAssuredProxySelector
  extends java.net.ProxySelector  implements
    groovy.lang.GroovyObject {
public  groovy.lang.MetaClass getMetaClass() { return (groovy.lang.MetaClass)null;}
public  void setMetaClass(groovy.lang.MetaClass mc) { }
public  java.lang.Object invokeMethod(java.lang.String method, java.lang.Object arguments) { return null;}
public  java.lang.Object getProperty(java.lang.String property) { return null;}
public  void setProperty(java.lang.String property, java.lang.Object value) { }
public  java.net.ProxySelector getDelegatingProxySelector() { return (java.net.ProxySelector)null;}
public  void setDelegatingProxySelector(java.net.ProxySelector value) { }
public  io.restassured.specification.ProxySpecification getProxySpecification() { return (io.restassured.specification.ProxySpecification)null;}
public  void setProxySpecification(io.restassured.specification.ProxySpecification value) { }
public  java.util.List<java.net.Proxy> select(java.net.URI uri) { return (java.util.List)null;}
public  void connectFailed(java.net.URI uri, java.net.SocketAddress sa, java.io.IOException ioe) { }
}
