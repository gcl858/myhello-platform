package io.restassured.internal.filter;

import java.lang.*;
import java.io.*;
import java.net.*;
import java.util.*;
import groovy.lang.*;
import groovy.util.*;

public class CsrfFilter
  extends java.lang.Object  implements
    io.restassured.filter.Filter,    groovy.lang.GroovyObject {
public  groovy.lang.MetaClass getMetaClass() { return (groovy.lang.MetaClass)null;}
public  void setMetaClass(groovy.lang.MetaClass mc) { }
public  java.lang.Object invokeMethod(java.lang.String method, java.lang.Object arguments) { return null;}
public  java.lang.Object getProperty(java.lang.String property) { return null;}
public  void setProperty(java.lang.String property, java.lang.Object value) { }
public  io.restassured.config.CsrfConfig getCsrfConfig() { return (io.restassured.config.CsrfConfig)null;}
public  void setCsrfConfig(io.restassured.config.CsrfConfig value) { }
@java.lang.Override() public  io.restassured.response.Response filter(io.restassured.specification.FilterableRequestSpecification requestSpec, io.restassured.specification.FilterableResponseSpecification responseSpec, io.restassured.filter.FilterContext ctx) { return (io.restassured.response.Response)null;}
}
