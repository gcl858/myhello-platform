package io.restassured.internal;

import java.lang.*;
import java.io.*;
import java.net.*;
import java.util.*;
import groovy.lang.*;
import groovy.util.*;

public class RequestLogSpecificationImpl
  extends io.restassured.internal.LogSpecificationImpl  implements
    io.restassured.specification.RequestLogSpecification,    groovy.lang.GroovyObject {
public  groovy.lang.MetaClass getMetaClass() { return (groovy.lang.MetaClass)null;}
public  void setMetaClass(groovy.lang.MetaClass mc) { }
public  java.lang.Object invokeMethod(java.lang.String method, java.lang.Object arguments) { return null;}
public  java.lang.Object getProperty(java.lang.String property) { return null;}
public  void setProperty(java.lang.String property, java.lang.Object value) { }
public  io.restassured.specification.RequestSpecification getRequestSpecification() { return (io.restassured.specification.RequestSpecification)null;}
public  void setRequestSpecification(io.restassured.specification.RequestSpecification value) { }
public  io.restassured.internal.log.LogRepository getLogRepository() { return (io.restassured.internal.log.LogRepository)null;}
public  void setLogRepository(io.restassured.internal.log.LogRepository value) { }
public  java.util.Set<java.lang.String> getBlacklistedHeaders() { return (java.util.Set)null;}
public  void setBlacklistedHeaders(java.util.Set<java.lang.String> value) { }
public  io.restassured.specification.RequestSpecification params() { return (io.restassured.specification.RequestSpecification)null;}
public  io.restassured.specification.RequestSpecification parameters() { return (io.restassured.specification.RequestSpecification)null;}
public  io.restassured.specification.RequestSpecification uri() { return (io.restassured.specification.RequestSpecification)null;}
public  io.restassured.specification.RequestSpecification method() { return (io.restassured.specification.RequestSpecification)null;}
public  io.restassured.specification.RequestSpecification body() { return (io.restassured.specification.RequestSpecification)null;}
public  io.restassured.specification.RequestSpecification body(boolean shouldPrettyPrint) { return (io.restassured.specification.RequestSpecification)null;}
public  io.restassured.specification.RequestSpecification all(boolean shouldPrettyPrint) { return (io.restassured.specification.RequestSpecification)null;}
public  io.restassured.specification.RequestSpecification everything(boolean shouldPrettyPrint) { return (io.restassured.specification.RequestSpecification)null;}
public  io.restassured.specification.RequestSpecification all() { return (io.restassured.specification.RequestSpecification)null;}
public  io.restassured.specification.RequestSpecification everything() { return (io.restassured.specification.RequestSpecification)null;}
public  io.restassured.specification.RequestSpecification headers() { return (io.restassured.specification.RequestSpecification)null;}
public  io.restassured.specification.RequestSpecification cookies() { return (io.restassured.specification.RequestSpecification)null;}
public  io.restassured.specification.RequestSpecification ifValidationFails() { return (io.restassured.specification.RequestSpecification)null;}
public  io.restassured.specification.RequestSpecification ifValidationFails(io.restassured.filter.log.LogDetail logDetail) { return (io.restassured.specification.RequestSpecification)null;}
public  io.restassured.specification.RequestSpecification ifValidationFails(io.restassured.filter.log.LogDetail logDetail, boolean shouldPrettyPrint) { return (io.restassured.specification.RequestSpecification)null;}
}
