package io.restassured.internal.multipart;

import java.lang.*;
import java.io.*;
import java.net.*;
import java.util.*;
import groovy.lang.*;
import groovy.util.*;

public class RestAssuredMultiPartEntity
  extends java.lang.Object  implements
    org.apache.http.HttpEntity,    groovy.lang.GroovyObject {
public RestAssuredMultiPartEntity
(java.lang.String subType, java.lang.String charset, org.apache.http.entity.mime.HttpMultipartMode mode, java.lang.String boundary) {}
public  groovy.lang.MetaClass getMetaClass() { return (groovy.lang.MetaClass)null;}
public  void setMetaClass(groovy.lang.MetaClass mc) { }
public  java.lang.Object invokeMethod(java.lang.String method, java.lang.Object arguments) { return null;}
public  java.lang.Object getProperty(java.lang.String property) { return null;}
public  void setProperty(java.lang.String property, java.lang.Object value) { }
public  void addPart(org.apache.http.entity.mime.FormBodyPart bodyPart) { }
public  void addPart(java.lang.String name, org.apache.http.entity.mime.content.ContentBody contentBody) { }
public  boolean isRepeatable() { return false;}
public  boolean isChunked() { return false;}
public  boolean isStreaming() { return false;}
public  long getContentLength() { return (long)0;}
public  org.apache.http.Header getContentType() { return (org.apache.http.Header)null;}
public  org.apache.http.Header getContentEncoding() { return (org.apache.http.Header)null;}
public  void consumeContent()throws java.io.IOException, java.lang.UnsupportedOperationException { }
public  java.io.InputStream getContent()throws java.io.IOException, java.lang.UnsupportedOperationException { return (java.io.InputStream)null;}
public  void writeTo(java.io.OutputStream outstream)throws java.io.IOException { }
}
