package io.restassured.internal.mapping;

import java.lang.*;
import java.io.*;
import java.net.*;
import java.util.*;
import groovy.lang.*;
import groovy.util.*;

public class ObjectMapperDeserializationContextImpl
  extends io.restassured.internal.common.ObjectDeserializationContextImpl  implements
    io.restassured.mapper.ObjectMapperDeserializationContext,    groovy.lang.GroovyObject {
public  groovy.lang.MetaClass getMetaClass() { return (groovy.lang.MetaClass)null;}
public  void setMetaClass(groovy.lang.MetaClass mc) { }
public  java.lang.Object invokeMethod(java.lang.String method, java.lang.Object arguments) { return null;}
public  java.lang.Object getProperty(java.lang.String property) { return null;}
public  void setProperty(java.lang.String property, java.lang.Object value) { }
public  void setContentType(java.lang.Object value) { }
@java.lang.Override() public  java.lang.String getContentType() { return (java.lang.String)null;}
}
