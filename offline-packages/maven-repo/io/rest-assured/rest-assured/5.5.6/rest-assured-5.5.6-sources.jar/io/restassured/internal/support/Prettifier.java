package io.restassured.internal.support;

import java.lang.*;
import java.io.*;
import java.net.*;
import java.util.*;
import groovy.lang.*;
import groovy.util.*;

public class Prettifier
  extends java.lang.Object  implements
    groovy.lang.GroovyObject {
public  groovy.lang.MetaClass getMetaClass() { return (groovy.lang.MetaClass)null;}
public  void setMetaClass(groovy.lang.MetaClass mc) { }
public  java.lang.Object invokeMethod(java.lang.String method, java.lang.Object arguments) { return null;}
public  java.lang.Object getProperty(java.lang.String property) { return null;}
public  void setProperty(java.lang.String property, java.lang.Object value) { }
public  java.lang.String getPrettifiedBodyIfPossible(io.restassured.specification.FilterableRequestSpecification request) { return (java.lang.String)null;}
public  java.lang.String getPrettifiedBodyIfPossible(io.restassured.response.ResponseOptions responseOptions, io.restassured.response.ResponseBody responseBody) { return (java.lang.String)null;}
public  java.lang.String prettify(java.lang.Object content, io.restassured.parsing.Parser parser) { return (java.lang.String)null;}
}
