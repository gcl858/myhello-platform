package io.restassured.internal;

import java.lang.*;
import java.io.*;
import java.net.*;
import java.util.*;
import groovy.lang.*;
import groovy.util.*;

public class RedirectSpecificationImpl
  extends java.lang.Object  implements
    io.restassured.specification.RedirectSpecification,    groovy.lang.GroovyObject {
public RedirectSpecificationImpl
(io.restassured.specification.RequestSpecification requestSpecification, java.util.Map httpClientParams) {}
public  groovy.lang.MetaClass getMetaClass() { return (groovy.lang.MetaClass)null;}
public  void setMetaClass(groovy.lang.MetaClass mc) { }
public  java.lang.Object invokeMethod(java.lang.String method, java.lang.Object arguments) { return null;}
public  java.lang.Object getProperty(java.lang.String property) { return null;}
public  void setProperty(java.lang.String property, java.lang.Object value) { }
public  io.restassured.specification.RequestSpecification max(int maxNumberOfRedirect) { return (io.restassured.specification.RequestSpecification)null;}
public  io.restassured.specification.RequestSpecification follow(boolean followRedirects) { return (io.restassured.specification.RequestSpecification)null;}
public  io.restassured.specification.RequestSpecification allowCircular(boolean allowCircularRedirects) { return (io.restassured.specification.RequestSpecification)null;}
public  io.restassured.specification.RequestSpecification rejectRelative(boolean rejectRelativeRedirects) { return (io.restassured.specification.RequestSpecification)null;}
}
