package io.restassured.authentication;

import java.lang.*;
import java.io.*;
import java.net.*;
import java.util.*;
import groovy.lang.*;
import groovy.util.*;

public class FormAuthScheme
  extends java.lang.Object  implements
    io.restassured.authentication.AuthenticationScheme,    groovy.lang.GroovyObject {
public  groovy.lang.MetaClass getMetaClass() { return (groovy.lang.MetaClass)null;}
public  void setMetaClass(groovy.lang.MetaClass mc) { }
public  java.lang.Object invokeMethod(java.lang.String method, java.lang.Object arguments) { return null;}
public  java.lang.Object getProperty(java.lang.String property) { return null;}
public  void setProperty(java.lang.String property, java.lang.Object value) { }
public  java.lang.Object getUserName() { return null;}
public  void setUserName(java.lang.Object value) { }
public  java.lang.Object getPassword() { return null;}
public  void setPassword(java.lang.Object value) { }
public  io.restassured.authentication.FormAuthConfig getConfig() { return (io.restassured.authentication.FormAuthConfig)null;}
public  void setConfig(io.restassured.authentication.FormAuthConfig value) { }
public  void authenticate(io.restassured.internal.http.HTTPBuilder httpBuilder) { }
}
