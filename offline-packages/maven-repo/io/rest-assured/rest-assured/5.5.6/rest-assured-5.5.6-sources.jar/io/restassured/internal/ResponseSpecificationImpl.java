package io.restassured.internal;

import io.restassured.assertion.*;
import io.restassured.specification.*;
import java.lang.*;
import java.io.*;
import java.net.*;
import java.util.*;
import groovy.lang.*;
import groovy.util.*;

public class ResponseSpecificationImpl
  extends java.lang.Object  implements
    io.restassured.specification.FilterableResponseSpecification,    groovy.lang.GroovyObject {
public ResponseSpecificationImpl
(java.lang.String bodyRootPath, io.restassured.specification.ResponseSpecification defaultSpec, io.restassured.internal.ResponseParserRegistrar rpr, io.restassured.config.RestAssuredConfig config, io.restassured.internal.log.LogRepository logRepository) {
super ();
}
public ResponseSpecificationImpl
(java.lang.String bodyRootPath, io.restassured.specification.ResponseSpecification defaultSpec, io.restassured.internal.ResponseParserRegistrar rpr, io.restassured.config.RestAssuredConfig config, io.restassured.response.Response response, io.restassured.internal.log.LogRepository logRepository) {}
public  groovy.lang.MetaClass getMetaClass() { return (groovy.lang.MetaClass)null;}
public  void setMetaClass(groovy.lang.MetaClass mc) { }
public  java.lang.Object invokeMethod(java.lang.String method, java.lang.Object arguments) { return null;}
public  java.lang.Object getProperty(java.lang.String property) { return null;}
public  void setProperty(java.lang.String property, java.lang.Object value) { }
public  io.restassured.internal.ResponseParserRegistrar getRpr() { return (io.restassured.internal.ResponseParserRegistrar)null;}
public  void setRpr(io.restassured.internal.ResponseParserRegistrar value) { }
public  io.restassured.config.RestAssuredConfig getConfig() { return (io.restassured.config.RestAssuredConfig)null;}
public  void setConfig(io.restassured.config.RestAssuredConfig value) { }
public  io.restassured.internal.log.LogRepository getLogRepository() { return (io.restassured.internal.log.LogRepository)null;}
public  void setLogRepository(io.restassured.internal.log.LogRepository value) { }
public  io.restassured.specification.ResponseSpecification body(java.util.List<io.restassured.specification.Argument> arguments, org.hamcrest.Matcher matcher, java.lang.Object... additionalKeyMatcherPairs) { return (io.restassured.specification.ResponseSpecification)null;}
public  io.restassured.response.Response validate(io.restassured.response.Response response) { return (io.restassured.response.Response)null;}
public  io.restassured.specification.ResponseSpecification body(org.hamcrest.Matcher matcher, org.hamcrest.Matcher... additionalMatchers) { return (io.restassured.specification.ResponseSpecification)null;}
public  io.restassured.specification.ResponseSpecification body(java.lang.String key, org.hamcrest.Matcher matcher, java.lang.Object... additionalKeyMatcherPairs) { return (io.restassured.specification.ResponseSpecification)null;}
public  io.restassured.specification.ResponseSpecification time(org.hamcrest.Matcher<java.lang.Long> matcher) { return (io.restassured.specification.ResponseSpecification)null;}
public  io.restassured.specification.ResponseSpecification time(org.hamcrest.Matcher<java.lang.Long> matcher, java.util.concurrent.TimeUnit timeUnit) { return (io.restassured.specification.ResponseSpecification)null;}
public  io.restassured.specification.ResponseSpecification statusCode(org.hamcrest.Matcher<? super java.lang.Integer> expectedStatusCode) { return (io.restassured.specification.ResponseSpecification)null;}
public  io.restassured.specification.ResponseSpecification statusCode(int expectedStatusCode) { return (io.restassured.specification.ResponseSpecification)null;}
public  io.restassured.specification.ResponseSpecification statusLine(org.hamcrest.Matcher<? super java.lang.String> expectedStatusLine) { return (io.restassured.specification.ResponseSpecification)null;}
public  io.restassured.specification.ResponseSpecification headers(java.util.Map expectedHeaders) { return (io.restassured.specification.ResponseSpecification)null;}
public  io.restassured.specification.ResponseSpecification headers(java.lang.String firstExpectedHeaderName, java.lang.Object firstExpectedHeaderValue, java.lang.Object... expectedHeaders) { return (io.restassured.specification.ResponseSpecification)null;}
@java.lang.Override() public  io.restassured.specification.ResponseSpecification header(java.lang.String headerName, java.util.function.Function mappingFunction, org.hamcrest.Matcher expectedValueMatcher) { return (io.restassured.specification.ResponseSpecification)null;}
public  io.restassured.specification.ResponseSpecification header(java.lang.String headerName, org.hamcrest.Matcher expectedValueMatcher) { return (io.restassured.specification.ResponseSpecification)null;}
public  io.restassured.specification.ResponseSpecification header(java.lang.String headerName, java.lang.String expectedValue) { return (io.restassured.specification.ResponseSpecification)null;}
public  io.restassured.specification.ResponseSpecification cookies(java.util.Map expectedCookies) { return (io.restassured.specification.ResponseSpecification)null;}
public  io.restassured.specification.ResponseSpecification cookies(java.lang.String firstExpectedCookieName, java.lang.Object firstExpectedCookieValue, java.lang.Object... expectedCookieNameValuePairs) { return (io.restassured.specification.ResponseSpecification)null;}
public  io.restassured.specification.ResponseSpecification cookie(java.lang.String cookieName, org.hamcrest.Matcher expectedValueMatcher) { return (io.restassured.specification.ResponseSpecification)null;}
public  io.restassured.specification.ResponseSpecification cookie(java.lang.String cookieName, io.restassured.matcher.DetailedCookieMatcher detailedCookieMatcher) { return (io.restassured.specification.ResponseSpecification)null;}
public  io.restassured.specification.ResponseSpecification cookie(java.lang.String cookieName) { return (io.restassured.specification.ResponseSpecification)null;}
public  io.restassured.specification.ResponseSpecification cookie(java.lang.String cookieName, java.lang.Object expectedValue) { return (io.restassured.specification.ResponseSpecification)null;}
public  io.restassured.specification.ResponseSpecification spec(io.restassured.specification.ResponseSpecification responseSpecificationToMerge) { return (io.restassured.specification.ResponseSpecification)null;}
public  io.restassured.specification.ResponseSpecification specification(io.restassured.specification.ResponseSpecification responseSpecificationToMerge) { return (io.restassured.specification.ResponseSpecification)null;}
public  io.restassured.specification.ResponseSpecification statusLine(java.lang.String expectedStatusLine) { return (io.restassured.specification.ResponseSpecification)null;}
public  io.restassured.specification.ResponseSpecification body(java.lang.String key, java.util.List<io.restassured.specification.Argument> arguments, org.hamcrest.Matcher matcher, java.lang.Object... additionalKeyMatcherPairs) { return (io.restassured.specification.ResponseSpecification)null;}
public  io.restassured.specification.ResponseLogSpecification log() { return (io.restassured.specification.ResponseLogSpecification)null;}
public  io.restassured.internal.ResponseSpecificationImpl logDetail(io.restassured.filter.log.LogDetail logDetail) { return (io.restassured.internal.ResponseSpecificationImpl)null;}
public  io.restassured.specification.ResponseSpecification onFailMessage(java.lang.String message) { return (io.restassured.specification.ResponseSpecification)null;}
public  io.restassured.filter.log.LogDetail getLogDetail() { return (io.restassured.filter.log.LogDetail)null;}
public  io.restassured.specification.RequestSender when() { return (io.restassured.specification.RequestSender)null;}
public  io.restassured.specification.ResponseSpecification response() { return (io.restassured.specification.ResponseSpecification)null;}
public  io.restassured.specification.RequestSpecification given() { return (io.restassured.specification.RequestSpecification)null;}
public  io.restassured.specification.ResponseSpecification that() { return (io.restassured.specification.ResponseSpecification)null;}
public  io.restassured.specification.RequestSpecification request() { return (io.restassured.specification.RequestSpecification)null;}
public  io.restassured.specification.ResponseSpecification parser(java.lang.String contentType, io.restassured.parsing.Parser parser) { return (io.restassured.specification.ResponseSpecification)null;}
public  io.restassured.specification.ResponseSpecification and() { return (io.restassured.specification.ResponseSpecification)null;}
public  io.restassured.specification.RequestSpecification with() { return (io.restassured.specification.RequestSpecification)null;}
public  io.restassured.specification.ResponseSpecification then() { return (io.restassured.specification.ResponseSpecification)null;}
public  io.restassured.specification.ResponseSpecification expect() { return (io.restassured.specification.ResponseSpecification)null;}
public  io.restassured.specification.ResponseSpecification rootPath(java.lang.String rootPath) { return (io.restassured.specification.ResponseSpecification)null;}
public  io.restassured.specification.ResponseSpecification noRootPath() { return (io.restassured.specification.ResponseSpecification)null;}
public  io.restassured.specification.ResponseSpecification appendRootPath(java.lang.String pathToAppend) { return (io.restassured.specification.ResponseSpecification)null;}
public  io.restassured.specification.ResponseSpecification appendRootPath(java.lang.String pathToAppend, java.util.List<io.restassured.specification.Argument> arguments) { return (io.restassured.specification.ResponseSpecification)null;}
public  io.restassured.specification.ResponseSpecification detachRootPath(java.lang.String pathToDetach) { return (io.restassured.specification.ResponseSpecification)null;}
public  io.restassured.specification.ResponseSpecification rootPath(java.lang.String rootPath, java.util.List<io.restassured.specification.Argument> arguments) { return (io.restassured.specification.ResponseSpecification)null;}
public  io.restassured.specification.ResponseSpecification root(java.lang.String rootPath, java.util.List<io.restassured.specification.Argument> arguments) { return (io.restassured.specification.ResponseSpecification)null;}
public  boolean hasBodyAssertionsDefined() { return false;}
public  boolean hasAssertionsDefined() { return false;}
public  io.restassured.specification.ResponseSpecification defaultParser(io.restassured.parsing.Parser parser) { return (io.restassured.specification.ResponseSpecification)null;}
public  io.restassured.specification.ResponseSpecification contentType(io.restassured.http.ContentType contentType) { return (io.restassured.specification.ResponseSpecification)null;}
public  io.restassured.specification.ResponseSpecification contentType(java.lang.String contentType) { return (io.restassured.specification.ResponseSpecification)null;}
public  io.restassured.specification.ResponseSpecification contentType(org.hamcrest.Matcher<? super java.lang.String> contentType) { return (io.restassured.specification.ResponseSpecification)null;}
public  org.hamcrest.Matcher<java.lang.Integer> getStatusCode() { return (org.hamcrest.Matcher)null;}
public  org.hamcrest.Matcher<java.lang.String> getStatusLine() { return (org.hamcrest.Matcher)null;}
public  boolean hasHeaderAssertions() { return false;}
public  boolean hasCookieAssertions() { return false;}
public  java.lang.String getResponseContentType() { return (java.lang.String)null;}
public  java.lang.String getRootPath() { return (java.lang.String)null;}
public  void throwIllegalStateExceptionIfRootPathIsNotDefined(java.lang.String description) { }
public  java.lang.Object forceDisableEagerAssert() { return null;}
public  java.lang.Object forceValidateResponse() { return null;}
public class HamcrestAssertionClosure
  extends java.lang.Object  implements
    groovy.lang.GroovyObject {
public HamcrestAssertionClosure
(io.restassured.specification.ResponseSpecification responseSpecification) {}
public  groovy.lang.MetaClass getMetaClass() { return (groovy.lang.MetaClass)null;}
public  void setMetaClass(groovy.lang.MetaClass mc) { }
public  java.lang.Object invokeMethod(java.lang.String method, java.lang.Object arguments) { return null;}
public  java.lang.Object getProperty(java.lang.String property) { return null;}
public  void setProperty(java.lang.String property, java.lang.Object value) { }
public  java.lang.Object call(java.lang.Object response, java.lang.Object content) { return null;}
public  java.lang.Object call(java.lang.Object response) { return null;}
public  java.lang.Object getResponseContentType() { return null;}
public  java.lang.Object getClosure() { return null;}
public  java.lang.Object validate(io.restassured.response.Response response) { return null;}
}
}
