package io.restassured.assertion;

import java.lang.*;
import java.io.*;
import java.net.*;
import java.util.*;
import groovy.lang.*;
import groovy.util.*;

public class ResponseTimeMatcher
  extends java.lang.Object  implements
    groovy.lang.GroovyObject {
public  groovy.lang.MetaClass getMetaClass() { return (groovy.lang.MetaClass)null;}
public  void setMetaClass(groovy.lang.MetaClass mc) { }
public  java.lang.Object invokeMethod(java.lang.String method, java.lang.Object arguments) { return null;}
public  java.lang.Object getProperty(java.lang.String property) { return null;}
public  void setProperty(java.lang.String property, java.lang.Object value) { }
public  org.hamcrest.Matcher<java.lang.Long> getMatcher() { return (org.hamcrest.Matcher)null;}
public  void setMatcher(org.hamcrest.Matcher<java.lang.Long> value) { }
public  java.util.concurrent.TimeUnit getTimeUnit() { return (java.util.concurrent.TimeUnit)null;}
public  void setTimeUnit(java.util.concurrent.TimeUnit value) { }
public  java.lang.Object validate(io.restassured.response.Response response) { return null;}
}
