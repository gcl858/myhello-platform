package io.restassured.assertion;

import java.lang.*;
import java.io.*;
import java.net.*;
import java.util.*;
import groovy.lang.*;
import groovy.util.*;

public class HeaderMatcher
  extends java.lang.Object  implements
    groovy.lang.GroovyObject {
public  groovy.lang.MetaClass getMetaClass() { return (groovy.lang.MetaClass)null;}
public  void setMetaClass(groovy.lang.MetaClass mc) { }
public  java.lang.Object invokeMethod(java.lang.String method, java.lang.Object arguments) { return null;}
public  java.lang.Object getProperty(java.lang.String property) { return null;}
public  void setProperty(java.lang.String property, java.lang.Object value) { }
public  java.lang.Object getHeaderName() { return null;}
public  void setHeaderName(java.lang.Object value) { }
public  java.lang.Object getMappingFunction() { return null;}
public  void setMappingFunction(java.lang.Object value) { }
public  org.hamcrest.Matcher getMatcher() { return (org.hamcrest.Matcher)null;}
public  void setMatcher(org.hamcrest.Matcher value) { }
public  java.lang.Object validateHeader(java.lang.Object headers) { return null;}
}
