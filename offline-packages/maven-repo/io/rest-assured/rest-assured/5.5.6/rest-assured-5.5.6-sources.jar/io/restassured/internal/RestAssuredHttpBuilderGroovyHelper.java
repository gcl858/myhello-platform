package io.restassured.internal;

import java.lang.*;
import java.io.*;
import java.net.*;
import java.util.*;
import groovy.lang.*;
import groovy.util.*;

public class RestAssuredHttpBuilderGroovyHelper
  extends java.lang.Object  implements
    groovy.lang.GroovyObject {
public  groovy.lang.MetaClass getMetaClass() { return (groovy.lang.MetaClass)null;}
public  void setMetaClass(groovy.lang.MetaClass mc) { }
public  java.lang.Object invokeMethod(java.lang.String method, java.lang.Object arguments) { return null;}
public  java.lang.Object getProperty(java.lang.String property) { return null;}
public  void setProperty(java.lang.String property, java.lang.Object value) { }
public static  java.util.Collection<java.lang.String> flattenToString(java.util.Collection collection) { return (java.util.Collection)null;}
public static  groovy.lang.Closure createClosureThatCalls(java.lang.Object assertionClosure) { return (groovy.lang.Closure)null;}
}
