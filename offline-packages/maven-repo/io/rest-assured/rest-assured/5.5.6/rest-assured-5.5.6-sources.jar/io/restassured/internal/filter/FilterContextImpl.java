package io.restassured.internal.filter;

import java.lang.*;
import java.io.*;
import java.net.*;
import java.util.*;
import groovy.lang.*;
import groovy.util.*;

public class FilterContextImpl
  extends java.lang.Object  implements
    io.restassured.filter.FilterContext,    groovy.lang.GroovyObject {
public FilterContextImpl
(java.lang.String requestUri, java.lang.String fullOriginalPath, java.lang.String fullSubstitutedPath, java.lang.String internalRequestUri, java.lang.String userDefinedPath, java.lang.Object[] unnamedPathParams, java.lang.String method, java.lang.Object assertionClosure, java.util.Iterator<io.restassured.filter.Filter> filters, java.util.Map<java.lang.String, java.lang.Object> properties) {}
public  groovy.lang.MetaClass getMetaClass() { return (groovy.lang.MetaClass)null;}
public  void setMetaClass(groovy.lang.MetaClass mc) { }
public  java.lang.Object invokeMethod(java.lang.String method, java.lang.Object arguments) { return null;}
public  java.lang.Object getProperty(java.lang.String property) { return null;}
public  void setProperty(java.lang.String property, java.lang.Object value) { }
public  java.lang.Object getAssertionClosure() { return null;}
public  void setAssertionClosure(java.lang.Object value) { }
public  java.util.Map<java.lang.String, java.lang.Object> getProperties() { return (java.util.Map)null;}
public  void setProperties(java.util.Map<java.lang.String, java.lang.Object> value) { }
public  io.restassured.response.Response next(io.restassured.specification.FilterableRequestSpecification request, io.restassured.specification.FilterableResponseSpecification response) { return (io.restassured.response.Response)null;}
@java.lang.SuppressWarnings(value="GroovyUnusedDeclaration") public  java.lang.String getInternalRequestURI() { return (java.lang.String)null;}
public  io.restassured.response.Response send(io.restassured.specification.RequestSender requestSender) { return (io.restassured.response.Response)null;}
public  void setValue(java.lang.String name, java.lang.Object value) { }
public  boolean hasValue(java.lang.String name) { return false;}
@java.lang.Override() public  boolean hasValue(java.lang.String name, java.lang.Object value) { return false;}
public  java.lang.Object getValue(java.lang.String name) { return null;}
}
