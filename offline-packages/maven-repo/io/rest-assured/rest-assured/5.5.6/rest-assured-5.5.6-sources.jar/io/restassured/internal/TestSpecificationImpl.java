package io.restassured.internal;

import java.lang.*;
import java.io.*;
import java.net.*;
import java.util.*;
import groovy.lang.*;
import groovy.util.*;

public class TestSpecificationImpl
  extends java.lang.Object  implements
    io.restassured.specification.RequestSender,    groovy.lang.GroovyObject {
public TestSpecificationImpl
(io.restassured.specification.RequestSpecification requestSpecification, io.restassured.specification.ResponseSpecification responseSpecification) {}
public  groovy.lang.MetaClass getMetaClass() { return (groovy.lang.MetaClass)null;}
public  void setMetaClass(groovy.lang.MetaClass mc) { }
public  java.lang.Object invokeMethod(java.lang.String method, java.lang.Object arguments) { return null;}
public  java.lang.Object getProperty(java.lang.String property) { return null;}
public  void setProperty(java.lang.String property, java.lang.Object value) { }
public  io.restassured.response.Response get(java.lang.String path, java.lang.Object... pathParams) { return (io.restassured.response.Response)null;}
public  io.restassured.response.Response post(java.lang.String path, java.lang.Object... pathParams) { return (io.restassured.response.Response)null;}
public  io.restassured.response.Response put(java.lang.String path, java.lang.Object... pathParams) { return (io.restassured.response.Response)null;}
public  io.restassured.response.Response delete(java.lang.String path, java.lang.Object... pathParams) { return (io.restassured.response.Response)null;}
public  io.restassured.response.Response head(java.lang.String path, java.lang.Object... pathParams) { return (io.restassured.response.Response)null;}
public  io.restassured.response.Response patch(java.lang.String path, java.lang.Object... pathParams) { return (io.restassured.response.Response)null;}
public  io.restassured.response.Response options(java.lang.String path, java.lang.Object... pathParams) { return (io.restassured.response.Response)null;}
public  io.restassured.response.Response get(java.net.URI uri) { return (io.restassured.response.Response)null;}
public  io.restassured.response.Response post(java.net.URI uri) { return (io.restassured.response.Response)null;}
public  io.restassured.response.Response put(java.net.URI uri) { return (io.restassured.response.Response)null;}
public  io.restassured.response.Response delete(java.net.URI uri) { return (io.restassured.response.Response)null;}
public  io.restassured.response.Response head(java.net.URI uri) { return (io.restassured.response.Response)null;}
public  io.restassured.response.Response patch(java.net.URI uri) { return (io.restassured.response.Response)null;}
public  io.restassured.response.Response options(java.net.URI uri) { return (io.restassured.response.Response)null;}
public  io.restassured.response.Response get(java.net.URL url) { return (io.restassured.response.Response)null;}
public  io.restassured.response.Response post(java.net.URL url) { return (io.restassured.response.Response)null;}
public  io.restassured.response.Response put(java.net.URL url) { return (io.restassured.response.Response)null;}
public  io.restassured.response.Response delete(java.net.URL url) { return (io.restassured.response.Response)null;}
public  io.restassured.response.Response head(java.net.URL url) { return (io.restassured.response.Response)null;}
public  io.restassured.response.Response patch(java.net.URL url) { return (io.restassured.response.Response)null;}
public  io.restassured.response.Response options(java.net.URL url) { return (io.restassured.response.Response)null;}
public  io.restassured.response.Response get() { return (io.restassured.response.Response)null;}
public  io.restassured.response.Response post() { return (io.restassured.response.Response)null;}
public  io.restassured.response.Response put() { return (io.restassured.response.Response)null;}
public  io.restassured.response.Response delete() { return (io.restassured.response.Response)null;}
public  io.restassured.response.Response head() { return (io.restassured.response.Response)null;}
public  io.restassured.response.Response patch() { return (io.restassured.response.Response)null;}
public  io.restassured.response.Response options() { return (io.restassured.response.Response)null;}
public  io.restassured.response.Response request(io.restassured.http.Method method) { return (io.restassured.response.Response)null;}
public  io.restassured.response.Response request(java.lang.String method) { return (io.restassured.response.Response)null;}
public  io.restassured.response.Response request(io.restassured.http.Method method, java.lang.String path, java.lang.Object... pathParams) { return (io.restassured.response.Response)null;}
public  io.restassured.response.Response request(java.lang.String method, java.lang.String path, java.lang.Object... pathParams) { return (io.restassured.response.Response)null;}
public  io.restassured.response.Response request(io.restassured.http.Method method, java.net.URI uri) { return (io.restassured.response.Response)null;}
public  io.restassured.response.Response request(io.restassured.http.Method method, java.net.URL url) { return (io.restassured.response.Response)null;}
public  io.restassured.response.Response request(java.lang.String method, java.net.URI uri) { return (io.restassured.response.Response)null;}
public  io.restassured.response.Response request(java.lang.String method, java.net.URL url) { return (io.restassured.response.Response)null;}
public  io.restassured.response.Response get(java.lang.String path, java.util.Map pathParams) { return (io.restassured.response.Response)null;}
public  io.restassured.response.Response post(java.lang.String path, java.util.Map pathParams) { return (io.restassured.response.Response)null;}
public  io.restassured.response.Response put(java.lang.String path, java.util.Map pathParams) { return (io.restassured.response.Response)null;}
public  io.restassured.response.Response delete(java.lang.String path, java.util.Map pathParams) { return (io.restassured.response.Response)null;}
public  io.restassured.response.Response head(java.lang.String path, java.util.Map pathParams) { return (io.restassured.response.Response)null;}
public  io.restassured.response.Response patch(java.lang.String path, java.util.Map pathParams) { return (io.restassured.response.Response)null;}
public  io.restassured.response.Response options(java.lang.String path, java.util.Map pathParams) { return (io.restassured.response.Response)null;}
public  io.restassured.specification.RequestSpecification getRequestSpecification() { return (io.restassured.specification.RequestSpecification)null;}
public  io.restassured.specification.ResponseSpecification getResponseSpecification() { return (io.restassured.specification.ResponseSpecification)null;}
}
