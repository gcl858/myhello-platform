package io.restassured.authentication;

import java.lang.*;
import java.io.*;
import java.net.*;
import java.util.*;
import groovy.lang.*;
import groovy.util.*;

public class PreemptiveBasicAuthScheme
  extends java.lang.Object  implements
    io.restassured.authentication.AuthenticationScheme,    groovy.lang.GroovyObject {
public  groovy.lang.MetaClass getMetaClass() { return (groovy.lang.MetaClass)null;}
public  void setMetaClass(groovy.lang.MetaClass mc) { }
public  java.lang.Object invokeMethod(java.lang.String method, java.lang.Object arguments) { return null;}
public  java.lang.Object getProperty(java.lang.String property) { return null;}
public  void setProperty(java.lang.String property, java.lang.Object value) { }
public  java.lang.String getUserName() { return (java.lang.String)null;}
public  void setUserName(java.lang.String value) { }
public  java.lang.String getPassword() { return (java.lang.String)null;}
public  void setPassword(java.lang.String value) { }
@java.lang.Override() public  void authenticate(io.restassured.internal.http.HTTPBuilder httpBuilder) { }
public  java.lang.String generateAuthToken() { return (java.lang.String)null;}
}
