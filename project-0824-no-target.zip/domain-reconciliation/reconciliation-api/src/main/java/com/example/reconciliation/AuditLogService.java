package com.example.reconciliation;

import com.example.platform.common.PlatformPaths;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import io.quarkus.runtime.StartupEvent;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.enterprise.event.Observes;
import jakarta.inject.Inject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.sql.DataSource;
import java.nio.file.Path;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;

import com.example.reconciliation.migration.DatabaseMigrationRunner;

/**
 * 通用型 Workflow 執行紀錄與對帳服務 (Audit & Reconciliation Service)
 *
 * 高併發優化與模組化 Migration 版本:
 * 1. 啟用 SQLite WAL (Write-Ahead Logging) 模式與 busy_timeout=5000
 * 2. 注入 Quarkus Agroal DataSource 連線池管理連線
 * 3. 透過 DatabaseMigrationRunner 自動執行各模組之 SQL 遷移腳本 (解耦表結構與業務專屬 View)
 * 4. 使用 AtomicBoolean 確保資料庫結構與 PRAGMA 配置僅初始化一次
 */
@ApplicationScoped
public class AuditLogService {

    private static final Logger LOG = LoggerFactory.getLogger(AuditLogService.class);
    private static final ObjectMapper MAPPER = new ObjectMapper();
    /**
     * SQLite 連線 URL — 透過 {@link PlatformPaths} 跨平台解析,
     * Linux 與 Windows 都會使用對應平台的路徑分隔符。
     */
    private static final String DB_FILE_NAME = "reconciliation.db";
    private final AtomicBoolean initialized = new AtomicBoolean(false);

    /** 跨平台 SQLite JDBC URL — 啟動時由 {@link #initDatabase()} 解析。 */
    private static final String DB_URL = PlatformPaths.sqliteUrl(DB_FILE_NAME);

    @Inject
    DataSource dataSource;

    /**
     * 應用程式啟動時，確保 data 目錄與 SQLite 表格/視圖已初始化
     */
    void onStart(@Observes StartupEvent ev) {
        initDatabase();
    }

    private Connection getConnection() throws Exception {
        if (dataSource != null) {
            return dataSource.getConnection();
        }
        // 備用路徑:DataSource 未注入(例如非 Quarkus 環境或單元測試)。
        // DB_URL 為 static final,於 class 載入時由 PlatformPaths.sqliteUrl() 解析,
        // 只看 MYHELLO_DATA_DIR 環境變數 / 系統參數,不會跟 quarkus.datasource.jdbc.url 同步。
        // 若兩者設定不一致,備用路徑會寫到不同檔案,請改用 application.properties 配置。
        LOG.warn("[AuditLogService] DataSource 未注入,fallback 到 DriverManager(JDBC URL={})."
                + "若與 quarkus.datasource.jdbc.url 不一致,請改用 application.properties 配置避免資料分裂。",
                DB_URL);
        Class.forName("org.sqlite.JDBC");
        return DriverManager.getConnection(DB_URL);
    }

    /**
     * 初始化 SQLite 資料庫結構 (透過 DatabaseMigrationRunner 執行各模組遷移腳本)，全效能 WAL 模式設定
     */
    public void initDatabase() {
        if (initialized.get()) {
            return;
        }
        synchronized (this) {
            if (initialized.get()) {
                return;
            }
            try {
                // 確保 data 目錄存在 — 跨平台 (Windows/Linux) 共用 PlatformPaths
                Path dataDir = PlatformPaths.ensureDataDirectory();
                LOG.info("[AuditLogService] 使用 data 目錄: {}", dataDir.toAbsolutePath());

                try (Connection conn = getConnection();
                        Statement stmt = conn.createStatement()) {

                    // 0. 啟用高併發 WAL 模式與繁忙超時設定
                    stmt.execute("PRAGMA journal_mode=WAL;");
                    stmt.execute("PRAGMA synchronous=NORMAL;");
                    stmt.execute("PRAGMA busy_timeout=5000;");

                    // 1. 執行模組化資料庫遷移腳本 (包含 V1.0.0 基礎稽核表、V1.1.0 業務專屬 View 等)
                    DatabaseMigrationRunner.runMigrations(conn);

                    initialized.set(true);
                    LOG.info(
                            "[AuditLogService] SQLite 資料庫 (WAL 模式) 結構與模組化遷移已就緒。");
                }
            } catch (Exception e) {
                LOG.error("[AuditLogService] 初始化 SQLite 資料庫失敗: {}", e.getMessage(), e);
            }
        }
    }

    /**
     * 多參數進入點 (對應 SonataFlow 反射將 arguments key 展開為獨立參數)
     */
    // Backwards-compatible 4-arg overload retained for any generated handlers
    public JsonNode saveLog(String workflowId, Object businessKey, Object inputData, Object outputData) {
        return saveLog(workflowId, businessKey, null, inputData, outputData);
    }

    public JsonNode saveLog(String workflowId, Object businessKey, Object processInstanceId, Object inputData,
            Object outputData) {
        String bKeyStr = businessKey != null ? businessKey.toString() : null;
        String pInstStr = processInstanceId != null ? processInstanceId.toString() : null;
        JsonNode inputNode = MAPPER.valueToTree(inputData);
        JsonNode outputNode = MAPPER.valueToTree(outputData);
        return doSaveLog(workflowId, bKeyStr, pInstStr, inputNode, outputNode);
    }

    /**
     * 單一 JsonNode 參數進入點
     */
    public JsonNode saveLog(JsonNode arguments) {
        if (arguments == null) {
            return MAPPER.createObjectNode().put("saved", false);
        }
        String workflowId = arguments.has("workflowId") ? arguments.get("workflowId").asText() : "unknown-workflow";
        String businessKey = arguments.has("businessKey") ? arguments.get("businessKey").asText() : null;
        String processInstanceId = arguments.has("processInstanceId") ? arguments.get("processInstanceId").asText()
                : null;
        JsonNode inputDataNode = arguments.get("inputData");
        JsonNode outputDataNode = arguments.get("outputData");
        return doSaveLog(workflowId, businessKey, processInstanceId, inputDataNode, outputDataNode);
    }

    /**
     * 單一 Map 參數進入點
     */
    public JsonNode saveLog(Map<String, Object> arguments) {
        if (arguments == null) {
            return MAPPER.createObjectNode().put("saved", false);
        }
        JsonNode node = MAPPER.valueToTree(arguments);
        return saveLog(node);
    }

    /**
     * 實際執行 DB 寫入邏輯
     */
    private JsonNode doSaveLog(String workflowId, String businessKey, String processInstanceId, JsonNode inputDataNode,
            JsonNode outputDataNode) {
        try {
            String inputDataJson = inputDataNode != null ? inputDataNode.toString() : "{}";
            String outputDataJson = outputDataNode != null ? outputDataNode.toString() : "{}";

            String status = "UNKNOWN";
            String message = "";
            if (outputDataNode != null) {
                if (outputDataNode.has("status")) {
                    status = outputDataNode.get("status").asText();
                }
                if (outputDataNode.has("message")) {
                    message = outputDataNode.get("message").asText();
                }
            }

            if (!initialized.get()) {
                initDatabase();
            }

            String insertSql = "INSERT INTO workflow_execution_log " +
                    "(workflow_id, business_key, process_instance_id, status, message, input_data, output_data) " +
                    "VALUES (?, ?, ?, ?, ?, ?, ?);";

            try (Connection conn = getConnection();
                    PreparedStatement pstmt = conn.prepareStatement(insertSql)) {
                pstmt.setString(1, workflowId);
                pstmt.setString(2, businessKey);
                pstmt.setString(3, processInstanceId);
                pstmt.setString(4, status);
                pstmt.setString(5, message);
                pstmt.setString(6, inputDataJson);
                pstmt.setString(7, outputDataJson);

                int rows = pstmt.executeUpdate();
                LOG.info("[AuditLogService] 成功寫入對帳紀錄! Workflow: {}, BusinessKey: {}, Status: {}, Rows: {}",
                        workflowId, businessKey, status, rows);
            }

            ObjectNode response = MAPPER.createObjectNode();
            response.put("saved", true);
            response.put("workflowId", workflowId);
            response.put("status", status);
            return response;

        } catch (Exception e) {
            LOG.error("[AuditLogService] 寫入對帳紀錄失敗: {}", e.getMessage(), e);
            ObjectNode response = MAPPER.createObjectNode();
            response.put("saved", false);
            response.put("error", e.getMessage());
            return response;
        }
    }
}
