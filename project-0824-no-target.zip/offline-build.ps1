# ==============================================================================
# offline-build.ps1  (Windows / PowerShell 版本)
#
# 作用：在斷網/無外網連線 (Air-Gapped / Offline) 環境中，
#       使用專案內建的離線套件庫進行完整編譯與打包
#
# 用法：
#   .\offline-build.ps1                       # 使用預設離線套件庫
#   .\offline-build.ps1 -SkipTests            # 額外傳遞 Maven 參數
#   .\offline-build.ps1 -OfflineRepo D:\repo  # 指定其他離線套件庫路徑
# ==============================================================================

[CmdletBinding()]
param(
    [string]$OfflineRepo,
    # 其餘未命名的參數會自動收集到 $args，可直接傳遞給 mvn
    [Parameter(ValueFromRemainingArguments = $true)]
    [string[]]$RemainingArgs
)

# 讓中文輸出正常顯示
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$OutputEncoding = [System.Text.Encoding]::UTF8

$ErrorActionPreference = 'Stop'

# 取得腳本所在目錄（等同於 bash 的 $(dirname "${BASH_SOURCE[0]}" )）
$ScriptDir = $PSScriptRoot

# 若使用者未指定 -OfflineRepo，預設使用專案內的離線套件庫
if (-not $OfflineRepo) {
    $OfflineRepo = Join-Path -Path $ScriptDir -ChildPath 'offline-packages\maven-repo'
}

# 檢查離線套件庫是否存在
if (-not (Test-Path -LiteralPath $OfflineRepo -PathType Container)) {
    Write-Host "❌ 錯誤：找不到離線套件庫目錄: $OfflineRepo" -ForegroundColor Red
    exit 1
}

# 確認 mvn 指令可用
if (-not (Get-Command mvn -ErrorAction SilentlyContinue)) {
    Write-Host "❌ 錯誤：找不到 'mvn' 指令，請確認 Maven 已安裝並加入 PATH。" -ForegroundColor Red
    exit 1
}

Write-Host "================================================================="
Write-Host "開始執行 100% 嚴格離線編譯與打包 (mvn clean package -o)..."
Write-Host "使用離線 Maven Repository: $OfflineRepo"
Write-Host "================================================================="

# 組合 Maven 命令參數（等同於 bash 的 "$@"）
$mvnArgs = @('clean', 'package', '-o', "-Dmaven.repo.local=$OfflineRepo") + $RemainingArgs

# 執行 Maven；& 是呼叫運算子，確保以原生命令方式執行
& mvn @mvnArgs
if ($LASTEXITCODE -ne 0) {
    Write-Host "❌ Maven 建置失敗，退出代碼：$LASTEXITCODE" -ForegroundColor Red
    exit $LASTEXITCODE
}

Write-Host "================================================================="
Write-Host "✅ 離線編譯與打包成功！"
Write-Host "產出物："
Write-Host "  - distribution\transfer-app\target\quarkus-app\quarkus-run.jar"
Write-Host "  - distribution\reconciliation-app\target\quarkus-app\quarkus-run.jar"
Write-Host "================================================================="
