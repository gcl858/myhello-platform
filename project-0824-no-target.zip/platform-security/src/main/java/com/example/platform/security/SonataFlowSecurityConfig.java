package com.example.platform.security;

import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.ws.rs.container.ContainerRequestContext;
import jakarta.ws.rs.container.ContainerRequestFilter;
import jakarta.ws.rs.container.ContainerResponseContext;
import jakarta.ws.rs.container.ContainerResponseFilter;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.ext.Provider;
import org.eclipse.microprofile.openapi.OASFilter;
import org.eclipse.microprofile.openapi.models.PathItem;
import org.jboss.logging.Logger;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.Map;

public class SonataFlowSecurityConfig {

    private static final ObjectMapper MAPPER = new ObjectMapper();

    // 1. 全域 Swagger 過濾器：自動過濾未使用的 HTTP 方法
    public static class SwaggerFilter implements OASFilter {
        @Override
        public PathItem filterPathItem(PathItem pathItem) {
            pathItem.setDELETE(null);
            pathItem.setPUT(null);
            pathItem.setPATCH(null);
            pathItem.setHEAD(null);
            return pathItem;
        }
    }

    // 2. 全域 HTTP 請求攔截器：非 POST 請求一律在執行期回傳 403 Forbidden，並緩存原始 Input Payload (排除靜態頁面、系統端點與對帳查詢)
    @Provider
    @jakarta.enterprise.context.ApplicationScoped
    @jakarta.annotation.Priority(jakarta.ws.rs.Priorities.USER)
    public static class RuntimeFilter implements ContainerRequestFilter {
        @Override
        public void filter(ContainerRequestContext requestContext) throws IOException {
            String rawPath = requestContext.getUriInfo().getPath();
            String path = (rawPath != null && rawPath.startsWith("/")) ? rawPath.substring(1) : (rawPath != null ? rawPath : "");
            String method = requestContext.getMethod();

            // 自動排除 Quarkus 系統頁面（如 /q/swagger-ui, /q/dev）、靜態資源及對帳/監控查詢 API
            if (path.startsWith("q/") || path.endsWith(".html") || path.endsWith(".js") || path.endsWith(".css") || path.endsWith(".ico") || path.contains("reconciliation") || path.contains("specs") || path.contains("instances") || path.contains("jobs") || path.contains("trace")) {
                return;
            }

            if (!method.equalsIgnoreCase("POST")) {
                requestContext.abortWith(
                    Response.status(Response.Status.FORBIDDEN)
                            .entity("{\"error\": \"Only POST method is allowed\"}")
                            .build()
                );
                return;
            }

            // 讀取 Input Stream 並緩存，使用 ByteArrayInputStream 重設 stream 避免 stream 被耗盡
            InputStream entityStream = requestContext.getEntityStream();
            if (entityStream != null) {
                byte[] bytes = entityStream.readAllBytes();
                String inputPayload = new String(bytes, StandardCharsets.UTF_8);

                // 重設 Stream 供後續 SonataFlow 反序列化使用
                requestContext.setEntityStream(new ByteArrayInputStream(bytes));

                // 暫存於 requestContext 供後續 Audit Log 使用
                requestContext.setProperty("rawInputPayload", inputPayload);
                requestContext.setProperty("startTimeNano", System.nanoTime());
            }
        }
    }

    /**
     * 3. Response Filter：
     *   (1) 依 workflow 回應 body 內 `status` 欄位改寫 HTTP code（配置化，v2.2 平台化）。
     *       - 啟用名單：`platform.status-rewrite.workflows`（逗號分隔；預設 saga2-transfer-workflow）
     *       - 狀態映射：`platform.status-rewrite.mapping`（格式 STATUS=CODE,逗號分隔；
     *         預設 VALIDATION_FAILED=400,ROLLBACK_FAILED=409）
     *       未列出的 status 保持引擎原狀態碼（SUCCESS / FAILED / ROLLED_BACK → 200）。
     *   (2) 記錄完整的 URI Path、HTTP Code、耗時 (ms)、最初 Input Payload 與最終 Output Payload 至 Log。
     *
     *   執行順序注意:JAX-RS response filter 以 priority 「降序」執行 (數字大者先跑)。
     *   本 filter (USER - 10) 刻意排在 {@link UnwrapResponseFilter} (USER) 「之後」執行,
     *   以取得解包後的最終 entity,並讓改寫的狀態碼覆蓋 Unwrap 強制設定的 200。
     *
     *   相容性:entity 可能為 Map、Jackson JsonNode 或 JSON 字串 (依資源回傳型別而定),
     *   三種型別統一正規化為 Map 後再判讀 status。
     */
    @Provider
    @jakarta.enterprise.context.ApplicationScoped
    @jakarta.annotation.Priority(jakarta.ws.rs.Priorities.USER - 10)
    public static class WorkflowStatusFilter implements ContainerResponseFilter {
        private static final Logger LOG = Logger.getLogger(WorkflowStatusFilter.class);

        /** 預設啟用改寫的 workflow 名單 (可被 platform.status-rewrite.workflows 覆寫) */
        static final String DEFAULT_WORKFLOWS = "saga2-transfer-workflow";
        /** 預設 status→HTTP 映射 (可被 platform.status-rewrite.mapping 覆寫) */
        static final String DEFAULT_MAPPING = "VALIDATION_FAILED=400,ROLLBACK_FAILED=409";

        @jakarta.inject.Inject
        @org.eclipse.microprofile.config.inject.ConfigProperty(
                name = "platform.status-rewrite.workflows", defaultValue = DEFAULT_WORKFLOWS)
        String configuredWorkflows;

        @jakarta.inject.Inject
        @org.eclipse.microprofile.config.inject.ConfigProperty(
                name = "platform.status-rewrite.mapping", defaultValue = DEFAULT_MAPPING)
        String configuredMapping;

        /** 解析後的啟用名單 (比對目標:路徑第一段,即 workflow id) */
        private volatile java.util.Set<String> workflowNames = java.util.Set.of();
        /** 解析後的 status→HTTP 映射 */
        private volatile Map<String, Integer> statusRewriteMap = Map.of();

        @jakarta.annotation.PostConstruct
        void init() {
            java.util.Set<String> names = new java.util.LinkedHashSet<>();
            for (String n : configuredWorkflows.split(",")) {
                if (!n.isBlank()) {
                    names.add(n.trim());
                }
            }
            Map<String, Integer> mapping = new java.util.LinkedHashMap<>();
            for (String entry : configuredMapping.split(",")) {
                if (entry.isBlank()) {
                    continue;
                }
                String[] kv = entry.split("=", 2);
                if (kv.length == 2) {
                    try {
                        mapping.put(kv[0].trim(), Integer.parseInt(kv[1].trim()));
                    } catch (NumberFormatException e) {
                        LOG.warnf("[WorkflowStatusFilter] 無效的映射條目 '%s' (格式應為 STATUS=CODE),已忽略", entry);
                    }
                }
            }
            this.workflowNames = java.util.Collections.unmodifiableSet(names);
            this.statusRewriteMap = java.util.Collections.unmodifiableMap(mapping);
            LOG.infof("[WorkflowStatusFilter] 已載入配置: workflows=%s, mapping=%s", workflowNames, statusRewriteMap);
        }

        @Override
        public void filter(ContainerRequestContext requestContext,
                           ContainerResponseContext responseContext) {
            // 只處理 POST 啟動流程的回應 (GET 狀態查詢、DELETE 取消不適用)
            if (!"POST".equalsIgnoreCase(requestContext.getMethod())) {
                return;
            }

            String path = requestContext.getUriInfo().getPath();
            if (path.startsWith("q/")) {
                return;
            }

            // 正規化路徑:RESTEasy Reactive 的 getPath() 含前導斜線 ("/saga2-..."),
            // 與 RuntimeFilter 口徑一致去掉斜線,否則下方 startsWith 前綴比對永遠失敗
            if (path.startsWith("/")) {
                path = path.substring(1);
            }

            // 1. 若路徑第一段命中啟用名單,執行狀態碼改寫邏輯
            String rootSegment = path.contains("/") ? path.substring(0, path.indexOf('/')) : path;
            if (workflowNames.contains(rootSegment)) {
                Map<?, ?> map = normalizeEntityToMap(responseContext.getEntity());
                if (map != null) {
                    Object status = map.get("status");
                    if (status == null && map.get("workflowdata") instanceof Map<?, ?> wfMap) {
                        status = wfMap.get("status");
                    }
                    if (status != null) {
                        Integer rewrite = statusRewriteMap.get(status.toString());
                        if (rewrite != null) {
                            LOG.infof("[WorkflowStatusFilter] %s status=%s → HTTP %d", path, status, rewrite);
                            responseContext.setStatus(rewrite);
                        }
                    }
                }
            }

            // 2. 輸出完整的 Path、Input Payload、Output Payload 與執行耗時
            String inputPayload = (String) requestContext.getProperty("rawInputPayload");
            Long startTime = (Long) requestContext.getProperty("startTimeNano");
            long durationMs = startTime != null ? (System.nanoTime() - startTime) / 1_000_000 : 0;

            String outputPayload = "{}";
            try {
                Object entity = responseContext.getEntity();
                if (entity != null) {
                    outputPayload = (entity instanceof String s) ? s : MAPPER.writeValueAsString(entity);
                }
            } catch (Exception ignored) {
                outputPayload = String.valueOf(responseContext.getEntity());
            }

            String displayPath = path.startsWith("/") ? path : "/" + path;
            LOG.infof("[HTTP-AUDIT] URI: %s | HTTP: %d | Cost: %dms | INPUT: %s | OUTPUT: %s",
                    displayPath,
                    responseContext.getStatus(),
                    durationMs,
                    inputPayload != null ? inputPayload.replaceAll("\\s+", " ").trim() : "{}",
                    outputPayload.replaceAll("\\s+", " ").trim()
            );
        }

        /**
         * 將回應 entity 正規化為 Map 以判讀 status 欄位。
         * 相容三種來源型別:Map / Jackson JsonNode / JSON 字串;無法解析時回傳 null。
         */
        private static Map<?, ?> normalizeEntityToMap(Object entity) {
            if (entity instanceof Map<?, ?> map) {
                return map;
            }
            if (entity instanceof java.lang.String s && s.trim().startsWith("{")) {
                try {
                    return MAPPER.readValue(s, Map.class);
                } catch (Exception ignored) {
                    return null;
                }
            }
            try {
                return MAPPER.convertValue(entity, Map.class);
            } catch (Exception ignored) {
                return null;
            }
        }
    }
}