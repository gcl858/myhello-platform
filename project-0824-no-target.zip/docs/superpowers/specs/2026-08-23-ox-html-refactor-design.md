# Ox_* Console Pages Refactor — Design

Date: 2026-08-23
Scope: `domain-reconciliation/reconciliation-api/src/main/resources/META-INF/resources`

## Decisions (user-approved)

- New files named with original basename: `Ox_reconciliation.html`, `Ox_jobs.html`, `Ox_tester.html`, `Ox_specs.html`, `Ox_flow-trace.html`.
- Old 5 files stay untouched; new files coexist.
- Each `Ox_*.html` is fully self-contained (inline CSS/JS, no shared assets).
- Full UI/UX overhaul: refined dark fintech-console style (per-page accent color).
- No git commit unless user asks.

## Common design system (inlined per file)

- Tokens: layered surfaces, `--accent` / `--accent-rgb` / `--accent-deep` per page
  (recon=emerald, jobs=amber, tester=violet, specs=sky, trace=pink), Inter + Fira Code,
  4px spacing grid.
- Components: sticky glass navbar (8 links; sibling links point to `Ox_*.html`,
  portal links stay absolute `http://localhost:8080/...`), stat cards, toolbar fields,
  responsive tables (≤768px → stacked cards via `data-label`), toast stack
  (replaces `alert()`), promise-based confirm modal (replaces `confirm()`),
  skeleton loading rows, empty/error state banners with retry, copy-to-clipboard buttons.
- JS helpers per file: `$`, `escapeHtml`, `fmtDateTime`, `debounce`, `fetchJson`
  (checks `res.ok`), `toast`, `confirmDialog`, `copyText`, `skeletonRows`.
- API base: relative `/api/...` when served from port 8090, else fallback
  `http://localhost:8090`.
- All dynamic values escaped before `innerHTML`; no string-built `onclick`.

## Per-page changes

| File | Bug fixes | Upgrades |
|---|---|---|
| Ox_reconciliation | filename-in-onclick XSS → data-index delegation; escape all fields | stats row, CSV preview modal w/ download + Esc/backdrop close, export feedback |
| Ox_jobs | stats computed from unfiltered dataset; status filter applied locally | search + status local filtering, 30s auto-refresh switch, confirm modals |
| Ox_tester | GraphQL fallback filter always-true condition fixed | inline JSON validation error, step copy buttons, duration chips |
| Ox_specs | — | parallel ping (`Promise.allSettled`), YAML/JSON syntax highlighting, last-check timestamps |
| Ox_flow-trace | mojibake `�` char fixed; node names escaped | animated SVG connectors, node click scrolls+opens timeline card |

## Verification

Serve the resources dir statically; open each page in a headless browser:
no page-level JS errors, graceful error states when backend is down,
cross-links between Ox pages resolve.

## Out of scope

Old file edits; backend/API changes; portal pages on :8080.
