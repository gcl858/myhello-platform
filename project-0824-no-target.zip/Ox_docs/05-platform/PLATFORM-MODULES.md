# 平台元件手冊(platform-* 模組群)

> 本文為 `myhello-platform` 四個平台模組(`platform-common` / `platform-security` / `platform-data-index` / `platform-extensions`)的元件手冊。
> 所有技術事實均直接取自原始碼;引用格式以「類別#方法」為主,行號為輔(行號可能隨版本變動)。
> 版本基準:Java 17 · Quarkus 3.27.2 · KIE/Kogito 10.2.0 · sqlite-jdbc 3.45.1.0。

---

## 目錄

- [1. platform-common — 零框架共用工具層](#1-platform-common)
- [2. platform-security — 請求/回應過濾管線](#2-platform-security)
- [3. platform-data-index — Data Index 平台層封裝](#3-platform-data-index)
- [4. platform-extensions — Kogito SQLite 擴展模組群](#4-platform-extensions)
- [5. 各模組 pom 關鍵依賴表](#5-pom-關鍵依賴表)
- [6. 常見錯誤](#6-常見錯誤)

---

## 1. platform-common

### 1.1 模組定位

| 項目 | 內容 |
|------|------|
| Maven artifact | `org.acme.platform:platform-common`(parent:`myhello-platform`) |
| 套件 | `com.example.platform.common` |
| 框架依賴 | **無**。pom 的 `<dependencies>` 刻意留空(`platform-common/pom.xml:20-22`),不引入任何 Quarkus / Hibernate / Kogito API |
| 現有成員 | `PlatformPaths.java`、`package-info.java`(套件契約說明) |

`package-info.java` 明文約定:「本套件下的類別不可依賴任何 Quarkus / Hibernate / Kogito 等 framework API」,目的是讓 platform-common 可被任何模組重用而不污染 classpath。未來多個業務域共用的純 Java 工具(例:`JsonNodeExtensions`、`ErrorShape`、`DateUtils`)都應放這裡。

### 1.2 PlatformPaths 全方法表

`PlatformPaths` 是平台唯一跨模組的路徑事實來源(single source of truth),設計原則(摘自其 Javadoc):不寫死路不寫死路徑分隔符、錨定 JVM 工作目錄、支援環境變數覆寫、classpath 一律 `/`、零 framework 依賴。

#### 常數與靜態初始化

| 成員 | 值 / 行為 |
|------|-----------|
| `DATA_DIR_ENV` | `"MYHELLO_DATA_DIR"` — 外部資料目錄覆寫的環境變數名 |
| `DEFAULT_DATA_DIR_NAME` | `"data"` |
| `LOGS_DIR_ENV` | `"MYHELLO_LOGS_DIR"` — 外部紀錄目錄覆寫的環境變數名 |
| `DEFAULT_LOGS_DIR_NAME` | `"logs"` |
| static initializer(`PlatformPaths#<clinit>`,行 57-74) | 類別載入時檢查:System Property 與環境變數皆未設定時,自動把 `MYHELLO_DATA_DIR` 設為「專案根目錄 + data」絕對路徑、`MYHELLO_LOGS_DIR` 設為「專案根目錄 + logs」;任何例外都被吞掉(ignored),不阻斷啟動 |

#### 公開方法一覽

| 方法 | 簽名要點 | 解析優先序 / 行為 | 副作用 |
|------|----------|-------------------|--------|
| `findProjectRoot()` | → `Path` | 從 `user.dir` 起逐層向上找「含 `.git` 或(同時含 `pom.xml` 與 `distribution`)」的目錄;找不到則回傳 `user.dir` 本身 | 讀檔案系統(僅 exists 檢查) |
| `dataDirectory()` | → `Path` | ①環境變數 `MYHELLO_DATA_DIR` → ②System Property 同名 → ③`findProjectRoot()/data`;一律 `toAbsolutePath().normalize()` | 無(**不會**建立目錄) |
| `ensureDataDirectory()` | → `Path` | = `dataDirectory()` 後執行 `mkdirs()`;雙重檢查避免併發下 `mkdirs`/`exists` 競爭誤判 | 建立目錄;失敗拋 `UncheckedIOException` |
| `dataFile(String)` | fileName 為空拋 `IllegalArgumentException` | `dataDirectory().resolve(fileName)` | 不建目錄(需先呼叫 ensure 系列) |
| `logsDirectory()` | → `Path` | 與 `dataDirectory()` 對稱,改用 `MYHELLO_LOGS_DIR` / `logs` | 無 |
| `ensureLogsDirectory()` | → `Path` | 與 `ensureDataDirectory()` 對稱 | 建立目錄;失敗拋 `UncheckedIOException` |
| `logFile(String)` | fileName 為空拋 `IllegalArgumentException` | `logsDirectory().resolve(fileName)` | 不建目錄 |
| `sqliteUrl(String)` | → `String` | `jdbc:sqlite:<dataFile(fileName) 的絕對路徑>`;Linux 例 `jdbc:sqlite:/opt/app/data/reconciliation.db`,Windows 使用 `\` | 無 |
| `normalizeClasspath(String)` | → `String` | `\`→`/`、折疊連續 `//`、去頭尾 `/`;空白輸入回 `""`。Classloader 規格要求 classpath 內部用 `/` | 無 |
| `resolveOsNative(String, String...)` | → `Path` | 直接委派 `Paths.get(first, more)` 再 `toAbsolutePath().normalize()`,顯式表達 OS 原生分隔符意圖 | 無 |

#### 在其他模組的使用點

- `PlatformConfigSource`(platform-data-index)在建構子呼叫 `ensureDataDirectory()` / `ensureLogsDirectory()` 取得絕對路徑注入 MicroProfile Config(見 §3.2)。
- distribution 兩 app 的 `application.properties` 以 `${MYHELLO_DATA_DIR:data}` 形式消費同一變數,組出 `jdbc:sqlite:${MYHELLO_DATA_DIR:data}/reconciliation.db`(見 `platform-data-index/src/main/resources/application.properties:21`)。
- 相關部署模型請見 [../02-architecture/ARCHITECTURE.md](../02-architecture/ARCHITECTURE.md)。

---

## 2. platform-security

### 2.1 模組定位

Maven artifact `org.acme.platform:platform-security`,套件 `com.example.platform.security`,pom 描述:「橫切安全關注:OpenAPI 文件過濾、SonataFlow 安全設定、Response 統一解包。所有 distribution 模組都應依賴本模組,確保安全策略一致。」實際上兩個可執行應用(`distribution/transfer-app`、`distribution/reconciliation-app`)都在 pom 中宣告了此依賴,並在 `application.properties` 以 `mp.openapi.filter=com.example.platform.security.SonataFlowSecurityConfig$SwaggerFilter` 掛載 Swagger 過濾器。

成員三類:

| 成員 | 型別 | 掛載方式 |
|------|------|----------|
| `SonataFlowSecurityConfig$SwaggerFilter` | `OASFilter`(MicroProfile OpenAPI) | 兩 app 的 `mp.openapi.filter` 屬性,**已掛載** |
| `SonataFlowSecurityConfig$RuntimeFilter` | JAX-RS `ContainerRequestFilter`(`@Provider @ApplicationScoped @Priority(USER)`) | CDI + JAX-RS 自動發現 |
| `SonataFlowSecurityConfig$WorkflowStatusFilter` | JAX-RS `ContainerResponseFilter`(`@Provider @ApplicationScoped @Priority(USER - 10)`) | CDI + JAX-RS 自動發現 |
| `UnwrapResponseFilter` | JAX-RS `ContainerResponseFilter`(`@Provider @ApplicationScoped @Priority(USER)`) | CDI + JAX-RS 自動發現 |
| `OpenApiFilter` | `OASFilter` | **未掛載**(備援實作,全專案無任何 properties 引用) |

### 2.2 Request Pipeline 全景圖

JAX-RS request filter 以 priority **升序**執行,response filter 以 priority **降序**執行(數字大者先跑)。因此一次 POST 啟動 workflow 的完整順序是:

```mermaid
flowchart TB
    subgraph REQ["HTTP Request(POST /saga2-transfer-workflow)"]
        A[Client] --> B
        B["RuntimeFilter<br/>ContainerRequestFilter<br/>priority = USER (=2000)<br/>白名單檢查 → 非 POST 回 403<br/>POST:緩存 rawInputPayload + startTimeNano<br/>並以 ByteArrayInputStream 重設 entity stream"]
    end
    B --> C[JAX-RS Resource / SonataFlow 引擎執行]
    C --> D
    subgraph RESP["HTTP Response(priority 降序)"]
        D["UnwrapResponseFilter<br/>ContainerResponseFilter<br/>priority = USER (=2000) 先跑<br/>剝除 workflowdata 外殼、強制 200"]
        D --> E["WorkflowStatusFilter<br/>ContainerResponseFilter<br/>priority = USER - 10 (=1990) 刻意後跑<br/>status→HTTP 改寫(覆蓋 Unwrap 的 200)<br/>輸出 [HTTP-AUDIT] 日誌"]
    end
    E --> F[Client 收到最終回應]
```

順序的關鍵設計(`SonataFlowSecurityConfig` 行 86-88 的註解原文):response filter 以 priority 「降序」執行;`WorkflowStatusFilter`(USER − 10)**刻意排在** `UnwrapResponseFilter`(USER)「之後」執行,以取得解包後的最終 entity,並讓改寫的狀態碼覆蓋 Unwrap 強制設定的 200。若兩者 priority 相同或顛倒,status-rewrite 會讀到尚未解包的外殼(找不到 `status` 欄位)且改寫會被 Unwrap 的 200 蓋掉。

### 2.3 Filter 行為總表

| Filter(類別#方法) | 階段 / Priority | 觸發條件 | 白名單(跳過處理) | 副作用 | 日誌輸出 |
|---|---|---|---|---|---|
| `RuntimeFilter#filter` | Request / `USER`(2000) | 所有 HTTP 請求 | path 去前導 `/` 後:`startsWith("q/")`、`.html` / `.js` / `.css` / `.ico` 結尾、**包含** `reconciliation` / `specs` / `instances` / `jobs` / `trace` 子字串者直接 return(不擋、也不緩存 payload) | ①非 POST → `abortWith(403)`,body 固定 `{"error": "Only POST method is allowed"}`;②POST → 讀光 entity stream、以 UTF-8 存成 `rawInputPayload` property、`System.nanoTime()` 存 `startTimeNano` property,再用 `ByteArrayInputStream(bytes)` 重設 stream 供引擎反序列化 | 無(靜默) |
| `UnwrapResponseFilter#filter` | Response / `USER`(2000) | 所有帶非 null entity 的回應 | entity == null(如 204)直接 return | 若 entity 含 `workflowdata`:把 entity 替換為該子物件並強制 `setStatus(200)`;Map / JsonNode / POJO 三型別相容(見 §2.4) | 無 |
| `WorkflowStatusFilter#filter` | Response / `USER - 10`(1990) | 僅 **POST** 請求的回應(`GET` 狀態查詢、`DELETE` 取消不適用);path 去前導 `/` 前 `startsWith("q/")` 也跳過 | 同左(q/ 與非 POST) | ①路徑第一段命中 `platform.status-rewrite.workflows` 名單時,讀取 `status`(或 `workflowdata.status`)查 `platform.status-rewrite.mapping`,`setStatus(rewrite)`;②組裝 `[HTTP-AUDIT]` 完整稽核日誌 | 見 §2.5 |

補充細節:

- RuntimeFilter 的白名單比對用的是 `contains`,所以任何 URI 只要**含有** `reconciliation`、`specs`、`instances`、`jobs`、`trace` 任一子字串即繞過 POST-only 限制——這同時代表這些路徑**不會**被緩存 input payload,也就不會出現在 `[HTTP-AUDIT]` 的 INPUT 欄位。
- WorkflowStatusFilter 內也做了與 RuntimeFilter 相同的去前導斜線正規化(RESTEasy Reactive 的 `getPath()` 含前導 `/`,不去掉的話後續 `startsWith` 前綴比對永遠失敗;見 `SonataFlowSecurityConfig#filter` 行 159-163 的註解)。

### 2.4 UnwrapResponseFilter — 三型別相容剝殼

Kogito/SonataFlow 生成的 REST 回應預設包裝為:

```json
{
  "id": "12345-abcde",
  "workflowdata": { "greeting": "Hello, John!", "...": "..." }
}
```

`UnwrapResponseFilter`(`UnwrapResponseFilter.java`)攔截所有傳出回應,依 entity 實際型別走三分支:

| 分支(#filter 內判斷) | 判斷條件 | 處理 |
|---|---|---|
| 1. Map | `entity instanceof Map` 且 `containsKey("workflowdata")` | `setEntity(map.get("workflowdata"))` + `setStatus(200)` |
| 2. JsonNode | `entity instanceof JsonNode` 且 `has("workflowdata")` | `setEntity(node.get("workflowdata"))` + `setStatus(200)` |
| 3. POJO / 其他 | 嘗試注入之 `ObjectMapper.valueToTree(entity)` 後 `has("workflowdata")` | 提取節點 + `setStatus(200)`;轉換例外被忽略、保持原 entity |

注意:三分支只要成功剝殼就**一律強制 200**;真正的業務失敗語意由排在後面的 `WorkflowStatusFilter` 依 status 欄位改寫(400/409),這正是 §2.2 所述 priority 安排的原因。

### 2.5 WorkflowStatusFilter — 配置化狀態碼改寫 + HTTP-AUDIT

#### 配置鍵(SonataFlowSecurityConfig 行 99-112)

| 配置鍵 | 預設值 | 意義 |
|--------|--------|------|
| `platform.status-rewrite.workflows` | `saga2-transfer-workflow` | 啟用改寫的 workflow 名單(逗號分隔;比對目標=URI 路徑第一段) |
| `platform.status-rewrite.mapping` | `VALIDATION_FAILED=400,ROLLBACK_FAILED=409` | status→HTTP 映射(格式 `STATUS=CODE`,逗號分隔) |

`#init`(`@PostConstruct`)解析兩鍵:名單去空白後存入不可變 `LinkedHashSet`;映射逐條 `split("=", 2)`,格式錯誤或非整數者記 WARN 並略過。啟動時輸出一條 INFO:`[WorkflowStatusFilter] 已載入配置: workflows=..., mapping=...`。

未列在 mapping 的 status(`SUCCESS` / `FAILED` / `ROLLED_BACK`)保持引擎原狀態碼(200)。此機制的行為語意另見 [../02-architecture/OBSERVABILITY.md](../02-architecture/OBSERVABILITY.md);參數清單見 [../04-reference/CONFIG-REFERENCE.md](../04-reference/CONFIG-REFERENCE.md)。

#### entity 正規化(#normalizeEntityToMap)

與 `UnwrapResponseFilter` 三分支呼應但更寬容:Map 直接回;String 且 trim 後以 `{` 開頭才嘗試 `MAPPER.readValue(s, Map.class)`;其餘型別走 `MAPPER.convertValue(entity, Map.class)`。全部失敗回 null(跳過改寫但仍會記 audit)。status 取值順位:頂層 `status` → 頂層沒有時改抓 `workflowdata` 子 Map 的 `status`。

#### `[HTTP-AUDIT]` 日誌格式全文

```
[HTTP-AUDIT] URI: %s | HTTP: %d | Cost: %dms | INPUT: %s | OUTPUT: %s
```

| 欄位 | 來源 |
|------|------|
| `URI` | 正規化後 path(確保以 `/` 開頭顯示) |
| `HTTP` | **最終**(可能已被本 filter 改寫)的狀態碼 |
| `Cost` | `(System.nanoTime() - startTimeNano) / 1_000_000` ms;property 缺失時為 0 |
| `INPUT` | RuntimeFilter 緩存的 `rawInputPayload`;缺失時 `{}`;兩 payload 都會 `replaceAll("\\s+", " ").trim()` 折疊空白 |
| `OUTPUT` | response entity:String 直接用,否則 Jackson 序列化;序列化失敗 fallback `String.valueOf(entity)`;null 時 `{}` |

### 2.6 SwaggerFilter(已掛載)與 OpenApiFilter(備援未掛)

| 類別 | 移除的 HTTP 方法 | 掛載狀態 |
|------|------------------|----------|
| `SonataFlowSecurityConfig$SwaggerFilter#filterPathItem` | DELETE、PUT、PATCH、HEAD(**保留 GET**) | 已掛載:兩 app `application.properties` 的 `mp.openapi.filter` |
| `OpenApiFilter#filterPathItem` | GET、DELETE、PUT、PATCH、HEAD(**只留 POST**,與平台「POST-only」原則一致) | 未掛載:全專案無任何配置引用,屬備援實作 |

也就是說目前 Swagger UI 上仍看得到 GET 端點(對帳查詢等),但文件中不會出現四個被禁的方法;若日後想讓 OpenAPI 文件完全反映 RuntimeFilter 的 POST-only 策略,把 `mp.openapi.filter` 換成 `...security.OpenApiFilter` 即可。

---

## 3. platform-data-index

### 3.1 模組定位

Maven artifact `org.acme.platform:platform-data-index`,套件 `org.acme.platform.dataindex`。pom 描述列出三大職責:①自訂 `KogitoSQLiteDialect` 解決 ZonedDateTime 解析問題;②`SqliteZonedDateTimeJdbcType` 處理 Unix epoch ms 字串;③統一 Liveness 健康檢查。此外還承載 `PlatformConfigSource` 與 `NodeTracingProcessEventListener`。任何需要 Kogito Data Index 的 distribution 模組都應依賴本模組。

模組自帶一份 `src/main/resources/application.properties`(基礎設定,distribution 可覆寫),內容重點:

- `quarkus.datasource.db-kind=other`(Quarkus 3.27.x 沒有內建 sqlite db-kind)+ `jdbc.driver=org.sqlite.JDBC`;
- `jdbc.url=jdbc:sqlite:${MYHELLO_DATA_DIR:data}/reconciliation.db`;
- `additional-jdbc-properties`:`foreign_keys=true`、`journal_mode=WAL`、`synchronous=NORMAL`;
- `quarkus.hibernate-orm.dialect=org.acme.platform.dataindex.KogitoSQLiteDialect`(**Dialect 掛載點**);
- Hibernate schema validation 全關(`database.generation=none` 等)——Flyway 才是 schema 唯一來源,Hibernate 6.x 對 xerial driver 的欄位 metadata 解析會誤拋 `NoSuchElementException`;
- `kie.flyway.enabled=true`、OIDC 全關、GraphQL UI always-include、`kogito.data-index.blocking=true`。

完整參數說明見 [../04-reference/CONFIG-REFERENCE.md](../04-reference/CONFIG-REFERENCE.md)。

### 3.2 PlatformConfigSource — ordinal 250 的自動路徑注入

`PlatformConfigSource implements ConfigSource`(MicroProfile Config SPI),透過 ServiceLoader 註冊於 `META-INF/services/org.eclipse.microprofile.config.spi.ConfigSource`。

| 成員 | 行為 |
|------|------|
| 建構子 #`<init>` | 呼叫 `PlatformPaths.ensureDataDirectory()` / `ensureLogsDirectory()` 取得絕對路徑,放進內部 map,key 分別為 `PlatformPaths.DATA_DIR_ENV`(`MYHELLO_DATA_DIR`)與 `LOGS_DIR_ENV`(`MYHELLO_LOGS_DIR`);建目錄因權限失敗時**吞掉例外**優雅降級 |
| #`getOrdinal` | 固定回 **250**:高於 application.properties(ordinal 100)的預設 fallback,低於 OS 環境變數(300)與 `-D` JVM 參數(400),保留外部覆寫能力 |
| #`getProperties` / #`getPropertyNames` / #`getValue` | 直讀內部 map |
| #`getName` | `"PlatformConfigSource"` |

效果:Quarkus 在載入配置、初始化 DataSource **之前**就已保證 `data/`、`logs/` 目錄存在,且 `${MYHELLO_DATA_DIR:data}` 佔位符永遠有值——這是「雙 app 共享單一 reconciliation.db」部署模型能開箱即用的前置條件(見 [../02-architecture/ARCHITECTURE.md](../02-architecture/ARCHITECTURE.md))。

### 3.3 SQLite timestamp 修補原理(epoch ms 字串問題)

#### 問題本質

Kogito Data Index 的 SQLite 持久化把時間戳存成 **TEXT 欄位裡的 Unix epoch 毫秒數字字串**(例:`"1786185258763"`)。而 Hibernate ORM 6+ 預設的 `ZonedDateTime` JavaType/JdbcType 只認 ISO-8601 字串,讀到純數字字串時拋出 `DateTimeParseException`("Error parsing time stamp"),導致 GraphQL ProcessInstances 查詢的 timestamp 解析炸掉(KogitoSQLiteDialect Javadoc 所述 issue #9)。

#### 修補的三層結構

**第 1 層:`SqliteZonedDateTimeJdbcType`**(platform-data-index 與 platform-extensions runtime 各有一份等價實作,見 §4.3)。

| 方法 | 行為 |
|------|------|
| #`getJdbcTypeCode` | 回 `Types.VARCHAR` —— 把 ZonedDateTime 綁定到 TEXT |
| #`getBinder`(BasicBinder.doBind) | 寫入方向:`ZonedDateTime` → `toInstant().toEpochMilli()` 的十進位字串(`st.setString`);非 null 非 ZonedDateTime → `value.toString()`;null → `setNull(VARCHAR)`。PreparedStatement 與 CallableStatement 兩條路徑都有實作 |
| #`getExtractor`(BasicExtractor.doExtract) | 讀取方向:`rs.getString(...)` 後交給 #`parseValue` |
| #`parseValue` | **先試** `Long.parseLong(str)` → `Instant.ofEpochMilli(epochMs).atZone(ZoneId.systemDefault())`(epoch ms 數字字串);`NumberFormatException` **再退** `ZonedDateTime.parse(str)`(ISO-8601);兩者皆失敗回 null 不拋例外。目標 Java 型別就是 `ZonedDateTime` 時直接 cast,否則 `javaType.wrap(zdt, options)` |

**第 2 層:`KogitoSQLiteDialect extends org.hibernate.community.dialect.SQLiteDialect`**(`KogitoSQLiteDialect.java`)。

覆寫 `contributeTypes(TypeContributions, ServiceRegistry)`:先 `super.contributeTypes(...)`,然後:

1. `contributeJdbcType(SqliteZonedDateTimeJdbcType.INSTANCE)`;
2. `contributeJavaType(SqliteZonedDateTimeJavaType.INSTANCE)`(來自 platform-extensions runtime,見 §4.3);
3. 額外組裝一個 `BasicTypeImpl<ZonedDateTime>`(Java 側=`SqliteZonedDateTimeJavaType`、JDBC 側=`SqliteZonedDateTimeJdbcType`),以三個註冊名貢獻進 type registry:`"zdt"`、`"ZonedDateTime"`、`java.time.ZonedDateTime` 的 FQN。

如此一來 Hibernate Metadata 建構階段就把 `ZonedDateTime ↔ TEXT` 的雙向轉換換成了 epoch-ms 相容版。掛載方式即 §3.1 的 `quarkus.hibernate-orm.dialect` 屬性——不需要程式碼引用,純配置生效。

**第 3 層(runtime 備援,platform-extensions):`SqliteZonedDateTimeIntegrationListener`**(§4.3)。它在 Hibernate Metadata 初始化後,把自訂 JavaType 註冊進 `TypeConfiguration.getJavaTypeRegistry().addDescriptor(...)`,並以反射清空目標 kogito entities(`ProcessInstanceEntity` / `UserTaskEntity` / `JobEntity`)上所有 ZonedDateTime 屬性的 `SimpleValue.type` 快取,迫使下次 `getType()` 重新解析、吃到新 JavaType。原理:`BasicExtractor#doExtract` 最終呼叫 `javaType.wrap(rs.getString(col), options)`,只要 wrap 能吃數字字串,讀取就成功。

#### 修補前後對照

| 情境 | 未修補(Hibernate 預設) | 修補後(JdbcType+Dialect) |
|------|--------------------------|----------------------------|
| 寫入 `start_date` 等 TEXT 欄 | ISO-8601 字串(與 kogito 寫入的 epoch ms 格式不一致) | epoch-ms 十進位字串 |
| 讀取 `"1786185258763"` | `DateTimeParseException: Error parsing time stamp` | `Instant.ofEpochMilli` + system zone → `ZonedDateTime` |
| 讀取 ISO-8601 字串 | 正常 | fallback `ZonedDateTime.parse`,正常 |
| GraphQL ProcessInstances 查詢 | timestamp 欄位炸掉 | 正常回傳 |

### 3.4 MyLivenessCheck

```java
@Liveness
public class MyLivenessCheck implements HealthCheck {
    public HealthCheckResponse call() { return HealthCheckResponse.up("alive"); }
}
```

MicroProfile Health 的 Liveness 探針,名稱固定 `alive`、恆 UP。搭配 `platform-data-index/application.properties` 的 `quarkus.smallrye-health.management.enabled=false`(management endpoint 關閉,只用一般 health)。掛載依賴為 pom 內的 `quarkus-smallrye-health`。

### 3.5 NodeTracingProcessEventListener — 全節點 I/O 軌跡

`@ApplicationScoped @Unremovable`,繼承 `DefaultKogitoProcessEventListener`。`@Unremovable` 確保即使無明確 injection point 也不被 Arc 移除——Kogito 引擎會自動收集容器內所有 `ProcessEventListener` bean。目的:確保 nodes 資料表(reconciliation.db)中所有節點(Split、ActionNode、StartNode、EndNode、WorkItemNode、CompositeContextNode、Join 等)都有完整 I/O 與錯誤紀錄。

metadata 鍵常數:`inputArgs` / `outputArgs` / `errorMessage`;流程變數偏好鍵:`workflowdata`。

#### 事件表

| 事件(#方法) | 觸發時機 | 擷取內容 | 寫入位置 | 失敗處理 |
|---|---|---|---|---|
| `beforeNodeTriggered(ProcessNodeTriggeredEvent)` | 進入任一節點前 | WorkItem 節點→`workItem.getParameters()`(非空才採用);否則流程變數 snapshot(優先 `workflowdata`) | `nodeInstance.getMetaData()["inputArgs"]`(僅在尚未存在時寫入,避免覆蓋) | try/catch 全包,WARN `Failed to capture inputArgs for node ...` |
| `beforeNodeLeft(ProcessNodeLeftEvent)` | 離開任一節點前 | WorkItem 節點→`workItem.getResults()`;否則同上 snapshot | `metaData["outputArgs"]`(同樣只在缺值時寫) | WARN `Failed to capture outputArgs for node ...` |
| `onError(ErrorEvent)` | 流程錯誤事件 | `pi.getErrorMessage()`;null 時取 `pi.getErrorCause()` 的 message/toString;再 null 用 `"Process execution error"` | `metaData["errorMessage"]`;若 `outputArgs` 尚空,補一個 `{"error": <msg>}` | WARN `Failed to record error_message on error event` |

snapshot 工具 `#snapshotValue`:`JsonNode` 直接 `deepCopy()`;一般物件用注入的 `ObjectMapper.valueToTree`(mapper 注入失敗時有 private fallback mapper);序列化失敗的 Map 退化為 `new LinkedHashMap<>(map)`,其他型別原值返回。`#extractProcessStateSnapshot` 只處理 `KogitoProcessInstance`,變數含 `workflowdata` 時只拍 workflowdata,否則拍整包變數。

這些軌跡最終經 Data Index 落到 nodes 表的 `input_args` / `output_args` 欄(Flyway 腳本 `V1.48.0__add_input_output_args.sql` 提供),供 GraphQL 與 OPS-ALERT 分析使用,詳見 [../02-architecture/OBSERVABILITY.md](../02-architecture/OBSERVABILITY.md)。

---

## 4. platform-extensions

### 4.1 模組群結構

`platform-extensions` 是 `<packaging>pom</packaging>` 的聚合模組(parent 仍是 `org.acme.platform:myhello-platform`),聚合三個**移植自上游 Kogito 10.2.0 並本地修補**的子模組(pom 屬性:`enforcer.skip=true`):

| 子模組 | 上游 parent | 性質 | 內容 |
|--------|-------------|------|------|
| `data-index-storage-sqlite` | `org.kie.kogito:data-index-storage:10.2.0` | 普通 jar(非 Quarkus extension) | SQL 函式、predicate builder、capability provider、Flyway SQLite 腳本 |
| `kogito-addons-quarkus-data-index-sqlite` | `org.kie:kogito-addons-quarkus-data-index:10.2.0` | Quarkus extension(parent+runtime+deployment) | DevUI/feature 註冊、kogito.apps.persistence 設定根、ZonedDateTime runtime 型別 |
| `kogito-addons-quarkus-data-index-persistence-sqlite` | `org.kie:kogito-addons-quarkus-data-index-persistence:10.2.0` | Quarkus extension(parent+runtime+deployment) | persistence 佔位(runtime 無 Java 程式碼)、native resources 註冊 |

#### runtime/deployment 雙層結構解說

Quarkus extension 的標準兩層式打包:

- **runtime jar**:隨應用一起跑的類別與資源(application.properties 預設值、CDI bean、Hibernate 型別…)。runtime pom 以 `quarkus-extension-maven-plugin` 的 `extension-descriptor` goal 產生 extension descriptor,宣告 `<deployment>` 座標與 capability(provides),例如 sqlite addon runtime 提供 `org.kie.kogito.data-index`、persistence-sqlite runtime 提供 `org.kie.kogito.data-index.persistence`。
- **deployment jar**:只在 `mvn quarkus:build` / dev mode 的 **augmentation(build-time)階段**執行,內含 `@BuildStep` 處理器,負責 feature 註冊、DevUI 卡片、設定根發現、native-image resource 收集等;不會進入最終 runtime classpath。

依賴鏈(runtime 側):`kogito-addons-quarkus-data-index-sqlite(runtime)` → `kogito-addons-quarkus-data-index-persistence-sqlite(runtime)` → `data-index-storage-sqlite` + `quarkus-flyway` + `kie-addons-quarkus-flyway` + `sqlite-jdbc` + `quarkus-hibernate-orm`。deployment 側對稱地依賴各自的 common-deployment 與 `-deployment` 版本。兩個 Quarkus extension 的 runtime 都附帶同名 `application.properties`,統一聲明:`kogito.apps.persistence.type=sqlite`、`quarkus.datasource.db-kind=sqlite`、`quarkus.hibernate-orm.jdbc.timezone=UTC`、`physical-naming-strategy=CamelCaseToUnderscoresNamingStrategy`。

> 注意:persistence-sqlite deployment pom 特別註明「`io.quarkus:quarkus-jdbc-sqlite-deployment` 在上游 Quarkus 不存在;SQLite JDBC 由 xerial driver 於 runtime classpath 提供,不需 deployment 對應物」。persistence-sqlite runtime pom 亦註明「Flyway 10+(Quarkus 3.27.x)已將 SQLite support 併入 flyway-core,不需額外 flyway-sqlite artifact」。

### 4.2 data-index-storage-sqlite — SQL 能力層

#### ContainsSQLFunction — JSON CONTAINS 三函式

繼承 Hibernate `StandardSQLFunction`,以 SQLite JSON1 擴展(`json_each` / `json_array` / `json_valid`)渲染等效於 PostgreSQL `jsonb @> / ?& / ?|` 的 SQL 片段。函式名常數:`CONTAINS_NAME="contains"`、`CONTAINS_ALL_NAME="containsAll"`、`CONTAINS_ANY_NAME="containsAny"`;建構子第二參數 `all` 區分 containsAll(true)與其他(false);回傳型別 `boolean(SqlTypes.BOOLEAN)`。

`#render(SqlAppender, args, returnType, translator)` 的渲染規則(參數少於 2 個拋 `IllegalArgumentException`;第一參數=JSON 文件欄位,會在每個 EXISTS 內重複 inline,SQLite 下安全):

| 函式 | 參數形態 | 渲染出的 SQL 形狀 |
|------|----------|--------------------|
| `contains(j, v)` | 2 個參數 | `(json_valid(j)=1 AND EXISTS (SELECT 1 FROM json_each(j) AS doc INNER JOIN json_each(json_array(v)) AS arr ON CAST(doc.value AS TEXT)=CAST(arr.value AS TEXT)))` |
| `containsAny(j, v1, v2, …)` | ≥3 參數且 all=false | 同上(INNER JOIN json_array 多值,OR 語意由 JOIN 天然達成) |
| `containsAll(j, v1, v2, …)` | ≥3 參數且 all=true | 各值的 EXISTS 檢查用 `AND` 串接:每值一段 `(json_valid(j)=1 AND EXISTS (SELECT 1 FROM json_each(j) AS doc WHERE CAST(doc.value AS TEXT)=CAST(vN AS TEXT)))` |

所有比較都以 `CAST(... AS TEXT)` 對齊型別(SQLite dynamic typing)。需求:SQLite 3.38+ 的 JSON1;Quarkus 綁定的 sqlite-jdbc 3.40+ 恆滿足。

#### CustomFunctionsContributor

`implements FunctionContributor`(Hibernate Boot SPI),`#contributeFunctions` 向 `SqmFunctionRegistry` 註冊三個函式:`contains`、`containsAny`(all=false)與 `containsAll`(all=true)。函式名刻意與 PostgreSQL 對應物相同,讓 JPA predicate builder 保持 dialect 無關。註冊途徑為 ServiceLoader:`META-INF/services/org.hibernate.boot.model.FunctionContributor` 檔案內容一行 `org.kie.kogito.index.sqlite.CustomFunctionsContributor`。

#### SQLiteJsonPredicateBuilder

`@ApplicationScoped`(jar 內附空的 `META-INF/beans.xml` 使 CDI 可發現),實作 `org.kie.kogito.index.jpa.storage.JsonPredicateBuilder`——`PostgresqlJsonPredicateBuilder` 的 SQLite 對應物。JSON 值存於 TEXT 欄,path 存取用內建 `json_extract(col, '$.k1.k2')`。

`#buildPredicate(AttributeFilter, Root, CriteriaBuilder)` 支援的 condition 全表:

| Condition | 產生的 predicate 要點 |
|-----------|------------------------|
| EQUAL / GT / GTE / LT / LTE | `json_extract(path expr)` 與比較值;值是否為 String 決定 literal 或 `CAST(literal AS TEXT)` |
| LIKE | `builder.like(json_extract(...), value.toString().replaceAll("\\*", "%"))`(`*` 轉 `%`) |
| IS_NULL / NOT_NULL | `isNull` / `isNotNull`(isString=false 版本的 path expression) |
| BETWEEN | 以 values[0] 是否 String 決定型別,`between(lo, hi)` |
| IN | path expression `.in(...)` |
| CONTAINS | `builder.isTrue(builder.function("contains", Boolean.class, pathExpr, literal(value)))` |
| CONTAINS_ANY / CONTAINS_ALL | `#containsPredicate`:函式名帶入,第一參數 pathExpr、其餘為各值 literal,外面包 `isTrue` |
| 其他 | 拋 `UnsupportedOperationException` |

`#buildPathExpression` 的路徑解析:attribute 以 `.` 切分;單段→直接 `root.get(attr)`(實體欄位);多段→先嘗試把第一段當 join(`root.join` 失敗會拋 `PersistenceException`,catch 後改視第一段為 JSON 欄位),剩餘段拼成 `'$.a.b.c'` 單一字串參數交給 `json_extract`。

#### SQLiteStorageServiceCapabilities

`implements StorageServiceCapabilityProvider`,`#capabilities` 回 `Set.of(StorageServiceCapability.JSON_QUERY)`——向 kogito persistence-api 宣告本儲存支援 JSON path 查詢(等同 PostgreSQL provider 的宣告)。ServiceLoader 註冊:`META-INF/services/org.kie.kogito.persistence.api.StorageServiceCapabilityProvider`。

#### Flyway 腳本與 kie-flyway.properties 註冊

腳本位置:`src/main/resources/kie-flyway/db/data-index/sqlite/`,由 `META-INF/kie-flyway.properties` 向 KIE 的 flyway 機制註冊:

```properties
module.name=data-index
module.locations.sqlite=classpath:kie-flyway/db/data-index/sqlite
```

即「module=data-index」宣告自己有一組 sqlite location;`kie-addons-quarkus-flyway`(persistence-sqlite runtime 依賴)會在啟動時把 `module.locations.<dbKind>` 指到的 classpath 目錄併入 Flyway migration 掃描,配合 `platform-data-index/application.properties` 的 `kie.flyway.enabled=true` 生效。收錄腳本(版本遞增):

`V1.32.0__data_index_create.sql`、`V1.44.0__data_index_definitions.sql`、`V1.45.0.0__data_index_node_definitions.sql`、`V1.45.0.1__add_identity_to_process_instance.sql`、`V1.45.0.2__data_index_definitions_add_columns.sql`、`V1.45.0.3__add_fk_index.sql`、`V1.45.0.4__increase_varchar_length.sql`、`V1.45.0.5__add_external_reference_id.sql`、`V1.45.0.6__add_sla_due_date_columns.sql`、`V1.45.0.7__add_sla_due_date_tasks.sql`、`V1.45.0.8__modify_columns_with_reserved_words.sql`、`V1.45.0.9__increase_comments_content_size.sql`、`V1.45.1.0__metadata_as_jsonb.sql`、`V1.45.1.1__retrigger.sql`、`V1.45.1.2__cloudevent.sql`、`V1.45.1.3__add_cancelled_type_nodes.sql`、`V1.45.1.4__add_indexes_for_jobs_and_tasks.sql`、`V1.46.0__add_user_task_id_column.sql`、`V1.47.0__adjust_column_sizes_in_tables_updated_by_hibernate.sql`、`V1.48.0__add_input_output_args.sql`、`V1.49.0__add_job_exception_details.sql`、`V1.50.0__definitions_upsert_trigger.sql`。

`readme.txt` 記錄 PG→SQLite 型別對映(`bytea`→BLOB、`jsonb`/`varchar(n)`/`timestamp`→TEXT、`int4/int8`→INTEGER、`boolean`→INTEGER 0/1)、善用 `CREATE TABLE IF NOT EXISTS`、`ALTER TABLE DROP CONSTRAINT` 不支援(FK 需 inline 宣告 + 每連線 `PRAGMA foreign_keys=ON`)、需 SQLite 3.38+ JSON1;並警告新增 migration 的版本不得與 persistence-commons-sqlite 衝突。表級 schema 全景見 [../04-reference/DATABASE-REFERENCE.md](../04-reference/DATABASE-REFERENCE.md)。

### 4.3 kogito-addons-quarkus-data-index-sqlite — 主 addon(runtime/deployment)

#### deployment 層(三個 processor)

| 類別 | Build step | 職責 |
|------|-----------|------|
| `SQLiteDataIndexProcessor extends AbstractKogitoAddonsQuarkusDataIndexProcessor` | `#feature()` → `FeatureBuildItem("kogito-addons-quarkus-data-index-sqlite")` | 註冊 extension feature flag(與 PostgreSQLDataIndexProcessor 幾乎逐字相同的 SQLite 對應物) |
| 同上 | `#createDevUILink(...)`(`onlyIf = IsDevelopment.class`) | dev mode 的 DevUI 卡片:external page 「Data Index GraphQL UI」指向 `/q/graphql-ui/` |
| `KogitoAppsPersistenceConfig` | 非processor,而是 `@ConfigRoot(phase = BUILD_TIME)` + `@ConfigMapping(prefix = "kogito.apps.persistence")` 介面 | 把 `kogito.apps.persistence.type` 登記為「已知」配置鍵,消除每次啟動 `Unrecognized configuration key kogito.apps.persistence.type` 警告。`#type()` 以 `@WithName("type")` 映射、`@WithDefault("sqlite")` 預設;合法值 inmemory/postgresql/mongodb/sqlite。實際消費者是 runtime 的 `org.kie.kogito.persistence.api.factory.*`(經 Constants.PERSISTENCE_TYPE_PROPERTY 讀取) |
| `SqliteZonedDateTimeIntegrationProcessor` | `#register()` 本應產生 `HibernateOrmIntegrationStaticConfiguredBuildItem`,但 `@BuildStep` 已被**註解停用**(防 bootstrap/reflection 風險),方法回 null | 目前是**死代碼**:實驗性 reflection listener 的入口保留但不生效 |

> 因此 §3.3 的第 3 層(`SqliteZonedDateTimeIntegrationListener`)**目前不會被觸發**;實際修補主力是 `KogitoSQLiteDialect`(配置掛載)。閱讀原始碼時勿被 listener 的存在誤導。

#### runtime 層 — SqliteZonedDateTime* 家族

| 類別 | 角色 | 重點方法/行為 |
|------|------|---------------|
| `SqliteZonedDateTimeJdbcType`(runtime 版,與 platform-data-index 版等價) | Hibernate 6 `JdbcType` | `getJdbcTypeCode`=VARCHAR;binder 寫 epoch-ms 字串;extractor 讀字串後 parseValue(Long.parseLong → epoch ms,否則 ISO-8601,皆敗回 null) |
| `SqliteZonedDateTimeJavaType` | Hibernate `JavaType<ZonedDateTime>` | `#unwrap`:支援 Instant / OffsetDateTime / LocalDateTime / Long(epoch ms)/ Timestamp / Date / String(epoch-ms 字串);`#wrap`:反向支援上述全部,其中 String 先 `Long.parseLong` 試 epoch ms、失敗才 `#parseIso`;`#fromString` 走 ISO;`#getRecommendedJdbcType` 回自訂 JdbcType;mutability=Immutable;comparator=natural order |
| `SqliteZonedDateTimeUserType` | Hibernate legacy `UserType<ZonedDateTime>` | `getSqlType`=BIGINT;`#nullSafeGet` 讀 long(0 或 wasNull → null)轉 system-zone ZonedDateTime;`#nullSafeSet` 寫 `setLong(epochMs)`;`#disassemble`/`#assemble` 以 Long epoch ms 序列化。Javadoc 說明選 UserType 的原因:Hibernate 7 沒有 `SimpleValue.setJdbcType`,JdbcType 在 metadata-build 期鎖定,UserType 是可在 runtime 整體替換型別的高階抽象 |
| `SqliteZonedDateTimeIntegrationListener` | `HibernateOrmIntegrationStaticInitListener` | `#onMetadataInitialized`:①`typeConfig.getJavaTypeRegistry().addDescriptor(new SqliteZonedDateTimeJavaType())`;②遍歷 `metadata.getEntityBindings()`,只處理 TARGET_ENTITIES(ProcessInstanceEntity/UserTaskInstanceEntity… 正名:`ProcessInstanceEntity`、`UserTaskEntity`、`JobEntity`)中回傳型別為 ZonedDateTime 的屬性,反射清空 `SimpleValue.type` 快取(cleared 計數與逐筆 INFO 日誌)。**目前因 deployment processor 停用而不會掛載** |

### 4.4 kogito-addons-quarkus-data-index-persistence-sqlite — persistence 佔位 addon

| 層 | 內容 |
|----|------|
| runtime | **無任何 Java 原始碼**;只有 `application.properties`(`kogito.apps.persistence.type=sqlite`、db-kind=sqlite、hibernate timezone/naming strategy)與 `META-INF/quarkus-extension.yaml`(name: Kogito Data Index Persistence SQLite Quarkus Add-On,description 強調 embedded SQLite colocate 模式,status stable)。它的價值在於把正確的 datasource/Hibernate 預設值與 `data-index-storage-sqlite`、flyway 依賴「捆」成一個可宣告的 extension |
| deployment | 唯一類別 `SQLiteDataIndexPersistenceProcessor extends AbstractKogitoAddonsQuarkusDataIndexPersistenceProcessor`:`#feature()` 註冊 `FeatureBuildItem("kogito-addons-quarkus-data-index-persistence-sqlite")`;`#addNativeResources`(`onlyIf = NativeOrNativeSourcesBuild.class`)把 `sql/*.sql` glob 加入 native image resources(與其他方言 parity;SQLite 一般不做 native 生產部署) |

deployment processor 的共同職責總結:在 augmentation 階段(1)登記 feature flag 讓 build 報告/health 可見,(2)注入 DevUI 卡片(dev 模式),(3)註冊 build-time config root 消除警告,(4)為 native build 收集資源——全部都是「建置期副作用」,不含任何 runtime 邏輯;runtime 邏輯(CDI bean、Hibernate 型別、application.properties 預設)全部放在 runtime jar。

---

## 5. pom 關鍵依賴表

### 5.1 platform-common

| 依賴 | scope | 備註 |
|------|-------|------|
| (無) | — | `<dependencies>` 空,純 Java;這是模組的存在理由 |

### 5.2 platform-security

| 依賴 | scope | 用途 |
|------|-------|------|
| `org.acme.platform:platform-common` | compile | 模組間基礎依賴 |
| `io.quarkus:quarkus-arc` | compile | CDI(@ApplicationScoped provider 註冊) |
| `io.quarkus:quarkus-resteasy` | compile | JAX-RS Container{Request,Response}Filter API |
| `io.quarkus:quarkus-resteasy-jackson` | compile | ObjectMapper 整合 |
| `io.quarkus:quarkus-smallrye-openapi` | compile | OASFilter 掛載機制(mp.openapi.filter) |
| `org.eclipse.microprofile.openapi:microprofile-openapi-api` | compile | `OASFilter` / `PathItem` API |

### 5.3 platform-data-index

| 依賴 | scope | 用途 |
|------|-------|------|
| `org.acme.platform:platform-common` | compile | `PlatformPaths`(PlatformConfigSource 使用) |
| `io.quarkus:quarkus-arc` | compile | CDI(listener bean) |
| `io.quarkus:quarkus-smallrye-health` | compile | `MyLivenessCheck` |
| `org.xerial:sqlite-jdbc` | compile | SQLite JDBC driver |
| `org.hibernate.orm:hibernate-community-dialects` | compile | `SQLiteDialect` 基底類 |
| `org.kie:kogito-addons-quarkus-data-index-sqlite`(`${kie.version}`) | compile | **本地修補過的 Kogito SQLite addon**(pom 註記:需先在環境內 `mvn install kogito-sqlite-modules-10.2.0-patched`);提供 runtime 的 SqliteZonedDateTime* 類 |
| `org.apache.kie.sonataflow:sonataflow-quarkus` | compile | SonataFlow 引擎 API(ProcessEventListener 等) |

### 5.4 platform-extensions(聚合 pom)

packaging=pom;properties:`enforcer.skip=true`、`version.io.quarkus=${quarkus.platform.version}`;modules 如 §4.1。

| 子模組 | 關鍵依賴 |
|--------|----------|
| `data-index-storage-sqlite`(parent=`org.kie.kogito:data-index-storage:10.2.0`) | `data-index-storage-jpa-common`(JsonPredicateBuilder/Storage API);test:`hibernate-ant`;resources:FunctionContributor 與 StorageServiceCapabilityProvider service 檔、beans.xml、kie-flyway 腳本 |
| `kogito-addons-quarkus-data-index-sqlite` runtime(parent=sqlite-parent) | `kogito-addons-quarkus-data-index-common-runtime`、`kogito-addons-quarkus-data-index-persistence-sqlite`(10.2.0);build:`quarkus-extension-maven-plugin(extension-descriptor,capability provides org.kie.kogito.data-index)` |
| 同上 deployment | `...-common-deployment`、`...-persistence-sqlite-deployment`、`kogito-addons-quarkus-data-index-sqlite`(runtime jar);test:`quarkus-junit5-internal` |
| `kogito-addons-quarkus-data-index-persistence-sqlite` runtime(parent=persistence-sqlite-parent) | `...-persistence-common-runtime`、`quarkus-flyway`、`org.xerial:sqlite-jdbc:3.45.1.0`(版本寫死)、`data-index-storage-sqlite:10.2.0`、`quarkus-hibernate-orm`、`kie-addons-quarkus-flyway`;capability provides `org.kie.kogito.data-index.persistence` |
| 同上 deployment | `...-persistence-common-deployment`、runtime jar、`quarkus-flyway-deployment`、`kie-addons-quarkus-flyway-deployment`、`quarkus-hibernate-orm-deployment`(註記:不存在 quarkus-jdbc-sqlite-deployment) |

### 5.5 消費端(distribution)

`transfer-app` 與 `reconciliation-app` 的 pom 都直接依賴 `platform-security` + `platform-data-index`(platform-common 為傳遞依賴,並以 `quarkus.index-dependency.platform-*` 三條目加入 Jandex index 以利 CDI/反射發現)。模組 DAG 全貌見 [../01-getting-started/PROJECT-LAYOUT.md](../01-getting-started/PROJECT-LAYOUT.md)。

---

## 6. 常見錯誤

| # | 症狀 | 根因 | 解法 |
|---|------|------|------|
| 1 | GET/DELETE 對 workflow 端點回 403,body `{"error": "Only POST method is allowed"}` | `RuntimeFilter` 的 POST-only 策略,**設計如此** | 改用 POST;查詢/取消類操作走含 `instances`/`jobs` 等白名單子字串的路徑 |
| 2 | 某個含 `reconciliation`/`specs`/`instances`/`jobs`/`trace` 字樣的新業務路徑可以亂用 HTTP method,而且不出現 `[HTTP-AUDIT]` | 白名單是 `contains` 子字串比對,命中即完全繞過 RuntimeFilter(不擋、不緩存 payload) | 新路徑命名避開白名單關鍵字,或有意識地把該路徑加進豁免清單並另行稽核 |
| 3 | `[HTTP-AUDIT]` 只有 POST 請求有記錄,Cost 都是 0ms | WorkflowStatusFilter 開頭即對非 POST return;Cost 依賴 RuntimeFilter 緩存的 `startTimeNano`,白名單路徑沒緩存 | 屬預期行為;需要 GET 稽核得另寫 filter |
| 4 | status-rewrite 完全沒生效(VALIDATION_FAILED 仍回 200) | ①workflow id 不在 `platform.status-rewrite.workflows`;②entity 是 POJO 且不含可解析的 status;③mapping 鍵拼錯(啟動日誌會 WARN `無效的映射條目`) | 核對啟動 INFO `已載入配置: workflows=..., mapping=...`;確認回應頂層或 `workflowdata.status` 有值 |
| 5 | status-rewrite 改寫後又變回 200 | 自行調整了兩個 response filter 的 priority,使 Unwrap(USER)晚於 WorkflowStatusFilter(USER-10)執行 | 保持現有 priority:response filter 降序執行,Unwrap 必須先跑 |
| 6 | 啟動噴 `Unrecognized configuration key kogito.apps.persistence.type` | 缺少 `KogitoAppsPersistenceConfig` 這個 build-time config root(例如換掉 platform-extensions 修補版、用了上游原版 addon) | 依賴本地修補版的 `kogito-addons-quarkus-data-index-sqlite-deployment`,或自行保留該 config root |
| 7 | GraphQL 查 ProcessInstances 時 `Error parsing time stamp`(DateTimeParseException) | timestamp 走了 Hibernate 預設 ZonedDateTime 型別,遇到 TEXT 欄位的 epoch-ms 數字字串 | 確認 `quarkus.hibernate-orm.dialect=org.acme.platform.dataindex.KogitoSQLiteDialect` 未被覆寫;platform-data-index 依赖在 classpath |
| 8 | 以為 `SqliteZonedDateTimeIntegrationListener` 有在跑,但 log 沒出現 `onMetadataInitialized called` | 其 deployment 掛載點 `SqliteZonedDateTimeIntegrationProcessor#register` 的 `@BuildStep` 已被註解停用(回 null) | 修補主力是 Dialect;除非有意承擔 reflection 風險,否則不要重新啟用該 step |
| 9 | 啟動失敗:`Unable to expand MYHELLO_DATA_DIR` 或 DataSource URL 含字面 `${MYHELLO_DATA_DIR}` | `PlatformConfigSource` 沒被載入(ServiceLoader 註冊遺失,例如手刻 fat-jar 漏掉 `META-INF/services/org.eclipse.microprofile.config.spi.ConfigSource`) | 確認 platform-data-index jar 內 services 檔存在;或直接設環境變數 `MYHELLO_DATA_DIR` |
| 10 | `data/` 目錄建立在奇怪的位置(例如子模組目錄下) | `PlatformPaths#findProjectRoot` 以 `user.dir` 向上找 `.git` 或(`pom.xml`+`distribution`),從非常深或脫離 repo 的 cwd 啟動會找不到 | 從專案根/標準位置啟動,或顯式設定 `MYHELLO_DATA_DIR` |
| 11 | Flyway 啟動後 data-index 表沒建立 | `META-INF/kie-flyway.properties` 的 `module.locations.sqlite` 沒被掃描(缺 `kie-addons-quarkus-flyway` 依賴或 `kie.flyway.enabled=false`) | 保持 persistence-sqlite runtime 的依賴鏈與 `kie.flyway.enabled=true` |
| 12 | Swagger 文件仍顯示 PUT/PATCH/DELETE/HEAD | `mp.openapi.filter` 沒指到 `SonataFlowSecurityConfig$SwaggerFilter`(內部類要用 `$` 寫法) | 檢查 distribution app 的 application.properties;若想連 GET 也藏,改掛備援的 `OpenApiFilter` |
| 13 | Windows 上 JDBC URL 或 classpath 分隔符錯誤 | 手工拼路徑而未用 `PlatformPaths#sqliteUrl` / `#normalizeClasspath` | 統一走 PlatformPaths;classpath 字串務必 normalize 成 `/` |

---

> 延伸閱讀:[ARCHITECTURE](../02-architecture/ARCHITECTURE.md)(三層架構與雙 app 部署)、[OBSERVABILITY](../02-architecture/OBSERVABILITY.md)(errorType/OPS-ALERT/節點軌跡/GraphQL)、[CONFIG-REFERENCE](../04-reference/CONFIG-REFERENCE.md)(`platform.status-rewrite.*` 等全參數)、[DATABASE-REFERENCE](../04-reference/DATABASE-REFERENCE.md)(reconciliation.db schema 與 WAL)、[TROUBLESHOOTING](../07-operations/TROUBLESHOOTING.md)(症狀→原因速查)。
