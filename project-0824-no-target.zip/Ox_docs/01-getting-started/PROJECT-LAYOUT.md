# 01 — PROJECT LAYOUT：目錄地圖、模組依賴 DAG 與單一事實來源規則

> 本文回答「東西放在哪、為什麼這樣放、哪些檔案不能手改」。
> 建置與操作步驟見 [GETTING-STARTED](./GETTING-STARTED.md)；分層架構的設計論述見 [ARCHITECTURE](../02-architecture/ARCHITECTURE.md)。
> 引用慣例：`類別#方法` 或檔名為主，行號為輔且可能隨版本變動。

## 目錄

1. [完整目錄樹（註解版）](#1-完整目錄樹註解版)
2. [八大模組分層](#2-八大模組分層)
3. [模組依賴 DAG（Mermaid）](#3-模組依賴-dagmermaid)
4. [四大核心不變式](#4-四大核心不變式)
5. [canonical workflow 檔案位置清單 vs distribution 同步副本](#5-canonical-workflow-檔案位置清單-vs-distribution-同步副本)
6. [sync-domain-resources：單一事實來源機制](#6-sync-domain-resources單一事實來源機制)
7. [執行期產物目錄（data/、logs/、target/）](#7-執行期產物目錄datalogstarget)
8. [常見錯誤](#8-常見錯誤)

---

## 1. 完整目錄樹（註解版）

```
myhello-platform/
├── pom.xml                  # 根 POM：版本集中管理(quarkus 3.27.2 / kie 10.2.0 / sqlite-jdbc 3.45.1.0)、
│                            #   dependencyManagement、pluginManagement(jandex 3.2.7)、compiler release=17
├── offline-build.sh         # 離線建置腳本(bash)：mvn clean package -o -Dmaven.repo.local=offline-packages/maven-repo
├── offline-build.ps1        # 離線建置腳本(PowerShell)：同上,另具 -OfflineRepo 參數與 mvn 存在性檢查
├── .gitignore               # 排除 target/、logs/、*.db*、data/*.csv,以及 transfer-app 的同步副本(見 §6)
├── offline-packages/
│   └── maven-repo/          # 離線 Maven 套件庫(斷網環境用,-Dmaven.repo.local 指向此處)
│
├── data/                    # 【執行期】gitignore;SQLite 與 CSV 落盤處(MYHELLO_DATA_DIR 預設值)
│   ├── reconciliation.db    #   唯一共享資料庫(WAL);附屬 .db-wal/.db-shm 由引擎管理
│   └── reconciliation-*.csv #   對帳 CSV 匯出(時間戳命名)
├── logs/                    # 【執行期】gitignore;transfer-app.log / reconciliation-app.log 及輪替備份
│
├── platform-common/         # 平台層:純 Java 工具(零內部依賴)——PlatformPaths(data/logs 路徑解析)
├── platform-security/       # 平台層:JAX-RS filter 鏈——SonataFlowSecurityConfig(RuntimeFilter/
│                            #   WorkflowStatusFilter/SwaggerFilter)、UnwrapResponseFilter、OpenApiFilter
├── platform-data-index/     # 平台層:KogitoSQLiteDialect、PlatformConfigSource、NodeTracingProcessEventListener、
│                            #   SqliteZonedDateTimeJdbcType、MyLivenessCheck + base application.properties(datasource/WAL/flyway/OIDC-off)
├── platform-extensions/     # 平台層:KIE/Kogito SQLite 修補(parent,pom packaging;子模組 groupId 屬 org.kie*/org.kie.kogito)
│   ├── data-index-storage-sqlite/                        # SQLite storage 實作 + kie-flyway DDL(V1.32.0~V1.50.0)
│   ├── kogito-addons-quarkus-data-index-sqlite/          # Quarkus addon(deployment/runtime 兩子模組)
│   └── kogito-addons-quarkus-data-index-persistence-sqlite/  # persistence addon(deployment/runtime 兩子模組)
│
├── domain-transfer/         # 轉帳 bounded context(parent pom)
│   ├── transfer-workflow/   #   ★核心:saga2-transfer-workflow.sw.yaml(v2.2.0)、saga-transfer-workflow.sw.yaml(v15)
│   │                        #   + MyOpenApiService/SagaApiService + schemas/(文件化契約)+ db/migration/
│   │                        #   + canonical specs/A16220-api.yaml、A16229-api.yaml(workflow 模組自包含合約)
│   └── transfer-samples/    #   示範 workflows:java-workflow/OpenAPI-workflow/rest-workflow(.sw.yaml)+ specs/openapi.yaml
│
├── domain-reconciliation/   # 對帳 bounded context(parent pom)
│   └── reconciliation-api/  #   AuditLogService/OpsAlertService/AuditQueryService、ReconciliationResource/
│                            #   ReconciliationAuditResource(14 endpoints)、ReconciliationCsvExporter、
│                            #   migration/DatabaseMigrationRunner + db/migration/V1.0.0 + 5 個內建 HTML 頁
│
├── mocks/                   # 外部系統模擬器(僅本機/UAT 整合測試用,生產部署可移除)
│   └── transfer-mock/       # mock REST:A16220Resource/A16229Resource(/A16220,/A16229)+ Request/Response DTO(package 保留 org.acme.transfer.api)
│
├── distribution/            # 可執行應用(parent,pom packaging;唯一允許組裝 Quarkus app 的層)
│   ├── transfer-app/        #   :8080 讀寫交易 App → target/quarkus-app/quarkus-run.jar(src/main/resources 多為同步副本,見 §6)
│   └── reconciliation-app/  #   :8090 唯讀對帳 App(read-only=true)→ target/quarkus-app/quarkus-run.jar
│
├── Ox_docs/                 # 本技術文件集(17 份)
└── docs/                    # 歷史遺留文件目錄(本文件集不引用其內容)
```

> `platform-extensions` 三個修補模組各自內含 `deployment/`＋`runtime/` 子結構（Quarkus extension 標準佈局），建置時經 kogito-bom 對位安裝；根 `pom.xml` 註解標明它們是「修補模組本地版本」。

---

## 2. 八大模組分層

| 層 | 模組 | Maven 座標 | 一句話職責 | 關鍵內容物 |
|----|------|-----------|-----------|-----------|
| 平台 | platform-common | `org.acme.platform:platform-common` | 跨平台路徑工具，**純 Java 零框架依賴** | `PlatformPaths`（MYHELLO_DATA_DIR/MYHELLO_LOGS_DIR 解析、sqliteUrl、findProjectRoot） |
| 平台 | platform-security | `org.acme.platform:platform-security` | HTTP 橫切：安全過濾與回應改寫 | `SonataFlowSecurityConfig$RuntimeFilter`／`$WorkflowStatusFilter`／`$SwaggerFilter`、`UnwrapResponseFilter` |
| 平台 | platform-data-index | `org.acme.platform:platform-data-index` | Data Index 的 SQLite 化基礎 | `KogitoSQLiteDialect`、`PlatformConfigSource`、`NodeTracingProcessEventListener`、base `application.properties` |
| 平台 | platform-extensions | `org.kie*:…sqlite`（3 子模組） | 上游 KIE/Kogito 套件的 SQLite 修補版 | data-index-storage-sqlite、kogito-addons-quarkus-data-index(-persistence)-sqlite |
| 業務域 | domain-transfer（2 子模組） | transfer-workflow / transfer-samples | 轉帳 bounded context | saga2/saga workflow＋service＋canonical specs（內嵌於 workflow 模組）、示範 workflows |
| 業務域 | domain-reconciliation（1 子模組） | reconciliation-api | 對帳 bounded context | AuditLogService（寫入）、AuditQueryService／REST（查詢）、CSV 匯出、遷移 runner |
| 模擬器 | mocks（1 子模組） | transfer-mock | 外部系統模擬器：本機/UAT 整合測試用，生產部署可移除 | A16220Resource／A16229Resource（/A16220、/A16229）＋ Request/Response DTO（package 保留 `org.acme.transfer.api`） |
| 組裝 | distribution（2 app） | transfer-app / reconciliation-app | **唯一**的可執行 Quarkus 應用層 | quarkus-run.jar ×2（8080 讀寫、8090 唯讀） |

分層原則（`distribution/pom.xml` description 明文）：一個 bounded context = 一個 distribution；一個 distribution = 一條 release train；distribution 彼此不共用 application.properties（僅共享 platform-data-index 內的 base properties）。transfer-app 的 pom description 另載明部署假設：「獨立 Pod/主機，SLA 嚴格（replica ≥ 3）」且 `transfer-samples`「可於上線前排除」、「`transfer-mock` 外部系統模擬器，本機/UAT 整合測試用，生產部署可移除」；reconciliation-app「SLA 寬鬆（replica = 1 即可），可排程批次」。


---

## 3. 模組依賴 DAG（Mermaid）

以下 DAG 依據各模組 `pom.xml` 的 `<dependencies>` 實證繪製（僅列專案內部依賴，Quarkus/KIE 外部套件省略）：

```mermaid
flowchart TB
    subgraph Platform["platform-* 平台層（library）"]
        PC["platform-common<br/>純 Java"]
        PS["platform-security<br/>filter 鏈"]
        PDI["platform-data-index<br/>Dialect/ConfigSource/Tracing"]
        PE["platform-extensions<br/>KIE SQLite 修補 ×3<br/>(groupId: org.kie*)"]
    end

    subgraph DT["domain-transfer 轉帳域"]
        TWF["transfer-workflow<br/>saga2 + saga .sw.yaml<br/>+ canonical specs"]
        TSAMP["transfer-samples<br/>java/OpenAPI/rest"]
    end

    subgraph DR["domain-reconciliation 對帳域"]
        RAPI["reconciliation-api<br/>AuditLog/OpsAlert/CsvExporter"]
    end

    subgraph MOCKS["mocks 外部系統模擬器（本機/UAT 測試用）"]
        TMOCK["transfer-mock<br/>mock /A16220 /A16229"]
    end

    subgraph DIST["distribution 可執行應用"]
        TA["transfer-app :8080<br/>讀寫 reconciliation.db"]
        RA["reconciliation-app :8090<br/>read-only"]
    end

    PS --> PC
    PDI --> PC
    PDI -. "org.kie:kogito-addons-quarkus-<br/>data-index-sqlite（本地 mvn install）" .-> PE
    TWF --> PC & RAPI
    RAPI --> PC & PDI
    TA --> PS & PDI & TWF & TSAMP & TMOCK & RAPI
    RA --> PS & PDI & RAPI
    TA -. "共享 volume：reconciliation.db" .-> RA
```

### 3.1 依賴明細表（pom 實證）

| 模組 | 直接依賴的專案內模組 | 備註 |
|------|----------------------|------|
| platform-common | （無） | 全平台唯一零內部依賴 |
| platform-security | platform-common | 另依賴 quarkus-resteasy/jackson、smallrye-openapi |
| platform-data-index | platform-common、`org.kie:kogito-addons-quarkus-data-index-sqlite` | 後者即 platform-extensions 的修補產物；另直接依賴 sqlite-jdbc |
| transfer-mock | （無） | 外部系統模擬器的 Resource＋DTO（package 保留 `org.acme.transfer.api`）；本機/UAT 整合測試用，生產部署可移除 |
| transfer-workflow | platform-common、**reconciliation-api** | 引入 reconciliation-api 是為 saga2 的對帳寫入（見不變式 B 的最小接觸面）；canonical specs 內嵌於本模組 `resources/specs/` |
| transfer-samples | （無） | 示範 workflows 自成體系，只共用 Kogito 引擎依賴 |
| reconciliation-api | platform-common、platform-data-index | 為了 GraphQL/Data Index 能力與 dialect；直接依賴 sqlite-jdbc |
| transfer-app | platform-security、platform-data-index、transfer-workflow、transfer-samples、transfer-mock、reconciliation-api | pom description：reconciliation-api「僅 AuditLogService，因 saga2 workflow 對帳需要」；transfer-mock「外部系統模擬器，本機/UAT 整合測試用，生產部署可移除」 |
| reconciliation-app | platform-security、platform-data-index、reconciliation-api | **不含任何 transfer-\***——上線對帳 Pod 不應跑交易流程 |

### 3.2 拓撲排序（建置順序即依此）

```
platform-common → (platform-security, platform-data-index, platform-extensions, transfer-mock)
              → reconciliation-api → transfer-workflow / transfer-samples
              → transfer-app / reconciliation-app
```

Maven reactor 會自動按此順序建置；此圖亦保證**無循環依賴**（不變式 D）。

---

## 4. 四大核心不變式

> 這四條是多模組分層的護欄。違反任何一條，架構就開始劣化。驗證方式都以 pom 宣告為準。

### A. 分層單向：依賴只能向下流，永不反向

- **內容**：`distribution → domain → platform` 是唯一的依賴方向。platform 層**永不**依賴任何 domain／distribution 模組；domain 層**永不**依賴 distribution。
- **實證**：platform-common 零內部依賴；platform-security／platform-data-index 只依賴 platform-common（與 KIE 外部件）；全部 domain 模組的 pom 都沒有出現 `*-app` 座標。
- **違例後果**：平台層被業務綁架，無法單獨升級或重用於新 bounded context。

### B. 跨域最小接觸面：transfer 只用 reconciliation 的服務類別，不碰其內部

- **內容**：transfer 域需要寫入對帳紀錄時，僅透過兩個對外服務呼叫——`AuditLogService#saveLog` 與 `OpsAlertService#raise`（定義於 `saga2-transfer-workflow.sw.yaml` functions 區：`service:com.example.reconciliation.AuditLogService::saveLog`、`service:com.example.reconciliation.OpsAlertService::raise`）。不 import、不呼叫 `ReconciliationResource`／`ReconciliationAuditResource`／`AuditQueryService` 等 REST／查詢實作。
- **實證**：transfer-app pom 對 reconciliation-api 的註解原文：「僅 AuditLogService，因 saga2 workflow 對帳需要」；舊版 `saga-transfer-workflow.sw.yaml`（v15）則完全不用 reconciliation 服務。
- **違例後果**：對帳域的重構（換 schema、換儲存）會波及交易域。

### C. 只有 distribution 可以組裝成可執行應用

- **內容**：`quarkus-maven-plugin` 只出現在三個地方——根 pom 的 `<pluginManagement>`（版本管理）與兩個 app 模組的 `<build><plugins>`。其餘所有模組都只是 library jar，不得自帶打包設定。
- **實證**：全倉庫 grep `quarkus-maven-plugin` 僅命中根 pom、`distribution/transfer-app/pom.xml`、`distribution/reconciliation-app/pom.xml`。
- **違例後果**：出現第二個部署單位，release train 失控（「一個 distribution = 一條 release train」被打破）。

### D. 無循環依賴（DAG）

- **內容**：§3 的 DAG 必須始終可拓撲排序；任何新依賴若形成環（例如 reconciliation 反過來用 transfer 的類別）即屬違規。
- **實證**：目前所有 pom 宣告皆沿 §3.2 的方向；`mvn dependency:tree` 在任一模組執行都不應出現 cycle。
- **違例後果**：Maven 建置順序不可判定、IDE 索引錯亂、測試隔離失效。


---

## 5. canonical workflow 檔案位置清單 vs distribution 同步副本

平台共 **5 支 `.sw.yaml`**。**canonical（唯一可編輯）來源全部在 `domain-transfer` 各模組**；`distribution/transfer-app/src/main/resources` 下的同名檔案是建置同步副本（機制見 §6）。

| # | workflow id | 版本 | canonical 位置 | 分類 |
|---|-------------|------|----------------|------|
| 1 | `saga2-transfer-workflow` | 2.2.0 | `domain-transfer/transfer-workflow/src/main/resources/saga2-transfer-workflow.sw.yaml` | 開發範本主流程（MyOpenApiService 路線，18 states：6 switch + 6 operation + 6 inject） |
| 2 | `saga-transfer-workflow` | v15 | `domain-transfer/transfer-workflow/src/main/resources/saga-transfer-workflow.sw.yaml` | 舊版主流程（SagaApiService 直打 REST），僅作對照 |
| 3 | `java-workflow` | - | `domain-transfer/transfer-samples/src/main/resources/java-workflow.sw.yaml` | 示範：Java service 呼叫（配 ApiService.java） |
| 4 | `OpenAPI-workflow` | - | `domain-transfer/transfer-samples/src/main/resources/OpenAPI-workflow.sw.yaml` | 示範：OpenAPI spec 呼叫（配 specs/openapi.yaml） |
| 5 | `rest-workflow` | - | `domain-transfer/transfer-samples/src/main/resources/rest-workflow.sw.yaml` | 示範：rest 呼叫（fetchHealthData） |

同步副本（**勿手改、勿納版控**）：`distribution/transfer-app/src/main/resources/` 下同名 5 支 `.sw.yaml` 加上 `schemas/`、`specs/` 兩個目錄。`.gitignore` 已明文排除並註記「P1-2 單一事實來源」。

其他資源的 canonical 對應：

| 資源類型 | canonical 位置 | 同步後落點 |
|----------|----------------|-----------|
| mock API OpenAPI specs | `domain-transfer/transfer-workflow/src/main/resources/specs/A16220-api.yaml`、`A16229-api.yaml`（workflow 模組自包含合約） | `distribution/transfer-app/src/main/resources/specs/` |
| samples 共用 spec | `domain-transfer/transfer-samples/src/main/resources/specs/openapi.yaml` | 同上合併 |
| 輸入契約 schemas | `domain-transfer/transfer-workflow/src/main/resources/schemas/saga-transfer-input-schema.json`、`input-schema.json` | `distribution/transfer-app/src/main/resources/schemas/` |

> transfer-app 的 resources 中**屬於 canonical、有被 git 追蹤**的檔案只有三類：`application.properties`、`db/migration/V1.1.0__create_view_transfer_reconciliation.sql`、`META-INF/resources/{dashboard,index,instances}.html`（可用 `git ls-files distribution/transfer-app/src/main/resources` 自行驗證）。其餘 YAML/schema/spec 全是同步產物。

---

## 6. sync-domain-resources：單一事實來源機制

### 6.1 機制定義

`distribution/transfer-app/pom.xml` 的 `<build>` 內宣告了一個 `maven-resources-plugin` execution：

| 屬性 | 值 |
|------|-----|
| execution id | `sync-domain-resources` |
| phase | `initialize`（每次建置的最早期執行） |
| goal | `copy-resources` |
| outputDirectory | `${project.basedir}/src/main/resources` |
| overwrite | `true`（**靜默覆蓋**同名檔案） |
| 來源目錄 ×2 | `../../domain-transfer/transfer-workflow/src/main/resources`、`../../domain-transfer/transfer-samples/src/main/resources`（specs 隨 transfer-workflow 一併同步） |

pom 內註解原文直指設計意圖：「workflow YAML / schemas / specs 的 canonical source 在 domain-transfer/* 模組；本模組的 src/main/resources 內同名檔案為『建置產物』，由下方 sync-domain-resources (initialize 階段) 自 domain 模組同步生成，已列入 .gitignore。直接編輯本模組的副本會在下一次建置被靜默覆蓋，請一律修改 domain 模組來源。」

### 6.2 為什麼要這樣做？

Quarkus/SonataFlow 打包時以**應用模組自己的 classpath resources** 為主要掃描來源；把兩個 domain 模組的 resources 實體複製進 app 模組，可確保 codegen 與打包都看得到全部 workflow 定義與 specs；同時用「副本＝建置產物＋gitignore」防止兩處編輯造成內容漂移——**單一事實來源（Single Source of Truth）**。

### 6.3 正確與錯誤的工作流

```text
[正確] 編輯 domain-transfer/transfer-workflow/src/main/resources/saga2-transfer-workflow.sw.yaml
       → mvn package（或 quarkus:dev）
       → sync-domain-resources 自動把新版複製進 transfer-app
       → 打包／熱載後生效

[錯誤] 直接編輯 distribution/transfer-app/src/main/resources/saga2-transfer-workflow.sw.yaml
       → 下一次 mvn package 被靜默覆蓋，修改人間蒸發
```

### 6.4 .gitignore 的配套排除

`.gitignore` 尾端區塊（註解「transfer-app 同步產物 (P1-2 單一事實來源)」）：

```gitignore
distribution/transfer-app/src/main/resources/*.sw.yaml
distribution/transfer-app/src/main/resources/schemas/
distribution/transfer-app/src/main/resources/specs/
```

歷史脈絡：這些檔案曾經被 git 追蹤，後續解除追蹤並列入 ignore（`git status --ignored` 可見其呈 ignored 狀態）。因此 clone 後若 `src/main/resources` 下看不到這些檔案是正常的——跑一次 `mvn package` 即由 sync 機制自動補齊。

---

## 7. 執行期產物目錄（data/、logs/、target/）

| 目錄 | 內容 | 版控狀態 | 位置決定者 |
|------|------|----------|-----------|
| `data/` | `reconciliation.db`（＋`-wal`/`-shm`）、`reconciliation-<時間戳>.csv` | gitignore（`*.db*`、`data/*.csv`，保留 `.gitkeep`） | `MYHELLO_DATA_DIR`，預設專案根 `data/`（`PlatformPaths#dataDirectory()`） |
| `logs/` | `transfer-app.log`、`reconciliation-app.log` 及輪替備份 | gitignore（`logs/`、`*.log`） | `MYHELLO_LOGS_DIR`，預設專案根 `logs/`（`PlatformPaths#logsDirectory()`） |
| `*/target/` | classes、`quarkus-app/quarkus-run.jar`、generated-sources 等 | gitignore（`target/`） | Maven 標準 |

> 細節（rotation 參數、WAL 附屬檔注意事項）見 [GETTING-STARTED §8](./GETTING-STARTED.md#8-logs-與-data-產物說明) 與 [DATABASE-REFERENCE](../04-reference/DATABASE-REFERENCE.md)。

---

## 8. 常見錯誤

### 8.1 手改同步副本被靜默覆蓋

- **症狀**：改了 `distribution/transfer-app/src/main/resources/*.sw.yaml` 後，下次建置修改消失或「改了沒效」。
- **原因與解法**：見 §6.3——一律改 canonical 來源（`domain-transfer/*/src/main/resources`），再重建。

### 8.2 在 app 模組找不到 `.sw.yaml`／specs 就以為專案壞了

- **症狀**：fresh clone 後 `distribution/transfer-app/src/main/resources` 下沒有 5 支 workflow。
- **解法**：正常現象（gitignored 建置產物）。執行一次 `mvn clean package -DskipTests` 即補齊。

### 8.3 把新 workflow 或 spec 加到 transfer-app 的 resources

- **症狀**：新檔案不會被 sync 管理；若檔名恰與 canonical 相同還會被覆蓋。
- **解法**：新 workflow YAML 放 `domain-transfer/transfer-workflow/src/main/resources/`；新 OpenAPI spec 放對應 domain 模組的 `specs/`。開發 SOP 詳見 [NEW-WORKFLOW-GUIDE](../03-workflow-dev-guide/NEW-WORKFLOW-GUIDE.md)。

### 8.4 誤以為 platform-extensions 可跳過

- **症狀**：只 build distribution 出現找不到 `org.kie:kogito-addons-quarkus-data-index-sqlite:10.2.0`。
- **解法**：該 artifact 是本倉庫的修補模組（上游不存在同名版本）。從根 pom 跑完整 reactor 建置，或先 `mvn install -pl platform-extensions -am`。

### 8.5 在 domain 模組間開出反向依賴

- **症狀**：例如讓 reconciliation-api 依賴 transfer-workflow，或在 platform 層 import 業務類別。
- **解法**：違反 §4 不變式 A/D。跨域只能走服務類別接觸面（不變式 B），新增依賴前先對照 §3 DAG。

---

## 下一步

- [GETTING-STARTED](./GETTING-STARTED.md)：建置、啟動與第一筆交易
- [ARCHITECTURE](../02-architecture/ARCHITECTURE.md)：三層架構與部署模型深論
- [PLATFORM-MODULES](../05-platform/PLATFORM-MODULES.md)：platform-* 四模組元件手冊
- [SAGA2-TEMPLATE-DEEP-DIVE](../03-workflow-dev-guide/SAGA2-TEMPLATE-DEEP-DIVE.md)：核心範本 workflow 全解析
