# NEW-WORKFLOW-GUIDE — 從零開發新 Workflow 的 8 步 SOP

> 本文以 `saga2-transfer-workflow`(v2.2.0)為範本,給出在本平台新增一個 workflow 的完整作業程序。每步都有具體指令與檔案範例;步驟⑧是上線 checklist。模式級的 YAML 片段速查見 [WORKFLOW-COOKBOOK](WORKFLOW-COOKBOOK.md),樣板逐行原理見 [SAGA2-TEMPLATE-DEEP-DIVE](SAGA2-TEMPLATE-DEEP-DIVE.md)。

## SOP 總覽

```mermaid
flowchart LR
    A["① 定義 OpenAPI spec<br/>transfer-workflow/resources/specs"] --> B["② 選服務層策略<br/>MyOpenApiService 或 custom"]
    B --> C["③ 寫 .sw.yaml<br/>transfer-workflow/resources"]
    C --> D["④ 配置註冊<br/>application.properties"]
    D --> E["⑤ schema 同步<br/>schemas/*.json 契約"]
    E --> F["⑥ @QuarkusTest<br/>rest-assured + JDBC"]
    F --> G["⑦ 端到端驗證<br/>tester.html / curl / GraphQL / log"]
    G --> H["⑧ 上線 checklist"]
```

前置閱讀:[../01-getting-started/PROJECT-LAYOUT.md](../01-getting-started/PROJECT-LAYOUT.md)(單一事實來源規則)、[SAGA2-TEMPLATE-DEEP-DIVE](SAGA2-TEMPLATE-DEEP-DIVE.md) §3-§5。

**鐵律(先記住再動手)**:

1. canonical 資源只放在 `domain-*` 模組;`distribution/transfer-app/src/main/resources` 是建置同步副本,**手改會被覆蓋**。
2. 所有技術事實以原始碼為準,本文件所有範例均取自實際可運行的檔案。

---

## 步驟① 定義 OpenAPI spec(放 transfer-workflow/src/main/resources/specs/)

對照範本:`domain-transfer/transfer-workflow/src/main/resources/specs/A16229-api.yaml`(全文 108 行)。骨架:

```yaml
openapi: 3.0.0
info:
  title: A16229 API
  description: A16229 交易處理 API
  version: 1.0.0
servers:
  - url: http://localhost:8080/
paths:
  /A16229:
    post:
      operationId: executeA16229
      summary: 執行 A16229 交易
      requestBody:
        required: true
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/A16229Request'
      responses:
        '200':
          description: 交易成功
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/A16229Response'
              examples:
                success:
                  value:
                    code: "100"
                    message: "成功"
                    Account: "A123456789"
        '403':
          description: 交易失敗 (Request 為空或 AMT 不符合條件)
          ...
components:
  schemas:
    A16229Request:
      type: object
      required: [Account_A, AMT, EC]
      properties:
        Account_A: { type: string }
        AMT: { type: integer, format: int32 }
        EC: { type: boolean }
    A16229Response:
      type: object
      required: [code, message]
      properties:
        code: { type: string, description: "`100` 成功 / `999` 失敗" }
        message: { type: string }
        Account: { type: string, nullable: true }
```

慣例清單(全部對照 A16229-api.yaml 實文):

| 項目 | 慣例 | 理由 |
|------|------|------|
| 檔名 | `<NAME>-api.yaml`,放 `specs/` | workflow 以 `'specs/<NAME>-api.yaml#<operationId>'` 定位;`MyOpenApiService#callOpenApi` 以 classpath 載入,specs 位於 transfer-workflow 模組自身 resources,隨 transfer-workflow jar 進入 runtime(自包含) |
| `operationId` | `executeXxx`,全 spec 唯一 | `MyOpenApiService#resolveEndpoint` 逐 path/method 掃描比對 operationId;重複或缺失直接 IllegalArgumentException |
| `servers[0].url` | 必填(如 `http://localhost:8080/`) | Base URL 解析第 4 優先序的兜底值(`MyOpenApiService#doResolveBaseUrl`) |
| `requestBody.required` | `true` | 文件化契約;mock 端點對 null body 回 403+code 999 |
| responses examples | 200 與 4xx 各附 success/failure 樣本(code "100"/"999") | 團隊閱讀契約即可寫測試;code 語義必須寫進 schema description |
| 欄位命名 | 與 mock Resource 的 DTO 完全一致(Account_A/AMT/EC) | payload 由 MyOpenApiService 原樣序列化,拼錯不會報錯而是靜默送出 null |

> 提示:`RuntimeFilter`(platform-security)會放行路徑含 `specs` 的請求,spec 檔也可透過 HTTP 檢視;Swagger UI(/q/swagger-ui/)可直接驗證 spec 語法。

---

## 步驟② 選擇服務層策略(MyOpenApiService 通用 vs 新寫 custom service)

**預設選 MyOpenApiService**(零 Java):只要目標是「HTTP + OpenAPI 描述得到的 REST API」,workflow 直接以 schemaRef 呼叫,享有:多 HTTP 方法、path-param/query 自動組裝、自訂 headers、可配置逾時(`kogito.sw.openapi.timeout-seconds`,預設 10s)、傳輸層指數退避重試、回應標準化 + errorType 四分類、四層快取(詳見 [../04-reference/SERVICE-REFERENCE.md](../04-reference/SERVICE-REFERENCE.md))。

**何時才需要自己的 custom service**:

1. **特殊鑒權**:簽章/HMAC/動態 token/雙向 TLS 等無法用 headers 參數表達者;
2. **非 REST 協定**:SOAP/TCP/JMS/檔案傳輸;
3. **固定內部邏輯**:不需要 spec、想省去 schemaRef 解析開銷(如 v15 的 SagaApiService);
4. **需要 CompletionStage 介面**或特殊回應後處理。

自寫時的最低契約(參照 `SagaApiService`):吞掉一切例外回標準化 body——至少含 `code`(成功 "100")、`message`、`_httpStatus`;傳輸失敗回 `code:"999"` + `_httpStatus:0`;建議再加 `errorType` 對齊 saga2 契約。**絕不可讓例外拋進引擎**,否則只能靠 onErrors 兜底,失去「結果未知 vs 業務確定失敗」的分流能力。

函式綁定格式(workflow functions 區塊):

```yaml
- name: callApiViaOpenAPI
  operation: 'service:com.example.transfer.workflow.MyOpenApiService::callOpenApi'
  type: custom
```

---

## 步驟③ 寫 .sw.yaml(canonical 位置:domain-transfer/transfer-workflow/src/main/resources/)

### 3.1 骨架(從 saga2 複製後改)

```yaml
id: my-new-workflow                # 同時是 REST 路徑 POST /my-new-workflow
version: '1.0.0'
specVersion: '0.8'                 # 固定 0.8
name: My New Workflow
description: |
  (目的、版本變更記錄、冪等性註記——學 saga2 的 description 格式)
start: ValidateInput

metadata:
  domain: <域>
  pattern: <模式>
  criticality: high
  owner: <團隊>

timeouts:
  workflowExecTimeout: PT5M

errors:
  - name: platformError
    code: 'PLATFORM_ERROR'         # 必填!漏了整個 errors 區塊會被 codegen 忽略
    description: 平台層非預期錯誤

functions:                          # 學 §6.1 三函式,按需取用
  ...

states:                             # ValidateInput → ... → FinalAuditAndEnd
  ...
```

### 3.2 P2-1 switch 慣則(複誦)

僅正向條件 + 安全 default;jq 一律安全寫法(`// ""` 收斂、`match() // false == false` 替代 test()、`type != "number"`);onErrors 目標與 default 同向。細節見 [SAGA2-TEMPLATE-DEEP-DIVE](SAGA2-TEMPLATE-DEEP-DIVE.md) §5。

### 3.3 onErrors 收斂決策表(新 workflow 逐 state 填寫)

| 問題 | 若「否」 | 若「是」 |
|------|---------|---------|
| 此 state 出錯時,**前面已經扣款(產生需補償的外部效應)** 了嗎? | → 收斂到 InjectFailedStatus(或驗證語義 InjectValidationFailedStatus) | → 收斂到 Rollback*(已完成的階段數決定 Rollback 哪幾個;LIFO 順序) |
| 此 state 位於補償過程中? | — | → 只能收斂到 InjectRollbackFailedStatus(+OpsAlert 自動接手) |
| 此 state 是 switch 且評估可能壞? | — | → onErrors 與 defaultCondition **同向**(學 DecideByEvaluation 全回沖策略) |
| 此 state 是 inject? | 不掛 onErrors(字面注入不可能失敗) | |
| 此 state 是收尾(寫帳/告警)? | 不掛 onErrors;要求服務層吞例外回布林(AuditLogService/OpsAlertService 契約) | |

### 3.4 統一終點模板(直接抄)

把 saga2 的 `FinalAuditAndEnd` 整段抄走,改三處:`workflowId` 字面值、`businessKey` 取捨、outputData 內容。**不要**更動 output 模板的欄位集合語義(status/message/AMT/結果物件們//null/auditSaved//false/opsAlertRaised//false)——消費端依賴形狀固定。若不需要 OpsAlert,保留呼叫亦無妨(其餘狀態靜默回 raised=false)。

### 3.5 timeout/onErrors 全覆蓋自查

每個 operation/switch state 都要有:timeouts(actionExecTimeout > HTTP 逾時)、onErrors(platformError)、transition/defaultCondition。inject 與收尾除外(見上表)。

---

## 步驟④ 配置註冊:application.properties

編輯 `distribution/transfer-app/src/main/resources/application.properties`(建置時疊加 platform-data-index 的 base;同名 key 會覆寫 base)。

### 4.1 函式 Base URL(kogito.sw.functions.*)

```properties
# callApiViaOpenAPI (saga2-transfer-workflow 主路徑)
kogito.sw.functions.callApiViaOpenAPI.protocol=http
kogito.sw.functions.callApiViaOpenAPI.host=localhost
kogito.sw.functions.callApiViaOpenAPI.port=8080
```

新 workflow 若用了新的 functionName,照此三行註冊(protocol 可省略預設 http)。解析優先序(`MyOpenApiService#doResolveBaseUrl`):① `.base_url`/`.url` → ② `.protocol`+`.host`+`.port` → ③ `kogito.sw.openapi.<specKey>.base_url`/`quarkus.rest-client.<specKey>.url` → ④ spec `servers[0].url`;全部缺席會在呼叫時拋 IllegalStateException。

### 4.2 HTTP 狀態碼改寫(若需對外語義化)

```properties
# (1) 啟用改寫的 workflow 名單 (逗號分隔;比對目標為路徑第一段 = workflow id)
platform.status-rewrite.workflows=saga2-transfer-workflow,my-new-workflow
# (2) finalStatus → HTTP 狀態碼映射 (格式: STATUS=CODE)
platform.status-rewrite.mapping=VALIDATION_FAILED=400,ROLLBACK_FAILED=409
```

兩處都要加:名單沒有新 id → 改寫不生效;mapping 未列的 status 保持引擎原碼(SUCCESS/FAILED/ROLLED_BACK → 200)。實作:`SonataFlowSecurityConfig$WorkflowStatusFilter`(ContainerResponseFilter),priority = USER−10,**刻意晚於** UnwrapResponseFilter(USER)執行——JAX-RS response filter 以 priority 降序執行,後跑才能取得解包後的最終 entity,並讓改寫碼覆蓋 Unwrap 強制設定的 200(`SonataFlowSecurityConfig` 類別註解原文)。

### 4.3 index-dependency(確認新模組已被掃描)

```properties
quarkus.index-dependency.transfer-mock.group-id=org.acme.platform
quarkus.index-dependency.transfer-mock.artifact-id=transfer-mock
...
```

現有名單:platform-common、platform-security、platform-data-index、transfer-mock、transfer-workflow、transfer-samples、reconciliation-api(application.properties Index Dependencies 區塊)。新增自訂 service 所在的新 Maven 模組時,**必須**補一組 index-dependency,否則 Jandex 掃不到類別,Kogito codegen 找不到 `service:FQCN::method`,啟動即失敗。另注意:transfer-samples 目前無內部模組依賴;OpenAPI specs 已併入 transfer-workflow 自身 resources。

### 4.4 測試 profile(%test)

既有配置已備妥:`%test.quarkus.http.test-port=8080`(self-call 命中)、`%test.quarkus.datasource.jdbc.url=jdbc:sqlite:target/test-reconciliation.db`、OIDC/Keycloak devservices 關閉。新 workflow 測試直接沿用,勿另開 port。

---

## 步驟⑤ schema 同步:schemas/*.json 文件化契約

- 檔案:`domain-transfer/transfer-workflow/src/main/resources/schemas/saga-transfer-input-schema.json`;其 description 自述定位:「規則與 runtime ValidateInput 同步 (v2.1.0)」。
- saga2 已把 YAML 內 `dataInputSchema` **註解停用**(引擎不再做 JSON Schema 驗證),schema 檔轉為「同步後的文件化契約」——給人與工具看,不參與 runtime 攔截。
- 因此**文件化契約必須人工保持一致**,同步檢核表:

| schema(saga-transfer-input-schema.json) | runtime(ValidateInput jq) |
|------------------------------------------|-----------------------------|
| `pattern: "^[A-Za-z0-9_]+$"` + `minLength: 1` | `((.Account_A // "") \| match("^[A-Za-z0-9_]+$") // false) == false`(空字串自然不通過) |
| `AMT.type: number` | `.AMT \| type != "number"` |
| `exclusiveMinimum: 0` | `.AMT <= 0` |
| required Account_A ≠ Account_B(schema 以 description 描述)| `.Account_A == .Account_B` |
| `required: [Account_A, Account_B, AMT]` | 缺失欄位由 `// ""` / type 檢查接住 |
| `additionalProperties: false` | runtime 不擋多餘欄位(**已知差異**,契約上聲明即可) |

規則一處改、三處同步:ValidateInput 條件 ↔ schema 檔 ↔ InjectValidationFailedStatus 的 finalMessage(+測試斷言)。

---

## 步驟⑥ 寫 @QuarkusTest

範本:`distribution/transfer-app/src/test/java/com/example/platform/distribution/transfer/Saga2TransferWorkflowTest.java`(18 個測試)。要點:

**(1) POST /<workflowId> + rest-assured 斷言 body**

```java
private static final String WORKFLOW_URL = "/saga2-transfer-workflow";

given()
    .contentType("application/json")
    .body("{\"Account_A\":\"A123\",\"Account_B\":\"B123\",\"AMT\":100}")
.when()
    .post(WORKFLOW_URL)
.then()
    .statusCode(200)
    .body("status", equalTo("SUCCESS"))
    .body("message", equalTo("交易成功"))
    .body("a16229Result.code", equalTo("100"))
    .body("a16229Result._httpStatus", equalTo(200))
    .body("opsAlertRaised", equalTo(false));
```

斷言軸線:`statusCode`(含 status-rewrite 後的 400/409)+ `status/message` + 各 result 物件的 code/_httpStatus/errorType + nullValue()(短路欄位)+ auditSaved/opsAlertRaised。

**(2) RBFAIL 式哨兵設計**:mock 端點內建「強制失敗開關」——`A16229Resource#execute`:EC=true 且 Account_A="RBFAIL" → 403 + code "401"(回沖失敗);A16220Resource#execute 對 Account_B 同理。EC=false 的一般交易不受影響,所以同一帳號可先正常扣款、再於回沖階段強制失敗,端到端打出 ROLLBACK_FAILED→HTTP 409(測試 [17]/[18])。新業務 mock 一律學這招,不要用「隨機失敗」。

**(3) JDBC 直查對帳 view**(測試 [7]):

```java
try (java.sql.Connection conn = java.sql.DriverManager.getConnection("jdbc:sqlite:target/test-reconciliation.db");
     java.sql.Statement stmt = conn.createStatement();
     java.sql.ResultSet rs = stmt.executeQuery("SELECT id, workflow_id, business_key, status FROM vw_saga_reconciliation")) {
    // assert count > 0
}
```

**(4) 邊界值成對測試**:AMT=500(SUCCESS)/501(ROLLED_BACK)(測試 [5][6]);errorType 契約測試:成功不含 errorType 欄位(nullValue)、業務失敗 errorType=BUSINESS(測試 [15][16])。

---

## 步驟⑦ 端到端驗證

前提:依 [../01-getting-started/GETTING-STARTED.md](../01-getting-started/GETTING-STARTED.md) 啟動雙 app(8080 讀寫 / 8090 唯讀對帳)。

### 7.1 tester.html(沙盒除錯器)

開 `http://localhost:8090/tester.html` → 選 workflow(自動載 payload 範本,如 saga2 預設 AMT=888)→ 「執行沙盒測試」→ 右側三步驟:請求目標、HTTP 回應碼+耗時、Data Index GraphQL 實例與節點軌跡。內部流程:瀏覽器 POST `http://localhost:8090/api/reconciliation/proxy-test`(body: `{workflowPath, payload}`)→ `ReconciliationAuditResource#proxyTest` 轉打 8080;GraphQL 軌跡走 `/api/reconciliation/graphql` 代理(`AuditQueryService` 轉發 8080 `/graphql`,解 CORS)。

### 7.2 curl 五情境(與 mock 成功規則一致:A16229 需 AMT>50、A16220 需 AMT<1000)

| # | 指令(body 摘要) | 預期 HTTP | 預期 status/關鍵欄位 |
|---|------------------|-----------|----------------------|
| 1 正常成功 | `{"Account_A":"A123","Account_B":"B123","AMT":100}` | 200 | SUCCESS;a16229/a16220 code=100;opsAlertRaised=false |
| 2 LIFO 回沖 | `...,"AMT":600`(>500) | 200 | ROLLED_BACK;a16229Rollback/a16220Rollback message="成功(EC)" |
| 3 扣款前失敗 | `...,"AMT":30`(<50,A16229 失敗短路)| 200 | FAILED;a16229Result.code=999/_httpStatus=403/errorType=BUSINESS;a16220Result=nullValue |
| 4 驗證失敗 | `{"Account_A":"123456"}`(缺欄位)| **400** | VALIDATION_FAILED;auditSaved=true;不拋 jq 例外 |
| 5 回沖失敗哨兵 | `{"Account_A":"123456","Account_B":"RBFAIL","AMT":600}` | **409** | ROLLBACK_FAILED;a16220Rollback.code=401「回沖失敗(測試哨兵)」;a16229Rollback.code=100(LIFO 不中斷);opsAlertRaised=true |

```bash
# 情境 1
curl -s -X POST http://localhost:8080/saga2-transfer-workflow \
  -H 'Content-Type: application/json' \
  -d '{"Account_A":"A123","Account_B":"B123","AMT":100}'
# 情境 5(RBFAIL 哨兵)
curl -si -X POST http://localhost:8080/saga2-transfer-workflow \
  -H 'Content-Type: application/json' \
  -d '{"Account_A":"123456","Account_B":"RBFAIL","AMT":600}' | head -n 1   # HTTP/1.1 409
```

> 變體:AMT=2000(A16229 成功 >50、A16220 失敗 ≥1000)→ 200 + ROLLED_BACK「僅回沖 A16229」;再疊 Account_A=RBFAIL → 409(測試 [18])。

### 7.3 Data Index GraphQL 查實例

```bash
curl -s -X POST http://localhost:8080/graphql \
  -H 'Content-Type: application/json' \
  -d '{"query":"query{ ProcessInstances(where:{processId:{equal:\"saga2-transfer-workflow\"}}){ id processId state start end variables nodes { id name enter exit } } }"}'
```

(query 形狀取自 tester.html 的 fetchGraphQLTrace;節點軌跡由 NodeTracingProcessEventListener 落地。)圖形介面:`/q/dev-ui/org.kie.kogito.kogito-addons-quarkus-data-index-graphql-ui/graphql-ui`;dashboard.html 的 `ProcessDefinitions { id name version }` 可確認新 workflow 已被索引。

### 7.4 log 確認

檔案:`${MYHELLO_LOGS_DIR:logs}/transfer-app.log`(rotation 10M×10)。grep 兩個通道:

```bash
grep '\[HTTP-AUDIT\]' logs/transfer-app.log    # WorkflowStatusFilter#filter:URI|HTTP|Cost|INPUT|OUTPUT
grep '\[OPS-ALERT\]'  logs/transfer-app.log    # OpsAlertService#raise:僅 ROLLBACK_FAILED 出現
```

另可見 `[WorkflowStatusFilter] <path> status=VALIDATION_FAILED → HTTP 400` 的改寫軌跡與 AuditLogService 的寫入 INFO。

---

## 步驟⑧ 上線 checklist

上線前逐項打勾(全過才放行):

- [ ] **timeout 順序**:HTTP 逾時(10s 或自訂)< actionExecTimeout < stateExecTimeout < workflowExecTimeout;啟用傳輸重試時已重新估算最壞耗時。
- [ ] **onErrors 全覆蓋**:每個 operation/switch state 都掛 platformError;收斂目標符合決策表(扣款前→FAILED 語義/扣款後→Rollback*/回沖中→ROLLBACK_FAILED);errors 定義**含 code**。
- [ ] **metadata 四標籤**:domain/pattern/criticality/owner 已填,鍵集合與 saga2 一致。
- [ ] **輸出契約**:統一終點模板欄位集合(status/message/AMT/結果物件//null/auditSaved//false/opsAlertRaised//false)未被增刪;所有路徑都流經它。
- [ ] **冪等性評估**:description 已寫明去重策略;Gateway Idempotency-Key 或業務鍵唯一約束至少其一。
- [ ] **對帳欄位**:businessKey/processInstanceId/inputData/outputData 已填;vw_saga_reconciliation 查得到新 workflow 紀錄。
- [ ] **告警條件**:OpsAlertService 觸發條件(ALERT_ON_STATUS)與業務期望一致;detail 帶回沖現場。
- [ ] **status-rewrite 註冊**:workflows 名單 + mapping 兩處都加了新 id;400/409 實測生效。
- [ ] **index-dependency**:新模組(若有)已註冊;應用啟動無 codegen 缺類錯誤。
- [ ] **schema 同步**:schemas/*.json 與 ValidateInput 規則一致;finalMessage 同步。
- [ ] **測試覆蓋**:五情境 curl/測試全綠;RBFAIL 哨兵 409;邊界值成對;JDBC view 直查。
- [ ] **distribution 未手改**:所有變更都在 canonical 模組,distribution 由建置產生。

---

## 常見錯誤(歷史地雷速查)

| # | 症狀 | 根因 | 解法 |
|---|------|------|------|
| 1 | errors 定義完全不生效,onErrors 攔不到任何東西 | error 定義漏 `code`,Kogito codegen 直接忽略該定義 | 補 `code: 'PLATFORM_ERROR'` |
| 2 | switch 條件 runtime 求值錯誤/驗證被繞過 | jq 用了 jackson-jq 不支援的 `test()`;或對 null 直接 `match()` 拋例外 | 用 `match("...") // false == false` + 先 `// ""` 收斂 |
| 3 | 引擎先斷、拿不到標準化錯誤 body | actionExecTimeout/stateExecTimeout 設得小於 MyOpenApiService HTTP 逾時(10s),或啟用重試未放大防線 | 維持 10s < PT15S < PT30S < PT5M 順序 |
| 4 | 改了 workflow 卻沒生效/改動消失 | 手改 distribution 副本,被建置覆蓋 | 只改 domain-transfer/transfer-workflow/src/main/resources |
| 5 | 啟動即報找不到 service:FQCN::method | 新模組沒加 quarkus.index-dependency.* | application.properties 補兩行(group-id/artifact-id) |
| 6 | VALIDATION_FAILED 仍是 200 | 忘記把新 workflow id 加進 platform.status-rewrite.workflows | 名單+mapping 兩處一起加 |
| 7 | 測試 self-call 連線失敗 | %test port 不是 8080,kogito.sw.functions.<fn>.host 指不到自己 | 沿用 `%test.quarkus.http.test-port=8080` 配置 |
| 8 | 重送請求產生重複交易 | 平台無內建去重(設計如此) | Gateway 層 Idempotency-Key 去重或業務鍵唯一約束 |

---

## 相關文件

- [SAGA2-TEMPLATE-DEEP-DIVE](SAGA2-TEMPLATE-DEEP-DIVE.md):樣板逐區塊原理。
- [WORKFLOW-COOKBOOK](WORKFLOW-COOKBOOK.md):12 道配方(YAML 片段速查)。
- [../04-reference/REST-API-REFERENCE.md](../04-reference/REST-API-REFERENCE.md)/[../04-reference/CONFIG-REFERENCE.md](../04-reference/CONFIG-REFERENCE.md)/[../06-testing/TESTING-GUIDE.md](../06-testing/TESTING-GUIDE.md)。
