# UI-PAGES — myhello-platform 內建 8 頁導覽

> 本文為 Ox_docs 第 07 冊。平台在兩個可執行應用內建 8 個純靜態 HTML 營運頁面(原生 HTML/CSS/JS,免安裝),本文逐頁說明所在位置、功能、關鍵操作與背後打擊的 API。
> 內容基於各 HTML 原始檔掃描歸納;術語依 [README 術語統一表](../README.md)。

---

## 1. 全域地圖:兩個 App、八個頁面

| 頁面 | 所在 App / Port | URL | 檔案位置(canonical) |
|------|-----------------|-----|----------------------|
| index(門戶) | transfer-app / **8080** | `http://localhost:8080/index.html` | `distribution/transfer-app/src/main/resources/META-INF/resources/index.html` |
| dashboard(KPI 儀表板) | transfer-app / **8080** | `http://localhost:8080/dashboard.html` | 同上目錄 `dashboard.html` |
| instances(實例管理) | transfer-app / **8080** | `http://localhost:8080/instances.html` | 同上目錄 `instances.html` |
| reconciliation(對帳流水) | reconciliation-app / **8090** | `http://localhost:8090/reconciliation.html` | `domain-reconciliation/reconciliation-api/src/main/resources/META-INF/resources/reconciliation.html` |
| flow-trace(節點軌跡) | reconciliation-app / **8090** | `http://localhost:8090/flow-trace.html` | 同上目錄 `flow-trace.html` |
| jobs(Jobs & Timers) | reconciliation-app / **8090** | `http://localhost:8090/jobs.html` | 同上目錄 `jobs.html` |
| specs(OpenAPI 監控) | reconciliation-app / **8090** | `http://localhost:8090/specs.html` | 同上目錄 `specs.html` |
| tester(沙盒除錯器) | reconciliation-app / **8090** | `http://localhost:8090/tester.html` | 同上目錄 `tester.html` |

### 頁面導覽關係圖

實線=站內連結;虛線=跨 port 連結。8080 門戶以新視窗指向 8090 五頁;8090 各頁的 navbar 又可跳回 8080 三頁:

```mermaid
flowchart LR
    subgraph TA["transfer-app : 8080(讀寫交易)"]
        IDX["🏠 index<br/>管理控制中心門戶"]
        DASH["📊 dashboard<br/>KPI & Analytics"]
        INST["🔄 instances<br/>Workflow Instances 實例管理"]
    end
    subgraph RA["reconciliation-app : 8090(唯讀對帳微服務)"]
        REC["📋 reconciliation<br/>Saga2 對帳流水 + CSV 檔案庫"]
        FT["🎨 flow-trace<br/>節點軌跡視覺化亮燈圖"]
        JOBS["⏳ jobs<br/>Jobs & Timers retry/cancel"]
        SPECS["🌳 specs<br/>OpenAPI 規格 + 端點 ping"]
        TST["🎯 tester<br/>沙盒觸發任一 workflow"]
    end
    IDX -->|"./instances.html"| INST
    IDX -->|"./dashboard.html"| DASH
    IDX -.->|"target=_blank 開新視窗"| REC & FT & JOBS & SPECS & TST
    INST <--> DASH
    INST -.->|"navbar 跨port"| REC
    REC <-.->|"8090 站內互鏈"| FT & JOBS & SPECS & TST
    FT --- TST & JOBS & SPECS
```

> 設計意涵:8080 三頁吃的是「寫入端」Data Index GraphQL(`/graphql`)與 Health(`/q/health`);8090 五頁全部經 `/api/reconciliation/*` 讀 SQLite(唯讀微服務)。兩邊互不寫對方的資料來源——呼應 [ARCHITECTURE](../02-architecture/ARCHITECTURE.md) 的單寫者架構。

---

## 2. 逐頁詳解

### 2.1 index — 管理控制中心門戶(8080)

| 項目 | 說明 |
|------|------|
| 定位 | 全平台的入口 Hub:`<title>` 為「SonataFlow 10.2.0 - 門戶與控制中心 Hub」,hero 區自述「SonataFlow 系統管理與控制中心門戶」。純靜態導覽頁,**不呼叫任何後端 API**。 |
| 版面結構 | 頂部品牌列(SF logo)→ hero 徽章(`Quarkus 3.27.2 + SonataFlow 10.2.0 + SQLite Data Index`)→ 卡片網格 → 底部環境資訊盒(env-info-box:Quarkus Platform 3.27.2/SonataFlow 10.2.0/Data Index Storage=SQLite Embedded/Registered Workflows=5 Definitions)。 |

ASCII 版面示意:

```text
+--------------------------------------------------------------+
| SF  SonataFlow Control Center Hub      (KIE SonataFlow 10.2) |
+--------------------------------------------------------------+
|   [⚡ Quarkus 3.27.2 + SonataFlow 10.2.0 + SQLite Data Index] |
|          SonataFlow 系統管理與控制中心門戶                      |
+---------------------------+---------------------------+------+
| [🔄] Workflow Instances    | [📊] Custom Dashboard     | [📋] 對帳與審計日誌檢視器 |
| 實例檢視頁 (8080 站內)       | 統計儀表板 (8080 站內)      | (獨立微服務 8090) |
+---------------------------+---------------------------+------+
| [🎯] 全工作流沙盒測試除錯器   | [⏳] Jobs & Timers         | [🌳] OpenAPI 監控 |
| (獨立微服務 8090)           | (獨立微服務 8090)           | (獨立微服務 8090) |
+---------------------------+---------------------------+------+
| [🎨] 流程軌跡圖形化 (8090)  | [🛠️] Dev UI Workflows      | [📖] Swagger UI |
+---------------------------+---------------------------+------+
| [🔍] Data Index GraphQL UI | [💚] System Health Endpoint (/q/health)   |
+--------------------------------------------------------------+
| Quarkus 3.27.2 | SonataFlow 10.2.0 | SQLite | 5 Definitions  |
+--------------------------------------------------------------+
```

| 關鍵操作(卡片) | 目標 |
|------------------|------|
| Workflow Instances 實例檢視頁 | 站內 `./instances.html`(標記「🟢 補齊頁面」) |
| Custom Dashboard 統計儀表板 | 站內 `./dashboard.html` |
| 對帳與審計日誌檢視器/全工作流沙盒測試與除錯器/Jobs & Timers/OpenAPI 監控/流程節點執行軌跡(五張卡) | **跨 port 新視窗**開啟 `http://localhost:8090/*.html`(標記「✨ 獨立微服務 (8090)」) |
| SonataFlow Dev UI Workflows | `/q/dev-ui/org.apache.kie.sonataflow.sonataflow-quarkus-devui/workflows`(預覽已登記的 5 個 Serverless Workflow 定義與架構流程圖) |
| Swagger UI / OpenAPI | `/q/swagger-ui/` |
| Data Index GraphQL UI | GraphiQL(`/q/dev-ui/org.kie.kogito.kogito-addons-quarkus-data-index-graphql-ui/graphql-ui`) |
| System Health Endpoint | `/q/health` Raw JSON(卡片自述含 9 項健康檢查指標) |

---

### 2.2 dashboard — KPI & Analytics(8080)

| 項目 | 說明 |
|------|------|
| 定位 | 「📈 系統指標與數據儀表板」——實時從 SQLite Data Index GraphQL 及 SmallRye Health 彙整之 KPI 統計(Chart.js 圖表)。 |

ASCII 版面示意:

```text
+ SF SonataFlow Analytics Dashboard -- [🏠][🔄 Instances][📊 Dashboard*][🛠️ DevUI][💚 Health] +
| 📈 系統指標與數據儀表板                          [🔄 刷新數據圖表]
| [已登記 Workflow 定義: N] [累積 Process Instances: N] [系統整體健康狀態: UP] [Data Index 儲存引擎: SQLite]
|
| +-- 🍩 工作流實例狀態比例 (Status Ratio) --+  +-- 📊 各 Workflow 執行次數 (Top Workflows) --+
| |    Completed/Active/Error/Aborted        |  |    以 processId 分組的長條圖                |
| +-----------------------------------------+  +--------------------------------------------+
| 💚 系統與 Data Index 模組健康檢查狀態 (Health Check Breakdown)   [檢視原生 JSON -> /q/health]
|    📌 <check-name> UP ・ 📌 <check-name> UP ...(動態渲染 data.checks)
+---------------------------------------------------------------------------------------------+
```

| 功能/關鍵操作 | 打擊的 API |
|---------------|-----------|
| KPI 卡(定義數/實例數)+ 🍩 狀態甜甜圈圖 + 📊 Top Workflows 長條圖 | `POST /graphql`:一次 query 同時取回 `ProcessDefinitions { id name version }` 與 `ProcessInstances { id processId state }`,前端分組統計(COMPLETED/ACTIVE/ERROR/ABORTED 四色) |
| 系統整體健康狀態卡 + Health Check Breakdown | `GET /q/health`:取 `status` 與 `checks[]` 逐項列出名稱與狀態徽章 |
| 「🔄 刷新數據圖表」按鈕 | `refreshDashboard()` = Promise.all 同時重打上述兩個 API;初次載入自動執行 |

---

### 2.3 instances — Workflow Instances 實例管理(8080)

| 項目 | 說明 |
|------|------|
| 定位 | 實時檢視已執行的工作流實例(Process Instances)、狀態、變數快照與節點軌跡,**並支援一鍵觸發 Saga2 轉帳流程**(index 門戶卡片原文)。 |

ASCII 版面示意:

```text
+ SF SonataFlow Control Center -- [🏠][🔄 Instances*][📊 Dashboard][🛠️ DevUI][📖 Swagger] +
| [🔍 搜尋 Instance ID 或 Workflow 名稱...]  [所有狀態 v ACTIVE/COMPLETED/ERROR/ABORTED]
|                        (x)5s 自動更新  [🔄 重新整理]  [⚡ 觸發新 Saga2 轉帳流程]
| [總 Process Instances 數] [進行中 Active] [成功完成 Completed] [異常/中斷 Error/Aborted]
+--------------------------------------------------------------------------------------------+
| Instance ID(前8碼+複製) | Workflow 名稱 | 狀態(State 徽章) | 開始時間 | 結束/耗時 | 操作[檢視細節 v] |
|   展開列:📦 流程變數快照 (Process Variables,pretty JSON)
|            📌 執行節點軌跡 (Node Execution Timeline,每節點 enter 時間)
+--------------------------------------------------------------------------------------------+
| 彈窗:「⚡ 觸發 Saga2 雙階段轉帳工作流」 Account_A / Account_B / AMT 表單 -> 發送觸發請求
+--------------------------------------------------------------------------------------------+
```

| 功能/關鍵操作 | 打擊的 API |
|---------------|-----------|
| 實例表格 + 狀態徽章 + 展開列(變數快照/節點時間軸) | `POST /graphql`:query `ProcessInstances { id processId processName state start end variables nodes { id name enter exit } }` |
| 關鍵字搜尋(id/processId)、狀態過濾 | 純前端 filter(`renderInstances()`),不重打 API |
| ☑ 5s 自動更新 | 每 5 秒重打同一 GraphQL query(`toggleAutoRefresh()`) |
| 「⚡ 觸發新 Saga2 轉帳流程」彈窗(預設值 `Account_Web_UI_A`/`Account_Web_UI_B`/AMT=500) | `POST /saga2-transfer-workflow`,body `{Account_A, Account_B, AMT}`;完成後 alert 顯示 `result.status + result.message` 並自動刷新列表 |

---

### 2.4 reconciliation — Saga2 雙階段對帳流水(8090)

| 項目 | 說明 |
|------|------|
| 定位 | 「📋 轉帳交易審計與 Saga2 雙階段對帳流水」——由獨立對帳微服務(Port 8090)即時讀取 SQLite `vw_saga_reconciliation` 視圖與歷史 CSV(頁面副標原文)。 |

ASCII 版面示意:

```text
+ RC Reconciliation & Audit Portal (Decoupled Microservice Port 8090)
|   navbar: [🏠門戶->8080][🔄Instances->8080][📊Dashboard->8080][📋對帳與審計流水*]
| 📋 轉帳交易審計與 Saga2 雙階段對帳流水      [🔄 重新整理] [⚡ 立即產出新對帳 CSV 檔]
| [🔍 扣款帳號 Account A] [🔍 入帳帳號 Account B] [所有交易狀態 v SUCCESS/REFUNDED/ROLLED_BACK]
+--------------------------------------------------------------------------------------------+
| 📊 Saga2 轉帳交易與沖正/補償紀錄 (Audit Logs)                                 共 N 筆紀錄
| ID/時間 | Workflow/BusinessKey | Status 徽章 | 扣款->入帳(金額 TWD) | A16229扣款碼 | A16220入帳碼 | Saga補償狀態
|   補償欄:「✓ 正常無回沖」或「⚠️ 已觸發補償回沖 (code)」
+--------------------------------------------------------------------------------------------+
| 📁 歷史對帳 CSV 檔案庫 (Exported CSV Files)                                  [刷新檔案列表]
| 對帳檔名 reconciliation-YYYYMMDD-HHmmss.csv | 大小 Bytes | 產生時間 | [⬇ 預覽/下載]
|   彈窗:「📄 預覽對帳 CSV 檔案」全文文字預覽
+--------------------------------------------------------------------------------------------+
```

| 功能/關鍵操作 | 打擊的 API(`API_BASE = http://localhost:8090/api/reconciliation`) |
|---------------|-------------------------------------------------------------------|
| 流水表格(accountA/accountB/status 三重過濾,輸入即查) | `GET /records?accountA=&accountB=&status=`(`AuditQueryService#getReconciliationRecords` 讀 vw_saga_reconciliation) |
| 狀態徽章 SUCCESS/REFUNDED/ROLLED_BACK;補償欄依 rollback code 有無切換 | 同上,前端 `getStatusBadge()` 與 rollback 欄位判斷 |
| 「⚡ 立即產出新對帳 CSV 檔」 | `POST /export-csv`,body `{status:'ALL'}` |
| 歷史 CSV 檔案庫列表 | `GET /files`(回 filename/sizeBytes/lastModified) |
| 「⬇️ 預覽/下載」彈窗(全文文字) | `GET /files/{filename}` |

> 小提醒:此頁 status 下拉含 `REFUNDED` 選項屬舊語意相容;saga2 目前產出的 finalStatus 是 `ROLLED_BACK`(契約見 [REST-API-REFERENCE](../04-reference/REST-API-REFERENCE.md))。

---

### 2.5 flow-trace — 節點軌跡視覺化(8090)

| 項目 | 說明 |
|------|------|
| 定位 | 「🎨 流程節點執行軌跡圖形化頁面」——由獨立微服務將 GraphQL nodes 資料與 Saga2 兩階段沖正,轉換為 SVG/CSS 可視化亮燈軌跡圖(頁面副標原文);呈現 StartNode ➔ Execute ➔ Rollback 的亮燈走向(index 門戶原文)。 |

ASCII 版面示意:

```text
+ FT Workflow Node Trace Visualizer
|   navbar: [🏠->8080][🔄->8080][📊->8080][📋對帳][🎯沙盒][⏳Jobs][🌳OpenAPI][🎨流程軌跡圖*]
| [近期實例下拉 v (🟢/🔴 processId (#短ID) - 業務狀態 [時間])] [或貼上 Instance ID UUID...] [🔍 讀取軌跡圖]
|                     [⚡ 測試發送 (AMT=888 觸發回沖)] [⚡ 測試發送 (AMT=300 成功)]
+--------------------------------------------------------------------------------------------+
| Banner:Instance ID #xxxx | Process ID saga2-transfer-workflow | Start ... | [🟢 SUCCESS] / [🔴 ROLLED_BACK (LIFO 回沖)]
+--------------------------------------------------------------------------------------------+
| 💡 SVG/CSS 實例執行軌跡圖 (Flowchart Trace)
|   ●ValidateInput > ●CallA16229State > ●CallA16220State > ●RollbackA16220(🔴) > ●FinalAuditAndEnd
|   (綠燈=forward 正常;紅燈=補償沖正/觸發回沖;hover tooltip 顯示 type/#id/耗時 ms)
+---------------------------------------------------------------+----------------------------+
| ⏱️ 節點時間軸明細 (Execution Sequence)                          | 📦 實例變數 (Variables Inspection)
|   每節點卡:名稱/徽章/耗時 ms/Enter-Exit/❗errorMessage            | pretty-print JSON
|   點擊可展開 📥 INPUTS / 📤 OUTPUTS 區塊(has-io 卡片)             |
+---------------------------------------------------------------+----------------------------+
```

| 功能/關鍵操作 | 打擊的 API |
|---------------|-----------|
| 近期實例下拉(Map 依 id 去重;🟢SUCCESS/🔴ROLLED_BACK 上色) | `GET http://localhost:8090/api/reconciliation/instances` |
| 讀取軌跡圖(下拉選或手貼 UUID,Enter 亦可) | `GET /api/reconciliation/trace/{instanceId}`(回 instanceId/processId/status/startTime/variables/nodes[]) |
| 亮燈規則(前端 `getNodeStyle()`) | 名稱含 Rollback/沖正 或 state=ROLLED_BACK → 紅色「🔴 補償沖正」;ROLLED_BACK 軌跡中的 `DecideByEvaluation`/`InjectSuccessStatus` → 紅色「🔴 觸發回沖」;其餘綠色 forward;`EmbeddedStart`/`EmbeddedEnd`/`Script` 三類雜訊節點濾除不顯示 |
| 時間軸 I/O 明細(點擊展開) | trace 各節點的 `inputArgs`/`outputArgs`(資料源頭是 `NodeTracingProcessEventListener` 寫入 nodes 表,原理見 [OBSERVABILITY](../02-architecture/OBSERVABILITY.md)) |
| 兩顆測試發送鈕 | `POST /api/reconciliation/trigger-saga2`,body `{Account_A:'Trace_Demo_A', Account_B:'Trace_Demo_B', AMT:888 或 300}`(888 觸發 LIFO 回沖、300 成功,方便立即對比兩種亮燈走向) |

---

### 2.6 jobs — Jobs & Timers 管理(8090)

| 項目 | 說明 |
|------|------|
| 定位 | 「⏳ Kogito Jobs & Timers 延遲任務管理頁」——由獨立微服務監控 Data Index 與 SQLite `jobs` 資料表,提供排程中斷(Cancel)與異常手動發送重試機制(門戶卡片/頁面原文)。 |

ASCII 版面示意:

```text
+ JT Kogito Jobs & Timers Console
|   navbar: [🏠->8080][🔄->8080][📊->8080][📋對帳][🎯沙盒][⏳Jobs & Timers*]
| ⏳ Kogito Jobs & Timers 延遲任務管理頁                              [🔄 重新整理]
| [⏳ SCHEDULED 排程中: n] [✓ EXECUTED 已執行: n] [⚠️ ERROR/RETRY 異常重試: n] [🛑 CANCELED 已取消: n]
| [🔍 搜尋 Job ID / Process ID...]  [所有任務狀態 v SCHEDULED/EXECUTED/ERROR/RETRY/CANCELED]
+--------------------------------------------------------------------------------------------+
| Job ID | 綁定工作流 (Process ID / Instance) | 狀態徽章(+exceptionMessage) | 預定過期/觸發時間
|        | 重試次數 retries | Callback Endpoint | 手動干預操作
|          SCHEDULED / ERROR / RETRY 列 -> [🔄 重試] [🛑 取消](各帶 confirm 確認彈窗)
|          其餘狀態 -> 「無可用操作」
+--------------------------------------------------------------------------------------------+
```

| 功能/關鍵操作 | 打擊的 API |
|---------------|-----------|
| 任務列表 + 四宮格統計(SCHEDULED/EXECUTED/ERROR+RETRY/CANCELED 計數) | `GET http://localhost:8090/api/reconciliation/jobs?status=`(status 過濾由後端處理;Job ID/Process ID 搜尋為前端本地 filter) |
| 「🔄 重試」(僅 SCHEDULED/ERROR/RETRY 列顯示;confirm 後發送) | `POST /api/reconciliation/jobs/{id}/retry` |
| 「🛑 取消」(中斷排程;confirm 後發送) | `POST /api/reconciliation/jobs/{id}/cancel` |

---

### 2.7 specs — OpenAPI 規格監控 + ping(8090)

| 項目 | 說明 |
|------|------|
| 定位 | 「🌳 OpenAPI 規格與服務端點監控頁」——由獨立微服務實時載入 `src/main/resources/specs/` 規格做視覺化瀏覽,並提供 Mock 端點與 API Gateway 健康品質診斷(頁面原文)。雙欄式版面。 |

ASCII 版面示意:

```text
+ OS OpenAPI Specs & Endpoints Monitor
|   navbar: [🏠->8080][🔄->8080][📊->8080][📋對帳][🎯沙盒][⏳Jobs][🌳OpenAPI 監控*]
| 🌳 OpenAPI 規格與服務端點監控頁
+-------------------------------------------------------------------+------------------------+
| 🌳 OpenAPI 規格樹狀可視化                       [🔄 刷新規格]        | 🟢 Mock 服務與 API Gateway 點檢儀表板
| [規格下拉 v A16229-api.yaml (...)/A16220-api.yaml (...)]           |    [⚡ 一鍵測試所有連線]
| specMeta:標題 vX・描述・Server URL                                  | A16229 Mock (扣款) http://localhost:8080/A16229   [🔍 點檢]
| tree-view:spec rawContent(YAML 全文)                               | A16220 Mock (入帳) http://localhost:8080/A16220   [🔍 點檢]
|                                                                   | SonataFlow Saga2 Engine http://localhost:8080/saga2-transfer-workflow [🔍 點檢]
|                                                                   | 對帳微服務 (8090) .../api/reconciliation/records  [🔍 點檢]
|                                                                   | UAT API Gateway apimgw-uat.tcbbank.com.tw ...     [🔍 點檢]
|                                                                   | 每項結果徽章:🟢 ONLINE (status, latencyMs ms) / 🔴 OFFLINE
+-------------------------------------------------------------------+------------------------+
```

| 功能/關鍵操作 | 打擊的 API |
|---------------|-----------|
| 規格下拉 + metadata + YAML 全文樹狀檢視 | `GET http://localhost:8090/api/reconciliation/specs`(回 fileName/title/version/description/serverUrl/rawContent) |
| 單一端點「🔍 點檢」/「⚡ 一鍵測試所有連線」 | `POST /api/reconciliation/specs/ping`,body `{targetUrl}`,回 `{healthy, status, latencyMs}`;頁面載入時自動全量 ping 一次 |
| 內建點檢目標(`TARGET_ENDPOINTS`) | A16229 Mock(8080/A16229)、A16220 Mock(8080/A16220)、Saga2 引擎(8080/saga2-transfer-workflow)、對帳微服務(8090/api/reconciliation/records)、UAT API Gateway(https://apimgw-uat.tcbbank.com.tw/api/v1/transfer) |

> 維運用途:任何「轉帳一直失敗」的報障,先來此頁按一鍵測試——若 A16229/A16220 Mock OFFLINE 即為 mock 掛掉;若只有 UAT Gateway OFFLINE 且交易仍正常,屬外部聯調環境問題(mock 路線不打 Gateway)。

---

### 2.8 tester — 沙盒觸發任一 workflow 除錯(8090)

| 項目 | 說明 |
|------|------|
| 定位 | 「🎯 全工作流沙盒測試與除錯器」——線上選取專案 **5 大 Serverless Workflow**,編輯 JSON Request Payload 進行實時發送與 Step-by-Step 歷程除錯(門戶/頁面原文)。雙欄式版面。 |

ASCII 版面示意:

```text
+ SB Workflow Sandbox Debugger
|   navbar: [🏠->8080][🔄->8080][📊->8080][📋對帳][🎯沙盒測試除錯器*]
| 🎯 全工作流沙盒測試與除錯器
+---------------------------------------------+----------------------------------------------+
| ⚙️ 測試控制與 Payload 產生器                  | ⏱️ Step-by-Step 歷程追蹤與除錯 (Live Debugger)
| [🎯 選取 Serverless Workflow v]              |  Step 1 請求參數與代理目標 (Request Target)
|   saga2-transfer-workflow(Saga2 雙階段轉帳)   |    proxyEndpoint/targetUrl/method/payload JSON
|   saga-transfer-workflow(Saga 單階段轉帳)     |    [等待發送... -> 🚀 發送中 -> ✓ 請求已建立]
|   rest-workflow(REST 外部健康檢查)            |  Step 2 HTTP 響應碼與耗時 (HTTP Response)
|   java-workflow(Java 定製服務處理)            |    response_json + Code NNN (duration_ms)
|   OpenAPI-workflow(OpenAPI 規格介面對接)      |    [✓ Code 200 (123 ms) / ✕ Code 4xx]
| [📝 JSON Request Payload 編輯器 textarea]    |  Step 3 Data Index GraphQL 實例與節點軌跡
|                                             |    instanceId/processId/state/start/end/
| [⚡ 執行沙盒測試 (Run Test)]                  |    variables/nodesExecuted JSON
+---------------------------------------------+----------------------------------------------+
```

| 功能/關鍵操作 | 打擊的 API |
|---------------|-----------|
| 選 workflow 自動帶入 payload 範本(saga2 預設 `{Account_A:Sandbox_Saga2_A, Account_B:Sandbox_Saga2_B, AMT:888}`——刻意選會觸發回沖的金額;saga1 預設 AMT=500;其餘三支為空物件) | 純前端 `PAYLOAD_TEMPLATES` |
| 「⚡ 執行沙盒測試」(JSON 先前端 parse 驗證) | `POST http://localhost:8090/api/reconciliation/proxy-test`,body `{workflowPath, payload}`;後端代轉 `http://localhost:8080/{workflow}`(`AuditQueryService#proxyTestWorkflow`),回 `{status_code, duration_ms, response_json/response_text}` |
| Step 1 顯示請求參數與代理目標 | 前端組裝展示(含 targetUrl=`http://localhost:8080/{workflow}`) |
| Step 2 顯示 HTTP 響應碼與耗時 | 同 proxy-test 回應(≥200 且 <300 顯示綠色 ✓,否則紅色 ✕) |
| Step 3 GraphQL 實例軌跡(**最多重試 3 次、遞增等待 400/800/1200ms**) | `POST http://localhost:8090/api/reconciliation/graphql`,先帶 `where:{processId:{equal:$pid}}` 過濾查詢,空結果 fallback 全量查詢再本地過濾(`AuditQueryService#proxyGraphQL`;等待是為了讓 ProcessInstance 非同步寫入 SQLite) |

> 除錯套路:改 payload → Run Test → 看 Step 2 的 HTTP code(注意 RBFAIL 哨兵情境會得 409)→ 看 Step 3 的 nodesExecuted 確認走到的 state;再切到 [flow-trace](#25-flow-trace--節點軌跡視覺化8090) 看亮燈圖。

---

## 3. 頁面 ↔ API 對照總表

| 頁面 | 前端打擊的 endpoint | 後端處理類別#方法 |
|------|---------------------|-------------------|
| index | 無(純靜態導覽) | — |
| dashboard | `POST /graphql`、`GET /q/health` | Data Index GraphQL addon;SmallRye Health(`MyLivenessCheck` 等) |
| instances | `POST /graphql`、`POST /saga2-transfer-workflow` | Data Index;SonataFlow 生成的 workflow REST 端點 |
| reconciliation | `GET /api/reconciliation/records`・`/files`・`/files/{filename}`、`POST /api/reconciliation/export-csv` | `ReconciliationAuditResource#getRecords/getFiles/getFileContent/exportCsv` → `AuditQueryService`/`ReconciliationCsvExporter` |
| flow-trace | `GET /api/reconciliation/instances`・`/trace/{instanceId}`、`POST /api/reconciliation/trigger-saga2` | `ReconciliationAuditResource#getRecentInstances/getInstanceTrace/triggerSaga2` → `AuditQueryService#getRecentInstances/getInstanceTrace/triggerSaga2Transfer` |
| jobs | `GET /api/reconciliation/jobs`、`POST /api/reconciliation/jobs/{id}/retry`・`/cancel` | `ReconciliationAuditResource#getJobs/retryJob/cancelJob` → `AuditQueryService#getJobsRecords/retryJob/cancelJob` |
| specs | `GET /api/reconciliation/specs`、`POST /api/reconciliation/specs/ping` | `ReconciliationAuditResource#getOpenApiSpecs/pingEndpoint` → `AuditQueryService#getOpenApiSpecs/pingEndpoint` |
| tester | `POST /api/reconciliation/proxy-test`、`POST /api/reconciliation/graphql` | `ReconciliationAuditResource#proxyTest/proxyGraphQL` → `AuditQueryService#proxyTestWorkflow/proxyGraphQL` |

---

## 4. 常見錯誤

| 症狀 | 原因 | 解法 |
|------|------|------|
| 8090 五個頁面全部空白/打不到 API | reconciliation-app 沒啟動,或頁面寫死的 `http://localhost:8090` 與實際埠不符 | 先起 reconciliation-app;用 [specs 頁](#27-specs--openapi-規格監控--ping8090) 一鍵點檢五個目標端點定位斷點 |
| 8080 三頁圖表/列表空白但頁面能開 | `/graphql` 或 `/q/health` 異常(常見即 TROUBLESHOOTING ⑤ 的 timestamp 解析錯誤) | 開 DevTools 看response;`errors` 含 "Error parsing time stamp" 時見 [TROUBLESHOOTING ⑤](../07-operations/TROUBLESHOOTING.md);transfer-app 未啟動時整頁打不開 |
| instances 頁觸發彈窗送出後 alert 顯示失敗 | payload 不符驗證規則(同帳號/非法字元/AMT≤0 → HTTP 400 VALIDATION_FAILED)或 Account_B=RBFAIL 觸發 409 | 彈窗僅 alert `err.message`,細節以 curl 重放確認;驗證規則見 [TESTING-GUIDE](../06-testing/TESTING-GUIDE.md) 第四組測試 |
| tester 的 Step 3 顯示「未在 Data Index 找到有效實例」 | 實例尚未非同步寫入 SQLite(超過三次遞增等待),或 workflow 根本沒成功建立 | 等 1–2 秒手動再跑一次;或直接到 [instances 頁](#23-instances--workflow-instances-實例管理8080) 確認實例是否存在 |
| flow-trace 下拉沒有任何實例 | 8090 讀不到資料:`MYHELLO_DATA_DIR` 兩 app 指向不同目錄,DB 沒共享 | 確認兩 app datasource URL 指向同一 reconciliation.db(見 [CONFIG-REFERENCE](../04-reference/CONFIG-REFERENCE.md)) |
| CSV 預覽彈窗中文亂碼 | 預覽為純文字渲染,BOM 存在但瀏覽器字型/編碼判讀差異;下載後 Excel 開啟才是驗收基準 | 以下載的原檔用 Excel 驗證(BOM 完整性見 [TROUBLESHOOTING ⑪](../07-operations/TROUBLESHOOTING.md)) |
| 直接輸入網址 GET workflow 端點得 403 | RuntimeFilter 白名單策略(只准 POST) | 屬設計行為,見 [TROUBLESHOOTING ⑨](../07-operations/TROUBLESHOOTING.md) |
| 改了頁面 HTML 重啟後變回去 | 8080 三頁位於 distribution 建置同步範圍內;8090 五頁 canonical 在 domain-reconciliation | 修改 canonical 來源(第 1 節表格的檔案位置欄),詳見 [TROUBLESHOOTING ⑥](../07-operations/TROUBLESHOOTING.md) |

---

> 相關文件:[TESTING-GUIDE](../06-testing/TESTING-GUIDE.md)(與 UI 操作等價的自動化驗證)、[REST-API-REFERENCE](../04-reference/REST-API-REFERENCE.md)(上述 endpoint 的完整契約)、[OBSERVABILITY](../02-architecture/OBSERVABILITY.md)(flow-trace/nodes 資料的產生原理)、[ARCHITECTURE](../02-architecture/ARCHITECTURE.md)(8080/8090 部署模型)。
