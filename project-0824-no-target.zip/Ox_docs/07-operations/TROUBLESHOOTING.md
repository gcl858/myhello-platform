# TROUBLESHOOTING — myhello-platform 維運地雷手冊

> 本文為 Ox_docs 第 07 冊。收錄本平台已知的地雷/陷阱 12 項,每項以「症狀 → 原因 → 解法」對照表呈現;所有論述均附原始碼出處(`類別#方法` 為主,行號可能隨版本變動)。
> 術語依 [README 術語統一表](../README.md);測試面排查另見 [TESTING-GUIDE](../06-testing/TESTING-GUIDE.md)。

---

## 目錄(12 項地雷)

| # | 地雷 | 一句話摘要 |
|---|------|-----------|
| [①](#-jq-match-不能用-test) | jq `match()` 不能用 `test()` | jackson-jq 不支援 test(),條件寫法有固定套路 |
| [②](#-error-定義缺-code-被-codegen-靜默忽略) | error 定義缺 code 被 codegen 靜默忽略 | onErrors 引用不到錯誤定義,卻沒有任何報錯 |
| [③](#-workflow-timeout-必須大於-myopenapiservice-http-timeout) | workflow timeout 必須大於 HTTP timeout | 引擎先斷就拿不到標準化錯誤 body |
| [④](#-sqlite-wal-lock-contentiondatabase-is-locked) | SQLite WAL lock contention | 單寫者 + busy_timeout + max-size=1 的鐵三角 |
| [⑤](#-graphql-timestamp-error-parsing-time-stamp) | GraphQL "Error parsing time stamp" | SQLite timestamp dialect 修補被移除的症狀 |
| [⑥](#-手改-distributiontransfer-appsrcmainresources-被靜默覆蓋) | 手改 distribution resources 被覆蓋 | sync-domain-resources 每次建置靜默還原 |
| [⑦](#-離線建置-offline-packagesmaven-repo-空) | 離線建置 maven-repo 是空的 | `-o` 模式下依賴解析必敗 |
| [⑧](#-port-衝突8080--8090--test-port) | Port 衝突 8080/8090/test-port | 三個埠各有主人 |
| [⑨](#-非-post-請求一律-403runtimefilter-白名單) | 非 POST 一律 403 | RuntimeFilter 白名單之外的請求全擋 |
| [⑩](#-回沖失敗人工介入-soprollback_failed) | 回沖失敗人工介入 SOP | RBFAIL 重現 → [OPS-ALERT] → vw_saga_reconciliation |
| [⑪](#-csv-中文亂碼bom) | CSV 中文亂碼 | 缺 UTF-8 BOM,Excel 判錯編碼 |
| [⑫](#-windowslinux-路徑差異) | Windows/Linux 路徑差異 | PlatformPaths#normalizeClasspath 與相對路徑慣例 |

---

## ① jq `match()` 不能用 `test()`

| 項目 | 內容 |
|------|------|
| **症狀** | 在 switch 的 dataConditions 寫出 `(.Account_A \| test("^[A-Za-z0-9_]+$"))` 形式的驗證條件後,workflow 建置或執行期報 jq 運算式錯誤;或輸入驗證整個不生效、直接放行。 |
| **原因** | 本平台 workflow 引擎的 jq 實作是 **jackson-jq**,不支援 jq 標準的 `test()` 函式;正規表示式匹配必須改用 `match()`。另外兩個隱性陷阱:`match()` 對缺失/null 欄位呼叫會拋例外繞過驗證;且 jackson-jq 對「匹配失敗」回傳的是空結果串流而非 `false`,不能直接當布林用。 |
| **解法** | 採用 saga2 範本 `ValidateInput`(switch state)的固定套路(見下方程式碼):三層結構缺一不可——`// ""` 先把缺失/null 收斂成空字串(null-safety);`\| match(...) // false` 把空串流變明確布林;`== false` 把「匹配不到」導向失敗分支。數字驗證則用型別判斷 `${ .AMT \| type != "number" }`(null 的 type 即 `"null"`,自然落入)。 |

```yaml
# saga2-transfer-workflow.sw.yaml / ValidateInput(state 行號可能隨版本變動)
condition: '${ ((.Account_A // "") | match("^[A-Za-z0-9_]+$") // false) == false }'
```

> 更多 jq 配方見 [WORKFLOW-COOKBOOK](../03-workflow-dev-guide/WORKFLOW-COOKBOOK.md);完整 18-state 解析見 [SAGA2-TEMPLATE-DEEP-DIVE](../03-workflow-dev-guide/SAGA2-TEMPLATE-DEEP-DIVE.md)。

---

## ② error 定義缺 code 被 codegen 靜默忽略

| 項目 | 內容 |
|------|------|
| **症狀** | 明明在 workflow YAML 寫了 `errors:` 定義並在 state 掛上 `onErrors`,執行期的非預期例外卻不走兜底分支——AuditLog 缺失、對帳出現缺口;且**建置過程無任何警告**。 |
| **原因** | Kogito codegen 要求每一筆 error 定義**必須含 `code` 欄位**,否則該筆定義會被**靜默忽略**;onErrors 以名稱匹配不到任何已註冊錯誤,等於沒掛。saga2 範本 YAML 內有原註:「注意:Kogito codegen 要求 error 定義必須含 code,否則該定義會被忽略」。 |
| **解法** | 每筆 error 都補上 code(照抄下方 saga2 範本寫法)。自查:grep 新 workflow 的 `errors:` 區塊確認每筆都有 `code:`;再核對各 state 的 `onErrors[].errorRef` 名稱可命中。參考實作:saga2 六個 switch/operation state 全部掛 `platformError` 收斂至統一終點 `FinalAuditAndEnd`,保障「任何錯誤都留審計」。 |

```yaml
# saga2-transfer-workflow.sw.yaml(errors 區塊)
errors:
  - name: platformError
    code: 'PLATFORM_ERROR'
    description: 平台層非預期錯誤 (state timeout / 引擎例外 / 服務未攔截例外)
```

---

## ③ workflow timeout 必須大於 MyOpenApiService HTTP timeout

| 項目 | 內容 |
|------|------|
| **症狀** | 外部 API 變慢或掛掉時,拿到的不是標準化錯誤 JSON(`code="999"` + `errorType`),而是引擎層中斷(state timeout → platformError 兜底);Check* switch 完全沒機會依業務契約分流,Saga 判斷失準。 |
| **原因** | `MyOpenApiService#callOpenApi` 有自己的 HTTP 逾時(常數 `DEFAULT_HTTP_TIMEOUT = Duration.ofSeconds(10)`;可由全域 `kogito.sw.openapi.timeout-seconds` 或單次 `arguments.timeoutSeconds` 覆寫),逾時時它會自行吞例外並回傳標準化錯誤節點(`MyOpenApiService#transportError`)。若 workflow state 的 timeouts 比 HTTP timeout 小,**引擎先一步掐斷 action**,服務層的標準化回應永遠到不了 state data。 |
| **解法** | 保持 saga2 v2.1.0 以來的防線:**state timeouts > MyOpenApiService HTTP timeout**。saga2 各 operation state 配置 `actionExecTimeout: PT15S` + `stateExecTimeout: PT30S`(workflow 層 `timeouts.workflowExecTimeout: PT5M`),皆大於預設 HTTP 10 秒,讓服務層先回傳 `code=999 + errorType=TRANSPORT` 交給 Check* switch。調整任一側前檢查相對大小;若調大全域 HTTP timeout,同步放大 state timeouts。 |

---

## ④ SQLite WAL lock contention(database is locked)

| 項目 | 內容 |
|------|------|
| **症狀** | 日誌/API 回應出現 SQLite `database is locked` 或 `SQLITE_BUSY`;多筆轉帳同時收尾時 AuditLog 寫入偶發失敗(`auditSaved=false`)。 |
| **原因** | 平台刻意採「**單一 SQLite 檔、單一寫者**」架構:transfer-app(8080)負責所有寫入,reconciliation-app(8090)設 `quarkus.datasource.jdbc.read-only=true` 只讀;連線池壓到單一連線(`quarkus.datasource.jdbc.max-size=1`,platform-data-index base application.properties)。任何違反此架構的改動(讓 8090 可寫、調大 pool、行程殘留佔住 DB 檔)都會重新引入 lock contention。 |
| **解法** | 守住鐵三角:① **WAL + busy_timeout**:`AuditLogService#initDatabase` 啟動即執行 `PRAGMA journal_mode=WAL;` 與 `PRAGMA busy_timeout=5000;`;platform-data-index base 另以 JDBC properties 固化 `journal_mode=WAL`・`synchronous=NORMAL`・`foreign_keys=true`;② **單寫者**:寫入只走 transfer-app 的 `AuditLogService`,8090 保持 read-only(%test 段才放開 false 供種資料);③ **max-size=1 不動**:SQLite 單檔調大連線池零收益、只增鎖風險。仍遇 lock 時排查:是否有殘留 JVM/另一台機器的 app 開著同一個 reconciliation.db;兩個 app 的 `MYHELLO_DATA_DIR` 是否指向同一目錄。深入運維見 [DATABASE-REFERENCE](../04-reference/DATABASE-REFERENCE.md)。 |

---

## ⑤ GraphQL timestamp "Error parsing time stamp"

| 項目 | 內容 |
|------|------|
| **症狀** | `POST /graphql` 查詢含 `start`/`end`(如 ProcessInstances)時,response `errors` 出現 `Error parsing time stamp`(DateTimeParseException);[instances/dashboard 頁](UI-PAGES.md) 圖表空白。典型觸發:升級 Kogito addon、誤改 Hibernate dialect 設定、重建專案後 platform-data-index 未納入。 |
| **原因**(來龍去脈) | Data Index 以 Hibernate 讀 SQLite TEXT 欄位中的 ZonedDateTime:Kogito SQLite 擴展寫入的是 **Unix epoch 毫秒字串**(如 `"1786185258763"`),而 Hibernate 社群版 SQLiteDialect 預設只懂 ISO-8601 字串,相遇即拋 DateTimeParseException。平台以自訂 dialect 修補:`KogitoSQLiteDialect#contributeTypes` 註冊 `SqliteZonedDateTimeJdbcType.INSTANCE` + `SqliteZonedDateTimeJavaType.INSTANCE`,讀取同時相容 epoch-ms 與 ISO-8601 兩種字串(javadoc 明言此舉修復 GraphQL ProcessInstances timestamp parsing bug)。設定錨點:`quarkus.hibernate-orm.dialect=org.acme.platform.dataindex.KogitoSQLiteDialect`。 |
| **解法** | ① 確認 dialect 指向 `KogitoSQLiteDialect`(而非 `org.hibernate.community.dialect.SQLiteDialect`);② 確認 platform-data-index 修改後有重新 install 打進 distribution app;③ 迴歸定位:跑 `DataIndexGraphQLTest#testProcessInstancesQuery`(此雷的自動化哨兵,詳見 [TESTING-GUIDE](../06-testing/TESTING-GUIDE.md))。 |

---

## ⑥ 手改 distribution/transfer-app/src/main/resources 被靜默覆蓋

| 項目 | 內容 |
|------|------|
| **症狀** | 直接編輯 `distribution/transfer-app/src/main/resources/` 下的 workflow YAML/specs/schema,當下生效;下一次 `mvn package` 後修改憑空消失,舊問題復發。 |
| **原因** | 「**單一事實來源(Single Source of Truth)**」設計:canonical 版本在 `domain-transfer/*` 各模組,distribution 內同名檔案是建置產物(已列 .gitignore)。`distribution/transfer-app/pom.xml` 的 maven-resources-plugin 於 **initialize 階段**執行 execution id `sync-domain-resources`,以 `overwrite=true` 自 domain-transfer 的兩個模組(transfer-workflow、transfer-samples)複製資源蓋掉副本;pom 原註:「直接編輯本模組的副本會在下一次建置被靜默覆蓋,請一律修改 domain 模組來源」。 |
| **解法** | 改 canonical 來源:workflow YAML 與 mock API specs(均已併入 workflow 模組)→ `domain-transfer/transfer-workflow/src/main/resources/`;示範 workflows → `domain-transfer/transfer-samples/src/main/resources/`;改完重建,sync 自動帶入。application.properties 不受影響(僅 distribution 存在)。另注意 HTML 頁面 canonical 位置不同:8090 五頁在 `domain-reconciliation/reconciliation-api/src/main/resources/META-INF/resources/`(見 [PROJECT-LAYOUT](../01-getting-started/PROJECT-LAYOUT.md))。 |

---

## ⑦ 離線建置 offline-packages/maven-repo 空

| 項目 | 內容 |
|------|------|
| **症狀** | 斷網環境執行 `./offline-build.sh`:要嘛腳本立刻退出「❌ 錯誤:找不到離線套件庫目錄」,要嘛通過目錄檢查後 mvn 在依賴解析階段大量報 `Cannot access ... in offline mode` 失敗。 |
| **原因** | 腳本核心指令為 `mvn clean package -o -Dmaven.repo.local="${SCRIPT_DIR}/offline-packages/maven-repo"`(`-o` = strict offline,完全不觸網)。離線庫目錄目前存在但**是空的(0 個 artifact)**——strict offline 下任何不在本地倉庫的依賴必然解析失敗。該目錄設計上應隨完整交付包填充;clone/搬移過程常因體積或 .gitignore 而清空。 |
| **解法** | 二選一:① **填充離線庫**——在有網環境以同一 `-Dmaven.repo.local=./offline-packages/maven-repo` 跑一次完整 `mvn clean package`(不加 `-o`),讓 Maven 把全部依賴灌進該目錄,之後即可斷網重現;② **改用線上 mvn**——環境可上網時直接 `mvn clean package`。腳本成功後產出 `distribution/*/target/quarkus-app/quarkus-run.jar`(腳本尾端訊息所載)。Windows PowerShell 腳本參數語意見 [GETTING-STARTED](../01-getting-started/GETTING-STARTED.md)。 |

---

## ⑧ Port 衝突(8080 / 8090 / test-port)

| 項目 | 內容 |
|------|------|
| **症狀** | 啟動 app 報 `Port 8080 in use`;或跑測試時 self-call 打到別的行程導致情境全錯;或 8090 頁面全部打不到後端 API。 |
| **原因** | 埠分配剛性:transfer-app=**8080**(讀寫交易,A16229/A16220 mock 也在此)、reconciliation-app=**8090**(`quarkus.http.port=8090`)、transfer-app %test 測試埠=**8080**(`%test.quarkus.http.test-port=8080`,設定註解明言「將測試 port 改回 8080,讓 self-call 可命中」;reconciliation-app %test 雖為 8081 但其模組內無測試類)。衝突來源多半是上一輪 JVM 沒關乾淨、其他專案佔 8080、或 dev mode 與 packaged jar 同時開著。 |
| **解法** | 啟動前清場:Linux `lsof -i :8080 -i :8090`、Windows `netstat -ano \| findstr :8080`,終止殘留 PID;同一時間只跑一種形態(`quarkus:dev` OR `quarkus-run.jar` OR `mvn test`)。**不要**為避衝突改 %test port——workflow function 配置 `kogito.sw.functions.callApiViaOpenAPI.host=localhost/port=8080` 寫死回打 8080,改埠 self-call 即斷。8090 頁面打不到 API 時,先用 [specs 頁](UI-PAGES.md)一鍵點檢五個目標端點。 |

---

## ⑨ 非 POST 請求一律 403(RuntimeFilter 白名單)

| 項目 | 內容 |
|------|------|
| **症狀** | 對 `/saga2-transfer-workflow` 或自訂 REST 端點發 GET/DELETE 得到 `403 {"error": "Only POST method is allowed"}`;瀏覽器直接開 URL 也是 403。看似故障,實為安全策略。 |
| **原因** | `SonataFlowSecurityConfig$RuntimeFilter`(ContainerRequestFilter)實作「白名單之外一律只准 POST」。放行條件(任一):路徑以 `q/` 開頭(Quarkus 系統頁)、以 `.html`/`.js`/`.css`/`.ico` 結尾(靜態資源)、路徑含 `reconciliation`/`specs`/`instances`/`jobs`/`trace` 關鍵字(對帳與監控查詢 API);其餘非 POST 一律 abort with 403。此 filter 同時緩存 input payload 供稽核(`rawInputPayload`)與起算耗時,403 是設計行為。 |
| **解法** | 業務呼叫一律 POST;查詢需求走已被白名單涵蓋的 `/api/reconciliation/*`(路徑天然含關鍵字)。若新增的查詢端點被誤擋:優先調整路徑命名納入既有關鍵字,或在 `SonataFlowSecurityConfig$RuntimeFilter` 排除清單追加(同步評估 SwaggerFilter 口徑),**不要**停用整個 filter。附帶認知:Swagger UI 不顯示 DELETE/PUT/PATCH/HEAD(`SwaggerFilter#filterPathItem` 移除),API 以 POST 為主屬正常。 |

---

## ⑩ 回沖失敗人工介入 SOP(ROLLBACK_FAILED)

回沖失敗 = 扣款已發生但補償也失敗 = **帳務不一致的最糟情境**。平台內建完整的偵測 → 告警 → 重現工具鏈。

### 10.1 平台自動化鏈(偵測與告警)

```mermaid
flowchart TD
    A["Rollback* state(EC=true 回沖)"] --> B{"任一回沖 code != 100?"}
    B -- 否 --> C["ROLLED_BACK 正常收尾"]
    B -- 是 --> D["InjectRollbackFailedStatus<br/>finalStatus=ROLLBACK_FAILED<br/>message=⚠️ 回沖失敗,需人工介入處理"]
    D --> E["FinalAuditAndEnd"]
    E --> F["AuditLogService#saveLog<br/>auditSaved=true(審計必留)"]
    E --> G["OpsAlertService#raise<br/>logger OPS-ALERT ERROR:<br/>[OPS-ALERT] 回沖失敗,需人工介入..."]
    E --> H["輸出 opsAlertRaised=true"]
    H --> I["WorkflowStatusFilter 改寫 HTTP 409"]
```

- 觸發判定:`CheckRollbackResults`(LIFO 全回沖路徑,條件 `.a16229Rollback.code != "100" or .a16220Rollback.code != "100"`)與 `CheckRollbackA16229OnlyResult`(部分回沖路徑,default 分支)。
- 告警通道:`OpsAlertService#raise` 僅對 `finalStatus == "ROLLBACK_FAILED"`(常數 `ALERT_ON_STATUS`)輸出 `[OPS-ALERT]`;ELK/Splunk 以關鍵字 `[OPS-ALERT]` 建告警規則接單。服務回傳 `{raised:true|false}`,workflow 輸出經 `opsAlertRaised` 可見。

### 10.2 值班 SOP(人工六步)

| 步驟 | 操作 | 依據/工具 |
|------|------|----------|
| 1. 確認告警 | grep `logs/transfer-app.log` 的 `[OPS-ALERT]`,記下 workflowId/instanceId/businessKey/finalMessage/detail(含兩腳 rollback 結果) | `OpsAlertService#raise` 日誌格式 |
| 2. 找問題紀錄 | 查 `reconciliation.db`:`SELECT * FROM vw_saga_reconciliation WHERE status='ROLLBACK_FAILED'`;或經 8090 `GET /api/reconciliation/records?status=ROLLBACK_FAILED`;以 business_key 對照告警 | view 由 `AuditLogService` 遷移建立 |
| 3. 判定失敗腳位 | 看 `a16229_rollback_code` / `a16220_rollback_code` 何者非 100:LIFO 中 RollbackA16220 先走,可能 A16220 腳失敗而 A16229 已補救成功(半一致),或雙失敗(完全不一致) | `RollbackA16220` → `RollbackA16229` 順序 |
| 4. 重現(可選) | 以 RBFAIL 哨兵重演:A16220 腳 → `POST /saga2-transfer-workflow {"Account_B":"RBFAIL","AMT":600}`;A16229 腳 → `{"Account_A":"RBFAIL","AMT":2000}`;正確反應均為 HTTP 409 + status=ROLLBACK_FAILED | `A16220Resource`/`A16229Resource` 哨兵;自動化版 `Saga2TransferWorkflowTest#[17][18]` |
| 5. 帳務補償 | 依 mock/真實系統差異人工沖正並登記(平台不做自動銷帳) | — |
| 6. 收斂觀察 | 外部系統暫時性故障恢復後,可用 [tester 頁](UI-PAGES.md)重發驗證;持續失敗用 [specs 頁](UI-PAGES.md)點檢目標 API 健康 | UI-PAGES |

---

## ⑪ CSV 中文亂碼(BOM)

| 項目 | 內容 |
|------|------|
| **症狀** | 匯出的對帳 CSV 用 Excel 開啟中文全是亂碼;用記事本/VS Code 開反而正常。 |
| **原因** | Excel(尤其中文 Windows 版)不以 UTF-8 解析無 BOM 的 CSV,誤判為 Big5/ANSI。匯出器 `ReconciliationCsvExporter#exportToCsv` 特意在檔頭寫入 **UTF-8 BOM(0xEF 0xBB 0xBF)**,javadoc 原註:「UTF-8 BOM: 讓 Excel 開啟中文不亂碼」。看到亂碼代表手上檔案的 BOM 已被剝除——多半是事後腳本二次加工,或從 response 文字重新存檔所致。 |
| **解法** | ① 重新原生匯出:`POST /reconciliation/export-csv`(8080)或 [對帳頁](UI-PAGES.md)「立即產出新對帳 CSV 檔」,取回 `filePath` 指向的原檔,勿二次轉碼;② 自寫腳本處理 CSV 時保留前三 byte(byte 層級讀寫,別用文字模式讀完再寫出);③ 自動化守門可抄 `ReconciliationCsvTest#testAEmptyCsvStillHasHeader` 的 byte[0..2]==EF BB BF 斷言。 |

---

## ⑫ Windows/Linux 路徑差異

| 項目 | 內容 |
|------|------|
| **症狀** | 同份 workflow/測試在 Linux 正常、Windows 報「找不到指定的 OpenAPI 規格檔案 classpath:specs\\A16229-api.yaml」之類錯誤;CSV 路徑 regex 斷言只在其中一個 OS 通過;SQLite 絕對路徑連不上。 |
| **原因** | Windows 風格分隔符 `\` 混進 classpath/JDBC 路徑:Java ClassLoader 規格要求 classpath 資源一律用 `/`;SQLite JDBC 雖兩種分隔符皆接受,拼接方式不一致仍會踩雷。 |
| **解法** | 使用平台統一工具、不要自己拼路徑字串:① **classpath 類**——`PlatformPaths#normalizeClasspath(input)` 把 `\` 轉 `/`、去重複斜線、去首尾斜線(`MyOpenApiService#callOpenApi` 解析 schemaRef 時已內建呼叫,上游傳入 Windows 風格自動救回);② **檔案系統類**——`PlatformPaths#dataDirectory()/dataFile()/sqliteUrl()` 基於 `java.nio.file.Path` 與 `findProjectRoot()` 產生 OS 原生絕對路徑,支援 `MYHELLO_DATA_DIR`/`MYHELLO_LOGS_DIR` 覆寫;③ **測試慣例**——DB 用相對路徑 `jdbc:sqlite:target/test-reconciliation.db`(跨平台最省事),CSV 路徑 regex 學 `Saga2TransferWorkflowTest#testExportCsvAllRecords` 以 `File.separator` 動態構造。 |

---

## 快速索引:症狀 → 條目

| 你看到的 | 先翻 |
|----------|------|
| jq/條件運算式報錯 | [①](#-jq-match-不能用-test) |
| onErrors 沒反應 | [②](#-error-定義缺-code-被-codegen-靜默忽略) |
| timeout 時拿不到 code=999/errorType | [③](#-workflow-timeout-必須大於-myopenapiservice-http-timeout) |
| database is locked | [④](#-sqlite-wal-lock-contentiondatabase-is-locked) |
| Error parsing time stamp | [⑤](#-graphql-timestamp-error-parsing-time-stamp) |
| 改的 YAML/specs 自己變回去 | [⑥](#-手改-distributiontransfer-appsrcmainresources-被靜默覆蓋) |
| 離線 mvn 失敗 | [⑦](#-離線建置-offline-packagesmaven-repo-空) |
| Port in use / 測試打到別人 | [⑧](#-port-衝突8080--8090--test-port) |
| 403 Only POST method is allowed | [⑨](#-非-post-請求一律-403runtimefilter-白名單) |
| [OPS-ALERT] / 409 ROLLBACK_FAILED | [⑩](#-回沖失敗人工介入-soprollback_failed) |
| Excel 開 CSV 亂碼 | [⑪](#-csv-中文亂碼bom) |
| Windows 找不到 spec/DB | [⑫](#-windowslinux-路徑差異) |

> 相關文件:[TESTING-GUIDE](../06-testing/TESTING-GUIDE.md)(自動化守門)、[CONFIG-REFERENCE](../04-reference/CONFIG-REFERENCE.md)(status-rewrite/retry/port 參數)、[OBSERVABILITY](../02-architecture/OBSERVABILITY.md)(errorType/[OPS-ALERT]/節點軌跡原理)、[DATABASE-REFERENCE](../04-reference/DATABASE-REFERENCE.md)(vw_saga_reconciliation/WAL 運維)、[UI-PAGES](UI-PAGES.md)(頁面操作入口)。
